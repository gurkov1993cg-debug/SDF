SILVETON ARRANGER — автоматичен Android APK (GitHub SDF)
Постоянни имена: SILVETON-ARRANGER.zip и SDF.yml

Еднократно:
  1. Постави SDF.yml в .github/workflows/SDF.yml в хранилището gurkov1993cg-debug/SDF.
  2. Постави SILVETON-ARRANGER.zip в основната директория на main. Не го разархивирай предварително.
  3. GitHub Actions стартира автоматично при всяка замяна на ZIP-а и при промяна на workflow файла.

GitHub Actions:
  - проверява ZIP-а и го разархивира временно на runner машината;
  - стартира C++ регресионни тестове за PCM, Drum Kit, SET bank, Sampler;
  - компилира Android ARM64 с SDK 35, NDK 27 и Gradle 8.9;
  - проверява APK, подписа, версията и 16 KiB ELF/ZIP подравняването;
  - само при успешна компилация и проверки публикува GitHub Release с директен .apk файл.

След първи успешен build — постоянен адрес за директен APK:
https://github.com/gurkov1993cg-debug/SDF/releases/latest/download/SILVETON-ARRANGER.apk

ВНИМАНИЕ: За обновяване без деинсталиране е нужен постоянен signing key, зададен през GitHub repository secrets:
  SILVETON_ANDROID_KEYSTORE_BASE64
  SILVETON_ANDROID_KEYSTORE_PASSWORD
  SILVETON_ANDROID_KEY_ALIAS
  SILVETON_ANDROID_KEY_PASSWORD
При липса на secrets CI използва временния Android debug ключ: APK може да се инсталира, но следващ build може да не се инсталира върху него.

GitHub Actions не потвърждава реалната работа на звука и MIDI на Samsung SM-X130. Проверки с действителни Korg SET и PCM файлове остават необходими.
