SILVETON ARRANGER — GitHub Actions Android ARM64
Версия 0.1.72, build 69 (2026-11-23)

ФАЙЛОВЕ ЗА РЕПОТО: https://github.com/gurkov1993cg-debug/SDF
1) Замени точно .github/workflows/SDF.yml в GitHub с този от пакета.
2) Качи SILVETON-ARRANGER.zip в основната папка (root) на main (НЕ го разархивирай в репото).
3) Отвори Actions -> SILVETON ARRANGER Android ARM64 APK. Изпълнението трябва да започне автоматично след commit на ZIP-а, или избери Run workflow.
4) При PASS отвори Releases -> Latest и свали директно SILVETON-ARRANGER.apk.

Workflow първо изпълнява 4 C++ regression test програми и едва след успех компилира с Android SDK 35 / NDK r27 / ARM64, подписва, и валидира native ELF и APK.

ЗАЩО 2 ФАЙЛА: GitHub не компилира ZIP-а автоматично от само себе си. Нужен е отделен .github/workflows/SDF.yml в GitHub. Опитът за директен GitHub write от този разговор беше отхвърлен с 403.

ВАЖНО: Предишен APK с друг ключ няма да се обнови върху инсталираното приложение. Запази конфигурацията и SET пътищата. С временно CI подписване може да се наложи отделна инсталация.

Чети CHANGES_0.1.71_BG.txt вътре в ZIP. В този пакет няма гаранция за 100% Korg SET и няма реален tablet/Android build тест.
