# Original Korg Drum Kit Exclusive Group import

The importer reads the group number stored in each original Drum Kit key
record. It copies all 128 assignments, including `0` (None), into the immutable
Program table used by SILVETON's existing group runtime. It does not assign
groups from note positions, sample names, Drum Families or GM conventions.

This is an independently calibrated field layout. The Korg user manuals
document the control and factory assignments; they do not publish this Pa
binary record format. The semantic and cross-version evidence below is kept
separate from the supported playback behavior.

## Versioned field

Offsets are zero-based from the beginning of a single decoded key row, after
the normal bounded PCG/OC31 and Drum Kit graph parser has succeeded.

| Resource version | Key row bytes | Layer-count offset | Exclusive Group offset | Later key-flags offset, not imported |
| --- | ---: | ---: | ---: | ---: |
| 0.0, 1.0 | 18 | 2 | 7 | 8 |
| 2.0, 3.0 | 18 | 2 | 8 | 9 |
| 5.0, 6.0 | 20 | 4 | 10 | 11 |
| 7.0 | 22 | 4 | 10 | 13 |
| 8.0 | 29 | 4 | 10 | 13 |

Version 5 adds a two-byte field before the layer count. Version 7 adds two
bytes **after** the group number and before the flags. Version 8 extends the
velocity-switch area by seven bytes. Consequently, the group remains at
offset 10 for versions 5 through 8. All 14,592 version 7/8 rows in the inspected
original corpus contain zero in the two added bytes; their meaning is not
inferred from that observation.

`decodePa5xDrumExclusiveGroups` accepts only the listed major versions with
minor version zero and an already decoded reference graph. It additionally
checks exact row sizes, agreement with the parsed first-layer/count fields,
the bounded layer span, the existing three-byte sentinel and group range
0–127. A failure clears the complete output and returns false. An unsupported
version is never interpreted through a nearest-version fallback.

`buildPa5xDrumKeyGroups` returns a complete immutable table on success,
including a valid all-None table. It returns `nullptr` when metadata is
unavailable, unsupported or malformed. Only `exclusiveGroup` is imported.

## Independent semantic calibration

The official **Pa1X User's Manual 2.52**, printed pages 300–301 (PDF pages
304–305), labels the factory Drum Kit columns `Excl.` and explicitly defines
their group behavior. Its Standard Kit RX maps specify these eleven controls
independently of the hi-hat assignments:

| Original MIDI key(s) | Documented Exclusive Group |
| --- | ---: |
| 25, 29, 30 | 7 |
| 71, 72 | 2 |
| 73, 74 | 3 |
| 78, 79 | 4 |
| 80, 81 | 5 |

In the original corpus, **36 kits agree with every one of these eleven
assignments at the indicated group byte**: one version 0 kit, twelve version
2 kits, twelve version 5 kits and eleven version 8 kits. In those same kits,
every alternative byte position in the key record agrees with at most two
of the eleven values. Examples include `ZDR` (v0), `Drums 03 4x` and
`FUNK.kit` (v2), `Musi 15` and `Musi 19` (v5), and `Musi 33` and `Musi 36`
(v8). The comparison calibrates the meaning of a field; none of these note
numbers or factory assignments appear in the runtime decoder.

The official **Pa800 User's Manual 2.01**, printed pages 302–304, supplies an
additional sample-identity check for the original v0 `ZDR` kit. Its ROM sample
numbers 320/322/323 identify the closed/foot/open hi-hat entries at keys
42/44/46, whose stored group number is 1. ROM 450 is Samba Whistle at key 71
(group 2); ROM 448/447 identify the short/long guiro at keys 73/74 (group 3);
ROM 634/633 identify the mute/open triangle at keys 80/81 (group 5).
Other keys in this user kit were edited, so no claim is made that every ROM
sample or group still equals a factory kit. ROM numbering also differs
between models; Pa1X numbers are not substituted for Pa800 numbers.

The legacy record framing is independently consistent with the original
KORG-Tools versioned Sound readers. That source retains the two bytes as
`unknown13`; it is evidence for their location, not a published name for the
group field. SILVETON's implementation is its own bounded decoder.

## Cross-version corroboration from the original files

The supplied original standalone bank, Pa4X SET and Pa5X reference SET contain
326 successfully decoded kits, or **41,728 original key records**:

| Resource version | Original kits | Keys with nonzero stored group |
| --- | ---: | ---: |
| 0.0 | 2 | 20 |
| 1.0 | 2 | 0 |
| 2.0 | 96 | 1,042 |
| 5.0 | 105 | 1,480 |
| 6.0 | 7 | 66 |
| 7.0 | 8 | 110 |
| 8.0 | 106 | 1,549 |
| **Total** | **326** | **4,267** |

Two original Pa600 `new_dk`/`allvaluesset_dk` fixtures from KORG-Tools also
confirm the version 3 row grammar (256 additional rows). Both contain all-None
groups; they do not independently establish nonzero group semantics.

For the cross-version comparison, the first-layer table index and the added
two-byte index field are excluded. The comparison retains the layer count,
all shared control bytes, the first five velocity switches and the sentinels;
the version 7/8 inserted bytes are accounted for separately as described
above. Numerous records have the **same complete normalized header and
ordered RAM sample UID sequence**, including a nonzero group number.
Distinct matching signatures
include 68 for v2/v5, 27 for v5/v6, 37 for v5/v7, 281 for v5/v8 and 38 for
v7/v8. These are signature counts, not claims that every pair of similarly
named kits is identical.

For example, Pa4X v5 `Musi 46` and Pa5X v8 `Musi 46` have 115 same-key RAM
UID-sequence matches; all 115 normalized headers agree. Pa4X v5 `Musi 82`
and Pa5X v6 `Musi 03        2` have 111 such matches, all with equal normalized
headers. This corroborates the position across the versions where the
surrounding record changes.

The data also retains deliberate nonstandard assignments. Pa4X v5 `Musi 29`
stores group 29 for keys 78 and 80, linked to the actual recordings named
`Hh1 short` and `Hh1 long`. These values are copied as stored, not replaced by
a standard hi-hat group or a MIDI key heuristic.

### Original bank identities

The following SHA-256 hashes identify the binary evidence. Original PCG,
KMP, PCM and manual files are not redistributed inside the project ZIP.

| Original bank | Bytes | SHA-256 |
| --- | ---: | --- |
| Standalone `userdk01.pcg` | 230,831 | `ef834f58921b61724ffbf347f523ca1263b7a7f4ee577f2d48063ea11cdc4925` |
| Pa4X `SOUND/USERDK01.PCG` | 232,627 | `5ee86fcaf2ec233086e9acf939e090a550230a62cf2335d1debd174d88ea82c5` |
| Pa5X `SOUND/USERDK01.PCG` | 331,376 | `f3427eb8ae05c75a0d03b291cd75b3bfb989af40a252ac38a69eefceccfe8def` |
| Pa5X `SOUND/USERDK02.PCG` | 12,945 | `983fbafa01a7bb878413aebd04f9333483f276cd0b8de281a7569c1f6a60fce5` |
| Pa5X `SOUND/USERDK03.PCG` | 60,238 | `6190dd0155be7ad247a8839b922b9a86d405d1891128c1d98387a60544ebf3f5` |

The separate Pa3X archive contains unsupported Sound payloads with chunk type
ending in `0x78`, outside the supported `0x38`/OC31 path. Its bytes
were not used to infer any key field, and this change does not add decryption
or extend that container parser.

## Loading, edits and limits

Fresh Drum Kit Programs receive the table during sample-program construction.
On installation, older prepared bank graphs are upgraded from their already
retained original key records by making a shallow Program copy. Samples and
PCM caches remain shared. Original groups are captured before applying the
user's `.svdk` edit overlay, so the editor can restore the SET's assignments.

Legacy `.svdk` version 1 carries no group fields and therefore inherits the
source table. Version 2 has explicit assignments for all 128 keys, including
deliberate None values, and remains authoritative. The editor's `Use SET
groups` action restores only the group numbers and preserves the other drum
edits and controls.

Single Trigger bits, Subgroup Choke Off encoding and Korg's original Choke
Fade Out law remain uncalibrated and are not imported. Their SILVETON
defaults are retained: Single Trigger Off, Subgroup Choke Off disabled and
4 ms fade. The existing explicit SILVETON group behavior still governs voice
termination. This work does not claim an identical Korg DSP implementation.

The evidence work comprised read-only parsing and comparison of original
source bytes and official documentation. It did not execute unit,
functional, GUI, audio or hardware tests. Build/package validation is recorded
separately in the release documentation.

## References

- [Korg Pa1X User's Manual 2.52, official PDF](https://cdn.korg.com/us/support/download/files/28159965be25c6e0b0b646bba7eb5fa5.pdf), printed pp. 300–301.
- [Korg Pa800 User's Manual 2.01, official PDF](https://cdn.korg.com/us/support/download/files/1c1da327a641547b3863b6e06da095b9.pdf), printed pp. 302–304.
- Korg Pa5X User Manual v1.5, printed pp. 1122–1123, for the user-facing group controls and their separate roles.
- [KORG-Tools Drum Kit data structure](https://github.com/aczwink/KORG-Tools/blob/master/include/libkorg/Sound/DrumKit.hpp) and its versioned SoundFormat readers, for the legacy framing retained by this parser.
