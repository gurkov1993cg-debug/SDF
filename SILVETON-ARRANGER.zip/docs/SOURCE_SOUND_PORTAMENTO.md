# Original Sound voice assignment and Portamento

This change attaches original Portamento controls to their oscillator's native
`ProgramLayer`. It also imports the supported original common voice assignment.
It does not turn a Sound's distinct oscillator settings into one Upper time.
The numerical glide scale is SILVETON DSP, explicitly separate from the saved
Korg parameter index and from an unestablished Korg physical timing law.

## Version 0.1.96 playback update

The earlier automatic playback restriction below is relaxed only for the base
Enable/Fingered/Time behavior of revisions 6–8, with two retained extension
bytes and no flag bits outside 0x0b. This is an explicitly authored fallback
using the existing fixed-time SILVETON curve, not decoding bit 3, Rate/Time,
AMS or the extensions. Full encoding support remains separate. Revision 5
remains outside this fallback. Explicit performance CC5/CC65 overrides and
the per-layer source fields share the same time-index resolution in the engine
and editor. The original indices and extension bytes remain intact.


## Field evidence and executable scope

The official Korg TRITON MIDI implementation describes the retained legacy
oscillator block at bytes 266–355. Its bytes 274 and 275 correspond to normalized
Pa DSP90 offsets 8 and 9. The existing paired-program and cross-revision evidence
is documented in `PA5X_SOUND_DSP_LAYOUT.md`; the original Pa file layout remains
version aware.

| Original field | Meaning applied | Scope |
|---|---|---|
| DSP90 offset 8, bit 0 | Portamento Enable | Corroborated revisions 0–3 with flags 0–3 |
| DSP90 offset 8, bit 1 | Fingered; glide only if a previous key is held | Same scope |
| DSP90 offset 9 | Original Time index 0–127 | Same scope |
| Common voice byte, bit 2 | Mono rather than Poly | Revisions 0–3 and 5–8 |
| Common voice byte, bit 3 | Legacy Mono Legato | Revisions 0–3 only |
| Common body byte 431 | Separate Legato mode: 0 Off, 1 Legato, 2 Offset | Revision 8; Off/Legato playback supported, Offset preserved separately |
| Common voice byte, bits 4–5 | Legacy priority: 0 Low, 1 High, 2 Last | Revisions 0–3 only; code 3 is unsupported |

The common legacy bit positions also appear in the official TRITON Program
common byte 204. Mono has separate original Pa corroboration: `Warvick GA poly`
and `Warvick GA mono`, USER07 raw programs 6 and 7, have revision-8 bodies of
1056 bytes. Their only common-block difference is byte 2 changing from 0x28 to
0x2C. The other six differences are the three oscillators' Portamento flags and
times. Additional original Mono/Poly pairs agree with this common bit.

The official Pa5X User Manual v1.5, printed pages 1096–1097, describes common
Mono, Poly, Legato, Legato Offset and priority. Printed pages 1129–1130 describe
the oscillator Portamento Enable, Fingered, Rate/Time modes and Time AMS. These
pages explain behavior, but do not give the private Pa file bit positions or an
index-to-seconds conversion.

**No M50/Kronos Mode bit is transplanted into Pa files.** In the original Pa
corpus, Portamento flag values include 8, 9 and 11; bit 2 is never set. M50,
M3 and Krome document a different Mode bit. Pa's observed bit 3 is retained as
raw data and disables automatic source Portamento execution for that record.
Revisions 6–8 also carry two adjacent bytes; they are retained but their apparent
AMS role is not inferred by the runtime. Revision 5 is likewise kept outside
the executable legacy gate until its Portamento behavior is independently
established.

Revision 8 adds a separate two-byte common field before Pitch EG. Body byte
431 stores its Legato choice, while byte 432 is retained as an unassigned
extension. In all 212 original revision-8 Sounds, mode 1 exactly mirrors the
older Legato bit; modes 0 and 2 clear that bit. All six mode-2 Sounds are Mono.
The Pa5X's ordinary GUI resource independently declares the three choices as
Off, Legato and Legato Offset. The Pa4X 3.1 ordinary GUI repeats the same
declaration. This is Pa-specific corroboration, not another model's list order.
The importer enables modes 0 and 1 only when the retained extension is zero
and the compatibility bit agrees. Mode 2 is recognized and saved as Offset;
it is not played as ordinary Legato. The multisample-specific skip-attack
position needed for Offset is not yet established. In particular, the loop
start is not substituted for a missing No Attack offset.

## Playback ownership

`SourcePortamento` stores the original revision, flag byte, time index and up to
two adjacent bytes. `present` and `encodingSupported` are separate. A record can
therefore remain visible and survive save/load while its unsupported behavior
is not activated. `SourceVoiceAssignment` retains the original common byte
and the separate revision-8 Legato field when present.

Every selected oscillator keeps its own duration and Enable/Fingered state,
including High/Low velocity layers. The native engine initializes the glide
on the voice that owns that layer. A continued legacy Legato voice starts its
new transition from its current sounding pitch. When a new recording takes
over, its anchor is taken from the same oscillator's previous voice when one
exists. Polyphonic playback keeps the other notes alive; the existing bounded
rolled-chord grouping supplies an anchor without merging oscillator durations.

For an eligible original time index `t`, SILVETON uses:

`seconds = 5 × (t / 127)^2.2`

This is a fixed-duration glide in semitone space using the engine's existing
continuous transition machinery. Index 0 is immediate and index 127 is five
seconds. This is an authored playback design, not a claim to reproduce a Korg
Rate/Time mode or its measured transfer curve. No original byte is overwritten
by the converted duration.

Two explicit Upper policies separate source inheritance from performer edits:

- `sourcePortamentoInherit` allows the saved per-oscillator glide. A manual
  portamento edit, including Off, disables this inheritance. An active existing
  SILVETON/KRONOS/INSTRUMENT/BASS performance setting also takes precedence.
- `sourceVoiceInherit` lets the currently selected original Program supply its
  supported Mono/Poly/Legato policy. A manual voice-mode edit disables
  inheritance. This is evaluated from the currently selected Program, so a
  Style changing Sounds does not keep the preceding Sound's mode.

SOLO's explicit note priority keeps precedence. Source priority is common to
the base Sound; it is not selected from an arbitrary oscillator or extra Upper
layer. Native files without the new extension keep their authored voice mode.

## Persistence and compatibility

The optional `SVSP` block leaves the existing native SET and prepared Program
base graphs intact. It stores common voice records and per-Program/per-layer
Portamento records, including unsupported raw data. Native SETs additionally
store the two inheritance policies for all parts of each COMBI and the live
performance. The policies are applied after the older engine-slot extensions,
so those extensions cannot silently reset them. Duplicate references, out of
range owners, malformed flags and inconsistent record counts are rejected.

`SVSP` version 2 appends explicit Legato-field presence, mode and extension
bytes to each common voice record. The reader still accepts version 1;
revision-8 records loaded from that older trailer do not acquire an inferred
Legato field. The separate `SVOD` trailer preserves original oscillator DSP,
Pitch EG and output bytes through an explicitly encoded raw profile.

`SILVPROGRAM2` base graph storage and the independent PCM sample identities are
unchanged. The prepared-SET manifest revision forces original Sound metadata
to be rebuilt once; decoded PCM caching remains separate.

Older saved Style/session bindings require their original full Program
fingerprint. `projectPa5xSampleProgramLegacy69` reconstructs the exact 0.1.69
control projection only for bounded, provenance-bearing normal imports. The
importer retains the old SampleDecay eligibility and stages. The projection
restores the former neutral Mono/Legato/Portamento and ADSR values and computes
the old layer compensation in its original numerical order. It preserves
sample identities, source references, key/velocity zones and loop boundaries.
It returns an empty pointer when the required evidence is missing. Callers
must restrict this fallback to older saved formats and still require the
complete fingerprint to match; the projection is never used for playback.

## Static original-data coverage

The source archive contains 808 normal Sounds and 3978 oscillator records.
`SOURCE_SOUND_PORTAMENTO_COVERAGE.json` records the input digest, exact paired
differences and per-version counts.

| Finding | Original records |
|---|---:|
| Supported legacy Portamento encodings, including Off | 2011 oscillators |
| Supported saved Portamento Enable | 468 oscillators |
| Supported enabled Portamento with a nonzero Time | 460 oscillators in 118 Sounds |
| Sounds containing different oscillator Portamento settings | 192 |
| Saved Mono bit set | 433 Sounds |
| Supported legacy Mono Legato bit set | 98 Sounds |
| Additional revision-8 Mono Legato mode 1 | 106 Sounds |
| Revision-8 Legato modes 0/1 with supported encoding | 206 Sounds |
| Revision-8 Legato Offset mode 2, retained but not yet executed | 6 Sounds |
| Oscillators carrying unresolved Pa Portamento bit 3 | 1004 |

These are source-setting counts before RAM/ROM sample resolution and key or
velocity selection. They are not a count of fully reproduced instruments or
an audio-equivalence result. Active unknown controller/AMS behavior, new Pa
Portamento modes, Legato Offset, Hold and Single Trigger are not claimed by
this feature. The broader source Amp EG work has its own support gates.

For the 0.1.70 Amp EG baseline, including corroborated Filter Keyboard Tracking
AMS IDs 6–9, the separate static census reports **3855 of 3978 oscillators
eligible**, with 123 blocked. This includes 3043 eligible oscillators with
nonzero Sustain and 742 with active supported AMS. All oscillators are eligible
in 768 of 808 Sounds, and at least one is eligible in 801 Sounds. These final
Amp EG figures replace the intermediate 3748-oscillator count in the earlier
agent handoff. Subsequent oscillator work has its own current reports under
`VERIFY/source-completion`; the Portamento counts above remain unchanged.

The current common-field proof is recorded in
`VERIFY/source-completion/research/portamento/common_fields.json`. It also
records the 14-byte common Pitch EG layout: all 808 source Sounds pass the
numeric and packed-direction domains; all nine same-Sound cross-revision
comparisons match; and five comparisons against three independently framed
official TRITON factory Programs match all 14 bytes. The graph rebuilds these
derived fields from retained common bytes without changing its base archive.
AMS identities and physical transfer laws remain separate from field framing.

Validation for this work consists of static source inspection, bounded reads
of the original archive and compiler checks. No application, audio engine,
MIDI device, instrument or unit-test executable was run for this research.

## Source provenance

- Official Korg TRITON MIDI Implementation, download page
  `https://www.korg.com/us/support/download/manual/1/214/2736/`.
- Official ZIP SHA-256:
  `5b3158787722104ebef40f140265a52e587dc6fb78e47171ca492e0771fe69ee`.
- Extracted `TRITON_MIDIimp.TXT` SHA-256:
  `c236565b8676cb07d67876366c6453bee7b4986627e55d306f7c7e24daa41b38`.
- Supplied whole-SET archive SHA-256:
  `699764b5d6267b093c0af90429c3dc3d9148b32cf5762f496611b5f422970693`.

Only format facts and SILVETON implementation code are included. No vendor
executable or vendor DSP implementation is copied or executed.
