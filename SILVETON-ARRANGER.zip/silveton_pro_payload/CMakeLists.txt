cmake_minimum_required(VERSION 3.20)
project(SilvetonArranger VERSION 0.1.93 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(APPLE)
    enable_language(OBJCXX)
    set(CMAKE_OSX_ARCHITECTURES "x86_64" CACHE STRING "Intel iMac 2011" FORCE)
    set(CMAKE_OSX_DEPLOYMENT_TARGET "10.13" CACHE STRING "Minimum macOS (High Sierra)" FORCE)
endif()

option(IMAK_BUILD_TESTS "Build the tests" ON)
option(IMAK_WERROR "Treat compiler warnings as errors (used on the Linux test machine)" OFF)
option(IMAK_SANITIZERS "Build with ASan + UBSan (Linux test machine)" OFF)

# The tablet build (Android NDK, started by android/ with Gradle) makes only the program: no tests, no warnings as errors.
if(ANDROID)
    set(IMAK_BUILD_TESTS OFF CACHE BOOL "Build the tests" FORCE)
    set(IMAK_WERROR OFF CACHE BOOL "Treat compiler warnings as errors" FORCE)
    set(IMAK_SANITIZERS OFF CACHE BOOL "Build with ASan + UBSan" FORCE)
    set(CMAKE_POSITION_INDEPENDENT_CODE ON)   # every library goes into the one shared library of the program
endif()

set(SILVETON_WERROR ${IMAK_WERROR} CACHE BOOL "" FORCE)
set(SILVETON_LIVE_BUILD_TESTS ${IMAK_BUILD_TESTS} CACHE BOOL "" FORCE)
set(SILVETON_LIVE_ENABLE_SANITIZERS ${IMAK_SANITIZERS} CACHE BOOL "" FORCE)

if(IMAK_BUILD_TESTS)
    add_executable(silveton_source_identity_migration_tests host/tests/SourceIdentityMigrationTests.cpp)
    target_link_libraries(silveton_source_identity_migration_tests PRIVATE imak_host)
    target_compile_options(silveton_source_identity_migration_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_source_identity_migration_tests COMMAND silveton_source_identity_migration_tests)
    add_executable(silveton_pa_series_source_recall_tests host/tests/PaSeriesSourceRecallTests.cpp)
    target_link_libraries(silveton_pa_series_source_recall_tests PRIVATE imak_host)
    target_compile_options(silveton_pa_series_source_recall_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_pa_series_source_recall_tests COMMAND silveton_pa_series_source_recall_tests)
    add_executable(silveton_arranger_read_tests host/tests/ArrangerReadTests.cpp)
    target_link_libraries(silveton_arranger_read_tests PRIVATE imak_host)
    target_compile_options(silveton_arranger_read_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_arranger_read_tests COMMAND silveton_arranger_read_tests ${CMAKE_BINARY_DIR}/native-style-fixture.stg)
    set_tests_properties(silveton_arranger_read_tests PROPERTIES FIXTURES_REQUIRED native_stg_audio)
    add_executable(silveton_pa5x_pcm_preview_tests host/tests/Pa5xPcmPreviewTests.cpp)
    target_link_libraries(silveton_pa5x_pcm_preview_tests PRIVATE imak_host)
    target_compile_options(silveton_pa5x_pcm_preview_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_pa5x_pcm_preview_tests COMMAND silveton_pa5x_pcm_preview_tests)
    add_executable(silveton_korg_style_audio_tests host/tests/KorgStyleAudioTests.cpp)
    target_link_libraries(silveton_korg_style_audio_tests PRIVATE imak_host)
    target_compile_options(silveton_korg_style_audio_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_korg_style_audio_tests COMMAND silveton_korg_style_audio_tests ${CMAKE_BINARY_DIR}/native-style-fixture.stg)
    set_tests_properties(silveton_korg_style_audio_tests PROPERTIES FIXTURES_REQUIRED native_stg_audio)
    enable_testing()
endif()

find_package(Threads REQUIRED)

# ---- the sound core (the same code as in the tablet program)
add_subdirectory(core)

# ---- drawing layer + screens
add_subdirectory(ui)

# ---- host: bank/set/combi handling + the doors to CoreAudio / CoreMIDI
set(IMAK_HOST_SOURCES host/src/SamplerHost.cpp host/src/ArrangerHost.cpp)
if(ANDROID)
    # the tablet: the sound / MIDI / bank engine of the tablet program itself (Direct ALSA, raw MIDI, realtime threads)
    set(IMAK_HOST_SOURCES host/src/android/SamplerHostAndroid.cpp host/src/ArrangerHost.cpp)
elseif(APPLE)
    list(APPEND IMAK_HOST_SOURCES host/src/mac/CoreAudioOutput.cpp host/src/mac/CoreMidiInput.cpp host/src/mac/DefaultIoMac.cpp)
else()
    list(APPEND IMAK_HOST_SOURCES host/src/DefaultIoOther.cpp)
endif()
add_library(imak_host STATIC ${IMAK_HOST_SOURCES})
target_include_directories(imak_host PUBLIC host/include)
target_link_libraries(imak_host PUBLIC silveton_live_core Threads::Threads)
if(APPLE)
    target_link_libraries(imak_host PUBLIC "-framework CoreAudio" "-framework AudioToolbox" "-framework AudioUnit" "-framework CoreMIDI" "-framework Foundation")
endif()
if(ANDROID)
    target_link_libraries(imak_host PUBLIC log aaudio)
endif()
if(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
    target_compile_options(imak_host PRIVATE -Wall -Wextra -Wpedantic -Wshadow $<$<BOOL:${IMAK_WERROR}>:-Werror>)
    if(IMAK_SANITIZERS)
        target_compile_options(imak_host PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)
        target_link_options(imak_host PUBLIC -fsanitize=address,undefined)
    endif()
endif()

if(IMAK_BUILD_TESTS)
    add_executable(silveton_arranger_chord_setup_tests host/tests/ArrangerChordSetupTests.cpp)
    target_link_libraries(silveton_arranger_chord_setup_tests PRIVATE imak_host)
    target_compile_options(silveton_arranger_chord_setup_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_arranger_chord_setup_tests COMMAND silveton_arranger_chord_setup_tests)
    add_executable(silveton_arranger_damper_tests host/tests/ArrangerDamperTests.cpp)
    target_link_libraries(silveton_arranger_damper_tests PRIVATE imak_host)
    target_compile_options(silveton_arranger_damper_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_arranger_damper_tests COMMAND silveton_arranger_damper_tests)
    if(UNIX AND NOT APPLE)
        add_executable(silveton_arranger_host_tests host/tests/ArrangerHostTests.cpp)
        target_link_libraries(silveton_arranger_host_tests PRIVATE imak_host)
        target_compile_options(silveton_arranger_host_tests PRIVATE -UNDEBUG)
        add_test(NAME silveton_arranger_host_tests COMMAND silveton_arranger_host_tests)
    endif()
    add_executable(silveton_arranger_audio_tests host/tests/ArrangerAudioTests.cpp)
    target_link_libraries(silveton_arranger_audio_tests PRIVATE imak_host)
    target_compile_options(silveton_arranger_audio_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_arranger_audio_tests COMMAND silveton_arranger_audio_tests ${CMAKE_BINARY_DIR})
    add_executable(imak_upper_source_tests host/tests/UpperSourceTests.cpp)
    target_link_libraries(imak_upper_source_tests PRIVATE imak_host)
    target_compile_options(imak_upper_source_tests PRIVATE -UNDEBUG)
    add_test(NAME imak_upper_source_tests COMMAND imak_upper_source_tests)
    add_executable(imak_solo_model_host_tests host/tests/SoloModelHostTests.cpp)
    target_link_libraries(imak_solo_model_host_tests PRIVATE imak_host)
    target_compile_options(imak_solo_model_host_tests PRIVATE -UNDEBUG)
    add_test(NAME imak_solo_model_host_tests COMMAND imak_solo_model_host_tests)
    add_executable(imak_host_tests host/tests/HostTests.cpp)
    target_link_libraries(imak_host_tests PRIVATE imak_host)
    if(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
        target_compile_options(imak_host_tests PRIVATE -UNDEBUG -Wall -Wextra -Wpedantic -Wshadow $<$<BOOL:${IMAK_WERROR}>:-Werror>)
    endif()
    add_test(NAME imak_host_tests COMMAND imak_host_tests)
endif()

# ---- the program for the Mac (a normal .app)
if(APPLE)
    add_executable(SILVETON_ARRANGER MACOSX_BUNDLE app/mac/main.mm)
    target_link_libraries(SILVETON_ARRANGER PRIVATE
        imak_ui
        imak_host
        "-framework Cocoa"
        "-framework CoreGraphics"
        "-framework QuartzCore"
    )
    target_compile_options(SILVETON_ARRANGER PRIVATE -fobjc-arc -Werror=unguarded-availability-new)
    set_target_properties(SILVETON_ARRANGER PROPERTIES
        OUTPUT_NAME "SILVETON ARRANGER"
        MACOSX_BUNDLE_BUNDLE_NAME "SILVETON ARRANGER"
        MACOSX_BUNDLE_GUI_IDENTIFIER "com.silveton.arranger.mac"
        MACOSX_BUNDLE_SHORT_VERSION_STRING "${PROJECT_VERSION}"
        MACOSX_BUNDLE_BUNDLE_VERSION "5"
        MACOSX_BUNDLE_INFO_PLIST "${CMAKE_CURRENT_SOURCE_DIR}/app/mac/Info.plist.in"
    )
    # the fonts the screens draw their text with travel inside the app
    add_custom_command(TARGET SILVETON_ARRANGER POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E make_directory "$<TARGET_BUNDLE_CONTENT_DIR:SILVETON_ARRANGER>/Resources/fonts"
        COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_CURRENT_SOURCE_DIR}/resources/fonts" "$<TARGET_BUNDLE_CONTENT_DIR:SILVETON_ARRANGER>/Resources/fonts"
    )
endif()

# ---- the program for the tablet (Samsung Galaxy Tab A11): a NativeActivity, no Kotlin or Java
if(ANDROID)
    set(IMAK_GLUE_DIR "${ANDROID_NDK}/sources/android/native_app_glue")
    add_library(silveton_sampler SHARED
        app/android/AndroidApp.cpp
        app/android/AndroidRoot.cpp
        app/android/GlRenderer.cpp
        ${IMAK_GLUE_DIR}/android_native_app_glue.c
    )
    target_include_directories(silveton_sampler PRIVATE ${IMAK_GLUE_DIR} app/android)
    target_link_libraries(silveton_sampler PRIVATE imak_ui imak_host android log dl)
    # NativeActivity finds this function by name: the linker must keep it
    target_link_options(silveton_sampler PRIVATE -u ANativeActivity_onCreate)
    target_compile_options(silveton_sampler PRIVATE -Wall -Wextra -Wno-unused-parameter)
endif()

# ---- "imak_check": builds every registered native test and runs them all.
# The normal Android APK workflow keeps IMAK_BUILD_TESTS=OFF.
if(IMAK_BUILD_TESTS)
    set(IMAK_TEST_TARGETS
        silveton_korg_style_audio_tests
        silveton_korg_style_playback_tests
        silveton_arranger_chord_setup_tests
        silveton_arranger_damper_tests
        silveton_arranger_chord_ui_tests
        silveton_chord_recognition_tests
        silveton_arranger_tests
        silveton_arranger_audio_tests
        silveton_korg_style_index_tests
        silveton_pa5x_pcg_tests
        silveton_pa5x_sample_tests
        silveton_pa5x_kst_tests
        silveton_pa5x_performance_tests
        silveton_pa5x_sound_graph_tests
        imak_MenuWiringRegression_test
        imak_quick_controls_touch_test
        imak_set_import_test
        imak_upper_source_tests
        imak_set_browser_state_test
        imak_solo_model_host_tests
        silveton_solo_model_tests
        imak_host_tests
        silveton_solo_tuning_tests
        silveton_pitch_mapping_tests
        silveton_combi_independent_tests
        silveton_velocity_shape_tests
        silveton_solo_source_tests
        silveton_solo_bend_transitions_tests
        silveton_solo_compatibility_tests
        silveton_core_audio_fix_tests
        silveton_realtime_safety_tests
        silveton_portamento_regression_tests
        silveton_live_core_tests
        silveton_live_fuzz_tests
        silveton_sampler_tests
        silveton_fsx_tests
        imak_gfx_test
        imak_damage_test
        imak_list_persist_test
        imak_set_persistence_test
        imak_set_ui_integration_test
        imak_engine_control_regression_test
        imak_LiveWorkflow_test
        imak_ListWorkflowRegression_test
        imak_SoundWorkflow_test
        imak_ScaleWorkflow_test)
    if(TARGET silveton_arranger_host_tests)
        list(APPEND IMAK_TEST_TARGETS silveton_arranger_host_tests)
    endif()
    add_custom_target(imak_check
        COMMAND ${CMAKE_CTEST_COMMAND} -C $<CONFIG> --output-on-failure
        DEPENDS ${IMAK_TEST_TARGETS}
        COMMENT "Running all SILVETON ARRANGER tests"
    )
endif()
