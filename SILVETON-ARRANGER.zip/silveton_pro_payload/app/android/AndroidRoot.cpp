// SILVETON_ANDROID_ROOT_V1 - see AndroidRoot.h
#include "AndroidRoot.h"
#include "silveton/sampler/CpuWorkPolicy.h"
#include <android/log.h>

#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstring>
#include <thread>
#include <vector>

#include <fcntl.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "RootScripts.inc"

namespace silveton::android {
namespace {

std::string cpuMask(int firstCpu,int lastCpu) {
    if(firstCpu<0||lastCpu<firstCpu)return "1";
    constexpr char digits[]="0123456789abcdef";
    std::vector<unsigned> nibbles(static_cast<std::size_t>(lastCpu/4+1),0U);
    for(int cpu=firstCpu;cpu<=lastCpu;++cpu)
        nibbles[static_cast<std::size_t>(cpu/4)]|=1U<<static_cast<unsigned>(cpu%4);
    std::string mask;mask.reserve(nibbles.size());
    for(auto it=nibbles.rbegin();it!=nibbles.rend();++it)mask.push_back(digits[*it]);
    const auto nonzero=mask.find_first_not_of('0');
    return nonzero==std::string::npos?"1":mask.substr(nonzero);
}

// Fill process identity and the ARRANGER package in the inherited tablet scripts.
// The generated source still carries the original SAMPLER package literal.
std::string filled(const char* script) {
    std::string text(script);
    const std::string uid = std::to_string(static_cast<long long>(::getuid()));
    const std::string pid = std::to_string(static_cast<long long>(::getpid()));
    const std::string package = "com.silveton.arranger.panel";
    const auto policy=silveton::sampler::deviceCpuWorkPolicy();
    const std::string audioMask=cpuMask(policy.audioCpu,policy.audioCpu);
    const std::string backgroundMask=cpuMask(0,policy.backgroundLastCpu);
    const std::string midiMask=cpuMask(policy.midiFirstCpu,policy.midiLastCpu);
    const std::string streamMask=cpuMask(policy.streamFirstCpu,policy.streamLastCpu);
    std::string renderPromotions;
    const int helpers=policy.renderThreads-1;
    const std::string expectedRenderMask=std::to_string((1U<<helpers)-1U);
    for(int index=0;index<helpers;++index){
        const auto bit=std::to_string(1U<<index);
        renderPromotions+="SilvRender"+std::to_string(index)+") MASK="+
            cpuMask(policy.renderCpu(index),policy.renderCpu(index))+
            "; PRIO=79; RENDER_SEEN=$((RENDER_SEEN | "+bit+")) ;;\n";
    }
    const struct { const char* key; const std::string* value; } keys[] = {
        {"@UID@", &uid}, {"@PID@", &pid}, {"com.silveton.sampler", &package},
        {"@AUDIO_MASK@",&audioMask},{"@BACKGROUND_MASK@",&backgroundMask},
        {"@MIDI_MASK@",&midiMask},{"@STREAM_MASK@",&streamMask},{"@RENDER_PROMOTIONS@",&renderPromotions},
        {"@EXPECTED_RENDER_MASK@",&expectedRenderMask}
    };
    for (const auto& k : keys) {
        const std::string key = k.key;
        for (std::size_t at = text.find(key); at != std::string::npos; at = text.find(key, at + k.value->size())) {
            text.replace(at, key.size(), *k.value);
        }
    }
    return text;
}

std::string trimmedText(std::string s) {
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ' || s.back() == '\t')) s.pop_back();
    std::size_t begin = 0U;
    while (begin < s.size() && (s[begin] == '\n' || s[begin] == '\r' || s[begin] == ' ' || s[begin] == '\t')) ++begin;
    return s.substr(begin);
}

void setNonBlocking(int fd) {
    const int flags = ::fcntl(fd, F_GETFL, 0);
    if (flags >= 0) ::fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

} // namespace

// ---------------------------------------------------------------- su
// The tablet's runSu: start `su`, write the script into it, never read before the process ends or the time is up
// (a hanging command must not make the timeout useless), kill it when the time is up.
RootRuntime::Result RootRuntime::runSu(const std::string& script, int timeoutSeconds) {
    ::signal(SIGPIPE, SIG_IGN);
    int in[2] = {-1, -1};
    int out[2] = {-1, -1};
    int failed[2] = {-1, -1};   // the child reports a failed exec through this one (errno), it closes by itself when exec worked
    if (::pipe2(in, O_CLOEXEC) != 0 || ::pipe2(out, O_CLOEXEC) != 0 || ::pipe2(failed, O_CLOEXEC) != 0) {
        const std::string why = std::strerror(errno);
        for (int fd : {in[0], in[1], out[0], out[1], failed[0], failed[1]}) if (fd >= 0) ::close(fd);
        return {false, "Root unavailable: " + why};
    }
    const pid_t child = ::fork();
    if (child < 0) {
        const std::string why = std::strerror(errno);
        for (int fd : {in[0], in[1], out[0], out[1], failed[0], failed[1]}) ::close(fd);
        return {false, "Root unavailable: " + why};
    }
    if (child == 0) {
        // only calls that are safe between fork and exec
        ::dup2(in[0], 0);
        ::dup2(out[1], 1);
        ::dup2(out[1], 2);
        char* const argv[] = {const_cast<char*>("su"), nullptr};
        ::execvp("su", argv);
        const int err = errno;
        const ssize_t ignored = ::write(failed[1], &err, sizeof(err));
        (void)ignored;
        ::_exit(127);
    }
    ::close(in[0]);
    ::close(out[1]);
    ::close(failed[1]);

    // exec failed? ("Cannot run program su")
    int execError = 0;
    const ssize_t got = ::read(failed[0], &execError, sizeof(execError));
    ::close(failed[0]);
    if (got == static_cast<ssize_t>(sizeof(execError))) {
        ::close(in[1]);
        ::close(out[0]);
        int st = 0;
        ::waitpid(child, &st, 0);
        return {false, std::string("Root unavailable: Cannot run program \"su\": error=") + std::to_string(execError) + ", " + std::strerror(execError)};
    }

    // the script (a few kilobytes: it fits into the pipe at once)
    {
        const std::string text = script + "\n";
        std::size_t done = 0U;
        setNonBlocking(in[1]);
        const auto writeDeadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
        while (done < text.size() && std::chrono::steady_clock::now() < writeDeadline) {
            const ssize_t n = ::write(in[1], text.data() + done, text.size() - done);
            if (n > 0) { done += static_cast<std::size_t>(n); continue; }
            if (n < 0 && errno == EINTR) continue;
            if (n < 0 && errno == EAGAIN) { std::this_thread::sleep_for(std::chrono::milliseconds(5)); continue; }
            break;
        }
        ::close(in[1]);
    }

    setNonBlocking(out[0]);
    std::string output;
    bool eof = false;
    bool exited = false;
    int status = 0;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeoutSeconds);
    while (true) {
        if (!eof) {
            struct pollfd p;
            p.fd = out[0];
            p.events = POLLIN;
            p.revents = 0;
            const int ready = ::poll(&p, 1, 25);
            if (ready > 0) {
                char buffer[1024];
                for (;;) {
                    const ssize_t n = ::read(out[0], buffer, sizeof(buffer));
                    if (n > 0) { output.append(buffer, static_cast<std::size_t>(n)); continue; }
                    if (n == 0) eof = true;
                    break;
                }
            }
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        const pid_t w = ::waitpid(child, &status, WNOHANG);
        if (w == child) { exited = true; break; }
        if (std::chrono::steady_clock::now() >= deadline) break;
    }
    if (!exited) {
        ::kill(child, SIGKILL);
        for (int i = 0; i < 100; ++i) {   // up to one second for the end
            if (::waitpid(child, &status, WNOHANG) == child) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        ::close(out[0]);
        return {false, "Root setup timed out"};
    }
    // what is left in the pipe
    for (;;) {
        char buffer[1024];
        const ssize_t n = ::read(out[0], buffer, sizeof(buffer));
        if (n > 0) { output.append(buffer, static_cast<std::size_t>(n)); continue; }
        break;
    }
    ::close(out[0]);
    const int code = WIFEXITED(status) ? WEXITSTATUS(status) : (128 + (WIFSIGNALED(status) ? WTERMSIG(status) : 0));
    if (code == 0) return {};
    return {false, "Root setup failed (" + std::to_string(code) + "): " + trimmedText(output)};
}

// ---------------------------------------------------------------- the calls of SilvetonRootRuntime
RootRuntime::Result RootRuntime::enter() {
    std::lock_guard<std::mutex> guard(lock_);
    if (active_) return {};
    const Result r = runSu(filled(kScript_enter), 15);
    if (r.ok) active_ = true;
    return r;
}

RootRuntime::Result RootRuntime::promoteRealtimeThreads() { return runSu(filled(kScript_promoteRealtimeThreads), 5); }
RootRuntime::Result RootRuntime::refreshBankStorageAccess() { return runSu(filled(kScript_refreshBankStorageAccess), 5); }
RootRuntime::Result RootRuntime::refreshAudioPermissions() { return runSu(filled(kScript_refreshAudioPermissions), 8); }
RootRuntime::Result RootRuntime::refreshMidiPermissions() { return runSu(filled(kScript_refreshMidiPermissions), 5); }

RootRuntime::Result RootRuntime::leave() {
    std::lock_guard<std::mutex> guard(lock_);
    if (!active_) return {};
    const Result r = runSu(filled(kScript_leave), 10);
    if (r.ok) active_ = false;
    return r;
}

// ---------------------------------------------------------------- the controller's view of it
AndroidPlatform::AndroidPlatform() : shared_(std::make_shared<Shared>()) {}

AndroidPlatform::Result AndroidPlatform::enter() { return shared_->root.enter(); }
AndroidPlatform::Result AndroidPlatform::refreshAudioPermissions() { return shared_->root.refreshAudioPermissions(); }
AndroidPlatform::Result AndroidPlatform::refreshMidiPermissions() { return shared_->root.refreshMidiPermissions(); }
AndroidPlatform::Result AndroidPlatform::refreshBankStorageAccess() { return shared_->root.refreshBankStorageAccess(); }

// Wait for the host to name the audio and render threads. Recoveries supersede
// any earlier request. A slow root command never runs on the UI/audio thread.
void AndroidPlatform::audioStarted() {
    const auto shared=shared_;
    const auto generation=++shared->generation;
    std::thread([shared,generation] {
        for(int delay:{80,400,1200}){
            std::this_thread::sleep_for(std::chrono::milliseconds(delay));
            std::lock_guard<std::mutex> lock(shared->promotionMutex);
            if(shared->closed.load() || shared->generation.load()!=generation)return;
            const auto result=shared->root.promoteRealtimeThreads();
            {
                std::lock_guard<std::mutex> statusLock(shared->statusMutex);
                shared->schedulingStatus=result.ok?"Audio/render thread setup completed":result.message;
            }
            if(result.ok)return;
            __android_log_print(ANDROID_LOG_WARN,"SILVETON","%s",result.message.c_str());
        }
    }).detach();
}

std::string AndroidPlatform::audioSchedulingStatus() const {
    std::lock_guard<std::mutex> lock(shared_->statusMutex);
    return shared_->schedulingStatus;
}

void AndroidPlatform::leave() {
    shared_->closed.store(true);
    std::lock_guard<std::mutex> lock(shared_->promotionMutex);
    shared_->root.leave();
}

std::string AndroidPlatform::bankNotFoundMessage(const Result& storageAccess) const {
    const std::string detail = storageAccess.ok ? "all-files access granted" : storageAccess.message;
    return "SILVETON_BANK.sv is not readable (" + detail + "). Expected /storage/emulated/0/SILVETON_BANK.sv";
}

} // namespace silveton::android
