// SILVETON_ANDROID_APP_V1 - SILVETON ARRANGER on the tablet WITHOUT Kotlin or Java.
//
// A NativeActivity (android_native_app_glue) that does what MainActivity.kt + SilvetonSamplerView.kt did around the screens:
//   * the screens are the same C++ screens as on the Mac (ui/). Every picture they draw is written to a list of operations
//     (FrameRenderer::record). SILVETON_GPU_DRAW_V1: the list is drawn on the tablet's video card (GlRenderer, EGL + OpenGL ES 3),
//     retained menu textures with only changed regions repaired. The processor builds current drawing commands;
//     unchanged menu pixels are reused, and the completed retained image is copied to the Android surface;
//   * touch (one finger = the mouse, a second finger on a - / + pair = reset), volume keys = MASTER, Back = close the dialog;
//   * the sound, MIDI and bank engine is the tablet's own (Direct ALSA, raw MIDI, realtime threads), reached through the plain
//     C++ facade NativeSamplerEngine; the root set-up is AndroidRoot.cpp;
//   * Android's Toast and keyboard are replaced by a pill and an on-screen keyboard inside the picture.
//
// Threads: the main thread of the app (android_main) owns the screens and the drawing. "SilvetonAudioLifecycle" starts /
// resumes / pauses / closes the sound (root calls take seconds). "SilvetonHousekeeping" is the tablet's two 250 ms polls
// (audio recovery + MIDI status). Nothing else touches the screens except through the queue to the main thread.

#include <android/api-level.h>
#include <android/asset_manager.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <android/looper.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <android/window.h>
#include <android_native_app_glue.h>
#include <jni.h>
#include <pthread.h>
#include <sched.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "AndroidRoot.h"
#include "GlRenderer.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Support.h"
#include "silveton/sampler/CpuWorkPolicy.h"
#include "silveton/sampler/PerformanceDiagnostics.h"

namespace {

using silveton::ui::Canvas;
using silveton::ui::ControllerEnv;
using silveton::ui::FrameRenderer;
using silveton::ui::SamplerAppController;
using SilvetonSamplerView = silveton::ui::ArrangerView;

constexpr const char* kTag = "SILVETON";

void logInfo(const std::string& text) { __android_log_print(ANDROID_LOG_INFO, kTag, "%s", text.c_str()); }
void logError(const std::string& text) { __android_log_print(ANDROID_LOG_ERROR, kTag, "%s", text.c_str()); }

void nameThisThread(const char* name) { ::pthread_setname_np(::pthread_self(), name); }

void placeBackgroundThread() noexcept {
    const auto policy=silveton::sampler::deviceCpuWorkPolicy();
    cpu_set_t set;CPU_ZERO(&set);
    for(int cpu=0;cpu<=policy.backgroundLastCpu&&cpu<CPU_SETSIZE;++cpu)CPU_SET(static_cast<std::size_t>(cpu),&set);
    (void)::sched_setaffinity(0,sizeof(set),&set);
}

class EngineLifetimeLease {
public:
    EngineLifetimeLease() {
        auto& state = gate();
        std::unique_lock<std::mutex> lock(state.mutex);
        state.ready.wait(lock, [&state] { return !state.active; });
        state.active = true;
    }
    ~EngineLifetimeLease() {
        auto& state = gate();
        {
            std::lock_guard<std::mutex> lock(state.mutex);
            state.active = false;
        }
        state.ready.notify_one();
    }
    EngineLifetimeLease(const EngineLifetimeLease&) = delete;
    EngineLifetimeLease& operator=(const EngineLifetimeLease&) = delete;
private:
    struct Gate { std::mutex mutex; std::condition_variable ready; bool active{false}; };
    static Gate& gate() { static Gate state; return state; }
};

bool javaOkay(JNIEnv* env) {
    if (!env->ExceptionCheck()) return true;
    env->ExceptionClear();
    return false;
}

// android_main is the native-app-glue thread, not the Activity's Java thread.
// Never reuse activity->env here; attach this thread for each framework call.
bool withActivityJni(ANativeActivity* activity, const std::function<bool(JNIEnv*)>& use) {
    if (activity == nullptr || activity->vm == nullptr || activity->clazz == nullptr) return false;
    JNIEnv* env = nullptr;
    const jint status = activity->vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    bool attached = false;
    if (status == JNI_EDETACHED) {
        if (activity->vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return false;
        attached = true;
    } else if (status != JNI_OK) return false;
    bool result = false;
    if (env->PushLocalFrame(48) == JNI_OK) {
        result = use(env);
        if (!javaOkay(env)) result = false;
        env->PopLocalFrame(nullptr);
    } else {
        javaOkay(env);
    }
    if (attached) activity->vm->DetachCurrentThread();
    return result;
}

struct TabletAudioSelection { bool wired{false}; int speakerDeviceId{0}; };
bool tabletAudioSelection(ANativeActivity* activity,TabletAudioSelection& selected) {
    TabletAudioSelection next;
    const bool okay=withActivityJni(activity,[activity,&next](JNIEnv* env){
        const jclass activityType=env->GetObjectClass(activity->clazz);
        if(!javaOkay(env)||activityType==nullptr)return false;
        const auto service=env->GetMethodID(activityType,"getSystemService","(Ljava/lang/String;)Ljava/lang/Object;");
        if(!javaOkay(env)||service==nullptr)return false;
        const jstring name=env->NewStringUTF("audio");
        if(!javaOkay(env)||name==nullptr)return false;
        const jobject manager=env->CallObjectMethod(activity->clazz,service,name);
        if(!javaOkay(env)||manager==nullptr)return false;
        const jclass managerType=env->FindClass("android/media/AudioManager");
        if(!javaOkay(env)||managerType==nullptr)return false;
        const jclass deviceType=env->FindClass("android/media/AudioDeviceInfo");
        if(!javaOkay(env)||deviceType==nullptr)return false;
        const auto getDevices=env->GetMethodID(managerType,"getDevices","(I)[Landroid/media/AudioDeviceInfo;");
        if(!javaOkay(env)||getDevices==nullptr)return false;
        const auto getType=env->GetMethodID(deviceType,"getType","()I");
        if(!javaOkay(env)||getType==nullptr)return false;
        const auto getId=env->GetMethodID(deviceType,"getId","()I");
        if(!javaOkay(env)||getId==nullptr)return false;
        const auto devices=static_cast<jobjectArray>(env->CallObjectMethod(manager,getDevices,static_cast<jint>(2))); // GET_DEVICES_OUTPUTS
        if(!javaOkay(env)||devices==nullptr)return false;
        const auto count=env->GetArrayLength(devices);
        if(!javaOkay(env)||count<0||count>256)return false;
        for(jsize i=0;i<count;++i){
            const jobject device=env->GetObjectArrayElement(devices,i);
            if(!javaOkay(env)||device==nullptr)return false;
            const jint type=env->CallIntMethod(device,getType);
            if(!javaOkay(env))return false;
            const jint id=env->CallIntMethod(device,getId);
            if(!javaOkay(env))return false;
            if(type==3||type==4)next.wired=true; // TYPE_WIRED_HEADSET / TYPE_WIRED_HEADPHONES
            if(type==2&&id>0&&next.speakerDeviceId==0)next.speakerDeviceId=id; // TYPE_BUILTIN_SPEAKER
            env->DeleteLocalRef(device);
        }
        return true;
    });
    if(okay)selected=next;
    return okay;
}
void useMusicVolumeKeys(ANativeActivity* activity){
    (void)withActivityJni(activity,[activity](JNIEnv* env){
        const jclass type=env->GetObjectClass(activity->clazz);
        if(!javaOkay(env)||type==nullptr)return false;
        const auto method=env->GetMethodID(type,"setVolumeControlStream","(I)V");
        if(!javaOkay(env)||method==nullptr)return false;
        env->CallVoidMethod(activity->clazz,method,static_cast<jint>(3)); // STREAM_MUSIC
        return javaOkay(env);
    });
}

bool storageAccessGranted(ANativeActivity* activity) {
    return withActivityJni(activity, [activity](JNIEnv* env) {
        if (::android_get_device_api_level() >= 30) {
            const jclass type = env->FindClass("android/os/Environment");
            if (!javaOkay(env) || type == nullptr) return false;
            const jmethodID check = env->GetStaticMethodID(type, "isExternalStorageManager", "()Z");
            if (!javaOkay(env) || check == nullptr) return false;
            const jboolean granted = env->CallStaticBooleanMethod(type, check);
            return javaOkay(env) && granted == JNI_TRUE;
        }
        const jclass type = env->GetObjectClass(activity->clazz);
        if (!javaOkay(env) || type == nullptr) return false;
        const jmethodID check = env->GetMethodID(type, "checkSelfPermission", "(Ljava/lang/String;)I");
        if (!javaOkay(env) || check == nullptr) return false;
        const jstring permission = env->NewStringUTF("android.permission.READ_EXTERNAL_STORAGE");
        if (!javaOkay(env) || permission == nullptr) return false;
        const jint granted = env->CallIntMethod(activity->clazz, check, permission);
        return javaOkay(env) && granted == 0; // PackageManager.PERMISSION_GRANTED
    });
}

bool requestStorageAccess(ANativeActivity* activity) {
    return withActivityJni(activity, [activity](JNIEnv* env) {
        const jclass activityType = env->GetObjectClass(activity->clazz);
        if (!javaOkay(env) || activityType == nullptr) return false;
        if (::android_get_device_api_level() < 30) {
            const jclass stringType = env->FindClass("java/lang/String");
            if (!javaOkay(env) || stringType == nullptr) return false;
            const jstring permission = env->NewStringUTF("android.permission.READ_EXTERNAL_STORAGE");
            if (!javaOkay(env) || permission == nullptr) return false;
            const jobjectArray permissions = env->NewObjectArray(1, stringType, permission);
            if (!javaOkay(env) || permissions == nullptr) return false;
            const jmethodID request = env->GetMethodID(activityType, "requestPermissions", "([Ljava/lang/String;I)V");
            if (!javaOkay(env) || request == nullptr) return false;
            env->CallVoidMethod(activity->clazz, request, permissions, static_cast<jint>(7101));
            return javaOkay(env);
        }
        const jmethodID getPackage = env->GetMethodID(activityType, "getPackageName", "()Ljava/lang/String;");
        if (!javaOkay(env) || getPackage == nullptr) return false;
        const jobject package = env->CallObjectMethod(activity->clazz, getPackage);
        if (!javaOkay(env) || package == nullptr) return false;
        const jclass uriType = env->FindClass("android/net/Uri");
        if (!javaOkay(env) || uriType == nullptr) return false;
        const jmethodID fromParts = env->GetStaticMethodID(uriType, "fromParts", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;");
        if (!javaOkay(env) || fromParts == nullptr) return false;
        const jstring scheme = env->NewStringUTF("package");
        if (!javaOkay(env) || scheme == nullptr) return false;
        const jobject uri = env->CallStaticObjectMethod(uriType, fromParts, scheme, package, nullptr);
        if (!javaOkay(env) || uri == nullptr) return false;
        const jclass intentType = env->FindClass("android/content/Intent");
        if (!javaOkay(env) || intentType == nullptr) return false;
        const jmethodID makeIntent = env->GetMethodID(intentType, "<init>", "(Ljava/lang/String;Landroid/net/Uri;)V");
        if (!javaOkay(env) || makeIntent == nullptr) return false;
        const jmethodID start = env->GetMethodID(activityType, "startActivity", "(Landroid/content/Intent;)V");
        if (!javaOkay(env) || start == nullptr) return false;
        const auto open = [&](const char* action, jobject data) {
            const jstring name = env->NewStringUTF(action);
            if (!javaOkay(env) || name == nullptr) return false;
            const jobject intent = env->NewObject(intentType, makeIntent, name, data);
            if (!javaOkay(env) || intent == nullptr) return false;
            env->CallVoidMethod(activity->clazz, start, intent);
            return javaOkay(env);
        };
        // Some firmware omits the per-app settings activity. Keep a guarded
        // fallback rather than crashing or treating a missing activity as access.
        return open("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", uri) ||
            open("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION", nullptr) ||
            open("android.settings.APPLICATION_DETAILS_SETTINGS", uri);
    });
}

// ---------------------------------------------------------------- a thread that runs jobs one after the other
// (the tablet's single-thread executor "SilvetonAudioLifecycle"). It keeps itself alive until its last job is done, so the
// sound can be closed after the screens are gone.
class JobThread {
public:
    explicit JobThread(const char* name) : state_(std::make_shared<State>()) {
        const std::shared_ptr<State> state = state_;
        const std::string threadName = name;
        std::thread([state, threadName] {
            nameThisThread(threadName.c_str());
            for (;;) {
                std::function<void()> job;
                {
                    std::unique_lock<std::mutex> lock(state->mutex);
                    state->wake.wait(lock, [&] { return state->stop || !state->jobs.empty(); });
                    if (state->jobs.empty()) return;   // stop and nothing left
                    job = std::move(state->jobs.front());
                    state->jobs.pop_front();
                }
                job();
            }
        }).detach();
    }
    void post(std::function<void()> job) {
        {
            std::lock_guard<std::mutex> lock(state_->mutex);
            if (state_->stop) return;
            state_->jobs.push_back(std::move(job));
        }
        state_->wake.notify_one();
    }
    // Runs what is queued, then the thread ends. Does not wait.
    void finish() {
        {
            std::lock_guard<std::mutex> lock(state_->mutex);
            state_->stop = true;
        }
        state_->wake.notify_one();
    }

private:
    struct State {
        std::mutex mutex;
        std::condition_variable wake;
        std::deque<std::function<void()>> jobs;
        bool stop{false};
    };
    std::shared_ptr<State> state_;
};

// ---------------------------------------------------------------- what the sound / MIDI threads may reach
// They never touch the screens directly: they go through here. `view` is only set while the screens exist.
struct SharedState {
    std::mutex viewMutex;
    SilvetonSamplerView* view{nullptr};
    std::mutex queueMutex;
    std::deque<std::function<void()>> mainQueue;
    ALooper* looper{nullptr};
    bool closing{false};

    void postMain(std::function<void()> job) {
        std::lock_guard<std::mutex> lock(queueMutex);
        if (closing) return;
        mainQueue.push_back(std::move(job));
        if (looper != nullptr) ::ALooper_wake(looper);
    }
    void closeQueue() {
        std::lock_guard<std::mutex> lock(queueMutex);
        closing = true;
        mainQueue.clear();
    }
    void withView(const std::function<void(SilvetonSamplerView&)>& use) {
        std::lock_guard<std::mutex> lock(viewMutex);
        if (view != nullptr) use(*view);
    }
};

// ---------------------------------------------------------------- full screen (the tablet's hideSystemUi)
// The system bars are hidden and come back for a moment by a swipe from the edge. Made through JNI without any Java code of
// our own; every call may fail on some firmware, then the bars simply stay.
void hideSystemUi(ANativeActivity* activity) {
    if (activity == nullptr || activity->vm == nullptr) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (activity->vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (activity->vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    if (env != nullptr) {
        const auto clear = [&]() -> bool {
            if (env->ExceptionCheck()) { env->ExceptionClear(); return true; }
            return false;
        };
        jobject activityObject = activity->clazz;
        jclass activityClass = env->GetObjectClass(activityObject);
        jmethodID getWindow = activityClass != nullptr ? env->GetMethodID(activityClass, "getWindow", "()Landroid/view/Window;") : nullptr;
        jobject window = (getWindow != nullptr && !clear()) ? env->CallObjectMethod(activityObject, getWindow) : nullptr;
        clear();
        if (window != nullptr) {
            jclass windowClass = env->GetObjectClass(window);
            // Android 11 and newer: the insets controller (hide the bars, show them again by a swipe)
            if (::android_get_device_api_level() >= 30 && windowClass != nullptr) {
                jmethodID getController = env->GetMethodID(windowClass, "getInsetsController", "()Landroid/view/WindowInsetsController;");
                jobject controller = (getController != nullptr && !clear()) ? env->CallObjectMethod(window, getController) : nullptr;
                clear();
                jclass typeClass = env->FindClass("android/view/WindowInsets$Type");
                jmethodID systemBars = (typeClass != nullptr && !clear()) ? env->GetStaticMethodID(typeClass, "systemBars", "()I") : nullptr;
                clear();
                if (controller != nullptr && systemBars != nullptr) {
                    const jint bars = env->CallStaticIntMethod(typeClass, systemBars);
                    if (!clear()) {
                        jclass controllerClass = env->GetObjectClass(controller);
                        jmethodID hide = env->GetMethodID(controllerClass, "hide", "(I)V");
                        jmethodID behavior = env->GetMethodID(controllerClass, "setSystemBarsBehavior", "(I)V");
                        clear();
                        if (behavior != nullptr) { env->CallVoidMethod(controller, behavior, 2); clear(); }   // BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        if (hide != nullptr) { env->CallVoidMethod(controller, hide, bars); clear(); }
                        env->DeleteLocalRef(controllerClass);
                    }
                }
                if (controller != nullptr) env->DeleteLocalRef(controller);
                if (typeClass != nullptr) env->DeleteLocalRef(typeClass);
            }
            // every version: the old flags (stable layout, hide navigation + status bar, sticky immersive)
            jmethodID getDecor = windowClass != nullptr ? env->GetMethodID(windowClass, "getDecorView", "()Landroid/view/View;") : nullptr;
            jobject decor = (getDecor != nullptr && !clear()) ? env->CallObjectMethod(window, getDecor) : nullptr;
            clear();
            if (decor != nullptr) {
                jclass viewClass = env->GetObjectClass(decor);
                jmethodID setVisibility = env->GetMethodID(viewClass, "setSystemUiVisibility", "(I)V");
                clear();
                if (setVisibility != nullptr) {
                    env->CallVoidMethod(decor, setVisibility, static_cast<jint>(0x100 | 0x200 | 0x400 | 0x2 | 0x4 | 0x1000));
                    clear();
                }
                env->DeleteLocalRef(viewClass);
                env->DeleteLocalRef(decor);
            }
            if (windowClass != nullptr) env->DeleteLocalRef(windowClass);
            env->DeleteLocalRef(window);
        }
        if (activityClass != nullptr) env->DeleteLocalRef(activityClass);
    }
    if (attached) activity->vm->DetachCurrentThread();
}

// ---------------------------------------------------------------- the fonts travel inside the APK (assets/fonts)
// The text drawer reads ordinary files, so they are copied once into the app's own folder (again when a size differs).
std::string prepareFonts(ANativeActivity* activity) {
    const std::string directory = std::string(activity->internalDataPath != nullptr ? activity->internalDataPath : "/data/local/tmp") + "/fonts";
    ::mkdir(directory.c_str(), 0700);
    AAssetManager* assets = activity->assetManager;
    AAssetDir* dir = assets != nullptr ? ::AAssetManager_openDir(assets, "fonts") : nullptr;
    if (dir == nullptr) return directory;
    while (const char* name = ::AAssetDir_getNextFileName(dir)) {
        const std::string fileName = name;
        AAsset* asset = ::AAssetManager_open(assets, ("fonts/" + fileName).c_str(), AASSET_MODE_STREAMING);
        if (asset == nullptr) continue;
        const std::string target = directory + "/" + fileName;
        const off64_t size = ::AAsset_getLength64(asset);
        struct stat st {};
        const bool same = ::stat(target.c_str(), &st) == 0 && static_cast<off64_t>(st.st_size) == size;
        if (!same) {
            const std::string temporary = target + ".tmp";
            std::FILE* out = std::fopen(temporary.c_str(), "wb");
            bool ok = out != nullptr;
            char buffer[16384];
            for (;;) {
                const int n = ::AAsset_read(asset, buffer, sizeof(buffer));
                if (n <= 0) break;
                if (ok && std::fwrite(buffer, 1U, static_cast<std::size_t>(n), out) != static_cast<std::size_t>(n)) ok = false;
            }
            if (out != nullptr) std::fclose(out);
            if (ok) std::rename(temporary.c_str(), target.c_str());
            else std::remove(temporary.c_str());
        }
        ::AAsset_close(asset);
    }
    ::AAssetDir_close(dir);
    return directory;
}

// ---------------------------------------------------------------- the program
class SilvetonApp {
public:
    explicit SilvetonApp(android_app* app) : app_(app), shared_(std::make_shared<SharedState>()) {}

    void run() {
        nameThisThread("SilvetonMain");
        // New UI/loading/housekeeping threads inherit this background mask.
        // Audio and the shared DSP workers explicitly select their own cores.
        placeBackgroundThread();
        shared_->looper = app_->looper;   // the glue prepared it for this thread
        ::ANativeActivity_setWindowFlags(app_->activity, AWINDOW_FLAG_KEEP_SCREEN_ON | AWINDOW_FLAG_FULLSCREEN, 0);

        silveton::ui::setFontDirectory(prepareFonts(app_->activity));
        if (!silveton::ui::fontsReady()) logError("the font files were not found: the text cannot be drawn");

        create();
        app_->userData = this;
        app_->onAppCmd = &SilvetonApp::onCommand;
        app_->onInputEvent = &SilvetonApp::onInput;

        loop();
        destroy();
    }

private:
    // ------------------------------------------------------------ set-up and tear-down
    void create() {
        // An earlier Activity can still be closing on its lifecycle worker.
        // Its controller must finish before this controller initializes the
        // single process-wide sampler and replaces its native state.
        engineLifetime_ = std::make_shared<EngineLifetimeLease>();
        const char* internal = app_->activity->internalDataPath != nullptr ? app_->activity->internalDataPath : "/data/local/tmp";
        const char* external = app_->activity->externalDataPath;

        platform_ = std::make_shared<silveton::android::AndroidPlatform>();
        ControllerEnv env;
        env.dataDir = internal;
        env.bankCandidates = {"/storage/emulated/0/SILVETON_BANK.sv", "/storage/emulated/0/Download/SILVETON_BANK.sv"};
        if (external != nullptr) env.bankCandidates.push_back(std::string(external) + "/SILVETON_BANK.sv");
        env.bankCandidates.push_back(std::string(internal) + "/SILVETON_BANK.sv");
        env.olderStateCopies = {"/storage/emulated/0/SILVETON_BLENDS.SVSET", "/storage/emulated/0/Download/SILVETON_BLENDS.SVSET", "/storage/emulated/0/SILVETON/SILVETON_USER_STATE.SVSET", "/storage/emulated/0/SILVETON/SILVETON_USER_STATE.SVSET.BAK"};
        env.platform = platform_;
        const std::shared_ptr<SharedState> shared = shared_;
        env.statusChanged = [shared](const std::string& message) {
            if (!message.empty()) logInfo("status: " + message);
            shared->withView([&](SilvetonSamplerView& v) { v.setWarning(message); });   // thread safe
        };
        env.midiConnectionChanged = [shared](int count) {
            shared->postMain([shared, count] { shared->withView([count](SilvetonSamplerView& v) { v.setMidiConnections(count); }); });
        };
        env.chooseSoloModel = [shared](int upper, int sound) {
            shared->postMain([shared, upper, sound] {
                shared->withView([upper, sound](SilvetonSamplerView& v) {
                    if (v.editorActive()) v.chooseSoloModelFile(upper, sound, "/storage/emulated/0/Download");
                });
            });
        };
        controller_ = std::make_shared<SamplerAppController>(env);
        useMusicVolumeKeys(app_->activity);
        updateAudioSelection();

        view_ = std::make_unique<SilvetonSamplerView>(*controller_);
        view_->setKstStatePath(std::string(internal) + "/ARRANGER_KST.txt");
        view_->setStorageAccessRequest([this] {
            if (storageAccessGranted(app_->activity)) return true;
            // A denied automatic restore must not reopen Settings on every
            // Resume/Focus event. Keep the saved session for a later retry.
            if (storageAccessPrompted_) return false;
            storageAccessPrompted_ = true;
            const bool opened = requestStorageAccess(app_->activity);
            view_->showToast(opened
                ? "Allow file access in Android, then return to SILVETON ARRANGER"
                : "Enable file access in Android Settings > Apps > SILVETON ARRANGER", 7000);
            return false;
        });
        view_->setSoftKeyboard(true);   // no keyboard of Android: the text and number pages bring their own
        {
            std::lock_guard<std::mutex> lock(shared_->viewMutex);
            shared_->view = view_.get();
        }

        lifecycle_ = std::make_unique<JobThread>("SilvetonAudioLifecycle");
        housekeepingStop_ = false;
        housekeeping_ = std::thread([this] { housekeepingLoop(); });
        view_->resumePersistentState();
    }

    void destroy() {
        cancelTouch();
        if (view_) view_->flushPersistentState();
        shared_->closeQueue();
        {
            std::lock_guard<std::mutex> lock(housekeepingMutex_);
            housekeepingStop_ = true;
        }
        housekeepingWake_.notify_all();
        if (housekeeping_.joinable()) housekeeping_.join();
        {
            std::lock_guard<std::mutex> lock(shared_->viewMutex);
            shared_->view = nullptr;
        }
        view_.reset();
        gpu_.reset();
        renderer_.reset();
        // The sound is closed on its own thread: the root call that gives the cores back may take a few seconds and must not hold
        // up the end of the activity. The thread keeps the controller alive until it is done.
        lifecycle_->post([controller = std::move(controller_), platform = std::move(platform_),
                          lifetime = std::move(engineLifetime_)]() mutable {
            controller->close();
            // Destroy the old controller before releasing the lifetime gate:
            // its destructor may call close() again. Relying on lambda capture
            // destruction order could otherwise close a newly created engine.
            controller.reset();
            platform.reset();
            lifetime.reset();
        });
        lifecycle_->finish();
        lifecycle_.reset();
        controller_.reset();
        platform_.reset();
    }

    // The tablet's two 250 ms polls (SamplerRuntime.recoveryPoll and SamplerMidiController.statusPoll).
    void housekeepingLoop() {
        nameThisThread("SilvetonHousekeeping");
        std::unique_lock<std::mutex> lock(housekeepingMutex_);
        while (!housekeepingStop_) {
            housekeepingWake_.wait_for(lock, std::chrono::milliseconds(250), [this] { return housekeepingStop_; });
            if (housekeepingStop_) break;
            lock.unlock();
            updateAudioSelection();
            controller_->housekeeping();
            lock.lock();
        }
    }

    void updateAudioSelection(){
        TabletAudioSelection selected;
        if(!tabletAudioSelection(app_->activity,selected))return;
        wiredOutput_.store(selected.wired,std::memory_order_release);
        controller_->engine.nativeSetOutputSelection(selected.wired,selected.speakerDeviceId);
    }

    // ------------------------------------------------------------ Android life cycle (MainActivity.onStart / onResume / onPause)
    static void onCommand(android_app* app, int32_t command) { static_cast<SilvetonApp*>(app->userData)->handleCommand(command); }
    static int32_t onInput(android_app* app, AInputEvent* event) { return static_cast<SilvetonApp*>(app->userData)->handleInput(event); }

    void handleCommand(int32_t command) {
        switch (command) {
            case APP_CMD_INIT_WINDOW:
                if (app_->window != nullptr) {
                    windowReady_ = true;
                    startGpu();
                    useWindowSize();
                    hideSystemUi(app_->activity);
                }
                break;
            case APP_CMD_TERM_WINDOW:
                cancelTouch();
                gpu_.reset();   // (the video card's surface must go before the window does)
                windowReady_ = false;
                break;
            case APP_CMD_WINDOW_RESIZED:
            case APP_CMD_CONTENT_RECT_CHANGED:
            case APP_CMD_CONFIG_CHANGED:
                if (windowReady_) useWindowSize();
                break;
            case APP_CMD_GAINED_FOCUS:
                hideSystemUi(app_->activity);
                if (view_) view_->resumePersistentState();
                if (view_) view_->invalidateDisplay();
                if (renderer_) renderer_->invalidate();
                break;
            case APP_CMD_LOST_FOCUS:
                cancelTouch();
                break;
            case APP_CMD_START: {
                visible_ = true;
                const std::shared_ptr<SamplerAppController> controller = controller_;
                lifecycle_->post([controller] { controller->start(); });
                break;
            }
            case APP_CMD_RESUME: {
                visible_ = true;
                hideSystemUi(app_->activity);
                if (view_) view_->resumePersistentState();
                if (view_) view_->invalidateDisplay();
                const std::shared_ptr<SamplerAppController> controller = controller_;
                lifecycle_->post([controller] { controller->resumeAudio(); });
                if (renderer_) renderer_->invalidate();
                break;
            }
            case APP_CMD_PAUSE: {
                cancelTouch();
                if (view_) view_->flushPersistentState();
                const std::shared_ptr<SamplerAppController> controller = controller_;
                lifecycle_->post([controller] { controller->pauseAudio(); });
                break;
            }
            case APP_CMD_STOP:
                if (view_) view_->flushPersistentState();
                visible_ = false;
                break;
            case APP_CMD_SAVE_STATE:
                if (view_) view_->flushPersistentState();
                break;
            default:
                break;
        }
    }

    // SILVETON_GPU_DRAW_V1: the size of what is drawn into (the video card's surface, or the window for the software renderer).
    bool drawingSize(int& w, int& h) {
        if (app_->window == nullptr) return false;
        if (gpu_) return gpu_->querySize(w, h) && w > 0 && h > 0;
        w = ::ANativeWindow_getWidth(app_->window);
        h = ::ANativeWindow_getHeight(app_->window);
        return w > 0 && h > 0;
    }

    // The picture has the size of the window (the screens scale the 1340 x 800 design to it and keep its shape).
    void useWindowSize() {
        int w = 0, h = 0;
        if (!drawingSize(w, h)) return;
        if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
            renderer_ = std::make_unique<FrameRenderer>(w, h);
            logInfo("picture " + std::to_string(w) + " x " + std::to_string(h));
        } else {
            renderer_->invalidate();
        }
        if (view_) view_->invalidateDisplay();
    }

    // The video card's drawing (see GlRenderer.h). If it cannot be made, it is tried again a little later (see frame()).
    void startGpu() {
        gpu_.reset();
        if (app_->window == nullptr) return;
        silveton::gl::GlRenderer::Options options;
        options.nativeWindow = app_->window;
        ANativeWindow* window = app_->window;
        options.onNativeVisual = [window](int visual) { ::ANativeWindow_setBuffersGeometry(window, 0, 0, visual); };
        std::string error;
        gpu_ = silveton::gl::GlRenderer::create(options, error);
        if (gpu_) logInfo("graphics: video card - " + gpu_->info());
        else logError("graphics: the video card could not be started - " + error);
        if (renderer_) renderer_->invalidate();
        if (view_) view_->invalidateDisplay();
    }

    // ------------------------------------------------------------ touch and keys
    void cancelTouch() {
        if (primaryPointer_ >= 0 && view_)
            view_->pointer(SilvetonSamplerView::PointerAction::Cancel, 0.0F, 0.0F);
        primaryPointer_ = -1;
    }

    int32_t handleInput(AInputEvent* event) {
        if (!view_) return 0;
        const int32_t type = ::AInputEvent_getType(event);
        if (type == AINPUT_EVENT_TYPE_MOTION) return handleMotion(event);
        if (type == AINPUT_EVENT_TYPE_KEY) return handleKey(event);
        return 0;
    }

    void movePrimaryPointer(AInputEvent* event,bool history) {
        if(primaryPointer_<0)return;
        const size_t count=::AMotionEvent_getPointerCount(event);
        for(size_t pointer=0U;pointer<count;++pointer){
            if(::AMotionEvent_getPointerId(event,pointer)!=primaryPointer_)continue;
            // Android batches touch samples. Keep their chronological path:
            // using only the latest angle loses fast wheel turns/reversals.
            if(history){
                const size_t samples=::AMotionEvent_getHistorySize(event);
                for(size_t sample=0U;sample<samples;++sample)
                    view_->pointer(SilvetonSamplerView::PointerAction::Move,
                        ::AMotionEvent_getHistoricalX(event,pointer,sample),
                        ::AMotionEvent_getHistoricalY(event,pointer,sample),
                        ::AMotionEvent_getHistoricalEventTime(event,sample)/1000000);
            }
            view_->pointer(SilvetonSamplerView::PointerAction::Move,
                ::AMotionEvent_getX(event,pointer),::AMotionEvent_getY(event,pointer),
                ::AMotionEvent_getEventTime(event)/1000000);
            return;
        }
    }

    // MainActivity's touch: the first finger is the mouse; a second finger on the partner of a - / + pair resets it
    // (SilvetonSamplerView.handleTouch); moves follow the first finger only.
    int32_t handleMotion(AInputEvent* event) {
        if ((::AInputEvent_getSource(event) & AINPUT_SOURCE_CLASS_POINTER) == 0) return 0;
        const int32_t action = ::AMotionEvent_getAction(event);
        const int32_t masked = action & AMOTION_EVENT_ACTION_MASK;
        const int32_t index = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        const size_t pointerCount = ::AMotionEvent_getPointerCount(event);
        if (pointerCount == 0 || index < 0 || static_cast<size_t>(index) >= pointerCount) {
            cancelTouch();
            return 1;
        }
        switch (masked) {
            case AMOTION_EVENT_ACTION_DOWN:
                cancelTouch();
                primaryPointer_ = ::AMotionEvent_getPointerId(event, 0);
                view_->pointer(SilvetonSamplerView::PointerAction::Down, ::AMotionEvent_getX(event, 0), ::AMotionEvent_getY(event, 0),
                    ::AMotionEvent_getEventTime(event)/1000000);
                return 1;
            case AMOTION_EVENT_ACTION_POINTER_DOWN:
                if (view_->editorActive())
                    view_->secondPointerDown(::AMotionEvent_getX(event, static_cast<size_t>(index)), ::AMotionEvent_getY(event, static_cast<size_t>(index)));
                return 1;
            case AMOTION_EVENT_ACTION_POINTER_UP:
                if (::AMotionEvent_getPointerId(event, static_cast<size_t>(index)) == primaryPointer_){
                    movePrimaryPointer(event,false);
                    cancelTouch(); // Never turn the remaining finger into an unintended click.
                }
                return 1;
            case AMOTION_EVENT_ACTION_MOVE:
                movePrimaryPointer(event,true);
                return 1;
            case AMOTION_EVENT_ACTION_UP:
                if (primaryPointer_ < 0) return 1;
                // The lift can contain a final movement not delivered as MOVE.
                movePrimaryPointer(event,false);
                primaryPointer_ = -1;
                view_->pointer(SilvetonSamplerView::PointerAction::Up,
                    ::AMotionEvent_getX(event,static_cast<size_t>(index)),
                    ::AMotionEvent_getY(event,static_cast<size_t>(index)),
                    ::AMotionEvent_getEventTime(event)/1000000);
                return 1;
            case AMOTION_EVENT_ACTION_CANCEL:
                cancelTouch();
                return 1;
            default:
                return 1;   // pointer up of one of two fingers, hover ...: nothing to do
        }
    }

    // Speakers follow Android media volume. The direct wired route retains
    // the existing SILVETON MASTER keys, without opening a system click stream.
    int32_t handleKey(AInputEvent* event) {
        const int32_t code = ::AKeyEvent_getKeyCode(event);
        const bool down = ::AKeyEvent_getAction(event) == AKEY_EVENT_ACTION_DOWN;
        if(!wiredOutput_.load(std::memory_order_acquire)&&
           (code==AKEYCODE_VOLUME_UP||code==AKEYCODE_VOLUME_DOWN||code==AKEYCODE_VOLUME_MUTE))return 0;
        float step = 0.0F;
        switch (code) {
            case AKEYCODE_VOLUME_UP: step = 2.0F; break;
            case AKEYCODE_VOLUME_DOWN: step = -2.0F; break;
            case AKEYCODE_VOLUME_MUTE: break;
            case AKEYCODE_BACK:
                // the tablet's dialogs closed with Back; without a dialog Back leaves the program as on any Android app
                if (view_->dialogOpen()) {
                    if (down) view_->keyDown(SilvetonSamplerView::Key::Escape);
                    return 1;
                }
                return 0;
            default:
                return 0;
        }
        if (down && step != 0.0F) {
            const std::optional<float> db = controller_->nudgeMasterGain(step);
            if (db) {
                view_->globalChangedOutside();
                char text[48];
                std::snprintf(text, sizeof(text), "MASTER %s%.0f dB", *db > 0.0F ? "+" : "", static_cast<double>(*db));
                view_->showToast(text);
            }
        }
        return 1;
    }

    // ------------------------------------------------------------ the loop
    void loop() {
        for (;;) {
            const std::int64_t now = silveton::ui::nowMs();
            int timeout = timeoutMs(now);
            for (;;) {
                int events = 0;
                android_poll_source* source = nullptr;
                const int ident = ::ALooper_pollOnce(timeout, nullptr, &events, reinterpret_cast<void**>(&source));
                if (ident >= 0) {
                    if (source != nullptr) source->process(app_, source);
                    timeout = 0;   // more may be waiting
                    if (app_->destroyRequested != 0) return;
                    continue;
                }
                if (ident == ALOOPER_POLL_WAKE) { timeout = 0; continue; }
                break;   // time is up
            }
            if (app_->destroyRequested != 0) return;
            runQueue();
            frame();
        }
    }

    std::int64_t visualFrameIntervalMs() const {
        // Input/MIDI are not throttled by this limit. Gestures retain prompt
        // visual feedback; otherwise use less drawing work during performance.
        return controller_ && controller_->audioRunning() &&
            !(view_&&view_->interactiveFeedbackActive(silveton::ui::nowMs())) ? 33 : 12;
    }

    int timeoutMs(std::int64_t now) const {
        if (!windowReady_ || !visible_ || !view_ || !renderer_) return -1;   // nothing to draw: sleep until something happens
        const auto work = view_->nextWorkMs();
        // nextWorkMs() returns zero for a dirty picture. Keep that case on the
        // old bounded control-tick cadence instead of spinning while a visual
        // frame is capped. A future control deadline is independent of redraw.
        std::int64_t due = work > now ? work : lastViewTickMs_ + 12;
        if (view_->redrawDue(now)) {
            auto visualDue = lastFrameMs_ + visualFrameIntervalMs();
            // Retry a lost GL context only at its own deadline; keep control
            // ticks alive while the graphics retry is deliberately delayed.
            if (!gpu_ && nextGpuTryMs_ > now) visualDue = std::max(visualDue, nextGpuTryMs_);
            due = std::min(due, visualDue);
        }
        {
            std::lock_guard<std::mutex> lock(shared_->queueMutex);
            if (!shared_->mainQueue.empty()) due = now;
        }
        const std::int64_t wait = due - now;
        return wait <= 0 ? 0 : static_cast<int>(std::min<std::int64_t>(wait, 1000));
    }

    void runQueue() {
        for (;;) {
            std::function<void()> job;
            {
                std::lock_guard<std::mutex> lock(shared_->queueMutex);
                if (shared_->mainQueue.empty()) return;
                job = std::move(shared_->mainQueue.front());
                shared_->mainQueue.pop_front();
            }
            job();
        }
    }

    void frame() {
        if (!windowReady_ || !visible_ || !view_) return;
        const std::int64_t now = silveton::ui::nowMs();
        const auto tickStart = std::chrono::steady_clock::now();
        view_->tick(now);
        const auto tickEnd = std::chrono::steady_clock::now();
        const double tickUs = std::chrono::duration<double, std::micro>(tickEnd - tickStart).count();
        // Include tick-only polls: metadata work can be expensive without
        // making the visible picture dirty, and must not inflate frame FPS.
        silveton::sampler::diagnostics::recordUiTick(tickUs);
        lastViewTickMs_ = silveton::ui::nowMs();
        if (now < lastFrameMs_ + visualFrameIntervalMs() || !view_->redrawDue(now)) return;
        if (!gpu_) {
            if (now < nextGpuTryMs_) return;
            nextGpuTryMs_ = now + 2000;
            startGpu();
            if (!gpu_) return;
        }
        int w = 0, h = 0;
        if (!drawingSize(w, h)) return;
        if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
            useWindowSize();
            if (!renderer_) return;
        }
        lastFrameMs_ = silveton::ui::nowMs();
        // Rebuild the current values and touch zones when the view invalidates, compare with this
        // menu's cached signature, and repair only changed regions of its retained GPU picture.
        const auto recordStart = std::chrono::steady_clock::now();
        const bool changed = renderer_->record([this](Canvas& canvas) { view_->draw(canvas); }, view_->renderCacheKey());
        const auto recordEnd = std::chrono::steady_clock::now();
        const auto renderStart = std::chrono::steady_clock::now();
        const bool rendered = !changed || gpu_->renderRetained(renderer_->lastList(),
            renderer_->recordedSceneKey(), renderer_->recordedSceneBaseKey(), renderer_->recordedSceneBaseRevision(),
            renderer_->recordedSceneRevision(), renderer_->changed(), true);
        const auto renderEnd = std::chrono::steady_clock::now();
        const auto microseconds = [](const auto& start, const auto& end) noexcept {
            return std::chrono::duration<double, std::micro>(end - start).count();
        };
        // renderWallUs includes driver submission and eglSwapBuffers' VSync
        // wait. It is a wall-clock observation, not GPU utilization or GPU time.
        silveton::sampler::diagnostics::recordUiFrame(tickUs,
            microseconds(recordStart, recordEnd), changed ? microseconds(renderStart, renderEnd) : 0.0,
            silveton::ui::nowMs(), static_cast<std::uint64_t>(renderer_->lastOperationCount()));
        if (!rendered) {
            logError("graphics: drawing on the video card failed - " + gpu_->lastError());
            gpu_.reset();   // made again on the next picture
            nextGpuTryMs_ = 0;
            if (renderer_) renderer_->invalidate();
            view_->invalidateDisplay();
        }
    }

    android_app* app_;
    std::shared_ptr<SharedState> shared_;
    std::shared_ptr<silveton::android::AndroidPlatform> platform_;
    std::shared_ptr<SamplerAppController> controller_;
    std::shared_ptr<EngineLifetimeLease> engineLifetime_;
    std::unique_ptr<SilvetonSamplerView> view_;
    std::unique_ptr<FrameRenderer> renderer_;
    std::unique_ptr<silveton::gl::GlRenderer> gpu_;   // the video card's drawing
    std::int64_t nextGpuTryMs_{0};
    std::unique_ptr<JobThread> lifecycle_;
    std::thread housekeeping_;
    std::mutex housekeepingMutex_;
    std::condition_variable housekeepingWake_;
    bool housekeepingStop_{false};
    std::atomic<bool> wiredOutput_{false};
    bool windowReady_{false};
    bool visible_{false};
    bool storageAccessPrompted_{false};
    std::int32_t primaryPointer_{-1};
    std::int64_t lastFrameMs_{0};
    std::int64_t lastViewTickMs_{0};
};

} // namespace

// The entry point of android_native_app_glue.
extern "C" void android_main(android_app* app) {
    SilvetonApp program(app);
    program.run();
}
