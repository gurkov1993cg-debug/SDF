#pragma once
#include "silveton/host/ArrangerDrumEdit.h"
#include "silveton/host/ArrangerEnvelope.h"
#include "silveton/arranger/GuitarMode.h"

#include "silveton/sampler/SamplerTypes.h"
#include <array>
#include <bitset>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace silveton::sampler { struct MeterSnapshot; struct VoiceActivity; class SamplerEngine; }
namespace silveton::arranger { struct PlayerSnapshot; class Pa5xSetBank; struct Pa5xStyleRead; struct Pa5xKeyboardSetRead; }

namespace silveton::host {

// Control-thread descriptions. Their strings never cross into the audio callback.
struct StyleRangeView {
    bool available{},enabled{},edited{},wrapEdited{};
    int low{},high{127},wrap{};
};
enum class RangeField { Enable, Low, High, Wrap, ResetRange, ResetWrap };
struct StyleGuitarView {
    bool available{},sourceGuitar{},guitar{},edited{};
    // Original declaration remains visible even when playback support rejects
    // this pattern. These flags never enable a blocked track.
    bool sourceDeclaredGuitar{},sourceBlocked{};
    bool sourceCapoKnown{},sourceHumanizeKnown{};
    arranger::GuitarPatternSettings source,settings;
    arranger::GuitarOverride overrides;
};
enum class GuitarField { Mode, Capo, HighString, LowString, Humanize, ResetSource };
struct StyleDrumTone {
    int attack{-1},decay{-1},sustain{-1},release{-1}; // milliseconds, sustain percent; -1 inherits each layer
    int pan{0},tune{0},gate{-1}; // percent trim, cents trim, original / gated / one-shot
    bool valid() const {
        return attack>=-1&&attack<=10000&&decay>=-1&&decay<=10000&&sustain>=-1&&sustain<=100&&
               release>=-1&&release<=10000&&pan>=-100&&pan<=100&&tune>=-2400&&tune<=2400&&gate>=-1&&gate<=1;
    }
    bool neutral() const {return attack<0&&decay<0&&sustain<0&&release<0&&!pan&&!tune&&gate<0;}
};
using DrumTones=std::map<int,StyleDrumTone>;
struct RecentStyleHits {
    unsigned tracks{};
    std::array<std::bitset<128>,2> drums{};
};
struct ListenSolo {
    int player{-2},part{-1},key{-1}; // -2 = normal mix, -1 = keyboard
    bool matches(int p,int t,int k=-1) const {return player==p&&part==t&&key==k;}
};
struct StyleActivity {
    unsigned tracks{};
    std::array<std::string,8> programNames;
    std::array<sampler::ProgramPtr,8> sourcePrograms{};
    std::array<unsigned,8> representativeLayers{};
    struct Drum {
        int track{},note{};
        std::string name;
        sampler::ProgramPtr auditionSource;
        int velocity{};
        std::array<int,4> sourceEnvelope{}; // first played layer, milliseconds and percent
        unsigned mixedEnvelope{};
        bool hasGatedZone{},hasOneShotZone{};
    };
    std::vector<Drum> drums;
};
struct StyleSoundSettings {
    std::shared_ptr<const DrumTones> tones;
    int setAddress{-1};
    int trigger{-1}; // program, gate or one-shot
    std::array<std::int8_t,128> keyDb{};
};
struct ArrangerTrackView {
    StyleSoundSettings soundSettings;
    std::string name;
    std::string soundName;
    int soundSlot{0};
    // Original MIDI address metadata, independent of the assigned SILVETON slot.
    int msb{-1}, lsb{-1}, program{-1};
    bool addressKnown{false};
    bool addressVaries{false};
    std::string originalSoundName, originalSoundPath, originalSoundStatus;
    bool originalSoundAddressComplete{false}, originalSoundMultiple{false};
    bool originalSoundAtCvStart{true};
    int selectedCv{0}; // 1-based original Korg CV, 0 means no selected CV
    bool playbackBlocked{false};
    float volumeDb{0.0F};
    float pan{0.0F};
    bool mute{false};
    bool assigned{false};
    bool originalSoundRouted{false};
    // Native Style MIDI values; -1 means no source declaration observed.
    int sourceVolumeRaw{-1},sourcePanRaw{-1},sourceExpressionRaw{-1};
    sampler::SourceSoundEdits sourceSoundEdits{};
    std::array<int,3> sourceFxSendRaw{{-1,-1,-1}};
    std::uint8_t mixOverrideMask{0}; // volume trim, pan trim, mute: bits0..2
    float peak{0.0F};
};

struct ArrangerPlayerView {
    std::string name;
    std::string chordName;
    std::string elementName;
    std::string pendingElementName;
    std::string sourcePath;
    std::uint64_t soundRevision{};
    std::uint64_t styleSelectionSerial{0}; // committed load identity, unchanged by mix edits
    int savedStyleBank{0},savedStylePosition{0}; // private User Style destination, zero=original source
    std::string pendingStylePath, pendingStyleName;
    bool styleSwitchPending{false};
    std::string playbackWarning;
    bool playing{false};
    bool syncStart{false};
    bool syncStop{false},syncStartAutoOff{true};
    int loopElement{-1},fadeDirection{0};
    float fadeGain{1.0F},fadeInSeconds{5.0F},fadeOutSeconds{5.0F};
    bool autoFill{true};
    std::array<int,5> fillModes{};
    int autoFillMode{1}; // Current Variation=0, Target Variation=1
    bool memory{true};
    // Stable control values shared by the desktop and tablet screens.
    // Recognition: One Finger, One Finger Plus, Fingered (1 Note),
    // Fingered (3 Notes), Advanced (0..4).
    int chordRecognitionMode{2};
    // Scan area: Off, Lower, Upper, Full (0..3).
    int chordScanArea{1};
    bool splitEnabled{true};
    bool bassInversion{false};
    bool damperLatch{false};
    bool loaded{false};
    bool tempoLock{false};
    bool nativeKorgStyle{false};
    bool soundAssignmentsReady{false};
    bool samplePlaybackMode{false};
    std::uint8_t blockedTrackMask{0};
    double bpm{120.0};
    double originalBpm{120.0};
    int bar{1};
    int beat{1};
    std::uint64_t transportMeasure{0};
    int numerator{4};
    int denominator{4};
    int split{60};
    int globalSplit{60};
    int scaleAssignment{0}; // Keyboard=0, Upper=1, all melodic tracks=2
    int element{3};
    int pendingElement{-1};
    int returnElement{3}; // booked Variation after Intro/Fill/Break
    std::array<bool, 16> available{};
    std::array<ArrangerTrackView, 8> tracks{};
};

using ArrangerStyleKeyboardLinks = std::array<std::pair<std::string,std::string>,4>;
struct ArrangerStyleKeyboardSelection {
    std::string key;
    std::uint64_t serial{0};
    bool pending{false},playing{false};
    int element{3};
    std::shared_ptr<const silveton::arranger::Pa5xStyleRead> read;
    ArrangerStyleKeyboardLinks savedLinks;
};

struct ArrangerSavedStyleEntry {
    int bank{0},position{0};
    std::string name,sourcePath;
};

// A single decoded recording for audition. This is deliberately independent
// of the original PCG program, whose oscillator/DSP graph is not activated.
struct PcmPreviewView {
    std::string name;
    std::string error;
    std::uint32_t sampleRate{0};
    std::uint64_t frames{0};
    int rootKey{-1}; // -1: source key is not a valid MIDI key; audition is unpitched
    bool ready{false};
};

// Original-address binding supplied by the Korg importer. The strict API needs
// verified Sound DSP; the partial API identifies these as simplified sample playback.
// Neither mode assigns an unrelated GM patch or guesses a fixed Sound slot.
struct ArrangerOriginalProgram {
    int msb{-1}, lsb{-1}, program{-1};
    silveton::sampler::ProgramPtr sound;
};

// Control-thread keyboard recall. Programs keep their original SET addresses
// and shared sample storage; this is never a remap into 500 library positions.
struct ArrangerKeyboardSet {
    std::shared_ptr<const silveton::arranger::Pa5xKeyboardSetRead> read;
    std::shared_ptr<const std::vector<std::uint8_t>> sourceBytes;
    silveton::sampler::Combi combi;
    int splitPoint{-1}; // -1 retains the current global split
    std::size_t playableParts{0}; // available Program refs, including currently muted/out-of-zone parts
    std::vector<std::string> warnings;
};

// Native arranger facade. UI/file operations run on the control thread. prepare()
// is called while audio is stopped; renderAdd() and observeMidi() are RT-safe.
// Accompaniment uses the existing SILVETON sampler with explicitly assigned bank
// programs. A MIDI program number is never guessed/remapped to a bank slot.
struct ArrangerSourceCheckpoint;

class ArrangerHost {
public:
    ArrangerHost();
    ~ArrangerHost();
    ArrangerHost(const ArrangerHost&) = delete;
    ArrangerHost& operator=(const ArrangerHost&) = delete;

    bool loadStyle(int player, const std::string& path);
    void configureStyleEditStorage(const std::string& directory);
    bool saveStyleEdits(int player);
    bool saveStyleEdits(int player,int bank,int position,const std::string& displayName);
    bool saveStyleEdits(int player,int bank,int position,const std::string& displayName,const ArrangerStyleKeyboardLinks& keyboardSets);
    ArrangerStyleKeyboardLinks savedStyleKeyboardSets(int player) const;
    ArrangerStyleKeyboardSelection keyboardStyleSelection(int player) const;
    bool saveStyleKeyboardSets(int player,const ArrangerStyleKeyboardLinks& keyboardSets);
    bool loadSavedStyleEdits(int player,int bank,int position);
    std::vector<ArrangerSavedStyleEntry> savedStyleEdits() const;
    bool openDrumKit(const std::string& root,int msb,int lsb,int program,DrumKitDraft& draft);
    bool writeDrumKit(DrumKitDraft& draft);
    static bool inspectDrumKitEdit(const std::string& identity,const std::string& text);
    bool auditionDrumKit(DrumKitDraft& draft,int key,int velocity);
    bool setDrumKitMidiAudition(DrumKitDraft& draft,bool enabled);
    bool drumKitMidiAuditionEnabled() const noexcept;
    bool routeDrumKitPreviewMidi(std::uint8_t status,std::uint8_t key,std::uint8_t value) noexcept;
    bool auditionSetSound(sampler::ProgramPtr program,int key,int velocity);
    bool installKorgSetBank(std::shared_ptr<const silveton::arranger::Pa5xSetBank> bank);
    // Publish one immutable SET-wide sample bank after its worker has prepared
    // the Programs. loadStyle then binds only its own original addresses.
    bool installKorgSampleBank(std::shared_ptr<const silveton::arranger::Pa5xSetBank> bank,
        const std::vector<ArrangerOriginalProgram>& programs,
        const std::vector<std::string>& warnings = {}, bool hasPerformanceCatalog = false);
    std::shared_ptr<const silveton::arranger::Pa5xStyleRead> styleRead(int player) const;
    std::shared_ptr<const silveton::arranger::Pa5xSetBank> styleBank(int player) const;
    bool readKeyboardSet(const std::string& path);
    std::shared_ptr<const silveton::arranger::Pa5xKeyboardSetRead> keyboardSetRead() const;
    // keyboardSplitEnabled is the keyboard's physical SPLIT mode, independent
    // of Chord Split/recognition. Source ranges remain available in result.read.
    // allowSilent retains validated metadata for saving all four Style slots;
    // normal live recall rejects a setup with no playable prepared User parts.
    bool prepareKeyboardSet(const std::string& path, ArrangerKeyboardSet& result,
                            int midiChannel = 0, bool keyboardSplitEnabled = true,bool allowSilent = false);
    bool prepareKeyboardSetBytes(const std::vector<std::uint8_t>& bytes,const std::string& sourcePath,
                                ArrangerKeyboardSet& result,int midiChannel = 0,
                                bool keyboardSplitEnabled = true,bool allowSilent = false);
    // position is0..3. Original embedded XML/MIDI is read through the same
    // bounded decoder and uses the Style's exact prepared SET sound catalogue.
    bool prepareStyleKeyboardSet(int player,int position,ArrangerKeyboardSet& result,
                                 int midiChannel = 0,bool keyboardSplitEnabled = true,bool allowSilent = false);
    silveton::sampler::ProgramPtr preparedKeyboardSound(int msb, int lsb, int program,
                                                       const std::string& sourcePath = {}) const;
    // Explicit UI commit after a successful keyboard recall/assignment. Only
    // seven selected Program references are retained, never entire extra SETs.
    // Pass -1/-1/-1 to clear one part's provenance.
    bool retainPreparedKeyboardSound(int part, int msb, int lsb, int program,
                                     const std::string& sourcePath = {});
    bool loadPcmPreview(const std::string& pcmPath, const std::string& kmpPath,
                        std::uint64_t resourceId);
    bool playPcmPreview();
    void stopPcmPreview();
    PcmPreviewView pcmPreview() const;
    // Explicit user test assignment of the selected raw waveform. It is not
    // an automatic reconstruction of a Korg Sound or a saved fixed bank slot.
    bool assignPcmPreview(int player, int track);
    std::string lastError() const;
    ArrangerPlayerView snapshot(int player) const;
    arranger::PlayerSnapshot liveTransport(int player) const noexcept;
    // Bounded audio-thread read; the keyboard follows the sole playing player
    // or, with both/neither playing, the dominant crossfade side.
    float keyboardSourceTempo() const noexcept;
    bool pollPlayerVoices(int player,sampler::VoiceActivity& out) noexcept;
    bool setTempo(int player, double bpm);
    bool resetTempo(int player);
    bool setTempoLock(bool enabled, int sourcePlayer = 0);
    bool toggleTempoLock(int player);
    bool startStop(int player);
    bool start(int player);
    bool startWithTempo(int player, double bpm);
    bool resetPosition(int player);
    bool stop(int player);
    bool selectElement(int player, int element);
    bool setSyncStart(int player, bool enabled);
    bool setSyncStop(int player, bool enabled);
    bool toggleSyncStop(int player);
    bool setSyncStartAutoOff(bool enabled);
    bool toggleSyncStartAutoOff();
    bool toggleSectionLoop(int player);
    bool toggleFade(int player);
    bool setFadeTimes(float inSeconds,float outSeconds);
    bool adjustFadeTimes(float inDelta,float outDelta);
    bool setAutoFill(int player, bool enabled);
    bool setAutoFillMode(int mode);
    StyleRangeView styleRange(int player,std::uint64_t selection,int element,int track);
    bool editRange(int player,std::uint64_t selection,int element,int track,RangeField field,int value);
    StyleGuitarView styleGuitar(int player,std::uint64_t selection,int element,int track);
    bool editGuitar(int player,std::uint64_t selection,int element,int track,GuitarField field,int value);
    bool setFillMode(int player,std::uint64_t selection,int fill,int mode);
    bool setTrackTrigger(int player,std::uint64_t selection,int track,int mode);
    bool cycleAutoFillMode();
    bool setMemory(bool enabled);
    bool toggleSyncStart(int player);
    bool toggleAutoFill(int player);
    bool toggleMemory();
    bool setSplit(int key);
    bool setKeyboardSplit(int key, bool enabled); // shared panel SPLIT point/state, preserving Chord Scan
    // One recall; -1 leaves that optional control unchanged, including queued edits.
    // acceptedSerial is nonzero only after queue insertion. Read the ACK
    // before a control snapshot when deciding whether to use pending intent.
    bool setKeyboardRecall(int key,bool enabled,int chordScanArea=-1,int bassInversion=-1,std::uint32_t* acceptedSerial=nullptr);
    std::uint32_t keyboardRecallCommittedSerial() const noexcept;
    bool setGlobalSplit(int key,bool applyEffective=true); // template can be edited independently of a local split
    int globalSplit() const noexcept;
    bool setChordRecognitionMode(int mode);
    bool setChordScanArea(int area);
    bool toggleChordScanAreaBit(int bit); // 1=Lower, 2=Upper; preserves shared SPLIT
    bool selectChordScanZone(int area); // explicit Lower/Upper selection also enables Chord Split
    bool setSplitEnabled(bool enabled);
    bool setBassInversion(bool enabled);
    bool setDamperLatch(bool enabled);
    bool toggleChordSplit();
    bool toggleBassInversion();
    bool toggleDamperLatch();
    void setCrossfade(float position) noexcept;
    float crossfade() const noexcept;
    static bool inspectStyleRevision(const std::string& filename,const std::string& bytes,std::string& path,
            std::string& identity,std::string& name,ArrangerStyleKeyboardLinks& keyboardSets);
    std::shared_ptr<const sampler::Combi> styleTrackCombi(int player,std::uint64_t& selection) const;
    bool editStyleCombi(int player,std::uint64_t selection,const std::function<void(sampler::Combi&)>& change,const sampler::Combi* expected=nullptr);
    bool restoreStyleSourceEffects(int player,std::uint64_t selection);
    bool setTrackVolume(int player, int track, float db, std::uint64_t selection = 0);
    bool setTrackPan(int player, int track, float pan);
    float styleGateReduction(int player,int part) const;
    std::vector<float> styleAnalyzerFrame(int player,int track,bool after);
    ListenSolo listenSolo() const noexcept;
    void setListenSolo(sampler::SamplerEngine& keyboard,ListenSolo target) noexcept;
    bool setTrackMute(int player,int track,bool muted);
    bool toggleTrackMute(int player,int track,std::uint64_t selection,bool& muted);
    bool assignSound(int player, int track, int slot,
                     silveton::sampler::ProgramPtr program, std::uint64_t selection=0,
                     int setAddress=-1, const std::string& setRoot={});
    RecentStyleHits recentStyleHits(int player,std::uint64_t selection) const;
    StyleActivity styleActivity(int player,const ArrangerPlayerView& view) const;
    bool auditionStyleDrum(int player,std::uint64_t selection,std::uint64_t soundRevision,const StyleActivity::Drum& drum);
    void releasePreviewNote(int key);
    bool setStyleDrum(int player,int track,std::uint64_t selection,int note,int db,const StyleDrumTone& tone);
    void clearSoundAssignments();
    // Builds all original-address routes used by this loaded native Style.
    // Missing/ambiguous programs or unsupported channel ownership reject the
    // entire preparation, retaining previous explicit assignments unchanged.
    bool prepareKorgStylePrograms(int player,
        const std::vector<ArrangerOriginalProgram>& programs);
    // Partial, explicitly simplified sample playback. Missing addresses remain
    // silent; a real loaded sample Program on any used track enables START.
    bool prepareKorgSamplePrograms(int player,
        const std::vector<ArrangerOriginalProgram>& programs,
        const std::vector<std::string>& warnings = {});
    void syncGlobal(const silveton::sampler::GlobalState& global, bool scaleEnabled = true);
    bool setScaleAssignment(int assignment);
    bool saveSetup(const std::string& path) const;
    bool loadSetup(const std::string& path);
    // Private app-session text. Native routes are recorded by original source
    // and rebuilt only after the requested SET sample banks have been prepared.
    std::string persistentSession() const;
    std::uint64_t persistenceRevision() const noexcept;
    std::vector<std::string> persistentSessionSetRoots(const std::string& text) const;
    bool persistentSessionNeedsSamplerBank(const std::string& text) const;
    bool beginPersistentSessionRestore(const std::string& text,
        const std::vector<std::string>& additionalSetRoots = {});
    void cancelPersistentSessionRestore();
    bool restorePersistentSession(const std::string& text);
    bool persistentSessionRestoreCommitted() const;
    // MEDIA rollback pins existing prepared graphs; sample storage is shared.
    std::shared_ptr<const ArrangerSourceCheckpoint> sourceCheckpoint() const;
    bool restoreSourceCheckpoint(const std::shared_ptr<const ArrangerSourceCheckpoint>& checkpoint);


    // Audio callbacks must be stopped. The keyboard and both arranger players
    // use one bounded worker group and render sequentially on that callback.
    void configureSharedRendering(silveton::sampler::SamplerEngine& master);
    void prepare(double rate, std::uint32_t maximumFrames);
    void startStreaming(); // audio-control thread, before playback starts
    void stopStreaming();  // audio-control thread, after playback has stopped
    int takeEditorNote() noexcept;
    bool observeMidi(std::uint8_t status, std::uint8_t d1, std::uint8_t d2) noexcept;
    void renderAdd(float* stereo, std::uint32_t frames, double rate) noexcept;
    void recordBlockCost(float cpuPercent) noexcept;
    silveton::sampler::MeterSnapshot combinedMeters(const silveton::sampler::MeterSnapshot& keyboard) const noexcept;
    void panic() noexcept;

private:
    friend struct ArrangerSourceCheckpoint;
    bool prepareKeyboardSetResource(const std::string& path,const std::vector<std::uint8_t>* bytes,
        ArrangerKeyboardSet& result,int midiChannel,bool keyboardSplitEnabled,bool allowSilent);
    bool loadStyleWithEdits(int player,const std::string& path,const std::string& explicitRevision,int bank,int position);
    bool saveStyleEditsImpl(int player,int bank,int position,const std::string& displayName,const ArrangerStyleKeyboardLinks* keyboardSets = nullptr);
    bool prepareKorgSampleProgramsImpl(int player,
        const std::vector<ArrangerOriginalProgram>& programs,
        const std::vector<std::string>& warnings, bool prevalidated,
        const silveton::arranger::Pa5xStyleRead* expectedRead);
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

ArrangerHost& arrangerHost();
// Resolve against the sampler that already exists; constructing another
// NativeSamplerEngine would reset the existing host, so the UI uses these.
bool assignArrangerBankSound(int player, int track, int bank, int page, int slot);
silveton::sampler::ProgramPtr resolveArrangerBankSound(int slot);
bool loadArrangerSetup(const std::string& path);

} // namespace silveton::host
