#pragma once

#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/Pa5xStyleRead.h"
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <list>
#include <memory>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace silveton::host::detail {

// Control-thread only; callers serialize access with their host control mutex.
// Caches a small working set, not all of a potentially multi-gigabyte SET.
class Pa5xStyleReadCache {
public:
    struct Key {
        bool valid{false}, hasBank{false};
        std::string path;
        std::uint64_t device{0}, inode{0}, bytes{0};
        std::int64_t modifiedSeconds{0}, modifiedNanos{0}, changedSeconds{0}, changedNanos{0};
        const arranger::Pa5xSetBank* bankIdentity{nullptr};
        std::weak_ptr<const arranger::Pa5xSetBank> bank;
    };

    static Key keyFor(const std::string& path,
            const std::shared_ptr<const arranger::Pa5xSetBank>& bank) {
        Key key;std::string source=path;int slot=0;const bool legacy=arranger::paStyleSlot(path,&source,&slot);
        std::unique_ptr<char,decltype(&std::free)> real(::realpath(source.c_str(),nullptr),&std::free);
        if(!real)return key;
        struct stat info{};
        if(::stat(real.get(),&info)!=0 || !S_ISREG(info.st_mode) || info.st_size<=0)return key;
        key.valid=true;key.path=real.get();if(legacy)key.path+="!/"+std::to_string(slot);key.hasBank=bank!=nullptr;
        key.bankIdentity=bank.get();key.bank=bank;
        key.device=static_cast<std::uint64_t>(info.st_dev);
        key.inode=static_cast<std::uint64_t>(info.st_ino);
        key.bytes=static_cast<std::uint64_t>(info.st_size);
#if defined(__APPLE__)
        key.modifiedSeconds=static_cast<std::int64_t>(info.st_mtimespec.tv_sec);
        key.modifiedNanos=static_cast<std::int64_t>(info.st_mtimespec.tv_nsec);
        key.changedSeconds=static_cast<std::int64_t>(info.st_ctimespec.tv_sec);
        key.changedNanos=static_cast<std::int64_t>(info.st_ctimespec.tv_nsec);
#else
        key.modifiedSeconds=static_cast<std::int64_t>(info.st_mtim.tv_sec);
        key.modifiedNanos=static_cast<std::int64_t>(info.st_mtim.tv_nsec);
        key.changedSeconds=static_cast<std::int64_t>(info.st_ctim.tv_sec);
        key.changedNanos=static_cast<std::int64_t>(info.st_ctim.tv_nsec);
#endif
        return key;
    }

    std::shared_ptr<const arranger::Pa5xStyleRead> find(const Key& key) {
        if(!key.valid)return {};
        for(auto it=entries_.begin();it!=entries_.end();) {
            if(it->key.path!=key.path){++it;continue;}
            if(!same(it->key,key)) {
                usedBytes_-=it->bytes;it=entries_.erase(it);continue;
            }
            auto result=it->read;entries_.splice(entries_.begin(),entries_,it);return result;
        }
        return {};
    }

    // The key must be captured BEFORE parsing. Never cache a result if the
    // source was replaced or modified while the reader was building it.
    bool insert(const Key& key,std::shared_ptr<const arranger::Pa5xStyleRead> read) {
        if(!key.valid || !read || !read->valid || !read->nativeStyle)return false;
        const auto bank=key.bank.lock();
        if(key.hasBank && !bank)return false;
        if(!same(key,keyFor(key.path,bank)))return false;
        const auto bytes=estimatedBytes(*read);
        for(auto it=entries_.begin();it!=entries_.end();) {
            if(it->key.path==key.path){usedBytes_-=it->bytes;it=entries_.erase(it);}
            else ++it;
        }
        if(bytes>maximumBytes)return false;
        while(!entries_.empty() && (entries_.size()>=maximumEntries || usedBytes_>maximumBytes-bytes)) {
            usedBytes_-=entries_.back().bytes;entries_.pop_back();
        }
        entries_.push_front({key,std::move(read),bytes});usedBytes_+=bytes;return true;
    }

    void clear() noexcept {entries_.clear();usedBytes_=0;}
    std::size_t entryCount() const noexcept {return entries_.size();}
    std::size_t estimatedMemoryBytes() const noexcept {return usedBytes_;}

private:
    static constexpr std::size_t maximumEntries=8;
    static constexpr std::size_t maximumBytes=64U*1024U*1024U;
    struct Entry {Key key;std::shared_ptr<const arranger::Pa5xStyleRead> read;std::size_t bytes{0};};
    std::list<Entry> entries_;
    std::size_t usedBytes_{0};

    static bool same(const Key& a,const Key& b) {
        if(!a.valid || !b.valid || a.path!=b.path || a.hasBank!=b.hasBank || a.bankIdentity!=b.bankIdentity)return false;
        if(a.hasBank && (a.bank.expired() || b.bank.expired()))return false;
        return a.device==b.device && a.inode==b.inode && a.bytes==b.bytes &&
            a.modifiedSeconds==b.modifiedSeconds && a.modifiedNanos==b.modifiedNanos &&
            a.changedSeconds==b.changedSeconds && a.changedNanos==b.changedNanos;
    }

    struct Size {
        std::size_t bytes{0};
        void add(std::size_t amount) noexcept {
            const auto maximum=std::numeric_limits<std::size_t>::max();
            bytes=amount>maximum-bytes?maximum:bytes+amount;
        }
        void text(const std::string& value) noexcept {add(value.capacity());add(33);}
        template<class T> void vector(const std::vector<T>& values) noexcept {
            const auto maximum=std::numeric_limits<std::size_t>::max();
            if(values.capacity()>maximum/sizeof(T)){bytes=maximum;return;}
            add(values.capacity()*sizeof(T));if(values.capacity()!=0)add(32);
        }
        void strings(const std::vector<std::string>& values) noexcept {
            vector(values);for(const auto& value:values)text(value);
        }
        void soundChanges(const std::vector<arranger::Pa5xStyleSoundChange>& values) noexcept {
            vector(values);for(const auto& value:values){text(value.sound.name);text(value.sound.path);text(value.sound.message);}
        }
        void nativeTrack(const std::shared_ptr<const arranger::PaSeriesTrackSettings>& value) noexcept {
            if(!value)return;
            add(sizeof(*value)+64);vector(value->originalRecord);text(value->error);
        }
        void effects(const std::shared_ptr<const arranger::KorgSourceEffects>& value) noexcept {
            if(!value)return;
            add(sizeof(*value)+64);text(value->resourcePath);text(value->error);
            vector(value->definitions);for(const auto& effect:value->definitions)vector(effect.originalRecord);
            vector(value->sends);vector(value->unknownMessages);
            for(const auto& message:value->unknownMessages)vector(message.payload);
        }
    };

    static std::size_t estimatedBytes(const arranger::Pa5xStyleRead& read) noexcept {
        Size size;size.add(sizeof(read)+sizeof(Entry)+128);
        size.text(read.name);size.text(read.sourcePath);size.text(read.error);size.strings(read.warnings);
        size.effects(read.sourceEffects);
        for(const auto& slot:read.keyboardSets) {
            size.text(slot.name);size.text(slot.resourcePath);size.text(slot.error);
            if(slot.resourceBytes){size.add(sizeof(*slot.resourceBytes)+64);size.vector(*slot.resourceBytes);}
            if(!slot.keyboardSet)continue;
            const auto& keyboard=*slot.keyboardSet;size.add(sizeof(keyboard)+64);
            size.text(keyboard.name);size.text(keyboard.sourcePath);size.text(keyboard.error);size.strings(keyboard.issues);
            size.effects(keyboard.sourceEffects);
            for(const auto& part:keyboard.parts) {
                size.nativeTrack(part.sourceNativeTrack);size.effects(part.sourceEffects);
                size.text(part.name);size.text(part.resourcePath);size.text(part.soundName);
                size.text(part.soundPath);size.text(part.soundMessage);size.strings(part.issues);
                size.vector(part.opaqueMidiEvents);
                for(const auto& event:part.opaqueMidiEvents)size.vector(event.payload);
            }
            const auto& complement=keyboard.complement;
            size.text(complement.resourcePath);size.vector(complement.midiBytes);
            const auto& midi=complement.midi;size.text(midi.error);size.vector(midi.tracks);
            for(const auto& track:midi.tracks)size.text(track.name);
            size.vector(midi.channelEvents);size.vector(midi.opaqueMidiEvents);
            for(const auto& event:midi.opaqueMidiEvents)size.vector(event.payload);
            size.vector(midi.patches);size.vector(midi.tempos);size.vector(midi.timeSignatures);
        }
        for(const auto& section:read.sections)for(const auto& track:section.tracks) {
            // Shared source pointers are deliberately charged per reference:
            // this is a conservative upper bound, never an unbudgeted payload.
            size.nativeTrack(track.sourceNativeTrack);size.effects(track.sourceEffects);
            size.text(track.path);size.text(track.patternType);
            size.soundChanges(track.setupSoundChanges);size.vector(track.setupTempoChanges);
            size.vector(track.setupTimeSignatureChanges);size.vector(track.setupBankProgramEvents);
            size.vector(track.unscopedBankProgramEvents);size.vector(track.unscopedTempoChanges);
            size.vector(track.unscopedTimeSignatureChanges);
            for(const auto& cv:track.cvs) {
                size.text(cv.sourceRoot);size.text(cv.sourceChord);size.soundChanges(cv.soundChanges);
                size.vector(cv.tempoChanges);size.vector(cv.timeSignatureChanges);size.vector(cv.bankProgramEvents);
            }
        }
        if(read.nativeStyle) {
            const auto& style=*read.nativeStyle;size.add(sizeof(style)+64);
            size.text(style.name);size.strings(style.playbackWarnings);
            for(const auto& track:style.tracks)size.text(track.name);
            for(const auto& section:style.sections) {
                size.vector(section.events);
                for(const auto& pattern:section.patterns) {
                    size.vector(pattern.setupEvents);
                    for(const auto& cv:pattern.cvs){size.vector(cv.events);size.vector(cv.tempoEvents);}
                }
            }
        }
        if(read.inspection) {
            const auto& inspection=*read.inspection;size.add(sizeof(inspection)+64);
            size.effects(inspection.sourceEffects);
            size.text(inspection.name);size.text(inspection.error);size.strings(inspection.playbackBlockers);
            size.vector(inspection.elements);
            for(const auto& element:inspection.elements) {
                size.vector(element.clips);
                for(const auto& clip:element.clips) {
                    size.effects(clip.sourceEffects);
                    size.text(clip.path);size.text(clip.patternType);size.text(clip.originalRoot);size.text(clip.originalChord);
                    size.vector(clip.cvSources);for(const auto& cv:clip.cvSources){size.text(cv.root);size.text(cv.chord);}
                    size.vector(clip.chordVariations);size.vector(clip.chordSelections);
                    for(const auto& chord:clip.chordSelections)size.text(chord.chord);
                    size.vector(clip.patches);for(const auto& patch:clip.patches)size.text(patch.name);
                    size.vector(clip.patchSelections);size.vector(clip.channelEvents);size.vector(clip.midiTracks);
                    for(const auto& track:clip.midiTracks)size.text(track.name);
                    size.vector(clip.tempos);size.vector(clip.timeSignatures);size.vector(clip.opaqueMidiEvents);
                    for(const auto& event:clip.opaqueMidiEvents)size.vector(event.payload);
                }
            }
        }
        return size.bytes;
    }
};

} // namespace silveton::host::detail
