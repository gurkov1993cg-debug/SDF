#pragma once
#include "silveton/sampler/SamplerTypes.h"

namespace silveton::host::detail {
// User-requested recall policy, not a decoded Korg parameter. Apply only at
// original Keyboard Set/Sound recall, never to the immutable PCG Program,
// never on a note event and never when reopening an edited SILVETON combi.
inline constexpr int importedLegatoPortamentoTime = 30;
inline bool applyImportedLegatoPortamentoDefault(sampler::UpperPart& part) noexcept {
    if(!part.program||!part.sourceVoiceInherit||!part.sourcePortamentoInherit||
       !part.program->sourceVoiceAssignment.legato()||
       part.portaMode!=sampler::PortamentoMode::Silveton||part.portamentoSec>0.0F)return false;
    for(const auto& layer:part.program->layers){
        if(layer.enabled&&sampler::sourcePortamentoOn(layer.sourcePortamento,part.sourceSoundEdits)){
            part.sourceSoundEdits.setController(5,importedLegatoPortamentoTime);
            return true;
        }
    }
    return false;
}
// Selecting a new original SOUND is different from editing a recalled part.
// Restore its own voice/porta flags so CC5/65 from the previous SOUND cannot
// carry over to the newly selected one. Other mixer and tone edits remain.
inline void recallImportedSoundVoiceControls(sampler::UpperPart& part) noexcept {
    if(!part.program||!part.program->sourceVoiceAssignment.present||
       !part.program->sourceVoiceAssignment.valid())return;
    part.sourceVoiceInherit=true;
    part.voiceMode=part.program->legato?sampler::UpperVoiceMode::Legato:
        part.program->mono?sampler::UpperVoiceMode::Mono:sampler::UpperVoiceMode::Poly;
    part.sourcePortamentoInherit=true;
    part.portaMode=sampler::PortamentoMode::Silveton;
    part.portamentoSec=part.program->portamentoSec;
    part.sourceSoundEdits.setController(5,-1);
    part.sourceSoundEdits.setController(65,-1);
    (void)applyImportedLegatoPortamentoDefault(part);
}
}
