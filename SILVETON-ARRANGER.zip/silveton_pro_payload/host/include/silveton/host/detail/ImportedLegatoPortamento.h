#pragma once
#include "silveton/sampler/SamplerTypes.h"
#include <algorithm>
#include <cmath>

namespace silveton::host::detail {
// Original Pa programs always use their own oscillator portamento controls.
// Native SILVETON programs retain the existing alternative glide engines.
inline bool hasImportedKeyboardSound(const sampler::UpperPart& part) noexcept {
    const auto imported=[](const sampler::ProgramPtr& p){
        if(!p)return false;
        if(p->sourceVoiceAssignment.present)return true;
        for(const auto& osc:p->layers)if(osc.sourcePortamento.present)return true;
        return false;
    };
    if(imported(part.program))return true;
    for(const auto& layer:part.layers)if(layer.enabled&&imported(layer.program))return true;
    return false;
}
// Older working COMBIs may contain the duplicate manual glide engine. Migrate
// that explicit setting once to the per-part CC controls. A manual Off stays
// Off. A SILVETON millisecond duration is converted through the same time law
// used at playback (not reinterpreted as a Korg index).
inline bool normalizeImportedKeyboardPortamento(sampler::UpperPart& part) noexcept {
    if(!hasImportedKeyboardSound(part))return false;
    if(part.sourcePortamentoInherit&&part.portaMode==sampler::PortamentoMode::Silveton&&part.portamentoSec<=0.0F)return false;
    int index=part.portaTime;
    if(part.portaMode==sampler::PortamentoMode::Silveton){
        const float sec=std::isfinite(part.portamentoSec)?std::clamp(part.portamentoSec,0.0F,5.0F):0.0F;
        index=sec>0.0F?std::max(1,static_cast<int>(std::lround(127.0F*std::pow(sec/5.0F,1.0F/2.2F)))):0;
    }
    index=std::clamp(index,0,127);
    part.sourceSoundEdits.setController(65,index>0?127:0);
    if(index>0)part.sourceSoundEdits.setController(5,index);
    part.sourcePortamentoInherit=true;
    part.portaMode=sampler::PortamentoMode::Silveton;
    part.portamentoSec=0.0F;part.portaTime=0;
    return true;
}
inline void resetImportedKeyboardPortamento(sampler::UpperPart& part) noexcept {
    part.sourcePortamentoInherit=true;
    part.portaMode=sampler::PortamentoMode::Silveton;
    part.portamentoSec=0.0F;part.portaTime=0;
    part.sourceSoundEdits.setController(5,-1);
    part.sourceSoundEdits.setController(65,-1);
}

// User-requested recall policy, not a decoded Korg parameter. Apply only at
// original Keyboard Set/Sound recall, never to the immutable PCG Program,
// never on a note event and never when reopening an edited SILVETON combi.
inline constexpr int importedLegatoPortamentoTime = 30;
inline bool applyImportedLegatoPortamentoDefault(sampler::UpperPart& part) noexcept {
    // A stored Keyboard Set override is authoritative, including explicit 0.
    // The requested 30 default is only for parts with no stored Time override.
    if(part.sourceSoundEdits.controller(5)>=0)return false;
    if(!part.program||!part.sourceVoiceInherit||!part.sourcePortamentoInherit||
       !part.program->sourceVoiceAssignment.legato()||
       part.portaMode!=sampler::PortamentoMode::Silveton||part.portamentoSec>0.0F)return false;
    for(const auto& layer:part.program->layers){
        if(layer.enabled&&sampler::sourcePortamentoOn(layer.sourcePortamento,part.sourceSoundEdits)){
            part.sourceSoundEdits.setController(5,importedLegatoPortamentoTime);
            return true;
        }
    }
    return false;
}
// Selecting a new original SOUND is different from editing a recalled part.
// Restore its own voice/porta flags so CC5/65 from the previous SOUND cannot
// carry over to the newly selected one. Other mixer and tone edits remain.
inline void recallImportedSoundVoiceControls(sampler::UpperPart& part) noexcept {
    if(!part.program||!part.program->sourceVoiceAssignment.present||
       !part.program->sourceVoiceAssignment.valid())return;
    part.sourceVoiceInherit=true;
    part.voiceMode=part.program->legato?sampler::UpperVoiceMode::Legato:
        part.program->mono?sampler::UpperVoiceMode::Mono:sampler::UpperVoiceMode::Poly;
    part.sourcePortamentoInherit=true;
    part.portaMode=sampler::PortamentoMode::Silveton;
    part.portamentoSec=part.program->portamentoSec;
    part.sourceSoundEdits.setController(5,-1);
    part.sourceSoundEdits.setController(65,-1);
    (void)applyImportedLegatoPortamentoDefault(part);
}
}
