#pragma once
#include "silveton/sampler/SamplerTypes.h"
#include <array>
#include <map>

namespace silveton::host {
struct DrumEditZone {
    unsigned layer{0};
    sampler::SampleZone zone;
};
using DrumKeyZones=std::vector<DrumEditZone>;
struct DrumKitDraft {
    std::string root,identity;
    std::uint32_t address{};
    sampler::ProgramPtr original,current;
    std::array<DrumKeyZones,128> keys;
    sampler::DrumKeyGroups drumKeyGroups{};
    std::vector<sampler::SamplePtr> samples;
    sampler::ProgramPtr preview;
    std::string previewSignature;
    bool dirty{false};
    bool previewNeedsRefresh{true};
    void markEdited() noexcept {dirty=true;previewNeedsRefresh=true;}
    sampler::ProgramPtr makeProgram() const;
};
}
