#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace silveton::host {

// Per input cable: release its keys and its configured sustain controller when
// the device disappears. Remember all CC thresholds so remapped/reversed pedals
// use the same release message as the engine's current GLOBAL configuration.
class MidiHeldState {
public:
    void track(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
        const auto channel = static_cast<std::size_t>(status & 0x0FU);
        const auto kind = static_cast<std::uint8_t>(status & 0xF0U);
        const auto key = static_cast<std::uint8_t>(data1 & 0x7FU);
        const auto at = channel * 2U + static_cast<std::size_t>(key >> 6U);
        const std::uint64_t keyBit = std::uint64_t{1} << (key & 0x3FU);
        if (kind == 0x90U && data2 > 0U) keys_[at] |= keyBit;
        else if (kind == 0x80U || kind == 0x90U) keys_[at] &= ~keyBit;
        else if (kind == 0xB0U) {
            const auto channelBit = static_cast<std::uint16_t>(1U << channel);
            ccSeen_[key] = static_cast<std::uint16_t>(ccSeen_[key] | channelBit);
            if (data2 >= 64U) ccHigh_[key] = static_cast<std::uint16_t>(ccHigh_[key] | channelBit);
            else ccHigh_[key] = static_cast<std::uint16_t>(ccHigh_[key] & ~channelBit);
        }
    }

    template <class Sink>
    void release(Sink&& sink, std::uint8_t damperCc, bool reversed) {
        damperCc &= 0x7FU;
        const auto down = static_cast<std::uint16_t>(ccSeen_[damperCc] &
            (reversed ? static_cast<std::uint16_t>(~ccHigh_[damperCc]) : ccHigh_[damperCc]));
        for (std::uint8_t channel = 0U; channel < 16U; ++channel) {
            for (std::uint8_t half = 0U; half < 2U; ++half) {
                const auto bits = keys_[static_cast<std::size_t>(channel) * 2U + half];
                for (std::uint8_t bit = 0U; bit < 64U; ++bit) {
                    if ((bits & (std::uint64_t{1} << bit)) != 0U)
                        sink(static_cast<std::uint8_t>(0x80U | channel),
                             static_cast<std::uint8_t>(half * 64U + bit), std::uint8_t{0U});
                }
            }
            if ((down & (1U << channel)) != 0U)
                sink(static_cast<std::uint8_t>(0xB0U | channel), damperCc,
                     static_cast<std::uint8_t>(reversed ? 127U : 0U));
        }
        reset();
    }

    void reset() noexcept {
        keys_.fill(0U);
        ccSeen_.fill(0U);
        ccHigh_.fill(0U);
    }

private:
    std::array<std::uint64_t, 32U> keys_{};
    std::array<std::uint16_t, 128U> ccSeen_{};
    std::array<std::uint16_t, 128U> ccHigh_{};
};

} // namespace silveton::host
