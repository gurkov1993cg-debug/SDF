#pragma once
#include "silveton/sampler/SamplerTypes.h"
#include <algorithm>
#include <array>
#include <string>
#include <string_view>
#include <cctype>
#include <cmath>
#include <cstdint>

namespace silveton::host {
inline constexpr std::array<const char*,8> drumFamilyNames{{"Kick","Snare","Toms","Hi-Hat","Cymbals","Low Perc","High Perc","Effects"}};
// These are conservative name-derived suggestions, NOT decoded Korg family IDs.
// Do not infer family from an exclusive/choke group or from the MIDI key.
inline int suggestedDrumFamily(std::string_view name) {
    std::string words=" ";
    for(unsigned char ch:name) words+=std::isalnum(ch)?static_cast<char>(std::tolower(ch)):' ';
    words+=' ';
    const auto has=[&](std::string_view word){return words.find(" "+std::string(word)+" ")!=std::string::npos;};
    std::array<bool,8> found{{has("kick")||has("bd"),has("snare")||has("sd"),has("tom")||has("toms"),
        has("hihat")||has("hh")||has("hi hat"),has("ride")||has("crash")||has("cymbal"),
        has("low conga")||has("low bongo")||has("low perc")||has("low percussion"),
        has("high conga")||has("high bongo")||has("high perc")||has("high percussion"),has("sfx")||has("fx")||has("effect")}};
    int result=-1;
    for(int i=0;i<8;++i)if(found[i]){if(result>=0)return -1;result=i;}
    return result;
}
struct StyleDrumFamilyMap {
    bool available{};
    std::uint64_t revision{};
    std::string kitName,reason;
    struct Key { bool present{}; int family{-1}; std::string name; std::array<int,4> envelope{{-1,-1,-1,-1}}; unsigned mixedEnvelope{}; };
    std::array<Key,128> keys{};
};
inline StyleDrumFamilyMap describeDrumFamilies(const sampler::Program& program) {
    StyleDrumFamilyMap map;map.available=true;map.kitName=program.name;
    for(const auto& layer:program.layers){
        if(!layer.enabled||!layer.multisample)continue;
        const auto env=sampler::editableAmpEnvelope(layer);
        const std::array<int,4> envelope{{int(std::lround(env.attackSec*1000)),int(std::lround(env.decaySec*1000)),int(std::lround(env.sustain*100)),int(std::lround(env.releaseSec*1000))}};
        for(const auto& zone:layer.multisample->zones){
            if(!zone.sample||!zone.sample->valid()||zone.keyLow!=zone.keyHigh||zone.keyLow<layer.keyLow||zone.keyLow>layer.keyHigh||zone.velocityHigh<layer.velocityLow||zone.velocityLow>layer.velocityHigh)continue;
            auto& key=map.keys[zone.keyLow];const int family=suggestedDrumFamily(zone.sample->name);
            if(!key.present){key.present=true;key.family=family;key.name=zone.sample->name;key.envelope=envelope;}
            else{if(key.family!=family)key.family=-1;
                for(int i=0;i<4;++i)if(key.envelope[i]!=envelope[i])key.mixedEnvelope|=1U<<i;}
        }
    }
    if(std::none_of(map.keys.begin(),map.keys.end(),[](const auto& k){return k.present;})){
        map.available=false;map.reason="The selected track has no one-key drum sample zones";
    }
    return map;
}
}
