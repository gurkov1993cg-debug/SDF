#pragma once
#include "silveton/sampler/SamplerTypes.h"

namespace silveton::host { using sampler::editableAmpEnvelope; }
