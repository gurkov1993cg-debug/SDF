#include <type_traits>
#include "silveton/arranger/PaStyleBank.h"
#include "silveton/host/ArrangerHost.h"
#include "silveton/host/detail/Pa5xStyleReadCache.h"
#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xSampleIndex.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xSampleDiskCache.h"
#include "silveton/arranger/Pa5xStyleRead.h"
#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/arranger/Pa5xDrumSampleProgram.h"
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SourceEffects.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "silveton/sampler/CpuWorkPolicy.h"
#include "silveton/sampler/SampleStreamPrefetcher.h"
#include "silveton/sampler/SampleStream.h"
#include "silveton/sampler/SvBankFormat.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <limits>
#include <map>
#include <set>
#include <mutex>
#include <sstream>
#include <thread>
#include <tuple>
#include <cerrno>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

namespace silveton::host {
#include "ArrangerStyleFx.inc"
#include "ArrangerStyleSounds.inc"
#include "ArrangerStyleEdits.inc"
#include "ArrangerDrumEdits.inc"
#include "ArrangerSourceFx.inc"
#include "ArrangerSourceTrack.inc"
namespace {
constexpr std::uint32_t kMaximumFrames = 4096;
constexpr unsigned kMixVolume=1U,kMixPan=2U,kMixMute=4U;
constexpr std::uint16_t kDamperReversed = 128U, kControlChangesFiltered = 256U;
constexpr const char* kTrackNames[8] = {"Drum", "Perc", "Bass", "Acc 1", "Acc 2", "Acc 3", "Acc 4", "Acc 5"};
bool playerOk(int p) noexcept { return p >= 0 && p < 2; }
bool trackOk(int p, int t) noexcept { return playerOk(p) && t >= 0 && t < 8; }
void appendWarning(std::string& destination, const std::string& warning) {
    if (warning.empty()) return;
    if (!destination.empty()) destination += '\n';
    destination += warning;
}
std::set<std::uint32_t> styleEntryAddresses(const arranger::Pa5xStyleRead& read) {
    std::set<std::uint32_t> addresses;
    for(const auto& section:read.sections)if(section.available)
        for(const auto& track:section.tracks)for(const auto& cv:track.cvs)if(cv.available&&cv.hasNotes)
            for(const auto& change:cv.soundChanges){
                if(change.msb<0||change.msb>127||change.lsb<0||change.lsb>127||change.program<0||change.program>127)continue;
                addresses.insert((static_cast<std::uint32_t>(change.msb)<<16)|
                    (static_cast<std::uint32_t>(change.lsb)<<8)|static_cast<std::uint32_t>(change.program));
            }
    return addresses;
}
std::vector<sampler::ProgramPtr> styleEntryPrograms(const arranger::Pa5xStyleRead& read,
        const std::map<std::uint32_t,sampler::ProgramPtr>& programs){
    std::vector<sampler::ProgramPtr> entries;
    for(const auto address:styleEntryAddresses(read)){
        const auto found=programs.find(address);
        if(found!=programs.end()&&found->second)entries.push_back(found->second);
    }
    return entries;
}
arranger::ImportResult readStyle(const std::string& path) {
    const auto dot = path.find_last_of('.');
    std::string extension = dot == std::string::npos ? "" : path.substr(dot);
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if(arranger::paStyleSlot(path)){auto r=arranger::readPaStyleSlot(path,nullptr);return {r.nativeStyle,r.error,r.warnings};}
    return extension == ".stg" ? arranger::importKorgStyleFile(path) : arranger::importMidiFile(path);
}
std::string originalResourceFilePath(const std::string& path) {
    std::string physical;if(arranger::paKeyboardLocation(path,&physical))return physical;
    const auto marker=path.rfind("!/");
    if(marker!=std::string::npos&&marker>=4) {
        auto extension=path.substr(marker-4,4);
        std::transform(extension.begin(),extension.end(),extension.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
        if(extension==".stg"||extension==".sty")return path.substr(0,marker);
    }
    return path;
}
std::shared_ptr<const arranger::Pa5xSetBank> bankForPath(
    std::shared_ptr<const arranger::Pa5xSetBank> bank,const std::string& path){
    if(!bank)return {};
    const auto root=bank->status().rootPath;
    const auto originalPath=originalResourceFilePath(path);
    std::unique_ptr<char,decltype(&std::free)> canonical(::realpath(originalPath.c_str(),nullptr),&std::free);
    if(!canonical||root.empty())return {};
    const std::string prefix=root.back()=='/'?root:root+'/';
    const std::string file=canonical.get();
    return file.compare(0,prefix.size(),prefix)==0?bank:nullptr;
}
bool playableSampleProgram(const sampler::ProgramPtr& program) {
        if (!program) return false;
        for (const auto& layer : program->layers) {
            if (!layer.enabled || !layer.multisample || layer.keyLow>layer.keyHigh ||
                layer.velocityLow>layer.velocityHigh || layer.velocityHigh==0) continue;
            for (const auto& zone : layer.multisample->zones) {
                if (!zone.sample || !zone.sample->valid() || zone.keyLow>zone.keyHigh ||
                    zone.velocityLow>zone.velocityHigh ||
                    std::max<int>(layer.keyLow,zone.keyLow)>std::min<int>(layer.keyHigh,zone.keyHigh) ||
                    std::max<int>(1,std::max<int>(layer.velocityLow,zone.velocityLow))>
                        std::min<int>(layer.velocityHigh,zone.velocityHigh)) continue;
                if (zone.sample->preloadedFrameCount()>0 ||
                    (zone.sample->stream && zone.sample->stream->frameCount()>0)) return true;
            }
        }
        return false;
}
struct PersistentTrack {
    StyleSoundSettings soundSettings;
    int slot{0},binding{0},overrideMask{0};float db{0},pan{0};bool mute{false},seen{false};
    std::string programIdentity;
};
struct PersistentPlayer {
    StyleFxRack effects;bool fxSeen{false};
    std::string path,setRoot,savedStyleName,sourceIdentity;double bpm{120},savedStyleBpm{0};int element{3},savedStyleBank{0},savedStylePosition{0};
    bool autoFill{true},sampleMode{false},seen{false},sourceSeen{false};
    std::array<PersistentTrack,8> tracks;
};
struct PersistentSessionData {
    int version{21};
    std::array<PersistentPlayer,2> players;
    std::string catalogRoot;
    sampler::GlobalState tuning;
    int split{60},globalSplit{60},recognition{2},scanArea{1},autoFillMode{1},scaleAssignment{0};float crossfade{0};
    bool autoFill{true};
    bool syncStartAutoOff{true};float fadeInSeconds{5.0F},fadeOutSeconds{5.0F};
    bool memory{true},splitEnabled{true},bassInversion{false},damperLatch{false},tempoLock{false},scaleEnabled{true};
};
bool parsePersistentSession(const std::string& text,PersistentSessionData& result,std::string& error){
    const auto fail=[&](const char* reason){error=reason;return false;};
    if(text.empty()||text.size()>1024U*1024U)return fail("Invalid saved session size");
    const auto done=[](std::istringstream& row){row>>std::ws;return row.eof();};
    const auto flag=[](std::istringstream& row,bool& value){int raw=-1;if(!(row>>raw)||(raw!=0&&raw!=1))return false;value=raw!=0;return true;};
    const auto path=[](std::istringstream& row,std::string& value){row>>std::ws;return row.peek()=='"'&&(row>>std::quoted(value))&&
        value.size()<=32768U&&value.find_first_of("\r\n")==std::string::npos&&value.find('\0')==std::string::npos;};
    std::istringstream input(text);std::string line;
    if(!std::getline(input,line))return fail("Missing saved session header");
    std::istringstream header(line);std::string magic;int version=0;
    if(!(header>>magic>>version)||magic!="SILVETON_ARRANGER"||(version<4||version>21)||!done(header))return fail("Unsupported saved session version");
    result.version=version;
    bool globalSeen=false,tuningSeen=false,catalogSeen=false,liveSeen=false,legacyGuitarSeen=false;
    while(std::getline(input,line)){
        if(line.size()>65536U)return fail("Saved session record is too long");
        std::istringstream row(line);std::string kind;if(!(row>>kind))continue;
        if(kind=="GLOBAL"){
            auto& v=result;
            if(globalSeen||!(row>>v.split)||!flag(row,v.memory)||!(row>>v.crossfade>>v.recognition>>v.scanArea)||
                !flag(row,v.splitEnabled)||!flag(row,v.bassInversion)||!flag(row,v.damperLatch)||!flag(row,v.tempoLock)||
                (version>=7&&(!(row>>v.globalSplit)||!flag(row,v.autoFill)||!(row>>v.autoFillMode>>v.scaleAssignment)))||!done(row)||
                v.split<1||v.split>127||v.recognition<0||v.recognition>4||v.scanArea<0||v.scanArea>3||
                v.globalSplit<1||v.globalSplit>127||v.autoFillMode<0||v.autoFillMode>1||v.scaleAssignment<0||v.scaleAssignment>2||
                !std::isfinite(v.crossfade)||v.crossfade<0||v.crossfade>1)return fail("Invalid saved session chord controls");
            globalSeen=true;
        }else if(kind=="LIVE"){
            if(version<7||liveSeen||!flag(row,result.syncStartAutoOff)||!(row>>result.fadeInSeconds>>result.fadeOutSeconds)||!done(row)||
                !std::isfinite(result.fadeInSeconds)||!std::isfinite(result.fadeOutSeconds)||result.fadeInSeconds<0.1F||result.fadeInSeconds>60||
                result.fadeOutSeconds<0.1F||result.fadeOutSeconds>60)return fail("Invalid live arranger preferences");
            liveSeen=true;
        }else if(kind=="GUITAR_KEYS"){
            // Version 15 stored a global Upper 1 mode. Validate its legacy
            // record, but never restore it or convert it into a Style edit.
            int enabled=-1,base=-1,capo=-1,high=-1,low=-1,humanize=-1;
            int position=-1,followChord=-1,root=-1,chordType=-1;
            if(version!=15||legacyGuitarSeen||
                !(row>>enabled>>base>>capo>>high>>low>>humanize>>position>>followChord>>root>>chordType)||!done(row)||
                (enabled!=0&&enabled!=1)||(followChord!=0&&followChord!=1)||chordType<0||
                chordType>static_cast<int>(arranger::ChordType::RootFifth))return fail("Invalid saved legacy Guitar controls");
            if(base<0||base>104||capo<0||capo>12||high<1||high>6||low<high||low>6||
                humanize<0||humanize>127||position<0||position>5||root<0||root>11||
                arranger::chordPitchClassMask(static_cast<arranger::ChordType>(chordType))==0)
                return fail("Saved legacy Guitar controls exceed their supported ranges");
            legacyGuitarSeen=true;
        }else if(kind=="TUNING"){
            auto& v=result.tuning;int transpose=0,root=0;
            if(tuningSeen||!(row>>v.masterTuneHz>>transpose>>v.masterGainDb>>v.eqLowDb>>v.eqMidDb>>v.eqHighDb)||
                !flag(row,result.scaleEnabled)||!(row>>root)||!flag(row,v.limiterEnabled)||!(row>>v.limiterCeilingDb))return fail("Invalid saved tuning settings");
            if(!std::isfinite(v.masterTuneHz)||v.masterTuneHz<400||v.masterTuneHz>480||transpose< -127||transpose>127||
                !std::isfinite(v.masterGainDb)||v.masterGainDb< -96||v.masterGainDb>24||root<0||root>11||
                !std::isfinite(v.eqLowDb)||!std::isfinite(v.eqMidDb)||!std::isfinite(v.eqHighDb)||
                std::fabs(v.eqLowDb)>24||std::fabs(v.eqMidDb)>24||std::fabs(v.eqHighDb)>24||
                !std::isfinite(v.limiterCeilingDb)||v.limiterCeilingDb< -12||v.limiterCeilingDb>0)return fail("Saved tuning settings exceed their supported ranges");
            v.transposeSemitones=static_cast<std::int8_t>(transpose);v.scaleRoot=static_cast<std::uint8_t>(root);
            for(auto& cents:v.scaleOffsetsCents)if(!(row>>cents)||!std::isfinite(cents)||cents< -100||cents>100)return fail("Invalid saved scale offsets");
            if(!done(row))return fail("Unexpected saved tuning fields");
            tuningSeen=true;
        }else if(kind=="CATALOG"){
            if(catalogSeen||!path(row,result.catalogRoot)||!done(row))return fail("Invalid saved SET catalog path");
            catalogSeen=true;
        }else if(kind=="PLAYER"){
            int player=-1;bool savedSync=false;
            if(!(row>>player)||!playerOk(player))return fail("Invalid saved player index");
            auto& v=result.players[static_cast<std::size_t>(player)];
            if(v.seen||!path(row,v.path)||!(row>>v.bpm)||!flag(row,v.autoFill)||!flag(row,savedSync)||
                (version>=6&&(!(row>>v.savedStyleBank>>v.savedStylePosition)||!path(row,v.savedStyleName)||!path(row,v.sourceIdentity)||!(row>>v.savedStyleBpm)))||!done(row)||
                v.savedStyleBank<0||v.savedStyleBank>16||v.savedStylePosition<0||v.savedStylePosition>128||
                ((v.savedStyleBank==0)!=(v.savedStylePosition==0))||v.savedStyleName.size()>256U||
                (!v.sourceIdentity.empty()&&v.sourceIdentity.size()!=64U)||!std::isfinite(v.savedStyleBpm)||
                (v.savedStyleBpm!=0&&(v.savedStyleBpm<20||v.savedStyleBpm>400))||!std::isfinite(v.bpm)||v.bpm<20||v.bpm>400)return fail("Invalid saved player settings");
            // A prior file may carry a sync flag, but automatic restoration never arms it.
            v.seen=true;
        }else if(kind=="SOURCE"){
            int player=-1;if(!(row>>player)||!playerOk(player))return fail("Invalid saved source player");auto& v=result.players[static_cast<std::size_t>(player)];
            if(v.sourceSeen||!path(row,v.setRoot)||!flag(row,v.sampleMode)||!(row>>v.element)||v.element<0||
                v.element>=static_cast<int>(arranger::kElementCount)||!done(row))return fail("Invalid saved Style source");
            v.sourceSeen=true;
        }else if(kind=="FX"){
            int player=-1;if(version<8||!(row>>player)||!playerOk(player))return fail("Invalid saved FX player");
            auto& v=result.players[player];
            if(v.fxSeen||!readStyleFx(row,v.effects,version>=11,version>=12,version>=13,version>=14,version>=17,version>=18,version>=19,version>=20)||!done(row))return fail("Invalid saved Style FX");
            v.fxSeen=true;
        }else if(kind=="TRACK"){
            int player=-1,track=-1;if(!(row>>player>>track)||!trackOk(player,track))return fail("Invalid saved track index");
            auto& v=result.players[static_cast<std::size_t>(player)].tracks[static_cast<std::size_t>(track)];
            if(v.seen||!(row>>v.slot>>v.db>>v.pan)||!flag(row,v.mute)||!(row>>v.binding)||
                (version>=5&&!(row>>v.overrideMask))||(version>=6&&!path(row,v.programIdentity))||(version>=9&&(!readStyleSound(row,v.soundSettings,version>=10,version>=11)||(v.binding==3)!=(v.soundSettings.setAddress>=0)))||!done(row)||v.overrideMask<0||v.overrideMask>7||
                v.slot<0||v.slot>500||v.binding<0||v.binding>(version>=9?3:2)||!std::isfinite(v.db)||!std::isfinite(v.pan)||
                v.db< -60||v.db>12||v.pan< -1||v.pan>1||(v.binding==2&&v.slot==0)||(v.binding!=2&&v.slot!=0)||(version>=6&&((v.binding==2&&v.programIdentity.size()!=64U)||(v.binding!=2&&!v.programIdentity.empty()))))return fail("Invalid saved track binding");
            // v4 did not distinguish an inherited false/default mute from an
            // explicit unmute. Preserve non-neutral trims and explicit true
            // mutes; undeclared false falls back to the original Style mute.
            if(version==4)v.overrideMask=(v.db!=0?static_cast<int>(kMixVolume):0)|(v.pan!=0?static_cast<int>(kMixPan):0)|(v.mute?static_cast<int>(kMixMute):0);
            v.seen=true;
        }else return fail("Unknown saved session record");
    }
    if(!input.eof()||!globalSeen||!tuningSeen||!catalogSeen)return fail("Incomplete saved session");
    if(version==15&&!legacyGuitarSeen)return fail("Saved version 15 session is missing legacy Guitar controls");
    for(const auto& v:result.players){
        if(!v.seen||!v.sourceSeen||(version>=8&&!v.fxSeen))return fail("Saved session is missing a player/source");
        for(const auto& track:v.tracks)if(!track.seen||(track.binding==3&&v.setRoot.empty())||(track.binding==1&&(!v.sampleMode||v.path.empty()||v.setRoot.empty())))
            return fail("Saved session has an incomplete native sample source");
        if(v.path.empty()&&(!v.setRoot.empty()||v.savedStyleBank!=0||!v.savedStyleName.empty()||!v.sourceIdentity.empty()||v.savedStyleBpm!=0))return fail("Saved empty player has Style source metadata");
    }
    if(result.tempoLock&&result.players[0].bpm!=result.players[1].bpm)return fail("Saved Tempo Lock tempos disagree");
    if(version<7){
        result.globalSplit=result.split;
        result.autoFill=result.players[result.crossfade<0.5F?0U:1U].autoFill;
    }
    for(auto& player:result.players)player.autoFill=result.autoFill;
    return true;
}

std::string canonicalRestoreRoot(const std::string& root){
    if(root.empty())return {};
    std::unique_ptr<char,decltype(&std::free)> canonical(::realpath(root.c_str(),nullptr),&std::free);
    return canonical?std::string(canonical.get()):root;
}
std::vector<std::string> persistentRoots(const PersistentSessionData& session){
    std::vector<std::string> roots;
    for(const auto& player:session.players){const auto root=canonicalRestoreRoot(player.setRoot);
        if(!root.empty()&&std::find(roots.begin(),roots.end(),root)==roots.end())roots.push_back(root);}
    const auto catalogRoot=canonicalRestoreRoot(session.catalogRoot);
    if(!catalogRoot.empty()){
        roots.erase(std::remove(roots.begin(),roots.end(),catalogRoot),roots.end());roots.push_back(catalogRoot);
    }
    return roots;
}
const char* originalStatus(arranger::KstResolution status){
    switch(status){
        case arranger::KstResolution::ExactUserSound:return "Original User Sound found";
        case arranger::KstResolution::FactorySoundRequired:return "Original Factory Sound";
        case arranger::KstResolution::MissingUserSound:return "Original User Sound missing";
        case arranger::KstResolution::AmbiguousSound:return "Conflicting original Sound definitions";
        case arranger::KstResolution::UnsupportedSoundAddress:return "Original Sound address unresolved";
    }
    return "Original Sound address unresolved";
}
}

struct ArrangerHost::Impl final : arranger::RenderCallbacks {
    arranger::ArrangerEngine engine;
    std::array<sampler::SamplerEngine, 2> synth;
    sampler::SamplerEngine previewSynth;
    std::shared_ptr<sampler::EngineState> previewState;
    sampler::ProgramPtr previewProgram;
    std::atomic<bool> drumKitMidiAudition{false};
    PcmPreviewView previewView;
    sampler::SampleStreamPrefetcher prefetch0{synth[0]};
    sampler::SampleStreamPrefetcher prefetch1{synth[1]};
    std::array<std::shared_ptr<sampler::EngineState>, 2> state;
    std::array<std::array<ArrangerTrackView, 8>, 2> tracks;
    std::array<std::string, 2> paths;
    std::array<std::shared_ptr<const arranger::Style>, 2> styles;
    std::shared_ptr<const arranger::Pa5xSetBank> korgSetBank;
    struct PreparedSetSamples {
        std::shared_ptr<const arranger::Pa5xSetBank> bank;
        std::map<std::uint32_t,sampler::ProgramPtr> programs,originalKits;
        std::vector<std::string> warnings;
    };
    std::atomic<int> editorNote{-1};
    std::shared_ptr<const PreparedSetSamples> preparedSetSamples;
    // Bounded warm-restore pool, never a growing cache of full SETs.
    std::vector<std::shared_ptr<const PreparedSetSamples>> restoreSampleBanks;
    std::vector<std::string> expectedRestoreRoots;
    bool restoreCollecting{false},restoreKeyboardLease{false};
    void rememberPreparedSet(const std::shared_ptr<const PreparedSetSamples>& value){
        if(!restoreCollecting||!value)return;
        const auto root=value->bank->status().rootPath;
        if(std::find(expectedRestoreRoots.begin(),expectedRestoreRoots.end(),root)==expectedRestoreRoots.end())return;
        restoreSampleBanks.erase(std::remove_if(restoreSampleBanks.begin(),restoreSampleBanks.end(),[&](const auto& old){
            return old->bank->status().rootPath==root;
        }),restoreSampleBanks.end());
        restoreSampleBanks.push_back(value);if(restoreSampleBanks.size()>10U)restoreSampleBanks.erase(restoreSampleBanks.begin());
    }
    detail::Pa5xStyleReadCache styleReadCache; // bounded metadata/inspection working set
    std::array<std::shared_ptr<const arranger::Pa5xSetBank>,2> styleBanks;
    std::array<std::shared_ptr<const arranger::Pa5xStyleRead>,2> styleReads;
    std::shared_ptr<const arranger::Pa5xKeyboardSetRead> keyboardRead;
    struct OriginalAddress {
        int msb{-1}, lsb{-1}, program{-1};
        bool complete() const noexcept { return msb >= 0 && msb <= 127 && lsb >= 0 && lsb <= 127 && program >= 0 && program <= 127; }
        std::uint32_t key() const noexcept { return (static_cast<std::uint32_t>(msb) << 16) | (static_cast<std::uint32_t>(lsb) << 8) | static_cast<std::uint32_t>(program); }
    };
    struct KeyboardProgramProvenance {
        std::string root;
        OriginalAddress address;
        sampler::ProgramPtr sound;
    };
    std::array<KeyboardProgramProvenance,7> keyboardPrograms;
    // Caller holds control. Queries never grow or refresh this provenance cache.
    KeyboardProgramProvenance keyboardProgramFor(const OriginalAddress& address,
                                                 const std::string& sourcePath) const {
        const auto originalPath=originalResourceFilePath(sourcePath);
        std::unique_ptr<char,decltype(&std::free)> canonical(
            originalPath.empty()?nullptr: ::realpath(originalPath.c_str(),nullptr),&std::free);
        const bool explicitRoot=canonical&&arranger::canSelectPa5xKstDirectory(canonical.get());
        const auto matchesRoot=[&](const std::string& root){
            if(sourcePath.empty())return true;
            if(canonical){
                const std::string normalized=canonical.get();
                if(explicitRoot)return normalized==root;
                const std::string prefix=root.empty()||root.back()=='/'?root:root+'/';
                return normalized==root||(!prefix.empty()&&normalized.compare(0,prefix.size(),prefix)==0);
            }
            // An already selected Program still has valid provenance if its
            // original drive becomes unavailable. Only the exact retained
            // canonical root is accepted in that case, never an inferred path.
            return sourcePath==root;
        };
        std::shared_ptr<const PreparedSetSamples> selected;
        if(preparedSetSamples&&preparedSetSamples->bank&&matchesRoot(preparedSetSamples->bank->status().rootPath))
            selected=preparedSetSamples;
        else for(auto it=restoreSampleBanks.rbegin();it!=restoreSampleBanks.rend();++it)
            if(*it&&(*it)->bank&&matchesRoot((*it)->bank->status().rootPath)){selected=*it;break;}
        if(selected){
            const auto found=selected->programs.find(address.key());
            if(found!=selected->programs.end()&&playableSampleProgram(found->second))
                return {selected->bank->status().rootPath,address,found->second};
        }
        for(const auto& retained:keyboardPrograms){
            if(!retained.sound||!retained.address.complete()||retained.address.key()!=address.key())continue;
            if(sourcePath.empty()){
                if(!selected||retained.root!=selected->bank->status().rootPath)continue;
            }else if(!matchesRoot(retained.root))continue;
            return retained;
        }
        return {};
    }
    struct OriginalMidiState {
        struct Channel { int pendingMsb{-1}, pendingLsb{-1}; OriginalAddress active; };
        std::array<Channel,16> channels;
        int activeChannel{-1};
    };
    using ProgramMap=std::map<std::uint32_t,sampler::ProgramPtr>;
    using RequiredPrograms=std::array<std::set<std::uint32_t>,8>;
    struct StyleContext;
    struct RoutingPlan {
        const arranger::Style* style{nullptr};
        std::shared_ptr<const arranger::Style> styleOwner;
        std::shared_ptr<const arranger::Pa5xStyleRead> read;
        std::shared_ptr<const arranger::Pa5xSetBank> setBank;
        std::string path,warnings,sourceEditIdentity,savedStyleName;
        int savedStyleBank{0},savedStylePosition{0};double savedStyleBpm{0};
        std::array<std::string,8> fixedSoundIdentities;
        ProgramMap programs;
        RequiredPrograms required;
        std::array<ArrangerTrackView,8> views;
        std::shared_ptr<const sampler::EngineState> baseState;
        std::shared_ptr<const sampler::PreparedSamplerState> prepared;
        StyleContext* context{nullptr};

        PhraseRangeBank ranges;
        GuitarOverrideBank guitars;
        std::array<int,5> fillModes{};
        std::uint64_t revision{0},noteMapRevision{0};
        std::uint8_t trackMask{0};
        unsigned scaleMask{0};
        bool sampleMode{false};
    };
    struct StyleContext {
        int player{0};std::uint64_t serial{0};
        std::array<std::atomic<unsigned>,arranger::kElementCount*arranger::kTracks> ranges{};
        std::array<std::atomic<unsigned>,arranger::kTracks> wraps{};
        std::array<std::atomic<unsigned>,arranger::kElementCount*arranger::kTracks> guitars{};
        void loadRanges(const PhraseRangeBank& bank) noexcept {
            for(std::size_t i=0;i<ranges.size();++i)ranges[i].store(bank.sections[i],std::memory_order_relaxed);
            for(std::size_t i=0;i<wraps.size();++i)wraps[i].store(bank.wraps[i],std::memory_order_relaxed);
        }
        PhraseRangeBank readRanges() const noexcept {
            PhraseRangeBank bank;
            for(std::size_t i=0;i<ranges.size();++i)bank.sections[i]=ranges[i].load(std::memory_order_relaxed);
            for(std::size_t i=0;i<wraps.size();++i)bank.wraps[i]=wraps[i].load(std::memory_order_relaxed);
            return bank;
        }
        void loadGuitars(const GuitarOverrideBank& bank) noexcept {
            for(std::size_t i=0;i<guitars.size();++i)guitars[i].store(bank.sections[i],std::memory_order_relaxed);
        }
        GuitarOverrideBank readGuitars() const noexcept {
            GuitarOverrideBank bank;
            for(std::size_t i=0;i<guitars.size();++i)bank.sections[i]=guitars[i].load(std::memory_order_relaxed);
            return bank;
        }
        std::atomic<unsigned> fillModes{0}; // five four-bit modes, read once per manual fill
        std::array<int,5> readFillModes() const noexcept {
            const unsigned value=fillModes.load(std::memory_order_acquire);
            std::array<int,5> result{};
            for(int i=0;i<5;++i)result[i]=int((value>>(4*i))&15U);
            return result;
        }
        std::atomic<std::uint64_t> hitStart{0};
        bool savedOptions{false},savedAutoFill{true};int savedElement{3};
        ArrangerStyleKeyboardLinks keyboardSets;
        std::atomic<const RoutingPlan*> latest{nullptr},initial{nullptr};
    };
    std::array<std::map<std::uint32_t,sampler::ProgramPtr>,2> originalPrograms;
    std::array<std::array<std::set<std::uint32_t>,8>,2> requiredOriginalPrograms;
    std::array<std::uint8_t,2> originalRoutingMask{};
    std::array<bool,2> samplePlaybackMode{};
    std::array<std::string,2> samplePlaybackWarnings;
    // The context identity outlives audio. Superseded full plans are reclaimed
    // only on control, after latest/initial/active/hazard references release.
    std::vector<std::unique_ptr<RoutingPlan>> retainedRoutingPlans;
    std::vector<std::unique_ptr<StyleContext>> retainedStyleContexts;
    std::array<StyleContext*,2> controlContexts{},stagedContexts{},audioContexts{};
    std::array<StyleContext*,2> persistentRestoreContexts{};
    std::string pendingRestoredText;
    std::unique_ptr<PersistentSessionData> pendingRestoreIntent;
    std::uint32_t lastKeyboardRecallSerial{0}; // control mutex; advances only on accepted queue writes
    std::atomic<int> globalSplit{60}; // persistent template; local Keyboard Sets never replace it
    std::array<const RoutingPlan*,2> controlAckPlans{};
    std::array<std::atomic<StyleContext*>,2> publishedControlContexts{};
    std::array<std::atomic<const RoutingPlan*>,2> audioActivePlans{},audioPlanHazards{};
    std::uint64_t hitFrame{1}; // audio thread only
    std::atomic<std::uint64_t> publishedHitFrame{0};
    std::array<std::array<std::atomic<std::uint64_t>,8>,2> lastTrackHit{};
    std::array<std::array<std::array<std::atomic<std::uint64_t>,128>,2>,2> lastDrumHit{};
    std::array<bool,2> audioRouteReady{{false,false}};
    std::uint64_t nextContextSerial{1};
    std::array<const arranger::Style*,2> audioSourceStyles{};
    std::array<std::array<OriginalMidiState,8>,2> originalMidi;
    struct SourceMix {
        std::atomic<int> volume{-1},pan{-1},expression{-1};
        std::array<std::atomic<int>,3> sends{{-1,-1,-1}};
        std::array<std::atomic<int>,8> soundEditValues{{-1,-1,-1,-1,-1,-1,-1,-1}};
        std::atomic<int> portamentoTime{-1},portamentoOn{-1};
        sampler::SourceSoundEdits soundEdits; // audio-thread writer only
        sampler::SourceSoundEditReader soundEditReader; // same ordered stream as playback
        void resetSoundEdits() noexcept {
            soundEdits={};soundEditReader={};
            for(auto& raw:soundEditValues)raw.store(-1,std::memory_order_relaxed);
            portamentoTime.store(-1,std::memory_order_relaxed);portamentoOn.store(-1,std::memory_order_relaxed);
        }
        void observeSoundEdit(int cc,int value) noexcept {
            if(!soundEditReader.controller(soundEdits,cc,value))return;
            for(std::size_t i=0;i<soundEditValues.size();++i)
                soundEditValues[i].store(soundEdits.raw[i],std::memory_order_relaxed);
            portamentoTime.store(soundEdits.portamentoTimeRaw,std::memory_order_relaxed);
            portamentoOn.store(soundEdits.portamentoOnRaw,std::memory_order_relaxed);
        }
        sampler::SourceSoundEdits readSoundEdits() const noexcept {
            sampler::SourceSoundEdits result;
            for(std::size_t i=0;i<soundEditValues.size();++i)
                result.raw[i]=static_cast<std::int16_t>(soundEditValues[i].load(std::memory_order_relaxed));
            result.portamentoTimeRaw=static_cast<std::int16_t>(portamentoTime.load(std::memory_order_relaxed));
            result.portamentoOnRaw=static_cast<std::int16_t>(portamentoOn.load(std::memory_order_relaxed));
            return result;
        }
    };
    std::array<std::array<SourceMix,8>,2> sourceMix;
    std::array<std::atomic<const StyleContext*>,2> sourceMixContext{};
    std::uint64_t nextRoutingRevision{1}; // control thread, never reused
    std::array<bool,2> savedSyncStartPending{}; // control thread, waits for saved Sound restoration
    mutable std::mutex control;
    std::string error;
    std::atomic<std::uint64_t> persistentRevision{1};
    std::array<bool,2> persistedTransportSeen{};
    std::string styleEditStorage;
    std::array<std::string,2> sourceEditIdentities,savedStyleNames;
    std::array<int,2> savedStyleBanks{},savedStylePositions{};
    std::array<double,2> savedStyleBpms{};
    std::array<std::array<std::string,8>,2> fixedSoundIdentities;
    std::array<double,2> persistedTempo{};
    std::array<int,2> persistedElement{};
    std::atomic<int> listenSoloWord{0};
    std::atomic<float> xfade{0.0F};
    std::atomic<bool> panicPending{false};
    std::atomic<std::uint16_t> externalChannels{0xFFFFU};
    std::atomic<bool> externalNotesFiltered{false};
    // One publication keeps the selected controller, polarity and CC filter
    // coherent for the realtime MIDI observer. Bits 0..6 hold the controller.
    std::atomic<std::uint16_t> externalDamperConfig{64U};
    std::atomic<bool> limiterEnabled{false};
    std::atomic<float> limiterCeiling{0.501187F};
    std::atomic<float> outputPeakL{0.0F}, outputPeakR{0.0F}, reductionDb{0.0F}, cpuPercent{0.0F};
    float limiterGain{1.0F};
    std::array<float, kMaximumFrames * 2> scratch{};
    std::array<float, 2> currentGain{{1.0F, 0.0F}};
    float* destination{nullptr};
    double rate{96000.0};
    bool prepared{false};
    bool scaleEnabled{true};
    int scaleAssignment{0};
    std::uint32_t blockFrames{96};

    bool restoreAcknowledged(const std::array<arranger::PlayerSnapshot,2>& audio) const {
        if(pendingRestoredText.empty())return true;
        const auto* saved=pendingRestoreIntent.get();if(!saved)return false;
        if(engine.splitNote()!=saved->split||engine.memory()!=saved->memory||engine.recognitionMode()!=saved->recognition||engine.chordScanArea()!=saved->scanArea||
           engine.splitEnabled()!=saved->splitEnabled||engine.bassInversion()!=saved->bassInversion||engine.damperLatch()!=saved->damperLatch||
           engine.tempoLock()!=saved->tempoLock||engine.autoFillMode()!=saved->autoFillMode||engine.syncStartAutoOff()!=saved->syncStartAutoOff||
           std::fabs(engine.fadeInSeconds()-saved->fadeInSeconds)>0.00001F||
           std::fabs(engine.fadeOutSeconds()-static_cast<float>(std::lround(saved->fadeOutSeconds*1000.0F))/1000.0F)>0.00001F)return false;
        for(int player=0;player<2;++player){const auto& view=audio[player];const auto* expected=persistentRestoreContexts[player];
            const auto* plan=expected?expected->latest.load(std::memory_order_seq_cst):nullptr;if(!plan)return false;
            const double tempo=saved->players[saved->tempoLock?1:player].bpm;
            unsigned mutes=0;for(std::size_t track=0;track<plan->views.size();++track)if(plan->views[track].mute)mutes|=1U<<track;
            if(view.playing||view.syncStart||view.syncStop||view.autoFill!=saved->autoFill||view.loopElement!=arranger::Element::Count||view.fadeDirection!=0||
               std::fabs(view.fadeGain-1.0F)>0.00001F||std::fabs(view.tempoBpm-tempo)>0.000001||view.muteMask!=mutes)return false;
            if(!plan->style&&view.style==nullptr)continue;
            const auto* active=static_cast<const StyleContext*>(view.styleCommitToken);
            if(!active){const auto* current=audioActivePlans[player].load(std::memory_order_seq_cst);if(current&&current->style==view.style)active=current->context;}
            if(active!=expected)return false;
        }
        return true;
    }

    Impl() {
        previewState = std::make_shared<sampler::EngineState>();
        for (int t = 0; t < sampler::kPartCount; ++t) previewState->combi.part(t).enabled = false;
        previewState->global.masterGainDb = 0.0F;
        previewSynth.setState(previewState);
        for (int p = 0; p < 2; ++p) {
            state[p] = std::make_shared<sampler::EngineState>();
            for (int t = 0; t < sampler::kPartCount; ++t) state[p]->combi.part(t).enabled = false;
            for (int t = 0; t < 8; ++t) {
                tracks[p][t].name = kTrackNames[t];
                auto& part = state[p]->combi.part(t);
                part.name = kTrackNames[t];
                part.midiChannel = static_cast<std::uint8_t>(t);
                part.breathEnabled = false;
                part.expressionEnabled = true;
                part.aftertouchEnabled = false;
                part.damperEnabled = true;
            }
            synth[p].setState(state[p]);
            synth[p].setChannelMixEnabled(true);
            // A Style uses the sampler's available voice pool. Do not apply
            // a separate per-Player polyphony cap here.
            synth[p].setScaleUppers(0xFC);
        }
    }
    bool command(arranger::CommandType type, int p = 0, int index = 0, double value = 0.0,const arranger::Style* sourceStyle=nullptr) {
        if (!playerOk(p)) return false;
        std::lock_guard<std::mutex> lock(control);
        return commandLocked(type,p,index,value,sourceStyle);
    }
    bool commandLocked(arranger::CommandType type,int p,int index,double value,const arranger::Style* sourceStyle=nullptr,int data2=0){
        const bool ok=engine.post({type,p,index,value,data2,sourceStyle});
        if(!ok){error="Arranger command queue full";return false;}
        switch(type){
            case arranger::CommandType::SetTempo:case arranger::CommandType::StartWithTempo:case arranger::CommandType::SetTempoLock:
            case arranger::CommandType::ToggleTempoLock:case arranger::CommandType::ToggleAutoFill:case arranger::CommandType::ToggleMemory:
            case arranger::CommandType::ToggleChordSplit:case arranger::CommandType::ToggleBassInversion:case arranger::CommandType::ToggleDamperLatch:
            case arranger::CommandType::SetAutoFillMode:
            case arranger::CommandType::SetSyncStartAutoOff:case arranger::CommandType::SetFadeTimes:
            case arranger::CommandType::CycleAutoFillMode:case arranger::CommandType::ToggleSyncStartAutoOff:case arranger::CommandType::AdjustFadeTimes:
            case arranger::CommandType::SelectElement:case arranger::CommandType::SetAutoFill:
            case arranger::CommandType::SetMemory:case arranger::CommandType::SetSplit:case arranger::CommandType::SetKeyboardSplit:
            case arranger::CommandType::ApplyKeyboardRecall:
            case arranger::CommandType::SetChordRecognition:case arranger::CommandType::SetChordScanArea:case arranger::CommandType::ToggleChordScanAreaBit:
            case arranger::CommandType::SetChordScanZone:
            case arranger::CommandType::SetSplitEnabled:case arranger::CommandType::SetBassInversion:
            case arranger::CommandType::SetDamperLatch:case arranger::CommandType::SetTrackMute:
                persistentRevision.fetch_add(1,std::memory_order_relaxed);break;
            default:break;
        }
        if(pendingRestoreIntent){
            auto& intent=*pendingRestoreIntent;auto& player=intent.players[static_cast<std::size_t>(p)];
            switch(type){
                case arranger::CommandType::SetTempo:case arranger::CommandType::StartWithTempo:
                    if(intent.tempoLock)for(auto& target:intent.players)target.bpm=value;else player.bpm=value;break;
                case arranger::CommandType::SetTempoLock:case arranger::CommandType::ToggleTempoLock:
                    intent.tempoLock=type==arranger::CommandType::ToggleTempoLock?!intent.tempoLock:value!=0;
                    if(intent.tempoLock)for(auto& target:intent.players)target.bpm=player.bpm;
                    break;
                case arranger::CommandType::SelectElement:player.element=index;break;
                case arranger::CommandType::SetAutoFill:case arranger::CommandType::ToggleAutoFill:
                    intent.autoFill=type==arranger::CommandType::ToggleAutoFill?!intent.autoFill:value!=0;
                    for(auto& target:intent.players)target.autoFill=intent.autoFill;
                    break;
                case arranger::CommandType::SetAutoFillMode:case arranger::CommandType::CycleAutoFillMode:
                    intent.autoFillMode=type==arranger::CommandType::CycleAutoFillMode?(intent.autoFillMode==0?1:0):static_cast<int>(value);break;
                case arranger::CommandType::SetSyncStartAutoOff:case arranger::CommandType::ToggleSyncStartAutoOff:
                    intent.syncStartAutoOff=type==arranger::CommandType::ToggleSyncStartAutoOff?!intent.syncStartAutoOff:value!=0;break;
                case arranger::CommandType::SetFadeTimes:intent.fadeInSeconds=static_cast<float>(value);intent.fadeOutSeconds=static_cast<float>(index)/1000.0F;break;
                case arranger::CommandType::AdjustFadeTimes:
                    intent.fadeInSeconds=std::clamp(intent.fadeInSeconds+static_cast<float>(value),0.1F,60.0F);
                    intent.fadeOutSeconds=std::clamp(intent.fadeOutSeconds+static_cast<float>(index)/1000.0F,0.1F,60.0F);break;
                case arranger::CommandType::SetMemory:case arranger::CommandType::ToggleMemory:
                    intent.memory=type==arranger::CommandType::ToggleMemory?!intent.memory:value!=0;break;
                case arranger::CommandType::SetSplit:intent.split=static_cast<int>(value);break;
                case arranger::CommandType::SetKeyboardSplit:intent.split=static_cast<int>(value);intent.splitEnabled=index!=0;break;
                case arranger::CommandType::ApplyKeyboardRecall:
                    intent.split=static_cast<int>(value);intent.splitEnabled=(index&1)!=0;
                    if((index&2)!=0)intent.scanArea=(index>>2)&3;
                    if((index&16)!=0)intent.bassInversion=(index&32)!=0;
                    break;
                case arranger::CommandType::SetChordRecognition:intent.recognition=static_cast<int>(value);break;
                case arranger::CommandType::SetChordScanArea:intent.scanArea=static_cast<int>(value);break;
                case arranger::CommandType::ToggleChordScanAreaBit:intent.scanArea^=index;break;
                case arranger::CommandType::SetChordScanZone:intent.scanArea=static_cast<int>(value);intent.splitEnabled=true;break;
                case arranger::CommandType::SetSplitEnabled:case arranger::CommandType::ToggleChordSplit:
                    intent.splitEnabled=type==arranger::CommandType::ToggleChordSplit?!intent.splitEnabled:value!=0;break;
                case arranger::CommandType::SetBassInversion:case arranger::CommandType::ToggleBassInversion:
                    intent.bassInversion=type==arranger::CommandType::ToggleBassInversion?!intent.bassInversion:value!=0;break;
                case arranger::CommandType::SetDamperLatch:case arranger::CommandType::ToggleDamperLatch:
                    intent.damperLatch=type==arranger::CommandType::ToggleDamperLatch?!intent.damperLatch:value!=0;break;
                default:break;
            }
            if(!intent.splitEnabled&&intent.recognition==0)intent.recognition=3;
        }
        return true;
    }
    StyleContext* newContext(int player){
        auto context=std::make_unique<StyleContext>();context->player=player;context->serial=nextContextSerial++;
        auto* result=context.get();retainedStyleContexts.push_back(std::move(context));return result;
    }
    void collectPlans(){
        retainedRoutingPlans.erase(std::remove_if(retainedRoutingPlans.begin(),retainedRoutingPlans.end(),[&](const auto& item){
            const auto* plan=item.get();
            for(int p=0;p<2;++p)if(plan==audioActivePlans[p].load(std::memory_order_seq_cst)||
                plan==audioPlanHazards[p].load(std::memory_order_seq_cst)||plan==controlAckPlans[p])return false;
            for(const auto& context:retainedStyleContexts)if(plan==context->latest.load(std::memory_order_seq_cst)||
                plan==context->initial.load(std::memory_order_seq_cst))return false;
            return true;
        }),retainedRoutingPlans.end());
    }
    unsigned setRoles(const arranger::Style* style,sampler::EngineState& value) const {
        unsigned mask=0;
        for(int track=0;track<8;++track){
            const bool drums=style&&(style->tracks[track].role==arranger::TrackRole::Drums||style->tracks[track].role==arranger::TrackRole::Percussion);
            if(drums)value.combi.part(track).transposeSemitones-=value.global.transposeSemitones;
            if(!drums&&scaleEnabled&&scaleAssignment==2)mask|=1U<<track;
        }
        return mask;
    }
    const RoutingPlan* retainPlan(int player,std::unique_ptr<RoutingPlan> plan,StyleContext* context){
        if(!context)context=newContext(player);
        if(plan->sourceEditIdentity.empty()&&plan->styleOwner&&!plan->path.empty())
            plan->sourceEditIdentity=styleEditIdentity(plan->path,*plan->styleOwner);
        plan->context=context;plan->style=plan->styleOwner.get();plan->revision=nextRoutingRevision++;
        const auto* previous=context->latest.load(std::memory_order_acquire);
        bool sameSources=previous&&previous->style==plan->style&&previous->trackMask==plan->trackMask&&
            previous->programs==plan->programs&&previous->required==plan->required;
        for(int t=0;sameSources&&t<8;++t)
            sameSources=previous->baseState->combi.part(t).program==plan->baseState->combi.part(t).program;
        plan->noteMapRevision=sameSources?previous->noteMapRevision:plan->revision;
        const auto& base=plan->baseState;
        auto rendered=std::make_shared<sampler::EngineState>(*base);
        plan->scaleMask=setRoles(plan->style,*rendered);
        unsigned packed=0;
        for(int i=0;i<5;++i)packed|=static_cast<unsigned>(plan->fillModes[i])<<(4*i);
        rendered->combiGeneration=context->serial;
        for(int track=0;track<8;++track){
            const auto& setting=plan->views[track].soundSettings;
            auto& part=rendered->combi.part(track);
            part.livePartMix=true;part.mute=plan->views[track].mute;
            part.liveGate=setting.trigger;
            if(previous&&previous->views[track].soundSettings.tones==setting.tones&&previous->views[track].soundSettings.keyDb==setting.keyDb)
                part.liveDrumKeys=previous->prepared->state->combi.part(track).liveDrumKeys;
            else part.liveDrumKeys=liveDrumKeys(setting);
        }
        auto bank=std::make_shared<sampler::RealtimeProgramBank>();bank->revision=plan->revision;bank->sourceIdentity=context;
        for(int track=0;track<8;++track){
            if((plan->trackMask&(1U<<track))==0)continue;
            for(const auto address:plan->required[track]){
                const auto found=plan->programs.find(address);if(found==plan->programs.end()||!found->second)continue;
                auto routed=std::make_shared<sampler::EngineState>(*rendered);auto& part=routed->combi.part(track);
                part.program=found->second;part.enabled=true;part.soundSlotId=0;part.name=found->second->name;
                bank->routes.push_back({static_cast<std::uint8_t>(track),static_cast<std::uint8_t>((address>>16)&127U),
                    static_cast<std::uint8_t>((address>>8)&127U),static_cast<std::uint8_t>(address&127U),std::move(routed)});
            }
        }
        auto samplerState=std::make_shared<sampler::PreparedSamplerState>();samplerState->state=std::move(rendered);samplerState->bank=std::move(bank);
        if(!synth[player].registerPreparedState(samplerState)){error="The prepared Style sound/state graph is invalid";return nullptr;}
        plan->prepared=std::move(samplerState);const auto* result=plan.get();retainedRoutingPlans.push_back(std::move(plan));
        if(!context->initial.load(std::memory_order_seq_cst))context->initial.store(result,std::memory_order_seq_cst);
        if(!previous){context->fillModes.store(packed,std::memory_order_release);context->loadRanges(result->ranges);context->loadGuitars(result->guitars);}
        context->latest.store(result,std::memory_order_seq_cst);return result;
    }
    void adoptControlPlan(int player,const RoutingPlan* plan){
        if(!plan)return;
        styles[player]=plan->styleOwner;styleReads[player]=plan->read;styleBanks[player]=plan->setBank;paths[player]=plan->path;
        sourceEditIdentities[player]=plan->sourceEditIdentity;savedStyleNames[player]=plan->savedStyleName;
        savedStyleBpms[player]=plan->savedStyleBpm;fixedSoundIdentities[player]=plan->fixedSoundIdentities;savedStyleBanks[player]=plan->savedStyleBank;savedStylePositions[player]=plan->savedStylePosition;
        originalPrograms[player]=plan->programs;requiredOriginalPrograms[player]=plan->required;originalRoutingMask[player]=plan->trackMask;
        samplePlaybackMode[player]=plan->sampleMode;samplePlaybackWarnings[player]=plan->warnings;tracks[player]=plan->views;
        state[player]=std::make_shared<sampler::EngineState>(*plan->baseState);controlContexts[player]=plan->context;
        controlAckPlans[player]=plan;publishedControlContexts[player].store(plan->context,std::memory_order_release);
    }
    arranger::PlayerSnapshot synchronizeCommitted(int player){
        const auto view=engine.snapshot(player);auto* active=static_cast<StyleContext*>(const_cast<void*>(view.styleCommitToken));
        if(!active){const auto* audio=audioActivePlans[player].load(std::memory_order_seq_cst);if(audio&&audio->style==view.style)active=audio->context;}
        auto* staged=stagedContexts[player];
        if(staged&&!view.playing&&active!=staged){
            if(controlContexts[player]!=staged)adoptControlPlan(player,staged->latest.load(std::memory_order_seq_cst));
            return view;
        }
        if(active&&active->player==player){
            const auto* plan=active->latest.load(std::memory_order_seq_cst);
            if(plan&&controlAckPlans[player]!=plan)adoptControlPlan(player,plan);
            if(staged==active)stagedContexts[player]=nullptr;
            for(const auto& context:retainedStyleContexts)if(context->player==player&&context->serial<active->serial){
                if(context.get()==stagedContexts[player])continue;
                context->latest.store(nullptr,std::memory_order_seq_cst);context->initial.store(nullptr,std::memory_order_seq_cst);
            }
        }
        collectPlans();return view;
    }
    std::unique_ptr<RoutingPlan> currentPlan(int player){
        auto plan=std::make_unique<RoutingPlan>();plan->styleOwner=styles[player];plan->read=styleReads[player];
        plan->setBank=styleBanks[player];plan->path=paths[player];plan->warnings=samplePlaybackWarnings[player];
        plan->sourceEditIdentity=sourceEditIdentities[player];plan->savedStyleName=savedStyleNames[player];
        plan->savedStyleBpm=savedStyleBpms[player];plan->fixedSoundIdentities=fixedSoundIdentities[player];plan->savedStyleBank=savedStyleBanks[player];plan->savedStylePosition=savedStylePositions[player];
        plan->programs=originalPrograms[player];plan->required=requiredOriginalPrograms[player];plan->trackMask=originalRoutingMask[player];
        if(controlAckPlans[player])plan->fillModes=controlAckPlans[player]->fillModes;
        plan->sampleMode=samplePlaybackMode[player];plan->views=tracks[player];plan->baseState=state[player];return plan;
    }
    void refreshPendingMix(int player,int changedTrack=-1,unsigned changedFields=0){
        auto* pending=stagedContexts[player];if(!pending||pending==controlContexts[player])return;
        const auto* old=pending->latest.load(std::memory_order_seq_cst);if(!old)return;
        auto next=std::make_unique<RoutingPlan>(*old);auto base=std::make_shared<sampler::EngineState>(*old->baseState);
        base->global=state[player]->global;
        // Untouched trims belong to the newly selected Style, not the old
        // player's mixer. Only an explicit later edit crosses the queued handoff.
        if(changedTrack>=0&&changedTrack<8){
            const auto track=static_cast<std::size_t>(changedTrack);const auto& source=state[player]->combi.part(changedTrack);auto& target=base->combi.part(changedTrack);
            if((changedFields&kMixVolume)!=0){target.levelDb=source.levelDb;next->views[track].volumeDb=tracks[player][track].volumeDb;}
            if((changedFields&kMixPan)!=0){target.pan=source.pan;next->views[track].pan=tracks[player][track].pan;}
            if((changedFields&kMixMute)!=0){target.mute=source.mute;next->views[track].mute=tracks[player][track].mute;}
            next->views[track].mixOverrideMask=static_cast<std::uint8_t>(next->views[track].mixOverrideMask|changedFields);
        }
        next->baseState=std::move(base);next->prepared.reset();(void)retainPlan(player,std::move(next),pending);
    }
    void publishState(int player,int changedTrack=-1,unsigned changedFields=0){
        auto* context=controlContexts[player];
        const auto* previous=context?context->latest.load(std::memory_order_seq_cst):nullptr;
        if(!context||(previous&&previous->style!=styles[player].get()))context=newContext(player);
        const auto* plan=retainPlan(player,currentPlan(player),context);if(!plan)return;
        controlContexts[player]=context;controlAckPlans[player]=plan;publishedControlContexts[player].store(context,std::memory_order_release);
        (void)synth[player].publishPreparedState(plan->prepared);
        refreshPendingMix(player,changedTrack,changedFields);collectPlans();
        finishDeferredSync(player);
    }
    bool writeTrackMute(int player,int track,bool muted){
        if(!commandLocked(arranger::CommandType::SetTrackMute,player,track,muted?1:0,styles[player].get()))return false;
        auto next=std::make_shared<sampler::EngineState>(*state[player]);
        next->combi.part(track).mute=muted;state[player]=std::move(next);
        tracks[player][track].mute=muted;
        tracks[player][track].mixOverrideMask|=kMixMute;
        publishState(player,track,kMixMute);return true;
    }
    void finishDeferredSync(int player){
        if(savedSyncStartPending[player]&&styles[player]){
            bool complete=true;for(int track=0;track<8;++track)if(styles[player]->tracks[track].used&&!tracks[player][track].assigned)complete=false;
            if(complete&&engine.post({arranger::CommandType::SetSyncStart,player,0,1.0,0}))savedSyncStartPending[player]=false;
        }
    }
    const RoutingPlan* buildSamplePlan(int player,StyleContext* context,
            const std::shared_ptr<const arranger::Pa5xStyleRead>& read,
            const std::shared_ptr<const arranger::Pa5xSetBank>& setBank,const std::string& path,
            const std::vector<ArrangerOriginalProgram>& programs,const std::vector<std::string>& warnings,
            bool prevalidated,const std::shared_ptr<sampler::EngineState>& base,
            const std::array<ArrangerTrackView,8>& views,std::unique_ptr<RoutingPlan>* unregistered=nullptr){
        const auto& style=read->nativeStyle;
    std::string messages;for(const auto& warning:warnings)appendWarning(messages,warning);
    std::map<std::uint32_t,sampler::ProgramPtr> supplied;std::set<std::uint32_t> ambiguous;
    for(const auto& program:programs){
        Impl::OriginalAddress address{program.msb,program.lsb,program.program};
        if(!address.complete()||!program.sound||(!prevalidated&&!playableSampleProgram(program.sound))){
            appendWarning(messages,"Skipped an invalid address or a sample Program without playable audio");continue;
        }
        if(ambiguous.count(address.key())!=0)continue;
        if(!supplied.emplace(address.key(),program.sound).second){
            supplied.erase(address.key());ambiguous.insert(address.key());
            appendWarning(messages,"Conflicting sample Programs for one original address were silenced");
        }
    }
    std::array<std::set<std::uint32_t>,8> required;std::uint8_t mask=0,unsupported=0,unplayedPatterns=0,unroutedAcc=0;
    for(std::size_t sectionIndex=0;sectionIndex<read->sections.size();++sectionIndex){
        const auto& section=read->sections[sectionIndex];if(!section.available)continue;
        for(int track=0;track<8;++track){
            const auto& clip=section.tracks[static_cast<std::size_t>(track)];if(!clip.present)continue;
            for(const auto& cv:clip.cvs){
                if(!cv.available||!cv.hasNotes)continue;
                if(cv.number<1||cv.number>6){unsupported=static_cast<std::uint8_t>(unsupported|(1U<<track));continue;}
                const auto& sourcePattern=style->sections[sectionIndex].patterns[static_cast<std::size_t>(track)];
                if(sourcePattern.mode==arranger::NativePatternMode::Unsupported){
                    unplayedPatterns=static_cast<std::uint8_t>(unplayedPatterns|(1U<<track));continue;
                }
                // Keep exact Sound routes available even when an ACC CV has no
                // source chord: an explicit GTR override may interpret it. The
                // arranger still decides whether each pattern can emit notes.
                const bool noSourceChord=sourcePattern.mode==arranger::NativePatternMode::RecordedSourceOnly&&
                    sourcePattern.cvs[static_cast<std::size_t>(cv.number-1)].sourceChord==arranger::ChordType::None;
                const auto previousAddresses=noSourceChord?required[static_cast<std::size_t>(track)]:std::set<std::uint32_t>{};
                std::set<unsigned> channels;bool invalid=false;
                for(const auto& change:cv.soundChanges){
                    Impl::OriginalAddress address{change.msb,change.lsb,change.program};
                    if(!address.complete()){invalid=true;continue;}
                    channels.insert(change.channel);required[static_cast<std::size_t>(track)].insert(address.key());
                }
                if(channels.size()!=1||cv.number<1||cv.number>6)invalid=true;
                if(!invalid){
                    const auto& pattern=style->sections[sectionIndex].patterns[static_cast<std::size_t>(track)];
                    const auto& nativeCv=pattern.cvs[static_cast<std::size_t>(cv.number-1)];
                    Impl::OriginalMidiState declared;
                    const auto inspect=[&](const arranger::MidiEvent& event,bool notes){
                        const auto channel=static_cast<std::size_t>(event.status&15U);auto& source=declared.channels[channel];
                        const auto kind=event.status&0xF0U;
                        if(kind==0xB0U&&event.data1==0)source.pendingMsb=event.data2;
                        else if(kind==0xB0U&&event.data1==32)source.pendingLsb=event.data2;
                        else if(kind==0xC0U)source.active={source.pendingMsb,source.pendingLsb,event.data1};
                        else if(notes&&kind==0x90U&&event.data2>0)
                            return source.active.complete()&&channels.count(static_cast<unsigned>(channel))!=0&&
                                required[static_cast<std::size_t>(track)].count(source.active.key())!=0;
                        return true;
                    };
                    for(const auto& event:pattern.setupEvents)(void)inspect(event,false);
                    for(const auto& event:nativeCv.events)if(!inspect(event,true)){invalid=true;break;}
                }
                if(invalid){
                    if(noSourceChord){
                        required[static_cast<std::size_t>(track)]=previousAddresses;
                        unroutedAcc=static_cast<std::uint8_t>(unroutedAcc|(1U<<track));
                    }else unsupported=static_cast<std::uint8_t>(unsupported|(1U<<track));
                }
            }
        }
    }
    std::size_t missing=0;
    for(int track=0;track<8;++track){
        if(!style->tracks[static_cast<std::size_t>(track)].used)continue;
        mask=static_cast<std::uint8_t>(mask|(1U<<track));
        if((unplayedPatterns&(1U<<track))!=0)
            appendWarning(messages,views[track].name+": unsupported pattern type or timing remains silent");
        if((unroutedAcc&(1U<<track))!=0)
            appendWarning(messages,views[track].name+": an ACC CV without a source chord also lacks a complete Sound route");
        if((unsupported&(1U<<track))!=0){
            required[static_cast<std::size_t>(track)].clear();
            appendWarning(messages,views[track].name+": unsupported MIDI channel/Sound declaration; this track remains silent");
        }
        for(const auto address:required[static_cast<std::size_t>(track)])
            if(supplied.count(address)==0)++missing;
    }
    if(missing!=0)appendWarning(messages,std::to_string(missing)+" original track/Sound addresses have no loaded User sample audio and remain silent");
        auto plan=std::make_unique<RoutingPlan>();plan->styleOwner=style;plan->read=read;plan->setBank=setBank;plan->path=path;
        if(const auto* old=context?context->latest.load(std::memory_order_acquire):nullptr)plan->fillModes=old->fillModes;
        plan->programs=std::move(supplied);plan->required=std::move(required);plan->trackMask=mask;
        plan->sampleMode=true;plan->warnings=std::move(messages);plan->views=views;
        auto value=std::make_shared<sampler::EngineState>(*base);
        for(int track=0;track<8;++track){
            auto& part=value->combi.part(track);auto& view=plan->views[track];
            bool ready=false;for(const auto address:plan->required[track])if(plan->programs.count(address)){ready=true;break;}
            part.program.reset();part.enabled=ready;part.soundSlotId=0;part.name=kTrackNames[track];
            view.assigned=ready;view.originalSoundRouted=(mask&(1U<<track))!=0;view.soundSlot=0;
            view.soundName=ready?"Sample playback":"No loaded samples";
        }
        plan->baseState=std::move(value);
        if(unregistered){*unregistered=std::move(plan);return nullptr;}
        return retainPlan(player,std::move(plan),context);
    }
    bool anyPreparedSampleProgram(int player) const {
        const auto& style = styles[player];
        if (!style) return false;
        for (int track=0;track<8;++track) {
            if (!style->tracks[track].used) continue;
            if ((originalRoutingMask[player] & (1U << track)) == 0U) {
                if (tracks[player][track].assigned && state[player]->combi.part(track).program) return true;
                continue;
            }
            for (const auto address:requiredOriginalPrograms[player][track]) {
                const auto found=originalPrograms[player].find(address);
                if (found!=originalPrograms[player].end() && found->second) return true;
            }
        }
        return false;
    }
    bool readyToStart(int player) {
        std::lock_guard<std::mutex> lock(control);synchronizeCommitted(player);
        const auto& style = styles[player];
        if (!style) { error = "Load a Style before pressing START"; return false; }
        if (samplePlaybackMode[player]) {
            if (anyPreparedSampleProgram(player)) return true;
            error = "No playable User samples are available for this Style. Missing sample addresses remain silent";
            return false;
        }
        for (int track = 0; track < 8; ++track) {
            if (!style->tracks[track].used || tracks[player][track].assigned) continue;
            const auto& source = style->tracks[track];
            error = "START blocked: " + tracks[player][track].name + " has no playable Sound";
            if (source.addressKnown) {
                error += " (original " + std::to_string(source.msb) + "/" +
                    std::to_string(source.lsb) + "/" + std::to_string(source.program) + ")";
                const auto& bank = styleBanks[player];
                if (bank) {
                    const auto resolved = bank->resolveSoundAddress(source.msb,source.lsb,source.program);
                    if (!resolved.name.empty()) error += ": " + resolved.name;
                    if (resolved.resolution == arranger::KstResolution::FactorySoundRequired)
                        error += ". Factory waveform audio is not supplied by this KST";
                    else if (resolved.resolution == arranger::KstResolution::ExactUserSound)
                        error += ". The Sound engine still lacks verified envelope time/gain/modulation and filter execution";
                    else if (!resolved.message.empty()) error += ". " + resolved.message;
                }
            }
            error += ". No replacement Sound has been selected";
            return false;
        }
        return true;
    }
    const RoutingPlan* routing(int player,int track) const noexcept {
        const auto* plan=audioActivePlans[player].load(std::memory_order_seq_cst);
        return plan&&plan->style==audioSourceStyles[player]&&(plan->trackMask&(1U<<track))!=0?plan:nullptr;
    }
    const RoutingPlan* acquireLatest(StyleContext* context,int player,bool commit) noexcept {
        if(!context)return nullptr;
        const auto* plan=context->latest.load(std::memory_order_seq_cst);
        audioPlanHazards[player].store(plan,std::memory_order_seq_cst);
        if(context->latest.load(std::memory_order_seq_cst)!=plan){
            audioPlanHazards[player].store(nullptr,std::memory_order_seq_cst);
            return commit?context->initial.load(std::memory_order_seq_cst):nullptr;
        }
        return plan;
    }
    void activateAudioPlan(int player,const RoutingPlan* plan) noexcept {
        if(!plan)return;
        if(audioContexts[player]!=plan->context)plan->context->hitStart.store(++hitFrame,std::memory_order_relaxed);
        audioActivePlans[player].store(plan,std::memory_order_seq_cst);audioContexts[player]=plan->context;
        audioRouteReady[player]=synth[player].postPreparedState(plan->prepared.get());
        synth[player].setScaleUppers(static_cast<int>(plan->scaleMask));
        audioPlanHazards[player].store(nullptr,std::memory_order_seq_cst);
    }
    bool rendersTrackMutes() const noexcept override {return true;}
    std::uint8_t committedStyleMuteMask(int player,const void*,std::uint8_t fallback) noexcept override {
        if(!playerOk(player))return fallback;
        const auto* plan=audioActivePlans[player].load(std::memory_order_seq_cst);
        if(!plan||plan->style!=audioSourceStyles[player])return fallback;
        std::uint8_t mask=0;for(int track=0;track<8;++track)if(plan->views[track].mute)mask=static_cast<std::uint8_t>(mask|(1U<<track));
        return mask;
    }
    arranger::Element committedStyleElement(int player,const void* token,bool playing,arranger::Element fallback) noexcept override {
        const auto* context=static_cast<const StyleContext*>(token);
        if(!playerOk(player)||playing||!context||context->player!=player||!context->savedOptions)return fallback;
        return static_cast<arranger::Element>(context->savedElement);
    }
    bool committedStyleAutoFill(int player,const void* token,bool fallback) noexcept override {
        const auto* context=static_cast<const StyleContext*>(token);
        return playerOk(player)&&context&&context->player==player&&context->savedOptions?context->savedAutoFill:fallback;
    }
    void initializeStyleControllers(int player) noexcept override {
        if(!playerOk(player))return;
        sourceMixContext[player].store(nullptr,std::memory_order_release);
        for(int track=0;track<8;++track){
            auto& source=sourceMix[player][track];source.volume.store(-1,std::memory_order_relaxed);source.pan.store(-1,std::memory_order_relaxed);source.expression.store(-1,std::memory_order_relaxed);
            for(auto& send:source.sends)send.store(-1,std::memory_order_relaxed);
            source.resetSoundEdits();
            const auto channel=static_cast<std::uint8_t>(track);
            (void)synth[player].postControlChange(channel,7,127);(void)synth[player].postControlChange(channel,10,64);(void)synth[player].postControlChange(channel,11,127);
            (void)synth[player].postControlChange(channel,91,0);(void)synth[player].postControlChange(channel,93,0);(void)synth[player].postControlChange(channel,94,0);
        }
        sourceMixContext[player].store(audioContexts[player],std::memory_order_release);
    }
    void styleCommitted(int player,const arranger::Style* style,const void* token) noexcept override {
        if(!playerOk(player))return;
        persistentRevision.fetch_add(1,std::memory_order_relaxed);
        audioRouteReady[player]=false;
        auto* context=static_cast<StyleContext*>(const_cast<void*>(token));
        if(!context)context=publishedControlContexts[player].load(std::memory_order_acquire);
        const auto* plan=acquireLatest(context,player,true);
        if(plan&&plan->style==style)activateAudioPlan(player,plan);
        else audioPlanHazards[player].store(nullptr,std::memory_order_seq_cst);
        for(auto& track:originalMidi[player])track={};
    }
    void liveEvent(const arranger::LiveEvent& event) noexcept override {arranger::liveEvents.push(event);}
    void sourceStyle(int player,const arranger::Style* style) noexcept override {
        if(!playerOk(player))return;
        if(audioSourceStyles[player]!=style){
            audioRouteReady[player]=false;audioSourceStyles[player]=style;for(auto& track:originalMidi[player])track={};
            const auto* current=audioActivePlans[player].load(std::memory_order_seq_cst);
            if(!current||current->style!=style){
                auto* context=publishedControlContexts[player].load(std::memory_order_acquire);
                const auto* plan=acquireLatest(context,player,true);
                if(plan&&plan->style==style)activateAudioPlan(player,plan);
                else audioPlanHazards[player].store(nullptr,std::memory_order_seq_cst);
            }
        }
        if(auto* context=audioContexts[player]){
            const auto* plan=acquireLatest(context,player,false);
            const auto* previous=audioActivePlans[player].load(std::memory_order_seq_cst);
            if(plan&&plan->style==style&&plan!=previous)activateAudioPlan(player,plan);
            audioPlanHazards[player].store(nullptr,std::memory_order_seq_cst);
        }
        if(!audioRouteReady[player]){
            const auto* plan=audioActivePlans[player].load(std::memory_order_seq_cst);
            if(!plan||plan->style!=style){
                auto* context=publishedControlContexts[player].load(std::memory_order_acquire);
                const auto* candidate=acquireLatest(context,player,true);
                if(candidate&&candidate->style==style)activateAudioPlan(player,candidate);
                else audioPlanHazards[player].store(nullptr,std::memory_order_seq_cst);
            }else audioRouteReady[player]=synth[player].postPreparedState(plan->prepared.get());
        }
    }
    void patternStart(int player,int track) noexcept override {if(trackOk(player,track))originalMidi[player][track]={};}
    std::array<float,2> fadeFirst{{1.0F,1.0F}},fadeLast{{1.0F,1.0F}};
    std::array<std::atomic<float>,2> sourceTempos{{120.0F,120.0F}};
    std::array<std::atomic<bool>,2> sourcePlaying{{false,false}};
    void sourceTempo(int player,double bpm,bool playing) noexcept override {
        if(!playerOk(player)||!std::isfinite(bpm))return;
        const auto index=static_cast<std::size_t>(player);
        const auto value=static_cast<float>(std::clamp(bpm,20.0,400.0));
        synth[player].setSourceTempo(value);
        sourceTempos[index].store(value,std::memory_order_relaxed);
        sourcePlaying[index].store(playing,std::memory_order_relaxed);
    }
    void transportGain(int player,float first,float last) noexcept override {
        if(playerOk(player)){fadeFirst[static_cast<std::size_t>(player)]=first;fadeLast[static_cast<std::size_t>(player)]=last;}
    }
    arranger::PhraseRange phraseRange(const void* token,arranger::Element element,int track) const noexcept override {
        const auto* ctx=static_cast<const StyleContext*>(token);
        if(!ctx||element>=arranger::Element::Count||track<0||track>=arranger::kTracks)return {};
        const auto index=static_cast<std::size_t>(element)*arranger::kTracks+track;
        return PhraseRangeBank::unpack(ctx->ranges[index].load(std::memory_order_relaxed),ctx->wraps[track].load(std::memory_order_relaxed));
    }
    arranger::GuitarOverride guitarSettings(const void* token,arranger::Element element,int track) const noexcept override {
        const auto* ctx=static_cast<const StyleContext*>(token);
        if(!ctx||element>=arranger::Element::Count||track<0||track>=arranger::kTracks)return {};
        const auto index=static_cast<std::size_t>(element)*arranger::kTracks+track;
        return GuitarOverrideBank::unpack(ctx->guitars[index].load(std::memory_order_relaxed));
    }
    StyleGuitarView guitarView(const StyleContext* ctx,int element,int track) const {
        StyleGuitarView view;
        const auto* plan=ctx->latest.load(std::memory_order_acquire);
        if(!plan||!plan->style)return view;
        const auto& section=plan->style->sections[element];
        const auto& pattern=section.patterns[track];
        const auto role=plan->style->tracks[track].role;
        view.sourceDeclaredGuitar=pattern.present&&pattern.mode==arranger::NativePatternMode::Guitar;
        if(plan->read){
            const auto& original=plan->read->sections[element].tracks[track];
            view.sourceDeclaredGuitar=view.sourceDeclaredGuitar||(original.present&&original.patternType=="Guitar");
        }
        const bool supported=section.available&&section.nativePatterns&&pattern.present&&
            role!=arranger::TrackRole::Drums&&role!=arranger::TrackRole::Percussion&&
            (pattern.mode==arranger::NativePatternMode::RecordedSourceOnly||pattern.mode==arranger::NativePatternMode::Guitar);
        view.sourceBlocked=view.sourceDeclaredGuitar&&!supported;
        if(!supported)return view;
        view.available=true;view.sourceGuitar=pattern.mode==arranger::NativePatternMode::Guitar;
        view.overrides=guitarSettings(ctx,static_cast<arranger::Element>(element),track);
        view.edited=GuitarOverrideBank::pack(view.overrides)!=0;
        view.guitar=view.overrides.mode<0?view.sourceGuitar:view.overrides.mode==1;
        view.source=pattern.guitar;view.settings=arranger::resolveGuitarSettings(view.source,view.overrides);
        if(plan->read&&plan->read->inspection){
            const arranger::KorgStyleClip* source=nullptr;bool duplicate=false;
            for(const auto& sectionSource:plan->read->inspection->elements){
                if(sectionSource.element!=static_cast<arranger::Element>(element))continue;
                for(const auto& clip:sectionSource.clips)if(clip.track==track){
                    if(source)duplicate=true;else source=&clip;
                }
            }
            if(source&&!duplicate&&source->guitarParametersValid){
                view.sourceCapoKnown=source->guitarCapo>=0&&source->guitarCapo<=12&&source->guitarCapo==view.source.capo;
                view.sourceHumanizeKnown=source->guitarHumanize>=0&&source->guitarHumanize<=127&&source->guitarHumanize==view.source.humanize;
            }
        }
        return view;
    }
    StyleRangeView rangeView(const StyleContext* ctx,int element,int track) const {
        StyleRangeView view;
        const auto* plan=ctx->latest.load(std::memory_order_acquire);
        if(!plan||!plan->style)return view;
        const auto& section=plan->style->sections[element];
        const auto& pattern=section.patterns[track];
        const auto role=plan->style->tracks[track].role;
        if(!section.available||role==arranger::TrackRole::Drums||role==arranger::TrackRole::Percussion||
           (section.nativePatterns&&(!pattern.present||pattern.mode!=arranger::NativePatternMode::RecordedSourceOnly)))return view;
        const auto overrides=phraseRange(ctx,static_cast<arranger::Element>(element),track);
        view.available=true;view.edited=overrides.enabled>=0;view.wrapEdited=overrides.wrap!=0;
        view.enabled=view.edited?overrides.enabled!=0:pattern.keyRangeEnabled;
        const bool bounds=pattern.keyLow>=0&&pattern.keyHigh<=127&&pattern.keyLow<=pattern.keyHigh;
        view.low=view.edited?overrides.low:bounds?pattern.keyLow:0;
        view.high=view.edited?overrides.high:bounds?pattern.keyHigh:127;
        view.wrap=view.wrapEdited?overrides.wrap:(pattern.wrapAroundDegree>=1&&pattern.wrapAroundDegree<=12?pattern.wrapAroundDegree:0);
        return view;
    }
    int manualFillMode(const void* token,int fill) const noexcept override {
        const auto* ctx=static_cast<const StyleContext*>(token);
        return ctx&&fill>=0&&fill<5?int((ctx->fillModes.load(std::memory_order_acquire)>>(fill*4))&15U):0;
    }
    void render(std::uint32_t offset, std::uint32_t frames) noexcept override {
        if (destination == nullptr || frames == 0) return;
        const int listenPlayer=(listenSoloWord.load(std::memory_order_relaxed)>>16)-2;
        const float x = listenPlayer>=0?float(listenPlayer):std::clamp(xfade.load(std::memory_order_relaxed), 0.0F, 1.0F);
        const float target[2] = {std::cos(x * 1.57079632679F), std::sin(x * 1.57079632679F)};
        // Five-millisecond gain smoothing prevents fader zipper clicks.
        const float smoothing = static_cast<float>(1.0 - std::exp(-1.0 / (std::max(8000.0, rate) * 0.005)));
        for (int p = 0; p < 2; ++p) {
            synth[p].render(scratch.data(), frames);
            float g = currentGain[p];
            float fade=fadeFirst[static_cast<std::size_t>(p)];
            const float fadeStep=(fadeLast[static_cast<std::size_t>(p)]-fade)/static_cast<float>(frames);
            for (std::uint32_t f = 0; f < frames; ++f) {
                g += (target[p] - g) * smoothing;
                fade+=fadeStep;
                const auto source = static_cast<std::size_t>(f) * 2;
                const auto output = static_cast<std::size_t>(offset + f) * 2;
                destination[output] += scratch[source] * g * fade;
                destination[output + 1] += scratch[source + 1] * g * fade;
            }
            currentGain[p] = g;
        }
    }
    void midi(int p, int t, std::uint8_t status, std::uint8_t a, std::uint8_t b) noexcept override {
        if (!trackOk(p, t)) return;
        const auto channel = static_cast<std::uint8_t>(t);
        const auto sourceChannel = static_cast<std::uint8_t>(status & 15U);
        auto& midiState = originalMidi[p][t];
        auto& source = midiState.channels[sourceChannel];
        const auto kind = static_cast<std::uint8_t>(status & 0xF0U);
        const auto* plan = routing(p,t);
        if (kind == 0xB0U && a == 0) { source.pendingMsb = b; return; }
        if (kind == 0xB0U && a == 32) { source.pendingLsb = b; return; }
        if (kind == 0xC0U) {
            // A trailing bank-select remains pending. Only this Program Change
            // commits the exact channel's bank address.
            source.active = {source.pendingMsb,source.pendingLsb,a};
            midiState.activeChannel = sourceChannel;
            if (plan && source.active.complete())
                (void)synth[p].postProgramSelection(channel,static_cast<std::uint8_t>(source.active.msb),
                    static_cast<std::uint8_t>(source.active.lsb),static_cast<std::uint8_t>(source.active.program),plan->revision,plan->context);
            return;
        }
        switch (kind) {
            case 0x80: (void)synth[p].postNoteOff(channel, a, b); break;
            case 0x90:
                if (b == 0) { (void)synth[p].postNoteOff(channel,a,64U); break; }
                if (!audioRouteReady[p]) break;
                if (plan) {
                    if (midiState.activeChannel < 0) break;
                    const auto& active = midiState.channels[static_cast<std::size_t>(midiState.activeChannel)].active;
                    if (!active.complete()) break;
                    // Selection and NoteOn use the same bounded producer. If
                    // selection is refused, do not let a later note inherit the
                    // preceding instrument after the queue drains.
                    if (!synth[p].postProgramSelection(channel,static_cast<std::uint8_t>(active.msb),
                            static_cast<std::uint8_t>(active.lsb),static_cast<std::uint8_t>(active.program),plan->revision,plan->context)) break;
                } else {
                    if (!synth[p].postClearProgramSelection(channel)) break;
                }
                if(synth[p].postNoteOn(channel,a,b)){
                    lastTrackHit[p][t].store(hitFrame,std::memory_order_relaxed);
                    if(t<2&&a<128)lastDrumHit[p][t][a].store(hitFrame,std::memory_order_relaxed);
                }
                break;
            case 0xB0:
                sourceMix[p][t].observeSoundEdit(a,b);
                if(a==7U)sourceMix[p][t].volume.store(b,std::memory_order_relaxed);
                else if(a==10U)sourceMix[p][t].pan.store(b,std::memory_order_relaxed);
                else if(a==11U)sourceMix[p][t].expression.store(b,std::memory_order_relaxed);
                else if(const int send=originalFxSendSlot(a);send>=0)sourceMix[p][t].sends[static_cast<std::size_t>(send)].store(b,std::memory_order_relaxed);
                // Musical All Notes Off uses the existing 4 ms release. CC120/Panic stays immediate.
                if(a==123U)(void)synth[p].postSoftChannelRelease(channel);
                else (void)synth[p].postControlChange(channel,a,b);
                break;
            case 0xA0: (void)synth[p].postPolyPressure(channel,a,b); break;
            case 0xD0: (void)synth[p].postChannelPressure(channel,a); break;
            case 0xE0: (void)synth[p].postPitchBend(channel,static_cast<std::int16_t>((static_cast<int>(a) | (static_cast<int>(b) << 7)) - 8192)); break;
            default: break;
        }
    }
};

// Control-thread checkpoint: immutable graph ownership, never copied PCM.
struct ArrangerSourceCheckpoint {
    const ArrangerHost* owner{nullptr};std::string session;
    std::uint16_t channels{0xFFFFU},damper{64U};bool notesFiltered{false};
    std::shared_ptr<const arranger::Pa5xSetBank> catalog;
    std::shared_ptr<const ArrangerHost::Impl::PreparedSetSamples> prepared;
    std::vector<std::shared_ptr<const ArrangerHost::Impl::PreparedSetSamples>> banks;
    std::array<ArrangerHost::Impl::KeyboardProgramProvenance,7> keyboard;
    std::array<std::shared_ptr<const ArrangerHost::Impl::RoutingPlan>,2> plans;
    std::array<ArrangerStyleKeyboardLinks,2> links;
};

ArrangerHost::ArrangerHost() : impl_(std::make_unique<Impl>()) {}
ArrangerHost::~ArrangerHost() = default;
// The native audio host is itself process-global and calls this facade from its
// destructor. Keep the facade alive through static destruction; OS teardown
// reclaims it after the host has stopped the workers and devices.
ArrangerHost& arrangerHost() { static ArrangerHost* host = new ArrangerHost; return *host; }

bool ArrangerHost::loadPcmPreview(const std::string& pcmPath, const std::string& kmpPath,
                                 std::uint64_t resourceId) {
    // Decode on the control thread, then publish an immutable sampler graph.
    // A failed selection invalidates the previous one so Play cannot audition
    // a stale recording under the newly selected name.
    auto fail = [this](const std::string& message) {
        std::lock_guard<std::mutex> lock(impl_->control);
        (void)impl_->previewSynth.postPanic();
        impl_->previewProgram.reset();
        impl_->previewView = {};
        impl_->previewView.error = message;
        impl_->error = message;
        return false;
    };
    std::ifstream file(pcmPath, std::ios::binary | std::ios::ate);
    if (!file) return fail("Cannot open the selected PCM file");
    const auto size = file.tellg();
    if (size <= 0 || size > std::streamoff(256U * 1024U * 1024U))
        return fail("PCM file is empty or exceeds the 256 MiB audition limit");
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));
    file.seekg(0);
    if (!file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size())))
        return fail("Cannot read the selected PCM file");
    const auto pcm = arranger::inspectPa5xSampleBytes(bytes,true);
    const auto kmp = arranger::inspectPa5xSampleFile(kmpPath);
    if (!pcm.valid || pcm.kind != arranger::Pa5xSampleContainerKind::PcmSamples)
        return fail(pcm.error.empty() ? "Invalid PCM sample container" : pcm.error);
    if (!kmp.valid || !kmp.multisampleMappingDecoded)
        return fail(kmp.error.empty() ? "A decoded RAM.KMP from this set is required" : kmp.error);
    const arranger::Pa5xSampleObject* object = nullptr;
    for (const auto& candidate : pcm.objects) if (candidate.hasId && candidate.resourceId == resourceId) {
        if (object != nullptr) return fail("Duplicate PCM sample UID");
        object = &candidate;
    }
    const arranger::Pa5xKmpSample* metadata = nullptr;
    for (const auto& candidate : kmp.samples) if (candidate.resourceId == resourceId) {
        if (metadata != nullptr) return fail("Duplicate KMP sample UID");
        metadata = &candidate;
    }
    if (object == nullptr || metadata == nullptr) return fail("Sample UID is missing from PCM or RAM.KMP");
    auto decoded = arranger::decodePa5xSampleAudio(bytes, *object, *metadata);
    if (!decoded) return fail(decoded.error);
    const int originalKey = metadata->originalNote <= 127 ? metadata->originalNote : -1;
    auto sample = std::make_shared<sampler::SampleData>();
    sample->name = object->name;
    sample->sourcePath = pcmPath;
    sample->sampleRate = decoded.sampleRate;
    // A few source records use 128/255 rather than a MIDI root. Use the same
    // neutral key for playback and zone root so their raw audition is at unity
    // pitch, while retaining an explicitly unknown original key in the UI.
    sample->rootKey = static_cast<std::uint8_t>(originalKey < 0 ? 60 : originalKey);
    sample->interleaved = std::move(decoded.mono);
    // Header loop end semantics and KMP tuning are not fully established.
    // One-shot audition uses every decoded frame at its exact recorded rate.
    auto multi = std::make_shared<sampler::Multisample>();
    multi->name = sample->name;
    sampler::SampleZone zone;
    zone.sample = sample;
    zone.rootKey = sample->rootKey;
    zone.oneShot = true;
    multi->zones.push_back(zone);
    auto program = std::make_shared<sampler::Program>();
    program->name = "PCM preview: " + sample->name;
    sampler::ProgramLayer layer;
    layer.multisample = multi;
    layer.ampEnvelope = {0.0F, 0.0F, 1.0F, 0.0F};
    program->layers.push_back(layer);
    std::lock_guard<std::mutex> lock(impl_->control);
    (void)impl_->previewSynth.postPanic();
    impl_->previewProgram = program;
    auto state = std::make_shared<sampler::EngineState>(*impl_->previewState);
    auto& part = state->combi.part(0);
    part.enabled = true;
    part.program = program;
    part.expressionEnabled = false;
    part.damperEnabled = false;
    part.name = program->name;
    impl_->previewState = state;
    impl_->previewSynth.setState(state);
    impl_->previewView = {sample->name, "", sample->sampleRate,
                          sample->frameCount(), originalKey, true};
    impl_->error.clear();
    return true;
}
bool ArrangerHost::playPcmPreview() {
    std::lock_guard<std::mutex> lock(impl_->control);
    if (!impl_->previewView.ready || !impl_->previewProgram) {
        impl_->error = impl_->previewView.error.empty() ? "Select a PCM recording first" : impl_->previewView.error;
        return false;
    }
    (void)impl_->previewSynth.postPanic();
    const auto key = static_cast<std::uint8_t>(impl_->previewView.rootKey < 0 ? 60 : impl_->previewView.rootKey);
    return impl_->previewSynth.postNoteOn(0, key, 127);
}
void ArrangerHost::stopPcmPreview() {
    impl_->drumKitMidiAudition.store(false,std::memory_order_release);
    (void)impl_->previewSynth.postPanic();
}
PcmPreviewView ArrangerHost::pcmPreview() const {
    std::lock_guard<std::mutex> lock(impl_->control);
    return impl_->previewView;
}
bool ArrangerHost::assignPcmPreview(int player, int track) {
    sampler::ProgramPtr program;
    { std::lock_guard<std::mutex> lock(impl_->control); program = impl_->previewProgram; }
    if (!program) return false;
    return assignSound(player, track, 0, std::move(program));
}

void ArrangerHost::configureStyleEditStorage(const std::string& directory){
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->styleEditStorage=directory;
}
bool ArrangerHost::saveStyleEdits(int player){return saveStyleEditsImpl(player,0,0,{});}
bool ArrangerHost::saveStyleEdits(int player,int bank,int position,const std::string& name){
    if(bank<0||bank>16||position<0||position>128||((bank==0)!=(position==0))){std::lock_guard<std::mutex> lock(impl_->control);impl_->error="Choose the current Style or a User Style position";return false;}
    return saveStyleEditsImpl(player,bank,position,name);
}
bool ArrangerHost::saveStyleEdits(int player,int bank,int position,const std::string& displayName,const ArrangerStyleKeyboardLinks& keyboardSets){
    if(bank<0||bank>16||position<0||position>128||((bank==0)!=(position==0)))return false;
    return saveStyleEditsImpl(player,bank,position,displayName,&keyboardSets);
}
ArrangerStyleKeyboardLinks ArrangerHost::savedStyleKeyboardSets(int player) const {
    if(!playerOk(player))return {};
    std::string directory,identity;int bank=0,position=0;
    {std::lock_guard<std::mutex> lock(impl_->control);directory=impl_->styleEditStorage;bank=impl_->savedStyleBanks[player];position=impl_->savedStylePositions[player];
        const auto* context=impl_->controlContexts[player];const auto* plan=context?context->latest.load(std::memory_order_seq_cst):nullptr;if(plan)identity=plan->sourceEditIdentity;}
    SavedStylePointer pointer;SavedStyleEdit edit;
    const auto destination=bank>0?styleEditUserPointer(directory,bank,position):styleEditSourcePointer(directory,identity);
    if(directory.empty()||identity.empty()||!readStyleEditPointer(destination,pointer)||
       !readStyleEdit(styleEditJoin(directory,pointer.revision),edit)||edit.sourcePath!=pointer.sourcePath||edit.identity!=pointer.identity)return {};
    return edit.keyboardSets;
}
ArrangerStyleKeyboardSelection ArrangerHost::keyboardStyleSelection(int player) const {
    ArrangerStyleKeyboardSelection result;if(!playerOk(player))return result;
    {
        std::lock_guard<std::mutex> lock(impl_->control);const auto audio=impl_->synchronizeCommitted(player);
        auto* context=impl_->stagedContexts[player];
        if(!context)context=impl_->controlContexts[player];
        const auto* plan=context?context->latest.load(std::memory_order_seq_cst):nullptr;
        if(!plan||!plan->styleOwner)return result;
        result.serial=context->serial;result.pending=audio.styleCommitToken!=context;result.playing=audio.playing;
        result.key=plan->path.empty()?"<No Style>":plan->path;
        if(plan->savedStyleBank>0&&plan->savedStylePosition>0)result.key+="\nSILVETON_USER_STYLE "+std::to_string(plan->savedStyleBank)+" "+std::to_string(plan->savedStylePosition);
        result.read=plan->read;result.savedLinks=context->keyboardSets;
        int preferred=static_cast<int>(audio.returnVariation);
        if(!audio.playing&&context->savedOptions)preferred=context->savedElement;
        const auto& sections=plan->styleOwner->sections;
        if(preferred<0||static_cast<std::size_t>(preferred)>=sections.size()||!sections[static_cast<std::size_t>(preferred)].available){
            preferred=-1;for(int e=3;e<=6;++e)if(sections[static_cast<std::size_t>(e)].available){preferred=e;break;}
            if(preferred<0)for(std::size_t e=0;e<sections.size();++e)if(sections[e].available){preferred=static_cast<int>(e);break;}
        }
        result.element=preferred;
    }
    if(!result.pending&&std::none_of(result.savedLinks.begin(),result.savedLinks.end(),[](const auto& link){return !link.first.empty();}))
        result.savedLinks=savedStyleKeyboardSets(player);
    return result;
}
bool ArrangerHost::saveStyleKeyboardSets(int player,const ArrangerStyleKeyboardLinks& keyboardSets){
    if(!playerOk(player))return false;
    std::string directory,sourceIdentity,sourcePath;int bank=0,position=0;std::shared_ptr<const arranger::Style> original;
    {std::lock_guard<std::mutex> lock(impl_->control);directory=impl_->styleEditStorage;bank=impl_->savedStyleBanks[player];position=impl_->savedStylePositions[player];
        const auto* context=impl_->controlContexts[player];const auto* plan=context?context->latest.load(std::memory_order_seq_cst):nullptr;
        if(plan){sourceIdentity=plan->sourceEditIdentity;sourcePath=plan->path;original=plan->styleOwner;}}
    const auto reject=[&](const std::string& error){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=error;return false;};
    if(directory.empty()||sourceIdentity.empty()||!original)return reject("Select a Style before saving its Keyboard Sets");
    sourcePath=styleEditCanonicalPath(sourcePath);
    if(sourcePath.empty()||styleEditIdentity(sourcePath,*original)!=sourceIdentity)return reject("The original Style changed; select it again before saving");
    const auto destination=bank>0?styleEditUserPointer(directory,bank,position):styleEditSourcePointer(directory,sourceIdentity);
    SavedStylePointer pointer;SavedStyleEdit edit;
    if(!readStyleEditPointer(destination,pointer)||!readStyleEdit(styleEditJoin(directory,pointer.revision),edit)){
        if(bank>0)return reject("The selected User Style is unavailable");
        // First source-specific Keyboard Set save starts from the original
        // accompaniment, without saving unrelated live mixer edits.
        edit.sourcePath=sourcePath;edit.identity=sourceIdentity;edit.name=original->name;edit.bpm=original->tempoBpm;
        edit.effects.sourceEffects=original->nativeKorg;
        if(!original->sections[static_cast<std::size_t>(edit.element)].available)for(std::size_t e=0;e<original->sections.size();++e)if(original->sections[e].available){edit.element=static_cast<int>(e);break;}
        for(std::size_t t=0;t<edit.tracks.size();++t)if(original->tracks[t].used&&original->tracks[t].addressKnown)edit.tracks[t].binding=1;
        pointer={0,0,edit.name,sourcePath,sourceIdentity,{}};
    }
    if(edit.sourcePath!=sourcePath||edit.identity!=sourceIdentity)return reject("The saved Style belongs to another source revision");
    for(const auto& keyboard:keyboardSets){
        if(!styleEditValidText(keyboard.first,65536U)||!styleEditValidText(keyboard.second,256U)||keyboard.first.empty()!=keyboard.second.empty())return reject("A Style Keyboard Set reference is invalid");
        if(!keyboard.first.empty()){std::string bytes;if(!readStyleEditFile(keyboard.first,bytes,1024U*1024U))return reject("A Style Keyboard Set revision is unavailable");}
    }
    edit.keyboardSets=keyboardSets;const auto bytes=styleEditText(edit);
    if(bytes.empty())return reject("Invalid numbered FX settings; previous Style revision retained");
    const auto revision=styleEditRevisionName(bytes);const auto path=styleEditJoin(directory,revision);
    struct stat st{};if(::stat(path.c_str(),&st)==0){std::string previous;if(!readStyleEditFile(path,previous)||previous!=bytes)return reject("Saved Style revision is inconsistent");}
    else if(!styleEditDirectories(directory)||!styleEditAtomicWrite(path,bytes))return reject("Style Keyboard Sets could not be committed");
    pointer.revision=revision;
    if(!styleEditAtomicWrite(destination,styleEditPointerText(pointer)))return reject("Style destination could not be committed; previous entry retained");
    {std::lock_guard<std::mutex> lock(impl_->control);if(impl_->styles[player]==original&&impl_->controlContexts[player])impl_->controlContexts[player]->keyboardSets=keyboardSets;impl_->error.clear();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);}
    return true;
}
bool ArrangerHost::saveStyleEditsImpl(int player,int bank,int position,const std::string& displayName,const ArrangerStyleKeyboardLinks* keyboardSets){
    if(!playerOk(player))return false;
    const auto reject=[&](const std::string& reason){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=reason;return false;};
    SavedStyleEdit saved;std::string directory,loadedIdentity;
    std::shared_ptr<const arranger::Style> style;std::array<sampler::ProgramPtr,8> manual;
    {
        std::lock_guard<std::mutex> lock(impl_->control);const auto transport=impl_->synchronizeCommitted(player);
        const auto* context=impl_->controlContexts[player];const auto* plan=context?context->latest.load(std::memory_order_seq_cst):nullptr;
        if(!plan||!plan->styleOwner||plan->path.empty()){impl_->error="Select a Style before saving its edits";return false;}
        if(transport.style!=plan->styleOwner.get()||transport.styleCommitToken!=context){
            impl_->error="Wait for the selected Style to become active before saving";return false;
        }
        saved.effects.capture(plan->baseState->combi);saved.effects.fillModes=context->readFillModes();saved.effects.ranges=context->readRanges();saved.effects.guitars=context->readGuitars();
        style=plan->styleOwner;saved.sourcePath=plan->path;loadedIdentity=plan->sourceEditIdentity;directory=impl_->styleEditStorage;
        saved.name=displayName.empty()?(plan->savedStyleName.empty()?style->name:plan->savedStyleName):displayName;
        saved.bpm=transport.style==style.get()?transport.tempoBpm:style->tempoBpm;saved.autoFill=transport.autoFill;
        int element=static_cast<int>(transport.queued==arranger::Element::Count?transport.element:transport.queued);
        if(element>=static_cast<int>(arranger::Element::Fill1)&&element<=static_cast<int>(arranger::Element::Fill4))
            element=static_cast<int>(arranger::Element::Var1)+element-static_cast<int>(arranger::Element::Fill1);
        saved.element=element;
        for(int track=0;track<8;++track){const auto index=static_cast<std::size_t>(track);const auto& source=plan->views[index];auto& target=saved.tracks[index];
            target.db=source.volumeDb;target.pan=source.pan;target.mute=source.mute;target.mask=source.mixOverrideMask;
            target.soundSettings=source.soundSettings;
            if(source.soundSettings.setAddress>=0)target.binding=3;
            else if(source.originalSoundRouted)target.binding=1;
            else if(source.soundSlot>0&&source.soundSlot<=500){target.binding=2;target.slot=source.soundSlot;manual[index]=plan->baseState->combi.part(track).program;target.programIdentity=plan->fixedSoundIdentities[index];}
            else if(source.assigned){impl_->error="Assign a saved Sound before saving this Style; a temporary raw waveform cannot be restored";return false;}
        }
    }
    if(directory.empty())return reject("Style edit storage is not configured");
    if(keyboardSets)saved.keyboardSets=*keyboardSets;
    else {SavedStylePointer oldPointer;SavedStyleEdit oldEdit;
        const auto oldDestination=bank>0?styleEditUserPointer(directory,bank,position):styleEditSourcePointer(directory,loadedIdentity);
        if(readStyleEditPointer(oldDestination,oldPointer)&&readStyleEdit(styleEditJoin(directory,oldPointer.revision),oldEdit))saved.keyboardSets=oldEdit.keyboardSets;
    }
    for(const auto& keyboard:saved.keyboardSets){
        if(!styleEditValidText(keyboard.first,65536U)||!styleEditValidText(keyboard.second,256U)||keyboard.first.empty()!=keyboard.second.empty())return reject("A Style Keyboard Set reference is invalid");
        if(!keyboard.first.empty()){std::string bytes;if(!readStyleEditFile(keyboard.first,bytes,1024U*1024U))return reject("A Style Keyboard Set revision is unavailable");}
    }
    if(!styleEditValidText(saved.name,256U)||saved.name.empty())return reject("Enter a Style name of at most 256 bytes");
    saved.sourcePath=styleEditCanonicalPath(saved.sourcePath);saved.identity=styleEditIdentity(saved.sourcePath,*style);
    if(saved.identity.empty()||loadedIdentity.empty()||saved.identity!=loadedIdentity)return reject("The original Style file changed or is unavailable; select it again before saving");
    for(std::size_t track=0;track<manual.size();++track)if(saved.tracks[track].binding==2){
        if(manual[track])saved.tracks[track].programIdentity=styleEditProgramIdentity(manual[track]);
        if(saved.tracks[track].programIdentity.empty())return reject("The assigned Sound has no stable backing source and cannot be saved as a reference");
    }
    if(saved.element<0||saved.element>=static_cast<int>(arranger::kElementCount)||!style->sections[static_cast<std::size_t>(saved.element)].available)
        saved.element=static_cast<int>(arranger::Element::Var1);
    const auto bytes=styleEditText(saved);
    if(bytes.empty())return reject("Invalid numbered FX settings; previous Style revision retained");
    const auto revision=styleEditRevisionName(bytes);
    if(bytes.size()>kStyleEditMaximumBytes||!styleEditDirectories(directory))return reject("Style edit storage is unavailable");
    const auto revisionPath=styleEditJoin(directory,revision);struct stat revisionInfo{};
    if(::stat(revisionPath.c_str(),&revisionInfo)==0){std::string existing;if(!readStyleEditFile(revisionPath,existing)||existing!=bytes)return reject("The saved Style revision is inconsistent; previous edits retained");}
    else if(!styleEditAtomicWrite(revisionPath,bytes))return reject("Style edits could not be committed; previous saved edits retained");
    SavedStylePointer pointer{bank,position,saved.name,saved.sourcePath,saved.identity,revision};
    const auto destination=bank==0?styleEditSourcePointer(directory,saved.identity):styleEditUserPointer(directory,bank,position);
    if(!styleEditAtomicWrite(destination,styleEditPointerText(pointer)))return reject("Style destination could not be committed; previous saved entry retained");
    {
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error.clear();
        if(impl_->styles[player]==style&&(impl_->paths[player]==saved.sourcePath||styleEditCanonicalPath(impl_->paths[player])==saved.sourcePath)){
            impl_->savedStyleBanks[player]=bank;impl_->savedStylePositions[player]=position;impl_->savedStyleNames[player]=saved.name;impl_->savedStyleBpms[player]=saved.bpm;
            if(auto* context=impl_->controlContexts[player]){
                context->keyboardSets=saved.keyboardSets;
                const auto* old=context->latest.load(std::memory_order_seq_cst);
                if(old&&old->styleOwner==style){auto next=std::make_unique<Impl::RoutingPlan>(*old);next->savedStyleBank=bank;next->savedStylePosition=position;next->savedStyleName=saved.name;next->savedStyleBpm=saved.bpm;
                    for(std::size_t track=0;track<saved.tracks.size();++track)next->fixedSoundIdentities[track]=saved.tracks[track].programIdentity;
                    if(const auto* updated=impl_->retainPlan(player,std::move(next),context))impl_->adoptControlPlan(player,updated);}
            }
            impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
        }
    }
    return true;
}
std::vector<ArrangerSavedStyleEntry> ArrangerHost::savedStyleEdits() const{
    std::string directory;{std::lock_guard<std::mutex> lock(impl_->control);directory=impl_->styleEditStorage;}
    std::vector<ArrangerSavedStyleEntry> entries;if(directory.empty())return entries;
    const auto closeDirectory=[](DIR* handle){if(handle)::closedir(handle);};
    std::unique_ptr<DIR,decltype(closeDirectory)> handle(::opendir(directory.c_str()),closeDirectory);if(!handle)return entries;
    while(const auto* item=::readdir(handle.get())){
        const std::string name=item->d_name;
        if(name.compare(0,20U,"ARRANGER_USER_STYLE_")!=0)continue;
        SavedStylePointer pointer;if(!readStyleEditPointer(styleEditJoin(directory,name),pointer)||pointer.bank==0||
            styleEditUserPointer(directory,pointer.bank,pointer.position)!=styleEditJoin(directory,name))continue;
        SavedStyleEdit edit;if(!readStyleEdit(styleEditJoin(directory,pointer.revision),edit)||edit.sourcePath!=pointer.sourcePath||edit.identity!=pointer.identity)continue;
        entries.push_back({pointer.bank,pointer.position,pointer.name,pointer.sourcePath});
    }
    std::sort(entries.begin(),entries.end(),[](const auto& a,const auto& b){return std::tie(a.bank,a.position)<std::tie(b.bank,b.position);});return entries;
}
bool ArrangerHost::loadSavedStyleEdits(int player,int bank,int position){
    if(!playerOk(player)||bank<1||bank>16||position<1||position>128)return false;
    std::string directory;{std::lock_guard<std::mutex> lock(impl_->control);directory=impl_->styleEditStorage;}
    SavedStylePointer pointer;SavedStyleEdit edit;
    if(directory.empty()||!readStyleEditPointer(styleEditUserPointer(directory,bank,position),pointer)||pointer.bank!=bank||pointer.position!=position||
       !readStyleEdit(styleEditJoin(directory,pointer.revision),edit)||edit.sourcePath!=pointer.sourcePath||edit.identity!=pointer.identity){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="The selected User Style entry is unavailable or damaged";return false;
    }
    return loadStyleWithEdits(player,pointer.sourcePath,styleEditJoin(directory,pointer.revision),bank,position);
}
bool ArrangerHost::loadStyle(int player,const std::string& path){return loadStyleWithEdits(player,path,{},0,0);}
bool ArrangerHost::loadStyleWithEdits(int player,const std::string& path,const std::string& explicitRevision,int savedBank,int savedPosition){
    if(!playerOk(player))return false;
    const auto reject=[&](const std::string& reason){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=reason;return false;};
    std::shared_ptr<const arranger::Pa5xSetBank> bank;
    std::shared_ptr<const Impl::PreparedSetSamples> prepared;std::string directory;
    {
        std::lock_guard<std::mutex> lock(impl_->control);bank=impl_->korgSetBank;directory=impl_->styleEditStorage;
        const auto matches=[&](const std::shared_ptr<const Impl::PreparedSetSamples>& value){return value&&value->bank&&bankForPath(value->bank,path);};
        if(matches(impl_->preparedSetSamples))prepared=impl_->preparedSetSamples;
        else for(auto it=impl_->restoreSampleBanks.rbegin();it!=impl_->restoreSampleBanks.rend();++it)if(matches(*it)){prepared=*it;break;}
    }
    bank=prepared?prepared->bank:bankForPath(std::move(bank),path);
    std::shared_ptr<const arranger::Pa5xStyleRead> read;arranger::ImportResult imported;
    const auto dot=path.find_last_of('.');std::string extension=dot==std::string::npos?"":path.substr(dot);
    std::transform(extension.begin(),extension.end(),extension.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    if(extension==".stg"||arranger::paStyleSlot(path)){
        const auto key=detail::Pa5xStyleReadCache::keyFor(path,bank);
        {std::lock_guard<std::mutex> lock(impl_->control);read=impl_->styleReadCache.find(key);}
        if(!read){read=std::make_shared<arranger::Pa5xStyleRead>(arranger::readPa5xStyleFile(path,bank.get()));
            std::lock_guard<std::mutex> lock(impl_->control);(void)impl_->styleReadCache.insert(key,read);}
        imported.style=read->nativeStyle;imported.error=read->error;imported.warnings=read->warnings;
    }else imported=readStyle(path);
    if(!imported)return reject(imported.error);
    const auto identity=styleEditIdentity(path,*imported.style);SavedStyleEdit edit;bool haveEdit=false;std::string editWarning;
    std::string revision=explicitRevision;
    if(revision.empty()&&!directory.empty()&&!identity.empty()){
        SavedStylePointer pointer;const auto pointerPath=styleEditSourcePointer(directory,identity);struct stat info{};
        if(::stat(pointerPath.c_str(),&info)==0){
            if(readStyleEditPointer(pointerPath,pointer)&&pointer.bank==0&&pointer.identity==identity)revision=styleEditJoin(directory,pointer.revision);
            else editWarning="Saved Style edit pointer is invalid; original source settings were loaded";
        }
    }
    if(!revision.empty()){
        haveEdit=readStyleEdit(revision,edit)&&!identity.empty()&&edit.identity==identity&&styleEditCanonicalPath(edit.sourcePath)==styleEditCanonicalPath(path);
        if(!haveEdit){
            if(!explicitRevision.empty())return reject("The saved User Style source changed or its edit revision is damaged; select and save the current source again");
            editWarning="Saved Style edits no longer match the original source; original source settings were loaded";
        }
    }
    std::array<sampler::ProgramPtr,8> manualPrograms;
    if(haveEdit&&!prepared&&std::any_of(edit.tracks.begin(),edit.tracks.end(),[](const auto& track){return track.binding==1||track.binding==3;})){
        if(!explicitRevision.empty())return reject("Load this User Style's original KST sample bank before selecting it: "+path);
        appendWarning(editWarning,"Load this Style's original KST sample bank to restore its native Sound routes; those tracks remain silent");
    }
    if(haveEdit){
        auto style=std::make_shared<arranger::Style>(*imported.style);style->tempoBpm=edit.bpm;
        if(!edit.name.empty())style->name=edit.name;
        imported.style=style;
        if(read){auto adjusted=std::make_shared<arranger::Pa5xStyleRead>(*read);adjusted->nativeStyle=style;read=std::move(adjusted);}
        for(std::size_t track=0;track<edit.tracks.size();++track)if(edit.tracks[track].binding==3){
            if(prepared)manualPrograms[track]=findStyleSetSound(prepared->programs,edit.tracks[track].soundSettings);
            if(!manualPrograms[track])appendWarning(editWarning,std::string(kTrackNames[track])+": saved SET Sound unavailable");
        }else if(edit.tracks[track].binding==2){
            auto program=resolveArrangerBankSound(edit.tracks[track].slot);
            if(styleEditProgramMatches(program,edit.tracks[track].programIdentity,edit.formatVersion<13,edit.formatVersion<14)){
                edit.tracks[track].programIdentity=styleEditProgramIdentity(program);
                manualPrograms[track]=std::move(program);
            }
            else appendWarning(editWarning,std::string(kTrackNames[track])+": saved Sound slot is unavailable or belongs to a different source; track remains silent");
        }
    }
    // Fault only this selection's entry pages before publishing it. Do not
    // hold the host control mutex across cold storage I/O: mixer/GUI snapshots
    // and independent controls must remain available while preparation runs.
    std::vector<sampler::ProgramPtr> entryPrograms;
    if(prepared&&read&&read->valid&&imported.style->nativeKorg)
        entryPrograms=styleEntryPrograms(*read,prepared->programs);
    for(const auto& program:manualPrograms)if(program)entryPrograms.push_back(program);
    (void)arranger::warmPa5xSamplePrograms(entryPrograms);
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
    auto* context=impl_->newContext(player);
    if(haveEdit){context->savedOptions=true;context->savedAutoFill=edit.autoFill;context->savedElement=edit.element;context->keyboardSets=edit.keyboardSets;}
    auto freshBase=std::make_shared<sampler::EngineState>(*impl_->state[player]);auto freshViews=impl_->tracks[player];
    (haveEdit?edit.effects:StyleFxRack{}).apply(freshBase->combi);
    if(read&&(!haveEdit||edit.effects.sourceEffects))applyOriginalStyleEffects(freshBase->combi,*read);
    if(read)applyOriginalStyleTracks(freshBase->combi,*read,haveEdit?&edit.effects.channels:nullptr);
    const auto savedMute=static_cast<unsigned>(imported.style->initialMuteMask&imported.style->initialMuteKnownMask);
    for(int track=0;track<8;++track){
        auto& part=freshBase->combi.part(track);part.levelDb=0;part.pan=0;part.mute=(savedMute&(1U<<track))!=0;
        auto& view=freshViews[track];
        // A fixed SET assignment and note balance belong to a single Style.
        if(view.soundSettings.setAddress>=0){part.program.reset();part.enabled=false;part.soundSlotId=0;
            view.assigned=false;view.originalSoundRouted=false;view.soundSlot=0;view.soundName="Unassigned";}
        view.soundSettings={};view.volumeDb=0;view.pan=0;view.mute=part.mute;view.mixOverrideMask=0;
        if(haveEdit){const auto& saved=edit.tracks[static_cast<std::size_t>(track)];
            if((saved.mask&kMixVolume)!=0)part.levelDb=saved.db;
            if((saved.mask&kMixPan)!=0)part.pan=saved.pan;
            if((saved.mask&kMixMute)!=0)part.mute=saved.mute;
            view.volumeDb=part.levelDb;view.pan=part.pan;view.mute=part.mute;view.mixOverrideMask=static_cast<std::uint8_t>(saved.mask);
        }
    }
    std::unique_ptr<Impl::RoutingPlan> value;
    if(prepared&&read&&read->valid&&imported.style->nativeKorg){
        std::set<std::uint32_t> needed;
        for(const auto& section:read->sections)if(section.available)
            for(const auto& track:section.tracks)for(const auto& cv:track.cvs)if(cv.available&&cv.hasNotes)
                for(const auto& change:cv.soundChanges){Impl::OriginalAddress address{change.msb,change.lsb,change.program};if(address.complete())needed.insert(address.key());}
        std::vector<ArrangerOriginalProgram> programs;programs.reserve(needed.size());
        for(const auto address:needed){const auto found=prepared->programs.find(address);if(found==prepared->programs.end())continue;
            programs.push_back({static_cast<int>((address>>16)&127U),static_cast<int>((address>>8)&127U),static_cast<int>(address&127U),found->second});}
        (void)impl_->buildSamplePlan(player,context,read,bank,path,programs,prepared->warnings,true,freshBase,freshViews,&value);
    }else{
        value=std::make_unique<Impl::RoutingPlan>();value->styleOwner=imported.style;value->read=read;value->setBank=bank;value->path=path;
        value->views=freshViews;auto base=freshBase;
        if(imported.style->nativeKorg)for(int track=0;track<8;++track){auto& part=base->combi.part(track);part.program.reset();part.enabled=false;part.soundSlotId=0;
            auto& view=value->views[track];view.assigned=false;view.originalSoundRouted=false;view.soundSlot=0;view.soundName="Unassigned";}
        value->baseState=std::move(base);
    }
    if(!value){impl_->error="The Style sample graph could not be prepared";return false;}
    value->sourceEditIdentity=identity;value->savedStyleName=haveEdit?edit.name:std::string{};value->savedStyleBpm=haveEdit?edit.bpm:0;value->savedStyleBank=haveEdit?savedBank:0;value->savedStylePosition=haveEdit?savedPosition:0;
    appendWarning(value->warnings,editWarning);
    if(haveEdit){
        auto combined=std::make_shared<sampler::EngineState>(*value->baseState);
        for(int track=0;track<8;++track){const auto index=static_cast<std::size_t>(track);const auto& saved=edit.tracks[index];
            value->fixedSoundIdentities[index]=saved.programIdentity;
            value->views[index].soundSettings=saved.soundSettings;
            if(saved.binding==1)continue;
            value->trackMask=static_cast<std::uint8_t>(value->trackMask&~(1U<<track));value->required[index].clear();
            auto& part=combined->combi.part(track);auto& view=value->views[index];
            part.program=manualPrograms[index];part.enabled=part.program!=nullptr;part.soundSlotId=static_cast<std::uint16_t>(saved.slot);
            part.name=part.program?part.program->name:kTrackNames[track];view.soundSlot=saved.slot;view.assigned=part.enabled;
            view.originalSoundRouted=false;view.soundName=part.program?part.program->name:"Unassigned";
        }
        value->baseState=std::move(combined);
    }
    if(haveEdit){value->ranges=edit.effects.ranges;value->guitars=edit.effects.guitars;}
    value->fillModes=haveEdit?edit.effects.fillModes:std::array<int,5>{};
    const auto* plan=impl_->retainPlan(player,std::move(value),context);if(!plan)return false;
    if(!impl_->engine.stageStyle(player,imported.style,plan->sampleMode,context)){impl_->error="Style staging failed validation";return false;}
    impl_->stagedContexts[player]=context;impl_->savedSyncStartPending[player]=false;
    if(impl_->pendingRestoreIntent)impl_->persistentRestoreContexts[player]=context;
    if(!impl_->engine.snapshot(player).playing)impl_->adoptControlPlan(player,plan);
    impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    impl_->error.clear();return true;
}

bool ArrangerHost::installKorgSetBank(std::shared_ptr<const arranger::Pa5xSetBank> bank){
    if(!bank)return false;
    const auto status=bank->status();
    std::lock_guard<std::mutex> lock(impl_->control);
    if(!status.recognized||status.cancelled||(!status.indexed&&!status.soundDirectoryComplete&&bank->sounds().empty())){
        impl_->error="The selected KST Sound directory was not completed";return false;
    }
    // Existing players retain their own source bank/read snapshot. Opening a
    // second SET must not rename an already loaded Style's original Sounds.
    if(impl_->preparedSetSamples && impl_->preparedSetSamples->bank.get()!=bank.get()){
        impl_->rememberPreparedSet(impl_->preparedSetSamples);impl_->preparedSetSamples.reset();
    }
    if(impl_->korgSetBank.get()!=bank.get())impl_->styleReadCache.clear();
    impl_->korgSetBank=std::move(bank);impl_->keyboardRead.reset();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);return true;
}
bool ArrangerHost::installKorgSampleBank(std::shared_ptr<const arranger::Pa5xSetBank> bank,
        const std::vector<ArrangerOriginalProgram>& programs,const std::vector<std::string>& warnings,bool hasPerformanceCatalog){
    if(!bank)return false;
    const auto status=bank->status();
    if(!status.recognized||status.cancelled||(!hasPerformanceCatalog&&!status.indexed&&!status.soundDirectoryComplete&&bank->sounds().empty())){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="The selected KST sample bank is incomplete";return false;
    }
    auto prepared=std::make_shared<Impl::PreparedSetSamples>();prepared->bank=bank;prepared->warnings=warnings;
    for(auto& message:prepared->warnings)
        if(message=="Temporary User sample playback: original Korg envelopes, filters, effects and choke groups are not recreated")
            message="Temporary User sample playback: original Korg envelopes, filters and effects are not recreated";
    std::set<std::uint32_t> ambiguous;
    const auto warn=[&](const std::string& message){
        if(prepared->warnings.size()<16U && std::find(prepared->warnings.begin(),prepared->warnings.end(),message)==prepared->warnings.end())
            prepared->warnings.push_back(message);
    };
    for(const auto& program:programs){
        Impl::OriginalAddress address{program.msb,program.lsb,program.program};
        if(!address.complete()||!playableSampleProgram(program.sound)){
            warn("A prepared SET Program had no valid address/playable sample audio and was skipped");continue;
        }
        if(ambiguous.count(address.key())!=0)continue;
        if(!prepared->programs.emplace(address.key(),program.sound).second){
            prepared->programs.erase(address.key());ambiguous.insert(address.key());
            warn("Conflicting SET sample Programs for one original address remain silent");
        }
    }
    std::lock_guard<std::mutex> lock(impl_->control);
    DrumSamples availableSamples;
    for(auto& entry:prepared->programs){
        const auto id=entry.first;
        const auto* source=bank->findSampleSound(static_cast<int>(id>>16),static_cast<int>((id>>8)&127U),static_cast<int>(id&127U));
        if(!source || source->descriptor.kind!=arranger::Pa5xPcgSoundKind::DrumKit)continue;
        // Startup may restore a prepared graph written before group import.
        // Derive its source metadata from the retained original key records,
        // sharing every sample/layer resource and applying user edits afterward.
        if(const auto groups=arranger::buildPa5xDrumKeyGroups(source->drumKit)){
            auto imported=std::make_shared<sampler::Program>(*entry.second);
            imported->drumKeyGroups=groups;entry.second=std::move(imported);
        }else warn("Original Drum Kit group numbers unavailable for "+source->descriptor.name);
        prepared->originalKits.emplace(id,entry.second);
        if(impl_->styleEditStorage.empty())continue;
        DrumKitDraft draft;draft.original=entry.second;
        draft.identity=drumIdentity(status.rootPath,id,*draft.original);
        std::string text;
        const auto path=drumEditFile(impl_->styleEditStorage,draft.identity);
        if(::access(path.c_str(),F_OK)!=0)continue;
        if(availableSamples.empty())availableSamples=drumSamples(prepared->programs);
        if(readStyleEditFile(path,text,16U*1024U*1024U)&&decodeDrumEdit(text,availableSamples,draft)){
            auto edited=draft.makeProgram();
            if(playableSampleProgram(edited)){entry.second=std::move(edited);continue;}
        }
        warn("Could not restore drum edits for "+draft.original->name);
    }
    // Existing players retain their selected subset/graphs independently. A
    // newly opened SET becomes the source only for subsequently chosen Styles.
    if(impl_->korgSetBank.get()!=bank.get())impl_->styleReadCache.clear();
    impl_->rememberPreparedSet(impl_->preparedSetSamples);impl_->rememberPreparedSet(prepared);
    impl_->korgSetBank=std::move(bank);impl_->preparedSetSamples=std::move(prepared);
    impl_->keyboardRead.reset();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();return true;
}
std::shared_ptr<const arranger::Pa5xStyleRead> ArrangerHost::styleRead(int player) const{
    if(!playerOk(player))return {};
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);return impl_->styleReads[player];
}
std::shared_ptr<const arranger::Pa5xSetBank> ArrangerHost::styleBank(int player) const {
    if (!playerOk(player)) return {};
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);return impl_->styleBanks[player];
}
bool ArrangerHost::readKeyboardSet(const std::string& path){
    std::shared_ptr<const arranger::Pa5xSetBank> bank;
    {std::lock_guard<std::mutex> lock(impl_->control);bank=impl_->korgSetBank;}
    bank=bankForPath(std::move(bank),path);
    auto read=std::make_shared<arranger::Pa5xKeyboardSetRead>(arranger::readPa5xKeyboardSet(path,bank.get()));
    std::lock_guard<std::mutex> lock(impl_->control);
    if(!read->valid){impl_->keyboardRead.reset();impl_->error=read->error.empty()?"Keyboard Set could not be read":read->error;return false;}
    impl_->keyboardRead=std::move(read);impl_->error.clear();return true;
}
std::shared_ptr<const arranger::Pa5xKeyboardSetRead> ArrangerHost::keyboardSetRead() const{
    std::lock_guard<std::mutex> lock(impl_->control);return impl_->keyboardRead;
}
bool ArrangerHost::inspectDrumKitEdit(const std::string& identity,const std::string& text){
    if(identity.size()!=64U||text.empty()||text.size()>16U*1024U*1024U||
       !std::all_of(identity.begin(),identity.end(),[](unsigned char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');}))return false;
    DrumKitDraft draft;draft.identity=identity;
    return decodeDrumEdit(text,{},draft,false);
}
bool ArrangerHost::openDrumKit(const std::string& root,int msb,int lsb,int program,DrumKitDraft& draft){
    std::lock_guard<std::mutex> lock(impl_->control);
    const Impl::OriginalAddress address{msb,lsb,program};const auto bank=impl_->preparedSetSamples;
    if(!address.complete()||!bank||bank->bank->status().rootPath!=root){impl_->error="Select the loaded SET";return false;}
    const auto original=bank->originalKits.find(address.key());
    if(original==bank->originalKits.end()){impl_->error="This kit has no prepared User drum samples";return false;}
    DrumKitDraft next;next.original=original->second;next.current=bank->programs.at(address.key());
    next.root=root;next.address=address.key();next.identity=drumIdentity(root,next.address,*next.original);
    if(next.current->layers.size()>16){impl_->error="This kit exceeds 16 velocity layers";return false;}
    fillDrumKeys(next,*next.current);
    auto sources=bank->programs;
    for(const auto& kit:bank->originalKits)sources[kit.first]=kit.second;
    const auto samples=drumSamples(sources);
    for(const auto& pair:samples)next.samples.push_back(pair.second);
    std::stable_sort(next.samples.begin(),next.samples.end(),[](const auto& a,const auto& b){return a->name<b->name;});
    draft=std::move(next);return true;
}
bool ArrangerHost::writeDrumKit(DrumKitDraft& draft){
    std::lock_guard<std::mutex> lock(impl_->control);
    const auto bank=impl_->preparedSetSamples;
    if(!bank||bank->bank->status().rootPath!=draft.root||!bank->programs.count(draft.address)||
       bank->programs.at(draft.address)!=draft.current){impl_->error="The source kit changed. Reopen it before writing";return false;}
    const auto fresh=draft.makeProgram();
    if(!playableSampleProgram(fresh)){impl_->error="Keep at least one assigned drum sample";return false;}
    const auto folder=styleEditJoin(impl_->styleEditStorage,"DrumKits");
    if(impl_->styleEditStorage.empty()||!styleEditDirectories(folder)||
       !styleEditAtomicWrite(drumEditFile(impl_->styleEditStorage,draft.identity),encodeDrumEdit(draft))){
        impl_->error="Cannot save this drum kit in app storage";return false;
    }
    auto edited=std::make_shared<Impl::PreparedSetSamples>(*bank);edited->programs[draft.address]=fresh;
    impl_->preparedSetSamples=edited;
    for(auto& b:impl_->restoreSampleBanks)if(b==bank)b=edited;
    for(auto& remembered:impl_->keyboardPrograms)if(remembered.sound==draft.current)remembered.sound=fresh;
    bool updatedAll=true;
    for(int player=0;player<2;++player){
        impl_->synchronizeCommitted(player);
        for(const auto& ctx:impl_->retainedStyleContexts){
            if(ctx->player!=player)continue;
            const auto* plan=ctx->latest.load(std::memory_order_seq_cst);
            if(!plan)continue;
            auto replacement=std::make_unique<Impl::RoutingPlan>(*plan);
            bool changed=false;
            auto match=replacement->programs.find(draft.address);
            if(match!=replacement->programs.end() && (match->second==draft.current ||
               (plan->setBank && plan->setBank->status().rootPath==draft.root &&
                drumIdentity(draft.root,draft.address,*match->second)==draft.identity))){
                match->second=fresh;changed=true;
            }
            auto base=std::make_shared<sampler::EngineState>(*plan->baseState);
            for(int t=0;t<8;++t)if(base->combi.part(t).program==draft.current){base->combi.part(t).program=fresh;changed=true;}
            if(!changed)continue;
            replacement->baseState=base;
            const auto* next=impl_->retainPlan(player,std::move(replacement),ctx.get());
            if(!next){updatedAll=false;continue;}
            if(ctx.get()==impl_->controlContexts[player])impl_->adoptControlPlan(player,next);
        }
        impl_->collectPlans();
    }
    draft.current=fresh;draft.dirty=false;impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    impl_->error=updatedAll?"":"Kit saved. Reselect the Style to refresh its routing";return true;
}
bool ArrangerHost::auditionDrumKit(DrumKitDraft& draft,int key,int velocity){
    if(key< -1||key>127||(key>=0&&(velocity<1||velocity>127)))return false;
    if(!draft.original||draft.original->layers.empty())return false;
    for(const auto& group:draft.drumKeyGroups)if(!group.valid())return false;
    for(const auto& zones:draft.keys)for(const auto& zone:zones)if(!zone.zone.sample)return false;
    // Check the complete editable reference/parameter record. Key selection
    // itself is not an edit, so alternating keys shares one immutable Program.
    const auto signature=encodeDrumEdit(draft);
    if(!draft.preview||draft.previewSignature!=signature){
        auto next=draft.makeProgram();if(!playableSampleProgram(next))return false;
        draft.preview=std::move(next);draft.previewSignature=signature;
    }
    std::lock_guard<std::mutex> lock(impl_->control);
    if(impl_->previewState->combi.part(0).program!=draft.preview){
        (void)impl_->previewSynth.postPanic();
        auto state=std::make_shared<sampler::EngineState>();
        for(int part=0;part<sampler::kPartCount;++part)state->combi.part(part).enabled=false;
        state->global.masterGainDb=0.0F;
        auto& part=state->combi.part(0);part.enabled=true;part.program=draft.preview;part.damperEnabled=false;
        part.expressionEnabled=false;impl_->previewState=state;impl_->previewSynth.setState(state);
        impl_->previewProgram.reset();impl_->previewView={};
    }
    draft.previewNeedsRefresh=false;
    return key<0||impl_->previewSynth.postNoteOn(0,static_cast<std::uint8_t>(key),static_cast<std::uint8_t>(velocity));
}
bool ArrangerHost::setDrumKitMidiAudition(DrumKitDraft& draft,bool enabled){
    if(!enabled){stopPcmPreview();return true;}
    if(!auditionDrumKit(draft,-1,0)){stopPcmPreview();return false;}
    impl_->drumKitMidiAudition.store(true,std::memory_order_release);return true;
}
bool ArrangerHost::drumKitMidiAuditionEnabled() const noexcept {
    return impl_->drumKitMidiAudition.load(std::memory_order_acquire);
}
bool ArrangerHost::routeDrumKitPreviewMidi(std::uint8_t status,std::uint8_t key,std::uint8_t value) noexcept {
    if(!impl_->drumKitMidiAudition.load(std::memory_order_acquire))return false;
    const auto kind=status&0xf0U;
    if(kind==0x90U&&value!=0U){
        const auto channel=static_cast<unsigned>(status&15U);
        if(impl_->externalNotesFiltered.load(std::memory_order_relaxed)||
           (impl_->externalChannels.load(std::memory_order_relaxed)&(1U<<channel))==0U)return true;
        impl_->editorNote.store(((key&127U)<<7U)|(value&127U),std::memory_order_relaxed);
        (void)impl_->previewSynth.postNoteOn(0,key,value);
        // Stop can race a MIDI producer after it observed the armed flag.
        // Place a final release after any late attack in that case.
        if(!impl_->drumKitMidiAudition.load(std::memory_order_acquire))(void)impl_->previewSynth.postPanic();
        return true;
    }
    // Releases continue into the normal keyboard/chord engine too: notes held
    // before enabling the preview must still receive their original NoteOff.
    if(kind==0x80U||(kind==0x90U&&value==0U))(void)impl_->previewSynth.postNoteOff(0,key,kind==0x90U?64U:value);
    if(kind==0xb0U&&(key==120U||key==123U))(void)impl_->previewSynth.postPanic();
    return false;
}
bool ArrangerHost::auditionSetSound(sampler::ProgramPtr program,int key,int velocity){
    if(!program||key<0||key>127||velocity<1||velocity>127)return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->drumKitMidiAudition.store(false,std::memory_order_release);
    (void)impl_->previewSynth.postPanic();
    auto state=std::make_shared<sampler::EngineState>(*impl_->previewState);
    auto& part=state->combi.part(0);part.enabled=true;part.program=std::move(program);part.damperEnabled=false;
    part.expressionEnabled=false;impl_->previewState=state;impl_->previewSynth.setState(state);
    impl_->previewProgram.reset();impl_->previewView={};
    return impl_->previewSynth.postNoteOn(0,static_cast<std::uint8_t>(key),static_cast<std::uint8_t>(velocity));
}
sampler::ProgramPtr ArrangerHost::preparedKeyboardSound(int msb,int lsb,int program,
                                                       const std::string& sourcePath) const {
    const Impl::OriginalAddress address{msb,lsb,program};
    if(!address.complete())return {};
    std::lock_guard<std::mutex> lock(impl_->control);
    return impl_->keyboardProgramFor(address,sourcePath).sound;
}
bool ArrangerHost::retainPreparedKeyboardSound(int part,int msb,int lsb,int program,
                                              const std::string& sourcePath){
    std::lock_guard<std::mutex> lock(impl_->control);
    if(part<0||part>=static_cast<int>(impl_->keyboardPrograms.size())){
        impl_->error="Invalid keyboard part for Sound provenance";return false;
    }
    if(msb== -1&&lsb== -1&&program== -1){
        impl_->keyboardPrograms[static_cast<std::size_t>(part)]={};impl_->error.clear();return true;
    }
    const Impl::OriginalAddress address{msb,lsb,program};
    if(!address.complete()){
        impl_->error="The keyboard Sound provenance has an incomplete original address";return false;
    }
    auto binding=impl_->keyboardProgramFor(address,sourcePath);
    if(!binding.sound){
        impl_->error="The original keyboard User Sound is not prepared for its exact SET";return false;
    }
    impl_->keyboardPrograms[static_cast<std::size_t>(part)]=std::move(binding);
    impl_->error.clear();return true;
}
bool ArrangerHost::prepareKeyboardSet(const std::string& path,ArrangerKeyboardSet& result,int midiChannel,
                                      bool keyboardSplitEnabled,bool allowSilent) {
    const auto sourceFile=originalResourceFilePath(path);
    if(sourceFile!=path&&!arranger::paKeyboardLocation(path)) {
        const auto reject=[&](const std::string& message){
            std::lock_guard<std::mutex> lock(impl_->control);impl_->error=message;return false;
        };
        const auto internalPath=path.substr(sourceFile.size()+2);
        std::shared_ptr<const arranger::Pa5xStyleRead> style;
        std::shared_ptr<const arranger::Pa5xSetBank> bank;
        {
            std::lock_guard<std::mutex> lock(impl_->control);
            const auto matches=[&](const std::shared_ptr<const Impl::PreparedSetSamples>& value){
                return value&&value->bank&&bankForPath(value->bank,sourceFile);
            };
            if(matches(impl_->preparedSetSamples))bank=impl_->preparedSetSamples->bank;
            else for(auto it=impl_->restoreSampleBanks.rbegin();it!=impl_->restoreSampleBanks.rend();++it)
                if(matches(*it)){bank=(*it)->bank;break;}
            if(!bank)bank=bankForPath(impl_->korgSetBank,sourceFile);
        }
        // Playback keeps its immutable active graph. A virtual resource recall
        // must independently validate today's parent revision before pairing
        // embedded metadata with any later disk-based source fingerprint.
        const auto key=detail::Pa5xStyleReadCache::keyFor(sourceFile,bank);
        if(!key.valid)return reject("The original Style containing this Keyboard Set is unavailable");
        {
            std::lock_guard<std::mutex> lock(impl_->control);style=impl_->styleReadCache.find(key);
        }
        const bool fromCache=style!=nullptr;
        if(!style)style=std::make_shared<arranger::Pa5xStyleRead>(arranger::readPa5xStyleFile(sourceFile,bank.get()));
        const auto after=detail::Pa5xStyleReadCache::keyFor(sourceFile,bank);
        if(!after.valid||key.path!=after.path||key.device!=after.device||key.inode!=after.inode||key.bytes!=after.bytes||
           key.modifiedSeconds!=after.modifiedSeconds||key.modifiedNanos!=after.modifiedNanos||
           key.changedSeconds!=after.changedSeconds||key.changedNanos!=after.changedNanos)
            return reject("The original Style changed while its embedded Keyboard Set was being read; select it again");
        if(!style->valid||!style->keyboardSetMappingKnown)
            return reject("The original Style's embedded Keyboard Set positions cannot be read exactly");
        if(!fromCache){std::lock_guard<std::mutex> lock(impl_->control);(void)impl_->styleReadCache.insert(key,style);}
        for(const auto& slot:style->keyboardSets)if(slot.resourcePath==internalPath) {
            if(!slot.available||!slot.resourceBytes)return reject(slot.error.empty()?"The original embedded Keyboard Set is unavailable":slot.error);
            return prepareKeyboardSetBytes(*slot.resourceBytes,path,result,midiChannel,keyboardSplitEnabled,allowSilent);
        }
        return reject("The saved embedded Keyboard Set is no longer declared by its original Style");
    }
    return prepareKeyboardSetResource(path,nullptr,result,midiChannel,keyboardSplitEnabled,allowSilent);
}
bool ArrangerHost::prepareKeyboardSetBytes(const std::vector<std::uint8_t>& bytes,const std::string& sourcePath,
                                          ArrangerKeyboardSet& result,int midiChannel,bool keyboardSplitEnabled,bool allowSilent) {
    return prepareKeyboardSetResource(sourcePath,&bytes,result,midiChannel,keyboardSplitEnabled,allowSilent);
}
bool ArrangerHost::prepareStyleKeyboardSet(int player,int position,ArrangerKeyboardSet& result,int midiChannel,
                                          bool keyboardSplitEnabled,bool allowSilent) {
    const auto reject=[&](const std::string& message){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error=message;return false;
    };
    if(!playerOk(player)||position<0||position>=4)return reject("Invalid original Style Keyboard Set position");
    const auto style=styleRead(player);
    if(!style||!style->valid||!style->keyboardSetMappingKnown)
        return reject("The selected Style has no supported exact Keyboard Set position mapping");
    const auto& slot=style->keyboardSets[static_cast<std::size_t>(position)];
    if(!slot.available||(!slot.resourceBytes&&!arranger::paStyleSlot(style->sourcePath)))
        return reject(slot.error.empty()?"The selected original Style Keyboard Set is unavailable":slot.error);
    const auto identity=style->sourcePath+"!/"+slot.resourcePath;
    return prepareKeyboardSet(identity,result,midiChannel,keyboardSplitEnabled,allowSilent);
}
bool ArrangerHost::prepareKeyboardSetResource(const std::string& path,const std::vector<std::uint8_t>* bytes,
                                             ArrangerKeyboardSet& result,int midiChannel,bool keyboardSplitEnabled,bool allowSilent) {
    const auto reject=[&](const std::string& message){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error=message;return false;
    };
    if(midiChannel<0||midiChannel>15)return reject("Keyboard input MIDI channel is invalid");
    std::shared_ptr<const Impl::PreparedSetSamples> prepared;
    int globalSplit=60;
    {
        std::lock_guard<std::mutex> lock(impl_->control);
        const auto matches=[&](const std::shared_ptr<const Impl::PreparedSetSamples>& value){
            return value&&value->bank&&bankForPath(value->bank,path);
        };
        if(matches(impl_->preparedSetSamples))prepared=impl_->preparedSetSamples;
        else for(auto it=impl_->restoreSampleBanks.rbegin();it!=impl_->restoreSampleBanks.rend();++it)
            if(matches(*it)){prepared=*it;break;}
        globalSplit=impl_->globalSplit.load(std::memory_order_relaxed);
    }
    if(!prepared)return reject("Load the Keyboard Set's original KST sample bank before selecting it");
    auto read=std::make_shared<arranger::Pa5xKeyboardSetRead>(bytes!=nullptr?
        arranger::readPa5xKeyboardSetBytes(*bytes,path,prepared->bank.get()):
        arranger::readPa5xKeyboardSet(path,prepared->bank.get()));
    if(!read->valid)return reject(read->error.empty()?"The Keyboard Set is not valid":read->error);
    if(read->upperOctaveTransposeKnown&&(read->upperOctaveTranspose< -4||read->upperOctaveTranspose>4))
        return reject("The saved Upper octave exceeds the supported range");
    ArrangerKeyboardSet next;next.read=read;next.combi.name=read->name;
    if(bytes!=nullptr)next.sourceBytes=std::make_shared<const std::vector<std::uint8_t>>(*bytes);
    next.warnings=read->issues;
    const auto warn=[&](const std::string& message){
        if(next.warnings.size()<32U&&std::find(next.warnings.begin(),next.warnings.end(),message)==next.warnings.end())
            next.warnings.push_back(message);
    };
    if(read->useGlobalSplit==0&&read->splitPoint>=1&&read->splitPoint<=127)next.splitPoint=read->splitPoint;
    else if(read->useGlobalSplit==1)next.splitPoint=globalSplit;
    else warn("No explicit saved split selection was available; the global split template is retained");
    const int split=next.splitPoint>=0?next.splitPoint:globalSplit;
    // A fresh performance intentionally leaves additional SILVETON Upper and
    // engine slots silent; their capacity remains available to subsequent edits.
    constexpr std::array<int,4> roles{{6,0,1,2}};
    for(std::size_t index=0;index<read->parts.size();++index){
        const auto& source=read->parts[index];auto& upper=next.combi.part(roles[index]);
        upper.name=source.soundName.empty()?source.name:source.soundName;
        upper.midiChannel=static_cast<std::uint8_t>(midiChannel);
        upper.independentLayerRanges=false;
        if(source.present&&!source.recallSetupValid)
            return reject(source.name+": conflicting or invalid Keyboard Set recall setup");
        if(!source.present||!source.addressKnown){warn(source.name+": no explicit playable Sound assignment; the part is silent");continue;}
        if(source.partTranspositionDeclared&&source.partTranspositionRaw!=0&&
           (!source.sourceNativeTrack||!source.sourceNativeTrack->octaveTransposeKnown))
            warn(source.name+": the saved raw Pitch value has unverified units and is not applied");
        upper.keyLow=static_cast<std::uint8_t>(source.keyLow>=0?source.keyLow:0);
        upper.keyHigh=static_cast<std::uint8_t>(source.keyHigh>=0?source.keyHigh:127);
        upper.velocityLow=static_cast<std::uint8_t>(std::max(1,source.velocityLow>=0?source.velocityLow:1));
        upper.velocityHigh=static_cast<std::uint8_t>(source.velocityHigh>=0?source.velocityHigh:127);
        upper.mute=source.mute==1;
        upper.sourceVolumeRaw=source.volumeRaw;upper.sourcePanRaw=source.panRaw;upper.sourceExpressionRaw=source.expressionRaw;
        if(source.sourceNativeTrack)applyOriginalNativeTrack(upper,*source.sourceNativeTrack);
        if(source.pitchBendRangeSemitones>=0)
            upper.pitchBendRange=static_cast<std::int8_t>(source.pitchBendRangeSemitones);
        upper.sourceCoarseTuneRaw=source.coarseTuneRaw;
        upper.sourceFineTuneRaw=source.fineTuneRaw;
        upper.sourceSoundEdits=source.sourceSoundEdits;
        // Official Pa5X Performance Guide: CC91/93/94 are MFX1/2/3 sends.
        // Keep slot identity and normalize the saved MIDI value for SILVETON;
        // this does not select or claim the original Korg effect algorithms.
        if(source.masterFxSendRaw[0]>=0)upper.fxSend1=static_cast<float>(source.masterFxSendRaw[0])/127.0F;
        if(source.masterFxSendRaw[1]>=0)upper.fxSend2=static_cast<float>(source.masterFxSendRaw[1])/127.0F;
        if(source.masterFxSendRaw[2]>=0)upper.fxSend3=static_cast<float>(source.masterFxSendRaw[2])/127.0F;
        if(source.octaveTransposeKnown)upper.octave=static_cast<std::int8_t>(source.octaveTranspose);
        if(source.sourceNativeTrack){
            if(!source.sourceNativeTrack->detuneKnown)warn(source.name+": native detune encoding is unavailable");
            if(!source.sourceNativeTrack->octaveTransposeKnown)warn(source.name+": native octave encoding is unavailable");
        }
        // Use the same inclusive Lower boundary as chord recognition. Keep
        // the source ranges in read so later split edits can restore them.
        if(keyboardSplitEnabled){
            if(index==0)upper.keyHigh=static_cast<std::uint8_t>(std::min<int>(upper.keyHigh,split));
            else upper.keyLow=static_cast<std::uint8_t>(std::max<int>(upper.keyLow,split+1));
        }else if(index==0){
            upper.mute=true; // the Lower Sound is silent in Full keyboard mode
        }
        const bool rangeSilent=upper.keyLow>upper.keyHigh||upper.velocityLow>upper.velocityHigh;
        if(rangeSilent){
            // A valid source range can be outside the current split region.
            // Keep its prepared Program so expanding/changing SPLIT can restore
            // it without loading samples again. The original ranges stay in read.
            upper.keyLow=0;upper.keyHigh=127;upper.velocityLow=1;upper.velocityHigh=127;
            warn(source.name+": the saved range does not intersect the current keyboard zone; the part is silent");
        }
        const Impl::OriginalAddress address{source.msb,source.lsb,source.program};
        const auto found=prepared->programs.find(address.key());
        if(source.status!=arranger::Pa5xKeyboardSetSoundStatus::ExactUserSound||
           found==prepared->programs.end()||!playableSampleProgram(found->second)){
            warn(source.name+": "+arranger::pa5xKeyboardSetSoundStatusName(source.status)+
                 "; no prepared User sample Sound is available and the part is silent");continue;
        }
        upper.program=found->second;upper.soundSlotId=sampler::kNoSoundSlot;
        upper.commonProcessing=true;upper.enabled=!rangeSilent;
        upper.voiceMode=upper.program->legato?sampler::UpperVoiceMode::Legato:
            (upper.program->mono?sampler::UpperVoiceMode::Mono:sampler::UpperVoiceMode::Poly);
        upper.portamentoSec=upper.program->portamentoSec;
        ++next.playableParts;
    }
    if(next.playableParts==0&&!allowSilent)return reject("This Keyboard Set has no playable prepared User sample Sounds; the current keyboard setup is retained");
    read->soundActivationSupported=next.playableParts>0;
    applyOriginalKeyboardEffects(next.combi,*read);
    if(next.combi.sourceEffects)warn(next.combi.sourceEffects->summary());
    warn("User sample playback uses SILVETON processing; original Korg Sound DSP and unsupported controllers are not reproduced");
    {
        std::lock_guard<std::mutex> lock(impl_->control);impl_->keyboardRead=read;impl_->error.clear();
    }
    result=std::move(next);return true;
}
std::string ArrangerHost::lastError() const { std::lock_guard<std::mutex> lock(impl_->control); return impl_->error; }
bool ArrangerHost::pollPlayerVoices(int player,sampler::VoiceActivity& out) noexcept {
    return playerOk(player) && impl_->synth[player].pollVoiceActivity(out);
}

arranger::PlayerSnapshot ArrangerHost::liveTransport(int player) const noexcept {return impl_->engine.snapshot(player);}
float ArrangerHost::keyboardSourceTempo() const noexcept {
    const bool first=impl_->sourcePlaying[0].load(std::memory_order_relaxed);
    const bool second=impl_->sourcePlaying[1].load(std::memory_order_relaxed);
    const std::size_t owner=first!=second?(second?1U:0U):
        (impl_->xfade.load(std::memory_order_relaxed)>=0.5F?1U:0U);
    return impl_->sourceTempos[owner].load(std::memory_order_relaxed);
}
ArrangerPlayerView ArrangerHost::snapshot(int player) const {
    ArrangerPlayerView out;
    if (!playerOk(player)) return out;
    std::lock_guard<std::mutex> lock(impl_->control);
    const auto s=impl_->synchronizeCommitted(player);
    const auto* pending=impl_->stagedContexts[player];
    if(s.pendingStyleCommitToken)pending=static_cast<const Impl::StyleContext*>(s.pendingStyleCommitToken);
    if(pending&&pending!=s.styleCommitToken){
        if(const auto* queued=pending->latest.load(std::memory_order_seq_cst)){
            out.styleSwitchPending=true;out.pendingStylePath=queued->path;out.pendingStyleName=queued->style?queued->style->name:"";
        }
    }
    out.loaded = impl_->styles[player] != nullptr;
    const auto* style = impl_->styles[player].get();
    out.name = style != nullptr ? (impl_->savedStyleNames[player].empty()?style->name:impl_->savedStyleNames[player]) : "No Style";
    out.sourcePath = impl_->paths[player];
    if(const auto* context=impl_->controlContexts[player])out.styleSelectionSerial=context->serial;
    if(const auto* plan=impl_->controlAckPlans[player]){out.soundRevision=plan->noteMapRevision;out.fillModes=plan->context->readFillModes();}
    out.savedStyleBank=impl_->savedStyleBanks[player];out.savedStylePosition=impl_->savedStylePositions[player];
    out.tempoLock = impl_->engine.tempoLock();
    out.nativeKorgStyle = style != nullptr && style->nativeKorg;
    out.originalBpm = style != nullptr ? (impl_->savedStyleBpms[player]>0?impl_->savedStyleBpms[player]:style->tempoBpm) : 120.0;
    out.soundAssignmentsReady = style != nullptr;
    out.samplePlaybackMode = impl_->samplePlaybackMode[player];
    if(impl_->state[player]&&impl_->state[player]->combi.sourceEffects)
        appendWarning(out.playbackWarning,impl_->state[player]->combi.sourceEffects->summary());
    out.blockedTrackMask = s.blockedTrackMask;
    if (style != nullptr) for (const auto& warning : style->playbackWarnings) {
        if(out.samplePlaybackMode && (warning.find("Pitched Korg tracks play only at their exact recorded source chord")==0 ||
            warning.find("Native Korg track/CV timing is loaded; full Korg Sound")==0)) continue;
        appendWarning(out.playbackWarning, warning);
    }
    out.chordName = arranger::chordName(s.chord);
    out.playing = s.playing;
    out.syncStart = s.syncStart;
    out.autoFill = s.autoFill;
    out.autoFillMode = impl_->engine.autoFillMode();
    out.syncStop=s.syncStop;out.syncStartAutoOff=impl_->engine.syncStartAutoOff();
    out.loopElement=s.loopElement==arranger::Element::Count?-1:static_cast<int>(s.loopElement);
    out.fadeDirection=s.fadeDirection;out.fadeGain=s.fadeGain;
    out.fadeInSeconds=impl_->engine.fadeInSeconds();out.fadeOutSeconds=impl_->engine.fadeOutSeconds();
    out.memory = impl_->engine.memory();
    out.chordRecognitionMode = impl_->engine.recognitionMode();
    out.chordScanArea = impl_->engine.chordScanArea();
    out.splitEnabled = impl_->engine.splitEnabled();
    out.bassInversion = impl_->engine.bassInversion();
    out.damperLatch = impl_->engine.damperLatch();
    out.bpm = s.tempoBpm;
    out.bar = static_cast<int>(s.bar);
    out.beat = static_cast<int>(s.beat);
    out.transportMeasure = s.transportMeasure;
    out.numerator = s.numerator;
    out.denominator = s.denominator;
    out.split = impl_->engine.splitNote();
    out.globalSplit = impl_->globalSplit.load(std::memory_order_relaxed);
    out.scaleAssignment = impl_->scaleAssignment;
    out.element = static_cast<int>(s.element);
    out.pendingElement = s.queued == arranger::Element::Count ? -1 : static_cast<int>(s.queued);
    out.returnElement = static_cast<int>(s.returnVariation);
    out.elementName = arranger::elementName(s.element);
    out.pendingElementName = out.pendingElement < 0 ? "" : arranger::elementName(s.queued);
    if(style!=nullptr&&s.style!=style){
        out.playing=false;out.syncStart=false;out.pendingElement=-1;out.pendingElementName.clear();
        int initial=-1;
        for(int e=static_cast<int>(arranger::Element::Var1);e<=static_cast<int>(arranger::Element::Var4);++e)
            if(style->sections[static_cast<std::size_t>(e)].available){initial=e;break;}
        if(initial<0)for(std::size_t e=0;e<style->sections.size();++e)
            if(style->sections[e].available){initial=static_cast<int>(e);break;}
        if(initial>=0){out.element=initial;out.elementName=arranger::elementName(static_cast<arranger::Element>(initial));}
        if(!out.tempoLock)out.bpm=out.originalBpm;
        out.bar=out.beat=1;
    }
    if(style!=nullptr&&out.element>=0&&static_cast<std::size_t>(out.element)<style->sections.size()){
        const auto& selected=style->sections[static_cast<std::size_t>(out.element)];
        if(selected.available){out.numerator=selected.numerator;out.denominator=selected.denominator;}
    }
    out.tracks = impl_->tracks[player];
    const auto meter = impl_->synth[player].meters();
    for (int t = 0; t < 8; ++t) {
        out.tracks[t].peak = std::max(meter.upperPeakLeft[static_cast<std::size_t>(t)], meter.upperPeakRight[static_cast<std::size_t>(t)]);
        if (style != nullptr && !style->tracks[t].name.empty()) out.tracks[t].name = style->tracks[t].name;
        out.tracks[t].selectedCv = s.selectedCvs[static_cast<std::size_t>(t)];
        if(!out.playing&&style&&out.element>=0&&static_cast<std::size_t>(out.element)<style->sections.size()){
            const auto& pattern=style->sections[out.element].patterns[t];
            const auto type=static_cast<std::size_t>(s.chord.valid()?s.chord.type:arranger::ChordType::Major);
            out.tracks[t].selectedCv=pattern.present&&type<pattern.chordCv.size()?pattern.chordCv[type]:0;
        }
        out.tracks[t].playbackBlocked = (s.blockedTrackMask & (1U << t)) != 0U;
        if (style != nullptr) {
            const auto& source = style->tracks[t];
            out.tracks[t].addressKnown = source.addressKnown;
            out.tracks[t].addressVaries = source.addressVaries;
            if (source.addressKnown) {
                out.tracks[t].msb = source.msb;
                out.tracks[t].lsb = source.lsb;
                out.tracks[t].program = source.program;
            }
        }
        const auto& read=impl_->styleReads[player];
        if(read&&read->valid&&out.element>=0&&static_cast<std::size_t>(out.element)<read->sections.size()){
            auto& view=out.tracks[t];
            const auto& section=read->sections[static_cast<std::size_t>(out.element)];
            const auto& track=section.tracks[static_cast<std::size_t>(t)];
            view.addressKnown=false;view.originalSoundAddressComplete=false;
            view.msb=view.lsb=view.program=-1;
            int cvNumber=0;
            if(out.playing&&s.style==style)cvNumber=s.selectedCvs[static_cast<std::size_t>(t)];
            else if(style!=nullptr){
                const auto& pattern=style->sections[static_cast<std::size_t>(out.element)].patterns[static_cast<std::size_t>(t)];
                const auto chord=s.chord.valid()?static_cast<std::size_t>(s.chord.type):static_cast<std::size_t>(arranger::ChordType::Major);
                if(chord<pattern.chordCv.size())cvNumber=pattern.chordCv[chord];
            }
            if(cvNumber>=1&&cvNumber<=6&&track.cvs[static_cast<std::size_t>(cvNumber-1)].available){
                view.selectedCv=cvNumber;
                const auto& cv=track.cvs[static_cast<std::size_t>(cvNumber-1)];
                std::uint32_t tick=0;
                view.originalSoundAtCvStart=!out.playing;
                if(out.playing&&style!=nullptr&&style->ppq>0)
                    tick=static_cast<std::uint32_t>(static_cast<std::uint64_t>(s.cvTicks[static_cast<std::size_t>(t)])*track.ppq/style->ppq);
                const arranger::Pa5xStyleSoundChange* active=nullptr;
                for(std::uint8_t channel=0;channel<16;++channel){
                    const auto* candidate=cv.soundAt(channel,tick);
                    if(candidate==nullptr)continue;
                    if(active==nullptr)active=candidate;
                    else if(active->msb!=candidate->msb||active->lsb!=candidate->lsb||active->program!=candidate->program)
                        view.originalSoundMultiple=true;
                }
                if(view.originalSoundMultiple){view.originalSoundName="Multiple original Sounds";view.originalSoundStatus="Open Style contents for channel-specific Sound addresses";}
                else if(active!=nullptr){
                    view.msb=active->msb;view.lsb=active->lsb;view.program=active->program;
                    view.addressKnown=active->sound.addressComplete;
                    view.originalSoundAddressComplete=active->sound.addressComplete;
                    view.originalSoundName=active->sound.name;view.originalSoundPath=active->sound.path;
                    view.originalSoundStatus=originalStatus(active->sound.resolution);
                    if(view.originalSoundName.empty())view.originalSoundStatus=active->sound.message;
                }else view.originalSoundStatus="No original Sound address declared at this CV tick";
            }else{view.selectedCv=0;view.originalSoundStatus=track.present?"No available CV for this chord":"Track absent from selected section";}
        }
        auto& sourceView=out.tracks[t];
        sourceView.sourceVolumeRaw=sourceView.sourcePanRaw=sourceView.sourceExpressionRaw=-1;
        sourceView.sourceSoundEdits={};
        sourceView.sourceFxSendRaw.fill(-1);
        if(out.playing&&s.style==style){
            const auto* context=impl_->sourceMixContext[player].load(std::memory_order_acquire);
            if(context&&context==impl_->controlContexts[player]){
                const auto& current=impl_->sourceMix[player][t];
                sourceView.sourceVolumeRaw=current.volume.load(std::memory_order_relaxed);
                sourceView.sourcePanRaw=current.pan.load(std::memory_order_relaxed);
                sourceView.sourceExpressionRaw=current.expression.load(std::memory_order_relaxed);
                sourceView.sourceSoundEdits=current.readSoundEdits();
                for(std::size_t send=0;send<sourceView.sourceFxSendRaw.size();++send)
                    sourceView.sourceFxSendRaw[send]=current.sends[send].load(std::memory_order_relaxed);
                if(impl_->sourceMixContext[player].load(std::memory_order_acquire)!=context){
                    sourceView.sourceVolumeRaw=sourceView.sourcePanRaw=sourceView.sourceExpressionRaw=-1;
                    sourceView.sourceSoundEdits={};
                    sourceView.sourceFxSendRaw.fill(-1);
                }
            }
        }else if(style&&out.element>=0&&static_cast<std::size_t>(out.element)<style->sections.size()){
            sampler::SourceSoundEditReader soundEditReader;
            const auto readMix=[&](const arranger::MidiEvent& event){
                if((event.status&0xF0U)!=0xB0U)return;
                (void)soundEditReader.controller(sourceView.sourceSoundEdits,event.data1,event.data2);
                if(event.data1==7)sourceView.sourceVolumeRaw=event.data2;
                else if(event.data1==10)sourceView.sourcePanRaw=event.data2;
                else if(event.data1==11)sourceView.sourceExpressionRaw=event.data2;
                else if(const int send=originalFxSendSlot(event.data1);send>=0)sourceView.sourceFxSendRaw[static_cast<std::size_t>(send)]=event.data2;
            };
            const auto& selected=style->sections[static_cast<std::size_t>(out.element)];
            if(selected.nativePatterns){
                const auto& pattern=selected.patterns[static_cast<std::size_t>(t)];
                for(const auto& event:pattern.setupEvents)readMix(event);
                const auto cv=sourceView.selectedCv;
                if(cv>=1&&cv<=6)for(const auto& event:pattern.cvs[static_cast<std::size_t>(cv-1)].events){if(event.tick>0)break;readMix(event);}
            }else for(const auto& event:selected.events){if(event.tick>0)break;if(event.track==t)readMix(event);}
        }
        if (out.tracks[t].originalSoundRouted) {
            auto& track=out.tracks[t];
            if(out.samplePlaybackMode){
                bool ready=false;
                if(track.addressKnown && !track.originalSoundMultiple){
                    Impl::OriginalAddress address{track.msb,track.lsb,track.program};
                    const auto found=address.complete()?impl_->originalPrograms[player].find(address.key()):impl_->originalPrograms[player].end();
                    ready=found!=impl_->originalPrograms[player].end() && found->second &&
                        impl_->requiredOriginalPrograms[player][t].count(address.key())!=0;
                }
                track.assigned=ready;
                track.soundName=ready ? "Samples: " + track.originalSoundName : "No loaded samples";
                if(!ready)track.originalSoundStatus += "; no prepared sample audio for this address";
            }else if(!track.originalSoundName.empty())track.soundName=track.originalSoundName;
        }
        if (style != nullptr && style->tracks[t].used && !out.tracks[t].assigned)
            out.soundAssignmentsReady = false;
    }
    if (style != nullptr) for (std::size_t e = 0; e < arranger::kElementCount; ++e) out.available[e] = style->sections[e].available;
    if(out.samplePlaybackMode){
        out.soundAssignmentsReady=impl_->anyPreparedSampleProgram(player);
        appendWarning(out.playbackWarning,"Sample playback: available User PCM only; missing addresses remain silent. Sound DSP and chord transposition are simplified; effects/DNC are not reproduced. With no played chord, supported ACC patterns can audition recorded notes.");
        appendWarning(out.playbackWarning,impl_->samplePlaybackWarnings[player]);
    }else if (out.loaded && !out.soundAssignmentsReady)
        appendWarning(out.playbackWarning, "Assign a sound explicitly to every used Style track before playback.");
    if (out.nativeKorgStyle && !out.samplePlaybackMode && impl_->originalRoutingMask[player] == 0)
        appendWarning(out.playbackWarning, "Original Korg Sounds have not been prepared for audio playback.");
    std::string blockedTracks, varyingAddresses;
    for (int t = 0; t < 8; ++t) {
        if (out.tracks[t].playbackBlocked) {
            if (!blockedTracks.empty()) blockedTracks += ", ";
            blockedTracks += out.tracks[t].name;
        }
        if (out.tracks[t].addressVaries) {
            if (!varyingAddresses.empty()) varyingAddresses += ", ";
            varyingAddresses += out.tracks[t].name;
        }
    }
    if (!blockedTracks.empty())
        appendWarning(out.playbackWarning, "Not sounding: " + blockedTracks +
            ". The selected CV has no supported pattern or chord mapping for the current settings.");
    if (!varyingAddresses.empty())
        appendWarning(out.playbackWarning, "Original bank/program addresses vary by pattern or CV: " + varyingAddresses +
            (out.samplePlaybackMode ? ". Sample routing follows original Program Changes." : (impl_->originalRoutingMask[player] != 0 ? ". Prepared original Sound routing follows Program Changes." : ". Read addresses follow the selected section and CV.")));
    // Tempo automation and automatic section returns can change saved intent
    // without a UI command. Beats and meters never dirty the session.
    int savedElement=out.pendingElement>=0?out.pendingElement:out.element;
    if(savedElement>=static_cast<int>(arranger::Element::Fill1)&&savedElement<=static_cast<int>(arranger::Element::Fill4))
        savedElement=static_cast<int>(arranger::Element::Var1)+savedElement-static_cast<int>(arranger::Element::Fill1);
    if(!impl_->persistedTransportSeen[player]||impl_->persistedTempo[player]!=out.bpm||impl_->persistedElement[player]!=savedElement){
        impl_->persistedTransportSeen[player]=true;impl_->persistedTempo[player]=out.bpm;impl_->persistedElement[player]=savedElement;
        impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    }
    return out;
}

bool ArrangerHost::setTempo(int p, double bpm) { return std::isfinite(bpm) && impl_->command(arranger::CommandType::SetTempo, p, 0, std::clamp(bpm, 20.0, 400.0)); }
bool ArrangerHost::resetTempo(int player) {
    if(!playerOk(player))return false;
    double original=120;
    {
        std::lock_guard<std::mutex> lock(impl_->control);
        if(!impl_->styles[player]){impl_->error="Load a Style before resetting its tempo";return false;}
        original=impl_->savedStyleBpms[player]>0?impl_->savedStyleBpms[player]:impl_->styles[player]->tempoBpm;
    }
    return setTempo(player,original);
}
bool ArrangerHost::setTempoLock(bool enabled, int sourcePlayer) {
    if (!playerOk(sourcePlayer)) {
        std::lock_guard<std::mutex> lock(impl_->control);
        impl_->error = "Tempo Lock source player must be 0 or 1";
        return false;
    }
    return impl_->command(arranger::CommandType::SetTempoLock, sourcePlayer, 0, enabled ? 1 : 0);
}
bool ArrangerHost::toggleTempoLock(int player) {
    if(!playerOk(player)){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="Tempo Lock source player must be 0 or 1";return false;
    }
    return impl_->command(arranger::CommandType::ToggleTempoLock,player);
}
bool ArrangerHost::startStop(int p) {
    if (!playerOk(p)) return false;
    if (!impl_->engine.snapshot(p).playing) {
        if (!impl_->readyToStart(p)) return false;
        (void)impl_->synth[p].postPanic();
    }
    return impl_->command(arranger::CommandType::TogglePlay, p);
}
bool ArrangerHost::start(int p) {
    if (!playerOk(p)) return false;
    if (!impl_->readyToStart(p)) return false;
    if (!impl_->engine.snapshot(p).playing) (void)impl_->synth[p].postPanic();
    return impl_->command(arranger::CommandType::Play, p);
}
bool ArrangerHost::startWithTempo(int player,double bpm) {
    if(!playerOk(player)||!std::isfinite(bpm)||bpm<20||bpm>400||!impl_->readyToStart(player))return false;
    std::shared_ptr<const arranger::Style> style;
    {std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);style=impl_->styles[player];}
    if(!style)return false;
    if(!impl_->engine.snapshot(player).playing)(void)impl_->synth[player].postPanic();
    return impl_->command(arranger::CommandType::StartWithTempo,player,0,bpm,style.get());
}
bool ArrangerHost::resetPosition(int player) {
    if(!playerOk(player))return false;
    std::shared_ptr<const arranger::Style> style;
    {std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);style=impl_->styles[player];}
    if(!style)return false;
    return impl_->command(arranger::CommandType::ResetPosition,player,0,0,style.get());
}
bool ArrangerHost::stop(int p) { return impl_->command(arranger::CommandType::Stop, p); }
bool ArrangerHost::selectElement(int p, int e) { return e >= 0 && e < static_cast<int>(arranger::kElementCount) && impl_->command(arranger::CommandType::SelectElement, p, e); }
bool ArrangerHost::setSyncStart(int p, bool b) {
    if (!playerOk(p)) return false;
    if (b && !impl_->readyToStart(p)) return false;
    { std::lock_guard<std::mutex> lock(impl_->control); impl_->savedSyncStartPending[p] = false; }
    if (b && !impl_->engine.snapshot(p).playing) (void)impl_->synth[p].postPanic();
    return impl_->command(arranger::CommandType::SetSyncStart, p, 0, b ? 1 : 0);
}
bool ArrangerHost::setSyncStop(int player,bool enabled) {
    if(!playerOk(player)||(enabled&&!impl_->readyToStart(player)))return false;
    return impl_->command(arranger::CommandType::SetSyncStop,player,0,enabled?1.0:0.0);
}
bool ArrangerHost::toggleSyncStop(int player) {
    if(!playerOk(player))return false;
    const bool ready=impl_->readyToStart(player);const auto current=impl_->engine.snapshot(player);
    if(!ready&&!current.syncStop)return false;
    return impl_->command(arranger::CommandType::ToggleSyncStop,player,0,ready?1.0:-1.0);
}
bool ArrangerHost::setSyncStartAutoOff(bool enabled) {return impl_->command(arranger::CommandType::SetSyncStartAutoOff,0,0,enabled?1.0:0.0);}
bool ArrangerHost::toggleSyncStartAutoOff() {return impl_->command(arranger::CommandType::ToggleSyncStartAutoOff);}
bool ArrangerHost::toggleSectionLoop(int player) {return impl_->command(arranger::CommandType::ToggleSectionLoop,player);}
bool ArrangerHost::toggleFade(int player) {
    if(!playerOk(player))return false;
    const auto current=impl_->engine.snapshot(player);
    if(!current.playing&&!impl_->readyToStart(player))return false;
    std::shared_ptr<const arranger::Style> style;
    {std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);style=impl_->styles[player];}
    if(!style)return false;
    if(!current.playing)(void)impl_->synth[player].postPanic();
    return impl_->command(arranger::CommandType::Fade,player,0,0,style.get());
}
bool ArrangerHost::setFadeTimes(float inSeconds,float outSeconds) {
    if(!std::isfinite(inSeconds)||!std::isfinite(outSeconds)||inSeconds<0.1F||inSeconds>60||outSeconds<0.1F||outSeconds>60){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="SILVETON Fade times must be between 0.1 and 60 seconds";return false;
    }
    return impl_->command(arranger::CommandType::SetFadeTimes,0,static_cast<int>(std::lround(outSeconds*1000.0F)),inSeconds);
}
bool ArrangerHost::adjustFadeTimes(float inDelta,float outDelta) {
    if(!std::isfinite(inDelta)||!std::isfinite(outDelta)||inDelta< -60||inDelta>60||outDelta< -60||outDelta>60){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="Fade adjustments must be between -60 and 60 seconds";return false;
    }
    return impl_->command(arranger::CommandType::AdjustFadeTimes,0,static_cast<int>(std::lround(outDelta*1000.0F)),inDelta);
}
bool ArrangerHost::setAutoFill(int p, bool b) { return impl_->command(arranger::CommandType::SetAutoFill, p, 0, b ? 1 : 0); }
bool ArrangerHost::setAutoFillMode(int mode) {
    if(mode<0||mode>1){std::lock_guard<std::mutex> lock(impl_->control);impl_->error="Auto Fill mode must be Current Variation or Target Variation; Smart is not calibrated";return false;}
    return impl_->command(arranger::CommandType::SetAutoFillMode,0,0,mode);
}
bool ArrangerHost::cycleAutoFillMode() {return impl_->command(arranger::CommandType::CycleAutoFillMode);}
bool ArrangerHost::setMemory(bool b) { return impl_->command(arranger::CommandType::SetMemory, 0, 0, b ? 1 : 0); }
bool ArrangerHost::toggleSyncStart(int player) {
    if(!playerOk(player))return false;
    const bool ready=impl_->readyToStart(player);
    const auto transport=impl_->engine.snapshot(player);
    if(!ready&&!transport.syncStart)return false;
    {std::lock_guard<std::mutex> lock(impl_->control);impl_->savedSyncStartPending[player]=false;}
    if(ready&&!transport.playing)(void)impl_->synth[player].postPanic();
    return impl_->command(arranger::CommandType::ToggleSyncStart,player,0,ready?1.0:-1.0);
}
bool ArrangerHost::toggleAutoFill(int player) {return impl_->command(arranger::CommandType::ToggleAutoFill,player);}
bool ArrangerHost::toggleMemory() {return impl_->command(arranger::CommandType::ToggleMemory,0);}
bool ArrangerHost::setSplit(int key) { return impl_->command(arranger::CommandType::SetSplit, 0, 0, std::clamp(key, 1, 127)); }
bool ArrangerHost::setKeyboardSplit(int key,bool enabled) { return impl_->command(arranger::CommandType::SetKeyboardSplit,0,enabled?1:0,std::clamp(key,1,127)); }
bool ArrangerHost::setKeyboardRecall(int key,bool enabled,int chordScanArea,int bassInversion,std::uint32_t* acceptedSerial) {
    if(acceptedSerial)*acceptedSerial=0;
    if(key<1||key>127||chordScanArea< -1||chordScanArea>3||bassInversion< -1||bassInversion>1){
        std::lock_guard<std::mutex> lock(impl_->control);
        impl_->error="Keyboard recall requires split 1..127, optional scan -1..3 and bass inversion -1..1";
        return false;
    }
    int flags=enabled?1:0;
    if(chordScanArea>=0)flags|=2|(chordScanArea<<2);
    if(bassInversion>=0)flags|=16|(bassInversion<<5);
    std::lock_guard<std::mutex> lock(impl_->control);
    const auto serial=impl_->lastKeyboardRecallSerial>=0x7fffffffU?1U:impl_->lastKeyboardRecallSerial+1U;
    if(!impl_->commandLocked(arranger::CommandType::ApplyKeyboardRecall,0,flags,key,nullptr,static_cast<int>(serial)))return false;
    impl_->lastKeyboardRecallSerial=serial;
    if(acceptedSerial)*acceptedSerial=serial;
    return true;
}
std::uint32_t ArrangerHost::keyboardRecallCommittedSerial() const noexcept { return impl_->engine.keyboardRecallCommittedSerial(); }
bool ArrangerHost::setGlobalSplit(int key,bool applyEffective) {
    const int split=std::clamp(key,1,127);
    if(applyEffective&&!setSplit(split))return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->globalSplit.store(split,std::memory_order_relaxed);
    if(!applyEffective)impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    if(impl_->pendingRestoreIntent)impl_->pendingRestoreIntent->globalSplit=split;
    return true;
}
int ArrangerHost::globalSplit() const noexcept { return impl_->globalSplit.load(std::memory_order_relaxed); }
bool ArrangerHost::setChordRecognitionMode(int mode) {
    if (mode < 0 || mode > 4) {
        std::lock_guard<std::mutex> lock(impl_->control);
        impl_->error = "Chord recognition mode must be between 0 and 4";
        return false;
    }
    return impl_->command(arranger::CommandType::SetChordRecognition, 0, 0, mode);
}
bool ArrangerHost::setChordScanArea(int area) {
    if (area < 0 || area > 3) {
        std::lock_guard<std::mutex> lock(impl_->control);
        impl_->error = "Chord scan area must be between 0 and 3";
        return false;
    }
    return impl_->command(arranger::CommandType::SetChordScanArea, 0, 0, area);
}
bool ArrangerHost::toggleChordScanAreaBit(int bit) {
    if(bit!=1&&bit!=2){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="Choose the Lower or Upper chord button";return false;
    }
    return impl_->command(arranger::CommandType::ToggleChordScanAreaBit,0,bit);
}
bool ArrangerHost::selectChordScanZone(int area) {
    if(area!=1&&area!=2){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="Choose Lower or Upper for split-zone recognition";return false;
    }
    return impl_->command(arranger::CommandType::SetChordScanZone,0,0,area);
}
bool ArrangerHost::setSplitEnabled(bool enabled) { return impl_->command(arranger::CommandType::SetSplitEnabled, 0, 0, enabled ? 1 : 0); }
bool ArrangerHost::setBassInversion(bool enabled) { return impl_->command(arranger::CommandType::SetBassInversion, 0, 0, enabled ? 1 : 0); }
bool ArrangerHost::setDamperLatch(bool enabled) { return impl_->command(arranger::CommandType::SetDamperLatch, 0, 0, enabled ? 1 : 0); }
bool ArrangerHost::toggleChordSplit() { return impl_->command(arranger::CommandType::ToggleChordSplit); }
bool ArrangerHost::toggleBassInversion() { return impl_->command(arranger::CommandType::ToggleBassInversion); }
bool ArrangerHost::toggleDamperLatch() { return impl_->command(arranger::CommandType::ToggleDamperLatch); }
void ArrangerHost::setCrossfade(float x) noexcept {
    if(!std::isfinite(x))return;
    const auto value=std::clamp(x,0.0F,1.0F);
    if(impl_->xfade.exchange(value,std::memory_order_relaxed)!=value)impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
}
float ArrangerHost::crossfade() const noexcept { return impl_->xfade.load(std::memory_order_relaxed); }

bool ArrangerHost::inspectStyleRevision(const std::string& filename,const std::string& bytes,std::string& path,
        std::string& identity,std::string& name,ArrangerStyleKeyboardLinks& keyboardSets){
    SavedStyleEdit edit;
    if(!parseStyleEdit(bytes,edit)||filename!=styleEditRevisionName(bytes))return false;
    path=std::move(edit.sourcePath);identity=std::move(edit.identity);name=std::move(edit.name);
    keyboardSets=std::move(edit.keyboardSets);return true;
}
std::shared_ptr<const sampler::Combi> ArrangerHost::styleTrackCombi(int player,std::uint64_t& selection) const {
    if(!playerOk(player))return {};
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    const auto* ctx=impl_->controlContexts[player];if(!ctx||!impl_->styles[player])return {};
    selection=ctx->serial;
    return std::shared_ptr<const sampler::Combi>(impl_->state[player],&impl_->state[player]->combi);
}
bool ArrangerHost::editStyleCombi(int player,std::uint64_t selection,const std::function<void(sampler::Combi&)>& change,const sampler::Combi* expected){
    if(!playerOk(player)||!change)return false;
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
    if(expected&&(!impl_->state[player]||expected!=&impl_->state[player]->combi)){
        impl_->error="The Style sound changed during the edit";return false;
    }
    auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx)){impl_->error="The selected Style changed";return false;}
    const auto* old=ctx->latest.load(std::memory_order_seq_cst);if(!old)return false;
    auto plan=std::make_unique<Impl::RoutingPlan>(*old);
    auto next=std::make_shared<sampler::EngineState>(*old->baseState);change(next->combi);
    plan->baseState=std::move(next);
    const auto* live=impl_->retainPlan(player,std::move(plan),ctx);if(!live)return false;
    impl_->adoptControlPlan(player,live);
    (void)impl_->synth[player].publishPreparedState(live->prepared);
    impl_->collectPlans();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();return true;
}
bool ArrangerHost::restoreStyleSourceEffects(int player,std::uint64_t selection){
    if(!playerOk(player))return false;
    std::shared_ptr<const arranger::Pa5xStyleRead> source;
    std::shared_ptr<const sampler::EngineState> current;
    {
        std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
        const auto* context=impl_->controlContexts[player];
        const auto* plan=context?context->latest.load(std::memory_order_seq_cst):nullptr;
        if(!context||context->serial!=selection||!plan||!plan->read){impl_->error="The original Style FX resource is unavailable";return false;}
        source=plan->read;current=impl_->state[player];
    }
    auto restored=current->combi;
    if(!applyOriginalStyleEffects(restored,*source)){
        std::lock_guard<std::mutex> lock(impl_->control);impl_->error="This Style has no readable original FX profile";return false;
    }
    // The expected immutable state prevents a concurrent Sound/mixer edit
    // from being overwritten while the source graph was being prepared.
    return editStyleCombi(player,selection,[restored=std::move(restored)](sampler::Combi& target){target=restored;},&current->combi);
}

bool ArrangerHost::setTrackTrigger(int player,std::uint64_t selection,int track,int mode){
    if(!trackOk(player,track)||mode< -1||mode>1)return false;
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
    auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx)){
        impl_->error="The selected Style changed";return false;
    }
    auto plan=impl_->currentPlan(player);
    if(plan->views[track].soundSettings.trigger==mode)return true;
    plan->views[track].soundSettings.trigger=mode;
    const auto* live=impl_->retainPlan(player,std::move(plan),ctx);if(!live)return false;
    impl_->adoptControlPlan(player,live);
    (void)impl_->synth[player].publishPreparedState(live->prepared);
    impl_->collectPlans();
    impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);return true;
}
StyleRangeView ArrangerHost::styleRange(int player,std::uint64_t selection,int element,int track){
    if(!trackOk(player,track)||element<0||element>=int(arranger::kElementCount))return {};
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    const auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx))return {};
    return impl_->rangeView(ctx,element,track);
}
bool ArrangerHost::editRange(int player,std::uint64_t selection,int element,int track,RangeField field,int value){
    if(!trackOk(player,track)||element<0||element>=int(arranger::kElementCount))return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx)){
        impl_->error="The selected Style changed";return false;
    }
    auto r=impl_->rangeView(ctx,element,track);
    if(!r.available){impl_->error="No melodic part in this section";return false;}
    const bool wrap=field==RangeField::Wrap||field==RangeField::ResetWrap;
    auto& word=wrap?ctx->wraps[track]:ctx->ranges[element*arranger::kTracks+track];
    unsigned next=0;
    switch(field){
        case RangeField::Enable:r.enabled=value!=0;break;
        case RangeField::Low:r.low=std::clamp(value,0,r.high);break;
        case RangeField::High:r.high=std::clamp(value,r.low,127);break;
        case RangeField::Wrap:next=unsigned(std::clamp(value,1,12));break;
        case RangeField::ResetWrap:case RangeField::ResetRange:break;
    }
    if(!wrap&&field!=RangeField::ResetRange)next=PhraseRangeBank::pack(r.enabled,r.low,r.high);
    if(word.exchange(next,std::memory_order_relaxed)!=next)impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    return true;
}

StyleGuitarView ArrangerHost::styleGuitar(int player,std::uint64_t selection,int element,int track){
    if(!trackOk(player,track)||element<0||element>=int(arranger::kElementCount))return {};
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    const auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx))return {};
    return impl_->guitarView(ctx,element,track);
}
bool ArrangerHost::editGuitar(int player,std::uint64_t selection,int element,int track,GuitarField field,int value){
    if(!trackOk(player,track)||element<0||element>=int(arranger::kElementCount))return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx)){
        impl_->error="The selected Style changed";return false;
    }
    const auto current=impl_->guitarView(ctx,element,track);
    if(!current.available){impl_->error="No supported ACC/GTR pattern in this section";return false;}
    auto edited=current.overrides;
    switch(field){
        case GuitarField::Mode:edited.mode=std::clamp(value,-1,1);break;
        case GuitarField::Capo:edited.capo=std::clamp(value,-1,12);break;
        case GuitarField::HighString:
            if(value<0)edited.highString=-1;
            else {edited.highString=std::clamp(value,1,current.settings.lowString);edited.lowString=current.settings.lowString;}
            break;
        case GuitarField::LowString:
            if(value<0)edited.lowString=-1;
            else {edited.lowString=std::clamp(value,current.settings.highString,6);edited.highString=current.settings.highString;}
            break;
        case GuitarField::Humanize:edited.humanize=std::clamp(value,-1,127);break;
        case GuitarField::ResetSource:edited={};break;
    }
    if(!edited.valid()){impl_->error="The Guitar settings are outside their supported ranges";return false;}
    auto& word=ctx->guitars[element*arranger::kTracks+track];
    const auto next=GuitarOverrideBank::pack(edited);
    if(word.exchange(next,std::memory_order_relaxed)!=next)impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    impl_->error.clear();return true;
}

bool ArrangerHost::setFillMode(int player,std::uint64_t selection,int fill,int mode){
    if(!playerOk(player)||fill<0||fill>=5||mode<0||mode>14)return false;
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
    auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx)){
        impl_->error="The selected Style changed";return false;
    }
    const unsigned shift=static_cast<unsigned>(fill)*4;
    const unsigned old=ctx->fillModes.load(std::memory_order_relaxed);
    const unsigned updated=(old&~(15U<<shift))|(static_cast<unsigned>(mode)<<shift);
    if(updated!=old){
        ctx->fillModes.store(updated,std::memory_order_release);
        impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    }
    return true;
}

bool ArrangerHost::setTrackVolume(int p, int t, float db,std::uint64_t selection) {
    if (!trackOk(p, t) || !std::isfinite(db)) return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(p);
    if(selection){
        const auto* context=impl_->controlContexts[p];
        if(!context||context->serial!=selection||(impl_->stagedContexts[p]&&impl_->stagedContexts[p]!=context)){
            impl_->error="The Style changed. Select its track again.";return false;
        }
    }
    const float v = std::clamp(db, -60.0F, 12.0F);
    if(impl_->tracks[p][t].volumeDb==v&&(impl_->tracks[p][t].mixOverrideMask&kMixVolume)!=0){
        const auto* pending=impl_->stagedContexts[p];
        const auto* plan=pending?pending->latest.load(std::memory_order_seq_cst):nullptr;
        if(!pending||pending==impl_->controlContexts[p]||(plan&&plan->views[t].volumeDb==v&&(plan->views[t].mixOverrideMask&kMixVolume)!=0))return true;
    }
    impl_->state[p] = std::make_shared<sampler::EngineState>(*impl_->state[p]);
    impl_->state[p]->combi.part(t).levelDb = v;
    impl_->tracks[p][t].volumeDb = v;
    impl_->tracks[p][t].mixOverrideMask=static_cast<std::uint8_t>(impl_->tracks[p][t].mixOverrideMask|kMixVolume);
    impl_->publishState(p,t,kMixVolume);impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    return true;
}
bool ArrangerHost::setTrackPan(int p, int t, float pan) {
    if (!trackOk(p, t) || !std::isfinite(pan)) return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(p);
    const float v = std::clamp(pan, -1.0F, 1.0F);
    if(impl_->tracks[p][t].pan==v&&(impl_->tracks[p][t].mixOverrideMask&kMixPan)!=0){
        const auto* pending=impl_->stagedContexts[p];
        const auto* plan=pending?pending->latest.load(std::memory_order_seq_cst):nullptr;
        if(!pending||pending==impl_->controlContexts[p]||(plan&&plan->views[t].pan==v&&(plan->views[t].mixOverrideMask&kMixPan)!=0))return true;
    }
    impl_->state[p] = std::make_shared<sampler::EngineState>(*impl_->state[p]);
    impl_->state[p]->combi.part(t).pan = v;
    impl_->tracks[p][t].pan = v;
    impl_->tracks[p][t].mixOverrideMask=static_cast<std::uint8_t>(impl_->tracks[p][t].mixOverrideMask|kMixPan);
    impl_->publishState(p,t,kMixPan);impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    return true;
}
float ArrangerHost::styleGateReduction(int player,int part) const{
    return trackOk(player,part)?impl_->synth[player].channelGateReduction(part):0;
}
std::vector<float> ArrangerHost::styleAnalyzerFrame(int player,int track,bool after){
    if(!playerOk(player))return {};
    auto& synth=impl_->synth[player];
    synth.setAnalyzerTap(track,after);
    if(track<0||track>=8)return {};
    std::vector<float> frame(8192);
    synth.readAnalyzer(frame.data(),frame.size());
    return frame;
}
ListenSolo ArrangerHost::listenSolo() const noexcept {
    const int bits=impl_->listenSoloWord.load(std::memory_order_relaxed);
    return {(bits>>16)-2,((bits>>8)&255)-1,(bits&255)-1};
}
void ArrangerHost::setListenSolo(sampler::SamplerEngine& keyboard,ListenSolo target) noexcept {
    if(target.player< -1||target.player>1||target.part<0||target.part>=(target.player<0?7:8))target={};
    if(target.key<0||target.key>127||target.player<0||target.part>1)target.key=-1;
    const auto partFor=[&](int group){return target.player==-2?-1:group==target.player?target.part:-2;};
    keyboard.setListenPart(partFor(-1));
    for(int p=0;p<2;++p)impl_->synth[p].setListenPart(partFor(p),target.player==p?target.key:-1);
    impl_->listenSoloWord.store(((target.player+2)<<16)|((target.part+1)<<8)|(target.key+1),std::memory_order_relaxed);
}
bool ArrangerHost::setTrackMute(int p,int t,bool muted){
    if(!trackOk(p,t))return false;
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(p);
    return impl_->writeTrackMute(p,t,muted);
}
bool ArrangerHost::toggleTrackMute(int p,int t,std::uint64_t selection,bool& muted){
    if(!trackOk(p,t))return false;
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(p);
    auto* ctx=impl_->controlContexts[p];
    if(!ctx||ctx->serial!=selection||(impl_->stagedContexts[p]&&impl_->stagedContexts[p]!=ctx)){
        impl_->error="The selected Style changed";return false;
    }
    const auto solo=listenSolo();
    muted=(solo.player==p&&solo.part==t)||!impl_->tracks[p][t].mute;
    if(muted==impl_->tracks[p][t].mute)return true;
    return impl_->writeTrackMute(p,t,muted);
}
bool ArrangerHost::assignSound(int p,int t,int slot,sampler::ProgramPtr program,std::uint64_t selection,
                               int setAddress,const std::string& setRoot) {
    if (!trackOk(p, t) || slot < 0 || (slot != 0 && program == nullptr)) return false;
    // A manual track Sound can be selected after the Style's initial warm-up.
    // Prepare that exact new recording set before taking the publication lock.
    if(program)(void)arranger::warmPa5xSamplePrograms({program});
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(p);
    auto* context=impl_->controlContexts[p];
    if(selection&&(!context||context->serial!=selection||(impl_->stagedContexts[p]&&impl_->stagedContexts[p]!=context))){
        impl_->error="The Style changed. Select its track again.";return false;
    }
    if(setAddress>=0){
        const auto& bank=impl_->styleBanks[p];
        if(!bank||setRoot.empty()||bank->status().rootPath!=setRoot){
            impl_->error="Choose a Sound from this Style's own SET or from USER.";return false;
        }
        const Impl::OriginalAddress address{(setAddress>>16)&127,(setAddress>>8)&127,setAddress&127};
        if(impl_->keyboardProgramFor(address,setRoot).sound!=program||!program){
            impl_->error="This SET Sound is no longer available.";return false;
        }
    }
    auto plan=impl_->currentPlan(p);
    auto base=std::make_shared<sampler::EngineState>(*plan->baseState);
    auto& part=base->combi.part(t);
    part.program=std::move(program);part.enabled=part.program!=nullptr;
    part.soundSlotId=static_cast<std::uint16_t>(slot);part.name=part.program?part.program->name:kTrackNames[t];
    plan->trackMask=static_cast<std::uint8_t>(plan->trackMask&~(1U<<t));plan->required[t].clear();
    auto& view=plan->views[t];view.soundSettings.setAddress=setAddress;
    view.originalSoundRouted=false;view.soundSlot=slot;view.assigned=part.enabled;
    view.soundName=part.program?part.name:"Unassigned";
    plan->fixedSoundIdentities[t]=slot>0?styleEditProgramIdentity(part.program):std::string{};
    plan->baseState=std::move(base);
    const auto* installed=impl_->retainPlan(p,std::move(plan),context);if(!installed)return false;
    impl_->adoptControlPlan(p,installed);
    (void)impl_->synth[p].postControlChange(static_cast<std::uint8_t>(t),123,0);
    (void)impl_->synth[p].publishPreparedState(installed->prepared);
    impl_->finishDeferredSync(p);
    impl_->collectPlans();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();
    return true;
}
RecentStyleHits ArrangerHost::recentStyleHits(int player,std::uint64_t selection) const {
    RecentStyleHits hits;
    if(!playerOk(player))return hits;
    std::lock_guard<std::mutex> lock(impl_->control);
    const auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection)return hits;
    const auto now=impl_->publishedHitFrame.load(std::memory_order_acquire);
    const auto start=ctx->hitStart.load(std::memory_order_relaxed);
    if(!start||now<start)return hits;
    const auto span=static_cast<std::uint64_t>(impl_->rate*2);
    const auto since=std::max(start,now>span?now-span:0);
    for(int t=0;t<8;++t){
        if(impl_->lastTrackHit[player][t].load(std::memory_order_relaxed)<since)continue;
        hits.tracks|=1U<<t;
        if(t<2)for(int key=0;key<128;++key)
            if(impl_->lastDrumHit[player][t][key].load(std::memory_order_relaxed)>=since)hits.drums[t].set(key);
    }
    return hits;
}
StyleActivity ArrangerHost::styleActivity(int player,const ArrangerPlayerView& view) const {
    StyleActivity activity;
    if(!playerOk(player)||!view.loaded)return activity;
    std::lock_guard<std::mutex> lock(impl_->control);
    const auto* ctx=impl_->controlContexts[player];
    const auto* plan=impl_->controlAckPlans[player];
    if(!ctx||ctx->serial!=view.styleSelectionSerial||!plan||plan->noteMapRevision!=view.soundRevision||!plan->style||
       view.element<0||static_cast<std::size_t>(view.element)>=plan->style->sections.size())return activity;
    const auto& section=plan->style->sections[view.element];
    if(!section.available)return activity;
    std::array<std::set<std::string>,8> programNames;
    std::array<const sampler::Program*,8> lastNamedProgram{};
    std::array<std::array<std::set<std::string>,128>,2> names;
    std::array<std::array<StyleActivity::Drum,128>,2> rows{};
    // Look up each distinct kit/key/velocity once, even when the phrase repeats the same hit.
    std::set<std::tuple<int,const sampler::Program*,int,int>> inspected;
    std::array<Impl::OriginalMidiState,8> midi;
    const auto event=[&](int track,const arranger::MidiEvent& e,bool notes){
        if(track<0||track>=8)return;
        const int kind=e.status&0xf0;
        auto& state=midi[track];const int channel=e.status&15;
        auto& voice=state.channels[channel];
        if(kind==0xb0&&e.data1==0){voice.pendingMsb=e.data2;return;}
        if(kind==0xb0&&e.data1==32){voice.pendingLsb=e.data2;return;}
        if(kind==0xc0){voice.active={voice.pendingMsb,voice.pendingLsb,e.data1};state.activeChannel=channel;return;}
        if(!notes||kind!=0x90||!e.data2||e.data1>=128)return;
        auto program=plan->baseState->combi.part(track).program;
        if(plan->trackMask&(1U<<track)){
            if(state.activeChannel<0)return;
            const auto& address=state.channels[state.activeChannel].active;
            if(!address.complete()||!plan->required[track].count(address.key()))return;
            const auto found=plan->programs.find(address.key());
            program=found==plan->programs.end()?nullptr:found->second;
        }
        if(!program)return;
        if(!activity.sourcePrograms[track]){
            for(unsigned i=0;i<program->layers.size();++i)if(program->layers[i].matches(e.data1,e.data2)){
                activity.sourcePrograms[track]=program;activity.representativeLayers[track]=i;break;
            }
        }
        if(program.get()!=lastNamedProgram[track]){
            lastNamedProgram[track]=program.get();
            if(!program->name.empty()&&programNames[track].insert(program->name).second){
                auto& title=activity.programNames[track];
                if(!title.empty())title+=" / ";
                title+=program->name;
            }
        }
        if(track>=2){activity.tracks|=1U<<track;return;}
        if(!inspected.emplace(track,program.get(),e.data1,e.data2).second)return;
        for(const auto& layer:program->layers)if(layer.matches(e.data1,e.data2)){
            for(const auto& zone:layer.multisample->zones)if(zone.matches(e.data1,e.data2)&&zone.sample->valid()){
                const auto env=editableAmpEnvelope(layer);
                const std::array<int,4> values{{int(std::lround(env.attackSec*1000)),int(std::lround(env.decaySec*1000)),
                    int(std::lround(env.sustain*100)),int(std::lround(env.releaseSec*1000))}};
                auto& row=rows[track][e.data1];
                if(zone.oneShot)row.hasOneShotZone=true;else row.hasGatedZone=true;
                if(names[track][e.data1].empty()){
                    row.sourceEnvelope=values;row.auditionSource=program;row.velocity=e.data2;
                }
                else for(int i=0;i<4;++i)if(values[i]!=row.sourceEnvelope[i])row.mixedEnvelope|=1U<<i;
                names[track][e.data1].insert(zone.sample->name);
                activity.tracks|=1U<<track;
            }
        }
    };
    if(section.nativePatterns){
        for(int track=0;track<8;++track){
            const auto& pattern=section.patterns[track];
            const int cv=view.tracks[track].selectedCv;
            if(!pattern.present||pattern.mode==arranger::NativePatternMode::Unsupported||
               (view.playing&&view.tracks[track].playbackBlocked)||cv<1||cv>static_cast<int>(pattern.cvs.size()))continue;
            const auto& clip=pattern.cvs[cv-1];
            if(!clip.available||!clip.lengthTicks)continue;
            for(const auto& e:pattern.setupEvents)event(track,e,false);
            for(const auto& e:clip.events)event(track,e,true);
        }
    }else for(const auto& e:section.events)event(e.track,e,true);
    // An inactive track can still be selected in Track Controls. Resolve its
    // own assignment or its sole unambiguous source in the prepared bank.
    for(int track=0;track<8;++track){
        if(activity.sourcePrograms[track])continue;
        if(!(plan->trackMask&(1U<<track)))activity.sourcePrograms[track]=plan->baseState->combi.part(track).program;
        else if(plan->required[track].size()==1){
            const auto entry=plan->programs.find(*plan->required[track].begin());
            if(entry!=plan->programs.end())activity.sourcePrograms[track]=entry->second;
        }
    }
    for(int track=0;track<2;++track)for(int key=0;key<128;++key){
        const auto& hits=names[track][key];if(hits.empty())continue;
        std::string name;int count=0;
        for(const auto& sample:hits)if(!sample.empty()){
            if(count<2){if(count)name+=" / ";name+=sample;}++count;
        }
        if(count>2)name+=" +"+std::to_string(count-2);
        auto& row=rows[track][key];
        row.track=track;row.note=key;row.name=std::move(name);
        activity.drums.push_back(std::move(row));
    }
    return activity;
}
bool ArrangerHost::auditionStyleDrum(int player,std::uint64_t selection,std::uint64_t soundRevision,const StyleActivity::Drum& drum){
    if(!playerOk(player)||drum.track<0||drum.track>1||!drum.auditionSource)return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    const auto* plan=impl_->controlAckPlans[player];
    if(!plan||!plan->prepared||!plan->context||plan->context->serial!=selection||plan->noteMapRevision!=soundRevision)return false;
    auto source=drum.auditionSource;
    auto preview=std::make_shared<sampler::EngineState>(*impl_->previewState);
    const auto& mix=plan->prepared->state->combi;
    auto& voice=preview->combi.part(0);voice=mix.part(drum.track);
    voice.program=std::move(source);voice.midiChannel=0;voice.enabled=true;voice.mute=false;voice.solo=false;
    voice.damperEnabled=voice.expressionEnabled=voice.breathEnabled=false;
    preview->combi.fx=mix.fx;preview->combi.fxRouting=mix.fxRouting;preview->combi.insertOf(0)=mix.insertOf(drum.track);
    preview->global.transposeSemitones=plan->prepared->state->global.transposeSemitones;
    (void)impl_->previewSynth.postPanic();impl_->previewSynth.setState(preview);
    impl_->previewProgram.reset();impl_->previewView={};
    return impl_->previewSynth.postNoteOn(0,static_cast<std::uint8_t>(drum.note),static_cast<std::uint8_t>(drum.velocity));
}
void ArrangerHost::releasePreviewNote(int key){
    if(key>=0&&key<128)(void)impl_->previewSynth.postNoteOff(0,static_cast<std::uint8_t>(key));
}
bool ArrangerHost::setStyleDrum(int player,int track,std::uint64_t selection,int note,int db,const StyleDrumTone& tone){
    if(!playerOk(player)||track<0||track>1||note<0||note>127||db< -60||db>12||!tone.valid())return false;
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
    auto* ctx=impl_->controlContexts[player];
    if(!ctx||ctx->serial!=selection||!impl_->styles[player]||(impl_->stagedContexts[player]&&impl_->stagedContexts[player]!=ctx)){
        impl_->error="The Style changed. Open Drum Levels again.";return false;
    }
    auto plan=impl_->currentPlan(player);
    auto& trim=plan->views[track].soundSettings.keyDb[note];
    auto& settings=plan->views[track].soundSettings;
    auto tones=settings.tones?*settings.tones:DrumTones{};
    if(tone.neutral())tones.erase(note);else tones[note]=tone;
    settings.tones=tones.empty()?nullptr:std::make_shared<const DrumTones>(std::move(tones));
    trim=static_cast<std::int8_t>(db);
    const auto* installed=impl_->retainPlan(player,std::move(plan),ctx);if(!installed)return false;
    impl_->adoptControlPlan(player,installed);
    (void)impl_->synth[player].publishPreparedState(installed->prepared);
    impl_->collectPlans();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();return true;
}
void ArrangerHost::clearSoundAssignments() { for (int p = 0; p < 2; ++p) for (int t = 0; t < 8; ++t) (void)assignSound(p, t, 0, nullptr); }
bool ArrangerHost::prepareKorgStylePrograms(int player,const std::vector<ArrangerOriginalProgram>& programs) {
    if (!playerOk(player)) return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->synchronizeCommitted(player);
    const auto& style = impl_->styles[player];
    const auto& read = impl_->styleReads[player];
    if (!style || !style->nativeKorg || !read || !read->valid) {
        impl_->error = "Load a readable native Korg Style before preparing its original Sounds"; return false;
    }
    std::map<std::uint32_t,sampler::ProgramPtr> supplied;
    for (const auto& program : programs) {
        Impl::OriginalAddress address{program.msb,program.lsb,program.program};
        if (!address.complete() || !playableSampleProgram(program.sound) ||
            !supplied.emplace(address.key(),program.sound).second) {
            impl_->error = "Original Sound programs contain an invalid address, empty Sound or duplicate definition"; return false;
        }
    }
    std::array<std::set<std::uint32_t>,8> required;
    std::uint8_t mask = 0;
    for (const auto& section : read->sections) {
        if (!section.available) continue;
        for (int track = 0; track < 8; ++track) {
            const auto& clip = section.tracks[static_cast<std::size_t>(track)];
            if (!clip.present) continue;
            for (const auto& cv : clip.cvs) {
                if (!cv.available || !cv.hasNotes) continue;
                std::set<unsigned> channels;
                for (const auto& change : cv.soundChanges) {
                    Impl::OriginalAddress address{change.msb,change.lsb,change.program};
                    if (!address.complete()) {
                        impl_->error = "Original Sound address is incomplete for " + impl_->tracks[player][track].name; return false;
                    }
                    channels.insert(change.channel);
                    required[static_cast<std::size_t>(track)].insert(address.key());
                }
                if (channels.size() != 1) {
                    impl_->error = channels.empty() ? "A sounding Korg CV has no committed original Sound address" :
                        "Several original MIDI channels share one Korg Style track; independent note ownership is not implemented";
                    return false;
                }
                const auto sectionIndex = static_cast<std::size_t>(&section-read->sections.data());
                if (cv.number < 1 || cv.number > 6) {
                    impl_->error = "Invalid original Korg CV number"; return false;
                }
                const auto& pattern = style->sections[sectionIndex].patterns[static_cast<std::size_t>(track)];
                const auto& nativeCv = pattern.cvs[static_cast<std::size_t>(cv.number-1)];
                Impl::OriginalMidiState declared;
                const auto readMidi = [&](const arranger::MidiEvent& event,bool notes) {
                    const auto sourceChannel = static_cast<std::size_t>(event.status&15U);
                    auto& source = declared.channels[sourceChannel];
                    const auto type = event.status&0xF0U;
                    if(type==0xB0U&&event.data1==0)source.pendingMsb=event.data2;
                    else if(type==0xB0U&&event.data1==32)source.pendingLsb=event.data2;
                    else if(type==0xC0U)source.active={source.pendingMsb,source.pendingLsb,event.data1};
                    else if(notes&&type==0x90U&&event.data2>0)
                        return source.active.complete()&&channels.count(static_cast<unsigned>(sourceChannel))!=0&&
                            required[static_cast<std::size_t>(track)].count(source.active.key())!=0;
                    return true;
                };
                for(const auto& event:pattern.setupEvents)(void)readMidi(event,false);
                for(const auto& event:nativeCv.events)if(!readMidi(event,true)){
                    impl_->error = "A Korg CV note precedes a complete Sound declaration on its original MIDI channel"; return false;
                }
            }
        }
    }
    for (int track = 0; track < 8; ++track) {
        if (!style->tracks[static_cast<std::size_t>(track)].used) continue;
        const auto& addresses = required[static_cast<std::size_t>(track)];
        if (addresses.empty()) {
            impl_->error = "No original playable Sound address was established for " + impl_->tracks[player][track].name; return false;
        }
        for (const auto address : addresses) if (supplied.find(address) == supplied.end()) {
            impl_->error = "Missing playable original Sound " + std::to_string((address >> 16) & 127U) + "/" +
                std::to_string((address >> 8) & 127U) + "/" + std::to_string(address & 127U) + " for " + impl_->tracks[player][track].name; return false;
        }
        mask = static_cast<std::uint8_t>(mask | (1U << track));
    }
    (void)impl_->synth[player].postPanic();
    impl_->originalPrograms[player] = std::move(supplied);
    impl_->requiredOriginalPrograms[player] = std::move(required);

    impl_->originalRoutingMask[player] = mask;
    impl_->samplePlaybackMode[player] = false;
    impl_->samplePlaybackWarnings[player].clear();
    impl_->state[player] = std::make_shared<sampler::EngineState>(*impl_->state[player]);
    for (int track = 0; track < 8; ++track) if ((mask & (1U << track)) != 0U) {
        auto& part = impl_->state[player]->combi.part(track);
        part.program.reset(); part.enabled = true; part.soundSlotId = 0;
        auto& view = impl_->tracks[player][track];
        view.assigned = true; view.originalSoundRouted = true; view.soundSlot = 0;
        view.soundName = "Original Sound routing";
    }
    impl_->publishState(player);
    if(!impl_->engine.post({arranger::CommandType::SetSamplePlaybackMode,player,0,0,0,style.get()})){
        impl_->error="Arranger command queue full while preparing Sound playback";return false;
    }
    impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();return true;
}
bool ArrangerHost::prepareKorgSamplePrograms(int player,const std::vector<ArrangerOriginalProgram>& programs,
        const std::vector<std::string>& warnings) {
    return prepareKorgSampleProgramsImpl(player,programs,warnings,false,nullptr);
}
bool ArrangerHost::prepareKorgSampleProgramsImpl(int player,const std::vector<ArrangerOriginalProgram>& programs,
        const std::vector<std::string>& warnings,bool prevalidated,const arranger::Pa5xStyleRead* expectedRead){
    if(!playerOk(player))return false;
    std::shared_ptr<const arranger::Pa5xStyleRead> read;
    {
        std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
        read=impl_->styleReads[player];
        if(expectedRead&&read.get()!=expectedRead){impl_->error="The selected Style changed before sample preparation";return false;}
        if(!read||!read->valid||!read->nativeStyle){impl_->error="Load a readable Korg Style before sample playback";return false;}
    }
    std::vector<sampler::ProgramPtr> entryPrograms;
    const auto needed=styleEntryAddresses(*read);
    for(const auto& program:programs){
        const Impl::OriginalAddress address{program.msb,program.lsb,program.program};
        if(address.complete()&&needed.count(address.key())&&program.sound)entryPrograms.push_back(program.sound);
    }
    (void)arranger::warmPa5xSamplePrograms(entryPrograms);
    std::lock_guard<std::mutex> lock(impl_->control);impl_->synchronizeCommitted(player);
    if(impl_->styleReads[player]!=read){impl_->error="The selected Style changed during sample preparation";return false;}
    auto* context=impl_->controlContexts[player];if(!context)context=impl_->newContext(player);
    const auto* plan=impl_->buildSamplePlan(player,context,read,impl_->styleBanks[player],impl_->paths[player],
        programs,warnings,prevalidated,impl_->state[player],impl_->tracks[player]);
    if(!plan)return false;
    impl_->adoptControlPlan(player,plan);(void)impl_->synth[player].publishPreparedState(plan->prepared);
    impl_->refreshPendingMix(player);impl_->collectPlans();impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    if(!impl_->engine.post({arranger::CommandType::SetSamplePlaybackMode,player,0,1,0,plan->style})){
        impl_->error="Arranger command queue full while enabling sample playback";return false;
    }
    if(!impl_->anyPreparedSampleProgram(player)){impl_->error="No playable User samples are available for this Style; missing addresses remain silent";return false;}
    impl_->error.clear();return true;
}

void ArrangerHost::syncGlobal(const sampler::GlobalState& global, bool scaleEnabled) {
    impl_->externalChannels.store(global.midiInputChannelMask, std::memory_order_relaxed);
    impl_->externalNotesFiltered.store(global.filterNotes, std::memory_order_relaxed);
    const auto damperConfig = static_cast<std::uint16_t>(std::min<unsigned>(127U, global.damperCc) |
        (global.damperPolarityReversed ? kDamperReversed : 0U) |
        (global.filterControlChange ? kControlChangesFiltered : 0U));
    const auto previousDamper = impl_->externalDamperConfig.exchange(damperConfig, std::memory_order_relaxed);
    if ((previousDamper & 255U) != (damperConfig & 255U)) {
        // The old pedal assignment can no longer release its latch. Preserve
        // physically held notes while ending sustain on all MIDI channels.
        for (int channel = 0; channel < 16; ++channel)
            (void)impl_->engine.postMidi(0xB0 | channel, 64, 0);
    }
    const bool limiterChanged=impl_->limiterEnabled.exchange(global.limiterEnabled,std::memory_order_relaxed)!=global.limiterEnabled;
    const float ceilingDb = std::isfinite(global.limiterCeilingDb) ? std::clamp(global.limiterCeilingDb, -12.0F, 0.0F) : -6.0F;
    const float ceiling=std::pow(10.0F,ceilingDb*0.05F);
    const bool ceilingChanged=impl_->limiterCeiling.exchange(ceiling,std::memory_order_relaxed)!=ceiling;
    // Style MIDI is an internal stream. Preserve sound/output settings while
    // keeping the user's external-keyboard filters and pedal calibration out.
    sampler::GlobalState internal;
    internal.masterTuneHz = global.masterTuneHz;
    internal.transposeSemitones = global.transposeSemitones;
    internal.masterGainDb = global.masterGainDb;
    internal.eqLowDb = global.eqLowDb;
    internal.eqMidDb = global.eqMidDb;
    internal.eqHighDb = global.eqHighDb;
    // A single linked stereo limiter follows keyboard + both players.
    internal.limiterEnabled = false;
    internal.limiterCeilingDb = global.limiterCeilingDb;
    internal.scaleRoot = global.scaleRoot;
    internal.scaleOffsetsCents = global.scaleOffsetsCents;
    std::lock_guard<std::mutex> lock(impl_->control);
    const auto sameGlobal=[](const sampler::GlobalState& a,const sampler::GlobalState& b){
        return a.masterTuneHz==b.masterTuneHz&&a.transposeSemitones==b.transposeSemitones&&a.masterGainDb==b.masterGainDb&&
            a.eqLowDb==b.eqLowDb&&a.eqMidDb==b.eqMidDb&&a.eqHighDb==b.eqHighDb&&a.scaleRoot==b.scaleRoot&&a.scaleOffsetsCents==b.scaleOffsetsCents;
    };
    for(int p=0;p<2;++p)impl_->synchronizeCommitted(p);
    const bool routingChanged=impl_->scaleEnabled!=scaleEnabled||!sameGlobal(impl_->state[0]->global,internal)||!sameGlobal(impl_->state[1]->global,internal);
    if(routingChanged||limiterChanged||ceilingChanged)impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);
    if(!routingChanged)return;
    impl_->scaleEnabled = scaleEnabled;
    for (int p = 0; p < 2; ++p) {
        impl_->state[p] = std::make_shared<sampler::EngineState>(*impl_->state[p]);
        impl_->state[p]->global = internal;
        
        impl_->publishState(p);
    }
}
bool ArrangerHost::setScaleAssignment(int assignment) {
    std::lock_guard<std::mutex> lock(impl_->control);
    if(assignment<0||assignment>2){impl_->error="Scale Assignment must be Keyboard, Upper, or all melodic tracks; native Style scales are not decoded";return false;}
    if(impl_->scaleAssignment==assignment)return true;
    for(int player=0;player<2;++player)impl_->synchronizeCommitted(player);
    impl_->scaleAssignment=assignment;
    if(impl_->pendingRestoreIntent)impl_->pendingRestoreIntent->scaleAssignment=assignment;
    for(int player=0;player<2;++player){
        impl_->state[player]=std::make_shared<sampler::EngineState>(*impl_->state[player]);
        impl_->publishState(player);
    }
    impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();return true;
}
void ArrangerHost::configureSharedRendering(sampler::SamplerEngine& master){
    // Read-ahead affinity is configured before thread start. Joining/restarting
    // these ordinary workers is allowed here only while audio is stopped.
    const bool restart=impl_->prefetch0.running()||impl_->prefetch1.running();
    stopStreaming();
    {
        std::lock_guard<std::mutex> lock(impl_->control);
        for(auto& synth:impl_->synth)synth.shareRenderWorkersFrom(master);
        impl_->previewSynth.setRenderThreads(1);
    }
    if(restart)startStreaming();
}
void ArrangerHost::prepare(double rate, std::uint32_t maximumFrames) {
    {
    // Audio startup runs on the lifecycle worker while the GUI may already be
    // editing a sound. Serialize control publications with synth preparation.
    std::lock_guard<std::mutex> lock(impl_->control);
    impl_->rate = std::max(8000.0, rate);
    const auto block = std::min(kMaximumFrames, std::max(1U, maximumFrames));
    impl_->blockFrames = block;
    for (int p = 0; p < 2; ++p) {
        const auto transport=impl_->synchronizeCommitted(p);
        const auto* mixContext=impl_->sourceMixContext[p].load(std::memory_order_acquire);
        // Reopening the audio device resets the sampler's channel controllers,
        // while an already playing arranger keeps its CV cursors and phase.
        // Retain only that exact committed source's current mix. A stopped or
        // pending new Style must receive its own setup at its normal START or
        // handoff rather than inheriting another Style's channel values.
        bool restoreMix=transport.playing&&transport.style&&transport.style==impl_->styles[p].get()&&
            transport.style==impl_->audioSourceStyles[p]&&mixContext&&
            mixContext==impl_->controlContexts[p]&&mixContext==impl_->audioContexts[p];
        std::array<std::array<int,6>,8> controllerValues{};
        if(restoreMix){
            for(int track=0;track<8;++track){
                const auto& source=impl_->sourceMix[p][track];
                controllerValues[static_cast<std::size_t>(track)]={{source.volume.load(std::memory_order_relaxed),
                    source.pan.load(std::memory_order_relaxed),source.expression.load(std::memory_order_relaxed),
                    source.sends[0].load(std::memory_order_relaxed),source.sends[1].load(std::memory_order_relaxed),source.sends[2].load(std::memory_order_relaxed)}};
            }
            restoreMix=impl_->sourceMixContext[p].load(std::memory_order_acquire)==mixContext;
        }
        impl_->synth[p].prepare(impl_->rate, block);
        impl_->synth[p].setInterpolationQuality(sampler::InterpolationQuality::Studio);
        impl_->state[p]=std::make_shared<sampler::EngineState>(*impl_->state[p]);
        impl_->publishState(p);
        const bool resumeSource=restoreMix&&impl_->controlContexts[p]==mixContext&&impl_->styles[p].get()==transport.style;
        if(resumeSource){
            constexpr std::array<std::uint8_t,6> controllers{{7U,10U,11U,91U,93U,94U}};
            for(int track=0;track<8;++track)for(std::size_t field=0;field<controllers.size();++field){
                const auto value=controllerValues[static_cast<std::size_t>(track)][field];
                if(value>=0&&value<=127)(void)impl_->synth[p].postControlChange(static_cast<std::uint8_t>(track),
                    controllers[field],static_cast<std::uint8_t>(value));
            }
        }
        // Preserve the running source identity so sourceStyle() retains its
        // committed bank/program MIDI declarations too. Its cursors continue
        // from the existing phase; clearing originalMidi here would make new
        // notes silent until a later Program Change. Routing itself must be
        // activated again against the newly prepared sampler.
        impl_->audioSourceStyles[p]=resumeSource?transport.style:nullptr;
        impl_->audioContexts[p]=nullptr;impl_->audioActivePlans[p].store(nullptr,std::memory_order_seq_cst);
        impl_->audioPlanHazards[p].store(nullptr,std::memory_order_seq_cst);impl_->audioRouteReady[p]=false;
    }
    impl_->previewSynth.prepare(impl_->rate, block);
    impl_->previewSynth.setInterpolationQuality(sampler::InterpolationQuality::Studio);
    impl_->previewSynth.setState(impl_->previewState);
    impl_->prepared = true;
    impl_->limiterGain = 1.0F;
    impl_->outputPeakL.store(0.0F, std::memory_order_relaxed);
    impl_->outputPeakR.store(0.0F, std::memory_order_relaxed);
    impl_->reductionDb.store(0.0F, std::memory_order_relaxed);
    impl_->cpuPercent.store(0.0F, std::memory_order_relaxed);
    }
    startStreaming();
}
void ArrangerHost::startStreaming() {
    const auto policy=sampler::deviceCpuWorkPolicy();
    if(!impl_->prefetch0.running())impl_->prefetch0.setCpuRange(policy.streamFirstCpu,policy.streamLastCpu);
    if(!impl_->prefetch1.running())impl_->prefetch1.setCpuRange(policy.streamFirstCpu,policy.streamLastCpu);
    if (!impl_->prefetch0.running()) (void)impl_->prefetch0.start();
    if (!impl_->prefetch1.running()) (void)impl_->prefetch1.start();
}
void ArrangerHost::stopStreaming() {
    impl_->drumKitMidiAudition.store(false,std::memory_order_release);
    (void)impl_->previewSynth.postPanic();
    impl_->prefetch0.stop(); impl_->prefetch1.stop();
}
int ArrangerHost::takeEditorNote() noexcept {return impl_->editorNote.exchange(-1,std::memory_order_relaxed);}
bool ArrangerHost::observeMidi(std::uint8_t s, std::uint8_t a, std::uint8_t b) noexcept {
    const auto kind = static_cast<std::uint8_t>(s & 0xF0U);
    const auto channelBit = static_cast<std::uint16_t>(1U << (s & 0x0FU));
    const bool channelAllowed = (impl_->externalChannels.load(std::memory_order_relaxed) & channelBit) != 0U;
    // Releases are always admitted, including after an input-filter change.
    if (kind == 0x90U && b > 0 &&
        (impl_->externalNotesFiltered.load(std::memory_order_relaxed) ||
         !channelAllowed)) return true;
    if(kind==0x90U&&b>0)impl_->editorNote.store(((a&127)<<7)|(b&127),std::memory_order_relaxed);
    if (kind == 0xB0U) {
        const auto config = impl_->externalDamperConfig.load(std::memory_order_relaxed);
        const bool filterCc = (config & kControlChangesFiltered) != 0U;
        if (a == (config & 127U)) {
            const bool down = (config & kDamperReversed) != 0U ? b < 64U : b >= 64U;
            // A release remains admissible after channel/filter changes.
            if (down && (!channelAllowed || filterCc)) return true;
            return impl_->engine.postMidi(s, 64, down ? 127 : 0);
        }
        // Only the configured damper controller may reach the core's logical
        // CC64 input. In particular ordinary breath CC2 is not a damper.
        if (a == 64U) return true;
        const bool safetyRelease = a == 120U || a == 121U || a == 123U;
        if (!safetyRelease && (!channelAllowed || filterCc)) return true;
    }
    return impl_->engine.postMidi(s, a, b);
}
void ArrangerHost::renderAdd(float* stereo, std::uint32_t frames, double rate) noexcept {
    if (!impl_->prepared || stereo == nullptr) return;
    if (impl_->panicPending.exchange(false, std::memory_order_acq_rel)) {
        for (auto& synth : impl_->synth) (void)synth.postPanic();
        (void)impl_->previewSynth.postPanic();
    }
    std::uint32_t offset = 0;
    while (offset < frames) {
        const auto count = std::min(impl_->blockFrames, frames - offset);
        impl_->destination = stereo + static_cast<std::size_t>(offset) * 2;
        impl_->engine.process(count, rate, *impl_);
        impl_->hitFrame+=count;
        impl_->publishedHitFrame.store(impl_->hitFrame,std::memory_order_release);
        impl_->previewSynth.setSourceTempo(keyboardSourceTempo());
        impl_->previewSynth.render(impl_->scratch.data(), count);
        for (std::size_t sample = 0; sample < static_cast<std::size_t>(count) * 2; ++sample)
            impl_->destination[sample] += impl_->scratch[sample];
        offset += count;
    }
    impl_->destination = nullptr;
    const bool limited = impl_->limiterEnabled.load(std::memory_order_relaxed);
    const float ceiling = impl_->limiterCeiling.load(std::memory_order_relaxed);
    const float release = static_cast<float>(1.0 - std::exp(-1.0 / (0.080 * std::max(8000.0, rate))));
    float peakL = 0.0F, peakR = 0.0F, minimumGain = 1.0F;
    if (!limited) impl_->limiterGain = 1.0F;
    for (std::uint32_t f = 0; f < frames; ++f) {
        const auto index = static_cast<std::size_t>(f) * 2;
        float left = std::isfinite(stereo[index]) ? stereo[index] : 0.0F;
        float right = std::isfinite(stereo[index + 1]) ? stereo[index + 1] : 0.0F;
        if (limited) {
            const float peak = std::max(std::fabs(left), std::fabs(right));
            const float required = peak > ceiling ? ceiling / peak : 1.0F;
            const float released = impl_->limiterGain + (1.0F - impl_->limiterGain) * release;
            impl_->limiterGain = std::min(required, released);
            minimumGain = std::min(minimumGain, impl_->limiterGain);
            left *= impl_->limiterGain;
            right *= impl_->limiterGain;
        }
        stereo[index] = left;
        stereo[index + 1] = right;
        peakL = std::max(peakL, std::fabs(left));
        peakR = std::max(peakR, std::fabs(right));
    }
    impl_->outputPeakL.store(peakL, std::memory_order_relaxed);
    impl_->outputPeakR.store(peakR, std::memory_order_relaxed);
    impl_->reductionDb.store(limited ? -20.0F * std::log10(std::max(minimumGain, 1.0e-10F)) : 0.0F, std::memory_order_relaxed);
}
void ArrangerHost::recordBlockCost(float percent) noexcept {
    impl_->cpuPercent.store(std::isfinite(percent) ? std::max(0.0F, percent) : 0.0F, std::memory_order_relaxed);
}
sampler::MeterSnapshot ArrangerHost::combinedMeters(const sampler::MeterSnapshot& keyboard) const noexcept {
    auto out = keyboard;
    out.peakLeft = impl_->outputPeakL.load(std::memory_order_relaxed);
    out.peakRight = impl_->outputPeakR.load(std::memory_order_relaxed);
    out.limiterGainReductionDb = impl_->reductionDb.load(std::memory_order_relaxed);
    out.cpuLoadPercent = impl_->cpuPercent.load(std::memory_order_relaxed);
    for (const auto& synth : impl_->synth) {
        const auto meter = synth.meters();
        out.activeVoices += meter.activeVoices;
        out.droppedEvents += meter.droppedEvents;
        out.coresWorking=std::max(out.coresWorking,meter.coresWorking);
    }
    const auto previewMeter = impl_->previewSynth.meters();
    out.activeVoices += previewMeter.activeVoices;
    out.droppedEvents += previewMeter.droppedEvents;
    out.droppedEvents += impl_->engine.droppedCommands();
    return out;
}
void ArrangerHost::panic() noexcept { impl_->panicPending.store(true, std::memory_order_release); (void)impl_->engine.post({arranger::CommandType::Panic}); }

std::uint64_t ArrangerHost::persistenceRevision() const noexcept {
    return impl_->persistentRevision.load(std::memory_order_relaxed);
}
std::string ArrangerHost::persistentSession() const {
    std::lock_guard<std::mutex> lock(impl_->control);
    std::array<arranger::PlayerSnapshot,2> audio{{impl_->synchronizeCommitted(0),impl_->synchronizeCommitted(1)}};
    if(!impl_->pendingRestoredText.empty()&&impl_->restoreAcknowledged(audio)){
        impl_->pendingRestoredText.clear();impl_->pendingRestoreIntent.reset();impl_->persistentRestoreContexts={};
    }
    std::array<const Impl::RoutingPlan*,2> plans{};
    const auto* restoring=impl_->pendingRestoreIntent.get();PersistentSessionData saved=restoring?*restoring:PersistentSessionData{};
    if(!restoring){
        saved.split=impl_->engine.splitNote();saved.memory=impl_->engine.memory();
        saved.recognition=impl_->engine.recognitionMode();saved.scanArea=impl_->engine.chordScanArea();
        saved.splitEnabled=impl_->engine.splitEnabled();saved.bassInversion=impl_->engine.bassInversion();saved.damperLatch=impl_->engine.damperLatch();saved.tempoLock=impl_->engine.tempoLock();
        saved.globalSplit=impl_->globalSplit.load(std::memory_order_relaxed);saved.autoFill=audio[0].autoFill;saved.autoFillMode=impl_->engine.autoFillMode();saved.scaleAssignment=impl_->scaleAssignment;
        saved.syncStartAutoOff=impl_->engine.syncStartAutoOff();saved.fadeInSeconds=impl_->engine.fadeInSeconds();saved.fadeOutSeconds=impl_->engine.fadeOutSeconds();
    }
    saved.crossfade=crossfade();
    saved.tuning=impl_->state[0]->global;saved.scaleEnabled=impl_->scaleEnabled;
    saved.tuning.limiterEnabled=impl_->limiterEnabled.load(std::memory_order_relaxed);
    saved.tuning.limiterCeilingDb=20.0F*std::log10(std::max(1.0e-10F,impl_->limiterCeiling.load(std::memory_order_relaxed)));
    if(impl_->korgSetBank)saved.catalogRoot=impl_->korgSetBank->status().rootPath;
    const auto validPath=[](const std::string& value){return value.size()<=32768U&&value.find_first_of("\r\n")==std::string::npos&&value.find('\0')==std::string::npos;};
    for(int player=0;player<2;++player){
        auto* context=impl_->stagedContexts[player];
        if(!context)context=impl_->controlContexts[player];
        if(context)plans[player]=context->latest.load(std::memory_order_seq_cst);
        const auto* plan=plans[player];auto& target=saved.players[static_cast<std::size_t>(player)];
        target.effects.capture((plan?plan->baseState:impl_->state[player])->combi);if(context){target.effects.fillModes=context->readFillModes();target.effects.ranges=context->readRanges();target.effects.guitars=context->readGuitars();}
        target.savedStyleBank=plan?plan->savedStyleBank:impl_->savedStyleBanks[player];
        target.savedStylePosition=plan?plan->savedStylePosition:impl_->savedStylePositions[player];
        target.savedStyleName=plan?plan->savedStyleName:impl_->savedStyleNames[player];
        target.sourceIdentity=plan?plan->sourceEditIdentity:impl_->sourceEditIdentities[player];
        target.savedStyleBpm=plan?plan->savedStyleBpm:impl_->savedStyleBpms[player];
        target.path=plan?plan->path:impl_->paths[player];target.sampleMode=plan?plan->sampleMode:impl_->samplePlaybackMode[player];
        target.setRoot.clear();const auto& bank=plan?plan->setBank:impl_->styleBanks[player];if(bank)target.setRoot=bank->status().rootPath;
        if(!restoring){target.autoFill=audio[player].autoFill;target.bpm=audio[player].tempoBpm;}
        if(player==0&&plan)saved.tuning=plan->baseState->global;
        const auto* style=plan?plan->style:impl_->styles[player].get();
        const bool pending=context&&impl_->stagedContexts[player]==context&&audio[player].styleCommitToken!=context;
        if(!restoring&&pending&&!saved.tempoLock&&style)target.bpm=style->tempoBpm;
        int preferred=restoring?target.element:static_cast<int>(audio[player].element);
        if(!restoring&&audio[player].queued!=arranger::Element::Count)preferred=static_cast<int>(audio[player].queued);
        if(preferred>=static_cast<int>(arranger::Element::Fill1)&&preferred<=static_cast<int>(arranger::Element::Fill4))
            preferred=static_cast<int>(arranger::Element::Var1)+preferred-static_cast<int>(arranger::Element::Fill1);
        if(style&&(preferred<0||static_cast<std::size_t>(preferred)>=style->sections.size()||!style->sections[static_cast<std::size_t>(preferred)].available)){
            preferred=-1;for(int element=static_cast<int>(arranger::Element::Var1);element<=static_cast<int>(arranger::Element::Var4);++element)
                if(style->sections[static_cast<std::size_t>(element)].available){preferred=element;break;}
            if(preferred<0)for(std::size_t element=0;element<style->sections.size();++element)if(style->sections[element].available){preferred=static_cast<int>(element);break;}
        }
        target.element=preferred>=0?preferred:static_cast<int>(arranger::Element::Var1);
        const auto& views=plan?plan->views:impl_->tracks[player];
        for(int track=0;track<8;++track){
            const auto& source=views[track];auto& value=target.tracks[static_cast<std::size_t>(track)];
            value.db=source.volumeDb;value.pan=source.pan;value.mute=source.mute;value.overrideMask=source.mixOverrideMask;
            value.programIdentity.clear();
            value.soundSettings=source.soundSettings;
            if(source.soundSettings.setAddress>=0){value.binding=3;value.slot=0;}
            else if(source.originalSoundRouted){value.binding=1;value.slot=0;}
            else if(source.soundSlot>0){value.binding=2;value.slot=source.soundSlot;
                const auto& program=(plan?plan->baseState:impl_->state[player])->combi.part(track).program;
                value.programIdentity=(plan?plan->fixedSoundIdentities:impl_->fixedSoundIdentities[player])[static_cast<std::size_t>(track)];
                if(value.programIdentity.empty()&&program)value.programIdentity=styleEditProgramIdentity(program);
                if(value.programIdentity.empty()){impl_->error="The saved Sound has no stable backing source; previous session retained";return {};}}
            else if(source.assigned){impl_->error="Temporary raw sample assignments cannot be restored after closing; the previous session was kept";return {};}
            else{value.binding=0;value.slot=0;}
        }
        if(!validPath(target.path)||!validPath(target.setRoot)){impl_->error="The Style/source path cannot be stored in the session";return {};}
    }
    saved.tuning.limiterEnabled=impl_->limiterEnabled.load(std::memory_order_relaxed);
    saved.tuning.limiterCeilingDb=std::clamp(20.0F*std::log10(std::max(1.0e-10F,impl_->limiterCeiling.load(std::memory_order_relaxed))),-12.0F,0.0F);
    if(saved.tempoLock)saved.players[1].bpm=saved.players[0].bpm;
    if(!validPath(saved.catalogRoot)){impl_->error="The SET catalog path cannot be stored in the session";return {};}
    std::ostringstream text;text<<std::setprecision(std::numeric_limits<double>::max_digits10);
    text<<"SILVETON_ARRANGER 21\n";
    text<<"GLOBAL "<<saved.split<<' '<<saved.memory<<' '<<saved.crossfade<<' '<<saved.recognition<<' '<<saved.scanArea<<' '
        <<saved.splitEnabled<<' '<<saved.bassInversion<<' '<<saved.damperLatch<<' '<<saved.tempoLock<<' '
        <<saved.globalSplit<<' '<<saved.autoFill<<' '<<saved.autoFillMode<<' '<<saved.scaleAssignment<<'\n';
    text<<"LIVE "<<saved.syncStartAutoOff<<' '<<saved.fadeInSeconds<<' '<<saved.fadeOutSeconds<<'\n';
    const auto& tuning=saved.tuning;
    text<<"TUNING "<<tuning.masterTuneHz<<' '<<static_cast<int>(tuning.transposeSemitones)<<' '<<tuning.masterGainDb<<' '
        <<tuning.eqLowDb<<' '<<tuning.eqMidDb<<' '<<tuning.eqHighDb<<' '<<saved.scaleEnabled<<' '<<static_cast<int>(tuning.scaleRoot)<<' '
        <<tuning.limiterEnabled<<' '<<tuning.limiterCeilingDb;
    for(const auto cents:tuning.scaleOffsetsCents)text<<' '<<cents;
    text<<'\n';
    text<<"CATALOG "<<std::quoted(saved.catalogRoot)<<'\n';
    for(int player=0;player<2;++player){
        const auto& value=saved.players[static_cast<std::size_t>(player)];
        text<<"PLAYER "<<player<<' '<<std::quoted(value.path)<<' '<<value.bpm<<' '<<value.autoFill<<" 0 "<<value.savedStyleBank<<' '<<value.savedStylePosition<<' '<<std::quoted(value.savedStyleName)<<' '<<std::quoted(value.sourceIdentity)<<' '<<value.savedStyleBpm<<'\n';
        text<<"FX "<<player<<' ';
        if(!writeStyleFx(text,value.effects)){impl_->error="Invalid numbered Style FX settings";return {};}
        text<<'\n';
        text<<"SOURCE "<<player<<' '<<std::quoted(value.setRoot)<<' '<<value.sampleMode<<' '<<value.element<<'\n';
        for(int track=0;track<8;++track){const auto& part=value.tracks[static_cast<std::size_t>(track)];
            text<<"TRACK "<<player<<' '<<track<<' '<<part.slot<<' '<<part.db<<' '<<part.pan<<' '<<part.mute<<' '<<part.binding<<' '<<part.overrideMask<<' '<<std::quoted(part.programIdentity);writeStyleSound(text,part.soundSettings);text<<'\n';}
    }
    auto serialized=text.str();PersistentSessionData validation;std::string error;
    if(!parsePersistentSession(serialized,validation,error)){impl_->error=error;return {};}
    return serialized;
}

bool ArrangerHost::persistentSessionRestoreCommitted() const {
    std::lock_guard<std::mutex> lock(impl_->control);
    const std::array<arranger::PlayerSnapshot,2> audio{{impl_->engine.snapshot(0),impl_->engine.snapshot(1)}};
    return impl_->restoreAcknowledged(audio);
}
std::shared_ptr<const ArrangerSourceCheckpoint> ArrangerHost::sourceCheckpoint() const {
    auto checkpoint=std::make_shared<ArrangerSourceCheckpoint>();checkpoint->owner=this;checkpoint->session=persistentSession();
    if(checkpoint->session.empty())return {};
    std::lock_guard<std::mutex> lock(impl_->control);checkpoint->catalog=impl_->korgSetBank;checkpoint->prepared=impl_->preparedSetSamples;
    checkpoint->banks=impl_->restoreSampleBanks;checkpoint->keyboard=impl_->keyboardPrograms;
    checkpoint->channels=impl_->externalChannels.load(std::memory_order_relaxed);checkpoint->damper=impl_->externalDamperConfig.load(std::memory_order_relaxed);checkpoint->notesFiltered=impl_->externalNotesFiltered.load(std::memory_order_relaxed);
    for(int player=0;player<2;++player){(void)impl_->synchronizeCommitted(player);auto* context=impl_->controlContexts[player];
        const auto* plan=context?context->latest.load(std::memory_order_seq_cst):nullptr;
        if(plan){
            auto copy=std::make_shared<Impl::RoutingPlan>(*plan);copy->fillModes=context->readFillModes();copy->ranges=context->readRanges();copy->guitars=context->readGuitars();
            checkpoint->plans[player]=std::move(copy);
        }
        else {auto empty=std::make_shared<Impl::RoutingPlan>();empty->baseState=impl_->state[player];empty->views=impl_->tracks[player];checkpoint->plans[player]=std::move(empty);}
        if(context)checkpoint->links[player]=context->keyboardSets;
    }
    return checkpoint;
}
bool ArrangerHost::restoreSourceCheckpoint(const std::shared_ptr<const ArrangerSourceCheckpoint>& checkpoint){
    if(!checkpoint||checkpoint->owner!=this)return false;
    PersistentSessionData saved;std::string error;if(!parsePersistentSession(checkpoint->session,saved,error))return false;
    std::lock_guard<std::mutex> lock(impl_->control);
    // Allocate/retain both old plans before publishing either one.
    const bool previousScale=impl_->scaleEnabled;const int previousAssignment=impl_->scaleAssignment;
    impl_->scaleEnabled=saved.scaleEnabled;impl_->scaleAssignment=saved.scaleAssignment;
    std::array<const Impl::RoutingPlan*,2> plans{};
    for(int player=0;player<2;++player){if(!checkpoint->plans[player]||!checkpoint->plans[player]->baseState)return false;
        auto* context=impl_->newContext(player);context->keyboardSets=checkpoint->links[player];
        auto plan=std::make_unique<Impl::RoutingPlan>(*checkpoint->plans[player]);plans[player]=impl_->retainPlan(player,std::move(plan),context);
        if(!plans[player]){impl_->scaleEnabled=previousScale;impl_->scaleAssignment=previousAssignment;return false;}}
    impl_->korgSetBank=checkpoint->catalog;impl_->preparedSetSamples=checkpoint->prepared;impl_->restoreSampleBanks=checkpoint->banks;
    impl_->keyboardPrograms=checkpoint->keyboard;impl_->styleReadCache.clear();
    impl_->externalChannels.store(checkpoint->channels,std::memory_order_relaxed);impl_->externalDamperConfig.store(checkpoint->damper,std::memory_order_relaxed);impl_->externalNotesFiltered.store(checkpoint->notesFiltered,std::memory_order_relaxed);
    impl_->scaleEnabled=saved.scaleEnabled;impl_->scaleAssignment=saved.scaleAssignment;
    bool accepted=impl_->engine.postChordControls(saved.recognition,saved.scanArea,saved.splitEnabled,saved.bassInversion,saved.damperLatch,saved.split,saved.memory);
    const auto post=[&](arranger::CommandType type,int player,int index=0,double value=0){accepted=impl_->engine.post({type,player,index,value,0})&&accepted;};
    post(arranger::CommandType::SetTempoLock,0,0,saved.tempoLock?1.0:0.0);
    post(arranger::CommandType::SetAutoFill,0,0,saved.autoFill?1.0:0.0);post(arranger::CommandType::SetAutoFillMode,0,0,saved.autoFillMode);
    post(arranger::CommandType::SetSyncStartAutoOff,0,0,saved.syncStartAutoOff?1.0:0.0);
    post(arranger::CommandType::SetFadeTimes,0,static_cast<int>(std::lround(saved.fadeOutSeconds*1000.0F)),saved.fadeInSeconds);
    for(int player=0;player<2;++player){post(arranger::CommandType::Stop,player);post(arranger::CommandType::SetSyncStart,player,0,0);post(arranger::CommandType::SetSyncStop,player,0,0);
        impl_->stagedContexts[player]=plans[player]->context;impl_->adoptControlPlan(player,plans[player]);impl_->savedSyncStartPending[player]=false;
        accepted=(plans[player]->styleOwner?impl_->engine.stageStyle(player,plans[player]->styleOwner,plans[player]->sampleMode,plans[player]->context):impl_->engine.installStyle(player,nullptr))&&accepted;
        post(arranger::CommandType::SetTempo,player,0,saved.players[player].bpm);
        if(plans[player]->styleOwner)post(arranger::CommandType::SelectElement,player,saved.players[player].element);
        for(int track=0;track<8;++track)post(arranger::CommandType::SetTrackMute,player,track,plans[player]->views[static_cast<std::size_t>(track)].mute?1.0:0.0);
    }
    impl_->globalSplit.store(saved.globalSplit,std::memory_order_relaxed);impl_->xfade.store(saved.crossfade,std::memory_order_relaxed);
    impl_->limiterEnabled.store(saved.tuning.limiterEnabled,std::memory_order_relaxed);impl_->limiterCeiling.store(std::pow(10.0F,saved.tuning.limiterCeilingDb*0.05F),std::memory_order_relaxed);
    impl_->persistentRestoreContexts={{plans[0]->context,plans[1]->context}};impl_->pendingRestoredText=checkpoint->session;impl_->pendingRestoreIntent=std::make_unique<PersistentSessionData>(saved);
    impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error=accepted?std::string{}:"The previous SET could not be fully queued for restoration";return accepted;
}

std::vector<std::string> ArrangerHost::persistentSessionSetRoots(const std::string& text) const {
    PersistentSessionData saved;std::string error;
    if(!parsePersistentSession(text,saved,error)){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=error;return {};}
    return persistentRoots(saved);
}
bool ArrangerHost::persistentSessionNeedsSamplerBank(const std::string& text) const {
    PersistentSessionData saved;std::string error;
    if(!parsePersistentSession(text,saved,error)){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=error;return false;}
    for(const auto& player:saved.players)for(const auto& track:player.tracks)if(track.binding==2)return true;
    return false;
}
bool ArrangerHost::beginPersistentSessionRestore(const std::string& text,
        const std::vector<std::string>& additionalSetRoots){
    PersistentSessionData saved;std::string error;
    const auto reject=[&](const std::string& message){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=message;return false;};
    if(!parsePersistentSession(text,saved,error))return reject(error);
    auto requested=persistentRoots(saved);
    requested.insert(requested.end(),additionalSetRoots.begin(),additionalSetRoots.end());
    std::vector<std::string> roots;
    for(const auto& root:requested){
        if(root.empty()||root.size()>32768U||root.find_first_of("\r\n")!=std::string::npos||root.find('\0')!=std::string::npos)
            return reject("The saved keyboard has an invalid SET folder path");
        std::unique_ptr<char,decltype(&std::free)> canonical(::realpath(root.c_str(),nullptr),&std::free);
        if(!canonical||!arranger::canSelectPa5xKstDirectory(canonical.get()))
            return reject("The saved keyboard SET folder is missing or inaccessible: "+root);
        const std::string normalized=canonical.get();
        if(std::find(roots.begin(),roots.end(),normalized)==roots.end())roots.push_back(normalized);
        if(roots.size()>10U)return reject("The saved session references too many SET folders");
    }
    std::lock_guard<std::mutex> lock(impl_->control);impl_->restoreSampleBanks.clear();
    impl_->expectedRestoreRoots=std::move(roots);impl_->restoreCollecting=true;
    impl_->restoreKeyboardLease=!additionalSetRoots.empty();impl_->rememberPreparedSet(impl_->preparedSetSamples);
    impl_->error.clear();return true;
}
void ArrangerHost::cancelPersistentSessionRestore(){
    std::lock_guard<std::mutex> lock(impl_->control);impl_->restoreSampleBanks.clear();impl_->expectedRestoreRoots.clear();
    impl_->restoreCollecting=false;impl_->restoreKeyboardLease=false;
}

bool ArrangerHost::restorePersistentSession(const std::string& text){
    PersistentSessionData saved;std::string error;
    const auto reject=[&](const std::string& message){std::lock_guard<std::mutex> lock(impl_->control);impl_->error=message;return false;};
    if(!parsePersistentSession(text,saved,error))return reject(error);
    for(auto& player:saved.players)player.setRoot=canonicalRestoreRoot(player.setRoot);
    saved.catalogRoot=canonicalRestoreRoot(saved.catalogRoot);
    std::vector<std::shared_ptr<const Impl::PreparedSetSamples>> available;
    {std::lock_guard<std::mutex> lock(impl_->control);available=impl_->restoreSampleBanks;
        if(impl_->preparedSetSamples)available.push_back(impl_->preparedSetSamples);}
    std::array<std::shared_ptr<const Impl::PreparedSetSamples>,2> sources;
    std::array<std::shared_ptr<const arranger::Pa5xStyleRead>,2> reads;
    std::array<std::shared_ptr<const arranger::Style>,2> styles;
    std::array<std::array<sampler::ProgramPtr,8>,2> manualPrograms;
    std::array<std::string,2> manualWarnings;
    // Validate every file, SET identity and saved fixed slot before changing
    // the active session. Missing storage/permission can be retried safely.
    for(int player=0;player<2;++player){
        const auto& value=saved.players[static_cast<std::size_t>(player)];
        if(!value.setRoot.empty()){
            for(auto candidate=available.rbegin();candidate!=available.rend();++candidate)
                if((*candidate)->bank->status().rootPath==value.setRoot){sources[player]=*candidate;break;}
            if(!sources[player])return reject("The saved Style's SET has not been prepared yet: "+value.setRoot);
            if(!bankForPath(sources[player]->bank,value.path))return reject("The saved Style is missing or no longer belongs to its original SET: "+value.path);
        }
        if(!value.path.empty()){
            const auto dot=value.path.find_last_of('.');std::string extension=dot==std::string::npos?"":value.path.substr(dot);
            std::transform(extension.begin(),extension.end(),extension.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
            if(extension==".stg"||arranger::paStyleSlot(value.path)){
                reads[player]=std::make_shared<arranger::Pa5xStyleRead>(arranger::readPa5xStyleFile(value.path,sources[player]?sources[player]->bank.get():nullptr));
                if(!reads[player]->valid||!reads[player]->nativeStyle)return reject(reads[player]->error.empty()?"The saved Korg Style could not be read":reads[player]->error);
                styles[player]=reads[player]->nativeStyle;
            }else{
                const auto loaded=readStyle(value.path);if(!loaded)return reject(loaded.error);styles[player]=loaded.style;
            }
            if(!value.sourceIdentity.empty()&&styleEditIdentity(value.path,*styles[player])!=value.sourceIdentity)
                return reject("The saved Style source file changed; select its current revision again: "+value.path);
            if(!value.savedStyleName.empty()){
                auto renamed=std::make_shared<arranger::Style>(*styles[player]);renamed->name=value.savedStyleName;styles[player]=renamed;
                if(reads[player]){auto renamedRead=std::make_shared<arranger::Pa5xStyleRead>(*reads[player]);renamedRead->nativeStyle=renamed;reads[player]=std::move(renamedRead);}
            }
            if(!styles[player]->sections[static_cast<std::size_t>(value.element)].available)return reject("The saved Style variation is no longer available: "+value.path);
        }
        if(value.sampleMode&&(!reads[player]||!sources[player]))return reject("The saved native sample routes require their original prepared SET");
        for(int track=0;track<8;++track){const auto& binding=value.tracks[static_cast<std::size_t>(track)];
            if(binding.binding==3){
                if(sources[player])manualPrograms[player][track]=findStyleSetSound(sources[player]->programs,binding.soundSettings);
                if(!manualPrograms[player][track])appendWarning(manualWarnings[player],std::string(kTrackNames[track])+": saved SET Sound unavailable");
            }else if(binding.binding==2){manualPrograms[player][track]=resolveArrangerBankSound(binding.slot);
                const bool matches=manualPrograms[player][track]&&(binding.programIdentity.empty()||styleEditProgramMatches(manualPrograms[player][track],binding.programIdentity,saved.version<20,saved.version<21));
                if(!matches){
                    if(saved.version<6)return reject("The saved sampler Sound slot is not available yet: "+std::to_string(binding.slot));
                    manualPrograms[player][track].reset();
                    appendWarning(manualWarnings[player],std::string(kTrackNames[track])+": required saved Sound source is unavailable; track remains silent");
                }else if(!binding.programIdentity.empty()){
                    saved.players[static_cast<std::size_t>(player)].tracks[static_cast<std::size_t>(track)].programIdentity=
                        styleEditProgramIdentity(manualPrograms[player][track]);
                }
            }
        }
    }
    // Startup/SET restore prepares only its two selected Styles, outside the
    // coarse control lock and before any of their routing plans are posted.
    std::vector<sampler::ProgramPtr> entryPrograms;
    for(int player=0;player<2;++player){
        if(saved.players[static_cast<std::size_t>(player)].sampleMode&&reads[player]&&sources[player]){
            auto entries=styleEntryPrograms(*reads[player],sources[player]->programs);
            entryPrograms.insert(entryPrograms.end(),entries.begin(),entries.end());
        }
        for(const auto& program:manualPrograms[player])if(program)entryPrograms.push_back(program);
    }
    (void)arranger::warmPa5xSamplePrograms(entryPrograms);
    std::lock_guard<std::mutex> lock(impl_->control);
    if(!saved.catalogRoot.empty()&&(!impl_->korgSetBank||impl_->korgSetBank->status().rootPath!=saved.catalogRoot)){
        impl_->error="The saved SET catalog has not finished loading";return false;
    }
    std::array<const Impl::RoutingPlan*,2> plans{};
    const bool previousScale=impl_->scaleEnabled;const int previousScaleAssignment=impl_->scaleAssignment;
    impl_->scaleEnabled=saved.scaleEnabled;impl_->scaleAssignment=saved.scaleAssignment;
    for(int player=0;player<2;++player){
        auto* context=impl_->newContext(player);const auto& value=saved.players[static_cast<std::size_t>(player)];
        auto base=std::make_shared<sampler::EngineState>(*impl_->state[player]);base->global=saved.tuning;base->global.limiterEnabled=false;value.effects.apply(base->combi);
        if(reads[player]&&value.effects.sourceEffects)applyOriginalStyleEffects(base->combi,*reads[player]);
        if(reads[player])applyOriginalStyleTracks(base->combi,*reads[player],&value.effects.channels);
        auto views=impl_->tracks[player];
        const auto originalMute=styles[player]?static_cast<unsigned>(styles[player]->initialMuteMask&styles[player]->initialMuteKnownMask):0U;
        for(int track=0;track<8;++track){const auto& binding=value.tracks[static_cast<std::size_t>(track)];
            const auto overrides=static_cast<unsigned>(binding.overrideMask);auto& part=base->combi.part(track);
            part.levelDb=(overrides&kMixVolume)!=0?binding.db:0.0F;part.pan=(overrides&kMixPan)!=0?binding.pan:0.0F;
            part.mute=(overrides&kMixMute)!=0?binding.mute:(originalMute&(1U<<track))!=0;
            auto& view=views[track];view.volumeDb=part.levelDb;view.pan=part.pan;view.mute=part.mute;view.mixOverrideMask=static_cast<std::uint8_t>(overrides);
        }
        std::unique_ptr<Impl::RoutingPlan> plan;
        if(value.sampleMode){
            std::set<std::uint32_t> needed;for(const auto& section:reads[player]->sections)if(section.available)
                for(const auto& track:section.tracks)for(const auto& cv:track.cvs)if(cv.available&&cv.hasNotes)
                    for(const auto& change:cv.soundChanges){Impl::OriginalAddress address{change.msb,change.lsb,change.program};if(address.complete())needed.insert(address.key());}
            std::vector<ArrangerOriginalProgram> programs;programs.reserve(needed.size());
            for(const auto address:needed){const auto found=sources[player]->programs.find(address);if(found==sources[player]->programs.end())continue;
                programs.push_back({static_cast<int>((address>>16)&127U),static_cast<int>((address>>8)&127U),static_cast<int>(address&127U),found->second});}
            (void)impl_->buildSamplePlan(player,context,reads[player],sources[player]->bank,value.path,programs,sources[player]->warnings,true,base,views,&plan);
        }else{
            plan=std::make_unique<Impl::RoutingPlan>();plan->styleOwner=styles[player];plan->read=reads[player];plan->setBank=sources[player]?sources[player]->bank:nullptr;
            plan->path=value.path;plan->baseState=base;plan->views=views;
        }
        if(!plan){impl_->scaleEnabled=previousScale;impl_->scaleAssignment=previousScaleAssignment;impl_->error="The saved Style sample graph could not be prepared";return false;}
        plan->sourceEditIdentity=value.sourceIdentity;plan->savedStyleBank=value.savedStyleBank;plan->savedStylePosition=value.savedStylePosition;plan->savedStyleName=value.savedStyleName;plan->savedStyleBpm=value.savedStyleBpm;
        appendWarning(plan->warnings,manualWarnings[player]);
        for(std::size_t track=0;track<value.tracks.size();++track)plan->fixedSoundIdentities[track]=value.tracks[track].programIdentity;
        if(saved.version==4)appendWarning(plan->warnings,"Legacy session mute defaults were migrated to the original Style balance; v4 did not record explicit unmute provenance.");
        auto combined=std::make_shared<sampler::EngineState>(*plan->baseState);
        for(int track=0;track<8;++track){const auto& binding=value.tracks[static_cast<std::size_t>(track)];
            auto& part=combined->combi.part(track);auto& view=plan->views[track];
            view.soundSettings=binding.soundSettings;
            if(binding.binding!=1){
                plan->trackMask=static_cast<std::uint8_t>(plan->trackMask&~(1U<<track));plan->required[track].clear();view.originalSoundRouted=false;
                part.program=manualPrograms[player][track];part.enabled=part.program!=nullptr;part.soundSlotId=static_cast<std::uint16_t>(binding.slot);
                part.name=part.program?part.program->name:kTrackNames[track];view.soundSlot=binding.slot;view.assigned=part.enabled;view.soundName=part.program?part.program->name:"Unassigned";
            }
        }
        plan->ranges=value.effects.ranges;plan->guitars=value.effects.guitars;plan->fillModes=value.effects.fillModes;plan->baseState=std::move(combined);plans[player]=impl_->retainPlan(player,std::move(plan),context);
        if(!plans[player]){impl_->scaleEnabled=previousScale;impl_->scaleAssignment=previousScaleAssignment;return false;}
    }
    // Restoration is deliberately stopped. Sync intent is not carried into
    // the session, including the deferred flag used by legacy setup loading.
    bool accepted=impl_->engine.postChordControls(saved.recognition,saved.scanArea,saved.splitEnabled,saved.bassInversion,saved.damperLatch,saved.split,saved.memory);
    const auto post=[&](arranger::CommandType type,int player,int index=0,double value=0){
        accepted=impl_->engine.post({type,player,index,value,0})&&accepted;
    };
    post(arranger::CommandType::SetTempoLock,0,0,saved.tempoLock?1.0:0.0);
    post(arranger::CommandType::SetAutoFill,0,0,saved.autoFill?1.0:0.0);
    post(arranger::CommandType::SetAutoFillMode,0,0,saved.autoFillMode);
    post(arranger::CommandType::SetSyncStartAutoOff,0,0,saved.syncStartAutoOff?1.0:0.0);
    post(arranger::CommandType::SetFadeTimes,0,static_cast<int>(std::lround(saved.fadeOutSeconds*1000.0F)),saved.fadeInSeconds);
    for(int player=0;player<2;++player){
        post(arranger::CommandType::Stop,player);post(arranger::CommandType::SetSyncStart,player,0,0);post(arranger::CommandType::SetSyncStop,player,0,0);
        impl_->stagedContexts[player]=plans[player]->context;impl_->adoptControlPlan(player,plans[player]);impl_->savedSyncStartPending[player]=false;
        const bool installed=styles[player]?
            impl_->engine.stageStyle(player,styles[player],plans[player]->sampleMode,plans[player]->context):
            impl_->engine.installStyle(player,nullptr);
        if(!installed){impl_->error="The saved Style failed staging validation";return false;}
        const auto& value=saved.players[static_cast<std::size_t>(player)];
        post(arranger::CommandType::SetTempo,player,0,value.bpm);
        if(styles[player])post(arranger::CommandType::SelectElement,player,value.element);
        for(int track=0;track<8;++track)post(arranger::CommandType::SetTrackMute,player,track,plans[player]->views[static_cast<std::size_t>(track)].mute?1.0:0.0);
    }
    impl_->globalSplit.store(saved.globalSplit,std::memory_order_relaxed);
    impl_->xfade.store(saved.crossfade,std::memory_order_relaxed);impl_->limiterEnabled.store(saved.tuning.limiterEnabled,std::memory_order_relaxed);
    impl_->limiterCeiling.store(std::pow(10.0F,saved.tuning.limiterCeilingDb*0.05F),std::memory_order_relaxed);
    if(!accepted){impl_->error="The saved session was partly applied because the arranger command queue is full; retry restoration";return false;}
    impl_->persistentRestoreContexts={{plans[0]->context,plans[1]->context}};impl_->pendingRestoredText=text;
    impl_->pendingRestoreIntent=std::make_unique<PersistentSessionData>(saved);
    // Native keyboard metadata is restored by the UI after the Style session.
    // Its exact SET Programs remain pinned until that caller releases the lease.
    if(!impl_->restoreKeyboardLease){
        impl_->restoreSampleBanks.clear();impl_->expectedRestoreRoots.clear();impl_->restoreCollecting=false;
    }
    impl_->persistentRevision.fetch_add(1,std::memory_order_relaxed);impl_->error.clear();return true;
}

bool ArrangerHost::saveSetup(const std::string& path) const {
    std::ostringstream text;
    text << std::setprecision(std::numeric_limits<double>::max_digits10);
    const std::array<ArrangerPlayerView, 2> views{{snapshot(0), snapshot(1)}};
    for (const auto& view : views) for (const auto& track : view.tracks)
        if (track.assigned && track.soundSlot == 0) {
            std::lock_guard<std::mutex> lock(impl_->control);
            impl_->error = track.originalSoundRouted ?
                "Korg sample/Sound routes must be rebuilt from their source KST; saving these bindings is not implemented" :
                "Raw PCM track assignments are temporary. Assign a saved bank Sound before saving the setup.";
            return false;
        }
    for (const auto& view : views)
        if (view.sourcePath.find_first_of("\r\n") != std::string::npos ||
            view.sourcePath.find('\0') != std::string::npos) return false;
    const auto& global = views[0];
    text << "SILVETON_ARRANGER 3\n";
    text << "GLOBAL " << global.split << ' ' << global.memory << ' ' << crossfade() << ' '
         << global.chordRecognitionMode << ' ' << global.chordScanArea << ' '
         << global.splitEnabled << ' ' << global.bassInversion << ' ' << global.damperLatch << ' '
         << global.tempoLock << '\n';
    for (int p = 0; p < 2; ++p) {
        const auto& s = views[static_cast<std::size_t>(p)];
        // Tempo Lock has one shared tempo. Use one published value for both
        // saved players even if this read straddles the engine publication.
        const double tempo = global.tempoLock ? global.bpm : s.bpm;
        text << "PLAYER " << p << ' ' << std::quoted(s.sourcePath) << ' ' << tempo << ' ' << s.autoFill << ' ' << s.syncStart << '\n';
        for (int t = 0; t < 8; ++t) text << "TRACK " << p << ' ' << t << ' ' << s.tracks[t].soundSlot << ' ' << s.tracks[t].volumeDb << ' ' << s.tracks[t].pan << ' ' << s.tracks[t].mute << '\n';
    }
    const std::string temporary = path + ".tmp";
    std::ofstream file(temporary, std::ios::binary | std::ios::trunc);
    const auto content = text.str();
    file.write(content.data(), static_cast<std::streamsize>(content.size()));
    file.flush();
    if (!file) return false;
    file.close();
    if (file.fail()) return false;
    return std::rename(temporary.c_str(), path.c_str()) == 0;
}
bool ArrangerHost::loadSetup(const std::string& path) {
    // Parsing and all resource reads precede mutation. Sounds are deliberately
    // left unresolved: NativeSamplerEngine::nativeArrangerLoadSetup resolves
    // saved fixed bank slots, reporting any missing resource to the caller.
    const auto reject = [&](const char* reason) {
        std::lock_guard<std::mutex> lock(impl_->control);
        impl_->error = reason;
        return false;
    };
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) return reject("Cannot open arranger setup");
    const auto fileSize = file.tellg();
    if (fileSize < 0 || fileSize > static_cast<std::streamoff>(1024 * 1024))
        return reject("Arranger setup exceeds the supported file size");
    file.seekg(0);
    std::string line;
    if (!std::getline(file, line)) return reject("Missing arranger setup header");
    std::istringstream header(line);
    std::string magic;
    int version = 0;
    const auto endRecord = [](std::istringstream& record) {
        record >> std::ws;
        return record.eof();
    };
    const auto boolean = [](std::istringstream& record, bool& value) {
        int raw = -1;
        if (!(record >> raw) || (raw != 0 && raw != 1)) return false;
        value = raw != 0;
        return true;
    };
    if (!(header >> magic >> version) || magic != "SILVETON_ARRANGER" ||
        (version != 1 && version != 2 && version != 3) || !endRecord(header))
        return reject("Unsupported or malformed arranger setup header");
    struct P { std::string path; double bpm{120}; bool fill{true}, sync{false}; bool seen{false}; };
    struct T { int slot{0}; float db{0}, pan{0}; bool mute{false}, seen{false}; };
    std::array<P,2> players;
    std::array<std::array<T,8>,2> tracks;
    std::array<std::shared_ptr<const arranger::Style>,2> imported;
    std::array<std::shared_ptr<const arranger::Pa5xStyleRead>,2> reads;
    std::array<std::shared_ptr<const arranger::Pa5xSetBank>,2> banks;
    // Version 1 used one-note -> Major, matching Fingered (1 Note).
    int split = 60, recognition = 2, scanArea = 1;
    bool memory = true, splitEnabled = true, bassInversion = false, damperLatch = false, tempoLock = false;
    float xfade = 0;
    bool globalSeen = false;
    while (std::getline(file, line)) {
        if (line.size() > 65536) return reject("Arranger setup record is too long");
        std::istringstream record(line);
        std::string kind;
        if (!(record >> kind)) continue;
        if (kind == "GLOBAL") {
            if (globalSeen || !(record >> split) || !boolean(record, memory) ||
                !(record >> xfade) || split < 1 || split > 127 ||
                !std::isfinite(xfade) || xfade < 0 || xfade > 1)
                return reject("Invalid arranger GLOBAL record");
            if (version >= 2 && (!(record >> recognition >> scanArea) ||
                recognition < 0 || recognition > 4 || scanArea < 0 || scanArea > 3 ||
                !boolean(record, splitEnabled) || !boolean(record, bassInversion) ||
                !boolean(record, damperLatch)))
                return reject("Invalid arranger chord controls");
            if (version == 3 && !boolean(record, tempoLock))
                return reject("Invalid arranger Tempo Lock setting");
            if (!endRecord(record)) return reject("Unexpected arranger GLOBAL fields");
            globalSeen = true;
        } else if (kind == "PLAYER") {
            int p;
            if (!(record >> p) || !playerOk(p) || players[p].seen)
                return reject("Invalid or repeated arranger PLAYER record");
            auto& v = players[p];
            record >> std::ws;
            if (record.peek() != '"' || !(record >> std::quoted(v.path) >> v.bpm) ||
                !boolean(record, v.fill) || !boolean(record, v.sync) ||
                v.path.find('\0') != std::string::npos ||
                !std::isfinite(v.bpm) || v.bpm < 20 || v.bpm > 400 || !endRecord(record))
                return reject("Invalid arranger PLAYER settings");
            v.seen = true;
        } else if (kind == "TRACK") {
            int p,t;
            if (!(record >> p >> t) || !trackOk(p,t) || tracks[p][t].seen)
                return reject("Invalid or repeated arranger TRACK record");
            auto& v = tracks[p][t];
            if (!(record >> v.slot >> v.db >> v.pan) || !boolean(record, v.mute) ||
                v.slot < 0 || v.slot > 500 || !std::isfinite(v.db) || !std::isfinite(v.pan) ||
                v.db < -60 || v.db > 12 || v.pan < -1 || v.pan > 1 || !endRecord(record))
                return reject("Invalid arranger TRACK settings");
            v.seen = true;
        } else return reject("Unknown arranger setup record");
    }
    if (!file.eof() || !globalSeen) return reject("Incomplete arranger setup");
    if (tempoLock && players[0].seen && players[1].seen && players[0].bpm != players[1].bpm)
        return reject("Tempo Lock setup must have the same tempo for both players");
    for (int p=0;p<2;++p) {
        if (!players[p].seen) return reject("Missing arranger PLAYER record");
        for (const auto& t:tracks[p]) if (!t.seen) return reject("Missing arranger TRACK record");
        if (!players[p].path.empty()) {
            {std::lock_guard<std::mutex> lock(impl_->control);banks[p]=impl_->korgSetBank;}
            banks[p]=bankForPath(std::move(banks[p]),players[p].path);
            const auto dot=players[p].path.find_last_of('.');
            std::string extension=dot==std::string::npos?"":players[p].path.substr(dot);
            std::transform(extension.begin(),extension.end(),extension.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
            arranger::ImportResult result;
            if(extension==".stg"||arranger::paStyleSlot(players[p].path)){
                reads[p]=std::make_shared<arranger::Pa5xStyleRead>(arranger::readPa5xStyleFile(players[p].path,banks[p].get()));
                result.style=reads[p]->nativeStyle;result.error=reads[p]->error;
            }else result=readStyle(players[p].path);
            if (!result) { std::lock_guard<std::mutex> lock(impl_->control); impl_->error=result.error; return false; }
            imported[p] = result.style;
        }
    }
    // The complete chord-control group is one audio command. A full queue is
    // rejected before changing the host states or any installed Style. Other
    // Style/track setup publications still use the existing separate commands.
    if (!impl_->engine.postChordControls(recognition, scanArea, splitEnabled,
                                        bassInversion, damperLatch, split, memory))
        return reject("Arranger command queue full; setup was not applied");
    // Restore the lock policy before the saved player tempos are posted.
    // Each saved tempo is equal when the lock is enabled, as validated above.
    if (!setTempoLock(tempoLock, 0))
        return reject("Arranger setup was partly applied because the command queue is full");
    bool commandsAccepted = true;
    const auto accepted = [&](bool ok) { commandsAccepted = ok && commandsAccepted; };
    impl_->globalSplit.store(split,std::memory_order_relaxed);
    accepted(setAutoFill(0,players[xfade<0.5F?0:1].fill));
    accepted(setAutoFillMode(1));
    for (int p=0;p<2;++p) {
        accepted(stop(p));
        {
            std::lock_guard<std::mutex> lock(impl_->control);
            if (!impl_->engine.installStyle(p, imported[p])) {
                impl_->error = "Style validation failed while applying arranger setup";
                return false;
            }
            (void)impl_->synth[p].postPanic();
            impl_->stagedContexts[p]=nullptr;
            impl_->styles[p]=imported[p]; impl_->paths[p]=players[p].path;
            impl_->styleReads[p]=std::move(reads[p]);impl_->styleBanks[p]=std::move(banks[p]);
            impl_->originalRoutingMask[p]=0;impl_->originalPrograms[p].clear();
            impl_->samplePlaybackMode[p]=false;impl_->samplePlaybackWarnings[p].clear();impl_->savedSyncStartPending[p]=false;
            for(auto& required:impl_->requiredOriginalPrograms[p])required.clear();
            impl_->state[p] = std::make_shared<sampler::EngineState>(*impl_->state[p]);
            
            impl_->publishState(p);
        }
        for (int t=0;t<8;++t) {
            accepted(assignSound(p,t,0,nullptr));
            accepted(setTrackVolume(p,t,tracks[p][t].db));
            accepted(setTrackPan(p,t,tracks[p][t].pan));
            accepted(setTrackMute(p,t,tracks[p][t].mute));
            std::lock_guard<std::mutex> lock(impl_->control);
            impl_->tracks[p][t].soundSlot=tracks[p][t].slot;
            if (tracks[p][t].slot>0) impl_->tracks[p][t].soundName="Unresolved slot " + std::to_string(tracks[p][t].slot);
        }
        accepted(setTempo(p,players[p].bpm));
        accepted(setSyncStart(p,false));
        { std::lock_guard<std::mutex> lock(impl_->control); impl_->savedSyncStartPending[p]=players[p].sync; }
    }
    setCrossfade(xfade);
    if (!commandsAccepted)
        return reject("Arranger setup was partly applied because the command queue is full");
    return true;
}

} // namespace silveton::host
