// Visit only the channel controls. A Style never stores a PCM buffer, a keyboard
// assignment, a mixer trim, or an internal routing channel in this record.
template<class Part,class Visit>
void visitStyleChannel(Part& u,Visit visit,bool gates=true,bool sourcePortamento=true){
    visit(u.voiceMode,0,2);visit(u.portaMode,0,3);visit(u.portamentoSec,0,.1);
    visit(u.portaTime,0,127);visit(u.portaFingered,0,1);visit(u.portaRateMode,0,1);
    visit(u.octave,-4,4);visit(u.transposeSemitones,-36,36);visit(u.tuneCents,-1200,1200);visit(u.pitchBendRange,0,24);
    visit(u.keyLow,0,127);visit(u.keyHigh,0,127);visit(u.velocityLow,1,127);visit(u.velocityHigh,1,127);
    visit(u.independentLayerRanges,0,1);visit(u.damperEnabled,0,1);visit(u.breathEnabled,0,1);
    visit(u.expressionEnabled,0,1);visit(u.aftertouchEnabled,0,1);
    visit(u.toneAttackMs,-1,10000);visit(u.toneDecayMs,-1,10000);visit(u.toneSustain,-1,1);
    visit(u.toneReleaseMs,-1,10000);visit(u.toneCutoffHz,-1,20000);visit(u.toneResonance,-1,1);
    visit(u.toneExtra.lfoRateHz,.05,20);visit(u.toneExtra.lfoDepthCents,0,200);visit(u.toneExtra.lfoDelayMs,0,10000);
    visit(u.toneExtra.lfoFadeMs,0,10000);visit(u.toneExtra.lfoModWheel,0,1);
    visit(u.eq.on,0,1);
    for(auto& b:u.eq.band){visit(b.on,0,1);visit(b.freqHz,20,20000);visit(b.gainDb,-18,18);visit(b.q,.1,10);}
    visit(u.eq.hpOn,0,1);visit(u.eq.hpHz,10,2000);visit(u.eq.hpSlopeDb,12,24);
    visit(u.eq.lpOn,0,1);visit(u.eq.lpHz,1000,20000);visit(u.eq.lpSlopeDb,12,24);
    if(gates){
        auto& g=u.channelGate;
        visit(g.enabled,0,1);visit(g.fastAttack,0,1);visit(g.expand,0,1);
        visit(g.thresholdDb,-30,10);visit(g.rangeDb,0,40);visit(g.holdSec,0,4);visit(g.releaseSec,.1,4);
    }
    if(sourcePortamento){visit(u.sourcePortamentoInherit,0,1);visit(u.sourceVoiceInherit,0,1);}
}
struct StyleChannelPreset {
    std::vector<double> values;
    void capture(const sampler::UpperPart& part){
        values.clear();
        visitStyleChannel(part,[this](const auto& field,double,double){values.push_back(static_cast<double>(field));});
    }
    void apply(sampler::UpperPart& part) const {
        if(values.empty()){
            static const StyleChannelPreset defaults=[]{
                StyleChannelPreset preset;preset.capture(sampler::UpperPart{});return preset;
            }();
            defaults.apply(part);return;
        }
        std::size_t i=0;
        visitStyleChannel(part,[&](auto& field,double,double){
            field=static_cast<std::decay_t<decltype(field)>>(values[i++]);
        });
        part.eqLowDb=part.eq.band[0].gainDb;part.eqMidDb=part.eq.band[2].gainDb;part.eqHighDb=part.eq.band[4].gainDb;
    }
    bool read(std::istream& in,bool gates,bool sourcePortamento){
        sampler::UpperPart part;bool ok=true;
        // Older authored Style records had only manual glide controls.
        part.sourcePortamentoInherit=sourcePortamento;
        part.sourceVoiceInherit=sourcePortamento;
        visitStyleChannel(part,[&](auto& field,double lo,double hi){
            using T=std::decay_t<decltype(field)>;
            double v=0;if(!ok||!(in>>v)||!std::isfinite(v)){ok=false;return;}
            // Text records may contain the exact promoted value of a float endpoint.
            if(v<static_cast<float>(lo)||v>static_cast<float>(hi)||(!std::is_floating_point_v<T>&&std::trunc(v)!=v)){ok=false;return;}
            field=static_cast<T>(v);
        },gates,sourcePortamento);
        const auto inherited=[](float v,float min){return v==-1.0F||v>=min;};
        if(!ok||part.keyLow>part.keyHigh||part.velocityLow>part.velocityHigh||
           !inherited(part.toneAttackMs,0)||!inherited(part.toneDecayMs,0)||!inherited(part.toneSustain,0)||
           !inherited(part.toneReleaseMs,0)||!inherited(part.toneCutoffHz,20)||!inherited(part.toneResonance,0)||
           (part.eq.hpSlopeDb!=12&&part.eq.hpSlopeDb!=24)||(part.eq.lpSlopeDb!=12&&part.eq.lpSlopeDb!=24))return false;
        capture(part);return true;
    }
};
