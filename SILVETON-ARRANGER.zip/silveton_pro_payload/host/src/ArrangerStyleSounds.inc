// Style-local sound assignments and key trims. All preparation runs on the control thread.
namespace {
void writeStyleSound(std::ostream& out,const StyleSoundSettings& setting){
    const auto count=std::count_if(setting.keyDb.begin(),setting.keyDb.end(),[](int db){return db!=0;});
    out<<' '<<setting.setAddress<<' '<<count;
    for(int note=0;note<128;++note)if(setting.keyDb[note]!=0)out<<' '<<note<<' '<<int(setting.keyDb[note]);
    out<<' '<<(setting.tones?setting.tones->size():0U);
    if(setting.tones)for(const auto& row:*setting.tones){
        const auto& t=row.second;
        out<<' '<<row.first<<' '<<t.attack<<' '<<t.decay<<' '<<t.sustain<<' '<<t.release<<' '<<t.pan<<' '<<t.tune<<' '<<t.gate;
    }
    out<<' '<<setting.trigger;
}
bool readStyleSound(std::istream& in,StyleSoundSettings& setting,bool hasTones,bool hasTrigger){
    int address,count;
    if(!(in>>address>>count)||count<0||count>128||
       (address!=-1&&(address<0||(address&~0x7f7f7f)!=0)))return false;
    StyleSoundSettings parsed;
    parsed.setAddress=address;
    for(int i=0;i<count;++i){
        int note,db;
        if(!(in>>note>>db)||note<0||note>127||db< -60||db>12||db==0||parsed.keyDb[note]!=0)return false;
        parsed.keyDb[note]=static_cast<std::int8_t>(db);
    }
    if(hasTones){
        if(!(in>>count)||count<0||count>128)return false;
        DrumTones tones;
        for(int i=0;i<count;++i){
            int note;StyleDrumTone t;
            if(!(in>>note>>t.attack>>t.decay>>t.sustain>>t.release>>t.pan>>t.tune>>t.gate)||
                note<0||note>127||!t.valid()||t.neutral()||!tones.emplace(note,t).second)return false;
        }
        if(!tones.empty())parsed.tones=std::make_shared<const DrumTones>(std::move(tones));
    }
    if(hasTrigger&&(!(in>>parsed.trigger)||parsed.trigger< -1||parsed.trigger>1))return false;
    setting=std::move(parsed);return true;
}
sampler::ProgramPtr findStyleSetSound(const std::map<std::uint32_t,sampler::ProgramPtr>& programs,const StyleSoundSettings& setting){
    const auto it=programs.find(static_cast<std::uint32_t>(setting.setAddress));
    return it==programs.end()?nullptr:it->second;
}
std::shared_ptr<const sampler::LiveDrumKeys> liveDrumKeys(const StyleSoundSettings& settings){
    if(!settings.tones&&std::none_of(settings.keyDb.begin(),settings.keyDb.end(),[](int v){return v!=0;}))return {};
    auto keys=std::make_shared<sampler::LiveDrumKeys>();
    for(int i=0;i<128;++i)(*keys)[i].gainDb=settings.keyDb[i];
    if(settings.tones)for(const auto& row:*settings.tones){
        auto& key=(*keys)[row.first];const auto& tone=row.second;
        key.attack=tone.attack;key.decay=tone.decay;key.sustain=tone.sustain;key.release=tone.release;
        key.pan=tone.pan;key.tune=tone.tune;key.gate=tone.gate;
    }
    return keys;
}
}
