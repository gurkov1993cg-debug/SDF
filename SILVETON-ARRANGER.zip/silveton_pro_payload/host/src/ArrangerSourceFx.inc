// Included in ArrangerHost.cpp. Original owner profiles are prepared on the
// control thread; no raw SysEx is replayed into the sampler or MIDI output.
namespace {
using OriginalFxProfiles=std::vector<std::shared_ptr<const arranger::KorgSourceEffects>>;
int originalFxSendSlot(std::uint8_t controller) noexcept {
    return controller==91?0:controller==93?1:controller==94?2:-1;
}
void retainOriginalFxProfile(OriginalFxProfiles& profiles,
        const std::shared_ptr<const arranger::KorgSourceEffects>& profile){
    if(profile&&std::find(profiles.begin(),profiles.end(),profile)==profiles.end())profiles.push_back(profile);
}
bool applyOriginalKeyboardEffects(sampler::Combi& combi,const arranger::Pa5xKeyboardSetRead& read){
    OriginalFxProfiles profiles;retainOriginalFxProfile(profiles,read.sourceEffects);
    for(const auto& part:read.parts)retainOriginalFxProfile(profiles,part.sourceEffects);
    if(profiles.empty())return false;
    // Source roles are Lower, Upper1, Upper2, Upper3. Additional SILVETON
    // keyboard parts are not assigned another instrument's original effects.
    constexpr std::array<int,8> roles{{6,0,1,2,-1,-1,-1,-1}};
    sampler::applySourceEffects(combi,profiles,roles,false);
    return bool(combi.sourceEffects);
}
bool applyOriginalStyleEffects(sampler::Combi& combi,const arranger::Pa5xStyleRead& read){
    OriginalFxProfiles profiles;retainOriginalFxProfile(profiles,read.sourceEffects);
    for(const auto& section:read.sections)
        for(const auto& track:section.tracks)retainOriginalFxProfile(profiles,track.sourceEffects);
    if(profiles.empty())return false;
    // Every section retains its own original context. The adapter decides
    // supported/stable execution and reports unavailable dynamic definitions;
    // the host never picks a section by Sound name or silently drops a CV.
    constexpr std::array<int,8> roles{{0,1,2,3,4,5,6,7}};
    sampler::applySourceEffects(combi,profiles,roles,true);
    return bool(combi.sourceEffects);
}
}
