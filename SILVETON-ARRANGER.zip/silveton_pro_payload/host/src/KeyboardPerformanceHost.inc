// Included inside the existing Android and desktop sampler hosts. A complete
// keyboard recall is one immutable publication, with shared Program storage.
    float gateReduction(int part) const{return engine_.channelGateReduction(part);}
    void listenSolo(int player,int part,int key){arrangerHost().setListenSolo(engine_,{player,part,key});}
    void prepareKeyboardMix(Combi& combi){
        for(int part=0;part<kPartCount;++part)combi.part(part).livePartMix=true;
    }

    std::shared_ptr<const Combi> keyboardCombi() const {
        std::lock_guard<std::mutex> lock(controlMutex_);
        return state_?std::shared_ptr<const Combi>(state_,&state_->combi):nullptr;
    }

    bool applyKeyboardCombi(const Combi& combi, bool markEdited) {
        const auto sourceValue=[](int value){return value>= -1&&value<=127;};
        for(int part=0;part<kPartCount;++part){
            const auto& upper=combi.part(part);
            if(upper.keyLow>127||upper.keyHigh>127||upper.keyLow>upper.keyHigh||
               upper.velocityLow<1||upper.velocityHigh>127||upper.velocityLow>upper.velocityHigh||
               upper.midiChannel>15||upper.octave< -4||upper.octave>4||
               !std::isfinite(upper.levelDb)||!std::isfinite(upper.pan)||
               !std::isfinite(upper.tuneCents)||!std::isfinite(upper.portamentoSec)||
               upper.pan< -1.0F||upper.pan>1.0F||upper.portamentoSec<0.0F||
               !sourceValue(upper.sourceVolumeRaw)||!sourceValue(upper.sourcePanRaw)||
               !sourceValue(upper.sourceExpressionRaw)||!upper.sourceSoundEdits.valid()){
                setTextError("Keyboard Set contains an invalid part range, tuning or source mix");return false;
            }
            if(upper.program&&!arranger::paSampleProgramLayerCountSupported(*upper.program)){
                setTextError("Keyboard Set Program exceeds the supported layer count");return false;
            }
        }
        auto next=std::make_shared<EngineState>();
        next->combi=combi;
        if(!markEdited){
            // Full recalls may come from a saved working copy or native COMBI,
            // not only from an original KSC. Prepare only their reachable PCM
            // sources, outside controlMutex_ and before immutable publication.
            // Include assigned muted/off parts too: their live Play/SPLIT
            // toggles must stay immediate and must not start prefault I/O.
            std::vector<ProgramPtr> programs;
            std::set<const Program*> seen;
            for(int part=0;part<kPartCount;++part){
                const auto& upper=combi.part(part);
                const auto add=[&](const SoundAssignment& source){
                    if(source.program&&seen.insert(source.program.get()).second)programs.push_back(source.program);
                };
                add(upper);for(const auto& layer:upper.layers)add(layer);
            }
            (void)arranger::warmPa5xSamplePrograms(programs);
        }
        {
            // Prefaulting can take time; take the current global settings only
            // afterwards so a concurrent global edit is not recalled away.
            std::lock_guard<std::mutex> lock(controlMutex_);
            next->global=state_?state_->global:library_.global();
            next->combiGeneration=(state_?state_->combiGeneration:0U)+(markEdited?0U:1U);
        }
        // Retained voice owners keep old note releases and FX tails valid.
        // No panic, sample decoding or hardware route operation occurs here.
        if(!installState(std::move(next),markEdited?Mark::Edit:Mark::Clean))return false;
        if(!markEdited){
            activeListEntry_=-1;
            std::lock_guard<std::mutex> lock(missingMutex_);lastRecallMissing_.clear();
        }
        setTextError({});return true;
    }

    bool assignPreparedKeyboardSound(int upperIndex,ProgramPtr program) {
        if(upperIndex<0||upperIndex>=kUpperCount||!program||program->layers.empty()||
           !arranger::paSampleProgramLayerCountSupported(*program)){
            setTextError("No prepared User Sound is available for this keyboard part");return false;
        }
        (void)arranger::warmPa5xSamplePrograms({program});
        std::shared_ptr<EngineState> next;
        {
            std::lock_guard<std::mutex> lock(controlMutex_);
            next=std::make_shared<EngineState>(state_?*state_:EngineState{});
        }
        auto& upper=next->combi.part(upperIndex);
        upper.program=std::move(program);upper.name=upper.program->name;
        upper.soundSlotId=kNoSoundSlot;upper.engine=EngineParams{};upper.soloModel.reset();
        upper.commonProcessing=true;upper.enabled=true;
        detail::recallImportedSoundVoiceControls(upper);
        if(!installState(std::move(next),Mark::Edit))return false;
        setTextError({});return true;
    }
