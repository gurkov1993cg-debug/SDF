#pragma once

#include "silveton/sampler/SamplerLibrary.h"
#include "silveton/sampler/WaveTable.h"

#include <memory>
#include <optional>
#include <string>

namespace silveton::host {

// Opaque to callers. All large sound/model/sample buffers remain shared.
struct PerformanceCheckpoint {
    const void* owner{nullptr};
    silveton::sampler::SamplerLibrary library;
    std::shared_ptr<const silveton::sampler::EngineState> state;
    std::shared_ptr<const silveton::sampler::WaveTableMap> waves;
    bool wavesPublished{false};
    std::optional<silveton::sampler::SlotAddress> activeListAddress;
    int activeListEntry{-1};
    int scaleTargets{0};
    bool edited{false};
    std::string pendingExtra;
    std::string loadedExtra;
    std::string recallMissing;
};

} // namespace silveton::host
