// Compact Style FX parameters shared by saved Style revisions and sessions.
// No Sound pointers, audio buffers or sample data are serialized.
namespace {
#include "ArrangerTrackControls.inc"
// Zero is the source setting. A stored range occupies one atomic word so
// the audio thread always sees matching bottom, top and enable values.
struct PhraseRangeBank {
    std::array<unsigned,arranger::kElementCount*arranger::kTracks> sections{};
    std::array<unsigned,arranger::kTracks> wraps{};
    static unsigned pack(bool enabled,int low,int high) noexcept {
        return 1U|(unsigned(enabled)<<1)|(unsigned(low)<<2)|(unsigned(high)<<9);
    }
    static arranger::PhraseRange unpack(unsigned word,unsigned wrap) noexcept {
        arranger::PhraseRange r;
        if(word){r.enabled=int((word>>1)&1);r.low=int((word>>2)&127);r.high=int((word>>9)&127);}
        r.wrap=int(wrap);return r;
    }
};
// Each section/track owns one coherent override word. Zero inherits every
// original field; value+1 preserves explicit ACC, capo 0 and Humanize 0.
struct GuitarOverrideBank {
    std::array<unsigned,arranger::kElementCount*arranger::kTracks> sections{};
    static unsigned pack(const arranger::GuitarOverride& value) noexcept {
        return unsigned(value.mode+1)|(unsigned(value.capo+1)<<2)|
            (unsigned(value.highString+1)<<6)|(unsigned(value.lowString+1)<<9)|
            (unsigned(value.humanize+1)<<12)|(unsigned(value.rxIntensity+1)<<20);
    }
    static arranger::GuitarOverride unpack(unsigned word) noexcept {
        arranger::GuitarOverride value;
        value.mode=int(word&3U)-1;value.capo=int((word>>2)&15U)-1;
        value.highString=int((word>>6)&7U)-1;value.lowString=int((word>>9)&7U)-1;
        value.humanize=int((word>>12)&255U)-1;value.rxIntensity=int((word>>20)&255U)-1;return value;
    }
    static bool valid(unsigned word) noexcept {
        return word<(1U<<28)&&unpack(word).valid();
    }
};
struct StyleFxRack {
    // New revisions distinguish an inherited original rack from an explicit
    // SILVETON rack. Older revisions have no marker and remain manual.
    bool sourceEffects{false};
    PhraseRangeBank ranges;
    GuitarOverrideBank guitars;
    std::array<StyleChannelPreset,8> channels;
    std::array<int,5> fillModes{};
    std::array<sampler::EffectSlot,sampler::kFxSendSlots> master{};
    std::array<sampler::EffectSlot,8> insert{};
    std::array<std::array<float,4>,8> sends{};
    sampler::EffectRouting routing{sampler::EffectRouting::Parallel};

    void capture(const sampler::Combi& combi){
        sourceEffects=bool(combi.sourceEffects);
        master=combi.fx;routing=combi.fxRouting;
        for(int t=0;t<8;++t){insert[t]=combi.insertOf(t);const auto& u=combi.part(t);
            channels[t].capture(u);sends[t]={u.fxSend1,u.fxSend2,u.fxSend3,u.fxSend4};}
    }
    void apply(sampler::Combi& combi) const {
        // A source graph is reconstructed from this Style's original read by
        // the host, after the saved channel controls have been applied.
        combi.sourceEffects.reset();
        combi.fx=master;combi.fxRouting=routing;
        for(int t=0;t<8;++t){combi.insertOf(t)=insert[t];auto& u=combi.part(t);
            channels[t].apply(u);u.fxSend1=sends[t][0];u.fxSend2=sends[t][1];u.fxSend3=sends[t][2];u.fxSend4=sends[t][3];}
    }
};
bool styleNumberedFxPresent(const sampler::NumberedFxState& state) noexcept {
    return state.schema!=sampler::kNumberedFxSchema||state.index!=0||state.knownMask!=0||
        state.origin!=sampler::NumberedFxOrigin::Unknown;
}
bool styleNumberedFxRowIdValid(const std::string& id) noexcept {
    return !id.empty()&&id.size()<=63U&&std::all_of(id.begin(),id.end(),[](unsigned char c){
        return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.';
    });
}
constexpr unsigned kStyleNumberedFxSlots=sampler::kFxSendSlots+8U;
constexpr unsigned kStyleNumberedFxModulatingMasterSlots=3;
const sampler::EffectSlot& styleNumberedFxSlot(const StyleFxRack& rack,unsigned slot){
    return slot<sampler::kFxSendSlots?rack.master[slot]:rack.insert[slot-sampler::kFxSendSlots];
}
sampler::EffectSlot& styleNumberedFxSlot(StyleFxRack& rack,unsigned slot){
    return slot<sampler::kFxSendSlots?rack.master[slot]:rack.insert[slot-sampler::kFxSendSlots];
}
bool styleNumberedFxModulatingValid(const sampler::EffectSlot& effect,unsigned slot) noexcept {
    const int part=effect.numberedModulatingPart;
    return part>=-1&&part<=7&&
        (part==-1||(slot<kStyleNumberedFxModulatingMasterSlots&&effect.numbered.index!=0&&
                    styleNumberedFxPresent(effect.numbered)));
}
bool writeStyleNumberedFx(std::ostream& out,const StyleFxRack& rack){
    unsigned count=0;
    for(unsigned slot=0;slot<kStyleNumberedFxSlots;++slot){
        const auto& effect=styleNumberedFxSlot(rack,slot);const auto& state=effect.numbered;
        if(!state.valid()||!styleNumberedFxModulatingValid(effect,slot))return false;
        if(styleNumberedFxPresent(state))++count;
    }
    if(count!=0&&rack.sourceEffects)return false;
    // The suffix contains SILVETON row identities/values only. It does not
    // replace SVFX, write a Korg parameter block or supply absent defaults.
    out<<" SVNF 2 "<<count;
    for(unsigned slot=0;slot<kStyleNumberedFxSlots;++slot){
        const auto& effect=styleNumberedFxSlot(rack,slot);const auto& state=effect.numbered;
        if(!styleNumberedFxPresent(state))continue;
        const auto* descriptor=sampler::findNumberedFx(state.index);if(!descriptor)return false;
        unsigned known=0;
        for(std::size_t row=0;row<sampler::kNumberedFxValueCount;++row)if(state.known(row))++known;
        out<<' '<<slot<<' '<<state.schema<<' '<<state.index<<' '<<static_cast<unsigned>(state.origin)
           <<' '<<static_cast<int>(effect.numberedModulatingPart)<<' '<<known;
        std::uint64_t written=0;
        for(unsigned row=0;row<descriptor->parameterCount;++row){
            const auto& parameter=descriptor->parameters[row];
            if(parameter.ordinal>=sampler::kNumberedFxValueCount||!state.known(parameter.ordinal))continue;
            const auto bit=std::uint64_t{1}<<parameter.ordinal;
            const std::string id=parameter.rowId?parameter.rowId:"";
            if((written&bit)!=0||!styleNumberedFxRowIdValid(id)||
               sampler::findNumberedFxParam(state.index,id.c_str())!=&parameter)return false;
            written|=bit;out<<' '<<id<<' '<<state.values[parameter.ordinal];
        }
        if(written!=state.knownMask)return false;
    }
    return static_cast<bool>(out);
}
bool readStyleNumberedFx(std::istream& in,StyleFxRack& rack,bool hasModulating){
    std::string marker;int version=0,count=-1;
    if(!(in>>std::setw(5)>>marker>>version>>count)||marker!="SVNF"||
       (version!=1&&(!hasModulating||version!=2))||count<0||
       count>static_cast<int>(kStyleNumberedFxSlots)||(rack.sourceEffects&&count!=0))return false;
    std::array<bool,kStyleNumberedFxSlots> seen{};
    for(int entry=0;entry<count;++entry){
        int slot=-1,schema=0,index=-1,origin=-1,modulating=-1,known=-1;
        if(!(in>>slot>>schema>>index>>origin)||(version>=2&&!(in>>modulating))||!(in>>known)||
           slot<0||slot>=static_cast<int>(kStyleNumberedFxSlots)||
           seen[static_cast<std::size_t>(slot)]||schema!=sampler::kNumberedFxSchema||index<0||index>65535||
           origin<0||origin>static_cast<int>(sampler::NumberedFxOrigin::Manual)||known<0||
           known>static_cast<int>(sampler::kNumberedFxValueCount)||modulating< -1||modulating>7||
           (modulating!=-1&&(slot>=static_cast<int>(kStyleNumberedFxModulatingMasterSlots)||index==0)))return false;
        seen[static_cast<std::size_t>(slot)]=true;
        sampler::NumberedFxState state;state.schema=static_cast<std::uint16_t>(schema);
        state.index=static_cast<std::uint16_t>(index);state.origin=static_cast<sampler::NumberedFxOrigin>(origin);
        const auto* descriptor=sampler::findNumberedFx(state.index);
        if(!descriptor||known>descriptor->parameterCount)return false;
        for(int field=0;field<known;++field){
            std::string id;double value=0;
            if(!(in>>std::setw(64)>>id>>value)||!styleNumberedFxRowIdValid(id)||!std::isfinite(value))return false;
            const auto* parameter=sampler::findNumberedFxParam(state.index,id.c_str());
            if(!parameter||parameter->ordinal>=sampler::kNumberedFxValueCount||state.known(parameter->ordinal)||
               !sampler::numberedFxValueValid(*parameter,value))return false;
            state.values[parameter->ordinal]=value;state.knownMask|=std::uint64_t{1}<<parameter->ordinal;
        }
        if(!state.valid()||!styleNumberedFxPresent(state))return false;
        auto& effect=styleNumberedFxSlot(rack,static_cast<unsigned>(slot));
        effect.numbered=state;effect.numberedModulatingPart=static_cast<std::int8_t>(modulating);
    }
    return true;
}
bool writeStyleFx(std::ostream& out,const StyleFxRack& rack){
    out<<static_cast<int>(rack.routing);
    const auto slot=[&](const sampler::EffectSlot& f){
        out<<' '<<static_cast<int>(f.type)<<' '<<f.wet<<' '<<f.timeMs<<' '<<f.feedback<<' '<<f.rateHz<<' '<<f.depth
           <<' '<<f.tone<<' '<<f.preDelayMs<<' '<<f.damping<<' '<<f.size<<' '<<f.mod<<' '<<f.tempoSync<<' '<<f.tempoBpm
           <<' '<<f.division<<' '<<f.param1<<' '<<f.param2<<' '<<f.param3;
    };
    for(const auto& f:rack.master)slot(f);
    for(const auto& f:rack.insert)slot(f);
    for(const auto& track:rack.sends)for(float send:track)out<<' '<<send;
    static const StyleChannelPreset defaults=[]{StyleChannelPreset p;p.capture(sampler::UpperPart{});return p;}();
    for(const auto& preset:rack.channels)for(double field:(preset.values.empty()?defaults.values:preset.values))out<<' '<<field;
    for(int mode:rack.fillModes)out<<' '<<mode;
    for(unsigned range:rack.ranges.sections)out<<' '<<range;
    for(unsigned wrap:rack.ranges.wraps)out<<' '<<wrap;
    for(unsigned guitar:rack.guitars.sections)out<<' '<<guitar;
    out<<' '<<rack.sourceEffects;
    return writeStyleNumberedFx(out,rack);
}
bool readStyleFx(std::istream& in,StyleFxRack& rack,bool hasControls,bool hasRanges,bool gates,bool hasGuitars,bool hasSourceEffects,bool hasNumbered=false,bool hasModulating=false,bool hasSourcePortamento=false){
    int routing;if(!(in>>routing)||routing<0||routing>1)return false;
    rack.routing=static_cast<sampler::EffectRouting>(routing);
    const auto slot=[&](sampler::EffectSlot& f){
        f.numbered={};f.numberedModulatingPart=-1; // Older formats must not inherit a numbered assignment or source.
        int type,sync;
        if(!(in>>type>>f.wet>>f.timeMs>>f.feedback>>f.rateHz>>f.depth>>f.tone>>f.preDelayMs>>f.damping>>f.size>>f.mod
             >>sync>>f.tempoBpm>>f.division>>f.param1>>f.param2>>f.param3)||type<0||type>=sampler::kEffectTypeCount||
           (sync!=0&&sync!=1))return false;
        const auto range=[](float v,float low,float high){return std::isfinite(v)&&v>=low&&v<=high;};
        if(!range(f.wet,0,1)||!range(f.timeMs,0,3000)||!range(f.feedback,-1,1)||!range(f.rateHz,0,20)||
           !range(f.depth,0,1)||!range(f.tone,0,24)||!range(f.preDelayMs,0,300)||!range(f.damping,0,1)||
           !range(f.size,0,1)||!range(f.mod,0,1)||!range(f.tempoBpm,20,400)||!range(f.division,0,1)||
           !range(f.param1,-96,128)||!range(f.param2,0,128)||!range(f.param3,0,3000))return false;
        f.type=static_cast<sampler::EffectType>(type);f.tempoSync=sync!=0;return true;
    };
    for(auto& f:rack.master)if(!slot(f))return false;
    for(auto& f:rack.insert)if(!slot(f))return false;
    for(auto& track:rack.sends)for(float& s:track)if(!(in>>s)||!std::isfinite(s)||s<0||s>1)return false;
    if(hasControls){
        for(auto& preset:rack.channels)if(!preset.read(in,gates,hasSourcePortamento))return false;
        for(int& mode:rack.fillModes)if(!(in>>mode)||mode<0||mode>14)return false;
    }
    if(hasRanges){
        for(auto& word:rack.ranges.sections){
            if(!(in>>word)||word>65535U)return false;
            const auto range=PhraseRangeBank::unpack(word,0);
            if(word&&(!(word&1U)||range.low>range.high))return false;
        }
        for(auto& wrap:rack.ranges.wraps)if(!(in>>wrap)||wrap>12)return false;
    }
    rack.guitars={};
    if(hasGuitars)for(auto& word:rack.guitars.sections)
        if(!(in>>word)||!GuitarOverrideBank::valid(word))return false;
    rack.sourceEffects=false;
    if(hasSourceEffects){int source=-1;if(!(in>>source)||(source!=0&&source!=1))return false;rack.sourceEffects=source!=0;}
    if(hasNumbered&&!readStyleNumberedFx(in,rack,hasModulating))return false;
    return true;
}
}
