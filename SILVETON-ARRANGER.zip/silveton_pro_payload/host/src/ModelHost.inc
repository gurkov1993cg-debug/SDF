// SILVETON_MODEL_V1 / SILVETON_SYNTH_V1 / SILVETON_MODELS_FROM_FILE_V1 - the learned models in the host.
// Included INSIDE the host class of the tablet and of the generic host (they share this text), after EngineBlockHost.inc.
    // The models are ONLY the sounds of the file of the teacher (SILVETON_OSC.sv next to the bank) - nothing is built into the sampler (Цветомир, 04.11.2026).
    // Read on the control thread, given to the engine; the set before is kept alive until the next one, so nothing big is freed on the audio thread.
    // false = not found / not readable (textError says why); the sampler then has no models. A file with more than kMaxModels sounds gives the first
    // kMaxModels to the engine (MODEL is a number 1..kMaxModels); learnedModelsInfo() says how many the file really holds.
    bool loadLearnedModels(const std::string& file) {
        auto loaded = model::loadLearnedModels(file);
        std::shared_ptr<const model::LearnedModels> use = loaded;
        if (loaded->error.empty() && loaded->models.size() > static_cast<std::size_t>(model::kMaxModels)) {
            auto cut = std::make_shared<model::LearnedModels>(*loaded);
            cut->models.resize(static_cast<std::size_t>(model::kMaxModels));
            use = cut;
        }
        std::lock_guard<std::mutex> lock(controlMutex_);
        learnedModelsBefore_ = learnedModels_;
        learnedModels_ = use;
        engine_.setLearnedModels(use);
        if (!loaded->error.empty()) { setTextError(loaded->error); return false; }
        return true;
    }
    void installNoModels() {   // at the start: no models until the file is read
        auto none = std::make_shared<const model::LearnedModels>();
        std::lock_guard<std::mutex> lock(controlMutex_);
        learnedModels_ = none;
        engine_.setLearnedModels(none);
    }
    // "name (slot)" of every model (MODEL 1 = the first)
    std::vector<std::string> learnedModelNames() const {
        std::vector<std::string> out;
        std::lock_guard<std::mutex> lock(controlMutex_);
        if (learnedModels_ == nullptr) return out;
        for (const auto& m : learnedModels_->models) {
            std::string n = m.slot.empty() || m.slot == m.name ? m.name : m.name + " (" + m.slot + ")";
            if (m.anyPitchDoubt()) n += " (! октава)";   // SILVETON_MODEL_CLEAN_V1: learned in another octave - SYNTH plays it as learned, in the octave of the recording
            out.push_back(n);
        }
        return out;
    }
    // what was read: the models the engine has, the sounds the file holds, the zones of the models
    void learnedModelsCounts(int& models, int& soundsInFile, int& zones) const {
        std::lock_guard<std::mutex> lock(controlMutex_);
        models = 0; soundsInFile = 0; zones = 0;
        if (learnedModels_ == nullptr) return;
        models = static_cast<int>(learnedModels_->models.size());
        soundsInFile = static_cast<int>(learnedModels_->total);
        for (const auto& m : learnedModels_->models) for (const auto& z : m.zones) if (z.ok) ++zones;
    }
    std::shared_ptr<const model::LearnedModels> learnedModels_;
    std::shared_ptr<const model::LearnedModels> learnedModelsBefore_;
