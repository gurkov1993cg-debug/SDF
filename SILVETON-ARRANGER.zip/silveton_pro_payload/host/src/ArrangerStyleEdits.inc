// Included in ArrangerHost.cpp inside silveton::host. Control-thread only.
// SILVETON reference/mixer edits; never writes or claims a Korg STG resource.
namespace {
constexpr std::size_t kStyleEditMaximumBytes=1024U*1024U;
struct SavedStyleTrackEdit {
    StyleSoundSettings soundSettings;
    unsigned mask{0};float db{0},pan{0};bool mute{false};
    int binding{0},slot{0};std::string programIdentity;
};
struct SavedStyleEdit {
    int formatVersion{14};
    StyleFxRack effects;
    std::string sourcePath,identity,name;
    double bpm{120};bool autoFill{true};int element{3};
    std::array<SavedStyleTrackEdit,8> tracks;
    ArrangerStyleKeyboardLinks keyboardSets{};
};
std::string styleEditDigest(const std::string& bytes){
    const auto digest=sampler::sha256(reinterpret_cast<const std::uint8_t*>(bytes.data()),bytes.size());
    constexpr char hex[]="0123456789abcdef";std::string result;result.reserve(digest.size()*2U);
    for(const auto byte:digest){result.push_back(hex[byte>>4U]);result.push_back(hex[byte&15U]);}return result;
}
bool readStyleEditFile(const std::string& path,std::string& bytes,std::size_t maximum=kStyleEditMaximumBytes){
    std::ifstream file(path,std::ios::binary|std::ios::ate);const auto size=file.tellg();
    if(!file||size<0||size>static_cast<std::streamoff>(maximum))return false;
    bytes.resize(static_cast<std::size_t>(size));file.seekg(0);
    if(!bytes.empty())file.read(bytes.data(),static_cast<std::streamsize>(bytes.size()));
    return static_cast<bool>(file);
}
std::string styleEditJoin(const std::string& parent,const std::string& name){return parent.empty()?name:parent+(parent.back()=='/'?"":"/")+name;}
bool styleEditDirectories(const std::string& path){
    if(path.empty())return false;
    for(std::size_t at=path[0]=='/'?1U:0U;at<=path.size();++at)if(at==path.size()||path[at]=='/'){
        const auto prefix=path.substr(0,at);if(prefix.empty())continue;
        if(::mkdir(prefix.c_str(),0700)!=0&&errno!=EEXIST)return false;
        struct stat info{};if(::stat(prefix.c_str(),&info)!=0||!S_ISDIR(info.st_mode))return false;
    }
    return true;
}
bool styleEditAtomicWrite(const std::string& path,const std::string& bytes){
    static std::atomic<unsigned> serial{0};
    const auto pending=path+".pending-"+std::to_string(::getpid())+"-"+std::to_string(serial.fetch_add(1));
    std::ofstream file(pending,std::ios::binary|std::ios::trunc);
    file.write(bytes.data(),static_cast<std::streamsize>(bytes.size()));file.flush();const bool okay=static_cast<bool>(file);file.close();
    if(!okay||file.fail()||std::rename(pending.c_str(),path.c_str())!=0){std::remove(pending.c_str());return false;}return true;
}
bool styleEditValidText(const std::string& value,std::size_t maximum=32768U){
    return value.size()<=maximum&&value.find('\0')==std::string::npos&&value.find_first_of("\r\n")==std::string::npos;
}
std::string styleEditCanonicalPath(const std::string& path){
    std::string source=path;int slot=0;const bool legacy=arranger::paStyleSlot(path,&source,&slot);
    std::unique_ptr<char,decltype(&std::free)> value(::realpath(source.c_str(),nullptr),&std::free);
    if(!value)return {};
    return std::string(value.get())+(legacy?"!/"+std::to_string(slot):std::string{});
}
std::string styleEditIdentity(const std::string& path,const arranger::Style& style){
    const auto canonical=styleEditCanonicalPath(path);std::string bytes,physical=canonical;arranger::paStyleSlot(canonical,&physical);
    if(canonical.empty()||!styleEditValidText(canonical)||!readStyleEditFile(physical,bytes,64U*1024U*1024U)||bytes.empty())return {};
    std::ostringstream text;text<<"SILVETON_STYLE_SOURCE 1\n"<<std::quoted(canonical)<<' '<<bytes.size()<<' '<<styleEditDigest(bytes)<<'\n';
    for(std::size_t track=0;track<style.tracks.size();++track){const auto& t=style.tracks[track];
        text<<track<<' '<<t.used<<' '<<static_cast<unsigned>(t.role)<<' '<<static_cast<unsigned>(t.sourceChannel)<<' '
            <<t.addressKnown<<' '<<static_cast<unsigned>(t.msb)<<' '<<static_cast<unsigned>(t.lsb)<<' '<<static_cast<unsigned>(t.program)<<'\n';}
    // Preserve original bank/program declarations and their track/CV scope.
    const auto addressEvents=[&text](const std::vector<arranger::MidiEvent>& events){
        for(const auto& e:events){
            if((e.status&0xF0U)==0xC0U||((e.status&0xF0U)==0xB0U&&(e.data1==0U||e.data1==32U)))
                text<<e.tick<<','<<static_cast<unsigned>(e.track)<<','<<static_cast<unsigned>(e.status)<<','<<static_cast<unsigned>(e.data1)<<','<<static_cast<unsigned>(e.data2)<<';';
        }
        text<<'\n';
    };
    for(std::size_t section=0;section<style.sections.size();++section){const auto& s=style.sections[section];text<<"S "<<section<<' '<<s.available<<'\n';
        addressEvents(s.events);for(std::size_t track=0;track<s.patterns.size();++track){const auto& pattern=s.patterns[track];text<<"T "<<track<<'\n';
            addressEvents(pattern.setupEvents);for(std::size_t cv=0;cv<pattern.cvs.size();++cv){text<<"CV "<<cv<<'\n';addressEvents(pattern.cvs[cv].events);}}}
    return styleEditDigest(text.str());
}
std::string styleEditProgramIdentity(const sampler::ProgramPtr& program){
    if(!program||!arranger::paSampleProgramLayerCountSupported(*program))return {};
    std::ostringstream text;text<<std::setprecision(std::numeric_limits<float>::max_digits10);
    text<<std::quoted(program->name)<<' '<<program->mono<<' '<<program->legato<<' '<<program->portamentoSec<<'\n';
    const auto rawValues=[&text](const auto& values){for(const auto value:values)text<<+value<<' ';text<<'\n';};
    if(program->sourceVoiceAssignment.present){
        const auto& source=program->sourceVoiceAssignment;if(!source.valid())return {};
        text<<"SOURCE_VOICE "<<+source.resourceVersion<<' '<<+source.flagsRaw<<' '
            <<source.legatoModePresent<<' '<<+source.legatoModeRaw<<' '<<+source.legatoExtensionRaw<<'\n';
    }
    if(program->sourceSoundEffects){
        const auto bytes=arranger::encodePa5xSoundEffects(*program->sourceSoundEffects);if(bytes.empty())return {};
        text<<"SOURCE_SOUND_FX "<<styleEditDigest(std::string(reinterpret_cast<const char*>(bytes.data()),bytes.size()))<<'\n';
    }
    const auto envelope=[&text](const sampler::EnvelopeParams& e){text<<e.attackSec<<' '<<e.decaySec<<' '<<e.sustain<<' '<<e.releaseSec<<' ';};
    const auto lfo=[&text](const sampler::LfoParams& l){text<<static_cast<unsigned>(l.wave)<<' '<<l.frequencyHz<<' '<<l.delaySec<<' '<<l.fadeSec<<' '<<l.keySync<<' '<<l.pitchCents<<' '<<l.filterOctaves<<' '<<l.ampDepth<<' ';};
    bool sources=false;
    for(const auto& layer:program->layers){text<<std::quoted(layer.name)<<' '<<layer.enabled<<' '<<static_cast<unsigned>(layer.keyLow)<<' '<<static_cast<unsigned>(layer.keyHigh)<<' '
        <<static_cast<unsigned>(layer.velocityLow)<<' '<<static_cast<unsigned>(layer.velocityHigh)<<' '<<static_cast<int>(layer.transposeSemitones)<<' '
        <<layer.tuneCents<<' '<<layer.levelDb<<' '<<layer.pan<<' '<<static_cast<unsigned>(layer.velocityFadeIn)<<' '<<static_cast<unsigned>(layer.velocityFadeOut)<<' '<<layer.delaySec<<' '<<layer.damperEnabled<<' ';
        envelope(layer.ampEnvelope);envelope(layer.filterEnvelope);envelope(layer.pitchEnvelope);text<<layer.pitchEnvelopeCents<<' '
            <<static_cast<unsigned>(layer.filter.mode)<<' '<<layer.filter.cutoffHz<<' '<<layer.filter.resonance<<' '<<layer.filter.keyTrack<<' '
            <<layer.filter.velocityAmount<<' '<<layer.filter.envelopeAmount<<' '<<layer.filter.lfoAmount<<' ';lfo(layer.lfo1);lfo(layer.lfo2);text<<'\n';
        if(layer.sourceAmpEnvelope.present){
            const auto& source=layer.sourceAmpEnvelope;if(!source.valid())return {};
            text<<"SOURCE_AMP "<<source.enabled<<' '<<source.modulationEncodingSupported<<'\n';
            rawValues(source.levels);rawValues(source.times);rawValues(source.amsSources);
            rawValues(source.amsIntensities);rawValues(source.amsDirections);
            rawValues(source.keyboardKeys);rawValues(source.keyboardRamps);
            text<<source.filterKeyboardTrackingPresent<<'\n';
            rawValues(source.filterKeyboardKeys);rawValues(source.filterKeyboardRamps);
        }
        if(layer.sourcePortamento.present){
            const auto& source=layer.sourcePortamento;if(!source.valid())return {};
            text<<"SOURCE_PORTAMENTO "<<source.encodingSupported<<' '<<+source.resourceVersion<<' '
                <<+source.flagsRaw<<' '<<+source.timeRaw<<' '<<+source.extensionByteCount<<' ';
            rawValues(source.extensionRaw);
        }
        if(layer.sourceOscillatorDsp){
            const auto bytes=sampler::encodeSourceOscillatorDsp(*layer.sourceOscillatorDsp);if(bytes.empty())return {};
            text<<"SOURCE_OSC_DSP "<<styleEditDigest(std::string(reinterpret_cast<const char*>(bytes.data()),bytes.size()))<<'\n';
        }
        if(!layer.multisample){text<<"NO_MULTISAMPLE\n";continue;}const auto& m=*layer.multisample;
        if(m.zones.size()>sampler::kMaxZonesPerMultisample)return {};
        text<<std::quoted(m.name)<<' '<<std::quoted(m.sourceIdentity)<<' '<<m.zones.size()<<'\n';
        for(const auto& z:m.zones){text<<static_cast<unsigned>(z.keyLow)<<' '<<static_cast<unsigned>(z.keyHigh)<<' '<<static_cast<unsigned>(z.velocityLow)<<' '
            <<static_cast<unsigned>(z.velocityHigh)<<' '<<static_cast<unsigned>(z.rootKey)<<' '<<static_cast<int>(z.transposeSemitones)<<' '<<z.tuneCents<<' '
            <<z.gainDb<<' '<<z.pan<<' '<<z.oneShot<<' '<<z.reverse<<' '<<z.nonTranspose<<' '<<static_cast<int>(z.sourceLevelRaw)<<' '<<static_cast<int>(z.sourceFilterRaw)<<' ';
            if(!z.sample){text<<"NO_SAMPLE\n";continue;}const auto& s=*z.sample;
            auto path=styleEditCanonicalPath(s.sourcePath);arranger::paStyleSlot(s.sourcePath,&path);struct stat st{};const bool backed=!path.empty()&&::stat(path.c_str(),&st)==0;
            if(s.sourceIdentity.empty()&&!backed)return {};
            text<<std::quoted(s.name)<<' '<<std::quoted(s.sourceIdentity)<<' ';
            // Stable import identities survive SET packaging/cache relocation.
            // File metadata is the fallback for ordinary file-backed samples.
            if(s.sourceIdentity.empty()){text<<std::quoted(path)<<' ';
                text<<st.st_size<<' '<<st.st_mtime<<' '<<st.st_ctime<<' ';
#if defined(__APPLE__)
                text<<st.st_mtimespec.tv_nsec<<' '<<st.st_ctimespec.tv_nsec<<' ';
#else
                text<<st.st_mtim.tv_nsec<<' '<<st.st_ctim.tv_nsec<<' ';
#endif
            }
            text<<s.sampleRate<<' '<<s.channels<<' '<<static_cast<unsigned>(s.rootKey)<<' '<<s.fineTuneCents<<' '<<s.frameCount()<<' '
                <<s.loop.enabled<<' '<<s.loop.startFrame<<' '<<s.loop.endFrame<<' '<<s.loop.crossfadeFrames<<'\n';sources=true;
        }
        if(text.tellp()>static_cast<std::streamoff>(8U*1024U*1024U))return {};
    }
    return sources?styleEditDigest(text.str()):std::string{};
}
bool styleEditProgramMatches(const sampler::ProgramPtr& program,const std::string& identity,bool legacy69,bool legacyOscillator1=false){
    if(!program||identity.empty())return false;
    if(styleEditProgramIdentity(program)==identity)return true;
    if(legacyOscillator1){
        const auto previous=arranger::projectPa5xSampleProgramLegacyOscillator1(program);
        if(previous&&styleEditProgramIdentity(previous)==identity)return true;
    }
    if(!legacy69)return false;
    // Only older saved formats may compare the exact former import result.
    // The projection retains the complete waveform/source identity and never
    // changes or publishes the currently prepared playback Program.
    const auto previous=arranger::projectPa5xSampleProgramLegacy69(program);
    return previous&&styleEditProgramIdentity(previous)==identity;
}
std::string styleEditRevisionName(const std::string& text){return "ARRANGER_STYLE_REV_"+styleEditDigest(text)+".svstyle";}
bool styleEditRevisionNameValid(const std::string& name){
    const std::string prefix="ARRANGER_STYLE_REV_",suffix=".svstyle";
    if(name.size()!=prefix.size()+64U+suffix.size()||name.compare(0,prefix.size(),prefix)!=0||name.compare(name.size()-suffix.size(),suffix.size(),suffix)!=0)return false;
    return std::all_of(name.begin()+static_cast<std::ptrdiff_t>(prefix.size()),name.end()-static_cast<std::ptrdiff_t>(suffix.size()),[](unsigned char c){return std::isxdigit(c)!=0;});
}
std::string styleEditSourcePointer(const std::string& directory,const std::string& identity){return styleEditJoin(directory,"ARRANGER_STYLE_SOURCE_"+identity+".ref");}
std::string styleEditUserPointer(const std::string& directory,int bank,int position){
    std::ostringstream name;name<<"ARRANGER_USER_STYLE_"<<std::setfill('0')<<std::setw(2)<<bank<<'_'<<std::setw(3)<<position<<".ref";return styleEditJoin(directory,name.str());
}
std::string styleEditText(SavedStyleEdit edit){
    if(edit.formatVersion<14)for(auto& track:edit.tracks)if(track.binding==2){
        const auto program=resolveArrangerBankSound(track.slot);
        if(!styleEditProgramMatches(program,track.programIdentity,edit.formatVersion<13,true))return {};
        track.programIdentity=styleEditProgramIdentity(program);
    }
    std::ostringstream out;out<<std::setprecision(std::numeric_limits<double>::max_digits10)<<"SILVETON_STYLE_EDITS 14\n"
        <<std::quoted(edit.sourcePath)<<'\n'<<std::quoted(edit.identity)<<'\n'<<std::quoted(edit.name)<<'\n'
        <<edit.bpm<<' '<<edit.autoFill<<' '<<edit.element<<'\n';
    for(const auto& t:edit.tracks){out<<t.mask<<' '<<t.db<<' '<<t.pan<<' '<<t.mute<<' '<<t.binding<<' '<<t.slot<<' '<<std::quoted(t.programIdentity);writeStyleSound(out,t.soundSettings);out<<'\n';}
    for(const auto& k:edit.keyboardSets)out<<std::quoted(k.first)<<' '<<std::quoted(k.second)<<'\n';
    if(!writeStyleFx(out,edit.effects))return {};
    out<<"\nEND\n";return out.str();
}
bool parseStyleEdit(const std::string& bytes,SavedStyleEdit& edit){
    if(bytes.empty()||bytes.size()>kStyleEditMaximumBytes)return false;
    std::istringstream in(bytes);std::string magic,end;int version=0,fill=-1;
    if(!(in>>magic>>version>>std::quoted(edit.sourcePath)>>std::quoted(edit.identity)>>std::quoted(edit.name)>>edit.bpm>>fill>>edit.element)||
       magic!="SILVETON_STYLE_EDITS"||(version<1||version>14)||!styleEditValidText(edit.sourcePath)||!styleEditValidText(edit.name,256U)||edit.identity.size()!=64U||
       !std::isfinite(edit.bpm)||edit.bpm<20||edit.bpm>400||(fill!=0&&fill!=1)||edit.element<0||edit.element>=static_cast<int>(arranger::kElementCount))return false;
    const auto isDigest=[](const std::string& s){return s.size()==64U&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});};
    if(!isDigest(edit.identity))return false;
    edit.formatVersion=version;
    edit.autoFill=fill!=0;
    for(auto& t:edit.tracks){int mute=-1;if(!(in>>t.mask>>t.db>>t.pan>>mute>>t.binding>>t.slot>>std::quoted(t.programIdentity))||t.mask>7U||
        !std::isfinite(t.db)||t.db< -60||t.db>12||!std::isfinite(t.pan)||t.pan< -1||t.pan>1||(mute!=0&&mute!=1)||t.binding<0||t.binding>(version>=4?3:2)||
        t.slot<0||t.slot>500||(t.binding==2&&(t.slot==0||!isDigest(t.programIdentity)))||(t.binding!=2&&(t.slot!=0||!t.programIdentity.empty())))return false;
        if(version>=4&&(!readStyleSound(in,t.soundSettings,version>=5,version>=6)||(t.binding==3)!=(t.soundSettings.setAddress>=0)))return false;
        t.mute=mute!=0;
    }
    if(version>=2)for(auto& k:edit.keyboardSets){
        if(!(in>>std::quoted(k.first)>>std::quoted(k.second))||!styleEditValidText(k.first,65536U)||!styleEditValidText(k.second,256U))return false;
        if(k.first.empty()!=k.second.empty())return false;
    }
    if(version>=3&&!readStyleFx(in,edit.effects,version>=6,version>=7,version>=8,version>=9,version>=10,version>=11,version>=12,version>=13))return false;
    if(!(in>>end)||end!="END")return false;
    in>>std::ws;return in.eof();
}
bool readStyleEdit(const std::string& path,SavedStyleEdit& edit){std::string bytes;return readStyleEditFile(path,bytes)&&parseStyleEdit(bytes,edit)&&styleEditRevisionName(bytes)==path.substr(path.find_last_of("/\\")+1U);}
struct SavedStylePointer {int bank{0},position{0};std::string name,sourcePath,identity,revision;};
std::string styleEditPointerText(const SavedStylePointer& p){std::ostringstream out;out<<"SILVETON_STYLE_POINTER 1\n"<<p.bank<<' '<<p.position<<' '<<std::quoted(p.name)<<'\n'<<std::quoted(p.sourcePath)<<'\n'<<std::quoted(p.identity)<<'\n'<<std::quoted(p.revision)<<'\n';return out.str();}
bool readStyleEditPointer(const std::string& path,SavedStylePointer& p){
    std::string bytes;if(!readStyleEditFile(path,bytes,65536U))return false;std::istringstream in(bytes);std::string magic;int version=0;
    if(!(in>>magic>>version>>p.bank>>p.position>>std::quoted(p.name)>>std::quoted(p.sourcePath)>>std::quoted(p.identity)>>std::quoted(p.revision))||
        magic!="SILVETON_STYLE_POINTER"||version!=1||p.bank<0||p.bank>16||p.position<0||p.position>128||((p.bank==0)!=(p.position==0))||
        !styleEditValidText(p.name,256U)||!styleEditValidText(p.sourcePath)||p.identity.size()!=64U||!styleEditRevisionNameValid(p.revision))return false;
    in>>std::ws;return in.eof();
}
}
