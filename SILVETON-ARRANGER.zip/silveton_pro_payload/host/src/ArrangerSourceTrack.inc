// Original native PRF/STS controls are typed before reaching this adapter.
// Native cents and octaves are not Pa5X XML Pitch or MIDI RPN payloads.
namespace {
void applyOriginalNativeTrack(sampler::UpperPart& upper,const arranger::PaSeriesTrackSettings& source){
    if(!source.structurallyValid)return;
    if(source.detuneKnown)upper.tuneCents=static_cast<float>(source.detuneCents);
    if(source.octaveTransposeKnown)
        upper.transposeSemitones=static_cast<std::int8_t>(source.octaveTranspose*12);
    if(source.pitchBendRangeSemitones>=0)
        upper.pitchBendRange=static_cast<std::int8_t>(source.pitchBendRangeSemitones);
    // Dry polarity and mixer-EQ bypass are not established by this layout.
    // The raw record remains in the reader; neither is inferred from gain.
}
void applyOriginalStyleTracks(sampler::Combi& combi,const arranger::Pa5xStyleRead& read,
                              const std::array<StyleChannelPreset,8>* savedChannels=nullptr){
    for(std::size_t index=0;index<8U;++index){
        // Authored channel edits already contain the user's chosen values.
        if(savedChannels&&!(*savedChannels)[index].values.empty())continue;
        const arranger::PaSeriesTrackSettings* source=nullptr;bool conflict=false;
        for(const auto& section:read.sections){
            if(!section.available)continue;
            const auto& track=section.tracks[index];if(!track.present)continue;
            const auto* current=track.sourceNativeTrack.get();
            if(!current){conflict=true;break;}
            if(!current->structurallyValid||current->trackIndex!=index){conflict=true;break;}
            if(source&&(source->tag!=current->tag||source->originalRecord!=current->originalRecord)){
                conflict=true;break;
            }
            source=current;
        }
        if(source&&!conflict)applyOriginalNativeTrack(combi.part(static_cast<int>(index)),*source);
    }
}
}
