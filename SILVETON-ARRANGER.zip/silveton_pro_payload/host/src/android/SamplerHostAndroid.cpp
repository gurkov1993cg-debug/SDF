#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/SoloDefs.h"
// SILVETON_ANDROID_HOST_V1
// C++ tablet sound/MIDI/bank host. AAudio lets Android configure the built-in
// speakers; a connected wired jack uses the proven Direct ALSA path. Both use
// the same sampler/arranger DSP and realtime worker policy. The former tablet
// bridge's control surface is exposed through NativeSamplerEngine.

#include "silveton/host/HostIo.h"
#include "silveton/host/MidiHeldState.h"
#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/host/ArrangerHost.h"
#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/host/detail/ImportedLegatoPortamento.h"
#include "../PerformanceCheckpoint.h"

#include <android/log.h>
#include <aaudio/AAudio.h>
#include <sound/asound.h>
#include <fcntl.h>
#include <dirent.h>
#include <poll.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sched.h>
#include <unistd.h>
#include <time.h>

#include "silveton/sampler/AudioFileLoader.h"
#include "silveton/sampler/KorgImporter.h"
#include "silveton/sampler/MultisampleEditor.h"
#include "silveton/sampler/SampleEditor.h"
#include "silveton/sampler/ProgramEditor.h"
#include "silveton/sampler/ModelBank.h"   // SILVETON_MODEL_V1: the learned models
#include "silveton/sampler/ModelDefs.h"   // SILVETON_BLEND_INFO_V1
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/CpuWorkPolicy.h"
#include "silveton/sampler/PerformanceDiagnostics.h"
#include "silveton/sampler/SamplerLibrary.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SourceEffects.h"
#include "silveton/sampler/SvBankRuntime.h"
#include "silveton/sampler/SvBankFormat.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <map>
#include <set>
#include <sstream>
#include <fstream>
#include "silveton/sampler/SampleStreamPrefetcher.h"

#include <algorithm>
#include <vector>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cmath>
#include <cerrno>
#include <cstring>
#include <filesystem>
#include <limits>
#include <memory>
#include <deque>
#include <mutex>
#include <optional>
#include <string>
#include <thread>

namespace silveton::host {
namespace {
using namespace silveton::sampler;

// ---------------------------------------------------------------- SILVETON_BANK_INFO_V1
// INFO / DELETE of whole SOUNDs in SILVETON_BANK.sv on the tablet. A deleted
// SOUND takes its samples with it (only samples no other SOUND uses), the bank
// file is written again smaller (new file next to it, then renamed over it).
struct Sha256Stream {
    std::array<std::uint32_t, 8> h{{0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U}};
    std::array<std::uint8_t, 64> buf{};
    std::size_t used{0U};
    std::uint64_t bits{0U};
    static std::uint32_t rr(std::uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
    void block(const std::uint8_t* p) {
        static constexpr std::uint32_t k[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,
            0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,
            0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,
            0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        std::uint32_t w[64];
        for (int i = 0; i < 16; ++i) w[i] = (std::uint32_t(p[4*i]) << 24) | (std::uint32_t(p[4*i+1]) << 16) | (std::uint32_t(p[4*i+2]) << 8) | std::uint32_t(p[4*i+3]);
        for (int i = 16; i < 64; ++i) {
            const std::uint32_t s0 = rr(w[i-15],7) ^ rr(w[i-15],18) ^ (w[i-15] >> 3);
            const std::uint32_t s1 = rr(w[i-2],17) ^ rr(w[i-2],19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        std::uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for (int i = 0; i < 64; ++i) {
            const std::uint32_t t1 = hh + (rr(e,6) ^ rr(e,11) ^ rr(e,25)) + ((e & f) ^ (~e & g)) + k[i] + w[i];
            const std::uint32_t t2 = (rr(a,2) ^ rr(a,13) ^ rr(a,22)) + ((a & b) ^ (a & c) ^ (b & c));
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
    }
    void add(const std::uint8_t* p, std::size_t n) {
        bits += static_cast<std::uint64_t>(n) * 8U;
        while (n > 0U) {
            if (used == 0U && n >= 64U) { block(p); p += 64; n -= 64; continue; }
            const std::size_t take = std::min<std::size_t>(64U - used, n);
            std::memcpy(buf.data() + used, p, take); used += take; p += take; n -= take;
            if (used == 64U) { block(buf.data()); used = 0U; }
        }
    }
    std::array<std::uint8_t, 32> finish() {
        const std::uint64_t total = bits;
        const std::uint8_t one = 0x80U; add(&one, 1U); bits -= 8U;
        const std::uint8_t zero = 0U;
        while (used != 56U) { add(&zero, 1U); bits -= 8U; }
        std::uint8_t len[8];
        for (int i = 0; i < 8; ++i) len[i] = static_cast<std::uint8_t>(total >> (56 - 8 * i));
        add(len, 8U);
        std::array<std::uint8_t, 32> out{};
        for (int i = 0; i < 8; ++i) for (int j = 0; j < 4; ++j) out[static_cast<std::size_t>(4*i+j)] = static_cast<std::uint8_t>(h[static_cast<std::size_t>(i)] >> (24 - 8 * j));
        return out;
    }
};

struct MappedFile {
    const std::uint8_t* data{nullptr};
    std::size_t size{0U};
    bool open(const std::string& path) {
        const int fd = ::open(path.c_str(), O_RDONLY | O_CLOEXEC);
        if (fd < 0) return false;
        struct stat st{};
        if (::fstat(fd, &st) != 0 || st.st_size <= 0) { ::close(fd); return false; }
        void* m = ::mmap(nullptr, static_cast<std::size_t>(st.st_size), PROT_READ, MAP_PRIVATE, fd, 0);
        ::close(fd);
        if (m == MAP_FAILED) return false;
        data = static_cast<const std::uint8_t*>(m);
        size = static_cast<std::size_t>(st.st_size);
        return true;
    }
    ~MappedFile() { if (data != nullptr) ::munmap(const_cast<std::uint8_t*>(data), size); }
};

struct BankModel {
    SvBankHeader header{};
    std::vector<SvSoundRecord> sounds;
    std::vector<SvSoundLayerRecord> layers;
    std::vector<SvMultisampleRecord> multisamples;
    std::vector<SvSampleRecord> samples;
    std::vector<SvZoneRecord> zones;
};

bool readBankModel(const MappedFile& f, BankModel& m, std::string& error) {
    if (!deserializeHeader(f.data, f.size, m.header, error)) return false;
    auto section = [&](SvSection s) { return m.header.sections[static_cast<std::size_t>(s)]; };
    auto readAll = [&](SvSection s, std::uint32_t count, std::size_t recSize, auto& vec, auto reader) {
        const auto sec = section(s);
        if (sec.offset + static_cast<std::uint64_t>(count) * recSize > f.size) return false;
        vec.resize(count);
        for (std::uint32_t i = 0U; i < count; ++i)
            if (!reader(f.data + sec.offset + static_cast<std::uint64_t>(i) * recSize, recSize, vec[i])) return false;
        return true;
    };
    if (!readAll(SvSection::Sounds, m.header.soundCount, kSvSoundRecordSize, m.sounds, readSoundRecord) ||
        !readAll(SvSection::SoundLayers, m.header.soundLayerCount, kSvSoundLayerRecordSize, m.layers, readSoundLayerRecord) ||
        !readAll(SvSection::Multisamples, m.header.multisampleCount, kSvMultisampleRecordSize, m.multisamples, readMultisampleRecord) ||
        !readAll(SvSection::Samples, m.header.sampleCount, kSvSampleRecordSize, m.samples, readSampleRecord) ||
        !readAll(SvSection::Zones, m.header.zoneCount, kSvZoneRecordSize, m.zones, readZoneRecord)) {
        error = "SILVETON_BANK.sv records cannot be read";
        return false;
    }
    return true;
}

std::string bankString(const MappedFile& f, const BankModel& m, std::uint32_t offset) {
    const auto sec = m.header.sections[static_cast<std::size_t>(SvSection::Strings)];
    if (offset >= sec.size) return {};
    std::size_t pos = static_cast<std::size_t>(sec.offset + offset);
    const std::size_t end = static_cast<std::size_t>(std::min<std::uint64_t>(sec.offset + sec.size, f.size));
    std::string out;
    while (pos < end && f.data[pos] != 0U) out.push_back(static_cast<char>(f.data[pos++]));
    return out;
}

// Sample ids used by a SOUND.
std::set<std::uint32_t> soundSamples(const BankModel& m, const SvSoundRecord& s) {
    std::map<std::uint32_t, const SvMultisampleRecord*> msById;
    for (const auto& ms : m.multisamples) msById[ms.multisampleId] = &ms;
    std::set<std::uint32_t> ids;
    for (std::uint32_t l = s.firstLayer; l < s.firstLayer + s.layerCount && l < m.layers.size(); ++l) {
        const auto it = msById.find(m.layers[l].multisampleId);
        if (it == msById.end()) continue;
        for (std::uint32_t z = it->second->firstZone; z < it->second->firstZone + it->second->zoneCount && z < m.zones.size(); ++z)
            ids.insert(m.zones[z].sampleId);
    }
    return ids;
}

// Text for INFO: first line "TOTAL\tsounds\tsamples\taudioBytes\tfileBytes", then
// one line per SOUND "slot\tname\tsamples\tbytes" (bytes = audio only this SOUND uses... and shared).
std::string bankInfoText(const std::string& path, std::string& error) {
    MappedFile f;
    if (!f.open(path)) { error = "Cannot open " + path; return {}; }
    BankModel m;
    if (!readBankModel(f, m, error)) return {};
    std::map<std::uint32_t, const SvSampleRecord*> sampleById;
    for (const auto& r : m.samples) sampleById[r.sampleId] = &r;
    std::set<std::uint64_t> allAudio;
    std::uint64_t totalAudio = 0U;
    for (const auto& r : m.samples) if (allAudio.insert(r.audioOffset).second) totalAudio += r.audioSize;
    std::ostringstream out;
    out << "TOTAL\t" << m.sounds.size() << "\t" << m.samples.size() << "\t" << totalAudio << "\t" << f.size << "\n";
    for (const auto& s : m.sounds) {
        const auto ids = soundSamples(m, s);
        std::set<std::uint64_t> audio;
        std::uint64_t bytes = 0U;
        for (auto id : ids) {
            const auto it = sampleById.find(id);
            if (it != sampleById.end() && audio.insert(it->second->audioOffset).second) bytes += it->second->audioSize;
        }
        std::string name = bankString(f, m, s.nameOffset);
        for (auto& ch : name) if (ch == '\t' || ch == '\n') ch = ' ';
        out << s.soundSlotId << "\t" << name << "\t" << ids.size() << "\t" << bytes << "\n";
    }
    return out.str();
}

bool removeBankSounds(const std::string& path, const std::set<std::uint16_t>& slots, std::string& error) {
    std::string tmp = path + ".tmp";
    {
        MappedFile f;
        if (!f.open(path)) { error = "Cannot open " + path; return false; }
        BankModel m;
        if (!readBankModel(f, m, error)) return false;
        BankModel n;
        n.header = m.header;
        std::set<std::uint32_t> usedMs;
        for (const auto& s : m.sounds) {
            if (slots.count(s.soundSlotId) != 0U) continue;
            SvSoundRecord r = s;
            r.firstLayer = static_cast<std::uint32_t>(n.layers.size());
            for (std::uint32_t l = s.firstLayer; l < s.firstLayer + s.layerCount && l < m.layers.size(); ++l) {
                n.layers.push_back(m.layers[l]);
                usedMs.insert(m.layers[l].multisampleId);
            }
            r.layerCount = static_cast<std::uint32_t>(n.layers.size()) - r.firstLayer;
            n.sounds.push_back(r);
        }
        if (n.sounds.empty()) { error = "The last SOUND cannot be deleted"; return false; }
        std::set<std::uint32_t> usedSamples;
        for (const auto& ms : m.multisamples) {
            if (usedMs.count(ms.multisampleId) == 0U) continue;
            SvMultisampleRecord r = ms;
            r.firstZone = static_cast<std::uint32_t>(n.zones.size());
            for (std::uint32_t z = ms.firstZone; z < ms.firstZone + ms.zoneCount && z < m.zones.size(); ++z) {
                n.zones.push_back(m.zones[z]);
                usedSamples.insert(m.zones[z].sampleId);
            }
            r.zoneCount = static_cast<std::uint32_t>(n.zones.size()) - r.firstZone;
            n.multisamples.push_back(r);
        }
        // audio: every kept piece once, aligned to 64 bytes
        std::map<std::uint64_t, std::uint64_t> newOffset;
        std::vector<std::pair<std::uint64_t, std::uint64_t>> copies;   // old offset, size
        std::uint64_t audioSize = 0U;
        for (const auto& r : m.samples) {
            if (usedSamples.count(r.sampleId) == 0U) continue;
            SvSampleRecord k = r;
            auto it = newOffset.find(r.audioOffset);
            if (it == newOffset.end()) {
                audioSize = (audioSize + 63U) & ~std::uint64_t{63U};
                it = newOffset.emplace(r.audioOffset, audioSize).first;
                copies.emplace_back(r.audioOffset, r.audioSize);
                audioSize += r.audioSize;
            }
            k.audioOffset = it->second;
            n.samples.push_back(k);
        }
        // layout
        auto& h = n.header;
        h.soundCount = static_cast<std::uint32_t>(n.sounds.size());
        h.soundLayerCount = static_cast<std::uint32_t>(n.layers.size());
        h.multisampleCount = static_cast<std::uint32_t>(n.multisamples.size());
        h.sampleCount = static_cast<std::uint32_t>(n.samples.size());
        h.zoneCount = static_cast<std::uint32_t>(n.zones.size());
        std::vector<std::uint8_t> records[5];
        for (const auto& r : n.sounds) appendSoundRecord(records[0], r);
        for (const auto& r : n.layers) appendSoundLayerRecord(records[1], r);
        for (const auto& r : n.multisamples) appendMultisampleRecord(records[2], r);
        for (const auto& r : n.samples) appendSampleRecord(records[3], r);
        for (const auto& r : n.zones) appendZoneRecord(records[4], r);
        const auto oldStrings = m.header.sections[static_cast<std::size_t>(SvSection::Strings)];
        const auto oldAudio = m.header.sections[static_cast<std::size_t>(SvSection::Audio)];
        std::uint64_t pos = kSvBankHeaderSize;
        auto place = [&](SvSection s, std::uint64_t size, std::uint64_t align) {
            pos = (pos + align - 1U) / align * align;
            h.sections[static_cast<std::size_t>(s)] = SvSectionDesc{pos, size};
            pos += size;
        };
        place(SvSection::Sounds, records[0].size(), 64U);
        place(SvSection::SoundLayers, records[1].size(), 64U);
        place(SvSection::Multisamples, records[2].size(), 64U);
        place(SvSection::Samples, records[3].size(), 64U);
        place(SvSection::Zones, records[4].size(), 64U);
        place(SvSection::Strings, oldStrings.size, 64U);
        place(SvSection::Audio, audioSize, 4096U);
        h.fileSize = pos;
        // write: header placeholder, payload streamed (SHA-256 on the way), header again
        const int fd = ::open(tmp.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        if (fd < 0) { error = "Cannot write " + tmp; return false; }
        Sha256Stream sha;
        std::uint64_t written = 0U;
        bool ok = true;
        auto put = [&](const std::uint8_t* p, std::size_t len, bool hash) {
            while (ok && len > 0U) {
                const ssize_t w = ::write(fd, p, len);
                if (w <= 0) { if (errno == EINTR) continue; ok = false; break; }
                if (hash) sha.add(p, static_cast<std::size_t>(w));
                p += w; len -= static_cast<std::size_t>(w); written += static_cast<std::uint64_t>(w);
            }
        };
        std::vector<std::uint8_t> zeros(4096, 0U);
        auto padTo = [&](std::uint64_t to) {
            while (ok && written < to) put(zeros.data(), static_cast<std::size_t>(std::min<std::uint64_t>(zeros.size(), to - written)), true);
        };
        const auto headerBytes = serializeHeader(h);
        put(headerBytes.data(), headerBytes.size(), false);
        while (ok && written < kSvBankHeaderSize) put(zeros.data(), static_cast<std::size_t>(kSvBankHeaderSize - written), false);
        const SvSection order[5] = {SvSection::Sounds, SvSection::SoundLayers, SvSection::Multisamples, SvSection::Samples, SvSection::Zones};
        for (int i = 0; i < 5 && ok; ++i) {
            padTo(h.sections[static_cast<std::size_t>(order[i])].offset);
            put(records[i].data(), records[i].size(), true);
        }
        padTo(h.sections[static_cast<std::size_t>(SvSection::Strings)].offset);
        if (oldStrings.offset + oldStrings.size <= f.size) put(f.data + oldStrings.offset, static_cast<std::size_t>(oldStrings.size), true);
        const std::uint64_t audioBase = h.sections[static_cast<std::size_t>(SvSection::Audio)].offset;
        for (const auto& c : copies) {
            padTo(audioBase + newOffset[c.first]);
            if (oldAudio.offset + c.first + c.second > f.size) { ok = false; error = "Bank audio is outside the file"; break; }
            put(f.data + oldAudio.offset + c.first, static_cast<std::size_t>(c.second), true);
        }
        padTo(h.fileSize);
        h.payloadSha256 = sha.finish();
        const auto finalHeader = serializeHeader(h);
        if (ok && ::lseek(fd, 0, SEEK_SET) == 0) { written = 0U; put(finalHeader.data(), finalHeader.size(), false); }
        else ok = false;
        if (ok && ::fsync(fd) != 0) ok = false;
        ::close(fd);
        if (!ok) { ::unlink(tmp.c_str()); if (error.empty()) error = "Writing the bank failed (storage full?)"; return false; }
    }
    if (::rename(tmp.c_str(), path.c_str()) != 0) { ::unlink(tmp.c_str()); error = "Cannot replace " + path; return false; }
    return true;
}

constexpr const char* kTag = "SilvetonSampler";

// Built-in playable fallback instrument. It is deliberately generated in the
// native realtime path so a fresh APK can verify MIDI -> DSP -> Direct ALSA
// without requiring a bank file. As soon as a real PROGRAM/COMBI is loaded,
// installState() disables this fallback automatically.
class BuiltinTestInstrument {
public:
    static constexpr std::size_t kVoiceCount = 24U;
    static constexpr std::size_t kTableSize = 2048U;
    static constexpr std::size_t kEventCount = 128U;

    BuiltinTestInstrument() noexcept {
        constexpr double pi = 3.14159265358979323846;
        for (std::size_t i = 0; i < kTableSize; ++i) {
            const double p = 2.0 * pi * static_cast<double>(i) / static_cast<double>(kTableSize);
            table_[i] = static_cast<float>(
                0.78 * std::sin(p) +
                0.16 * std::sin(2.0 * p) +
                0.06 * std::sin(3.0 * p));
        }
    }

    void setEnabled(bool enabled) noexcept {
        enabled_.store(enabled, std::memory_order_release);
        if (!enabled) push({3U, 0U, 0U});
    }

    bool enabled() const noexcept { return enabled_.load(std::memory_order_acquire); }

    void noteOn(std::uint8_t key, std::uint8_t velocity) noexcept {
        if (enabled() && velocity != 0U) push({1U, key, velocity});
    }
    void noteOff(std::uint8_t key) noexcept {
        if (enabled()) push({2U, key, 0U});
    }
    void panic() noexcept { push({3U, 0U, 0U}); }

    void render(float* interleavedStereo, std::uint32_t frames, int sampleRate) noexcept {
        if (interleavedStereo == nullptr || frames == 0U || sampleRate <= 0) return;
        consumeEvents(sampleRate);
        if (!enabled()) return;
        if (std::none_of(voices_.begin(),voices_.end(),[](const auto& voice){return voice.active;})) return;

        const float sr = static_cast<float>(sampleRate);
        const float attackStep = 1.0F / std::max(1.0F, sr * 0.004F);
        const float decayK = 1.0F - std::exp(-1.0F / std::max(1.0F, sr * 0.24F));
        const float releaseMul = std::exp(std::log(0.0001F) / std::max(1.0F, sr * 0.32F));

        for (std::uint32_t f = 0; f < frames; ++f) {
            float mono = 0.0F;
            for (auto& v : voices_) {
                if (!v.active) continue;

                if (!v.releasing) {
                    if (v.env < 0.999F && v.attack) {
                        v.env += attackStep;
                        if (v.env >= 1.0F) { v.env = 1.0F; v.attack = false; }
                    } else {
                        v.env += (0.48F - v.env) * decayK;
                    }
                } else {
                    v.env *= releaseMul;
                    if (v.env < 0.0001F) { v.active = false; continue; }
                }

                const auto i0 = static_cast<std::size_t>(v.phase) & (kTableSize - 1U);
                const auto i1 = (i0 + 1U) & (kTableSize - 1U);
                const float frac = v.phase - static_cast<float>(static_cast<std::size_t>(v.phase));
                const float osc = table_[i0] + (table_[i1] - table_[i0]) * frac;
                mono += osc * v.env * v.velocityGain * 0.035F;

                v.phase += v.phaseStep;
                if (v.phase >= static_cast<float>(kTableSize)) v.phase -= static_cast<float>(kTableSize);
            }

            interleavedStereo[static_cast<std::size_t>(f) * 2U] += mono;
            interleavedStereo[static_cast<std::size_t>(f) * 2U + 1U] += mono;
        }
    }

private:
    struct Event { std::uint8_t type; std::uint8_t key; std::uint8_t velocity; };
    struct Voice {
        bool active{false};
        bool releasing{false};
        bool attack{true};
        std::uint8_t key{0U};
        float phase{0.0F};
        float phaseStep{0.0F};
        float env{0.0F};
        float velocityGain{0.0F};
        std::uint64_t age{0U};
    };

    void push(Event e) noexcept {
        if (writeLock_.test_and_set(std::memory_order_acquire)) return;
        const unsigned w = write_.load(std::memory_order_relaxed);
        const unsigned next = (w + 1U) % static_cast<unsigned>(kEventCount);
        if (next != read_.load(std::memory_order_acquire)) {
            events_[w] = e;
            write_.store(next, std::memory_order_release);
        }
        writeLock_.clear(std::memory_order_release);
    }

    void consumeEvents(int sampleRate) noexcept {
        unsigned r = read_.load(std::memory_order_relaxed);
        const unsigned w = write_.load(std::memory_order_acquire);
        while (r != w) {
            const Event e = events_[r];
            r = (r + 1U) % static_cast<unsigned>(kEventCount);
            if (e.type == 1U) startVoice(e.key, e.velocity, sampleRate);
            else if (e.type == 2U) releaseKey(e.key);
            else if (e.type == 3U) for (auto& v : voices_) v = Voice{};
        }
        read_.store(r, std::memory_order_release);
    }

    void startVoice(std::uint8_t key, std::uint8_t velocity, int sampleRate) noexcept {
        Voice* chosen = nullptr;
        for (auto& v : voices_) if (!v.active) { chosen = &v; break; }
        if (chosen == nullptr) {
            chosen = &voices_[0];
            for (auto& v : voices_) if (v.env < chosen->env || (v.env == chosen->env && v.age < chosen->age)) chosen = &v;
        }
        const double frequency = 440.0 * std::pow(2.0, (static_cast<int>(key) - 69) / 12.0);
        chosen->active = true;
        chosen->releasing = false;
        chosen->attack = true;
        chosen->key = key;
        chosen->phase = 0.0F;
        chosen->phaseStep = static_cast<float>(frequency * static_cast<double>(kTableSize) / static_cast<double>(sampleRate));
        chosen->env = 0.0F;
        chosen->velocityGain = std::sqrt(static_cast<float>(velocity) / 127.0F);
        chosen->age = ++age_;
    }

    void releaseKey(std::uint8_t key) noexcept {
        for (auto& v : voices_) if (v.active && v.key == key) v.releasing = true;
    }

    std::array<float, kTableSize> table_{};
    std::array<Voice, kVoiceCount> voices_{};
    std::array<Event, kEventCount> events_{};
    std::atomic<unsigned> write_{0U};
    std::atomic<unsigned> read_{0U};
    std::atomic<bool> enabled_{true};
    std::atomic_flag writeLock_ = ATOMIC_FLAG_INIT;
    std::uint64_t age_{0U};
};

static void configureRealtimeThread(const char* name, int firstCpu, int lastCpu, int fifoPriority) noexcept {
    if (name != nullptr) (void)::pthread_setname_np(::pthread_self(), name);

    cpu_set_t set;
    CPU_ZERO(&set);
    for (int cpu = std::max(0, firstCpu); cpu <= std::max(firstCpu, lastCpu); ++cpu) CPU_SET(cpu, &set);
    (void)::sched_setaffinity(0, sizeof(set), &set);

    sched_param param{};
    param.sched_priority = fifoPriority;
    if (::sched_setscheduler(0, SCHED_FIFO, &param) != 0) {
        // Ordinary Android processes may not hold CAP_SYS_NICE. Root mode will
        // promote the named TID from outside; nice still gives a useful fallback.
        (void)::setpriority(PRIO_PROCESS, 0, -16);
    }
}


class AndroidSamplerAudio {
public:
    AndroidSamplerAudio() = default;
    ~AndroidSamplerAudio() {
        close();
        std::lock_guard<std::mutex> lock(routeMutex_);
        if (routeFd_ >= 0) { ::close(routeFd_); routeFd_ = -1; }
    }

    // Direct ALSA retains its proven wired-jack route. Without a jack, Android
    // owns speaker routing and amplifier/protection setup through AAudio; this
    // host never invents speaker mixer switches or analogue gain settings.
    void setOutputSelection(bool wired,int speakerDeviceId) {
        std::lock_guard<std::mutex> lock(controlMutex_);
        const bool previousWired=desiredWired_.load(std::memory_order_relaxed);
        const int previousSpeaker=desiredSpeakerId_.load(std::memory_order_relaxed);
        desiredWired_.store(wired,std::memory_order_release);
        desiredSpeakerId_.store(std::max(0,speakerDeviceId),std::memory_order_release);
        if((previousWired!=wired||(!wired&&previousSpeaker!=std::max(0,speakerDeviceId)))&&
            (pcmFd_.load(std::memory_order_acquire)>=0||managedStream_.load(std::memory_order_acquire)!=nullptr||
             wantStarted_.load(std::memory_order_acquire)))
            recoverRequested_.store(true,std::memory_order_release);
    }

    // PORTA BALANCE of the SILVETON keyboard processor (3..40, default 11).
    void setPortamentoBalance(float balance) noexcept { engine_.setPortamentoBalance(balance); }
    void setPortamentoNear(float ms) noexcept { engine_.setPortamentoNear(ms); }
    // SILVETON_VOICE_CEILING_V1: how many notes may sound at once
    void setVoiceCeiling(int voices) noexcept { engine_.setVoiceCeiling(voices); }
    [[nodiscard]] int voiceCeiling() const noexcept { return engine_.voiceCeiling(); }

    bool enforceHeadphoneRoute(bool onlyWhileRunning) {
        if(!desiredWired_.load(std::memory_order_acquire)||
            (onlyWhileRunning&&activeManaged_.load(std::memory_order_acquire)))return true;
        if (onlyWhileRunning && !started_.load(std::memory_order_acquire)) return true;
        std::lock_guard<std::mutex> lock(routeMutex_);
        if (routeFd_ < 0) {
            routeFd_ = ::open(kControlDevice, O_RDWR | O_CLOEXEC);
            if (routeFd_ < 0) return false;
            if (!scanRouteLocked() || routeTargets_.empty()) {
                ::close(routeFd_); routeFd_ = -1; routeTargets_.clear();
                return false;
            }
            __android_log_print(ANDROID_LOG_INFO, kTag, "Headphone lock: %zu mixer controls", routeTargets_.size());
        }
        const int changed = applyRouteLocked();
        if (changed < 0) {
            ::close(routeFd_); routeFd_ = -1; routeTargets_.clear(); // rescan next time
            return false;
        }
        if (changed > 0) __android_log_print(ANDROID_LOG_INFO, kTag, "Headphone lock restored %d mixer controls", changed);
        return true;
    }

    bool open() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        // MIDI is an independent realtime input path. Start it first so a
        // temporary PCM failure never makes the keyboard disappear.
        const bool midiOk = startDirectMidiLocked();
        // Read-ahead uses the background CPU partition, outside the audio and
        // shared DSP-worker cores. It never performs storage work on audio.
        const auto streamPolicy=deviceCpuWorkPolicy();
        prefetcher_.setCpuRange(streamPolicy.streamFirstCpu,streamPolicy.streamLastCpu);
        if (!prefetcher_.start()) {
            __android_log_print(ANDROID_LOG_WARN, kTag, "Bank read-ahead thread could not start");
        }
        const bool audioOk = openLocked();
        if (!audioOk) return false;
        if (!midiOk) {
            __android_log_print(ANDROID_LOG_WARN, kTag,
                "Direct MIDI did not start while audio opened successfully");
        }
        return true;
    }

    bool start() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(true, std::memory_order_release);
        return startLocked();
    }

    void stop() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(false, std::memory_order_release);
        (void)stopLocked();
    }

    void close() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(false, std::memory_order_release);
        (void)stopLocked();
        stopDirectMidiLocked();
        prefetcher_.stop();
        closePcmLocked();
    }

    bool recover() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        if (!recoverRequested_.load(std::memory_order_acquire)) return true;
        const bool resume = wantStarted_.load(std::memory_order_acquire);
        // A route/device recovery suspends output, not the arranger transport.
        // Closing AAudio fully also releases Android's primary PCM before the
        // wired Direct ALSA path tries to acquire it.
        (void)stopLocked(false);
        closePcmLocked();
        if (!openLocked()) return false;
        recoverRequested_.store(false, std::memory_order_release);
        return !resume || startLocked();
    }

    bool loadAudioFile(const std::string& path) {
        // Two seconds at 48 kHz is preloaded for instant attack; the remainder
        // stays mmap-backed. Higher-rate files preload the same frame count,
        // still avoiding full-library RAM residency on the 4 GB target tablet.
        const auto loaded = AudioFileLoader::loadStreaming(path, 96000U);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        return installMultisample(makeSingleSampleMultisample(loaded.sample, loaded.sample->name), loaded.sample->name);
    }

    bool loadKmp(const std::string& path) {
        const auto imported = library_.importKmp(path);
        if (!imported.success || imported.multisampleIds.empty()) {
            setTextError(imported.error.empty() ? "KMP library import returned no multisample" : imported.error);
            return false;
        }
        const auto ms = library_.multisample(imported.multisampleIds.front());
        if (ms == nullptr) { setTextError("Imported KMP multisample is missing from library"); return false; }
        return installMultisample(ms, ms->name);
    }

    std::vector<int> importKmpToLibrary(const std::string& path) {
        const auto imported = library_.importKmp(path);
        if (!imported.success) { setTextError(imported.error); return {}; }
        std::vector<int> ids; ids.reserve(imported.multisampleIds.size());
        for (const auto id : imported.multisampleIds) ids.push_back(static_cast<int>(id));
        setTextError({});
        return ids;
    }

    std::vector<int> importKscToLibrary(const std::string& path) {
        const auto imported = library_.importKsc(path);
        if (!imported.success) { setTextError(imported.error); return {}; }
        std::vector<int> ids; ids.reserve(imported.multisampleIds.size());
        for (const auto id : imported.multisampleIds) ids.push_back(static_cast<int>(id));
        setTextError({});
        return ids;
    }

    std::vector<int> multisampleIds() const {
        const auto raw = library_.multisampleIds();
        std::vector<int> ids; ids.reserve(raw.size());
        for (const auto id : raw) ids.push_back(static_cast<int>(id));
        return ids;
    }

    std::vector<std::string> multisampleNames() const { return library_.multisampleNames(); }
    std::vector<std::uint32_t> sampleIds() const { return library_.sampleIds(); }
    std::vector<std::string> sampleNames() const { return library_.sampleNames(); }
    bool sampleWave(std::uint32_t id, std::vector<float>& points) const { return library_.sampleWave(id, points); }

    std::vector<std::string> kscNames(const std::string& path) {
        if (!ensureKscCache(path)) return {};
        std::vector<std::string> names;
        names.reserve(kscCache_.multisamples.size());
        for (const auto& ms : kscCache_.multisamples) names.push_back(ms != nullptr ? ms->name : std::string{});
        return names;
    }

    bool loadKscItem(const std::string& path, int index) {
        if (!ensureKscCache(path)) return false;
        if (index < 0 || static_cast<std::size_t>(index) >= kscCache_.multisamples.size()) {
            setTextError("KSC multisample index is out of range");
            return false;
        }
        const auto& ms = kscCache_.multisamples[static_cast<std::size_t>(index)];
        if (ms == nullptr) { setTextError("KSC multisample is empty"); return false; }
        return installMultisample(ms, ms->name);
    }

    bool loadSvBank(const std::string& path) {
        const auto loaded = SvBankRuntime::load(path, 65536U, false);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        if (loaded.data.programs.empty() || loaded.data.programs.front().program == nullptr) {
            setTextError("SILVETON bank contains no playable SOUND");
            return false;
        }

        // Preserve user performance objects across a SOUND-bank replacement.
        // SILVETON_SOUND_BY_NAME_V1: a BLEND finds its sounds again by their NAME in the
        // new bank (the 1..500 place is only the first guess), so a bank with re-ordered
        // sounds never makes a BLEND play a different sound. A sound that is not in the
        // new bank is not replaced by another one - its part goes off.
        const auto preserved = library_.snapshot();
        auto merged = loaded.data;
        merged.global = preserved.global;
        merged.combis = preserved.combis;
        merged.lists = preserved.lists;
        library_.replace(merged);
        arrangerHost().clearSoundAssignments();

        const auto bankSounds = bankSoundCandidates();
        for (const auto& saved : preserved.combis) {
            Combi rebound = saved.combi;
            for (auto& upper : rebound.uppers) rebindUpper(upper, bankSounds);
            if (!library_.writeCombi(saved.address, rebound)) {
                setTextError("Failed to restore COMBI after SILVETON bank load");
                return false;
            }
        }
        // Do not accept a bank merely because SOUND names are visible. Select
        // a SOUND that resolves all the way to a valid SAMPLE.
        const ProgramSlot* selectedSound = nullptr;
        std::uint8_t selectedKey = 60U;
        std::uint8_t selectedVelocity = 100U;
        for (const auto& slot : loaded.data.programs) {
            if (slot.program == nullptr) continue;
            for (const auto& layer : slot.program->layers) {
                if (!layer.enabled || layer.multisample == nullptr) continue;
                for (const auto& zone : layer.multisample->zones) {
                    if (zone.sample == nullptr || !zone.sample->valid()) continue;
                    const int keyLow = std::max<int>(layer.keyLow, zone.keyLow);
                    const int keyHigh = std::min<int>(layer.keyHigh, zone.keyHigh);
                    const int velLow = std::max<int>(layer.velocityLow, zone.velocityLow);
                    const int velHigh = std::min<int>(layer.velocityHigh, zone.velocityHigh);
                    if (keyLow > keyHigh || velLow > velHigh || velHigh <= 0) continue;
                    selectedSound = &slot;
                    selectedKey = static_cast<std::uint8_t>(std::clamp<int>(zone.rootKey, keyLow, keyHigh));
                    selectedVelocity = static_cast<std::uint8_t>(std::clamp<int>(100, std::max(1, velLow), velHigh));
                    break;
                }
                if (selectedSound != nullptr) break;
            }
            if (selectedSound != nullptr) break;
        }
        if (selectedSound == nullptr || selectedSound->program == nullptr) {
            setTextError("SILVETON bank has SOUND names but no playable SAMPLE path");
            return false;
        }

        // Offline proof with the exact mmap-backed objects. No hardware audio
        // route is opened, stopped or changed by this probe.
        auto probeState = std::make_shared<EngineState>();
        probeState->combi.name = selectedSound->program->name;
        auto& probeUpper = probeState->combi.uppers[0];
        probeUpper.name = selectedSound->program->name;
        probeUpper.enabled = true;
        probeUpper.mute = false;
        probeUpper.solo = false;
        probeUpper.program = selectedSound->program;
        probeUpper.soundSlotId = selectedSound->address.slot;
        probeUpper.midiChannel = 0U;

        SamplerEngine probeEngine;
        probeEngine.prepare(48000.0, 256U);
        probeEngine.setInterpolationQuality(InterpolationQuality::LiveCubic4);
        probeEngine.setState(probeState);
        if (!probeEngine.postNoteOn(0U, selectedKey, selectedVelocity)) {
            setTextError("SILVETON bank playback probe could not queue MIDI note");
            return false;
        }
        std::vector<float> probeAudio(256U * 2U, 0.0F);
        float probePeak = 0.0F;
        for (int blockIndex = 0; blockIndex < 64 && probePeak <= 1.0e-6F; ++blockIndex) {
            probeEngine.render(probeAudio.data(), 256U);
            for (const float value : probeAudio) {
                const float magnitude = value < 0.0F ? -value : value;
                if (magnitude > probePeak) probePeak = magnitude;
            }
        }
        if (!(probePeak > 1.0e-6F)) {
            setTextError("SILVETON bank loaded but SAMPLE playback path is silent");
            return false;
        }

        auto state = std::make_shared<EngineState>();
        if (state_ != nullptr) state->global = state_->global;
        state->combi.name = selectedSound->program->name;
        auto& firstUpper = state->combi.uppers[0];
        firstUpper.name = selectedSound->program->name;
        firstUpper.enabled = true;
        firstUpper.mute = false;
        firstUpper.solo = false;
        firstUpper.program = selectedSound->program;
        firstUpper.soundSlotId = selectedSound->address.slot;
        firstUpper.midiChannel = 0U;
        if (!installState(std::move(state), Mark::Clean)) return false;
        setTextError({});
        return true;
    }

    bool loadSet(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        library_.replace(loaded.data);
        arrangerHost().clearSoundAssignments();
        auto state = std::make_shared<EngineState>();
        state->global = loaded.data.global;
        if (!loaded.data.combis.empty()) {
            state->combi = loaded.data.combis.front().combi;
        } else if (!loaded.data.programs.empty() && loaded.data.programs.front().program != nullptr) {
            state->combi.name = loaded.data.programs.front().program->name;
            state->combi.uppers[0].enabled = true;
            state->combi.uppers[0].program = loaded.data.programs.front().program;
            state->combi.uppers[0].midiChannel = 0U;
        } else {
            setTextError("SET contains no playable COMBI or PROGRAM");
            return false;
        }
        return installState(std::move(state), Mark::Clean);
    }

    bool saveSet(const std::string& path) {
        syncCurrentStateToLibrary();
        const auto saved = SetPackage::save(path, library_.snapshot());
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool saveUserPerformanceState(const std::string& path) {
        syncCurrentStateToLibrary();
        auto data = library_.snapshot();
        data.samples.clear();
        data.multisamples.clear();
        data.programs.clear();
        for (auto& slot : data.combis) stripPerformancePrograms(slot.combi);
        if (state_ != nullptr) {
            PerformanceSnapshot current;
            current.combi = state_->combi;
            current.activeListAddress = activeListAddress_;
            current.activeListEntry = activeListEntry_;
            current.edited = blendEdited_.load(std::memory_order_acquire);
            stripPerformancePrograms(current.combi);
            data.performance = std::move(current);
        }
        data.extra = pendingSetExtra_; // keep metadata on repeated saves, including automatic saves
        const auto saved = SetPackage::save(path, data);
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    // The metadata every saved SET carries, and the metadata of the last loaded SET.
    void setSetExtraText(const std::string& text) { pendingSetExtra_ = text; }
    std::string lastLoadedSetExtraText() const { return lastLoadedSetExtra_; }



    // SILVETON_SEND_V1 (the Manager's copy of the sampler): every SOUND of a small bank file goes into the library at its own place
    // (what was there is replaced); the bank the sampler plays is not written. The blends and the open COMBI find their sounds
    // again by name, so a SOUND sent again (a new version) is played at once.
    bool addBankSounds(const std::string& path) {
        const auto loaded = SvBankRuntime::load(path, 65536U, false);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        std::size_t added = 0U;
        for (const auto& slot : loaded.data.programs) {
            if (slot.program == nullptr) continue;
            if (!library_.writeProgram(slot.address, slot.program)) { setTextError("SOUND could not be added"); return false; }
            ++added;
        }
        if (added == 0U) { setTextError("The file has no SOUND"); return false; }
        const auto bankSounds = bankSoundCandidates();
        const auto snapshot = library_.snapshot();
        for (const auto& saved : snapshot.combis) {
            Combi rebound = saved.combi;
            for (auto& upper : rebound.uppers) rebindUpper(upper, bankSounds);
            (void)library_.writeCombi(saved.address, rebound);
        }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_);
            for (auto& upper : next->combi.uppers) rebindUpper(upper, bankSounds);
            if (!installState(std::move(next), Mark::Keep)) return false;
        }
        setTextError({});
        return true;
    }

    // SILVETON_PASTE_V1 (the Manager's copy): a new BLEND with only this SOUND on Upper 1, everything else as a new BLEND starts.
    bool writeSoundCombi(const SlotAddress& address, std::uint16_t soundSlot, const std::string& name) {
        const auto program = library_.program(SlotAddress{0U, 0U, soundSlot});
        if (program == nullptr) { setTextError("SOUND slot is empty"); return false; }
        Combi combi{};
        combi.name = name;
        auto& upper = combi.uppers[0];
        upper.program = program;
        upper.soundSlotId = soundSlot;
        upper.name = program->name;
        upper.enabled = true;
        if (!library_.writeCombi(address, combi)) { setTextError("Write Combi failed"); return false; }
        setTextError({});
        return true;
    }

    // SILVETON_LIST_DELETE_SOUNDS_V1 (the Manager's copy): which SOUND places a COMBI uses - basic sound, layers, TRANSWAVE frames -
    // found by the same rule the blends use when they load (resolveSoundByName).
    static void markCombiSounds(const Combi& combi, const std::vector<SoundCandidate>& bankSounds, std::set<int>& out) {
        auto mark = [&](std::uint16_t slot, const std::string& name) {
            if (slot == kNoSoundSlot) return;
            const auto found = resolveSoundByName(slot, name, bankSounds);
            if (found.found) out.insert(static_cast<int>(found.slot));
        };
        auto waves = [&](const ToneExtra& x) { for (const auto w : x.waveSlot) if (w != 0U) out.insert(static_cast<int>(w)); };
        for (int i = 0; i < kPartCount; ++i) {
            const auto& upper = combi.part(i);
            mark(upper.soundSlotId, upper.name);
            waves(upper.toneExtra);
            for (const auto& layer : upper.layers) {
                mark(layer.soundSlotId, layer.name);
                waves(layer.tone.x);
            }
        }
    }

    // SILVETON_LIST_DELETE_GHOST_V1: only the COMBIs in `listed` (the other LIST positions) count as other users. A COMBI that is not on the
    // LIST any more (the blend was taken off the LIST by the plain DELETE, which keeps the blend itself) is a ghost: it would keep the sound
    // for ever, so a deleted blend never took its sound with it. When the sound leaves, removeSoundPlaces makes the ghosts forget it.
    std::vector<int> soundsOnlyInCombi(const SlotAddress& address, bool countOpen, const std::vector<std::string>& setPaths,
                                       const std::vector<SlotAddress>& listed) const {
        const auto mine = library_.combi(address);
        if (!mine.has_value()) return {};
        const auto bankSounds = bankSoundCandidates();
        std::set<int> own, other;
        markCombiSounds(*mine, bankSounds, own);
        const auto all = library_.snapshot();
        for (const auto& slot : all.combis) {
            if (slot.address.bank == address.bank && slot.address.page == address.page && slot.address.slot == address.slot) continue;
            if (std::find(listed.begin(), listed.end(), slot.address) == listed.end()) continue;   // a ghost: not on the LIST
            markCombiSounds(slot.combi, bankSounds, other);
        }
        if (countOpen && state_ != nullptr) markCombiSounds(state_->combi, bankSounds, other);
        for (const auto& path : setPaths) {
            const auto loaded = SetPackage::load(path);
            if (!loaded.ok()) return {};   // a set that cannot be read: nothing may go
            for (const auto& slot : loaded.data.combis) markCombiSounds(slot.combi, bankSounds, other);
            if (loaded.data.performance) markCombiSounds(loaded.data.performance->combi, bankSounds, other);
        }
        std::vector<int> out;
        for (const int place : own) if (place >= 1 && place <= 500 && other.count(place) == 0U) out.push_back(place);
        return out;
    }

    // SILVETON_SOUND_BY_NUMBER_V2: a deleted place is forgotten by EVERY blend that used it (basic sound, layers, TRANSWAVE frames), so a new
    // sound that later takes that number is never played by an old blend. The place stays empty until a new sound is sent to it.
    static void forgetPlacesInCombi(Combi& combi, const std::set<int>& gone) {
        auto waves = [&](ToneExtra& x) { for (auto& w : x.waveSlot) if (w != 0U && gone.count(static_cast<int>(w)) != 0U) w = 0U; };
        for (auto& upper : combi.uppers) {
            if (upper.soundSlotId != kNoSoundSlot && gone.count(static_cast<int>(upper.soundSlotId)) != 0U) {
                upper.program.reset(); upper.soundSlotId = kNoSoundSlot;
            }
            waves(upper.toneExtra);
            for (auto& l : upper.layers) {
                if (l.soundSlotId != kNoSoundSlot && gone.count(static_cast<int>(l.soundSlotId)) != 0U) {
                    l.program.reset(); l.soundSlotId = kNoSoundSlot; l.enabled = false; l.name.clear();
                }
                waves(l.tone.x);
            }
            if (upper.program == nullptr && !upper.hasAnySound() && !engineMakesOwnSound(upper.engine)) upper.enabled = false;
        }
    }

    bool removeSoundPlaces(const std::vector<int>& places) {
        std::set<int> gone;
        for (const int place : places) {
            if (place >= 1 && place <= 500) { (void)library_.clearProgram(SlotAddress{0U, 0U, static_cast<std::uint16_t>(place)}); gone.insert(place); }
        }
        if (!gone.empty()) {
            const auto all = library_.snapshot();
            for (const auto& slot : all.combis) {
                Combi c = slot.combi;
                forgetPlacesInCombi(c, gone);
                (void)library_.writeCombi(slot.address, c);
            }
        }
        if (state_ == nullptr) return true;
        const auto bankSounds = bankSoundCandidates();
        auto next = std::make_shared<EngineState>(*state_);
        forgetPlacesInCombi(next->combi, gone);
        for (auto& upper : next->combi.uppers) rebindUpper(upper, bankSounds);
        return installState(std::move(next), Mark::Keep);
    }

    // SILVETON_PROJECT_V1 (the Manager's copy): the COMBI that is open now, into a file of its own and back.
    bool saveOpenCombi(const std::string& path) {
        if (state_ == nullptr) { setTextError("No COMBI is open"); return false; }
        SetData data;
        data.name = "OPEN COMBI";
        data.global = state_->global;
        CombiSlot slot;
        slot.address = SlotAddress{0U, 0U, 1U};
        slot.combi = state_->combi;
        stripPerformancePrograms(slot.combi);
        data.combis.push_back(slot);
        const auto saved = SetPackage::save(path, data);
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }
    bool loadOpenCombi(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        if (loaded.data.combis.empty()) { setTextError("The file has no COMBI"); return false; }
        auto next = std::make_shared<EngineState>();
        next->global = state_ != nullptr ? state_->global : library_.global();
        next->combi = loaded.data.combis.front().combi;
        next->combiGeneration = (state_ != nullptr ? state_->combiGeneration : 0U) + 1U;
        const auto bankSounds = bankSoundCandidates();
        const std::string missing = rebindPerformanceCombi(next->combi, bankSounds);
        if (!installState(std::move(next), Mark::Clean)) return false;
        {
            std::lock_guard<std::mutex> lock(missingMutex_);
            lastRecallMissing_ = missing;
        }
        return true;
    }

    // SILVETON_SET_SAVE_AS_V1: LOAD of a saved set. The LIST and all BLENDS are
    // replaced by the ones in the file (nothing old is mixed in), and the GLOBAL
    // settings saved with the set come back too. The sound bank is not touched.
    bool replaceUserPerformanceState(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        return replacePreparedUserPerformanceState(loaded.data);
    }

    bool replacePreparedUserPerformanceState(const SetData& data) {
        // Stage from the current bank, replacing only the saved performances.
        // A bad SET must not erase the old LIST before validation is complete.
        auto staged = library_;
        const auto before = library_.snapshot();
        for (const auto& c : before.combis) staged.clearCombi(c.address);
        for (const auto& l : before.lists) staged.clearList(l.address);
        const auto bankSounds = bankSoundCandidates();
        for (const auto& saved : data.combis) {
            Combi rebound = saved.combi;
            (void)rebindPerformanceCombi(rebound, bankSounds);
            if (!staged.writeCombi(saved.address, rebound)) {
                setTextError("Could not restore saved BLEND/COMBI"); return false;
            }
        }
        for (const auto& saved : data.lists) {
            if (!staged.writeList(saved.address, saved.list)) {
                setTextError("Could not restore saved LIST"); return false;
            }
        }
        auto next = std::make_shared<EngineState>();
        next->global = data.global;
        next->combiGeneration = (state_ != nullptr ? state_->combiGeneration : 0U) + 1U;
        std::optional<SlotAddress> listAddress;
        int listEntry = -1;
        bool edited = false;
        if (data.performance) {
            const auto& current = *data.performance;
            next->combi = current.combi;
            edited = current.edited;
            if (current.activeListAddress && current.activeListEntry >= 0) {
                const auto list = staged.list(*current.activeListAddress);
                if (list && static_cast<std::size_t>(current.activeListEntry) < list->entries.size()) {
                    const auto& entry = list->entries[static_cast<std::size_t>(current.activeListEntry)];
                    if (staged.hasCombi({entry.combiBank, entry.combiPage, entry.combiSlot})) {
                        listAddress = current.activeListAddress;
                        listEntry = current.activeListEntry;
                    }
                }
            }
        } else {
            // Legacy SETs have no open snapshot: recall the first valid LIST
            // blend (or stored COMBI), never the unrelated previously open one.
            bool found = false;
            for (const auto& saved : data.lists) {
                for (std::size_t i = 0U; i < saved.list.entries.size(); ++i) {
                    const auto& entry = saved.list.entries[i];
                    const auto combi = staged.combi({entry.combiBank, entry.combiPage, entry.combiSlot});
                    if (!combi) continue;
                    next->combi = *combi;
                    listAddress = saved.address;
                    listEntry = static_cast<int>(i);
                    found = true;
                    break;
                }
                if (found) break;
            }
            if (!found && !data.combis.empty()) {
                next->combi = data.combis.front().combi;
            } else if (!found) {
                next->combi.name = "EMPTY";
                for (int i = 0; i < kPartCount; ++i) next->combi.part(i).enabled = false;
            }
        }
        const std::string missing = rebindPerformanceCombi(next->combi, bankSounds);
        staged.setGlobal(next->global);
        if (!installState(std::move(next), edited ? Mark::Edit : Mark::Clean)) return false;
        library_ = std::move(staged);
        activeListAddress_ = listAddress;
        activeListEntry_ = listEntry;
        lastLoadedSetExtra_ = data.extra;
        pendingSetExtra_ = data.extra;
        {
            std::lock_guard<std::mutex> lock(missingMutex_);
            lastRecallMissing_ = missing;
        }
        setTextError({});
        return true;
    }

    bool saveBank(const std::string& path, int bank) {
        if (bank < 0 || bank > 65535) { setTextError("Bank number is out of range"); return false; }
        syncCurrentStateToLibrary();
        const auto bankData = library_.snapshotBank(static_cast<std::uint16_t>(bank));
        if (bankData.programs.empty() && bankData.combis.empty() && bankData.lists.empty()) {
            setTextError("Selected bank is empty");
            return false;
        }
        const auto saved = SetPackage::save(path, bankData);
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool loadBank(const std::string& path, int targetBank, bool overwrite) {
        if (targetBank < 0 || targetBank > 65535) { setTextError("Target bank is out of range"); return false; }
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        const auto merged = library_.mergeBank(loaded.data, static_cast<std::uint16_t>(targetBank), overwrite);
        if (!merged.success) { setTextError(merged.error); return false; }
        setTextError({});
        return true;
    }

    bool writeCurrentProgram(const SlotAddress& address, int upperIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Program");
            return false;
        }
        const auto& source = state_->combi.part(upperIndex).program;
        if (source == nullptr) { setTextError("Selected Upper has no PROGRAM"); return false; }
        auto copy = std::make_shared<Program>(*source);
        copy->name = name.empty() ? source->name : name;
        if (!library_.writeProgram(address, copy)) { setTextError("Write Program failed"); return false; }
        setTextError({});
        return true;
    }

    bool updateProgramBasic(const SlotAddress& address, bool mono, bool legato, float portamentoSec) {
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateBasic(source, mono, legato, portamentoSec));
    }

    bool addProgramLayer(const SlotAddress& address, std::uint32_t multisampleId, const std::string& name) {
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        const auto ms = library_.multisample(multisampleId);
        if (ms == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::addLayer(source, name, ms));
    }

    bool removeProgramLayer(const SlotAddress& address, int layerIndex) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::removeLayer(source, static_cast<std::size_t>(layerIndex)));
    }

    bool moveProgramLayer(const SlotAddress& address, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::moveLayer(source, static_cast<std::size_t>(fromIndex), static_cast<std::size_t>(toIndex)));
    }

    bool assignProgramMultisample(const SlotAddress& address, int layerIndex, std::uint32_t multisampleId) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        const auto ms = library_.multisample(multisampleId);
        if (ms == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::assignMultisample(source, static_cast<std::size_t>(layerIndex), ms));
    }

    bool updateProgramLayerBasic(const SlotAddress& address, int layerIndex, bool enabled,
                                 int keyLow, int keyHigh, int velocityLow, int velocityHigh,
                                 int velocityFadeIn, int velocityFadeOut, int transposeSemitones,
                                 float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerBasic(
            source, static_cast<std::size_t>(layerIndex), enabled, keyLow, keyHigh, velocityLow, velocityHigh,
            velocityFadeIn, velocityFadeOut, transposeSemitones, tuneCents, levelDb, pan, delaySec, damperEnabled));
    }

    bool updateProgramAmpEnvelope(const SlotAddress& address, int layerIndex,
                                  float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerAmpEnvelope(
            source, static_cast<std::size_t>(layerIndex), EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramPitch(const SlotAddress& address, int layerIndex, float amountCents,
                            float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerPitch(
            source, static_cast<std::size_t>(layerIndex), amountCents, EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramFilter(const SlotAddress& address, int layerIndex, int mode,
                             float cutoffHz, float resonance, float keyTrack, float velocityAmount,
                             float envelopeAmount, float lfoAmount,
                             float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        if (mode < static_cast<int>(FilterMode::LowPass) || mode > static_cast<int>(FilterMode::Bypass)) {
            setTextError("PROGRAM FILTER mode is invalid"); return false;
        }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        FilterParams filter{};
        filter.mode = static_cast<FilterMode>(mode);
        filter.cutoffHz = cutoffHz;
        filter.resonance = resonance;
        filter.keyTrack = keyTrack;
        filter.velocityAmount = velocityAmount;
        filter.envelopeAmount = envelopeAmount;
        filter.lfoAmount = lfoAmount;
        return commitProgramEdit(address, source, ProgramEditor::updateLayerFilter(
            source, static_cast<std::size_t>(layerIndex), filter, EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramLfo(const SlotAddress& address, int layerIndex, int lfoIndex, int wave,
                          float frequencyHz, float delaySec, float fadeSec, bool keySync,
                          float pitchCents, float filterOctaves, float ampDepth) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        if (wave < static_cast<int>(LfoWave::Sine) || wave > static_cast<int>(LfoWave::RandomHold)) {
            setTextError("PROGRAM LFO waveform is invalid"); return false;
        }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        LfoParams lfo{};
        lfo.wave = static_cast<LfoWave>(wave);
        lfo.frequencyHz = frequencyHz;
        lfo.delaySec = delaySec;
        lfo.fadeSec = fadeSec;
        lfo.keySync = keySync;
        lfo.pitchCents = pitchCents;
        lfo.filterOctaves = filterOctaves;
        lfo.ampDepth = ampDepth;
        return commitProgramEdit(address, source, ProgramEditor::updateLayerLfo(
            source, static_cast<std::size_t>(layerIndex), lfoIndex, lfo));
    }

    bool writeCurrentSample(std::uint32_t id, int upperIndex, int layerIndex, int zoneIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Sample"); return false;
        }
        const auto& program = state_->combi.part(upperIndex).program;
        if (program == nullptr || layerIndex < 0 || static_cast<std::size_t>(layerIndex) >= program->layers.size()) {
            setTextError("Selected PROGRAM layer is invalid"); return false;
        }
        const auto& ms = program->layers[static_cast<std::size_t>(layerIndex)].multisample;
        if (ms == nullptr || zoneIndex < 0 || static_cast<std::size_t>(zoneIndex) >= ms->zones.size() || ms->zones[static_cast<std::size_t>(zoneIndex)].sample == nullptr) {
            setTextError("Selected MULTISAMPLE zone has no SAMPLE"); return false;
        }
        const auto source = ms->zones[static_cast<std::size_t>(zoneIndex)].sample;
        auto edited = SampleEditor::updateMetadata(*source, name.empty() ? source->name : name, source->rootKey, source->fineTuneCents);
        if (!edited.ok() || !library_.writeSample(id, edited.sample)) { setTextError(edited.error.empty() ? "Write Sample failed" : edited.error); return false; }
        setTextError({}); return true;
    }

    bool updateSampleMetadata(std::uint32_t id, const std::string& name, int rootKey, float fineTuneCents) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::updateMetadata(*source, name, static_cast<std::uint8_t>(std::clamp(rootKey,0,127)), fineTuneCents));
    }
    bool trimSample(std::uint32_t id, std::uint64_t startFrame, std::uint64_t endFrame) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::trim(*source, startFrame, endFrame));
    }
    bool normalizeSample(std::uint32_t id, float targetPeakDb) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::normalize(*source, targetPeakDb));
    }
    bool reverseSample(std::uint32_t id) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::reverse(*source));
    }
    bool fadeSample(std::uint32_t id, std::uint64_t fadeInFrames, std::uint64_t fadeOutFrames) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::fade(*source, fadeInFrames, fadeOutFrames));
    }
    bool setSampleLoop(std::uint32_t id, std::uint64_t startFrame, std::uint64_t endFrame, std::uint32_t crossfadeFrames) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::setLoop(*source, startFrame, endFrame, crossfadeFrames));
    }
    bool clearSampleLoop(std::uint32_t id) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::clearLoop(*source));
    }
    std::int64_t sampleNearestZeroCrossing(std::uint32_t id, std::uint64_t aroundFrame, std::uint64_t radius) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return -1; }
        setTextError({}); return static_cast<std::int64_t>(SampleEditor::nearestZeroCrossing(*source, aroundFrame, radius));
    }

    bool renameMultisample(std::uint32_t id, const std::string& name) {
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitMultisampleEdit(id, source, MultisampleEditor::rename(source, name));
    }
    bool addMultisampleZone(std::uint32_t id, std::uint32_t sampleId, int insertIndex,
                            int keyLow, int keyHigh, int velocityLow, int velocityHigh, int rootKey,
                            int transpose, float tuneCents, float gainDb, float pan,
                            bool oneShot, bool reverse, bool nonTranspose) {
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        const auto sample = library_.sample(sampleId); if (sample == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        SampleZone z{}; z.sample=sample; z.keyLow=static_cast<std::uint8_t>(std::clamp(keyLow,0,127)); z.keyHigh=static_cast<std::uint8_t>(std::clamp(keyHigh,0,127));
        z.velocityLow=static_cast<std::uint8_t>(std::clamp(velocityLow,1,127)); z.velocityHigh=static_cast<std::uint8_t>(std::clamp(velocityHigh,1,127)); z.rootKey=static_cast<std::uint8_t>(std::clamp(rootKey,0,127));
        z.transposeSemitones=static_cast<std::int8_t>(std::clamp(transpose,-64,63)); z.tuneCents=tuneCents; z.gainDb=gainDb; z.pan=pan; z.oneShot=oneShot; z.reverse=reverse; z.nonTranspose=nonTranspose;
        const auto result = insertIndex < 0 ? MultisampleEditor::addZone(source,z) : MultisampleEditor::insertZone(source,static_cast<std::size_t>(insertIndex),z);
        return commitMultisampleEdit(id, source, result);
    }
    bool updateMultisampleZone(std::uint32_t id, int zoneIndex, std::uint32_t sampleId,
                               int keyLow, int keyHigh, int velocityLow, int velocityHigh, int rootKey,
                               int transpose, float tuneCents, float gainDb, float pan,
                               bool oneShot, bool reverse, bool nonTranspose) {
        if (zoneIndex < 0) { setTextError("Zone index is out of range"); return false; }
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        const auto sample = library_.sample(sampleId); if (sample == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        SampleZone z{}; z.sample=sample; z.keyLow=static_cast<std::uint8_t>(std::clamp(keyLow,0,127)); z.keyHigh=static_cast<std::uint8_t>(std::clamp(keyHigh,0,127));
        z.velocityLow=static_cast<std::uint8_t>(std::clamp(velocityLow,1,127)); z.velocityHigh=static_cast<std::uint8_t>(std::clamp(velocityHigh,1,127)); z.rootKey=static_cast<std::uint8_t>(std::clamp(rootKey,0,127));
        z.transposeSemitones=static_cast<std::int8_t>(std::clamp(transpose,-64,63)); z.tuneCents=tuneCents; z.gainDb=gainDb; z.pan=pan; z.oneShot=oneShot; z.reverse=reverse; z.nonTranspose=nonTranspose;
        return commitMultisampleEdit(id, source, MultisampleEditor::updateZone(source,static_cast<std::size_t>(zoneIndex),z));
    }
    bool removeMultisampleZone(std::uint32_t id, int zoneIndex) {
        if (zoneIndex < 0) { setTextError("Zone index is out of range"); return false; }
        const auto source=library_.multisample(id); if(source==nullptr){setTextError("MULTISAMPLE id is not available");return false;}
        return commitMultisampleEdit(id,source,MultisampleEditor::removeZone(source,static_cast<std::size_t>(zoneIndex)));
    }
    bool moveMultisampleZone(std::uint32_t id, int fromIndex, int toIndex) {
        if(fromIndex<0||toIndex<0){setTextError("Zone index is out of range");return false;}
        const auto source=library_.multisample(id); if(source==nullptr){setTextError("MULTISAMPLE id is not available");return false;}
        return commitMultisampleEdit(id,source,MultisampleEditor::moveZone(source,static_cast<std::size_t>(fromIndex),static_cast<std::size_t>(toIndex)));
    }

    bool writeCurrentMultisample(std::uint32_t id, int upperIndex, int layerIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Multisample");
            return false;
        }
        const auto& program = state_->combi.part(upperIndex).program;
        if (program == nullptr || layerIndex < 0 || static_cast<std::size_t>(layerIndex) >= program->layers.size()) {
            setTextError("Selected PROGRAM layer has no MULTISAMPLE");
            return false;
        }
        const auto& source = program->layers[static_cast<std::size_t>(layerIndex)].multisample;
        if (source == nullptr) { setTextError("Selected PROGRAM layer has no MULTISAMPLE"); return false; }
        auto copy = std::make_shared<Multisample>(*source);
        if (!name.empty()) copy->name = name;
        if (!library_.writeMultisample(id, copy)) { setTextError("Write Multisample failed"); return false; }
        setTextError({});
        return true;
    }

#include "../PerformanceCheckpointHost.inc"
#include "../KeyboardPerformanceHost.inc"

    bool writeCurrentCombi(const SlotAddress& address, const std::string& name) {
        if (state_ == nullptr) { setTextError("No active COMBI"); return false; }
        Combi copy = state_->combi;
        if (!copy.scale.stored) {
            copy.scale.stored = true;
            copy.scale.enabled = true;
            copy.scale.targets = static_cast<std::uint16_t>(scaleTargets_.load(std::memory_order_acquire));
            for (int pc = 0; pc < 12; ++pc) copy.scale.cents[static_cast<std::size_t>(pc)] =
                state_->global.scaleOffsetsCents[static_cast<std::size_t>((pc - state_->global.scaleRoot + 12) % 12)];
        }
        if (!name.empty()) copy.name = name;
        if (!library_.writeCombi(address, copy)) { setTextError("Write Combi failed"); return false; }
        blendEdited_.store(false, std::memory_order_release);   // SILVETON_SAVEQ_V1: what is open is now what is stored
        setTextError({});
        return true;
    }

    bool updateUpperMain(int upperIndex, bool enabled, bool solo, bool mute,
                         float levelDb, float pan, int keyLow, int keyHigh, int voiceMode) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        if (keyLow < 0 || keyLow > 127 || keyHigh < 0 || keyHigh > 127 || keyLow > keyHigh) { setTextError("Invalid Upper key range"); return false; }
        if (voiceMode < static_cast<int>(UpperVoiceMode::Poly) || voiceMode > static_cast<int>(UpperVoiceMode::Legato)) { setTextError("Invalid Upper voice mode"); return false; }
        if (!std::isfinite(levelDb) || !std::isfinite(pan)) { setTextError("Upper level / pan is not finite"); return false; }   // SILVETON_SET_FINITE_V1
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        // SILVETON_SAVEQ_V1: MUTE and SOLO are handled live while playing - alone they do not count as a change of the BLEND
        const bool realChange = u.enabled != enabled || u.levelDb != std::clamp(levelDb, -60.0F, 18.0F) || u.pan != std::clamp(pan, -1.0F, 1.0F)
            || static_cast<int>(u.keyLow) != keyLow || static_cast<int>(u.keyHigh) != keyHigh || static_cast<int>(u.voiceMode) != voiceMode;
        u.enabled = enabled;
        u.solo = solo;
        u.mute = mute;
        u.levelDb = std::clamp(levelDb, -60.0F, 18.0F);
        u.pan = std::clamp(pan, -1.0F, 1.0F);
        u.keyLow = static_cast<std::uint8_t>(keyLow);
        u.keyHigh = static_cast<std::uint8_t>(keyHigh);
        if (u.voiceMode != static_cast<UpperVoiceMode>(voiceMode)) u.sourceVoiceInherit = false;
        u.voiceMode = static_cast<UpperVoiceMode>(voiceMode);
        return installState(std::move(next), realChange ? Mark::Edit : Mark::Keep);
    }

    bool updateUpperTune(int upperIndex, int octave, int transpose, float fineCents,
                         int pitchBendRange, float portamentoSec) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        if (!std::isfinite(fineCents) || !std::isfinite(portamentoSec)) { setTextError("Upper tune is not finite"); return false; }   // SILVETON_SET_FINITE_V1
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        u.octave = static_cast<std::int8_t>(std::clamp(octave, -4, 4));
        // SILVETON_TUNE_RANGES_V1: TRANSPOSE -12..+12, FINE TUNE -1200..+1200 cents.
        u.transposeSemitones = static_cast<std::int8_t>(std::clamp(transpose, -12, 12));
        u.tuneCents = std::clamp(fineCents, -1200.0F, 1200.0F);
        u.pitchBendRange = static_cast<std::int8_t>(std::clamp(pitchBendRange, 0, 24));
        if (u.portamentoSec != std::clamp(portamentoSec, 0.0F, 0.1F)) u.sourcePortamentoInherit = false;
        u.portamentoSec = std::clamp(portamentoSec, 0.0F, 0.1F); // TIME 1..100 ms like the SILVETON keyboard processor
        return installState(std::move(next));
    }

    bool updateUpperRange(int upperIndex, int velocityLow, int velocityHigh) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        if (velocityLow < 1 || velocityLow > 127 || velocityHigh < 1 || velocityHigh > 127 || velocityLow > velocityHigh) { setTextError("Invalid Upper velocity range"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        u.velocityLow = static_cast<std::uint8_t>(velocityLow);
        u.velocityHigh = static_cast<std::uint8_t>(velocityHigh);
        return installState(std::move(next));
    }

    bool updateUpperControl(int upperIndex, bool breath, bool expression, bool aftertouch,
                            bool damper, int midiChannel) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        if (midiChannel < 0 || midiChannel > 15) { setTextError("Invalid Upper MIDI channel"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        u.breathEnabled = breath;
        u.expressionEnabled = expression;
        u.aftertouchEnabled = aftertouch;
        u.damperEnabled = damper;
        u.midiChannel = static_cast<std::uint8_t>(midiChannel);
        return installState(std::move(next));
    }

    bool updateUpperTone(int upperIndex, float ampAttackScale, float ampDecayScale,
                         float ampSustainScale, float ampReleaseScale,
                         float filterCutoffOctaves, float filterResonanceOffset,
                         float lfoRateScale, float lfoDepthScale,
                         float eqLowDb, float eqMidDb, float eqHighDb) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        const float values[] = {ampAttackScale, ampDecayScale, ampSustainScale, ampReleaseScale,
                                filterCutoffOctaves, filterResonanceOffset, lfoRateScale, lfoDepthScale,
                                eqLowDb, eqMidDb, eqHighDb};
        for (float v : values) if (!std::isfinite(v)) { setTextError("Upper TONE contains non-finite value"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        u.ampAttackScale = std::clamp(ampAttackScale, 0.0F, 16.0F);
        u.ampDecayScale = std::clamp(ampDecayScale, 0.0F, 16.0F);
        u.ampSustainScale = std::clamp(ampSustainScale, 0.0F, 2.0F);
        u.ampReleaseScale = std::clamp(ampReleaseScale, 0.0F, 16.0F);
        u.filterCutoffOctaves = std::clamp(filterCutoffOctaves, -10.0F, 10.0F);
        u.filterResonanceOffset = std::clamp(filterResonanceOffset, -1.0F, 1.0F);
        u.lfoRateScale = std::clamp(lfoRateScale, 0.0F, 16.0F);
        u.lfoDepthScale = std::clamp(lfoDepthScale, 0.0F, 8.0F);
        u.eqLowDb = std::clamp(eqLowDb, -18.0F, 18.0F);
        u.eqMidDb = std::clamp(eqMidDb, -18.0F, 18.0F);
        u.eqHighDb = std::clamp(eqHighDb, -18.0F, 18.0F);
        // SILVETON_EQ5_V1: LOW / MID / HIGH are bands 1 / 3 / 5 of the common EQ
        u.eq.band[0].gainDb = u.eqLowDb; u.eq.band[2].gainDb = u.eqMidDb; u.eq.band[4].gainDb = u.eqHighDb;
        return installState(std::move(next));
    }

    // TONE page: 0 attack ms, 1 decay ms, 2 sustain 0..1, 3 release ms, 4 cutoff Hz, 5 resonance 0..1.
    // A negative value clears the setting (the PROGRAM default is used again).
    bool setUpperToneParam(int upperIndex, int param, float value) {
        if (upperIndex < 0 || upperIndex >= kPartCount || param < 0 || param > 5) { setTextError("Invalid TONE parameter"); return false; }
        if (!std::isfinite(value)) { setTextError("TONE value is not finite"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        const float v = value < 0.0F ? -1.0F : value;
        switch (param) {
            case 0: u.toneAttackMs = v < 0.0F ? v : std::min(v, kToneMaxTimeMs); break;
            case 1: u.toneDecayMs = v < 0.0F ? v : std::min(v, kToneMaxTimeMs); break;
            case 2: u.toneSustain = v < 0.0F ? v : std::min(v, 1.0F); break;
            case 3: u.toneReleaseMs = v < 0.0F ? v : std::min(v, kToneMaxTimeMs); break;
            case 4: u.toneCutoffHz = v < 0.0F ? v : std::clamp(v, 20.0F, kToneCutoffOpenHz); break;
            default: u.toneResonance = v < 0.0F ? v : std::min(v, 1.0F); break;
        }
        return installState(std::move(next));
    }


    // ---------------------------------------------------------------- SILVETON_PARAMS_V1
    // Generic access to the new Upper settings (one id, one value), so every
    // page talks to the engine the same way. Ids of setUpperParam / upperParams:
    //   0..14  TONE of the basic sound: startMs, endMs, filterEnvOct, filterEnvMs, velToLevel, velToCutoff,
    //          highPassHz, lfoRateHz, lfoDepthCents, lfoDelayMs, lfoFadeMs, lfoModWheel, eqLow, eqMid, eqHigh
    //   15     EQ on; 16..35 bands 1..5 x (on, freq, gain, q); 36 hpOn 37 hpHz 38 hpSlope 39 lpOn 40 lpHz 41 lpSlope
    //   42 portaMode (0 SILVETON 1 KRONOS 2 INSTRUMENT 3 BASS) 43 fingered 44 rateMode 45 portaTime 0..127
    //   46 fxSend3 47 fxSend4 48 pitchBendRange
    //   50 velocityFadeIn 51 velocityFadeOut 52 velocityResponse 53 oscillatorMode 54 independentLayerRanges
    //   SILVETON_VELOCITY_V1 (the basic sound): 55 curve 0..6, 56..64 the nine points of the CUSTOM curve 0..127,
    //          65 compress -1..1, 66 velocity->attack 0..1, 67 crossfade on / off
    //   SILVETON_OFS_V1: 68..71 OFS of the velocity layers MS1..MS4 of the basic sound (ms, -1 = as START)
    static constexpr int kUpperParamCount = 72;   // SILVETON_EVEN_DECAY_LIVE_V1: 49 = ЗАТИХВАНЕ ms (0 = off)

    // SILVETON_VELOCITY_V1: the ids of a VelocityShape, counted from its first id (curve); the same order for the Upper and for a layer
    static bool applyVelocityShape(VelocityShape& s, int k, float v) {
        if (k == 0) s.curve = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(v)), 0, kVelocityCurveTypes - 1));
        else if (k >= 1 && k <= kVelocityCustomPoints) s.custom[static_cast<std::size_t>(k - 1)] = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(v)), 0, 127));
        else if (k == kVelocityCustomPoints + 1) s.compress = std::clamp(v, -1.0F, 1.0F);
        else if (k == kVelocityCustomPoints + 2) s.toAttack = std::clamp(v, 0.0F, 1.0F);
        else if (k == kVelocityCustomPoints + 3) s.crossfade = v >= 0.5F;
        else return false;
        return true;
    }
    static void readVelocityShape(const VelocityShape& s, std::vector<float>& out) {
        out.push_back(static_cast<float>(s.curve));
        for (const auto p : s.custom) out.push_back(static_cast<float>(p));
        out.insert(out.end(), {s.compress, s.toAttack, s.crossfade ? 1.0F : 0.0F});
    }

    static void applyToneExtra(ToneExtra& x, int id, float v) {
        switch (id) {
            case 0: x.startMs = std::clamp(v, 0.0F, kToneMaxStartMs); break;
            case 1: x.endMs = std::clamp(v, 0.0F, 600000.0F); break;
            case 2: x.filterEnvOctaves = std::clamp(v, -8.0F, 8.0F); break;
            case 3: x.filterEnvMs = std::clamp(v, 1.0F, 20000.0F); break;
            case 4: x.velToLevel = std::clamp(v, 0.0F, 1.0F); break;
            case 5: x.velToCutoff = std::clamp(v, 0.0F, 8.0F); break;
            case 6: x.highPassHz = std::clamp(v, 0.0F, 4000.0F); break;
            case 7: x.lfoRateHz = std::clamp(v, 0.1F, 20.0F); break;
            case 8: x.lfoDepthCents = std::clamp(v, 0.0F, 1200.0F); break;
            case 9: x.lfoDelayMs = std::clamp(v, 0.0F, 10000.0F); break;
            case 10: x.lfoFadeMs = std::clamp(v, 0.0F, 10000.0F); break;
            case 11: x.lfoModWheel = v >= 0.5F; break;
            case 12: x.eqLowDb = std::clamp(v, -18.0F, 18.0F); break;
            case 13: x.eqMidDb = std::clamp(v, -18.0F, 18.0F); break;
            case 14: x.eqHighDb = std::clamp(v, -18.0F, 18.0F); break;
            default: break;
        }
    }
    static void readToneExtra(const ToneExtra& x, std::vector<float>& out) {
        out.insert(out.end(), {x.startMs, x.endMs, x.filterEnvOctaves, x.filterEnvMs, x.velToLevel, x.velToCutoff, x.highPassHz,
                               x.lfoRateHz, x.lfoDepthCents, x.lfoDelayMs, x.lfoFadeMs, x.lfoModWheel ? 1.0F : 0.0F, x.eqLowDb, x.eqMidDb, x.eqHighDb});
    }

    bool setUpperParam(int upperIndex, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kPartCount || id < 0 || id >= kUpperParamCount || !std::isfinite(v)) { setTextError("Invalid Upper parameter"); return false; }
        if ((id == 46 || id == 47) && state_ &&
                (!state_->combi.sourceEffects || !state_->combi.sourceEffects->style)) {
            const auto& current = state_->combi.part(upperIndex);
            const float send = std::clamp(v, 0.0F, 1.0F);
            if ((id == 46 ? current.fxSend3 : current.fxSend4) == send) return true;
        }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        if (id <= 14) applyToneExtra(u.toneExtra, id, v);
        else if (id == 15) u.eq.on = v >= 0.5F;
        else if (id <= 35) {
            auto& b = u.eq.band[static_cast<std::size_t>((id - 16) / 4)];
            switch ((id - 16) % 4) {
                case 0: b.on = v >= 0.5F; break;
                case 1: b.freqHz = std::clamp(v, 20.0F, 20000.0F); break;
                case 2: b.gainDb = std::clamp(v, -18.0F, 18.0F); break;
                default: b.q = std::clamp(v, 0.1F, 10.0F); break;
            }
            u.eqLowDb = u.eq.band[0].gainDb; u.eqMidDb = u.eq.band[2].gainDb; u.eqHighDb = u.eq.band[4].gainDb;
        }
        else if (id == 36) u.eq.hpOn = v >= 0.5F;
        else if (id == 37) u.eq.hpHz = std::clamp(v, 10.0F, 2000.0F);
        else if (id == 38) u.eq.hpSlopeDb = v >= 18.0F ? 24U : 12U;
        else if (id == 39) u.eq.lpOn = v >= 0.5F;
        else if (id == 40) u.eq.lpHz = std::clamp(v, 1000.0F, 20000.0F);
        else if (id == 41) u.eq.lpSlopeDb = v >= 18.0F ? 24U : 12U;
        else if (id == 42) { const int x=std::clamp(static_cast<int>(std::lround(v)),0,3);u.sourcePortamentoInherit=false;u.portaMode=static_cast<PortamentoMode>(x); }
        else if (id == 43) { u.sourcePortamentoInherit=false;u.portaFingered = v >= 0.5F; }
        else if (id == 44) { u.sourcePortamentoInherit=false;u.portaRateMode = v >= 0.5F; }
        else if (id == 45) { u.sourcePortamentoInherit=false;u.portaTime = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(v)), 0, 127)); }
        else if (id == 46) u.fxSend3 = std::clamp(v, 0.0F, 1.0F);
        else if (id == 47) u.fxSend4 = std::clamp(v, 0.0F, 1.0F);
        else if (id == 48) u.pitchBendRange = static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(v)), 0, 24));
        else if (id == 49) u.evenDecayMs = v >= 30.0F ? std::min(v, 10000.0F) : 0.0F;   // SILVETON_EVEN_DECAY_LIVE_V1
        else if (id == 50) u.velocityFadeIn = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(v)),0,127));
        else if (id == 51) u.velocityFadeOut = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(v)),0,127));
        else if (id == 52) u.velocityResponse = std::clamp(v,0.25F,4.0F);
        else if (id == 53) u.oscillatorMode = static_cast<OscillatorMode>(std::clamp(static_cast<int>(std::lround(v)),0,6));
        else if (id == 54) u.independentLayerRanges = v>=0.5F;
        else if (id >= 68) u.toneExtra.zoneStartMs[static_cast<std::size_t>(id - 68)] = v < 0.0F ? -1.0F : std::min(v, kToneMaxStartMs);   // SILVETON_OFS_V1
        else if (id >= 55) applyVelocityShape(u.velocityShape, id - 55, v);
        // Keyboard sends belong to the part; editing their levels must
        // retain its original shared FX rack. Style MIDI sends keep
        // their existing separate ownership policy.
        if ((id == 46 || id == 47) && next->combi.sourceEffects &&
                next->combi.sourceEffects->style) next->combi.sourceEffects.reset();
        return installState(std::move(next));
    }

    std::vector<float> upperParams(int upperIndex) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) return out;
        const auto& u = state_->combi.part(upperIndex);
        readToneExtra(u.toneExtra, out);
        out.push_back(u.eq.on ? 1.0F : 0.0F);
        for (const auto& b : u.eq.band) out.insert(out.end(), {b.on ? 1.0F : 0.0F, b.freqHz, b.gainDb, b.q});
        out.insert(out.end(), {u.eq.hpOn ? 1.0F : 0.0F, u.eq.hpHz, static_cast<float>(u.eq.hpSlopeDb), u.eq.lpOn ? 1.0F : 0.0F, u.eq.lpHz, static_cast<float>(u.eq.lpSlopeDb)});
        out.insert(out.end(), {static_cast<float>(static_cast<std::uint8_t>(u.portaMode)), u.portaFingered ? 1.0F : 0.0F, u.portaRateMode ? 1.0F : 0.0F, static_cast<float>(u.portaTime)});
        out.insert(out.end(), {u.fxSend3, u.fxSend4, static_cast<float>(u.pitchBendRange)});
        out.push_back(u.evenDecayMs);   // 49: SILVETON_EVEN_DECAY_LIVE_V1
        out.insert(out.end(), {static_cast<float>(u.velocityFadeIn),static_cast<float>(u.velocityFadeOut),u.velocityResponse,static_cast<float>(static_cast<std::uint8_t>(u.oscillatorMode)),u.independentLayerRanges?1.0F:0.0F});
        readVelocityShape(u.velocityShape, out);   // 55..67
        for (const float z : u.toneExtra.zoneStartMs) out.push_back(z);   // 68..71 SILVETON_OFS_V1
        return out;
    }

    // SILVETON_LAYERS_V1. Ids of setLayerParam / layerParams (layer 0..3):
    //   0 enabled 1 levelDb 2 pan 3 transpose 4 octave 5 tuneCents 6 keyLow 7 keyHigh 8 velLow 9 velHigh
    //   10..15 TONE attackMs decayMs sustain releaseMs cutoffHz resonance (-1 = PROGRAM default)
    //   16..30 TONE extra (same order as the Upper ids 0..14)
    //   31 = soundSlotId (only read; the SOUND of a layer is set with setLayerSound), 32 velocityFadeIn 33 velocityFadeOut 34 velocityResponse
    //   SILVETON_VELOCITY_V1: 35 curve 0..6, 36..44 the nine points of the CUSTOM curve, 45 compress, 46 velocity->attack, 47 crossfade
    //   (the id of a value is the same in setLayerParam and in layerParams)
    //   SILVETON_OFS_V1: 48..51 OFS of the velocity layers MS1..MS4 of the layer's sound (ms, -1 = as START)
    static constexpr int kLayerParamCount = 52;

    bool setLayerParam(int upperIndex, int layer, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kPartCount || layer < 0 || layer >= kUpperLayers || id < 0 || id >= kLayerParamCount || !std::isfinite(v)) { setTextError("Invalid layer parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& l = next->combi.part(upperIndex).layers[static_cast<std::size_t>(layer)];
        const auto i8 = [](float x, int lo, int hi) { return static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(x)), lo, hi)); };
        const auto u8 = [](float x, int lo, int hi) { return static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(x)), lo, hi)); };
        const auto tone = [](float x, float hi) { return x < 0.0F ? -1.0F : std::min(x, hi); };
        switch (id) {
            case 0: l.enabled = v >= 0.5F; break;
            case 1: l.levelDb = std::clamp(v, -60.0F, 12.0F); break;
            case 2: l.pan = std::clamp(v, -1.0F, 1.0F); break;
            case 3: l.transposeSemitones = i8(v, -12, 12); break;
            case 4: l.octave = i8(v, -3, 3); break;
            case 5: l.tuneCents = std::clamp(v, -1200.0F, 1200.0F); break;
            case 6: l.keyLow = u8(v, 0, 127); break;
            case 7: l.keyHigh = u8(v, 0, 127); break;
            case 8: l.velocityLow = u8(v, 1, 127); break;
            case 9: l.velocityHigh = u8(v, 1, 127); break;
            case 10: l.tone.attackMs = tone(v, kToneMaxTimeMs); break;
            case 11: l.tone.decayMs = tone(v, kToneMaxTimeMs); break;
            case 12: l.tone.sustain = tone(v, 1.0F); break;
            case 13: l.tone.releaseMs = tone(v, kToneMaxTimeMs); break;
            case 14: l.tone.cutoffHz = v < 0.0F ? -1.0F : std::clamp(v, 20.0F, kToneCutoffOpenHz); break;
            case 15: l.tone.resonance = tone(v, 1.0F); break;
            case 31: break;   // the SOUND slot: only read
            case 32: l.velocityFadeIn = u8(v,0,127); break;
            case 33: l.velocityFadeOut = u8(v,0,127); break;
            case 34: l.velocityResponse = std::clamp(v,0.25F,4.0F); break;
            case 48: case 49: case 50: case 51: l.tone.x.zoneStartMs[static_cast<std::size_t>(id - 48)] = v < 0.0F ? -1.0F : std::min(v, kToneMaxStartMs); break;   // SILVETON_OFS_V1
            default:
                if (id >= 35) applyVelocityShape(l.velocityShape, id - 35, v);
                else applyToneExtra(l.tone.x, id - 16, v);
                break;
        }
        return installState(std::move(next));
    }

    // The SOUND of a layer: 1..500 = bank SOUND, 0 = none (the layer is turned off).


    std::vector<float> layerParams(int upperIndex, int layer) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kPartCount || layer < 0 || layer >= kUpperLayers || state_ == nullptr) return out;
        const auto& l = state_->combi.part(upperIndex).layers[static_cast<std::size_t>(layer)];
        out.insert(out.end(), {l.enabled ? 1.0F : 0.0F, l.levelDb, l.pan, static_cast<float>(l.transposeSemitones), static_cast<float>(l.octave), l.tuneCents,
                               static_cast<float>(l.keyLow), static_cast<float>(l.keyHigh), static_cast<float>(l.velocityLow), static_cast<float>(l.velocityHigh),
                               l.tone.attackMs, l.tone.decayMs, l.tone.sustain, l.tone.releaseMs, l.tone.cutoffHz, l.tone.resonance});
        readToneExtra(l.tone.x, out);
        out.push_back(static_cast<float>(l.soundSlotId));
        out.insert(out.end(), {static_cast<float>(l.velocityFadeIn),static_cast<float>(l.velocityFadeOut),l.velocityResponse});
        readVelocityShape(l.velocityShape, out);   // 35..47
        for (const float z : l.tone.x.zoneStartMs) out.push_back(z);   // 48..51 SILVETON_OFS_V1
        return out;
    }

    // SILVETON_LAYER_MOVE_V1: the SOUND (1..500, or a built-in one) of the basic place of an Upper; 0 = none. (Read only; upperParams is not changed.)
    int upperSoundSlot(int upperIndex) const {
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) return 0;
        const auto& u = state_->combi.part(upperIndex);
        return u.program != nullptr ? static_cast<int>(u.soundSlotId) : 0;
    }

    // SILVETON_OFS_V1: the velocity layers of a sound of an Upper (0 = basic, 1..4 = layer): the lowest velocity of each, hardest first
    std::vector<int> soundVelocityZones(int upperIndex, int sound) const {
        if (upperIndex < 0 || upperIndex >= kPartCount || sound < 0 || sound > kUpperLayers || state_ == nullptr) return {};
        const auto& u = state_->combi.part(upperIndex);
        const Program* p = sound == 0 ? u.program.get() : u.layers[static_cast<std::size_t>(sound - 1)].program.get();
        return p != nullptr ? velocityZoneBottoms(*p) : std::vector<int>{};
    }

    std::string layerName(int upperIndex, int layer) const {
        if (upperIndex < 0 || upperIndex >= kPartCount || layer < 0 || layer >= kUpperLayers || state_ == nullptr) return {};
        return state_->combi.part(upperIndex).layers[static_cast<std::size_t>(layer)].name;
    }

    // SILVETON_FX_V3: unit 0..3 = send slot, 4..10 = INSERT of Upper 1..7, 11..18 = INSERT of SILVETON SYNTH place 1..8. Ids:
    //   0 type 1 wet 2 timeMs 3 feedback 4 rateHz 5 depth 6 tone 7 preDelayMs 8 damping 9 size 10 mod
    //   11 tempoSync 12 tempoBpm 13 division 14 param1 15 param2 16 param3
    static constexpr int kFxParamCount = 17;
    static EffectSlot* fxUnitOf(Combi& c, int unit) {
        if (unit >= 0 && unit < kFxSendSlots) return &c.fx[static_cast<std::size_t>(unit)];
        if (unit >= kFxSendSlots && unit < kFxSendSlots + kPartCount) return &c.insertOf(unit - kFxSendSlots);   // SILVETON_PLACE_FX_V1: 4..10 Uppers, 11..18 SILVETON SYNTH places
        return nullptr;
    }
    bool setFxParam(int unit, int id, float v) {
        if (id < 0 || id >= kFxParamCount || !std::isfinite(v)) { setTextError("Invalid FX parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        EffectSlot* f = fxUnitOf(next->combi, unit);
        if (f == nullptr) { setTextError("Invalid FX unit"); return false; }
        // An explicit native master/insert edit makes this owner's rack manual.
        // Keep the prepared slots, but do not restore original FX over the edit.
        next->combi.sourceEffects.reset();
        // This legacy API explicitly edits the native namespace. It must not
        // leave an older numbered assignment hiding the requested native FX.
        f->numbered = {}; f->numberedModulatingPart = -1;
        switch (id) {
            case 0: { const int t = static_cast<int>(std::lround(v)); f->type = (t >= 0 && t < kEffectTypeCount) ? static_cast<EffectType>(t) : EffectType::Off; break; }
            case 1: f->wet = std::clamp(v, 0.0F, 1.0F); break;
            case 2: f->timeMs = std::clamp(v, 0.1F, 2500.0F); break;
            case 3: f->feedback = std::clamp(v, -0.95F, 0.95F); break;
            case 4: f->rateHz = std::clamp(v, 0.02F, 12.0F); break;
            case 5: f->depth = std::clamp(v, 0.0F, 1.0F); break;
            case 6: f->tone = std::clamp(v, 0.0F, 24.0F); break;
            case 7: f->preDelayMs = std::clamp(v, 0.0F, 200.0F); break;
            case 8: f->damping = std::clamp(v, 0.0F, 1.0F); break;
            case 9: f->size = std::clamp(v, 0.0F, 1.0F); break;
            case 10: f->mod = std::clamp(v, 0.0F, 1.0F); break;
            case 11: f->tempoSync = v >= 0.5F; break;
            case 12: f->tempoBpm = std::clamp(v, 30.0F, 300.0F); break;
            case 13: f->division = std::clamp(v, 1.0F / 64.0F, 1.0F); break;
            case 14: f->param1 = std::clamp(v, -60.0F, 60.0F); break;
            case 15: f->param2 = std::clamp(v, -60.0F, 60.0F); break;
            default: f->param3 = std::clamp(v, -60.0F, 10000.0F); break;
        }
        return installState(std::move(next));
    }
    std::vector<float> fxParams(int unit) const {
        std::vector<float> out;
        if (state_ == nullptr) return out;
        Combi c = state_->combi;   // a copy only for the lookup helper
        const EffectSlot* f = fxUnitOf(c, unit);
        if (f == nullptr) return out;
        out = {static_cast<float>(f->type), f->wet, f->timeMs, f->feedback, f->rateHz, f->depth, f->tone, f->preDelayMs, f->damping, f->size, f->mod,
               f->tempoSync ? 1.0F : 0.0F, f->tempoBpm, f->division, f->param1, f->param2, f->param3};
        return out;
    }

    // SILVETON_ANALYZER_V1
    std::vector<float> analyzerFrame(int upper, bool afterEq) {
        if (upper < 0 || upper >= kPartCount) { engine_.setAnalyzerTap(-1, true); return {}; }
        engine_.setAnalyzerTap(upper, afterEq);
        std::vector<float> out(8192U);
        engine_.readAnalyzer(out.data(), out.size());
        return out;
    }


    // ---------------------------------------------------------------- SILVETON_POLYSIX_V1
    // Synth functions of one sound (sound 0 = basic, 1..4 = layer). Ids:
    //   0 pwmWidth 1 pwmDepth 2 pwmRateHz 3 pwmMix 4 subLevel 5 subOctave 6 unisonVoices 7 unisonDetuneCents
    //   8 unisonSpread 9 drive 10 filterType 11 filterKeyTrack 12 filter2Type 13 filter2Hz 14 filter2Res
    //   15 filter2Parallel 16 analogFeel 17 synthBypass (SILVETON_SYNTH_BYPASS_V1: 1 = SYNTH ИЗКЛ); 20 + route*4 + (0 source, 1 target, 2 amount, 3 bipolar), route 0..7
    static constexpr int kSynthParamCount = 52;
    static void applySynth(ToneExtra& x, ModMatrix& m, int id, float v) {
        const auto i8 = [](float f, int lo, int hi) { return static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(f)), lo, hi)); };
        if (id >= 20) {
            const int r = (id - 20) / 4, k = (id - 20) % 4;
            if (r < 0 || r >= kModRoutes) return;
            auto& route = m.route[static_cast<std::size_t>(r)];
            switch (k) {
                case 0: route.source = static_cast<ModSource>(std::clamp(static_cast<int>(std::lround(v)), 0, kModSourceCount - 1)); break;
                case 1: route.target = static_cast<ModTarget>(std::clamp(static_cast<int>(std::lround(v)), 0, kModTargetCount - 1)); break;
                case 2: route.amount = std::clamp(v, -1.0F, 1.0F); break;
                default: route.bipolar = v >= 0.5F; break;
            }
            return;
        }
        switch (id) {
            case 0: x.pwmWidth = v < 0.02F ? 0.0F : std::clamp(v, 0.02F, 0.98F); break;
            case 1: x.pwmDepth = std::clamp(v, 0.0F, 0.45F); break;
            case 2: x.pwmRateHz = std::clamp(v, 0.02F, 20.0F); break;
            case 3: x.pwmMix = std::clamp(v, 0.0F, 1.0F); break;
            case 4: x.subLevel = std::clamp(v, 0.0F, 1.0F); break;
            case 5: x.subOctave = i8(v, 1, 2); break;
            case 6: x.unisonVoices = i8(v, 1, 4); break;
            case 7: x.unisonDetuneCents = std::clamp(v, 0.0F, 100.0F); break;
            case 8: x.unisonSpread = std::clamp(v, 0.0F, 1.0F); break;
            case 9: x.drive = std::clamp(v, 0.0F, 1.0F); break;
            case 10: x.filterType = i8(v, 0, 2); break;
            case 11: x.filterKeyTrack = std::clamp(v, -1.0F, 1.0F); break;
            case 12: x.filter2Type = i8(v, 0, 4); break;
            case 13: x.filter2Hz = std::clamp(v, 20.0F, 20000.0F); break;
            case 14: x.filter2Res = std::clamp(v, 0.0F, 1.0F); break;
            case 15: x.filter2Parallel = v >= 0.5F; break;
            case 16: x.analogFeel = v >= 0.5F; break;
            case 17: x.synthBypass = v >= 0.5F; break;
            default: break;
        }
    }
    static void readSynth(const ToneExtra& x, const ModMatrix& m, std::vector<float>& out) {
        out.insert(out.end(), {x.pwmWidth, x.pwmDepth, x.pwmRateHz, x.pwmMix, x.subLevel, static_cast<float>(x.subOctave), static_cast<float>(x.unisonVoices), x.unisonDetuneCents,
                               x.unisonSpread, x.drive, static_cast<float>(x.filterType), x.filterKeyTrack, static_cast<float>(x.filter2Type), x.filter2Hz, x.filter2Res,
                               x.filter2Parallel ? 1.0F : 0.0F, x.analogFeel ? 1.0F : 0.0F, x.synthBypass ? 1.0F : 0.0F, 0.0F, 0.0F});
        for (const auto& r : m.route) out.insert(out.end(), {static_cast<float>(r.source), static_cast<float>(r.target), r.amount, r.bipolar ? 1.0F : 0.0F});
    }
    bool setSoundSynthParam(int upperIndex, int sound, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kPartCount || sound < 0 || sound > kUpperLayers || id < 0 || id >= kSynthParamCount || !std::isfinite(v)) { setTextError("Invalid synth parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        if (sound == 0) applySynth(u.toneExtra, u.toneMod, id, v);
        else { auto& l = u.layers[static_cast<std::size_t>(sound - 1)]; applySynth(l.tone.x, l.tone.mod, id, v); }
        return installState(std::move(next));
    }
    std::vector<float> soundSynthParams(int upperIndex, int sound) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kPartCount || sound < 0 || sound > kUpperLayers || state_ == nullptr) return out;
        const auto& u = state_->combi.part(upperIndex);
        if (sound == 0) readSynth(u.toneExtra, u.toneMod, out);
        else { const auto& l = u.layers[static_cast<std::size_t>(sound - 1)]; readSynth(l.tone.x, l.tone.mod, out); }
        return out;
    }

#include "../WaveHost.inc"

    // ---------------------------------------------------------------- SILVETON_ENGINES_V1 (the same as in SamplerHost.cpp)
    // The ENGINE of an Upper (one per Upper, see core/include/silveton/sampler/EngineDefs.h). Ids of
    // setUpperEngineParam / upperEngineParams: 0 = the engine (0 OFF, 1 HD-1, 2 POLYSIX, 3 MS-20, 4 AL-1, 5 MOD-7, 6 STR-1,
    // 7 CX-3, 8 SGX, 9 EP; choosing another engine loads that engine's own starting values), 1..48 = value id - 1.
    static constexpr int kEngineHostParamCount = 1 + kEngineParamCount;
    // SILVETON_MODEL_START_V1 (Цветомир, 03.11.2026 14:10, "искам екрана да идва с тези настройки по дефолт"): the moment a place becomes
    // a SILVETON SYNTH place, its own settings start as on his screen: LEGATO; KRONOS portamento ON, TIME 17, FINGERED, TIME (not RATE);
    // PITCH BEND 1 st; ОКТАВА -1 (Цветомир, 03.11.2026 18:26: was -3), ТРАНСПОНИРАНЕ 0, TUNE 0; ATTACK 0 ms, DECAY 80 ms, SUSTAIN 100 %,
    // RELEASE 46 ms. (The engine's own knobs start from ModelDefs: SHAPE 0, SCOOP 23 %, F.ATTACK 1 ms ...)
    
    bool setUpperEngineParam(int upperIndex,int id,float value) {
  if(upperIndex<0||upperIndex>=kPartCount||id<0||id>=kEngineHostParamCount||!std::isfinite(value)){setTextError("Invalid engine parameter");return false;}
  if(id==0&&value!=0&&value!=13){setTextError("This synth engine has been removed; select SOLO");return false;}
  auto next=std::make_shared<EngineState>(state_?*state_:EngineState{});auto& u=next->combi.part(upperIndex);
  if(id==0){const auto type=engineTypeOf(static_cast<int>(value));if(type!=u.engine.type){u.engine=engineDefaults(type);if(type==EngineType::Solo){u.enabled=true;u.mute=false;u.voiceMode=UpperVoiceMode::Legato;}}}
  else u.engine.p[static_cast<std::size_t>(id-1)]=engineClamp(u.engine.type,id-1,value);
  if(id==E_BEND_UP+1||id==E_BEND_DOWN+1)u.engine.p[E_BEND_UP]=u.engine.p[E_BEND_DOWN]=engineClamp(u.engine.type,id-1,value);
  return installState(std::move(next));
 }
#include "../EngineBlockHost.inc"
#include "../ModelHost.inc"
#include "../SoundSourceHost.inc"
    std::vector<float> upperEngineParams(int upperIndex) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) return out;
        const auto& e = state_->combi.part(upperIndex).engine;
        out.reserve(static_cast<std::size_t>(kEngineHostParamCount));
        out.push_back(static_cast<float>(static_cast<std::uint8_t>(e.type)));
        out.insert(out.end(), e.p.begin(), e.p.end());
        return out;
    }

    std::vector<float> upperState(int upperIndex) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) return out;
        const auto& u = state_->combi.part(upperIndex);
        out = {
            u.enabled ? 1.0F : 0.0F, u.solo ? 1.0F : 0.0F, u.mute ? 1.0F : 0.0F,
            u.levelDb, u.pan, static_cast<float>(u.keyLow), static_cast<float>(u.keyHigh),
            static_cast<float>(u.velocityLow), static_cast<float>(u.velocityHigh),
            static_cast<float>(u.voiceMode), static_cast<float>(u.octave),
            static_cast<float>(u.transposeSemitones), u.tuneCents, static_cast<float>(u.pitchBendRange),
            u.portamentoSec, u.breathEnabled ? 1.0F : 0.0F, u.expressionEnabled ? 1.0F : 0.0F,
            u.aftertouchEnabled ? 1.0F : 0.0F, u.damperEnabled ? 1.0F : 0.0F,
            static_cast<float>(u.midiChannel), u.ampAttackScale, u.ampDecayScale,
            u.ampSustainScale, u.ampReleaseScale, u.filterCutoffOctaves, u.filterResonanceOffset,
            u.lfoRateScale, u.lfoDepthScale, u.eqLowDb, u.eqMidDb, u.eqHighDb, u.fxSend1, u.fxSend2
        };
        const UpperToneValues tone = effectiveUpperTone(u);
        out.insert(out.end(), {tone.attackMs, tone.decayMs, tone.sustain, tone.releaseMs, tone.cutoffHz, tone.resonance,
                               u.toneAttackMs >= 0.0F ? 1.0F : 0.0F, u.toneDecayMs >= 0.0F ? 1.0F : 0.0F,
                               u.toneSustain >= 0.0F ? 1.0F : 0.0F, u.toneReleaseMs >= 0.0F ? 1.0F : 0.0F,
                               u.toneCutoffHz >= 0.0F ? 1.0F : 0.0F, u.toneResonance >= 0.0F ? 1.0F : 0.0F});
        return out;
    }



    std::string combiName() const { return state_ == nullptr ? std::string{} : state_->combi.name; }


    std::vector<int> combiCatalogSlots() const {
        std::vector<int> out;
        out.reserve(500U);
        for (int slot = 1; slot <= 500; ++slot) {
            SlotAddress address{};
            address.bank = 0;
            address.page = 0;
            address.slot = static_cast<std::uint16_t>(slot);
            if (library_.combi(address).has_value()) out.push_back(slot);
        }
        return out;
    }

    std::vector<std::string> combiCatalogNames() const {
        std::vector<std::string> out;
        out.reserve(500U);
        for (int slot = 1; slot <= 500; ++slot) {
            SlotAddress address{};
            address.bank = 0;
            address.page = 0;
            address.slot = static_cast<std::uint16_t>(slot);
            const auto combi = library_.combi(address);
            if (combi.has_value()) out.push_back(combi->name);
        }
        return out;
    }

    // SILVETON_POLYSIX_V1: a SOUND slot is a bank SOUND (1..500) or a built-in wave (9001..).
    static bool isBuiltinSlot(std::uint16_t slot) noexcept {
        return slot >= kBuiltinWaveFirstSlot && slot < kBuiltinWaveFirstSlot + static_cast<std::uint16_t>(kBuiltinWaveCount);
    }
    ProgramPtr programForSlot(std::uint16_t slot) const {
        if (slot >= 1U && slot <= kFixedSoundSlotCount) return library_.program(SlotAddress{0U, 0U, slot});
        if (isBuiltinSlot(slot)) return builtinWaveProgram(static_cast<int>(slot - kBuiltinWaveFirstSlot));
        return nullptr;
    }
    // SILVETON_SOUND_BY_NAME_V1: every SOUND of the bank (1..500) with the place it has now.
    std::vector<SoundCandidate> bankSoundCandidates() const {
        std::vector<SoundCandidate> out;
        for (const auto& item : library_.programCatalog()) {
            if (item.address.bank != 0U || item.address.page != 0U) continue;
            if (item.address.slot < 1U || item.address.slot > kFixedSoundSlotCount) continue;
            out.push_back(SoundCandidate{item.address.slot, item.name});
        }
        return out;
    }
    // Finds the sound a part remembers: by its NAME in the bank (the place is only the first
    // guess and is updated when the sound sits elsewhere now). Built-in waves have fixed
    // places. Not found = nullptr (the place and the name stay remembered, nothing else is bound).
    ProgramPtr programForRemembered(std::uint16_t& slot, const std::string& name,
                                    const std::vector<SoundCandidate>& bankSounds) const {
        if (slot == kNoSoundSlot) return nullptr;
        if (isBuiltinSlot(slot)) return programForSlot(slot);
        const auto found = resolveSoundByName(slot, name, bankSounds);
        if (!found.found) return nullptr;
        slot = found.slot;
        return programForSlot(slot);
    }
    // Binds every sound of an Upper (basic + layers) to its SOUND, found by name. Missing = off.


    static void stripPerformancePrograms(Combi& combi) {
        for (int i = 0; i < kPartCount; ++i) {
            auto& upper = combi.part(i);
            upper.program.reset();
            for (auto& layer : upper.layers) layer.program.reset();
        }
    }

    // Reference-only SETs resolve every part against the current bank. Keep the
    // same missing-sound report as a normal COMBI recall, including engine slots.
    std::string rebindPerformanceCombi(Combi& combi, const std::vector<SoundCandidate>& bankSounds) const {
        std::string missing;
        for (int i = 0; i < kPartCount; ++i) {
            auto& upper = combi.part(i);
            const auto mainSlot = upper.soundSlotId;
            const auto mainName = upper.name;
            std::array<std::pair<std::uint16_t, std::string>, kUpperLayers> layers;
            for (std::size_t k = 0U; k < upper.layers.size(); ++k) layers[k] = {upper.layers[k].soundSlotId, upper.layers[k].name};
            if (upper.soundSlotId == kNoSoundSlot) upper.program.reset();
            rebindUpper(upper, bankSounds);
            if (mainSlot != kNoSoundSlot && upper.program == nullptr)
                missing += std::to_string(i + 1) + "\t0\t" + mainName + "\t" + std::to_string(mainSlot) + "\n";
            for (std::size_t k = 0U; k < upper.layers.size(); ++k) {
                if (layers[k].first != kNoSoundSlot && upper.layers[k].program == nullptr)
                    missing += std::to_string(i + 1) + "\t" + std::to_string(k + 1U) + "\t" + layers[k].second + "\t" + std::to_string(layers[k].first) + "\n";
            }
        }
        return missing;
    }





    bool updateUpperFxSends(int upperIndex, float send1, float send2) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        if (!std::isfinite(send1) || !std::isfinite(send2)) { setTextError("Invalid Upper FX send"); return false; }
        send1 = std::clamp(send1, 0.0F, 1.0F);send2 = std::clamp(send2, 0.0F, 1.0F);
        if (state_ && (!state_->combi.sourceEffects || !state_->combi.sourceEffects->style)) {
            const auto& current = state_->combi.part(upperIndex);
            if (current.fxSend1 == send1 && current.fxSend2 == send2) return true;
        }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& upper = next->combi.part(upperIndex);
        upper.fxSend1 = send1;
        upper.fxSend2 = send2;
        // Match sends 3/4: a keyboard level edit keeps the source rack.
        if (next->combi.sourceEffects && next->combi.sourceEffects->style) next->combi.sourceEffects.reset();
        return installState(std::move(next));
    }

    bool updateUpperControllerRoute(int upperIndex, int routeIndex, int source, int destination,
                                    int cc, float amount, bool bipolar) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        if (routeIndex < 0 || routeIndex >= kMaxUpperControllerRoutes) { setTextError("Invalid controller route index"); return false; }
        if (source < static_cast<int>(ControllerSource::Off) || source > static_cast<int>(ControllerSource::ControlChange)) { setTextError("Invalid controller source"); return false; }
        if (destination < static_cast<int>(ModDestination::LevelDb) || destination > static_cast<int>(ModDestination::FxSend2)) { setTextError("Invalid modulation destination"); return false; }
        if (!std::isfinite(amount)) { setTextError("Controller route amount is not finite"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& route = next->combi.part(upperIndex).controllerRoutes[static_cast<std::size_t>(routeIndex)];
        route.source = static_cast<ControllerSource>(source);
        route.destination = static_cast<ModDestination>(destination);
        route.cc = static_cast<std::uint8_t>(std::clamp(cc, 0, 127));
        route.amount = std::clamp(amount, -96.0F, 96.0F);
        route.bipolar = bipolar;
        return installState(std::move(next));
    }

    bool updateCombiFx(int slot, int type, float wet, float timeMs, float feedback,
                       float rateHz, float depth, float tone) {
        if (slot < 0 || slot >= kFxSendSlots) { setTextError("Invalid COMBI FX slot"); return false; }
        if (type < static_cast<int>(EffectType::Off) || type >= kEffectTypeCount) { setTextError("Invalid COMBI FX type"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& fx = next->combi.fx[static_cast<std::size_t>(slot)];
        fx.numbered = {}; fx.numberedModulatingPart = -1;
        fx.type = static_cast<EffectType>(type);
        fx.wet = std::clamp(wet, 0.0F, 1.0F);
        fx.timeMs = std::clamp(timeMs, 1.0F, 2500.0F);
        fx.feedback = std::clamp(feedback, 0.0F, 0.95F);
        fx.rateHz = std::clamp(rateHz, 0.02F, 12.0F);
        fx.depth = std::clamp(depth, 0.0F, 1.0F);
        fx.tone = std::clamp(tone, 0.0F, 1.0F);
        next->combi.sourceEffects.reset();
        return installState(std::move(next));
    }

    bool updateCombiFxRouting(int routing) {
        if (routing < static_cast<int>(EffectRouting::Parallel) || routing > static_cast<int>(EffectRouting::Fx1IntoFx2)) { setTextError("Invalid COMBI FX routing"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        next->combi.fxRouting = static_cast<EffectRouting>(routing);
        next->combi.sourceEffects.reset();
        return installState(std::move(next));
    }

    std::string pendingSetExtra_;       // SILVETON_SET_ONE_FILE_V1
    std::string lastLoadedSetExtra_;

    // SILVETON_BLEND_INFO_V1: what a stored BLEND holds, for the INFO window of the LIST. One record per line, fields split by TAB:
    //   U n soundNo name enabled      (Upper 1..7)         P n engineType modelNo enabled   (SILVETON SYNTH place 1..8, only used ones)
    //   F n fxType                    (send effect 1..4)   I label fxType                   (INSERT of an Upper "U3" / of a place "M2", only used ones)
    std::string blendInfo(const SlotAddress& address) const {
        const auto combi = library_.combi(address);
        if (!combi.has_value()) return {};
        std::ostringstream out;
        for (int i = 0; i < kUpperCount; ++i) {
            const auto& u = combi->uppers[static_cast<std::size_t>(i)];
            const bool has = u.program != nullptr || u.soundSlotId != kNoSoundSlot;
            out << "U\t" << (i + 1) << "\t" << (has ? static_cast<int>(u.soundSlotId) : 0) << "\t" << (has ? u.name : std::string()) << "\t" << (u.enabled ? 1 : 0) << "\n";
        }
        for (int i = 0; i < kEngineSlotCount; ++i) {
            const auto& u = combi->engineSlots[static_cast<std::size_t>(i)];
            if (!u.engine.chosen()) continue;
            out << "P\t" << (i + 1) << "\t" << static_cast<int>(u.engine.type) << "\t" << 0 << "\t" << (u.enabled ? 1 : 0) << "\n";
        }
        for (int i = 0; i < kFxSendSlots; ++i) out << "F\t" << (i + 1) << "\t" << static_cast<int>(combi->fx[static_cast<std::size_t>(i)].type) << "\n";
        for (int i = 0; i < kPartCount; ++i) {
            const EffectSlot& ins = combi->insertOf(i);
            if (ins.type == EffectType::Off) continue;
            out << "I\t" << (i < kUpperCount ? "U" + std::to_string(i + 1) : "M" + std::to_string(i - kUpperCount + 1)) << "\t" << static_cast<int>(ins.type) << "\n";
        }
        return out.str();
    }

    std::vector<float> combiFxState() const {
        std::vector<float> out;
        if (state_ == nullptr) return out;
        const auto append = [&out](const EffectSlot& fx) {
            out.push_back(static_cast<float>(fx.type));
            out.push_back(fx.wet); out.push_back(fx.timeMs); out.push_back(fx.feedback);
            out.push_back(fx.rateHz); out.push_back(fx.depth); out.push_back(fx.tone);
        };
        for (const auto& f : state_->combi.fx) append(f);
        out.push_back(static_cast<float>(state_->combi.fxRouting));
        return out;
    }

    std::vector<float> globalState() const {
        std::vector<float> out;
        if (state_ == nullptr) return out;
        const auto& g = state_->global;
        out = {g.masterTuneHz, static_cast<float>(g.transposeSemitones), g.masterGainDb,
               g.eqLowDb, g.eqMidDb, g.eqHighDb, g.limiterEnabled ? 1.0F : 0.0F,
               g.limiterCeilingDb, static_cast<float>(g.velocityCurve),
               static_cast<float>(g.breathCc), static_cast<float>(g.expressionCc),
               static_cast<float>(g.damperCc), g.pitchBendEnabled ? 1.0F : 0.0F,
               g.aftertouchEnabled ? 1.0F : 0.0F};
        // SILVETON_MIDI_FULL_V1: 14 scaleRoot, 15..26 scale cents, 27 MIDI IN mask,
        // 28..31 filters (notes, CC, bend, aftertouch), 32..34 breath min/max/curve,
        // 35..37 expression min/max/curve, 38 damper polarity reversed.
        out.push_back(static_cast<float>(g.scaleRoot));
        for (const float cents : g.scaleOffsetsCents) out.push_back(cents);
        out.push_back(static_cast<float>(g.midiInputChannelMask));
        out.push_back(g.filterNotes ? 1.0F : 0.0F);
        out.push_back(g.filterControlChange ? 1.0F : 0.0F);
        out.push_back(g.filterPitchBend ? 1.0F : 0.0F);
        out.push_back(g.filterAftertouch ? 1.0F : 0.0F);
        out.push_back(g.breathMin); out.push_back(g.breathMax); out.push_back(g.breathCurve);
        out.push_back(g.expressionMin); out.push_back(g.expressionMax); out.push_back(g.expressionCurve);
        out.push_back(g.damperPolarityReversed ? 1.0F : 0.0F);
        return out;
    }

    bool writeGlobal() {
        if (state_ == nullptr) { setTextError("No active GLOBAL state"); return false; }
        library_.setGlobal(state_->global);
        setTextError({});
        return true;
    }

    bool updateGlobal(float masterTuneHz, int transposeSemitones, float masterGainDb,
                      float eqLowDb, float eqMidDb, float eqHighDb, bool limiterEnabled,
                      float limiterCeilingDb, int velocityCurve, int breathCc, int expressionCc,
                      int damperCc, bool pitchBendEnabled, bool aftertouchEnabled) {
        for (const float value : {masterTuneHz, masterGainDb, eqLowDb, eqMidDb, eqHighDb, limiterCeilingDb}) {
            if (!std::isfinite(value)) { setTextError("GLOBAL values must be finite"); return false; }
        }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& g = next->global;
        g.masterTuneHz = std::clamp(masterTuneHz, 400.0F, 480.0F);
        g.transposeSemitones = static_cast<std::int8_t>(std::clamp(transposeSemitones, -12, 12));
        g.masterGainDb = std::clamp(masterGainDb, -60.0F, 18.0F);
        g.eqLowDb = std::clamp(eqLowDb, -18.0F, 18.0F);
        g.eqMidDb = std::clamp(eqMidDb, -18.0F, 18.0F);
        g.eqHighDb = std::clamp(eqHighDb, -18.0F, 18.0F);
        g.limiterEnabled = limiterEnabled;
        g.limiterCeilingDb = std::clamp(limiterCeilingDb, -12.0F, 0.0F);
        g.velocityCurve = static_cast<std::uint8_t>(std::clamp(velocityCurve, 0, 4));
        g.breathCc = static_cast<std::uint8_t>(std::clamp(breathCc, 0, 127));
        g.expressionCc = static_cast<std::uint8_t>(std::clamp(expressionCc, 0, 127));
        g.damperCc = static_cast<std::uint8_t>(std::clamp(damperCc, 0, 127));
        g.pitchBendEnabled = pitchBendEnabled;
        g.aftertouchEnabled = aftertouchEnabled;
        library_.setGlobal(g);
        return installState(std::move(next), Mark::Keep);
    }

    bool updateGlobalAdvanced(int scaleRoot, const std::array<float, 12>& scaleOffsetsCents,
                              std::uint16_t midiInputChannelMask, bool filterNotes,
                              bool filterControlChange, bool filterPitchBend, bool filterAftertouch,
                              float breathMin, float breathMax, float breathCurve,
                              float expressionMin, float expressionMax, float expressionCurve,
                              bool damperPolarityReversed) {
        for (const float value : scaleOffsetsCents) {
            if (!std::isfinite(value)) { setTextError("Scale offsets must be finite"); return false; }
        }
        for (const float value : {breathMin, breathMax, breathCurve, expressionMin, expressionMax, expressionCurve}) {
            if (!std::isfinite(value)) { setTextError("Controller curves must be finite"); return false; }
        }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& g = next->global;
        g.scaleRoot = static_cast<std::uint8_t>(std::clamp(scaleRoot, 0, 11));
        for (std::size_t i = 0; i < g.scaleOffsetsCents.size(); ++i) {
            g.scaleOffsetsCents[i] = std::clamp(scaleOffsetsCents[i], -100.0F, 100.0F);
        }
        if (next->combi.scale.stored) {
            auto& sc = next->combi.scale;
            for (int pc = 0; pc < 12; ++pc) sc.cents[static_cast<std::size_t>(pc)] =
                g.scaleOffsetsCents[static_cast<std::size_t>((pc - g.scaleRoot + 12) % 12)];
        }
        g.midiInputChannelMask = midiInputChannelMask;
        g.filterNotes = filterNotes;
        g.filterControlChange = filterControlChange;
        g.filterPitchBend = filterPitchBend;
        g.filterAftertouch = filterAftertouch;
        g.breathMin = std::clamp(breathMin, 0.0F, 0.9999F);
        g.breathMax = std::clamp(breathMax, g.breathMin + 0.0001F, 1.0F);
        g.breathCurve = std::clamp(breathCurve, 0.1F, 8.0F);
        g.expressionMin = std::clamp(expressionMin, 0.0F, 0.9999F);
        g.expressionMax = std::clamp(expressionMax, g.expressionMin + 0.0001F, 1.0F);
        g.expressionCurve = std::clamp(expressionCurve, 0.1F, 8.0F);
        g.damperPolarityReversed = damperPolarityReversed;
        library_.setGlobal(g);
        return installState(std::move(next), Mark::Keep);
    }

    bool writeList(const SlotAddress& address, const SetList& list) {
        if (!library_.writeList(address, list)) { setTextError("Write List failed"); return false; }
        setTextError({});
        return true;
    }

    // SILVETON_LIST_POSITIONS_V1: COMBI address 0/0/0 marks an empty LIST position,
    // so a BLEND can sit at any position 1..200 like a Korg Performance.
    static bool emptyListAddress(const SlotAddress& a) noexcept { return a.bank == 0U && a.page == 0U && a.slot == 0U; }

    bool setListEntry(const SlotAddress& listAddress, int index, int number, const std::string& name, const SlotAddress& combiAddress) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const bool empty = emptyListAddress(combiAddress);
        const auto combi = empty ? std::optional<Combi>{} : library_.combi(combiAddress);
        if (!empty && !combi.has_value()) { setTextError("LIST target COMBI slot is empty"); return false; }
        ListEntry entry{};
        entry.number = static_cast<std::uint16_t>(std::clamp(number, 0, 65535));
        entry.name = empty ? std::string("-") : (name.empty() ? combi->name : name);
        entry.combiBank = combiAddress.bank; entry.combiPage = combiAddress.page; entry.combiSlot = combiAddress.slot;
        if (!library_.setListEntry(listAddress, static_cast<std::size_t>(index), entry)) { setTextError("LIST entry update failed"); return false; }
        setTextError({}); return true;
    }

    bool insertListEntry(const SlotAddress& listAddress, int index, int number, const std::string& name, const SlotAddress& combiAddress) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const bool empty = emptyListAddress(combiAddress);
        const auto combi = empty ? std::optional<Combi>{} : library_.combi(combiAddress);
        if (!empty && !combi.has_value()) { setTextError("LIST target COMBI slot is empty"); return false; }
        ListEntry entry{};
        entry.number = static_cast<std::uint16_t>(std::clamp(number, 0, 65535));
        entry.name = empty ? std::string("-") : (name.empty() ? combi->name : name);
        entry.combiBank = combiAddress.bank; entry.combiPage = combiAddress.page; entry.combiSlot = combiAddress.slot;
        if (!library_.insertListEntry(listAddress, static_cast<std::size_t>(index), entry)) { setTextError("LIST entry insert failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress && activeListEntry_ >= index) ++activeListEntry_;
        setTextError({}); return true;
    }

    bool removeListEntry(const SlotAddress& listAddress, int index) {
        if (index < 0 || !library_.removeListEntry(listAddress, static_cast<std::size_t>(index))) { setTextError("LIST entry remove failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) {
            if (activeListEntry_ == index) activeListEntry_ = -1;
            else if (activeListEntry_ > index) --activeListEntry_;
        }
        setTextError({}); return true;
    }

    bool moveListEntry(const SlotAddress& listAddress, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < 0 || !library_.moveListEntry(listAddress, static_cast<std::size_t>(fromIndex), static_cast<std::size_t>(toIndex))) { setTextError("LIST entry move failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) {
            if (activeListEntry_ == fromIndex) activeListEntry_ = toIndex;
            else if (fromIndex < activeListEntry_ && activeListEntry_ <= toIndex) --activeListEntry_;
            else if (toIndex <= activeListEntry_ && activeListEntry_ < fromIndex) ++activeListEntry_;
        }
        setTextError({}); return true;
    }

    bool moveList(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
        if (!library_.moveList(from, to, overwrite)) { setTextError("LIST move failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == from) activeListAddress_ = to;
        setTextError({}); return true;
    }

    bool activateListEntry(const SlotAddress& listAddress, int index) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const auto list = library_.list(listAddress);
        if (!list.has_value() || static_cast<std::size_t>(index) >= list->entries.size()) { setTextError("LIST entry is not available"); return false; }
        const auto& entry = list->entries[static_cast<std::size_t>(index)];
        const SlotAddress combiAddress{entry.combiBank, entry.combiPage, entry.combiSlot};
        if (!activateCombi(combiAddress)) return false;
        activeListAddress_ = listAddress;
        activeListEntry_ = index;
        setTextError({}); return true;
    }

    // Marks which LIST position the loaded sound belongs to, without reloading it.
    bool setActiveListEntry(const SlotAddress& listAddress, int index) {
        const auto list = library_.list(listAddress);
        if (index < 0 || !list.has_value() || static_cast<std::size_t>(index) >= list->entries.size()) {
            if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) activeListEntry_ = -1;
            return true;
        }
        activeListAddress_ = listAddress;
        activeListEntry_ = index;
        return true;
    }

    int activeListEntry(const SlotAddress& listAddress) const noexcept {
        return activeListAddress_.has_value() && *activeListAddress_ == listAddress ? activeListEntry_ : -1;
    }

    std::vector<int> listEntryNumbers(const SlotAddress& address) const {
        std::vector<int> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()); for (const auto& e : list->entries) out.push_back(static_cast<int>(e.number)); return out;
    }

    std::vector<std::string> listEntryNames(const SlotAddress& address) const {
        std::vector<std::string> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()); for (const auto& e : list->entries) out.push_back(e.name); return out;
    }

    std::vector<int> listEntryCombiAddresses(const SlotAddress& address) const {
        std::vector<int> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()*3U); for (const auto& e : list->entries) { out.push_back(e.combiBank); out.push_back(e.combiPage); out.push_back(e.combiSlot); } return out;
    }

    bool clearProgram(const SlotAddress& address) { return library_.clearProgram(address); }
    bool clearCombi(const SlotAddress& address) { return library_.clearCombi(address); }
    bool clearList(const SlotAddress& address) {
        const bool ok = library_.clearList(address);
        if (ok && activeListAddress_.has_value() && *activeListAddress_ == address) { activeListAddress_.reset(); activeListEntry_ = -1; }
        return ok;
    }
    bool clearMultisample(std::uint32_t id) { return library_.clearMultisample(id); }

    bool assignArrangerSound(int player, int track, const SlotAddress& address) {
        if (address.slot == 0U) return arrangerHost().assignSound(player, track, 0, nullptr);
        const auto program = library_.program(address);
        if (program == nullptr) { setTextError("Arranger SOUND slot is missing: " + std::to_string(address.slot)); return false; }
        return arrangerHost().assignSound(player, track, static_cast<int>(address.slot), program);
    }
    bool loadArrangerSetup(const std::string& path) {
        std::ifstream setupFile(path);
        if (!setupFile) { setTextError("Arranger setup cannot be opened"); return false; }
        std::string setupLine;
        while (std::getline(setupFile, setupLine)) {
            std::istringstream row(setupLine);
            std::string type;
            row >> type;
            if (type != "TRACK") continue;
            int player = 0, track = 0, slot = 0;
            if (!(row >> player >> track >> slot) || slot < 0 || slot > 500) { setTextError("Invalid arranger sound assignment"); return false; }
            if (slot > 0 && library_.program(SlotAddress{0U, 0U, static_cast<std::uint16_t>(slot)}) == nullptr) {
                setTextError("Arranger SOUND slot is missing: " + std::to_string(slot));
                return false;
            }
        }
        if (!arrangerHost().loadSetup(path)) { setTextError("Arranger setup load failed: " + arrangerHost().lastError()); return false; }
        bool complete = true;
        for (int p = 0; p < 2; ++p) {
            const auto view = arrangerHost().snapshot(p);
            for (int t = 0; t < 8; ++t) {
                const auto slot = view.tracks[static_cast<std::size_t>(t)].soundSlot;
                if (slot > 0 && !assignArrangerSound(p, t, SlotAddress{0U, 0U, static_cast<std::uint16_t>(slot)})) complete = false;
            }
        }
        return complete;
    }

    bool programSlotOccupied(const SlotAddress& address) const { return library_.hasProgram(address); }
    bool combiSlotOccupied(const SlotAddress& address) const { return library_.hasCombi(address); }
    bool listSlotOccupied(const SlotAddress& address) const { return library_.hasList(address); }
    bool renameProgram(const SlotAddress& address, const std::string& name) { return library_.renameProgram(address, name); }
    bool renameCombi(const SlotAddress& address, const std::string& name) { return library_.renameCombi(address, name); }
    bool renameList(const SlotAddress& address, const std::string& name) { return library_.renameList(address, name); }
    bool copyProgram(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyProgram(from, to, overwrite); }
    bool copyCombi(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyCombi(from, to, overwrite); }
    std::shared_ptr<const Combi> storedCombi(const SlotAddress& address) const {
        const auto stored = library_.combi(address);
        return stored ? std::make_shared<const Combi>(*stored) : nullptr;
    }
    bool storeCombiSnapshot(const SlotAddress& address, const Combi& combi) {
        if (library_.hasCombi(address)) { setTextError("Clipboard COMBI position is occupied"); return false; }
        if (!library_.writeCombi(address, combi)) { setTextError("Clipboard COMBI could not be stored"); return false; }
        setTextError({});
        return true;
    }

    bool copyList(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyList(from, to, overwrite); }





    // SILVETON_EMPTY_START_V1 (Цветомир, 02.11.2026): ПРАЗНО - nothing sounds. The Uppers of the blend (1..7) are emptied, the engine
    // places (8..15) keep their SILVETON SYNTH but are switched off (their lamp turns them on again), no LIST position is the open one.
    // Nothing is asked about saving: this is not an edit of a blend.


    bool activateCombi(const SlotAddress& address) {
        const auto combi = library_.combi(address);
        if (!combi.has_value()) { setTextError("COMBI slot is empty"); return false; }
        auto next = std::make_shared<EngineState>();
        next->global = state_ != nullptr ? state_->global : library_.global();
        next->combi = *combi;
        // SILVETON_FX_TAIL_V1: a new BLEND -> the old effect rings out, no cut.
        next->combiGeneration = (state_ != nullptr ? state_->combiGeneration : 0U) + 1U;
        const auto bankSounds = bankSoundCandidates();   // SILVETON_SOUND_BY_NAME_V1
        // SILVETON_OPEN_WITHOUT_SOUND_V1 (Цветомир, 01.11.2026): a sound that is no longer in the bank does not stop the BLEND from opening.
        // That part stays off and the sampler tells which ones: one line per part "part<TAB>layer<TAB>name<TAB>number" (layer 0 = main sound).
        struct Remembered { std::uint16_t slot; std::string name; };
        std::string missing;
        int partNo = 0;
        for (auto& upper : next->combi.uppers) {
            std::vector<Remembered> before;
            before.push_back({upper.soundSlotId, upper.name});
            for (const auto& l : upper.layers) before.push_back({l.soundSlotId, l.name});
            rebindUpper(upper, bankSounds);   // SILVETON_LAYERS_V1 / SILVETON_POLYSIX_V1: basic sound, layers, built-in waves
            if (before[0].slot != kNoSoundSlot && upper.program == nullptr)
                missing += std::to_string(partNo + 1) + "\t0\t" + before[0].name + "\t" + std::to_string(before[0].slot) + "\n";
            for (std::size_t k = 0U; k < upper.layers.size(); ++k) {
                if (before[k + 1U].slot != kNoSoundSlot && upper.layers[k].program == nullptr)
                    missing += std::to_string(partNo + 1) + "\t" + std::to_string(k + 1U) + "\t" + before[k + 1U].name + "\t" + std::to_string(before[k + 1U].slot) + "\n";
            }
            ++partNo;
        }
        {
            std::lock_guard<std::mutex> lock(missingMutex_);
            lastRecallMissing_ = missing;
        }
        return installState(std::move(next), Mark::Clean);
    }

    bool setSetName(const std::string& name) {
        if (name.empty()) { setTextError("SET name cannot be empty"); return false; }
        library_.setSetName(name);
        return true;
    }

    // SILVETON_SCAN_V1: SCAN for TERCA (1) and SCALE (2), like the SILVETON
    // processor / Korg Pa. While scanning the keys make no sound; TERCA takes the
    // three-note shape held (tonality), SCALE takes every key pressed (notes of
    // the scale). When all scan keys are up the result is published and the
    // keyboard plays normally again. Keys held before SCAN are released normally.
    void startScan(int mode) noexcept {
        scanTercaPending_ = false;
        scanScaleCollected_ = 0;
        scanKeyPending_ = false;
        scanMode_.store(mode >= 1 && mode <= 3 ? mode : 0, std::memory_order_release);
    }
    std::vector<int> scanInfo() const {
        return {scanMode_.load(std::memory_order_acquire), tercaRoot_.load(std::memory_order_acquire),
                tercaCell_.load(std::memory_order_acquire), static_cast<int>(tercaSerial_.load(std::memory_order_acquire)),
                scaleMask_.load(std::memory_order_acquire), static_cast<int>(scaleSerial_.load(std::memory_order_acquire)),
                keyScan_.load(std::memory_order_acquire), static_cast<int>(keyScanSerial_.load(std::memory_order_acquire))};
    }
    void setTerca(int upperMask, int root, int cell) noexcept { engine_.setTerca(upperMask, root, cell); }
    void setScaleUppers(int upperMask) noexcept {
        scaleTargets_.store(upperMask & 0x7FFF, std::memory_order_release);
        engine_.setScaleUppers(upperMask);
    }
    bool setScaleTuning(bool enabled, int upperMask, int tonic,
                        const std::vector<float>& cents, const std::string& name, bool markEdited) {
        if (cents.size() != 12U || tonic < 0 || tonic > 11 || name.size() > 256U) { setTextError("Invalid scale tuning"); return false; }
        for (float v : cents) if (!std::isfinite(v)) { setTextError("Invalid scale cents"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& sc = next->combi.scale;
        const bool wasStored = sc.stored;
        bool changed = !wasStored || sc.enabled != enabled || sc.targets != (upperMask & 0x7FFF) || sc.tonic != tonic || sc.name != name;
        sc.stored = true;
        sc.enabled = enabled;
        sc.targets = static_cast<std::uint16_t>(upperMask & 0x7FFF);
        sc.tonic = static_cast<std::uint8_t>(tonic);
        sc.name = name;
        for (std::size_t i = 0U; i < 12U; ++i) {
            const float v = std::clamp(cents[i], -100.0F, 100.0F);
            changed = changed || sc.cents[i] != v;
            sc.cents[i] = v;
        }
        if (!changed) return true;
        return installState(std::move(next), markEdited ? Mark::Edit : Mark::Keep);
    }
    std::vector<float> scaleTuning() const {
        if (state_ == nullptr) return {};
        const auto& sc = state_->combi.scale;
        std::vector<float> out{sc.stored ? 1.0F : 0.0F, sc.enabled ? 1.0F : 0.0F,
                               static_cast<float>(sc.targets), static_cast<float>(sc.tonic)};
        out.insert(out.end(), sc.cents.begin(), sc.cents.end());
        return out;
    }
    std::string scaleName() const { return state_ != nullptr ? state_->combi.scale.name : std::string(); }

    void scanObserveOn(int mode, std::uint8_t key) noexcept {
        if (mode == 2) { scanScaleCollected_ |= 1 << (key % 12U); return; }
        // SILVETON_KEY_SCAN_V1: KEY RANGE - the first key pressed is the limit.
        if (mode == 3) { if (!scanKeyPending_) { scanKeyValue_ = key; scanKeyPending_ = true; } return; }
        if (scanTercaPending_) return;
        int mask = 0;
        for (int n = 0; n < 128; ++n) if (scanSwallowed_[static_cast<std::size_t>(n)] != 0U) mask |= 1 << (n % 12);
        if (__builtin_popcount(static_cast<unsigned>(mask)) != 3) return;
        static constexpr int kCells[6][3] = {{0, 4, 7}, {0, 2, 4}, {0, 3, 7}, {0, 2, 3}, {0, 1, 3}, {0, 1, 4}};
        for (int cell = 0; cell < 6; ++cell) {
            for (int root = 0; root < 12; ++root) {
                int shape = 0;
                for (int k = 0; k < 3; ++k) shape |= 1 << ((root + kCells[cell][k]) % 12);
                if (shape != mask) continue;
                scanTercaRoot_ = root;
                scanTercaCell_ = cell;
                scanTercaPending_ = true;
                return;
            }
        }
    }

    void scanFinishIfReleased(int mode) noexcept {
        for (const auto refs : scanSwallowed_) if (refs != 0U) return;
        if (mode == 1 && scanTercaPending_) {
            tercaRoot_.store(scanTercaRoot_, std::memory_order_release);
            tercaCell_.store(scanTercaCell_, std::memory_order_release);
            tercaSerial_.fetch_add(1U, std::memory_order_acq_rel);
            scanTercaPending_ = false;
            scanMode_.store(0, std::memory_order_release);
        } else if (mode == 3 && scanKeyPending_) {
            keyScan_.store(scanKeyValue_, std::memory_order_release);
            keyScanSerial_.fetch_add(1U, std::memory_order_acq_rel);
            scanKeyPending_ = false;
            scanMode_.store(0, std::memory_order_release);
        } else if (mode == 2 && scanScaleCollected_ != 0) {
            scaleMask_.store(scanScaleCollected_, std::memory_order_release);
            scaleSerial_.fetch_add(1U, std::memory_order_acq_rel);
            scanScaleCollected_ = 0;
            scanMode_.store(0, std::memory_order_release);
        }
    }

    // The Manager audition has its own MIDI receiver. Never forward those
    // same messages to the Sampler COMBI or its performance/scanner state.
    void setMidiPreviewIsolation(bool blocked) noexcept {
        midiPreviewIsolation_.store(blocked, std::memory_order_release);
        if (blocked) (void)panic();
    }

    bool midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
        if (midiPreviewIsolation_.load(std::memory_order_acquire)) return true;
        if (arrangerHost().routeDrumKitPreviewMidi(status,data1,data2)) return true;
        (void)arrangerHost().observeMidi(status, data1, data2);
        const std::uint8_t kind = static_cast<std::uint8_t>(status & 0xF0U);
        const std::uint8_t ch = static_cast<std::uint8_t>(status & 0x0FU);
        {
            const bool isOn = kind == 0x90U && data2 > 0U;
            const bool isOff = kind == 0x80U || (kind == 0x90U && data2 == 0U);
            if (isOn || isOff) {
                const std::size_t n = static_cast<std::size_t>(data1 & 0x7FU);
                const int mode = scanMode_.load(std::memory_order_acquire);
                if (isOff && scanSwallowed_[n] != 0U) {
                    --scanSwallowed_[n];
                    if (mode != 0) scanFinishIfReleased(mode);
                    midiActivitySerial_.fetch_add(1U, std::memory_order_release);
                    return true;
                }
                if (isOn && mode != 0) {
                    if (scanSwallowed_[n] < 255U) ++scanSwallowed_[n];
                    scanObserveOn(mode, static_cast<std::uint8_t>(n));
                    midiActivitySerial_.fetch_add(1U, std::memory_order_release);
                    return true;
                }
            }
        }
        midiLastStatus_.store(static_cast<int>(status), std::memory_order_relaxed);
        midiLastData1_.store(static_cast<int>(data1), std::memory_order_relaxed);
        midiLastData2_.store(static_cast<int>(data2), std::memory_order_relaxed);
        if (kind == 0xB0U) ccLast_[static_cast<std::size_t>(data1 & 0x7FU)].store(static_cast<int>(data2) + 1, std::memory_order_relaxed);   // SILVETON_PEDAL_CAL_V1
        midiActivitySerial_.fetch_add(1U, std::memory_order_release);
        if(kind==0x90U&&data2>0U&&arrangerHost().manualBassConsumesKey(data1))return true;
        if (kind == 0x80U || (kind == 0x90U && data2 == 0U)) testInstrument_.noteOff(data1);
        else if (kind == 0x90U) testInstrument_.noteOn(data1, data2);
        else if (kind == 0xB0U && (data1 == 120U || data1 == 123U)) testInstrument_.panic();
        switch (kind) {
            case 0x80U: return engine_.postNoteOff(ch, data1, data2);
            case 0x90U: return data2 == 0U ? engine_.postNoteOff(ch, data1, 64U) : engine_.postNoteOn(ch, data1, data2);
            case 0xA0U: return engine_.postPolyPressure(ch, data1, data2);
            case 0xB0U: return engine_.postControlChange(ch, data1, data2);
            case 0xD0U: return engine_.postChannelPressure(ch, data1);
            case 0xE0U: {
                const int raw = static_cast<int>(data1) | (static_cast<int>(data2) << 7);
                return engine_.postPitchBend(ch, static_cast<std::int16_t>(raw - 8192));
            }
            default: return true;
        }
    }

    bool panic() noexcept { arrangerHost().panic(); testInstrument_.panic(); return engine_.postPanic(); }

    MeterSnapshot meters() const noexcept { return arrangerHost().combinedMeters(engine_.meters()); }
    int sampleRate() const noexcept { return sampleRate_.load(std::memory_order_relaxed); }
    int framesPerBurst() const noexcept { return framesPerBurst_.load(std::memory_order_relaxed); }
    int bufferSizeFrames() const noexcept { return bufferSizeFrames_.load(std::memory_order_relaxed); }
    int xrunCount() const noexcept { return xrunCount_.load(std::memory_order_relaxed); }
    int midiDeviceCount() const noexcept { return midiDeviceCount_.load(std::memory_order_relaxed); }
    int midiLastError() const noexcept { return midiLastError_.load(std::memory_order_relaxed); }
    std::uint64_t midiActivitySerial() const noexcept { return midiActivitySerial_.load(std::memory_order_acquire); }
    int midiLastStatus() const noexcept { return midiLastStatus_.load(std::memory_order_relaxed); }
    int midiLastData1() const noexcept { return midiLastData1_.load(std::memory_order_relaxed); }
    int midiLastData2() const noexcept { return midiLastData2_.load(std::memory_order_relaxed); }
    // SILVETON_PEDAL_CAL_V1: the last value of a controller (CC) that came in; -1 = none yet
    int midiCcValue(int cc) const noexcept { if (cc < 0 || cc > 127) return -1; return ccLast_[static_cast<std::size_t>(cc)].load(std::memory_order_relaxed) - 1; }
    bool blendEdited() const noexcept { return blendEdited_.load(std::memory_order_acquire); }
    std::string lastRecallMissing() const { std::lock_guard<std::mutex> lock(missingMutex_); return lastRecallMissing_; }
    bool testInstrumentEnabled() const noexcept { return testInstrument_.enabled(); }
    bool testNoteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
        if (!testInstrument_.enabled() || velocity == 0U) return false;
        testInstrument_.noteOn(note, velocity);
        return true;
    }
    void testNoteOff(std::uint8_t note) noexcept { testInstrument_.noteOff(note); }

    // Real negotiated managed-stream properties; Direct ALSA has no Android
    // sharing/performance/device identifiers and continues to report -1.
    int sharingMode() const noexcept { return sharingMode_.load(std::memory_order_relaxed); }
    int performanceMode() const noexcept { return performanceMode_.load(std::memory_order_relaxed); }
    int deviceId() const noexcept { return outputDeviceId_.load(std::memory_order_relaxed); }
    std::string outputName() const {
        if(activeManaged_.load(std::memory_order_acquire))return "Android speaker";
        if(pcmFd_.load(std::memory_order_acquire)>=0)return "Direct ALSA jack";
        return desiredWired_.load(std::memory_order_acquire)?"Jack (not open)":"Speaker (not open)";
    }

    int lastError() const noexcept { return lastError_.load(std::memory_order_relaxed); }
    bool needsRecovery() const noexcept { return recoverRequested_.load(std::memory_order_acquire); }
    bool started() const noexcept { return started_.load(std::memory_order_acquire); }

    double estimatedOutputLatencyMs() const noexcept {
        std::lock_guard<std::mutex> lock(controlMutex_);
        if(auto* stream=managedStream_.load(std::memory_order_acquire)){
            std::int64_t position=0,timeNanos=0;
            if(AAudioStream_getTimestamp(stream,CLOCK_MONOTONIC,&position,&timeNanos)!=AAUDIO_OK)return -1.0;
            const auto written=AAudioStream_getFramesWritten(stream);
            const int rate=sampleRate();
            if(rate<=0||written<position)return -1.0;
            return static_cast<double>(written-position)*1000.0/static_cast<double>(rate);
        }
        const int fd = pcmFd_.load(std::memory_order_acquire);
        const int sr = sampleRate();
        if (fd < 0 || sr <= 0) return -1.0;
        snd_pcm_sframes_t delayFrames = 0;
        if (::ioctl(fd, SNDRV_PCM_IOCTL_DELAY, &delayFrames) < 0) return -1.0;
        const double queued = std::max(0.0, static_cast<double>(delayFrames));
        return queued * 1000.0 / static_cast<double>(sr);
    }

    std::string textError() const {
        std::lock_guard<std::mutex> lock(errorMutex_);
        return textError_;
    }

private:
    struct PcmConfig {
        unsigned requestedRate{0U};
        unsigned requestedPeriods{0U};
        unsigned rate{0U};
        unsigned periodFrames{0U};
        unsigned periods{0U};
        unsigned bufferFrames{0U};
    };

    struct MidiParserState {
        std::uint8_t runningStatus{0U};
        std::uint8_t pendingStatus{0U};
        std::uint8_t needed{0U};
        std::uint8_t count{0U};
        std::array<std::uint8_t, 2> data{};
        bool inSysEx{false};
    };

    struct RawMidiPort {
        std::string path;
        int fd{-1};
        MidiParserState parser{};
        MidiHeldState held{};
    };

    static constexpr const char* kPcmDevice = "/dev/snd/pcmC0D0p";
    static constexpr const char* kControlDevice = "/dev/snd/controlC0";
    static constexpr const char* kAlsaDeviceDirectory = "/dev/snd";
    static constexpr unsigned kChannels = 2U;
    static constexpr unsigned kPreferredMinimumPeriodFrames = 96U;
    static constexpr std::size_t kMaxRawMidiPorts = 16U;

    static bool isRawMidiNodeName(const char* name) noexcept {
        if (name == nullptr || std::strncmp(name, "midiC", 5U) != 0) return false;
        const char* p = name + 5;
        if (*p < '0' || *p > '9') return false;
        while (*p >= '0' && *p <= '9') ++p;
        if (*p != 'D') return false;
        ++p;
        if (*p < '0' || *p > '9') return false;
        while (*p >= '0' && *p <= '9') ++p;
        return *p == '\0';
    }

    static std::uint8_t midiDataBytesForStatus(std::uint8_t status) noexcept {
        if (status >= 0x80U && status <= 0xBFU) return 2U;
        if (status >= 0xC0U && status <= 0xDFU) return 1U;
        if (status >= 0xE0U && status <= 0xEFU) return 2U;
        if (status == 0xF1U || status == 0xF3U) return 1U;
        if (status == 0xF2U) return 2U;
        return 0U;
    }

    static void resetMidiParser(MidiParserState& parser) noexcept {
        parser = MidiParserState{};
    }

    std::vector<std::string> discoverRawMidiPaths() noexcept {
        std::vector<std::string> paths;
        DIR* dir = ::opendir(kAlsaDeviceDirectory);
        if (dir == nullptr) {
            midiLastError_.store(-errno, std::memory_order_relaxed);
            return paths;
        }

        while (dirent* entry = ::readdir(dir)) {
            if (!isRawMidiNodeName(entry->d_name)) continue;
            paths.emplace_back(std::string(kAlsaDeviceDirectory) + "/" + entry->d_name);
        }
        (void)::closedir(dir);
        std::sort(paths.begin(), paths.end());
        paths.erase(std::unique(paths.begin(), paths.end()), paths.end());
        return paths;
    }

    static int openRawMidiInput(const std::string& path) noexcept {
        const int fd = ::open(path.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) return -1;

        snd_rawmidi_params params{};
        params.stream = SNDRV_RAWMIDI_STREAM_INPUT;
        params.buffer_size = 4096U;
        params.avail_min = 1U;
        params.no_active_sensing = 0U;
        params.mode = 0U;
        if (::ioctl(fd, SNDRV_RAWMIDI_IOCTL_PARAMS, &params) < 0) {
            const int saved = errno;
            (void)::close(fd);
            errno = saved;
            return -1;
        }
        return fd;
    }

    // releaseHeld: the keys and the pedal this port held are let go (only from the MIDI thread)
    void closeRawMidiPort(RawMidiPort& port, bool releaseHeld = true) noexcept {
        if (port.fd >= 0) (void)::close(port.fd);
        port.fd = -1;
        resetMidiParser(port.parser);
        if (releaseHeld) {
            const auto config = damperConfig_.load(std::memory_order_acquire);
            port.held.release([this](std::uint8_t status, std::uint8_t key, std::uint8_t value) {
                (void)midi(status, key, value);
            }, static_cast<std::uint8_t>(config & 0x7FU), (config & 0x80U) != 0U);
        } else {
            port.held.reset();
        }
    }

    void syncRawMidiPorts() noexcept {
        const auto discovered = discoverRawMidiPaths();

        for (auto it = rawMidiPorts_.begin(); it != rawMidiPorts_.end();) {
            if (std::find(discovered.begin(), discovered.end(), it->path) != discovered.end()) {
                ++it;
                continue;
            }
            __android_log_print(ANDROID_LOG_INFO, kTag, "Direct MIDI detached: %s", it->path.c_str());
            closeRawMidiPort(*it);
            it = rawMidiPorts_.erase(it);
        }

        // SILVETON_ALL_MIDI_PORTS_V1: one USB MIDI device can carry several MIDI
        // ports inside one node (e.g. a Korg sends its keys on port 1 and what
        // comes into its MIDI IN on port 2). Each open of the node takes the next
        // free input port, so the node is opened once per port it has.
        int firstOpenError = 0;
        for (const auto& path : discovered) {
            const auto openCount = static_cast<unsigned>(std::count_if(rawMidiPorts_.begin(), rawMidiPorts_.end(),
                [&](const RawMidiPort& port) { return port.path == path && port.fd >= 0; }));
            if (openCount > 0U || rawMidiPorts_.size() >= kMaxRawMidiPorts) continue;

            const int fd = openRawMidiInput(path);
            if (fd < 0) {
                if (firstOpenError == 0) firstOpenError = -errno;
                continue;
            }
            unsigned inputPorts = 1U;
            snd_rawmidi_info info{};
            info.stream = SNDRV_RAWMIDI_STREAM_INPUT;
            if (::ioctl(fd, SNDRV_RAWMIDI_IOCTL_INFO, &info) == 0 && info.subdevices_count > 1U) {
                inputPorts = std::min<unsigned>(info.subdevices_count, 8U);
            }

            RawMidiPort port{};
            port.path = path;
            port.fd = fd;
            rawMidiPorts_.push_back(std::move(port));
            __android_log_print(ANDROID_LOG_INFO, kTag, "Direct MIDI attached: %s (%u ports)", path.c_str(), inputPorts);

            for (unsigned extra = 1U; extra < inputPorts && rawMidiPorts_.size() < kMaxRawMidiPorts; ++extra) {
                const int more = openRawMidiInput(path);
                if (more < 0) break;
                RawMidiPort next{};
                next.path = path;
                next.fd = more;
                rawMidiPorts_.push_back(std::move(next));
            }
        }

        midiDeviceCount_.store(static_cast<int>(rawMidiPorts_.size()), std::memory_order_relaxed);
        if (!rawMidiPorts_.empty() || discovered.empty()) {
            midiLastError_.store(0, std::memory_order_relaxed);
        } else if (firstOpenError != 0) {
            midiLastError_.store(firstOpenError, std::memory_order_relaxed);
        }
    }

    void dispatchRawMidiMessage(RawMidiPort& port, std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
        if (status >= 0xF0U) return;
        const std::uint8_t kind = static_cast<std::uint8_t>(status & 0xF0U);
        port.held.track(status, data1, data2);
        switch (kind) {
            case 0x80U:
            case 0x90U:
            case 0xB0U:
            case 0xD0U:
            case 0xE0U:
                (void)midi(status, data1, data2);
                break;
            default:
                break;
        }
    }

    void feedRawMidiByte(RawMidiPort& port, std::uint8_t byte) noexcept {
        auto& parser = port.parser;

        // System realtime bytes can be interleaved anywhere and do not alter
        // channel-message running status. The sampler does not consume them.
        if (byte >= 0xF8U) return;

        if (parser.inSysEx) {
            if (byte == 0xF7U) parser.inSysEx = false;
            return;
        }

        if ((byte & 0x80U) != 0U) {
            if (byte == 0xF0U) {
                resetMidiParser(parser);
                parser.inSysEx = true;
                return;
            }

            parser.pendingStatus = byte;
            parser.count = 0U;
            parser.needed = midiDataBytesForStatus(byte);
            parser.runningStatus = byte < 0xF0U ? byte : 0U;
            if (parser.needed == 0U) parser.pendingStatus = 0U;
            return;
        }

        if (parser.pendingStatus == 0U) {
            if (parser.runningStatus == 0U) return;
            parser.pendingStatus = parser.runningStatus;
            parser.needed = midiDataBytesForStatus(parser.runningStatus);
            parser.count = 0U;
        }

        if (parser.count < parser.data.size()) parser.data[parser.count] = static_cast<std::uint8_t>(byte & 0x7FU);
        ++parser.count;
        if (parser.count < parser.needed) return;

        const std::uint8_t status = parser.pendingStatus;
        const std::uint8_t data1 = parser.needed >= 1U ? parser.data[0] : 0U;
        const std::uint8_t data2 = parser.needed >= 2U ? parser.data[1] : 0U;
        dispatchRawMidiMessage(port, status, data1, data2);

        parser.pendingStatus = parser.runningStatus;
        parser.count = 0U;
        parser.needed = parser.pendingStatus != 0U ? midiDataBytesForStatus(parser.pendingStatus) : 0U;
    }

    void directMidiLoop() noexcept {
        const auto& placement = deviceCpuWorkPolicy();
        configureRealtimeThread("SilvMidiRT", placement.midiFirstCpu, placement.midiLastCpu, 75);
        auto nextScan = std::chrono::steady_clock::now();
        std::array<pollfd, kMaxRawMidiPorts> pollFds{};
        std::array<std::uint8_t, 256U> readBuffer{};

        while (midiThreadRun_.load(std::memory_order_acquire)) {
            const auto now = std::chrono::steady_clock::now();
            if (now >= nextScan) {
                syncRawMidiPorts();
                nextScan = now + std::chrono::milliseconds(250);
            }

            const std::size_t count = std::min(rawMidiPorts_.size(), pollFds.size());
            if (count == 0U) {
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                continue;
            }

            for (std::size_t i = 0U; i < count; ++i) {
                pollFds[i].fd = rawMidiPorts_[i].fd;
                pollFds[i].events = POLLIN;
                pollFds[i].revents = 0;
            }

            const int ready = ::poll(pollFds.data(), static_cast<nfds_t>(count), 1);
            if (ready < 0) {
                if (errno == EINTR) continue;
                midiLastError_.store(-errno, std::memory_order_relaxed);
                continue;
            }
            if (ready == 0) continue;

            bool rescanSoon = false;
            for (std::size_t i = 0U; i < count; ++i) {
                if ((pollFds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
                    closeRawMidiPort(rawMidiPorts_[i]);
                    rescanSoon = true;
                    continue;
                }
                if ((pollFds[i].revents & POLLIN) == 0) continue;

                for (;;) {
                    const ssize_t bytesRead = ::read(rawMidiPorts_[i].fd, readBuffer.data(), readBuffer.size());
                    if (bytesRead > 0) {
                        for (ssize_t b = 0; b < bytesRead; ++b) feedRawMidiByte(rawMidiPorts_[i], readBuffer[static_cast<std::size_t>(b)]);
                        continue;
                    }
                    if (bytesRead == 0) {
                        closeRawMidiPort(rawMidiPorts_[i]);
                        rescanSoon = true;
                    } else if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
                        midiLastError_.store(-errno, std::memory_order_relaxed);
                        closeRawMidiPort(rawMidiPorts_[i]);
                        rescanSoon = true;
                    }
                    break;
                }
            }

            if (rescanSoon) {
                rawMidiPorts_.erase(
                    std::remove_if(rawMidiPorts_.begin(), rawMidiPorts_.end(), [](const RawMidiPort& port) { return port.fd < 0; }),
                    rawMidiPorts_.end());
                midiDeviceCount_.store(static_cast<int>(rawMidiPorts_.size()), std::memory_order_relaxed);
                nextScan = std::chrono::steady_clock::now();
            }
        }

        for (auto& port : rawMidiPorts_) closeRawMidiPort(port, false);
        rawMidiPorts_.clear();
        midiDeviceCount_.store(0, std::memory_order_relaxed);
    }

    bool startDirectMidiLocked() {
        if (midiThreadRun_.load(std::memory_order_acquire)) return true;
        midiLastError_.store(0, std::memory_order_relaxed);
        midiThreadRun_.store(true, std::memory_order_release);
        try {
            midiThread_ = std::thread(&AndroidSamplerAudio::directMidiLoop, this);
        } catch (...) {
            midiThreadRun_.store(false, std::memory_order_release);
            midiLastError_.store(-EAGAIN, std::memory_order_relaxed);
            setTextError("Direct ALSA MIDI thread could not be created");
            return false;
        }
        return true;
    }

    void stopDirectMidiLocked() noexcept {
        midiThreadRun_.store(false, std::memory_order_release);
        if (midiThread_.joinable()) midiThread_.join();
        midiDeviceCount_.store(0, std::memory_order_relaxed);
    }

    static bool isMaskParam(int param) noexcept {
        return param >= SNDRV_PCM_HW_PARAM_FIRST_MASK && param <= SNDRV_PCM_HW_PARAM_LAST_MASK;
    }

    static bool isIntervalParam(int param) noexcept {
        return param >= SNDRV_PCM_HW_PARAM_FIRST_INTERVAL && param <= SNDRV_PCM_HW_PARAM_LAST_INTERVAL;
    }

    static snd_mask* maskParam(snd_pcm_hw_params& params, int param) noexcept {
        return &params.masks[param - SNDRV_PCM_HW_PARAM_FIRST_MASK];
    }

    static snd_interval* intervalParam(snd_pcm_hw_params& params, int param) noexcept {
        return &params.intervals[param - SNDRV_PCM_HW_PARAM_FIRST_INTERVAL];
    }

    static void initHwParams(snd_pcm_hw_params& params) noexcept {
        std::memset(&params, 0, sizeof(params));
        for (int param = SNDRV_PCM_HW_PARAM_FIRST_MASK; param <= SNDRV_PCM_HW_PARAM_LAST_MASK; ++param) {
            auto* mask = maskParam(params, param);
            for (auto& word : mask->bits) word = ~0U;
        }
        for (int param = SNDRV_PCM_HW_PARAM_FIRST_INTERVAL; param <= SNDRV_PCM_HW_PARAM_LAST_INTERVAL; ++param) {
            auto* interval = intervalParam(params, param);
            interval->min = 0U;
            interval->max = ~0U;
        }
        params.rmask = ~0U;
        params.cmask = 0U;
        params.info = ~0U;
    }

    static void setMaskParam(snd_pcm_hw_params& params, int param, unsigned bit) noexcept {
        if (!isMaskParam(param) || bit >= SNDRV_MASK_MAX) return;
        auto* mask = maskParam(params, param);
        std::memset(mask, 0, sizeof(*mask));
        mask->bits[bit >> 5U] |= (1U << (bit & 31U));
    }

    static void setIntParam(snd_pcm_hw_params& params, int param, unsigned value) noexcept {
        if (!isIntervalParam(param)) return;
        auto* interval = intervalParam(params, param);
        std::memset(interval, 0, sizeof(*interval));
        interval->min = value;
        interval->max = value;
        interval->integer = 1U;
    }

    static void setMinParam(snd_pcm_hw_params& params, int param, unsigned value) noexcept {
        if (!isIntervalParam(param)) return;
        auto* interval = intervalParam(params, param);
        interval->min = value;
        interval->openmin = 0U;
    }

    static unsigned getMinParam(snd_pcm_hw_params& params, int param) noexcept {
        return isIntervalParam(param) ? intervalParam(params, param)->min : 0U;
    }

    static std::optional<snd_ctl_elem_id> findControlId(int fd, const char* name) noexcept {
        if (fd < 0 || name == nullptr) return std::nullopt;
        snd_ctl_elem_list list{};
        if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_LIST, &list) < 0 || list.count == 0U) return std::nullopt;

        std::vector<snd_ctl_elem_id> ids(list.count);
        list.offset = 0U;
        list.space = list.count;
        list.pids = ids.data();
        if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_LIST, &list) < 0) return std::nullopt;

        const unsigned used = std::min<unsigned>(list.used, static_cast<unsigned>(ids.size()));
        for (unsigned i = 0U; i < used; ++i) {
            const char* controlName = reinterpret_cast<const char*>(ids[i].name);
            if (std::strncmp(controlName, name, SNDRV_CTL_ELEM_ID_NAME_MAXLEN) == 0) return ids[i];
        }
        return std::nullopt;
    }

    static bool setIntegerControl(int fd, const char* name, long first, long second, int& errorOut) noexcept {
        const auto id = findControlId(fd, name);
        if (!id.has_value()) { errorOut = -ENOENT; return false; }

        snd_ctl_elem_info info{};
        info.id = *id;
        if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_INFO, &info) < 0) { errorOut = -errno; return false; }
        if (info.type != SNDRV_CTL_ELEM_TYPE_BOOLEAN && info.type != SNDRV_CTL_ELEM_TYPE_INTEGER) {
            errorOut = -EINVAL;
            return false;
        }

        snd_ctl_elem_value value{};
        value.id = *id;
        const unsigned count = std::min<unsigned>(info.count, 128U);
        for (unsigned i = 0U; i < count; ++i) value.value.integer.value[i] = (i == 0U) ? first : second;
        if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_WRITE, &value) < 0) { errorOut = -errno; return false; }
        errorOut = 0;
        return true;
    }

    static bool setEnumControl(int fd, const char* name, const char* itemName, int& errorOut) noexcept {
        const auto id = findControlId(fd, name);
        if (!id.has_value()) { errorOut = -ENOENT; return false; }

        snd_ctl_elem_info info{};
        info.id = *id;
        if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_INFO, &info) < 0) { errorOut = -errno; return false; }
        if (info.type != SNDRV_CTL_ELEM_TYPE_ENUMERATED || info.value.enumerated.items == 0U) {
            errorOut = -EINVAL;
            return false;
        }

        unsigned selected = info.value.enumerated.items;
        for (unsigned item = 0U; item < info.value.enumerated.items; ++item) {
            snd_ctl_elem_info itemInfo{};
            itemInfo.id = *id;
            itemInfo.value.enumerated.item = item;
            if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_INFO, &itemInfo) < 0) { errorOut = -errno; return false; }
            if (std::strncmp(itemInfo.value.enumerated.name, itemName, sizeof(itemInfo.value.enumerated.name)) == 0) {
                selected = item;
                break;
            }
        }
        if (selected >= info.value.enumerated.items) { errorOut = -ENOENT; return false; }

        snd_ctl_elem_value value{};
        value.id = *id;
        const unsigned count = std::min<unsigned>(info.count, 128U);
        for (unsigned i = 0U; i < count; ++i) value.value.enumerated.item[i] = selected;
        if (::ioctl(fd, SNDRV_CTL_IOCTL_ELEM_WRITE, &value) < 0) { errorOut = -errno; return false; }
        errorOut = 0;
        return true;
    }

    struct RouteTarget {
        snd_ctl_elem_id id{};
        bool enumerated{false};
        unsigned count{0U};
        long value{0};
    };

    bool scanRouteLocked() {
        routeTargets_.clear();
        snd_ctl_elem_list list{};
        if (::ioctl(routeFd_, SNDRV_CTL_IOCTL_ELEM_LIST, &list) < 0 || list.count == 0U) return false;
        std::vector<snd_ctl_elem_id> ids(list.count);
        list.offset = 0U;
        list.space = list.count;
        list.pids = ids.data();
        if (::ioctl(routeFd_, SNDRV_CTL_IOCTL_ELEM_LIST, &list) < 0) return false;
        const unsigned used = std::min<unsigned>(list.used, static_cast<unsigned>(ids.size()));
        for (unsigned i = 0U; i < used; ++i) {
            const char* raw = reinterpret_cast<const char*>(ids[i].name);
            const std::string name(raw, ::strnlen(raw, SNDRV_CTL_ELEM_ID_NAME_MAXLEN));
            snd_ctl_elem_info info{};
            info.id = ids[i];
            if (::ioctl(routeFd_, SNDRV_CTL_IOCTL_ELEM_INFO, &info) < 0) continue;
            const bool isSwitch = info.type == SNDRV_CTL_ELEM_TYPE_BOOLEAN ||
                (info.type == SNDRV_CTL_ELEM_TYPE_INTEGER && info.value.integer.min == 0 && info.value.integer.max == 1);
            RouteTarget t;
            t.id = info.id;
            t.count = std::min<unsigned>(info.count, 128U);
            if (t.count == 0U) continue;
            if (name == "ADDA_DL_CH1 DL1_CH1" || name == "ADDA_DL_CH2 DL1_CH2") {
                if (!isSwitch) continue;
                t.value = 1;                                   // DL1 -> headphone DAC
            } else if (isSwitch && (name.find(" DL1_CH") != std::string::npos || name.rfind("ADDA_DL_CH", 0) == 0)) {
                t.value = 0;                                   // DL1 nowhere else, nothing else into the DAC
            } else if (info.type == SNDRV_CTL_ELEM_TYPE_ENUMERATED) {
                const char* want = name == "DAC In Mux" ? "Normal Path"
                    : (name == "HPL Mux" || name == "HPR Mux") ? "Audio Playback"
                    : name == "LOL Mux" ? "Open" : nullptr;   // line-out (speaker) off
                if (want == nullptr) continue;
                bool found = false;
                for (unsigned item = 0U; item < info.value.enumerated.items; ++item) {
                    snd_ctl_elem_info itemInfo{};
                    itemInfo.id = info.id;
                    itemInfo.value.enumerated.item = item;
                    if (::ioctl(routeFd_, SNDRV_CTL_IOCTL_ELEM_INFO, &itemInfo) < 0) break;
                    if (std::strncmp(itemInfo.value.enumerated.name, want, sizeof(itemInfo.value.enumerated.name)) == 0) {
                        t.value = static_cast<long>(item);
                        found = true;
                        break;
                    }
                }
                if (!found) continue;
                t.enumerated = true;
            } else if (name == "Headset Volume" && info.type == SNDRV_CTL_ELEM_TYPE_INTEGER &&
                       info.value.integer.min <= 12 && info.value.integer.max >= 12) {
                t.value = 12;                                  // never above 12
            } else {
                continue;
            }
            routeTargets_.push_back(t);
        }
        return true;
    }

    // Number of controls that had to be changed back, -1 on error.
    int applyRouteLocked() {
        int changed = 0;
        for (const auto& t : routeTargets_) {
            snd_ctl_elem_value now{};
            now.id = t.id;
            if (::ioctl(routeFd_, SNDRV_CTL_IOCTL_ELEM_READ, &now) < 0) return -1;
            bool same = true;
            for (unsigned i = 0U; i < t.count; ++i) {
                if (t.enumerated ? now.value.enumerated.item[i] != static_cast<unsigned>(t.value)
                                 : now.value.integer.value[i] != t.value) { same = false; break; }
            }
            if (same) continue;
            snd_ctl_elem_value want{};
            want.id = t.id;
            for (unsigned i = 0U; i < t.count; ++i) {
                if (t.enumerated) want.value.enumerated.item[i] = static_cast<unsigned>(t.value);
                else want.value.integer.value[i] = t.value;
            }
            if (::ioctl(routeFd_, SNDRV_CTL_IOCTL_ELEM_WRITE, &want) < 0) return -1;
            ++changed;
        }
        return changed;
    }

    bool configureOutputRouteLocked() {
        const int fd = ::open(kControlDevice, O_RDWR | O_CLOEXEC);
        if (fd < 0) {
            lastError_.store(-errno, std::memory_order_relaxed);
            return false;
        }

        int error = 0;
        const bool ok = setIntegerControl(fd, "ADDA_DL_CH1 DL1_CH1", 1L, 1L, error)
            && setIntegerControl(fd, "ADDA_DL_CH2 DL1_CH2", 1L, 1L, error)
            && setEnumControl(fd, "DAC In Mux", "Normal Path", error)
            && setEnumControl(fd, "HPL Mux", "Audio Playback", error)
            && setEnumControl(fd, "HPR Mux", "Audio Playback", error);

        if (ok) {
            int volumeError = 0;
            (void)setIntegerControl(fd, "Headset Volume", 12L, 12L, volumeError);
        }

        const int closeResult = ::close(fd);
        if (!ok) {
            lastError_.store(error == 0 ? -EIO : error, std::memory_order_relaxed);
            return false;
        }
        if (closeResult < 0) {
            lastError_.store(-errno, std::memory_order_relaxed);
            return false;
        }

        __android_log_print(ANDROID_LOG_INFO, kTag, "Direct ALSA SM-X130 output route configured");
        return true;
    }

    static int openPcmNode() noexcept {
        return ::open(kPcmDevice, O_RDWR | O_CLOEXEC);
    }

    static void releasePcmFd(int fd) noexcept {
        if (fd < 0) return;
        (void)::ioctl(fd, SNDRV_PCM_IOCTL_DROP);
        (void)::ioctl(fd, SNDRV_PCM_IOCTL_HW_FREE);
        (void)::close(fd);
    }

    static bool configurePcmFd(
        int fd,
        unsigned requestedRate,
        unsigned requestedPeriods,
        unsigned requestedPeriodFrames,
        PcmConfig& config,
        int& errorOut) noexcept {
        if (fd < 0) {
            errorOut = -EBADF;
            return false;
        }

        snd_pcm_hw_params params{};
        initHwParams(params);
        setMaskParam(params, SNDRV_PCM_HW_PARAM_ACCESS, static_cast<unsigned>(SNDRV_PCM_ACCESS_RW_INTERLEAVED));
        setMaskParam(params, SNDRV_PCM_HW_PARAM_FORMAT, static_cast<unsigned>(SNDRV_PCM_FORMAT_S16_LE));
        setMaskParam(params, SNDRV_PCM_HW_PARAM_SUBFORMAT, static_cast<unsigned>(SNDRV_PCM_SUBFORMAT_STD));
        setIntParam(params, SNDRV_PCM_HW_PARAM_SAMPLE_BITS, 16U);
        setIntParam(params, SNDRV_PCM_HW_PARAM_FRAME_BITS, 16U * kChannels);
        setIntParam(params, SNDRV_PCM_HW_PARAM_CHANNELS, kChannels);
        setIntParam(params, SNDRV_PCM_HW_PARAM_RATE, requestedRate);
        // Physical SM-X130 validation proved exactly 96 frames x 2 at 96 kHz.
        setIntParam(params, SNDRV_PCM_HW_PARAM_PERIOD_SIZE, requestedPeriodFrames);
        setIntParam(params, SNDRV_PCM_HW_PARAM_PERIODS, requestedPeriods);
        params.flags |= SNDRV_PCM_HW_PARAMS_NORESAMPLE;

        if (::ioctl(fd, SNDRV_PCM_IOCTL_HW_PARAMS, &params) < 0) {
            errorOut = -errno;
            return false;
        }

        config.requestedRate = requestedRate;
        config.requestedPeriods = requestedPeriods;
        config.rate = getMinParam(params, SNDRV_PCM_HW_PARAM_RATE);
        config.periodFrames = getMinParam(params, SNDRV_PCM_HW_PARAM_PERIOD_SIZE);
        config.periods = getMinParam(params, SNDRV_PCM_HW_PARAM_PERIODS);
        config.bufferFrames = getMinParam(params, SNDRV_PCM_HW_PARAM_BUFFER_SIZE);

        if (config.rate == 0U) config.rate = requestedRate;
        if (config.periodFrames == 0U) config.periodFrames = requestedPeriodFrames;
        if (config.periods == 0U) config.periods = requestedPeriods;
        if (config.bufferFrames == 0U) config.bufferFrames = config.periodFrames * config.periods;

        if (config.rate != requestedRate
            || config.periodFrames != requestedPeriodFrames
            || config.periods != requestedPeriods
            || config.bufferFrames != config.periodFrames * config.periods) {
            errorOut = -EINVAL;
            return false;
        }

        snd_pcm_sw_params sw{};
        sw.tstamp_mode = SNDRV_PCM_TSTAMP_ENABLE;
        sw.period_step = 1U;
        sw.avail_min = static_cast<snd_pcm_uframes_t>(config.periodFrames);
        sw.start_threshold = static_cast<snd_pcm_uframes_t>(
            config.bufferFrames - config.periodFrames);
        sw.stop_threshold = static_cast<snd_pcm_uframes_t>(config.bufferFrames);
        sw.xfer_align = 1U;
        sw.silence_threshold = 0U;
        sw.silence_size = 0U;

        if (::ioctl(fd, SNDRV_PCM_IOCTL_SW_PARAMS, &sw) < 0) {
            errorOut = -errno;
            return false;
        }
        if (::ioctl(fd, SNDRV_PCM_IOCTL_PREPARE) < 0) {
            errorOut = -errno;
            return false;
        }

        errorOut = 0;
        return true;
    }

    static double queueCapacityMs(const PcmConfig& config) noexcept {
        if (config.rate == 0U) return std::numeric_limits<double>::infinity();
        return static_cast<double>(config.bufferFrames) * 1000.0 / static_cast<double>(config.rate);
    }

    bool chooseAndOpenPcmLocked() {
        // Direct ALSA bypasses Android AudioPolicy. The hardware profile proven on the
        // physical SM-X130 is 96 kHz / 96 x 2.
        constexpr unsigned kRate = 96000U;
        constexpr unsigned kPeriods = 2U;
        // SILVETON_HALF_RATE_V1 is off: the player keeps the proven 96 kHz / 96 x 2 profile,
        // so the delay stays at 2 ms. (Half the rate would halve the work for the voices; the
        // kernels already follow whatever rate the sound leaves at, so it can be tried again
        // later by asking for kRate / 2 with half the portion before this one.)
        PcmConfig selected{};
        int error = 0;
        int fd = openPcmNode();
        if (fd < 0) {
            const int openError = -errno;
            lastError_.store(openError, std::memory_order_relaxed);
            if (openError == -EACCES || openError == -EPERM) {
                recoverRequested_.store(true, std::memory_order_release);
            }
            return false;
        }
        if (!configurePcmFd(fd, kRate, kPeriods, kPreferredMinimumPeriodFrames, selected, error)) {
            releasePcmFd(fd);
            lastError_.store(error, std::memory_order_relaxed);
            return false;
        }

        pcmFd_.store(fd, std::memory_order_release);
        sampleRate_.store(static_cast<int>(selected.rate), std::memory_order_relaxed);
        framesPerBurst_.store(static_cast<int>(selected.periodFrames), std::memory_order_relaxed);
        bufferSizeFrames_.store(static_cast<int>(selected.bufferFrames), std::memory_order_relaxed);
        periodCount_.store(static_cast<int>(selected.periods), std::memory_order_relaxed);

        const std::size_t sampleCount = static_cast<std::size_t>(selected.periodFrames) * kChannels;
        renderBuffer_.assign(sampleCount, 0.0F);
        pcmBuffer_.assign(sampleCount, 0);

        __android_log_print(
            ANDROID_LOG_INFO, kTag,
            "Direct ALSA locked %s: %u Hz, period=%u, periods=%u, buffer=%u (%.3f ms)",
            kPcmDevice, selected.rate, selected.periodFrames, selected.periods,
            selected.bufferFrames, queueCapacityMs(selected));
        return true;
    }

    bool openDirectLocked() {
        if (pcmFd_.load(std::memory_order_acquire) >= 0) return true;
        // Mixer route is configured by the privileged pre-open root gate.
        // The APK itself only owns the PCM realtime path.
        (void)enforceHeadphoneRoute(false);
        bool opened = chooseAndOpenPcmLocked();
        std::string routeNote;
        // SILVETON_ROUTE_FALLBACK_V1: EINVAL from the PCM means DL1 has no
        // connected output path (the MediaTek DL1 -> DAC mixer route is not
        // set: root tinymix missing/failed, or Android reset the route). Set the
        // same proven SM-X130 route directly from this control thread (never
        // the realtime audio thread) and open the same 96 kHz / 96 x 2 again.
        for (int routeAttempt = 0;
             !opened && routeAttempt < 3 && lastError_.load(std::memory_order_relaxed) == -EINVAL;
             ++routeAttempt) {
            if (routeAttempt > 0) std::this_thread::sleep_for(std::chrono::milliseconds(60));
            const bool routed = configureOutputRouteLocked();
            const int routeError = routed ? 0 : lastError_.load(std::memory_order_relaxed);
            routeNote = routed
                ? std::string(" [route set by app]")
                : std::string(" [route failed errno ") + std::to_string(-routeError) + "]";
            lastError_.store(-EINVAL, std::memory_order_relaxed);
            opened = chooseAndOpenPcmLocked();
        }
        if (!opened) {
            const int error = lastError_.load(std::memory_order_relaxed);
            if(error==-EBUSY)recoverRequested_.store(true,std::memory_order_release);
            if (error == -EACCES || error == -EPERM) {
                recoverRequested_.store(true, std::memory_order_release);
                setTextError("Direct ALSA permission denied for /dev/snd. Install the SILVETON SM-X130 audio privilege module.");
            } else {
                setTextError(
                    std::string("AUDIO DRIVER: PCM open/config failed ") + kPcmDevice
                    + " (errno " + std::to_string(-error) + ")"
                    + (error == -EBUSY ? " [PCM BUSY]" : "") + routeNote);
            }
            return false;
        }
        if (!routeNote.empty()) {
            __android_log_print(ANDROID_LOG_INFO, kTag, "Direct ALSA opened after app route fallback");
        }

        activeManaged_.store(false,std::memory_order_release);
        sharingMode_.store(-1,std::memory_order_relaxed);
        performanceMode_.store(-1,std::memory_order_relaxed);
        outputDeviceId_.store(-1,std::memory_order_relaxed);
        return true;
    }

    static constexpr int kManagedRenderFrames=96;

    static aaudio_data_callback_result_t managedDataCallback(AAudioStream* stream,void* user,void* audioData,std::int32_t frameCount) noexcept {
        auto& self=*static_cast<AndroidSamplerAudio*>(user);
        auto* destination=static_cast<float*>(audioData);
        if(frameCount<=0||!destination){
            self.lastError_.store(AAUDIO_ERROR_ILLEGAL_ARGUMENT,std::memory_order_relaxed);
            self.recoverRequested_.store(true,std::memory_order_release);
            self.started_.store(false,std::memory_order_release);
            self.threadRun_.store(false,std::memory_order_release);return AAUDIO_CALLBACK_RESULT_STOP;
        }
        if(!self.threadRun_.load(std::memory_order_acquire)||self.managedStream_.load(std::memory_order_acquire)!=stream){
            std::fill_n(destination,static_cast<std::size_t>(frameCount)*kChannels,0.0F);
            return AAUDIO_CALLBACK_RESULT_STOP;
        }
        if(!self.managedThreadConfigured_.exchange(true,std::memory_order_acq_rel)){
            const auto policy=deviceCpuWorkPolicy();
            configureRealtimeThread("SilvAudioRT",policy.audioCpu,policy.audioCpu,80);
            diagnostics::setAudioThreadId(static_cast<int>(::gettid()));
#if defined(__aarch64__)
            std::uint64_t fpcr=0U;__asm__ __volatile__("mrs %0, fpcr":"=r"(fpcr));
            fpcr|=(std::uint64_t{1}<<24);__asm__ __volatile__("msr fpcr, %0"::"r"(fpcr));
#endif
        }
        const auto dspStarted=std::chrono::steady_clock::now();
        std::uint64_t clippedSamples=0;
        float outputPeak=0.0F;
        std::int32_t offset=0;
        while(offset<frameCount){
            const auto frames=static_cast<std::uint32_t>(std::min(kManagedRenderFrames,frameCount-offset));
            auto* output=destination+static_cast<std::size_t>(offset)*kChannels;
            self.engine_.setSourceTempo(arrangerHost().keyboardSourceTempo());
            self.engine_.setLowerMemoryEnabled(arrangerHost().lowerMemoryActive());
            self.engine_.render(output,frames);
            self.testInstrument_.render(output,frames,self.sampleRate());
            arrangerHost().renderAdd(output,frames,static_cast<double>(self.sampleRate()));
            const auto samples=static_cast<std::size_t>(frames)*kChannels;
            for(std::size_t sample=0;sample<samples;++sample){
                const float magnitude=std::fabs(output[sample]);
                outputPeak=std::max(outputPeak,magnitude);
                if(magnitude>1.0F)++clippedSamples;
                output[sample]=std::clamp(output[sample],-1.0F,1.0F);
            }
            offset+=static_cast<std::int32_t>(frames);
        }
        diagnostics::recordOutput(clippedSamples,outputPeak);
        const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-dspStarted).count();
        diagnostics::recordAudioBlock(elapsed*1000.0,static_cast<std::uint32_t>(frameCount),self.sampleRate());
        arrangerHost().recordBlockCost(static_cast<float>(100.0*elapsed*static_cast<double>(self.sampleRate())/static_cast<double>(frameCount)));
        const auto xruns=AAudioStream_getXRunCount(stream);
        if(xruns>=0)self.xrunCount_.store(xruns,std::memory_order_relaxed);
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }
    static void managedErrorCallback(AAudioStream* stream,void* user,aaudio_result_t error) noexcept {
        auto& self=*static_cast<AndroidSamplerAudio*>(user);
        if(self.managedStream_.load(std::memory_order_acquire)!=stream)return;
        self.lastError_.store(error,std::memory_order_relaxed);
        self.recoverRequested_.store(true,std::memory_order_release);
        self.threadRun_.store(false,std::memory_order_release);
        self.started_.store(false,std::memory_order_release);
        // Never stop/close or call control code on AAudio's error callback.
    }
    void closeManagedLocked() noexcept {
        auto* stream=managedStream_.load(std::memory_order_acquire);
        if(!stream)return;
        threadRun_.store(false,std::memory_order_release);
        (void)AAudioStream_requestStop(stream);
        // Wait outside audio/error callbacks. close() then joins AAudio's
        // callback machinery before the DSP can be re-prepared or destroyed.
        for(unsigned attempt=0;attempt<10U;++attempt){
            const auto state=AAudioStream_getState(stream);
            if(state!=AAUDIO_STREAM_STATE_STARTED&&state!=AAUDIO_STREAM_STATE_STARTING&&
                state!=AAUDIO_STREAM_STATE_STOPPING)break;
            aaudio_stream_state_t next=AAUDIO_STREAM_STATE_UNINITIALIZED;
            (void)AAudioStream_waitForStateChange(stream,state,&next,100000000LL);
        }
        managedStream_.store(nullptr,std::memory_order_release);
        (void)AAudioStream_close(stream);
        activeManaged_.store(false,std::memory_order_release);
    }
    bool openManagedLocked() {
        const int speaker=desiredSpeakerId_.load(std::memory_order_acquire);
        if(speaker<=0){
            lastError_.store(AAUDIO_ERROR_UNAVAILABLE,std::memory_order_relaxed);
            recoverRequested_.store(true,std::memory_order_release);
            setTextError("Tablet speaker output has not been identified by Android yet");return false;
        }
        AAudioStream* stream=nullptr;
        aaudio_result_t result=AAUDIO_ERROR_UNAVAILABLE;
        // Prefer the existing 96 kHz DSP rate. If Android cannot open that
        // format, request the speaker's native rate and prepare the same DSP
        // at the real negotiated rate; never invent a 96 kHz status value.
        for(const int requestedRate:{96000,AAUDIO_UNSPECIFIED}){
            AAudioStreamBuilder* builder=nullptr;
            result=AAudio_createStreamBuilder(&builder);
            if(result!=AAUDIO_OK||!builder)break;
            AAudioStreamBuilder_setDirection(builder,AAUDIO_DIRECTION_OUTPUT);
            AAudioStreamBuilder_setDeviceId(builder,speaker);
            AAudioStreamBuilder_setFormat(builder,AAUDIO_FORMAT_PCM_FLOAT);
            AAudioStreamBuilder_setChannelCount(builder,static_cast<std::int32_t>(kChannels));
            AAudioStreamBuilder_setSampleRate(builder,requestedRate);
            AAudioStreamBuilder_setSharingMode(builder,AAUDIO_SHARING_MODE_SHARED);
            AAudioStreamBuilder_setPerformanceMode(builder,AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
            AAudioStreamBuilder_setFramesPerDataCallback(builder,kManagedRenderFrames);
            AAudioStreamBuilder_setDataCallback(builder,&AndroidSamplerAudio::managedDataCallback,this);
            AAudioStreamBuilder_setErrorCallback(builder,&AndroidSamplerAudio::managedErrorCallback,this);
            result=AAudioStreamBuilder_openStream(builder,&stream);
            (void)AAudioStreamBuilder_delete(builder);
            if(result==AAUDIO_OK&&stream)break;
            if(stream){(void)AAudioStream_close(stream);stream=nullptr;}
        }
        if(result!=AAUDIO_OK||!stream){
            lastError_.store(result,std::memory_order_relaxed);recoverRequested_.store(true,std::memory_order_release);
            setTextError(std::string("Android speaker output failed: ")+AAudio_convertResultToText(result));return false;
        }
        const int actualRate=AAudioStream_getSampleRate(stream);
        const int actualBurst=AAudioStream_getFramesPerBurst(stream);
        const int actualDevice=AAudioStream_getDeviceId(stream);
        if(AAudioStream_getFormat(stream)!=AAUDIO_FORMAT_PCM_FLOAT||AAudioStream_getChannelCount(stream)!=static_cast<std::int32_t>(kChannels)||
            actualRate<8000||actualBurst<=0||actualBurst>std::numeric_limits<int>::max()/2||actualDevice!=speaker){
            (void)AAudioStream_close(stream);lastError_.store(AAUDIO_ERROR_INVALID_FORMAT,std::memory_order_relaxed);
            recoverRequested_.store(true,std::memory_order_release);
            setTextError("Android did not negotiate the requested stereo speaker output");return false;
        }
        (void)AAudioStream_setBufferSizeInFrames(stream,std::max(kManagedRenderFrames,actualBurst*2));
        const int actualBuffer=AAudioStream_getBufferSizeInFrames(stream);
        if(actualBuffer<=0){
            (void)AAudioStream_close(stream);lastError_.store(AAUDIO_ERROR_INVALID_STATE,std::memory_order_relaxed);
            recoverRequested_.store(true,std::memory_order_release);setTextError("Android speaker buffer is unavailable");return false;
        }
        sampleRate_.store(actualRate,std::memory_order_relaxed);framesPerBurst_.store(actualBurst,std::memory_order_relaxed);
        bufferSizeFrames_.store(actualBuffer,std::memory_order_relaxed);
        periodCount_.store(actualBuffer%actualBurst==0?actualBuffer/actualBurst:0,std::memory_order_relaxed);
        sharingMode_.store(AAudioStream_getSharingMode(stream),std::memory_order_relaxed);
        performanceMode_.store(AAudioStream_getPerformanceMode(stream),std::memory_order_relaxed);
        outputDeviceId_.store(actualDevice,std::memory_order_relaxed);
        activeManaged_.store(true,std::memory_order_release);managedStream_.store(stream,std::memory_order_release);
        managedThreadConfigured_.store(false,std::memory_order_release);
        __android_log_print(ANDROID_LOG_INFO,kTag,"Android speaker output: device=%d rate=%d burst=%d buffer=%d sharing=%d performance=%d",
            actualDevice,actualRate,actualBurst,actualBuffer,sharingMode(),performanceMode());
        return true;
    }

    bool openLocked() {
        const bool wired=desiredWired_.load(std::memory_order_acquire);
        if(wired&&pcmFd_.load(std::memory_order_acquire)>=0)return true;
        if(!wired&&managedStream_.load(std::memory_order_acquire)!=nullptr&&
            outputDeviceId_.load(std::memory_order_relaxed)==desiredSpeakerId_.load(std::memory_order_acquire))return true;
        // open() can also be called after a selection changed but before the
        // housekeeping recovery ran. Quiesce that existing backend first.
        if(started_.load(std::memory_order_acquire)||threadRun_.load(std::memory_order_acquire)||audioThread_.joinable())
            (void)stopLocked(false);
        // No backend overlap: Android's speaker HAL may use the same primary
        // PCM that Direct ALSA needs after a jack is inserted.
        closePcmLocked();
        if(!(wired?openDirectLocked():openManagedLocked()))return false;
        prepareRenderLocked();return true;
    }

    void prepareRenderLocked() {
        const int sr = sampleRate();
        const int period = activeManaged_.load(std::memory_order_relaxed)?kManagedRenderFrames:framesPerBurst();
        engine_.prepare(
            static_cast<double>(std::max(8000, sr)),
            static_cast<std::uint32_t>(std::max(64, period)));
        arrangerHost().prepare(static_cast<double>(std::max(8000, sr)), static_cast<std::uint32_t>(std::max(64, period)));
        // Prepare only after the selected output is open and old callbacks have
        // stopped. Use its actual stream rate, retain Studio interpolation, and
        // initialize the master once; recovery keeps the user's existing level.
        engine_.setInterpolationQuality(InterpolationQuality::Studio);
        // SILVETON_MULTICORE_V1: the voices are shared out over the cores next to the audio
        // core. The audio thread also renders buses and waits for any claimed
        // helper work to finish; only verified realtime helpers may participate.
        // DSP quality/order is unchanged. Elapsed time still needs device measurement.
        engine_.setRenderThreads(deviceCpuWorkPolicy().renderThreads);
        // Keyboard and both Style players render serially on this callback,
        // sharing the SAME helper pool rather than spawning competing pools.
        arrangerHost().configureSharedRendering(engine_);
        if (state_ != nullptr) {
            auto fresh = std::make_shared<EngineState>(*state_);
            // SILVETON_MASTER_ONCE_V1: -6 dB the first time the sound opens after the program starts. A reopen in the middle of playing
            // (after an audio error or a changed output) keeps the level that was set.
            if (masterDefaultPending_.exchange(false, std::memory_order_acq_rel)) fresh->global.masterGainDb = -6.0F;
            state_ = fresh;
            library_.setGlobal(fresh->global);
        }
        if (state_ != nullptr) { publishKeyboardState(); }

        xrunCount_.store(0, std::memory_order_relaxed);
        lastError_.store(0, std::memory_order_relaxed);
        recoverRequested_.store(false, std::memory_order_release);
        setTextError({});
    }

    bool startLocked() {
        if (started_.load(std::memory_order_acquire)) return true;
        // A device failure lets audioLoop exit on its own. Reap that thread
        // before replacing it; assigning over a joinable std::thread terminates.
        if (audioThread_.joinable()) audioThread_.join();
        const bool wired=desiredWired_.load(std::memory_order_acquire);
        const bool matching= wired?pcmFd_.load(std::memory_order_acquire)>=0:
            managedStream_.load(std::memory_order_acquire)!=nullptr&&
            outputDeviceId_.load(std::memory_order_relaxed)==desiredSpeakerId_.load(std::memory_order_acquire);
        if(!matching&&!openLocked())return false;
        if(auto* stream=managedStream_.load(std::memory_order_acquire)){
            arrangerHost().startStreaming();threadRun_.store(true,std::memory_order_release);
            managedThreadConfigured_.store(false,std::memory_order_release);started_.store(true,std::memory_order_release);
            const auto result=AAudioStream_requestStart(stream);
            if(result!=AAUDIO_OK){
                threadRun_.store(false,std::memory_order_release);started_.store(false,std::memory_order_release);
                lastError_.store(result,std::memory_order_relaxed);recoverRequested_.store(true,std::memory_order_release);
                setTextError(std::string("Android speaker start failed: ")+AAudio_convertResultToText(result));return false;
            }
            setTextError({});return true;
        }

        const int fd = pcmFd_.load(std::memory_order_acquire);
        if (fd < 0) {
            lastError_.store(-ENODEV, std::memory_order_relaxed);
            return false;
        }
        if (::ioctl(fd, SNDRV_PCM_IOCTL_PREPARE) < 0) {
            const int error = -errno;
            lastError_.store(error, std::memory_order_relaxed);
            recoverRequested_.store(true, std::memory_order_release);
            setTextError("AUDIO DRIVER: PREPARE failed (errno " + std::to_string(-error) + ")");
            return false;
        }

        arrangerHost().startStreaming();
        threadRun_.store(true, std::memory_order_release);
        // Publish before launching so an immediate audioLoop failure remains
        // visible instead of being overwritten by the starting control thread.
        started_.store(true, std::memory_order_release);
        try {
            audioThread_ = std::thread(&AndroidSamplerAudio::audioLoop, this);
        } catch (...) {
            threadRun_.store(false, std::memory_order_release);
            started_.store(false, std::memory_order_release);
            lastError_.store(-EAGAIN, std::memory_order_relaxed);
            setTextError("Direct ALSA audio thread could not be created");
            return false;
        }
        setTextError({});
        return true;
    }

    bool stopLocked(bool panicTransport=true) {
        const int fd = pcmFd_.load(std::memory_order_acquire);
        threadRun_.store(false, std::memory_order_release);

        // DROP wakes a blocked WRITEI ioctl so the thread can terminate without
        // waiting for the hardware queue to drain.
        if (fd >= 0) (void)::ioctl(fd, SNDRV_PCM_IOCTL_DROP);
        if (audioThread_.joinable()) audioThread_.join();
        closeManagedLocked();
        diagnostics::setAudioThreadId(0);
        if(panicTransport)arrangerHost().panic();
        arrangerHost().stopStreaming();

        started_.store(false, std::memory_order_release);
        if (fd >= 0 && ::ioctl(fd, SNDRV_PCM_IOCTL_PREPARE) < 0) {
            const int error = -errno;
            lastError_.store(error, std::memory_order_relaxed);
            return false;
        }
        return true;
    }

    void closePcmLocked() noexcept {
        closeManagedLocked();
        sharingMode_.store(-1,std::memory_order_relaxed);performanceMode_.store(-1,std::memory_order_relaxed);
        outputDeviceId_.store(-1,std::memory_order_relaxed);
        const int fd = pcmFd_.exchange(-1, std::memory_order_acq_rel);
        if (fd >= 0) releasePcmFd(fd);
        sampleRate_.store(0, std::memory_order_relaxed);
        framesPerBurst_.store(0, std::memory_order_relaxed);
        bufferSizeFrames_.store(0, std::memory_order_relaxed);
        periodCount_.store(0, std::memory_order_relaxed);
        renderBuffer_.clear();
        pcmBuffer_.clear();
    }

    bool recoverXrunOnAudioThread(int fd) noexcept {
        xrunCount_.fetch_add(1, std::memory_order_relaxed);
        if (::ioctl(fd, SNDRV_PCM_IOCTL_PREPARE) < 0) {
            lastError_.store(-errno, std::memory_order_relaxed);
            recoverRequested_.store(true, std::memory_order_release);
            return false;
        }
        return true;
    }

    bool writePeriodOnAudioThread(int fd, std::uint32_t frames) noexcept {
        std::uint32_t offset = 0U;
        unsigned noProgress = 0;
        while (offset < frames && threadRun_.load(std::memory_order_acquire)) {
            snd_xferi transfer{};
            transfer.buf = pcmBuffer_.data() + static_cast<std::size_t>(offset) * kChannels;
            transfer.frames = static_cast<snd_pcm_uframes_t>(frames - offset);

            const int rc = ::ioctl(fd, SNDRV_PCM_IOCTL_WRITEI_FRAMES, &transfer);
            snd_pcm_sframes_t written = transfer.result;
            if (rc < 0) written = static_cast<snd_pcm_sframes_t>(-errno);

            // A deliberate stop() issues DROP to wake this ioctl. Do not count
            // that controlled wake-up as a hardware XRUN.
            if (!threadRun_.load(std::memory_order_acquire)) return false;

            if (written <= 0 && ++noProgress > 8U) {
                lastError_.store(written < 0 ? static_cast<int>(written) : -EIO, std::memory_order_relaxed);
                recoverRequested_.store(true, std::memory_order_release);
                return false;
            }
            if (written == -EINTR) continue;
            if (written == -EPIPE || written == -ESTRPIPE) {
                if (!recoverXrunOnAudioThread(fd)) return false;
                continue;
            }
            if (written == -EAGAIN || written == 0) {
                pollfd writable{fd, POLLOUT, 0};
                (void)::poll(&writable, 1, 2);
                continue;
            }
            if (written < 0) {
                lastError_.store(static_cast<int>(written), std::memory_order_relaxed);
                recoverRequested_.store(true, std::memory_order_release);
                return false;
            }
            noProgress = 0;

            const auto advance = static_cast<std::uint32_t>(
                std::min<snd_pcm_sframes_t>(written, static_cast<snd_pcm_sframes_t>(frames - offset)));
            offset += advance;
        }
        return offset == frames;
    }

    void audioLoop() noexcept {
        const auto cpuPolicy=deviceCpuWorkPolicy();
        configureRealtimeThread("SilvAudioRT",cpuPolicy.audioCpu,cpuPolicy.audioCpu,80);
        diagnostics::setAudioThreadId(static_cast<int>(::gettid()));
#if defined(__aarch64__)
        // Flush denormal floats to zero on the audio thread (reverb/delay tails
        // decay into denormals; they cost extra cycles and are inaudible).
        {
            std::uint64_t fpcr = 0U;
            __asm__ __volatile__("mrs %0, fpcr" : "=r"(fpcr));
            fpcr |= (std::uint64_t{1} << 24);
            __asm__ __volatile__("msr fpcr, %0" : : "r"(fpcr));
        }
#endif

        const int fd = pcmFd_.load(std::memory_order_acquire);
        const int period = framesPerBurst();
        if (fd < 0 || period <= 0 || renderBuffer_.empty() || pcmBuffer_.empty()) {
            lastError_.store(-EINVAL, std::memory_order_relaxed);
            recoverRequested_.store(true, std::memory_order_release);
            started_.store(false, std::memory_order_release);
            threadRun_.store(false, std::memory_order_release);
            return;
        }

        const auto frames = static_cast<std::uint32_t>(period);
        while (threadRun_.load(std::memory_order_acquire)) {
            const auto dspStarted = std::chrono::steady_clock::now();
            engine_.setSourceTempo(arrangerHost().keyboardSourceTempo());
            engine_.setLowerMemoryEnabled(arrangerHost().lowerMemoryActive());
            engine_.render(renderBuffer_.data(), frames);
            testInstrument_.render(renderBuffer_.data(), frames, sampleRate());
            arrangerHost().renderAdd(renderBuffer_.data(), frames, static_cast<double>(sampleRate()));

            const std::size_t samples = static_cast<std::size_t>(frames) * kChannels;
            std::uint64_t clippedSamples=0;
            float outputPeak=0.0F;
            // SILVETON_TPDF_DITHER_V1: triangular dither of +-1 step before the
            // 16-bit rounding, so quiet tails fade smoothly into a very low
            // noise floor instead of turning grainy. Digital silence stays silent.
            for (std::size_t i = 0U; i < samples; ++i) {
                const float magnitude=std::fabs(renderBuffer_[i]);
                outputPeak=std::max(outputPeak,magnitude);
                if(magnitude>1.0F)++clippedSamples;
                const float clipped = std::clamp(renderBuffer_[i], -1.0F, 1.0F);
                double scaled = static_cast<double>(clipped) * 32767.0;
                if (clipped != 0.0F) scaled += ditherNext() - ditherNext();
                const long quantized = std::lrint(scaled);
                pcmBuffer_[i] = static_cast<std::int16_t>(
                    std::clamp<long>(quantized, -32768L, 32767L));
            }

            diagnostics::recordOutput(clippedSamples,outputPeak);
            const auto dspElapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - dspStarted).count();
            diagnostics::recordAudioBlock(dspElapsed*1000.0,frames,sampleRate());
            arrangerHost().recordBlockCost(static_cast<float>(100.0 * dspElapsed * static_cast<double>(sampleRate()) / static_cast<double>(frames)));

            if (!writePeriodOnAudioThread(fd, frames)) break;
        }

        threadRun_.store(false, std::memory_order_release);
        started_.store(false, std::memory_order_release);
    }

    bool commitSampleEdit(std::uint32_t id, const SamplePtr& previous, SampleEditResult result) {
        if (!result.ok()) { setTextError(result.error); return false; }
        if (!library_.writeSample(id, result.sample)) { setTextError("SAMPLE write-back failed"); return false; }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_); bool changed=false;
            for (auto& upper : next->combi.uppers) {
                if (upper.program == nullptr) continue;
                std::shared_ptr<Program> pc;
                for (std::size_t li=0U; li<upper.program->layers.size(); ++li) {
                    const auto& oldMs=upper.program->layers[li].multisample; if(oldMs==nullptr) continue;
                    std::shared_ptr<Multisample> mc;
                    for(std::size_t zi=0U; zi<oldMs->zones.size(); ++zi){
                        if(oldMs->zones[zi].sample!=previous) continue;
                        if(mc==nullptr) mc=std::make_shared<Multisample>(*oldMs);
                        mc->zones[zi].sample=result.sample;
                    }
                    if(mc!=nullptr){ if(pc==nullptr) pc=std::make_shared<Program>(*upper.program); pc->layers[li].multisample=mc; }
                }
                if(pc!=nullptr){ upper.program=pc; changed=true; }
            }
            if(changed && !installState(std::move(next), Mark::Keep)) return false;
        }
        setTextError({}); return true;
    }

    bool commitMultisampleEdit(std::uint32_t id, const MultisamplePtr& previous, MultisampleEditResult result) {
        if(!result.ok()){setTextError(result.error);return false;}
        if(!library_.writeMultisample(id,result.multisample)){setTextError("MULTISAMPLE write-back failed");return false;}
        if(state_!=nullptr){auto next=std::make_shared<EngineState>(*state_);bool changed=false;for(auto& upper:next->combi.uppers){if(upper.program==nullptr)continue;std::shared_ptr<Program> pc;for(std::size_t li=0U;li<upper.program->layers.size();++li){if(upper.program->layers[li].multisample!=previous)continue;if(pc==nullptr)pc=std::make_shared<Program>(*upper.program);pc->layers[li].multisample=result.multisample;}if(pc!=nullptr){upper.program=pc;changed=true;}}if(changed&&!installState(std::move(next), Mark::Keep))return false;}
        setTextError({});return true;
    }

    bool commitProgramEdit(const SlotAddress& address, const ProgramPtr& previous, ProgramEditResult result) {
        if (!result.ok()) { setTextError(result.error); return false; }
        if (!library_.writeProgram(address, result.program)) { setTextError("PROGRAM write-back failed"); return false; }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_);
            bool activeChanged = false;
            for (auto& upper : next->combi.uppers) {
                if (upper.program == previous) {
                    upper.program = result.program;
                    activeChanged = true;
                }
            }
            if (activeChanged && !installState(std::move(next), Mark::Keep)) return false;
        }
        setTextError({});
        return true;
    }

    bool ensureKscCache(const std::string& path) {
        if (path == kscCachePath_ && kscCache_.ok()) return true;
        auto imported = KorgImporter::loadKsc(path);
        if (!imported.ok()) { setTextError(imported.error); return false; }
        kscCachePath_ = path;
        kscCache_ = std::move(imported);
        setTextError({});
        return true;
    }

    MultisamplePtr makeSingleSampleMultisample(const SamplePtr& sample, const std::string& name) {
        auto ms = std::make_shared<Multisample>();
        ms->name = name;
        SampleZone z{};
        z.sample = sample;
        z.keyLow = 0U; z.keyHigh = 127U; z.velocityLow = 1U; z.velocityHigh = 127U;
        z.rootKey = sample->rootKey;
        ms->zones.push_back(z);
        return ms;
    }

    bool installMultisample(const MultisamplePtr& ms, const std::string& name) {
        if (ms == nullptr) return false;
        auto program = std::make_shared<Program>();
        program->name = name;
        ProgramLayer layer{};
        layer.name = "Layer 1";
        layer.multisample = ms;
        program->layers.push_back(layer);
        auto state = std::make_shared<EngineState>();
        state->combi.name = name;
        auto& u = state->combi.uppers[0];
        u.name = "Upper 1";
        u.enabled = true;
        u.program = program;
        u.midiChannel = 0U;
        return installState(std::move(state), Mark::Keep);
    }

    // SILVETON_SYNTH_MENU_OFF_V1: the SYNTH and MATRIX pages are gone from the screen, so every
    // sound plays as the plain recording - exactly the SYNTH ИЗКЛ sound (no PWM, SUB, UNISON,
    // DRIVE, character filters, filter 2 or matrix; one voice per sound, lighter on the CPU).
    // The knob values stay stored in the SET untouched.
    static void forceSynthOff(EngineState& s) noexcept {
        for (auto& u : s.combi.uppers) {
            u.toneExtra.synthBypass = true;
            for (auto& l : u.layers) l.tone.x.synthBypass = true;
        }
    }

    // SILVETON_SAVEQ_V1: Edit = the open BLEND was changed (the screen may ask "save?"); Clean = a BLEND was recalled or loaded;
    // Keep = nothing about the open BLEND (global, bank, sound edits).
    enum class Mark { Edit, Clean, Keep };
    void publishKeyboardState() {
        if (state_ == nullptr) return;
        auto audioState = std::make_shared<EngineState>(*state_);
        prepareKeyboardMix(audioState->combi);
        // Limiting belongs to the final keyboard + dual-player sum.
        audioState->global.limiterEnabled = false;
        engine_.setState(std::move(audioState));
        arrangerHost().syncGlobal(state_->global, !state_->combi.scale.stored || state_->combi.scale.enabled);
    }

    bool installState(std::shared_ptr<const EngineState> state, Mark mark = Mark::Edit) {
        if (state == nullptr) return false;
        auto plain = std::make_shared<EngineState>(*state);   // SILVETON_SYNTH_MENU_OFF_V1
        forceSynthOff(*plain);
        if (plain->combi.scale.stored) {
            plain->global.scaleRoot = 0U;
            plain->global.scaleOffsetsCents = plain->combi.scale.cents;
        }
        prepareWaveTables(*plain);   // SILVETON_TRANSWAVE_V1: the tables go to the engine before the state
        std::lock_guard<std::mutex> lock(controlMutex_);
        state_ = std::move(plain);
        damperConfig_.store(static_cast<unsigned>(state_->global.damperCc) |
            (state_->global.damperPolarityReversed ? 0x80U : 0U), std::memory_order_release);
        if (state_->combi.scale.stored) {
            const auto& sc = state_->combi.scale;
            setScaleUppers(sc.enabled ? sc.targets : 0);
        }
        if (mark == Mark::Edit) blendEdited_.store(true, std::memory_order_release);
        else if (mark == Mark::Clean) blendEdited_.store(false, std::memory_order_release);
        // Real bank SOUND is authoritative. The old diagnostic TEST EP is retired.
        testInstrument_.setEnabled(false);
        publishKeyboardState();
        return true;
    }

    void syncCurrentStateToLibrary() {
        if (state_ == nullptr) return;
        library_.setGlobal(state_->global);
    }

    void setTextError(const std::string& s) {
        std::lock_guard<std::mutex> lock(errorMutex_);
        textError_ = s;
    }

    SamplerEngine engine_;
    SampleStreamPrefetcher prefetcher_{engine_};
    BuiltinTestInstrument testInstrument_{};
    std::atomic<std::uint64_t> midiActivitySerial_{0U};
    std::atomic<int> scaleTargets_{0};
    std::atomic<bool> blendEdited_{false};   // SILVETON_SAVEQ_V1
    std::atomic<bool> masterDefaultPending_{true};   // SILVETON_MASTER_ONCE_V1
    mutable std::mutex missingMutex_;        // SILVETON_OPEN_WITHOUT_SOUND_V1
    std::string lastRecallMissing_;
    std::array<std::atomic<int>, 128> ccLast_{};   // SILVETON_PEDAL_CAL_V1: last value + 1 of every controller; 0 = none yet
    std::atomic<int> midiLastStatus_{0};
    std::atomic<int> midiLastData1_{0};
    std::atomic<int> midiLastData2_{0};
    SamplerLibrary library_{"SILVETON SET"};
    KorgCollectionResult kscCache_{};
    std::string kscCachePath_;
    std::shared_ptr<const EngineState> state_{std::make_shared<EngineState>()};
    std::optional<SlotAddress> activeListAddress_{};
    int activeListEntry_{-1};
    std::atomic<int> pcmFd_{-1};
    std::atomic<AAudioStream*> managedStream_{nullptr};
    std::atomic<bool> desiredWired_{false},activeManaged_{false},managedThreadConfigured_{false};
    std::atomic<int> desiredSpeakerId_{0},sharingMode_{-1},performanceMode_{-1},outputDeviceId_{-1};
    std::thread audioThread_{};
    std::thread midiThread_{};
    std::vector<RawMidiPort> rawMidiPorts_{};
    std::vector<float> renderBuffer_{};
    std::vector<std::int16_t> pcmBuffer_{};
    std::atomic<int> scanMode_{0};
    std::array<std::uint8_t, 128> scanSwallowed_{};
    bool scanTercaPending_{false};
    int scanTercaRoot_{0};
    int scanTercaCell_{0};
    int scanScaleCollected_{0};
    bool scanKeyPending_{false};
    int scanKeyValue_{0};
    std::atomic<int> keyScan_{-1};
    std::atomic<std::uint32_t> keyScanSerial_{0U};
    std::atomic<int> tercaRoot_{-1};
    std::atomic<int> tercaCell_{-1};
    std::atomic<unsigned> tercaSerial_{0U};
    std::atomic<int> scaleMask_{0};
    std::atomic<unsigned> scaleSerial_{0U};
    std::uint32_t ditherState_{0x9E3779B9U};
    // Uniform 0..1 from a xorshift generator (audio thread only, no locks).
    double ditherNext() noexcept {
        std::uint32_t x = ditherState_;
        x ^= x << 13U; x ^= x >> 17U; x ^= x << 5U;
        ditherState_ = x;
        return static_cast<double>(x) * (1.0 / 4294967296.0);
    }
    std::atomic<bool> threadRun_{false};
    std::atomic<bool> midiThreadRun_{false};
    std::atomic<bool> midiPreviewIsolation_{false};   // the Manager audition; never set on the tablet
    std::atomic<unsigned> damperConfig_{64U}; // current CC plus reversed-polarity bit, read by MIDI thread
    std::atomic<bool> started_{false};
    std::atomic<bool> wantStarted_{false};
    std::atomic<bool> recoverRequested_{false};
    std::atomic<int> sampleRate_{0};
    std::atomic<int> framesPerBurst_{0};
    std::atomic<int> bufferSizeFrames_{0};
    std::atomic<int> periodCount_{0};
    std::atomic<int> xrunCount_{0};
    std::atomic<int> midiDeviceCount_{0};
    std::atomic<int> midiLastError_{0};
    std::atomic<int> lastError_{0};
    mutable std::mutex controlMutex_;
    mutable std::mutex errorMutex_;
    std::string textError_;
    std::mutex routeMutex_;
    int routeFd_{-1};
    std::vector<RouteTarget> routeTargets_{};
};


std::unique_ptr<AndroidSamplerAudio> gSampler;
AndroidSamplerAudio& sampler() { if (!gSampler) gSampler = std::make_unique<AndroidSamplerAudio>(); return *gSampler; }

SlotAddress makeAddress(int bank, int page, int slot) noexcept {
    SlotAddress a{};
    a.bank = static_cast<std::uint16_t>(std::clamp(bank, 0, 65535));
    a.page = static_cast<std::uint16_t>(std::clamp(page, 0, 65535));
    a.slot = static_cast<std::uint16_t>(std::clamp(slot, 0, 65535));
    return a;
}

std::vector<float> metersArray(const MeterSnapshot& m) {
    std::vector<float> v(7U + static_cast<std::size_t>(kUpperCount) * 2U, 0.0F);
    v[0]=m.peakLeft; v[1]=m.peakRight; v[2]=m.limiterGainReductionDb;
    v[3]=static_cast<float>(m.activeVoices); v[4]=static_cast<float>(m.droppedEvents);
    for (std::size_t i = 0; i < static_cast<std::size_t>(kUpperCount); ++i) {
        const std::size_t base = 5U + i * 2U;
        v[base] = m.upperPeakLeft[i];
        v[base + 1U] = m.upperPeakRight[i];
    }
    v[5U + static_cast<std::size_t>(kUpperCount) * 2U] = m.cpuLoadPercent;   // SILVETON_CPU_METER_V1
    v[6U + static_cast<std::size_t>(kUpperCount) * 2U] = static_cast<float>(m.coresWorking);   // SILVETON_MULTICORE_V1 (last value)
    return v;
}

}  // namespace

#include "../SoundSourceFacade.inc"

void NativeSamplerEngine::nativeSamplerInit() {(void)arrangerHost(); gSampler = std::make_unique<AndroidSamplerAudio>(); gSampler->installNoModels();}   // SILVETON_MODELS_FROM_FILE_V1: no model until the file is reads from the start

bool NativeSamplerEngine::nativeAudioOpen() {return sampler().open()?true:false;}

bool NativeSamplerEngine::nativeAudioStart() {return sampler().start()?true:false;}

void NativeSamplerEngine::nativeAudioStop() {sampler().stop();}

void NativeSamplerEngine::nativeSetMidiPreviewIsolation(bool blocked) {sampler().setMidiPreviewIsolation(blocked);}

void NativeSamplerEngine::nativeAudioClose() {sampler().close();}

bool NativeSamplerEngine::nativeAudioRecover() {return sampler().recover()?true:false;}

bool NativeSamplerEngine::nativeAudioNeedsRecovery() {return sampler().needsRecovery()?true:false;}

bool NativeSamplerEngine::nativeEnforceOutputRoute() {return sampler().enforceHeadphoneRoute(true)?true:false;}

void NativeSamplerEngine::nativeSetOutputSelection(bool wired,int speakerDeviceId) {sampler().setOutputSelection(wired,speakerDeviceId);}

void NativeSamplerEngine::nativeSetPortaBalance(int balance) {sampler().setPortamentoBalance(static_cast<float>(balance));}

void NativeSamplerEngine::nativeSetVoiceCeiling(int voices) {sampler().setVoiceCeiling(static_cast<int>(voices));}

void NativeSamplerEngine::nativeSetPortaNear(int ms) {sampler().setPortamentoNear(static_cast<float>(ms));}

std::string NativeSamplerEngine::nativeBankInfo(const std::string& path) {std::string err;const auto t=bankInfoText((path),err);return  std::string(t.empty()?("ERROR\t"+err).c_str():t.c_str());}

std::string NativeSamplerEngine::nativeRemoveBankSounds(const std::string& path, const std::vector<int>& slots) {
    std::set<std::uint16_t> s;
    for (const int x : slots) if (x >= 1 && x <= 65535) s.insert(static_cast<std::uint16_t>(x));
    std::string err;
    const bool ok = removeBankSounds(path, s, err);
    return ok ? std::string() : (err.empty() ? std::string("Delete failed") : err);
}

bool NativeSamplerEngine::nativeLoadAudio(const std::string& path) {return sampler().loadAudioFile((path))?true:false;}

bool NativeSamplerEngine::nativeLoadKmp(const std::string& path) {return sampler().loadKmp((path))?true:false;}

std::vector<int> NativeSamplerEngine::nativeImportKmpToLibrary(const std::string& path) {return (sampler().importKmpToLibrary((path)));}

std::vector<int> NativeSamplerEngine::nativeImportKscToLibrary(const std::string& path) {return (sampler().importKscToLibrary((path)));}

std::vector<int> NativeSamplerEngine::nativeMultisampleIds() {return (sampler().multisampleIds());}

std::vector<int> NativeSamplerEngine::nativeSampleIds() {
    std::vector<int> out;
    for (const auto id : sampler().sampleIds()) out.push_back(static_cast<int>(id));
    return out;
}

std::vector<std::string> NativeSamplerEngine::nativeSampleNames() { return sampler().sampleNames(); }

bool NativeSamplerEngine::nativeSampleWave(int id, std::vector<float>& points) {
    return sampler().sampleWave(static_cast<std::uint32_t>(id), points);
}

std::vector<std::string> NativeSamplerEngine::nativeMultisampleNames() {    return sampler().multisampleNames();
}

std::vector<std::string> NativeSamplerEngine::nativeKscNames(const std::string& path) {    return sampler().kscNames(path);
}

bool NativeSamplerEngine::nativeLoadKscItem(const std::string& path, int index) {return sampler().loadKscItem((path),index)?true:false;}

bool NativeSamplerEngine::nativeLoadSvBank(const std::string& path) {return sampler().loadSvBank((path))?true:false;}

bool NativeSamplerEngine::nativeLoadSet(const std::string& path) {return sampler().loadSet((path))?true:false;}

bool NativeSamplerEngine::nativeSaveUserPerformanceState(const std::string& path) {return sampler().saveUserPerformanceState((path))?true:false;}

std::shared_ptr<const PerformanceCheckpoint> NativeSamplerEngine::nativePerformanceCheckpoint() { return sampler().performanceCheckpoint(); }
bool NativeSamplerEngine::nativeRestorePerformanceCheckpoint(const std::shared_ptr<const PerformanceCheckpoint>& checkpoint) { return sampler().restorePerformanceCheckpoint(checkpoint); }

bool NativeSamplerEngine::nativeLoadUserPerformanceState(const std::string& path) {return sampler().loadUserPerformanceState((path))?true:false;}

bool NativeSamplerEngine::nativeReplaceUserPerformanceState(const std::string& path) {return sampler().replaceUserPerformanceState((path))?true:false;}
bool NativeSamplerEngine::nativeReplacePreparedUserPerformanceState(const sampler::SetData& data) {return sampler().replacePreparedUserPerformanceState(data);}
bool NativeSamplerEngine::nativeAddBankSounds(const std::string& path) {return sampler().addBankSounds(path);}   // SILVETON_SEND_V1
bool NativeSamplerEngine::nativeSaveOpenCombi(const std::string& path) {return sampler().saveOpenCombi(path);}   // SILVETON_PROJECT_V1
bool NativeSamplerEngine::nativeLoadOpenCombi(const std::string& path) {return sampler().loadOpenCombi(path);}
std::vector<int> NativeSamplerEngine::nativeSoundsOnlyInCombi(int bank, int page, int slot, bool countOpen, const std::vector<std::string>& setPaths,
                                                              const std::vector<std::array<int, 3>>& listedCombis) {
    std::vector<SlotAddress> listed;
    for (const auto& l : listedCombis) listed.push_back(makeAddress(l[0], l[1], l[2]));
    return sampler().soundsOnlyInCombi(makeAddress(bank, page, slot), countOpen, setPaths, listed);   // SILVETON_LIST_DELETE_SOUNDS_V1
}
bool NativeSamplerEngine::nativeRemoveSoundPlaces(const std::vector<int>& places) {return sampler().removeSoundPlaces(places);}
bool NativeSamplerEngine::nativeWriteSoundCombi(int combiSlot, int soundSlot, const std::string& name) {   // SILVETON_PASTE_V1
    if (combiSlot < 1 || combiSlot > 500 || soundSlot < 1 || soundSlot > 500) return false;
    return sampler().writeSoundCombi(makeAddress(0, 0, combiSlot), static_cast<std::uint16_t>(soundSlot), name);
}

bool NativeSamplerEngine::nativeSaveBank(const std::string& path, int bank) {return sampler().saveBank((path),bank)?true:false;}

bool NativeSamplerEngine::nativeLoadBank(const std::string& path, int targetBank, bool overwrite) {return sampler().loadBank((path),targetBank,overwrite)?true:false;}

bool NativeSamplerEngine::nativeWriteSample(int id, int upper, int layer, int zone, const std::string& name) {return sampler().writeCurrentSample(static_cast<std::uint32_t>(std::max(0,id)),upper,layer,zone,(name))?true:false;}

bool NativeSamplerEngine::nativeUpdateSampleMetadata(int id, const std::string& name, int rootKey, float fineTune) {return sampler().updateSampleMetadata(static_cast<std::uint32_t>(std::max(0,id)),(name),rootKey,fineTune)?true:false;}

bool NativeSamplerEngine::nativeTrimSample(int id, std::int64_t start, std::int64_t end) {if(start<0||end<0)return false;return sampler().trimSample(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(start),static_cast<std::uint64_t>(end))?true:false;}

bool NativeSamplerEngine::nativeNormalizeSample(int id, float targetDb) {return sampler().normalizeSample(static_cast<std::uint32_t>(std::max(0,id)),targetDb)?true:false;}

bool NativeSamplerEngine::nativeReverseSample(int id) {return sampler().reverseSample(static_cast<std::uint32_t>(std::max(0,id)))?true:false;}

bool NativeSamplerEngine::nativeFadeSample(int id, std::int64_t fadeIn, std::int64_t fadeOut) {if(fadeIn<0||fadeOut<0)return false;return sampler().fadeSample(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(fadeIn),static_cast<std::uint64_t>(fadeOut))?true:false;}

bool NativeSamplerEngine::nativeSetSampleLoop(int id, std::int64_t start, std::int64_t end, int crossfade) {if(start<0||end<0||crossfade<0)return false;return sampler().setSampleLoop(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(start),static_cast<std::uint64_t>(end),static_cast<std::uint32_t>(crossfade))?true:false;}

bool NativeSamplerEngine::nativeClearSampleLoop(int id) {return sampler().clearSampleLoop(static_cast<std::uint32_t>(std::max(0,id)))?true:false;}

std::int64_t NativeSamplerEngine::nativeSampleNearestZeroCrossing(int id, std::int64_t around, std::int64_t radius) {if(around<0||radius<0)return static_cast<std::int64_t>(-1);return static_cast<std::int64_t>(sampler().sampleNearestZeroCrossing(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(around),static_cast<std::uint64_t>(radius)));}

bool NativeSamplerEngine::nativeWriteMultisample(int id, int upper, int layer, const std::string& name) {return sampler().writeCurrentMultisample(static_cast<std::uint32_t>(std::max(0,id)),upper,layer,(name))?true:false;}

bool NativeSamplerEngine::nativeRenameMultisample(int id, const std::string& name) {return sampler().renameMultisample(static_cast<std::uint32_t>(std::max(0,id)),(name))?true:false;}

bool NativeSamplerEngine::nativeAddMultisampleZone(int id, int sampleId, int insertIndex, int keyLow, int keyHigh, int velLow, int velHigh, int rootKey, int transpose, float tune, float gain, float pan, bool oneShot, bool reverse, bool nonTranspose) {return sampler().addMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint32_t>(std::max(0,sampleId)),insertIndex,keyLow,keyHigh,velLow,velHigh,rootKey,transpose,tune,gain,pan,oneShot,reverse,nonTranspose)?true:false;}

bool NativeSamplerEngine::nativeUpdateMultisampleZone(int id, int zoneIndex, int sampleId, int keyLow, int keyHigh, int velLow, int velHigh, int rootKey, int transpose, float tune, float gain, float pan, bool oneShot, bool reverse, bool nonTranspose) {return sampler().updateMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),zoneIndex,static_cast<std::uint32_t>(std::max(0,sampleId)),keyLow,keyHigh,velLow,velHigh,rootKey,transpose,tune,gain,pan,oneShot,reverse,nonTranspose)?true:false;}

bool NativeSamplerEngine::nativeRemoveMultisampleZone(int id, int zoneIndex) {return sampler().removeMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),zoneIndex)?true:false;}

bool NativeSamplerEngine::nativeMoveMultisampleZone(int id, int fromIndex, int toIndex) {return sampler().moveMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),fromIndex,toIndex)?true:false;}

bool NativeSamplerEngine::nativeClearMultisample(int id) {return sampler().clearMultisample(static_cast<std::uint32_t>(std::max(0,id)))?true:false;}

bool NativeSamplerEngine::nativeProgramSlotOccupied(int bank, int page, int slot) {return sampler().programSlotOccupied(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeCombiSlotOccupied(int bank, int page, int slot) {return sampler().combiSlotOccupied(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeListSlotOccupied(int bank, int page, int slot) {return sampler().listSlotOccupied(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeRenameProgram(int bank, int page, int slot, const std::string& name) {return sampler().renameProgram(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeRenameCombi(int bank, int page, int slot, const std::string& name) {return sampler().renameCombi(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeRenameList(int bank, int page, int slot, const std::string& name) {return sampler().renameList(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeCopyProgram(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().copyProgram(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool NativeSamplerEngine::nativeCopyCombi(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().copyCombi(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}
std::shared_ptr<const silveton::sampler::Combi> NativeSamplerEngine::nativeStoredCombi(int bank, int page, int slot) {
    return sampler().storedCombi(makeAddress(bank, page, slot));
}
bool NativeSamplerEngine::nativeStoreCombiSnapshot(int bank, int page, int slot, const silveton::sampler::Combi& combi) {
    return sampler().storeCombiSnapshot(makeAddress(bank, page, slot), combi);
}


bool NativeSamplerEngine::nativeCopyList(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().copyList(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool assignArrangerBankSound(int player, int track, int bank, int page, int slot) {
    return sampler().assignArrangerSound(player, track, makeAddress(bank, page, slot));
}
silveton::sampler::ProgramPtr resolveArrangerBankSound(int slot) {
    return slot >= 1 && slot <= 500 ? sampler().programForSlot(static_cast<std::uint16_t>(slot)) : nullptr;
}
bool loadArrangerSetup(const std::string& path) { return sampler().loadArrangerSetup(path); }

bool NativeSamplerEngine::nativeArrangerAssignSound(int player, int track, int bank, int page, int slot) {
    return sampler().assignArrangerSound(player, track, makeAddress(bank, page, slot));
}
bool NativeSamplerEngine::nativeArrangerLoadSetup(const std::string& path) {
    return sampler().loadArrangerSetup(path);
}

bool NativeSamplerEngine::nativeMidi(int status, int d1, int d2) {return sampler().midi(static_cast<std::uint8_t>(status&0xFF),static_cast<std::uint8_t>(d1&0x7F),static_cast<std::uint8_t>(d2&0x7F))?true:false;}

int NativeSamplerEngine::nativeMidiDeviceCount() {return sampler().midiDeviceCount();}

int NativeSamplerEngine::nativeMidiLastError() {return sampler().midiLastError();}

std::int64_t NativeSamplerEngine::nativeMidiActivitySerial() {return static_cast<std::int64_t>(sampler().midiActivitySerial());}

std::vector<int> NativeSamplerEngine::nativeMidiLastMessage() {    return std::vector<int>{sampler().midiLastStatus(), sampler().midiLastData1(), sampler().midiLastData2()};
}
int NativeSamplerEngine::nativeMidiCcValue(int cc) {return sampler().midiCcValue(cc);}
bool NativeSamplerEngine::nativeBlendEdited() {return sampler().blendEdited();}
std::string NativeSamplerEngine::nativeLastRecallMissing() {return sampler().lastRecallMissing();}

bool NativeSamplerEngine::nativeAudioStarted() {return sampler().started()?true:false;}

bool NativeSamplerEngine::nativeTestInstrumentEnabled() {return sampler().testInstrumentEnabled()?true:false;}

bool NativeSamplerEngine::nativeTestNoteOn(int note, int velocity) {return sampler().testNoteOn(static_cast<std::uint8_t>(std::clamp(note,0,127)),static_cast<std::uint8_t>(std::clamp(velocity,0,127)))?true:false;}

void NativeSamplerEngine::nativeTestNoteOff(int note) {sampler().testNoteOff(static_cast<std::uint8_t>(std::clamp(note,0,127)));}

bool NativeSamplerEngine::nativePanic() {return sampler().panic()?true:false;}

std::vector<float> NativeSamplerEngine::nativeMeters() {return metersArray(sampler().meters());}

std::vector<int> NativeSamplerEngine::nativeAudioInfo() {    return std::vector<int>{sampler().sampleRate(), sampler().framesPerBurst(), sampler().bufferSizeFrames(), sampler().xrunCount(), sampler().sharingMode(), sampler().performanceMode(), sampler().deviceId()};
}

double NativeSamplerEngine::nativeLatencyMs() {return sampler().estimatedOutputLatencyMs();}

int NativeSamplerEngine::nativeLastAudioError() {return sampler().lastError();}

std::string NativeSamplerEngine::nativeLastTextError() {const auto s=sampler().textError();return  std::string(s.c_str());}

bool NativeSamplerEngine::nativeSaveSet(const std::string& path) {return sampler().saveSet((path))?true:false;}

bool NativeSamplerEngine::nativeSetSetName(const std::string& name) {return sampler().setSetName((name))?true:false;}

bool NativeSamplerEngine::nativeWriteProgram(int bank, int page, int slot, int upper, const std::string& name) {return sampler().writeCurrentProgram(makeAddress(bank,page,slot),upper,(name))?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramBasic(int bank, int page, int slot, bool mono, bool legato, float portamentoSec) {return sampler().updateProgramBasic(makeAddress(bank,page,slot),mono,legato,portamentoSec)?true:false;}

bool NativeSamplerEngine::nativeAddProgramLayer(int bank, int page, int slot, int multisampleId, const std::string& name) {return sampler().addProgramLayer(makeAddress(bank,page,slot),static_cast<std::uint32_t>(std::max(0,multisampleId)),(name))?true:false;}

bool NativeSamplerEngine::nativeRemoveProgramLayer(int bank, int page, int slot, int layer) {return sampler().removeProgramLayer(makeAddress(bank,page,slot),layer)?true:false;}

bool NativeSamplerEngine::nativeMoveProgramLayer(int bank, int page, int slot, int fromLayer, int toLayer) {return sampler().moveProgramLayer(makeAddress(bank,page,slot),fromLayer,toLayer)?true:false;}

bool NativeSamplerEngine::nativeAssignProgramMultisample(int bank, int page, int slot, int layer, int multisampleId) {return sampler().assignProgramMultisample(makeAddress(bank,page,slot),layer,static_cast<std::uint32_t>(std::max(0,multisampleId)))?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramLayerBasic(int bank, int page, int slot, int layer, bool enabled, int keyLow, int keyHigh, int velocityLow, int velocityHigh, int velocityFadeIn, int velocityFadeOut, int transpose, float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled) {return sampler().updateProgramLayerBasic(makeAddress(bank,page,slot),layer,enabled,keyLow,keyHigh,velocityLow,velocityHigh,velocityFadeIn,velocityFadeOut,transpose,tuneCents,levelDb,pan,delaySec,damperEnabled)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramAmpEnvelope(int bank, int page, int slot, int layer, float attack, float decay, float sustain, float release) {return sampler().updateProgramAmpEnvelope(makeAddress(bank,page,slot),layer,attack,decay,sustain,release)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramPitch(int bank, int page, int slot, int layer, float amountCents, float attack, float decay, float sustain, float release) {return sampler().updateProgramPitch(makeAddress(bank,page,slot),layer,amountCents,attack,decay,sustain,release)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramFilter(int bank, int page, int slot, int layer, int mode, float cutoffHz, float resonance, float keyTrack, float velocityAmount, float envelopeAmount, float lfoAmount, float attack, float decay, float sustain, float release) {return sampler().updateProgramFilter(makeAddress(bank,page,slot),layer,mode,cutoffHz,resonance,keyTrack,velocityAmount,envelopeAmount,lfoAmount,attack,decay,sustain,release)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramLfo(int bank, int page, int slot, int layer, int lfoIndex, int wave, float frequencyHz, float delaySec, float fadeSec, bool keySync, float pitchCents, float filterOctaves, float ampDepth) {return sampler().updateProgramLfo(makeAddress(bank,page,slot),layer,lfoIndex,wave,frequencyHz,delaySec,fadeSec,keySync,pitchCents,filterOctaves,ampDepth)?true:false;}

bool NativeSamplerEngine::nativeWriteCombi(int bank, int page, int slot, const std::string& name) {return sampler().writeCurrentCombi(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperMain(int upper, bool enabled, bool solo, bool mute, float levelDb, float pan, int keyLow, int keyHigh, int voiceMode) {return sampler().updateUpperMain(upper,enabled,solo,mute,levelDb,pan,keyLow,keyHigh,voiceMode)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperTune(int upper, int octave, int transpose, float fineCents, int pitchBendRange, float portamentoSec) {return sampler().updateUpperTune(upper,octave,transpose,fineCents,pitchBendRange,portamentoSec)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperRange(int upper, int velocityLow, int velocityHigh) {return sampler().updateUpperRange(upper,velocityLow,velocityHigh)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperControl(int upper, bool breath, bool expression, bool aftertouch, bool damper, int midiChannel) {return sampler().updateUpperControl(upper,breath,expression,aftertouch,damper,midiChannel)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperTone(int upper, float attack, float decay, float sustain, float release, float cutoff, float resonance, float lfoRate, float lfoDepth, float eqLow, float eqMid, float eqHigh) {return sampler().updateUpperTone(upper,attack,decay,sustain,release,cutoff,resonance,lfoRate,lfoDepth,eqLow,eqMid,eqHigh)?true:false;}

bool NativeSamplerEngine::nativeSetUpperToneParam(int upper, int param, float value) {return sampler().setUpperToneParam(upper,param,value)?true:false;}

std::vector<float> NativeSamplerEngine::nativeUpperState(int upper) {return (sampler().upperState(upper));}

std::string NativeSamplerEngine::nativeUpperSoundName(int upper) {const auto s=sampler().upperSoundName(upper);return  std::string(s.c_str());}

std::string NativeSamplerEngine::nativeCombiName() {const auto s=sampler().combiName();return  std::string(s.c_str());}

std::vector<int> NativeSamplerEngine::nativeCombiCatalogSlots() {return (sampler().combiCatalogSlots());}

std::vector<std::string> NativeSamplerEngine::nativeCombiCatalogNames() {return (sampler().combiCatalogNames());}

std::vector<int> NativeSamplerEngine::nativeSoundCatalogAddresses() {return (sampler().soundCatalogAddresses());}

std::vector<std::string> NativeSamplerEngine::nativeSoundCatalogNames() {return (sampler().soundCatalogNames());}

bool NativeSamplerEngine::nativeUpdateUpperFxSends(int upper, float send1, float send2) {return sampler().updateUpperFxSends(upper,send1,send2)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperControllerRoute(int upper, int route, int source, int destination, int cc, float amount, bool bipolar) {return sampler().updateUpperControllerRoute(upper,route,source,destination,cc,amount,bipolar)?true:false;}

bool NativeSamplerEngine::nativeUpdateCombiFx(int slot, int type, float wet, float timeMs, float feedback, float rateHz, float depth, float tone) {return sampler().updateCombiFx(slot,type,wet,timeMs,feedback,rateHz,depth,tone)?true:false;}

bool NativeSamplerEngine::nativeUpdateCombiFxRouting(int routing) {return sampler().updateCombiFxRouting(routing)?true:false;}

bool NativeSamplerEngine::nativeSetUpperParam(int upper, int id, float value) {return sampler().setUpperParam(upper,id,value)?true:false;}

std::vector<float> NativeSamplerEngine::nativeUpperParams(int upper) {return (sampler().upperParams(upper));}

bool NativeSamplerEngine::nativeSetLayerParam(int upper, int layer, int id, float value) {return sampler().setLayerParam(upper,layer,id,value)?true:false;}

bool NativeSamplerEngine::nativeSetLayerSound(int upper, int layer, int slot) {return sampler().setLayerSound(upper,layer,slot)?true:false;}

std::vector<float> NativeSamplerEngine::nativeLayerParams(int upper, int layer) {return (sampler().layerParams(upper,layer));}

int NativeSamplerEngine::nativeUpperSoundSlot(int upper) {return sampler().upperSoundSlot(upper);}

std::string NativeSamplerEngine::nativeLayerName(int upper, int layer) {return  std::string(sampler().layerName(upper,layer).c_str());}
std::vector<int> NativeSamplerEngine::nativeSoundVelocityZones(int upper, int sound) {return sampler().soundVelocityZones(upper,sound);}   // SILVETON_OFS_V1

bool NativeSamplerEngine::nativeSetFxParam(int unit, int id, float value) {return sampler().setFxParam(unit,id,value)?true:false;}

std::vector<float> NativeSamplerEngine::nativeFxParams(int unit) {return (sampler().fxParams(unit));}

bool NativeSamplerEngine::nativeSetSoundSynthParam(int upper, int sound, int id, float value) {return sampler().setSoundSynthParam(upper,sound,id,value)?true:false;}
bool NativeSamplerEngine::nativeSetUpperEngineParam(int upper, int id, float value) {return sampler().setUpperEngineParam(upper,id,value)?true:false;}   // SILVETON_ENGINES_V1
bool NativeSamplerEngine::nativeSetUpperEngineBlock(int upper, int firstId, const std::vector<float>& values) {return sampler().setUpperEngineBlock(upper,firstId,values)?true:false;}  
std::vector<float> NativeSamplerEngine::nativeUpperEngineParams(int upper) {return (sampler().upperEngineParams(upper));}
bool NativeSamplerEngine::nativeLoadLearnedModels(const std::string& file) {return sampler().loadLearnedModels(file)?true:false;}   // SILVETON_MODEL_V1
std::vector<std::string> NativeSamplerEngine::nativeLearnedModelNames() {return sampler().learnedModelNames();}
void NativeSamplerEngine::nativeLearnedModelsCounts(int& models, int& soundsInFile, int& zones) {sampler().learnedModelsCounts(models, soundsInFile, zones);}   // SILVETON_MODELS_FROM_FILE_V1
bool NativeSamplerEngine::nativeSetSoundWaveParam(int upper, int sound, int id, float value) {return sampler().setSoundWaveParam(upper,sound,id,value)?true:false;}
std::vector<float> NativeSamplerEngine::nativeSoundWaveParams(int upper, int sound) {return (sampler().soundWaveParams(upper,sound));}

std::vector<float> NativeSamplerEngine::nativeSoundSynthParams(int upper, int sound) {return (sampler().soundSynthParams(upper,sound));}

std::vector<float> NativeSamplerEngine::nativeAnalyzerFrame(int upper, bool after) {return (sampler().analyzerFrame(upper,after));}

std::vector<float> NativeSamplerEngine::nativeCombiFxState() {return (sampler().combiFxState());}
std::string NativeSamplerEngine::nativeBlendInfo(int bank, int page, int slot) {return sampler().blendInfo(makeAddress(bank, page, slot));}   // SILVETON_BLEND_INFO_V1
void NativeSamplerEngine::nativeSetSetExtraText(const std::string& text) {sampler().setSetExtraText(text);}   // SILVETON_SET_ONE_FILE_V1
std::string NativeSamplerEngine::nativeLastLoadedSetExtraText() {return sampler().lastLoadedSetExtraText();}

void NativeSamplerEngine::nativeStartScan(int mode) {sampler().startScan(static_cast<int>(mode));}

std::vector<int> NativeSamplerEngine::nativeScanInfo() {    const auto v = sampler().scanInfo();
    return std::vector<int>(v.begin(), v.end());
}

void NativeSamplerEngine::nativeSetTerca(int upperMask, int root, int cell) {sampler().setTerca(static_cast<int>(upperMask),static_cast<int>(root),static_cast<int>(cell));}

void NativeSamplerEngine::nativeSetScaleUppers(int upperMask) {sampler().setScaleUppers(static_cast<int>(upperMask));}
bool NativeSamplerEngine::nativeSetScaleTuning(bool enabled, int upperMask, int tonic, const std::vector<float>& cents, const std::string& name, bool markEdited) {
    return sampler().setScaleTuning(enabled, upperMask, tonic, cents, name, markEdited);
}
std::vector<float> NativeSamplerEngine::nativeScaleTuning() { return sampler().scaleTuning(); }
std::string NativeSamplerEngine::nativeScaleName() { return sampler().scaleName(); }

std::vector<float> NativeSamplerEngine::nativeGlobalState() {return (sampler().globalState());}

bool NativeSamplerEngine::nativeWriteGlobal() {return sampler().writeGlobal()?true:false;}

bool NativeSamplerEngine::nativeUpdateGlobal(float tune, int transpose, float gain, float low, float mid, float high, bool limiter, float ceiling, int velocityCurve, int breathCc, int expressionCc, int damperCc, bool pitchBend, bool aftertouch) {return sampler().updateGlobal(tune,transpose,gain,low,mid,high,limiter,ceiling,velocityCurve,breathCc,expressionCc,damperCc,pitchBend,aftertouch)?true:false;}

bool NativeSamplerEngine::nativeUpdateGlobalAdvanced(int scaleRoot, const std::vector<float>& scaleOffsets, int midiChannelMask, bool filterNotes, bool filterCc, bool filterPitchBend, bool filterAftertouch, float breathMin, float breathMax, float breathCurve, float expressionMin, float expressionMax, float expressionCurve, bool damperReverse) {
    if (scaleOffsets.size() < 12U) return false;
    std::array<float,12> offsets{};
    for (std::size_t i = 0; i < offsets.size(); ++i) offsets[i] = scaleOffsets[i];
    return sampler().updateGlobalAdvanced(scaleRoot, offsets, static_cast<std::uint16_t>(midiChannelMask & 0xFFFF), filterNotes, filterCc, filterPitchBend, filterAftertouch, breathMin, breathMax, breathCurve, expressionMin, expressionMax, expressionCurve, damperReverse);
}

bool NativeSamplerEngine::nativeWriteList(int bank, int page, int slot, const std::string& listName, const std::vector<int>& numbers, const std::vector<std::string>& names, const std::vector<int>& combiAddresses) {
    const std::size_t count = numbers.size();
    if (names.size() != count || combiAddresses.size() != count * 3U) return false;
    SetList list;
    list.name = listName;
    list.entries.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        ListEntry e;
        e.number = static_cast<std::uint16_t>(std::clamp(numbers[i], 0, 65535));
        e.name = names[i];
        e.combiBank = static_cast<std::uint16_t>(std::clamp(combiAddresses[i * 3U], 0, 65535));
        e.combiPage = static_cast<std::uint16_t>(std::clamp(combiAddresses[i * 3U + 1U], 0, 65535));
        e.combiSlot = static_cast<std::uint16_t>(std::clamp(combiAddresses[i * 3U + 2U], 0, 65535));
        list.entries.push_back(std::move(e));
    }
    return sampler().writeList(makeAddress(bank, page, slot), list);
}

bool NativeSamplerEngine::nativeSetListEntry(int lb, int lp, int ls, int index, int number, const std::string& name, int cb, int cp, int cs) {return sampler().setListEntry(makeAddress(lb,lp,ls),index,number,(name),makeAddress(cb,cp,cs))?true:false;}

bool NativeSamplerEngine::nativeInsertListEntry(int lb, int lp, int ls, int index, int number, const std::string& name, int cb, int cp, int cs) {return sampler().insertListEntry(makeAddress(lb,lp,ls),index,number,(name),makeAddress(cb,cp,cs))?true:false;}

bool NativeSamplerEngine::nativeRemoveListEntry(int lb, int lp, int ls, int index) {return sampler().removeListEntry(makeAddress(lb,lp,ls),index)?true:false;}

bool NativeSamplerEngine::nativeMoveListEntry(int lb, int lp, int ls, int fromIndex, int toIndex) {return sampler().moveListEntry(makeAddress(lb,lp,ls),fromIndex,toIndex)?true:false;}

bool NativeSamplerEngine::nativeMoveList(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().moveList(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool NativeSamplerEngine::nativeSetActiveListEntry(int lb, int lp, int ls, int index) {return sampler().setActiveListEntry(makeAddress(lb,lp,ls),index)?true:false;}

bool NativeSamplerEngine::nativeActivateListEntry(int lb, int lp, int ls, int index) {return sampler().activateListEntry(makeAddress(lb,lp,ls),index)?true:false;}

int NativeSamplerEngine::nativeActiveListEntry(int lb, int lp, int ls) {return static_cast<int>(sampler().activeListEntry(makeAddress(lb,lp,ls)));}

std::vector<int> NativeSamplerEngine::nativeListEntryNumbers(int lb, int lp, int ls) {return (sampler().listEntryNumbers(makeAddress(lb,lp,ls)));}

std::vector<std::string> NativeSamplerEngine::nativeListEntryNames(int lb, int lp, int ls) {    return sampler().listEntryNames(makeAddress(lb, lp, ls));
}

std::vector<int> NativeSamplerEngine::nativeListEntryCombiAddresses(int lb, int lp, int ls) {return (sampler().listEntryCombiAddresses(makeAddress(lb,lp,ls)));}

bool NativeSamplerEngine::nativeActivateProgram(int bank, int page, int slot, int upper) {return sampler().activateProgram(makeAddress(bank,page,slot),upper)?true:false;}

bool NativeSamplerEngine::nativeAssignUpperSound(int bank, int page, int slot, int upper) {return sampler().activateProgram(makeAddress(bank,page,slot),upper)?true:false;}
float NativeSamplerEngine::nativeGateReduction(int part) const{return sampler().gateReduction(part);}
void NativeSamplerEngine::nativeListenSolo(int player,int part,int key){sampler().listenSolo(player,part,key);}
std::shared_ptr<const silveton::sampler::Combi> NativeSamplerEngine::nativeKeyboardCombi() { return sampler().keyboardCombi(); }
bool NativeSamplerEngine::nativeApplyKeyboardCombi(const silveton::sampler::Combi& combi, bool markEdited) { return sampler().applyKeyboardCombi(combi,markEdited); }
bool NativeSamplerEngine::nativeAssignPreparedKeyboardSound(int upper, silveton::sampler::ProgramPtr program) { return sampler().assignPreparedKeyboardSound(upper,std::move(program)); }

bool NativeSamplerEngine::nativeClearUpperSound(int upper) {return sampler().clearUpperSound(upper)?true:false;}
bool NativeSamplerEngine::nativeClearPerformance() {return sampler().clearPerformance()?true:false;}   // SILVETON_EMPTY_START_V1

bool NativeSamplerEngine::nativeActivateCombi(int bank, int page, int slot) {return sampler().activateCombi(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeClearProgram(int bank, int page, int slot) {return sampler().clearProgram(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeClearCombi(int bank, int page, int slot) {return sampler().clearCombi(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeClearList(int bank, int page, int slot) {return sampler().clearList(makeAddress(bank,page,slot))?true:false;}

// Desktop audio backends are absent here: Android speaker / Direct ALSA jack output and the keyboard
// is read from the raw MIDI ports (both inside the engine above).
void NativeSamplerEngine::setBackends(std::unique_ptr<AudioOutput> audio, std::unique_ptr<MidiInput> midi) {
    (void)audio;
    (void)midi;
}
std::string NativeSamplerEngine::audioDeviceName() { return sampler().outputName(); }
std::vector<std::string> NativeSamplerEngine::midiSourceNames() { return std::vector<std::string>(); }

} // namespace silveton::host

