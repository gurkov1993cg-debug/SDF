// Included in ArrangerHost.cpp. These edits contain references and zone
// parameters. All PCM data stays shared with the input bank.
namespace {
using DrumProgramMap=std::map<std::uint32_t,sampler::ProgramPtr>;
using DrumSamples=std::map<std::string,sampler::SamplePtr>;
DrumSamples drumSamples(const DrumProgramMap& programs){
    DrumSamples result;
    for(const auto& entry:programs)for(const auto& layer:entry.second->layers)if(layer.multisample)
        for(const auto& zone:layer.multisample->zones)if(zone.sample&&!zone.sample->sourceIdentity.empty())
            result.emplace(zone.sample->sourceIdentity,zone.sample);
    return result;
}
std::string drumIdentity(const std::string& root,std::uint32_t address,const sampler::Program& program){
    std::ostringstream out;
    out<<std::quoted(root)<<' '<<address<<' '<<std::quoted(program.name)<<'\n';
    for(const auto& layer:program.layers)if(layer.multisample){
        out<<std::quoted(layer.name)<<'\n';
        for(const auto& z:layer.multisample->zones)if(z.sample)
            out<<int(z.keyLow)<<' '<<int(z.velocityLow)<<' '<<int(z.velocityHigh)<<' '<<int(z.transposeSemitones)<<' '
               <<z.gainDb<<' '<<z.reverse<<' '<<std::quoted(z.sample->sourceIdentity)<<'\n';
    }
    return styleEditDigest(out.str());
}
void fillDrumKeys(DrumKitDraft& draft,const sampler::Program& program){
    if(program.drumKeyGroups)draft.drumKeyGroups=*program.drumKeyGroups;
    for(std::size_t i=0;i<program.layers.size();++i){
        const auto& multi=program.layers[i].multisample;
        if(!multi)continue;
        for(const auto& z:multi->zones)if(z.keyLow==z.keyHigh && z.sample)
            draft.keys[z.keyLow].push_back({static_cast<unsigned>(i),z});
    }
    for(auto& key:draft.keys)std::stable_sort(key.begin(),key.end(),[](const auto& a,const auto& b){return a.zone.velocityLow<b.zone.velocityLow;});
}
std::string drumEditFile(const std::string& storage,const std::string& identity){
    return styleEditJoin(styleEditJoin(storage,"DrumKits"),identity+".svdk");
}
std::string encodeDrumEdit(const DrumKitDraft& draft){
    std::ostringstream out;out<<"SILVETON_DRUMKIT 2 "<<draft.identity<<'\n'<<std::setprecision(9);
    for(unsigned k=0;k<128;++k){
        const auto& group=draft.drumKeyGroups[k];
        out<<"GROUP "<<k<<' '<<int(group.exclusiveGroup)<<' '<<group.singleTrigger<<' '
           <<group.chokeFadeOutMs<<' '<<group.subgroupChokeOff<<'\n';
    }
    for(unsigned k=0;k<128;++k)for(const auto& item:draft.keys[k]){
        const auto& z=item.zone;
        out<<k<<' '<<item.layer<<' '<<int(z.velocityLow)<<' '<<int(z.velocityHigh)<<' '<<z.gainDb<<' '<<z.pan<<' '
           <<int(z.transposeSemitones)<<' '<<z.tuneCents<<' '<<z.reverse<<' '<<z.oneShot<<' '<<std::quoted(z.sample->sourceIdentity)<<'\n';
    }
    return out.str()+"END\n";
}
bool decodeDrumEdit(const std::string& text,const DrumSamples& samples,DrumKitDraft& draft,bool resolveSamples=true){
    std::istringstream in(text);
    std::string line;if(!std::getline(in,line))return false;
    const bool groups=line=="SILVETON_DRUMKIT 2 "+draft.identity;
    if(!groups&&line!="SILVETON_DRUMKIT 1 "+draft.identity)return false;
    // Version 1 edits contain no group intent, so retain the source kit's
    // decoded groups. Version 2 explicitly replaces every key, including None.
    draft.drumKeyGroups=(!groups&&draft.original&&draft.original->drumKeyGroups)
        ? *draft.original->drumKeyGroups : sampler::DrumKeyGroups{};
    std::array<bool,128> groupsSeen{};
    while(std::getline(in,line)){
        if(line=="END")return in.peek()==std::char_traits<char>::eof()&&
            (!groups||std::all_of(groupsSeen.begin(),groupsSeen.end(),[](bool seen){return seen;}));
        if(line.compare(0,6,"GROUP ")==0){
            if(!groups)return false;
            std::istringstream row(line.substr(6));int key,number,single,subgroup;float fade;
            if(!(row>>key>>number>>single>>fade>>subgroup)||!(row>>std::ws).eof()||
               key<0||key>127||number<0||number>127||(single!=0&&single!=1)||
               (subgroup!=0&&subgroup!=1)||!std::isfinite(fade)||fade<0||fade>10000||groupsSeen[key])return false;
            auto& value=draft.drumKeyGroups[key];value.exclusiveGroup=static_cast<std::uint8_t>(number);
            value.singleTrigger=single!=0;value.chokeFadeOutMs=fade;value.subgroupChokeOff=subgroup!=0;
            groupsSeen[key]=true;continue;
        }
        std::istringstream row(line);int k,l,lo,hi,pitch,reverse,oneShot;std::string id;sampler::SampleZone z;
        if(!(row>>k>>l>>lo>>hi>>z.gainDb>>z.pan>>pitch>>z.tuneCents>>reverse>>oneShot>>std::quoted(id))||
           !(row>>std::ws).eof()||k<0||k>127||l<0||l>=16||lo<1||hi>127||lo>hi||pitch< -64||pitch>63||
           !std::isfinite(z.gainDb)||z.gainDb< -96||z.gainDb>24||!std::isfinite(z.pan)||std::abs(z.pan)>1||
           !std::isfinite(z.tuneCents)||std::abs(z.tuneCents)>1200||(reverse!=0&&reverse!=1)||(oneShot!=0&&oneShot!=1))return false;
        auto& key=draft.keys[static_cast<unsigned>(k)];
        const auto found=samples.find(id);
        if((resolveSamples&&found==samples.end())||id.empty()||key.size()>=16||(!key.empty()&&key.back().zone.velocityHigh>=lo)||
           std::any_of(key.begin(),key.end(),[l](const auto& item){return item.layer==static_cast<unsigned>(l);}))return false;
        if(found!=samples.end())z.sample=found->second;
        z.keyLow=z.keyHigh=z.rootKey=static_cast<std::uint8_t>(k);
        z.velocityLow=static_cast<std::uint8_t>(lo);z.velocityHigh=static_cast<std::uint8_t>(hi);
        z.transposeSemitones=static_cast<std::int8_t>(pitch);z.reverse=reverse!=0;z.oneShot=oneShot!=0;z.nonTranspose=true;
        key.push_back({static_cast<unsigned>(l),std::move(z)});
    }
    return false;
}
}
sampler::ProgramPtr DrumKitDraft::makeProgram() const {
    if(!original||original->layers.empty())return {};
    for(const auto& group:drumKeyGroups)if(!group.valid())return {};
    auto program=std::make_shared<sampler::Program>(*original);
    program->drumKeyGroups=std::make_shared<const sampler::DrumKeyGroups>(drumKeyGroups);
    std::vector<std::shared_ptr<sampler::Multisample>> multis;
    for(const auto& layer:original->layers){
        auto m=std::make_shared<sampler::Multisample>();
        if(layer.multisample){m->name=layer.multisample->name;m->sourceIdentity=layer.multisample->sourceIdentity;}
        multis.push_back(std::move(m));
    }
    std::set<const sampler::SampleData*> warmed;
    for(const auto& k:keys)for(const auto& item:k){
        if(item.layer>=16||!item.zone.sample)return {};
        while(multis.size()<=item.layer){
            auto m=std::make_shared<sampler::Multisample>();m->name="User drum layer "+std::to_string(multis.size()+1);
            auto layer=original->layers.front();layer.name=m->name;program->layers.push_back(std::move(layer));multis.push_back(std::move(m));
        }
        if(item.zone.reverse&&item.zone.sample->stream&&warmed.insert(item.zone.sample.get()).second)
            arranger::warmPa5xReverseSampleEntry(*item.zone.sample->stream);
        multis[item.layer]->zones.push_back(item.zone);
    }
    for(std::size_t i=0;i<multis.size();++i)program->layers[i].multisample=std::move(multis[i]);
    return program;
}
