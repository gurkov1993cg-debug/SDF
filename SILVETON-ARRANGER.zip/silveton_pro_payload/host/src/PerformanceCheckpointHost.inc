// Included inside both host implementations. A failed performance WRITE must
// put back overwritten/new slots, LIST, open sound and dirty state together.
    std::shared_ptr<const PerformanceCheckpoint> performanceCheckpoint() {
        auto checkpoint = std::make_shared<PerformanceCheckpoint>();
        std::lock_guard<std::mutex> lock(controlMutex_);
        checkpoint->owner = this;
        checkpoint->library = library_;
        checkpoint->state = state_;
        checkpoint->activeListAddress = activeListAddress_;
        checkpoint->activeListEntry = activeListEntry_;
        checkpoint->scaleTargets = scaleTargets_.load(std::memory_order_acquire);
        checkpoint->edited = blendEdited_.load(std::memory_order_acquire);
        checkpoint->pendingExtra = pendingSetExtra_;
        checkpoint->loadedExtra = lastLoadedSetExtra_;
        {
            std::lock_guard<std::mutex> waveLock(waveMutex_);
            checkpoint->waves = wavePublished_;
            checkpoint->wavesPublished = wavePublishedOnce_;
        }
        {
            std::lock_guard<std::mutex> missingLock(missingMutex_);
            checkpoint->recallMissing = lastRecallMissing_;
        }
        return checkpoint;
    }

    bool restorePerformanceCheckpoint(const std::shared_ptr<const PerformanceCheckpoint>& checkpoint) {
        if (checkpoint == nullptr || checkpoint->owner != this || checkpoint->state == nullptr) {
            setTextError("Invalid performance checkpoint");
            return false;
        }
        std::lock_guard<std::mutex> lock(controlMutex_);
        library_ = checkpoint->library;
        state_ = checkpoint->state;
        activeListAddress_ = checkpoint->activeListAddress;
        activeListEntry_ = checkpoint->activeListEntry;
        pendingSetExtra_ = checkpoint->pendingExtra;
        lastLoadedSetExtra_ = checkpoint->loadedExtra;
        {
            std::lock_guard<std::mutex> waveLock(waveMutex_);
            engine_.setWaveTables(checkpoint->waves);
            wavePublished_ = checkpoint->waves;
            wavePublishedOnce_ = checkpoint->wavesPublished;
            if (checkpoint->waves != nullptr) {
                waveKeep_.push_back(checkpoint->waves);
                while (waveKeep_.size() > 8U) waveKeep_.pop_front();
            }
        }
        {
            std::lock_guard<std::mutex> missingLock(missingMutex_);
            lastRecallMissing_ = checkpoint->recallMissing;
        }
        setScaleUppers(checkpoint->scaleTargets);
        blendEdited_.store(checkpoint->edited, std::memory_order_release);
#if defined(__ANDROID__)
        damperConfig_.store(static_cast<unsigned>(state_->global.damperCc) |
            (state_->global.damperPolarityReversed ? 0x80U : 0U), std::memory_order_release);
#endif
        engine_.setState(state_);
        // Keep the disk/native error which caused the caller to roll back.
        return true;
    }
