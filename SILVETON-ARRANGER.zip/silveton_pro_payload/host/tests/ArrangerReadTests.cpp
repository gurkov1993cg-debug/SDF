#include "silveton/host/ArrangerHost.h"
#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xStyleRead.h"
#include "silveton/sampler/FsCompat.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <dirent.h>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <unistd.h>
#include <vector>

using namespace silveton;
namespace fs = silveton::fsx;
namespace {
using Bytes = std::vector<std::uint8_t>;
void check(bool condition, const std::string& message) {
    if (!condition) { std::cerr << "FAIL " << message << '\n'; std::exit(1); }
}
void append(Bytes& out, const Bytes& bytes) { out.insert(out.end(), bytes.begin(), bytes.end()); }
void text(Bytes& out, const std::string& value) { out.insert(out.end(), value.begin(), value.end()); }
void u16(Bytes& out, unsigned value) {
    out.push_back(static_cast<std::uint8_t>(value >> 8U)); out.push_back(static_cast<std::uint8_t>(value));
}
void u32(Bytes& out, std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8)
        out.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
void chunk(Bytes& out, std::uint32_t tag, const Bytes& bytes) {
    u32(out, tag); u32(out, static_cast<std::uint32_t>(bytes.size())); append(out, bytes);
}
void leaf(Bytes& out, const std::string& name, const Bytes& bytes) {
    text(out, "Leaf"); out.push_back(0); text(out, name); out.push_back(0);
    u32(out, static_cast<std::uint32_t>(bytes.size())); append(out, bytes);
}
void write(const fs::path& path, const Bytes& bytes) {
    fs::create_directories(path.parent_path());
    std::ofstream file(path.string(), std::ios::binary | std::ios::trunc);
    check(static_cast<bool>(file), "open test resource " + path.string());
    file.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    file.close(); check(static_cast<bool>(file), "write test resource " + path.string());
}
struct TemporaryDirectory {
    fs::path path;
    TemporaryDirectory() {
        char pattern[] = "/tmp/silveton-arranger-read-XXXXXX";
        const auto* created = ::mkdtemp(pattern); check(created != nullptr, "create isolated test directory");
        path = fs::path(created);
    }
    ~TemporaryDirectory() { (void)fs::remove_all(path); }
};

// Only a real directory record is needed to test Sound identity. The four-byte
// OC31 body deliberately cannot claim a decoded or playable Korg program.
Bytes pcg(const std::string& name) {
    check(name.size() <= 28, "fixture PCG name fits original field");
    Bytes fields; u16(fields, 3); u16(fields, 2); u16(fields, 28);
    text(fields, name); fields.insert(fields.end(), 28 - name.size(), 0);
    u16(fields, 0); u16(fields, 3); append(fields, {4, 0x0C, 20});
    u16(fields, 1); u16(fields, 2); append(fields, {2, 0}); u32(fields, 0x12345678);
    Bytes table; u16(table, static_cast<unsigned>(fields.size())); append(table, fields);
    Bytes children; chunk(children, 0x02000018, {11, 0, 0, 0, 0, 0, 0, 'K', 'O', 'R', 'F', 0});
    const auto directoryOffset = static_cast<std::uint32_t>(children.size() + 8);
    chunk(children, 0x05010018, table);
    const auto dataOffset = static_cast<std::uint32_t>(children.size() + 8);
    chunk(children, 0x10020038, {'O', 'C', '3', '1'});
    Bytes refs{'K', 'B', 'E', 'G'}; u32(refs, directoryOffset); u32(refs, dataOffset);
    append(refs, {'K', 'E', 'N', 'D'}); u32(refs, 2); chunk(children, 0xFE000018, refs);
    Bytes result; chunk(result, 0x01000114, children); return result;
}

Bytes keyboardSet(bool factory = false) {
    Bytes content;
    const std::array<std::string, 4> names{{"Lower.mid", "Upper1.mid", "Upper2.mid", "Upper3.mid"}};
    for (std::size_t part = 0; part < names.size(); ++part) {
        // Recall data in the real files commits at tick 24, without notes.
        // A tick-zero-only reader must not silently fall back to a GM slot.
        const std::uint8_t msb = factory ? 0 : 121;
        const std::uint8_t lsb = factory ? 0 : 66;
        const std::uint8_t program = factory ? 0 : 20;
        Bytes events{24, 0xB0, 0, msb, 0, 0xB0, 32, lsb, 0, 0xC0, program,
                     0, 0xB0, 7, 93, 0, 0xB0, 10, 72, 0, 0xB0, 11, 112, 0, 0xFF, 0x2F, 0};
        Bytes midi{'M', 'T', 'h', 'd', 0, 0, 0, 6, 0, 0, 0, 1, 1, 128, 'M', 'T', 'r', 'k'};
        u32(midi, static_cast<std::uint32_t>(events.size())); append(midi, events); leaf(content, names[part], midi);
    }
    std::string description = "<CLIP type=\"KeyboardSetClip\" subtype=\"4\" version=\"1\" release=\"0\">"
        "<RESOURCE track1=\"Lower.mid\" track2=\"Upper1.mid\" track3=\"Upper2.mid\" track4=\"Upper3.mid\"/>"
        "<PARAMS><Lower use=\"1\"/>";
    for (int part = 1; part <= 4; ++part)
        description += "<Track" + std::to_string(part) + "Params mute=\"" + (part == 1 ? "1" : "0") +
            "\" keyrangelow=\"21\" keyrangehigh=\"108\" dynamicrangelow=\"1\" dynamicrangehigh=\"127\"/>";
    description += "<KeyboardProcessing splitpoint=\"57\" globalsplit=\"0\" upperoctavetranspose=\"-1\"/></PARAMS></CLIP>";
    leaf(content, "ClipDescription.xml", Bytes(description.begin(), description.end()));
    Bytes result{'R', 'o', 'o', 't', 0, 1, 0}; u32(result, static_cast<std::uint32_t>(content.size())); append(result, content); return result;
}

std::shared_ptr<arranger::Pa5xSetBank> soundDirectory(const fs::path& root) {
    std::unique_ptr<char, decltype(&std::free)> canonical(::realpath(root.c_str(), nullptr), &std::free);
    check(canonical != nullptr, "canonical SET root");
    arranger::Pa5xKstIndex index; index.rootPath = canonical.get(); index.recognized = true;
    DIR* directory = ::opendir((root / "SOUND").c_str()); check(directory != nullptr, "open Sound directory");
    while (const auto* entry = ::readdir(directory)) {
        const std::string name = entry->d_name;
        if (name.size() < 4 || name.substr(name.size() - 4) != ".PCG") continue;
        arranger::KstResourceEntry resource; resource.kind = arranger::KstResourceKind::Sound;
        resource.relativePath = "SOUND/" + name; resource.readable = true; index.resources.push_back(resource);
    }
    ::closedir(directory);
    // An unrelated corrupt PCM must not erase a good PCG address/name. This
    // metadata-only path does not open audio resources or claim audio readiness.
    index.diagnostics.push_back({arranger::KstSeverity::Blocking, "PCM_INVALID", "PCM/RAM01.PCM", "Test: unrelated bad audio"});
    auto result = std::make_shared<arranger::Pa5xSetBank>();
    check(result->loadSoundDirectory(index), "load PCG-only metadata bank despite unrelated PCM error");
    check(result->status().recognized && result->status().soundDirectoryComplete && !result->status().indexed,
          "metadata bank remains separate from full audio inventory");
    check(result->findSound(121, 66, 20) == nullptr, "metadata-only bank does not enable audio lookup");
    return result;
}

void samePlayer(const host::ArrangerPlayerView& before, const host::ArrangerPlayerView& after) {
    check(before.name == after.name && before.sourcePath == after.sourcePath && before.loaded == after.loaded &&
          before.nativeKorgStyle == after.nativeKorgStyle && before.playing == after.playing && before.syncStart == after.syncStart &&
          before.bpm == after.bpm && before.originalBpm == after.originalBpm && before.numerator == after.numerator &&
          before.denominator == after.denominator && before.element == after.element && before.split == after.split &&
          before.available == after.available && before.soundAssignmentsReady == after.soundAssignmentsReady,
          "Keyboard Set read leaves player transport, timing, split and Style intact");
    for (std::size_t i = 0; i < before.tracks.size(); ++i) {
        const auto& a = before.tracks[i]; const auto& b = after.tracks[i];
        check(a.soundSlot == b.soundSlot && a.soundName == b.soundName && a.assigned == b.assigned &&
              a.volumeDb == b.volumeDb && a.pan == b.pan && a.mute == b.mute && a.msb == b.msb &&
              a.lsb == b.lsb && a.program == b.program && a.originalSoundName == b.originalSoundName &&
              a.originalSoundPath == b.originalSoundPath, "Keyboard Set read leaves explicit assignments and original Sound metadata intact");
    }
}
void renderOnce(host::ArrangerHost& host) {
    std::array<float, 128> output{}; host.renderAdd(output.data(), 64, 48000);
    for (const float value : output) check(value == 0.0F, "metadata read does not start playback");
}
void immediateRead(host::ArrangerHost& host, int player, const std::string& path) {
    check(host.loadStyle(player, path), "load native STG: " + host.lastError());
    const auto view = host.snapshot(player); const auto read = host.styleRead(player);
    check(read && read->valid && read->nativeStyle && read->nativeStyle->nativeKorg, "host retains typed native Style read");
    check(view.loaded && view.nativeKorgStyle && !view.playing && !view.soundAssignmentsReady,
          "loaded native Style is visible before audio adoption without fabricated assignments");
    check(view.name == read->name && view.sourcePath == read->sourcePath && view.bpm == 60 && view.originalBpm == 60 &&
          view.numerator == 5 && view.denominator == 8, "immediate source name, 60 BPM and 5/8 are not stale engine defaults");
    const auto& original = view.tracks[3];
    check(original.originalSoundAddressComplete && original.addressKnown && original.msb == 121 && original.lsb == 66 &&
          original.program == 20 && original.soundSlot == 0 && !original.assigned,
          "raw Acc1 original address remains independent of the 500 sampler slots");
}

void synthetic(const std::string& fixture) {
    TemporaryDirectory temporary;
    const auto a = temporary.path / "A.KST"; const auto b = temporary.path / "B.KST";
    const auto outside = temporary.path / "A.KST-other"; // shared prefix is not the same root
    for (const auto& root : {a, b, outside}) {
        fs::create_directories(root / "STYLE"); fs::create_directories(root / "KEYBOARDSET");
        fs::copy_file(fixture, root / "STYLE/001.Source.stg");
        write(root / "KEYBOARDSET/001.Blend.ksc", keyboardSet());
    }
    write(a / "SOUND/USER03.PCG", pcg("SET A original Sound"));
    write(b / "SOUND/USER03.PCG", pcg("SET B different Sound"));
    write(outside / "KEYBOARDSET/002.Factory.ksc", keyboardSet(true));
    write(outside / "KEYBOARDSET/003.Invalid.ksc", {'n', 'o', 't', ' ', 'a', ' ', 'K', 'S', 'C'});
    const auto bankA = soundDirectory(a); const auto bankB = soundDirectory(b);
    host::ArrangerHost host;
    check(host.installKorgSetBank(bankA), "install metadata-only SET A");
    immediateRead(host, 0, (a / "STYLE/001.Source.stg").string());
    const auto retained = host.styleRead(0); const auto native = retained->nativeStyle;
    check(host.snapshot(0).tracks[3].originalSoundName == "SET A original Sound", "native Style joins its own SET's exact PCG name");
    host.prepare(48000, 64); renderOnce(host);
    check(host.styleRead(0) == retained && host.styleRead(0)->nativeStyle == native,
          "audio adoption keeps the exact immutable Style read and native graph");
    check(host.snapshot(0).bpm == 60 && host.snapshot(0).numerator == 5 && host.snapshot(0).denominator == 8,
          "native graph adopts the source timing described before audio started");
    auto manual = std::make_shared<sampler::Program>(); manual->name = "Explicit manual assignment test";
    check(host.assignSound(0, 3, 437, manual), "set deliberately unrelated manual sampler slot");
    check(host.setTrackVolume(0, 3, -7.0F) && host.setTrackPan(0, 3, 0.25F) && host.setTrackMute(0, 3, true), "set manual track mix");
    const std::array<host::ArrangerPlayerView, 2> before{{host.snapshot(0), host.snapshot(1)}};
    check(host.readKeyboardSet((a / "KEYBOARDSET/001.Blend.ksc").string()), "read actual note-free Keyboard Set through host");
    const auto blend = host.keyboardSetRead();
    check(blend && blend->valid && blend->readComplete && !blend->soundActivationSupported && blend->splitPoint == 57,
          "typed four-part read is available without applying it to the audio engine");
    for (const auto& part : blend->parts)
        check(part.recallSetupValid && part.setupLastTick == 24 && part.msb == 121 && part.lsb == 66 && part.program == 20 &&
              part.soundName == "SET A original Sound" && part.status == arranger::Pa5xKeyboardSetSoundStatus::ExactUserSound &&
              part.volumeRaw == 93 && part.panRaw == 72 && part.expressionRaw == 112,
              "all four tick-24 original part selections resolve by raw address, not manual slot 437");
    samePlayer(before[0], host.snapshot(0)); samePlayer(before[1], host.snapshot(1));
    check(!host.readKeyboardSet((outside / "KEYBOARDSET/003.Invalid.ksc").string()) && !host.keyboardSetRead() && !host.lastError().empty(),
          "failed Keyboard Set clears stale previous read and exposes an error");
    samePlayer(before[0], host.snapshot(0)); samePlayer(before[1], host.snapshot(1));
    check(host.readKeyboardSet((a / "KEYBOARDSET/001.Blend.ksc").string()), "restore valid read before switching SET");
    check(host.installKorgSetBank(bankB) && !host.keyboardSetRead(), "new SET invalidates previous Keyboard Set read");
    check(host.styleRead(0) == retained && host.styleRead(0)->nativeStyle == native &&
          host.snapshot(0).tracks[3].originalSoundName == "SET A original Sound", "SET B does not rename an already loaded SET A Style");
    immediateRead(host, 1, (b / "STYLE/001.Source.stg").string());
    check(host.snapshot(1).tracks[3].originalSoundName == "SET B different Sound", "new Style independently resolves SET B's same raw address");
    check(host.installKorgSetBank(bankA), "reinstall SET A");
    check(host.readKeyboardSet((outside / "KEYBOARDSET/001.Blend.ksc").string()), "read User address from other root");
    for (const auto& part : host.keyboardSetRead()->parts)
        check(part.addressKnown && part.soundName.empty() && part.status == arranger::Pa5xKeyboardSetSoundStatus::BankUnavailable,
              "a similarly prefixed directory cannot borrow installed SET A User names");
    check(host.loadStyle(1, (outside / "STYLE/001.Source.stg").string()), "read Style outside installed KST");
    check(host.snapshot(1).tracks[3].originalSoundAddressComplete && host.snapshot(1).tracks[3].originalSoundName.empty(),
          "Style outside the bank's canonical root retains address without a false User Sound name");
    const auto linked = a / "STYLE/002.Outside.stg";
    check(::symlink((b / "STYLE/001.Source.stg").c_str(), linked.c_str()) == 0, "create scope-escape symlink");
    check(host.loadStyle(1, linked.string()) && host.snapshot(1).tracks[3].originalSoundName.empty(),
          "canonical-path scope rejects symlink escape from installed SET");
    host::ArrangerHost withoutBank;
    check(withoutBank.readKeyboardSet((outside / "KEYBOARDSET/002.Factory.ksc").string()), "read Factory Keyboard Set without any KST");
    for (const auto& part : withoutBank.keyboardSetRead()->parts)
        check(part.msb == 0 && part.lsb == 0 && part.program == 0 && part.soundName == "AcousticPiano XG" &&
              part.status == arranger::Pa5xKeyboardSetSoundStatus::FactorySoundRequired,
              "official exact Factory name is available without inventing a User or audio assignment");
    host.stopStreaming();
}

void collectKeyboards(const fs::path& root, std::vector<fs::path>& result) {
    DIR* directory = ::opendir(root.c_str()); check(directory != nullptr, "open corpus Keyboard Set folder");
    while (const auto* entry = ::readdir(directory)) {
        const std::string name = entry->d_name; if (name == "." || name == "..") continue;
        const auto path = root / name;
        if (fs::is_directory(path)) collectKeyboards(path, result);
        else if (path.extension().string() == ".ksc") result.push_back(path);
    }
    ::closedir(directory);
}
void corpus(const fs::path& root) {
    const auto bank = soundDirectory(root); check(bank->status().sounds == 962, "real SET retains all 962 original PCG records");
    host::ArrangerHost host; check(host.installKorgSetBank(bank), "install real read-only Sound directory");
    const auto path = root / "STYLE/01.9_8/002.Musi9_8 YORGO.stg";
    check(host.loadStyle(0, path.string()), "read Musi YORGO Style before audio starts");
    const auto view = host.snapshot(0); const auto read = host.styleRead(0);
    check(read && read->valid && read->nativeStyle && read->name == "002.Musi9_8 YORGO" && view.name == read->name &&
          std::fabs(view.originalBpm - 148.0) < 0.001 && view.bpm == view.originalBpm && view.numerator == 9 && view.denominator == 8,
          "Musi YORGO shows its real source tempo and selected 9/8 meter immediately");
    const auto& ending = read->sections[static_cast<std::size_t>(arranger::Element::Ending1)];
    check(ending.available && ending.meterKnown && ending.numerator == 4 && ending.denominator == 4,
          "Musi YORGO preserves its distinct 4/4 ending instead of imposing 9/8 on all sections");
    // The saved current Keyboard Set is SETTINGS/My Setting.ksc; the remaining
    // 771 live under KEYBOARDSET. Both use the same real four-part recall data.
    std::vector<fs::path> paths; collectKeyboards(root, paths); std::sort(paths.begin(), paths.end(),
        [](const fs::path& a, const fs::path& b) { return a.string() < b.string(); });
    check(paths.size() == 772, "all 772 real Keyboard Sets participate in the host read integration");
    std::size_t exact = 0, factory = 0, missing = 0, unsupported = 0;
    for (const auto& file : paths) {
        check(host.readKeyboardSet(file.string()), "host reads real blend " + file.string());
        const auto blend = host.keyboardSetRead(); const auto original = arranger::inspectPa5xPerformanceFile(file.string());
        check(blend && blend->valid && !blend->soundActivationSupported && original.parts.size() == 4,
              "real blend exposes four read-only parts");
        bool namesComplete = true;
        for (std::size_t i = 0; i < blend->parts.size(); ++i) {
            const auto& part = blend->parts[i]; check(original.parts[i].patches.size() == 1, "real part has one committed original selection");
            const auto& patch = original.parts[i].patches[0];
            check(part.recallSetupValid && part.channel == 0 && part.addressKnown && part.msb == patch.msb &&
                  part.lsb == patch.lsb && part.program == patch.program, "host preserves every original CC0/CC32/PC including legacy addresses");
            const auto identity = bank->resolveSoundAddress(patch.msb, patch.lsb, patch.program);
            check(part.soundName == identity.name && part.soundPath == identity.path, "host uses names from the same KST's original address directory");
            switch (part.status) {
                case arranger::Pa5xKeyboardSetSoundStatus::ExactUserSound: ++exact; check(!part.soundName.empty(), "resolved User part has exact name"); break;
                case arranger::Pa5xKeyboardSetSoundStatus::FactorySoundRequired: ++factory; check(!part.soundName.empty(), "catalogued Factory part has exact name"); break;
                case arranger::Pa5xKeyboardSetSoundStatus::MissingUserSound: ++missing; namesComplete = false; check(part.soundName.empty(), "missing User is explicit"); break;
                case arranger::Pa5xKeyboardSetSoundStatus::UnsupportedSoundAddress: ++unsupported; namesComplete = false; check(part.msb == 99, "unsupported legacy MSB is retained, never remapped"); break;
                default: check(false, "unexpected real Keyboard Set Sound status");
            }
        }
        check(blend->readComplete == namesComplete, "a parsed blend with missing names remains explicitly incomplete");
    }
    check(exact == 2542 && factory == 520 && missing == 11 && unsupported == 15,
          "all 3088 real part selections retain exact names or explicit missing/unsupported states");
    samePlayer(view, host.snapshot(0));
    for (int player = 0; player < 2; ++player) for (const auto& track : host.snapshot(player).tracks)
        check(track.soundSlot == 0 && !track.assigned, "reading all real blends creates no fabricated sampler assignments");
    std::cout << "Real SET: 772 blends / 3088 original parts; 2542 User names, 520 Factory names, 11 missing User, 15 unresolved MSB99\n";
}
} // namespace

int main(int argc, char** argv) {
    check(argc == 2 || argc == 3, "usage: arranger_read_tests NATIVE_STYLE_FIXTURE.stg [Working.KST]");
    synthetic(argv[1]); if (argc == 3) corpus(fs::path(argv[2]));
    std::cout << "PASS host native Style read timing, immutable source snapshots, isolated Keyboard Set reads and canonical KST name scope\n";
}
