#include "silveton/host/ArrangerHost.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>

using namespace silveton;

static sampler::ProgramPtr testProgram(){
    auto sample=std::make_shared<sampler::SampleData>();
    sample->sampleRate=48000;sample->rootKey=60;sample->interleaved.resize(480);
    for(std::size_t i=0;i<sample->interleaved.size();++i)
        sample->interleaved[i]=0.35F*std::sin(static_cast<float>(i)*6.283185307F/480.0F);
    sample->loop={true,0,480,0};
    auto multi=std::make_shared<sampler::Multisample>();
    sampler::SampleZone zone;zone.sample=sample;zone.rootKey=60;multi->zones.push_back(zone);
    auto program=std::make_shared<sampler::Program>();program->name="TEST ONLY — not Korg PCM";
    sampler::ProgramLayer layer;layer.multisample=multi;layer.ampEnvelope={0.001F,0.01F,1.0F,0.005F};
    program->layers.push_back(layer);return program;
}

int main(int argc,char** argv){
    assert(argc==2);
    host::ArrangerHost arranger;arranger.prepare(48000,64);
    assert(arranger.loadStyle(0,argv[1]));
    assert(arranger.snapshot(0).nativeKorgStyle&&!arranger.snapshot(0).soundAssignmentsReady);
    assert(arranger.assignSound(0,3,1,testProgram()));
    assert(arranger.snapshot(0).soundAssignmentsReady);
    assert(arranger.setTempo(0,90));
    {std::array<float,128> ignored{};arranger.renderAdd(ignored.data(),64,48000);}
    assert(arranger.snapshot(0).bpm==90&&arranger.snapshot(0).originalBpm==60);
    assert(arranger.resetTempo(0));
    {std::array<float,128> ignored{};arranger.renderAdd(ignored.data(),64,48000);}
    assert(arranger.snapshot(0).bpm==60);
    sampler::GlobalState global;global.masterGainDb=0;arranger.syncGlobal(global);
    for(const int key:{48,52,55})assert(arranger.observeMidi(0x90,static_cast<std::uint8_t>(key),100));
    assert(arranger.start(0));
    std::array<float,128> audio{};
    std::uint64_t first=std::numeric_limits<std::uint64_t>::max();
    double earlyEnergy=0,firstNoteEnergy=0,secondNoteEnergy=0;
    constexpr std::uint32_t total=300032;
    for(std::uint32_t offset=0;offset<total;){
        const auto frames=std::min<std::uint32_t>(64,total-offset);
        audio.fill(0);arranger.renderAdd(audio.data(),frames,48000);
        for(std::uint32_t i=0;i<frames;++i){
            const float value=audio[static_cast<std::size_t>(i)*2];assert(std::isfinite(value));
            const auto time=offset+i;
            if(std::fabs(value)>0.000001F)first=std::min(first,static_cast<std::uint64_t>(time));
            const double energy=static_cast<double>(value)*value;
            if(time<30000)earlyEnergy+=energy;
            if(time>=30000&&time<36000)firstNoteEnergy+=energy;
            if(time>=270000&&time<276000)secondNoteEnergy+=energy;
        }
        offset+=frames;
    }
    const auto state=arranger.snapshot(0);
    assert(state.playing&&state.nativeKorgStyle&&state.originalBpm==60&&state.bpm==60);
    assert(state.numerator==5&&state.denominator==8);
    assert(earlyEnergy<0.000000001&&first>=30000&&first<30128);
    assert(firstNoteEnergy>0.001&&secondNoteEnergy>0.001);
    // Setup has saved CC7 but no CC10/11/73. The preceding CV deliberately
    // changes those controls; the next cycle must render the same note mix.
    assert(std::abs(firstNoteEnergy-secondNoteEnergy)<firstNoteEnergy*.005);
    assert(arranger.stop(0));audio.fill(0);arranger.renderAdd(audio.data(),64,48000);
    assert(!arranger.snapshot(0).playing);arranger.stopStreaming();
    std::cout<<"Native STG -> CV transport -> sampler audio: PASS; first sound sample "<<first
             <<", 5/8 at 60 quarter-note BPM; explicit test program, not original Korg PCM\n";
}
