#include "silveton/host/ArrangerHost.h"
#include "silveton/sampler/SamplerEngine.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton;

static sampler::ProgramPtr tone() {
    auto sample = std::make_shared<sampler::SampleData>();
    sample->sampleRate = 48000;
    sample->rootKey = 48;
    sample->interleaved.resize(480);
    for (std::size_t i = 0; i < sample->interleaved.size(); ++i)
        sample->interleaved[i] = 0.4F * std::sin(static_cast<float>(i) * 6.283185307F / 480.0F);
    sample->loop = {true, 0, 480, 0};
    auto multi = std::make_shared<sampler::Multisample>();
    sampler::SampleZone zone; zone.sample = sample; zone.rootKey = 48;
    multi->zones.push_back(zone);
    auto program = std::make_shared<sampler::Program>();
    program->name = "TEST ONLY";
    sampler::ProgramLayer layer; layer.multisample = multi;
    layer.ampEnvelope = {0.001F, 0.01F, 1.0F, 0.01F};
    program->layers.push_back(layer);
    return program;
}

int main(int argc, char** argv) {
    assert(argc == 2);
    const std::string path = std::string(argv[1]) + "/arranger-audio.mid";
    const std::vector<unsigned char> track = {
        0, 0xFF, 0x51, 3, 7, 0xA1, 0x20,
        0, 0x98, 48, 100,
        96, 0x88, 48, 0,
        0, 0xFF, 0x2F, 0
    };
    std::vector<unsigned char> midi = {'M','T','h','d',0,0,0,6,0,0,0,1,0,96,'M','T','r','k',0,0,0,static_cast<unsigned char>(track.size())};
    midi.insert(midi.end(), track.begin(), track.end());
    std::ofstream file(path, std::ios::binary);
    file.write(reinterpret_cast<const char*>(midi.data()), static_cast<std::streamsize>(midi.size()));
    file.close();

    host::ArrangerHost arranger;
    assert(arranger.loadStyle(0, path));
    assert(arranger.loadStyle(1, path));
    assert(arranger.assignSound(0, 0, 1, tone()));
    assert(arranger.assignSound(1, 0, 1, tone()));
    sampler::GlobalState global;
    global.masterGainDb = 0;
    arranger.syncGlobal(global);
    arranger.prepare(48000, 128);
    assert(arranger.observeMidi(0x90, 48, 100));
    assert(arranger.observeMidi(0x90, 52, 100));
    assert(arranger.observeMidi(0x90, 55, 100));
    assert(arranger.start(0));
    std::array<float,256> audio{};
    float peak = 0;
    for (int block = 0; block < 80; ++block) {
        audio.fill(0); arranger.renderAdd(audio.data(), 128, 48000);
        for (float v : audio) { assert(std::isfinite(v)); peak = std::max(peak, std::fabs(v)); }
    }
    assert(peak > 0.01F);
    assert(arranger.stop(0));
    arranger.setCrossfade(1.0F);
    assert(arranger.start(1));
    peak = 0;
    for (int block = 0; block < 80; ++block) {
        audio.fill(0); arranger.renderAdd(audio.data(), 128, 48000);
        for (float v : audio) peak = std::max(peak, std::fabs(v));
    }
    assert(peak > 0.01F);
    assert(arranger.setTrackMute(1, 0, true));
    for (int block = 0; block < 200; ++block) {
        audio.fill(0); arranger.renderAdd(audio.data(), 128, 48000);
    }
    for (float v : audio) assert(std::fabs(v) < 0.000001F);

    global.limiterEnabled = true;
    global.limiterCeilingDb = -6;
    arranger.syncGlobal(global);
    audio.fill(2.0F);
    arranger.renderAdd(audio.data(), 128, 48000);
    const float ceiling = std::pow(10.0F, -6.0F / 20.0F);
    for (float v : audio) assert(std::isfinite(v) && std::fabs(v) <= ceiling + 0.00001F);
    const auto measured = arranger.combinedMeters({});
    assert(measured.peakLeft > 0.49F && measured.peakLeft <= ceiling + 0.00001F);
    assert(measured.limiterGainReductionDb > 10.0F);
    arranger.panic();
    arranger.stopStreaming();
    std::cout << "Arranger audio: PASS (both sample engines, crossfade, mute release, final limiter and measured output)\n";
}
