#include "silveton/host/ArrangerHost.h"
#include <array>
#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <unistd.h>

using silveton::host::ArrangerHost;
using silveton::host::ArrangerPlayerView;
namespace {
void drain(ArrangerHost& host) {
    std::array<float, 128> audio{};
    host.renderAdd(audio.data(), 64, 48000);
}
std::string read(const std::string& path) {
    std::ifstream file(path);
    return {std::istreambuf_iterator<char>(file), {}};
}
void write(const std::string& path, const std::string& body) {
    std::ofstream file(path, std::ios::binary);
    file << body;
    assert(file.good());
}
std::string change(std::string body, const std::string& from, const std::string& to) {
    const auto position = body.find(from);
    assert(position != std::string::npos);
    body.replace(position, from.size(), to);
    return body;
}
std::string globalLine(const std::string& body) {
    const auto start = body.find("GLOBAL ");
    assert(start != std::string::npos);
    return body.substr(start, body.find('\n', start) - start);
}
bool same(const ArrangerPlayerView& a, const ArrangerPlayerView& b) {
    if (a.loaded != b.loaded || a.sourcePath != b.sourcePath || a.playing != b.playing ||
        a.memory != b.memory || a.memoryMode != b.memoryMode || a.split != b.split || a.bpm != b.bpm ||
        a.autoFill != b.autoFill || a.syncStart != b.syncStart ||
        a.chordRecognitionMode != b.chordRecognitionMode || a.chordScanArea != b.chordScanArea ||
        a.splitEnabled != b.splitEnabled || a.bassInversion != b.bassInversion ||
        a.damperLatch != b.damperLatch || a.tempoLock != b.tempoLock ||
        a.originalBpm != b.originalBpm || a.nativeKorgStyle != b.nativeKorgStyle ||
        a.soundAssignmentsReady != b.soundAssignmentsReady) return false;
    for (int t = 0; t < 8; ++t) {
        const auto& x = a.tracks[t];
        const auto& y = b.tracks[t];
        if (x.soundSlot != y.soundSlot || x.pan != y.pan || x.volumeDb != y.volumeDb ||
            x.mute != y.mute || x.assigned != y.assigned || x.msb != y.msb ||
            x.lsb != y.lsb || x.program != y.program || x.addressKnown != y.addressKnown ||
            x.addressVaries != y.addressVaries) return false;
    }
    return true;
}
void rejectedWithoutMutation(ArrangerHost& host, const std::string& path, const std::string& body) {
    write(path, body);
    const auto a = host.snapshot(0), b = host.snapshot(1);
    assert(!host.loadSetup(path));
    assert(!host.lastError().empty());
    assert(same(a, host.snapshot(0)) && same(b, host.snapshot(1)));
    drain(host);
    assert(same(a, host.snapshot(0)) && same(b, host.snapshot(1)));
}
void writeMidi(const std::string& path, std::uint32_t micros, std::uint8_t numerator) {
    std::vector<std::uint8_t> track{0, 0xFF, 0x51, 3,
        static_cast<std::uint8_t>(micros >> 16U), static_cast<std::uint8_t>(micros >> 8U),
        static_cast<std::uint8_t>(micros), 0, 0xFF, 0x58, 4, numerator, 2, 24, 8,
        0, 0x90, 60, 100, 0x83, 0x60, 0x80, 60, 0, 0, 0xFF, 0x2F, 0};
    std::vector<std::uint8_t> file{'M','T','h','d',0,0,0,6,0,0,0,1,1,0xE0,'M','T','r','k'};
    const auto size = static_cast<std::uint32_t>(track.size());
    for (int shift = 24; shift >= 0; shift -= 8)
        file.push_back(static_cast<std::uint8_t>(size >> static_cast<unsigned>(shift)));
    file.insert(file.end(), track.begin(), track.end());
    std::ofstream stream(path, std::ios::binary);
    stream.write(reinterpret_cast<const char*>(file.data()), static_cast<std::streamsize>(file.size()));
    assert(stream.good());
}
void sourceTempoTest(const std::string& directory) {
    const auto first = directory + "/original 80.mid", second = directory + "/original 187.5.mid";
    writeMidi(first, 750000, 3);
    writeMidi(second, 320000, 5);
    ArrangerHost host;
    host.prepare(48000, 64);
    host.stopStreaming();
    assert(host.loadStyle(0, first));
    drain(host);
    auto snapshot = host.snapshot(0);
    assert(snapshot.originalBpm == 80.0 && snapshot.bpm == 80.0);
    assert(snapshot.numerator == 3 && snapshot.denominator == 4);
    assert(!snapshot.nativeKorgStyle && !snapshot.soundAssignmentsReady);
    assert(!snapshot.playbackWarning.empty());
    assert(host.setTempo(0, 104.25));
    assert(host.setTempoLock(true, 0));
    drain(host);
    assert(host.loadStyle(0, second));
    drain(host);
    snapshot = host.snapshot(0);
    assert(snapshot.originalBpm == 187.5 && snapshot.bpm == 104.25 && snapshot.tempoLock);
    assert(snapshot.numerator == 5 && snapshot.denominator == 4);
    assert(host.snapshot(1).bpm == 104.25);
    assert(host.setTempoLock(false));
    drain(host);
    assert(host.loadStyle(0, first));
    drain(host);
    assert(host.snapshot(0).bpm == 80.0);
    ::unlink(first.c_str());
    ::unlink(second.c_str());
}
void nativeAssignmentsTest(const std::string& source, const std::string& directory) {
    ArrangerHost host;
    host.prepare(48000, 64);
    host.stopStreaming();
    auto sound = std::make_shared<silveton::sampler::Program>();
    sound->name = "Explicit assignment fixture";
    for (int t = 0; t < 8; ++t) assert(host.assignSound(0, t, 1, sound));
    assert(host.loadStyle(0, source));
    drain(host);
    auto view = host.snapshot(0);
    assert(view.nativeKorgStyle && view.loaded && !view.soundAssignmentsReady);
    for (const auto& track : view.tracks) assert(!track.assigned && track.soundSlot == 0);
    assert(!view.playbackWarning.empty());
    for (int t = 0; t < 8; ++t) assert(host.assignSound(0, t, 1, sound));
    assert(host.snapshot(0).soundAssignmentsReady);
    assert(host.loadStyle(0, source)); // same source keeps deliberate assignments
    drain(host);
    for (const auto& track : host.snapshot(0).tracks) assert(track.assigned && track.soundSlot == 1);
    const auto copy = directory + "/different native source.stg";
    write(copy, read(source));
    assert(host.loadStyle(0, copy));
    drain(host);
    view = host.snapshot(0);
    assert(view.nativeKorgStyle && !view.soundAssignmentsReady);
    for (const auto& track : view.tracks) assert(!track.assigned && track.soundSlot == 0);
    const auto broken = directory + "/broken native source.stg";
    write(broken, "invalid STG");
    assert(!host.loadStyle(0, broken));
    assert(same(view, host.snapshot(0)));
    ::unlink(copy.c_str());
    ::unlink(broken.c_str());
}
void sourceTempoRangeTest(const std::string& directory) {
    const auto midi = directory + "/source tempo range.mid";
    const auto setup = directory + "/source tempo range.SVARR";
    ArrangerHost host;
    host.prepare(48000, 64);
    host.stopStreaming();
    // SMF stores integer microseconds; these are approximately300.1/350,
    // followed by exactly400. Every accepted source must survive save/load.
    for (const std::uint32_t micros : {199933U, 171429U, 150000U}) {
        writeMidi(midi, micros, 4);
        assert(host.loadStyle(0, midi));
        drain(host);
        const double tempo = 60000000.0 / micros;
        assert(host.snapshot(0).bpm == tempo && host.snapshot(0).originalBpm == tempo);
        assert(host.saveSetup(setup));
        assert(host.setTempo(0, 120));
        drain(host);
        assert(host.loadSetup(setup));
        drain(host);
        assert(host.snapshot(0).bpm == tempo && host.snapshot(0).originalBpm == tempo);
    }
    ::unlink(midi.c_str());
    ::unlink(setup.c_str());
}
}

int main(int argc, char** argv) {
    char pattern[] = "/tmp/arranger host controls XXXXXX";
    const char* directory = ::mkdtemp(pattern);
    assert(directory != nullptr);
    const std::string folder = directory, path = folder + "/setup with spaces.SVARR";
    ArrangerHost host;
    host.prepare(48000, 64);
    host.stopStreaming();
    // Full persistent sessions carry Velocity preferences; invalid values are rejected.
    assert(host.setVelocityControl(4,103,1));drain(host);
    const auto velocitySession=host.persistentSession();assert(velocitySession.find("VELOCITY 4 103 1\n")!=std::string::npos);
    assert(!host.restorePersistentSession(change(velocitySession,"VELOCITY 4 103 1","VELOCITY 4 128 1")));
    assert(host.setVelocityControl(0,95,0));drain(host);
    assert(host.restorePersistentSession(velocitySession));drain(host);
    assert(host.snapshot(0).velocityControl==4&&host.snapshot(0).velocityThreshold==103&&host.snapshot(0).velocityPlayer==1);
    assert(host.persistentSessionRestoreCommitted());
    assert(host.setVelocityControl(0,95,0));drain(host);
    const auto initial = host.snapshot(0);
    assert(initial.chordRecognitionMode == 2 && initial.chordScanArea == 1 &&
           initial.splitEnabled && !initial.bassInversion && !initial.damperLatch && !initial.tempoLock);
    assert(host.setChordRecognitionMode(4) && host.setChordScanArea(3) && host.setSplitEnabled(false) &&
           host.setBassInversion(true) && host.setDamperLatch(true) && host.setSplit(55) && host.setMemory(false) && host.setMemoryMode(2));
    host.setCrossfade(.35F);
    assert(same(initial, host.snapshot(0))); // queued controls are not displayed as applied
    assert(host.saveSetup(path));
    assert(read(path).find("GLOBAL 60 1 ") != std::string::npos);
    drain(host);
    assert(host.setTempo(0, 111.25) && host.setTempo(1, 144.5));
    drain(host);
    assert(host.setTempoLock(true, 1));
    assert(!host.snapshot(0).tempoLock);
    drain(host);
    assert(host.snapshot(0).bpm == 144.5 && host.snapshot(1).bpm == 144.5);
    assert(host.setTempo(0, 98.75));
    drain(host);
    const auto applied = host.snapshot(0);
    assert(applied.chordRecognitionMode == 4 && applied.chordScanArea == 3 && !applied.splitEnabled &&
           applied.bassInversion && applied.damperLatch && applied.split == 55 && !applied.memory && applied.memoryMode==2 &&
           applied.tempoLock && applied.bpm == 98.75 && host.snapshot(1).bpm == 98.75);
    assert(!host.setChordRecognitionMode(-1) && !host.setChordRecognitionMode(5) &&
           !host.setChordScanArea(-1) && !host.setChordScanArea(4) &&
           !host.setTempoLock(true, -1) && !host.setTempoLock(true, 2));
    drain(host);
    assert(same(applied, host.snapshot(0)));
    assert(host.saveSetup(path));
    const auto v4=read(path);
    assert(v4.find("SILVETON_ARRANGER 4\n")==0);
    const auto global4=globalLine(v4);
    auto v3=change(v4,"SILVETON_ARRANGER 4\n","SILVETON_ARRANGER 3\n");
    v3=change(v3,global4,global4.substr(0,global4.find_last_of(' ')));
    assert(host.setTempoLock(false) && host.setChordRecognitionMode(3) && host.setChordScanArea(0) && host.setMemoryMode(1));
    drain(host);
    assert(host.setTempo(0, 112) && host.setTempo(1, 113));
    drain(host);
    assert(host.loadSetup(path));
    assert(!host.snapshot(0).tempoLock);
    drain(host);
    assert(same(applied, host.snapshot(0)) && host.snapshot(1).bpm == 98.75);

    // Version 2 has the five chord controls, but no Tempo Lock field.
    auto v2 = change(v3, "SILVETON_ARRANGER 3\n", "SILVETON_ARRANGER 2\n");
    const auto global3 = globalLine(v3);
    const auto global2 = global3.substr(0, global3.find_last_of(' '));
    v2 = change(v2, global3, global2);
    write(path, v2);
    assert(host.loadSetup(path));
    drain(host);
    assert(!host.snapshot(0).tempoLock && host.snapshot(0).chordRecognitionMode == 4);
    auto independent = change(v2, "PLAYER 0 \"\" 98.75", "PLAYER 0 \"\" 104.5");
    independent = change(independent, "PLAYER 1 \"\" 98.75", "PLAYER 1 \"\" 121.25");
    write(path, independent);
    assert(host.loadSetup(path));
    drain(host);
    assert(host.snapshot(0).bpm == 104.5 && host.snapshot(1).bpm == 121.25);

    // Version 1 retains the original one-note recognition behavior.
    auto v1 = change(v2, "SILVETON_ARRANGER 2\n", "SILVETON_ARRANGER 1\n");
    std::istringstream global(global2);
    std::string kind;
    int split, memory;
    float crossfade;
    global >> kind >> split >> memory >> crossfade;
    std::ostringstream original;
    original << "GLOBAL " << split << ' ' << memory << ' ' << crossfade;
    v1 = change(v1, global2, original.str());
    write(path, v1);
    assert(host.loadSetup(path));
    drain(host);
    const auto legacy = host.snapshot(0);
    assert(legacy.chordRecognitionMode == 2 && legacy.chordScanArea == 1 && legacy.splitEnabled &&
           !legacy.bassInversion && !legacy.damperLatch && !legacy.tempoLock && legacy.split == 55 && !legacy.memory);

    std::vector<std::string> invalid;
    for (const auto& replacement : std::vector<std::string>{
        "GLOBAL 55 0 0.35 -1 3 0 1 1 1", "GLOBAL 55 0 0.35 5 3 0 1 1 1",
        "GLOBAL 55 0 0.35 4 4 0 1 1 1", "GLOBAL 55 0 0.35 4 -1 0 1 1 1",
        "GLOBAL 55 2 0.35 4 3 0 1 1 1", "GLOBAL 55 0 0.35 4 3 2 1 1 1",
        "GLOBAL 55 0 0.35 4 3 0 -1 1 1", "GLOBAL 55 0 0.35 4 3 0 1 true 1",
        "GLOBAL 0 0 0.35 4 3 0 1 1 1", "GLOBAL 55 0 inf 4 3 0 1 1 1",
        "GLOBAL 55 0 0.35 4 3 0 1 1 2", "GLOBAL 55 0 0.35 4 3 0 1 1 true",
        "GLOBAL 55 0 0.35 4 3 0 1 1", "GLOBAL 55 0 0.35 4 3 0 1 1 1 EXTRA"})
        invalid.push_back(change(v3, global3, replacement));
    invalid.push_back(change(v3, "SILVETON_ARRANGER 3\n", "SILVETON_ARRANGER 5\n"));
    invalid.push_back(change(v4,global4,global4.substr(0,global4.find_last_of(' '))+" 3"));
    invalid.push_back(v3 + global3 + '\n');
    invalid.push_back(v3 + "UNKNOWN 1\n");
    invalid.push_back(change(v3, "PLAYER 0 \"\" 98.75 1 0", "PLAYER 0 notquoted 98.75 1 0"));
    invalid.push_back(change(v3, "PLAYER 0 \"\" 98.75 1 0", "PLAYER 0 \"/definitely/missing/style.mid\" 98.75 1 0"));
    invalid.push_back(change(v3, "PLAYER 1 \"\" 98.75", "PLAYER 1 \"\" 99.5"));
    invalid.push_back(change(v3, "TRACK 0 0 0 0 0 0", "TRACK 0 0 501 0 0 0"));
    invalid.push_back(change(v3, "TRACK 0 0 0 0 0 0", "TRACK 0 0 0 0 0 2"));
    invalid.push_back(change(v3, "TRACK 0 0 0 0 0 0\n", ""));
    invalid.push_back(std::string(1024 * 1024 + 1, 'x'));
    for (const auto& body : invalid) rejectedWithoutMutation(host, path, body);
    write(path, v3);
    for (int i = 0; i < 1024; ++i) assert(host.setAutoFill(0, true));
    assert(!host.loadSetup(path));
    assert(host.lastError().find("not applied") != std::string::npos);
    assert(same(legacy, host.snapshot(0)));
    drain(host);
    assert(same(legacy, host.snapshot(0)));
    for (int i = 0; i < 1023; ++i) assert(host.setAutoFill(0, true));
    assert(!host.loadSetup(path));
    assert(host.lastError().find("partly applied") != std::string::npos);
    drain(host);
    sourceTempoTest(folder);
    sourceTempoRangeTest(folder);
    if (argc == 2) nativeAssignmentsTest(argv[1], folder);
    ::unlink(path.c_str());
    ::rmdir(folder.c_str());
    std::cout << "PASS actual host snapshots, shared Tempo Lock, source tempo/meter, v3/v2/v1 setup and strict failures\n";
}
