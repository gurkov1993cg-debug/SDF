#include "silveton/host/ArrangerHost.h"
#include "silveton/arranger/Pa5xSampleIndex.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <string>
#include <unistd.h>

using namespace silveton;

namespace {
constexpr double outputRate = 48000.0;
constexpr std::uint32_t blockFrames = 64;

float block(host::ArrangerHost& instrument) {
    std::array<float, blockFrames * 2> audio{};
    instrument.renderAdd(audio.data(), blockFrames, outputRate);
    float peak = 0.0F;
    for (const float value : audio) {
        assert(std::isfinite(value)); peak = std::max(peak, std::fabs(value));
    }
    return peak;
}

void stoppedIsSilent(host::ArrangerHost& instrument) {
    instrument.stopPcmPreview();
    for (int i = 0; i < 4; ++i) assert(block(instrument) < 0.0000001F);
}

void unavailableSelectionFailsClosed() {
    host::ArrangerHost instrument; instrument.prepare(outputRate, blockFrames);
    assert(!instrument.pcmPreview().ready && !instrument.playPcmPreview());
    assert(!instrument.assignPcmPreview(0, 0));
    assert(!instrument.loadPcmPreview("/missing/silveton-preview.pcm", "/missing/silveton-preview.kmp", 1));
    const auto failed = instrument.pcmPreview();
    assert(!failed.ready && !failed.error.empty() && failed.name.empty() && failed.frames == 0);
    assert(!instrument.playPcmPreview() && !instrument.assignPcmPreview(0, 0));
    stoppedIsSilent(instrument); instrument.stopStreaming();
}

void transientAssignmentIsNotSaved(host::ArrangerHost& instrument) {
    assert(instrument.assignPcmPreview(0, 0));
    const auto assigned = instrument.snapshot(0).tracks[0];
    assert(assigned.assigned && assigned.soundSlot == 0 && !assigned.soundName.empty());
    assert(!instrument.assignPcmPreview(-1, 0)); assert(!instrument.assignPcmPreview(2, 0));
    assert(!instrument.assignPcmPreview(0, -1)); assert(!instrument.assignPcmPreview(0, 8));
    char path[] = "/tmp/silveton-pcm-preview-XXXXXX";
    const int file = ::mkstemp(path); assert(file >= 0); ::close(file);
    assert(!instrument.saveSetup(path));
    assert(instrument.lastError().find("temporary") != std::string::npos);
    instrument.clearSoundAssignments();
    assert(instrument.saveSetup(path));
    host::ArrangerHost restored; restored.prepare(outputRate, blockFrames);
    assert(restored.loadSetup(path));
    for (int player = 0; player < 2; ++player)
        for (const auto& track : restored.snapshot(player).tracks) assert(!track.assigned);
    restored.stopStreaming(); assert(::unlink(path) == 0);
}

void allUploadedRecordingsRender(const std::string& pcmPath, const std::string& kmpPath) {
    const auto pcm = arranger::inspectPa5xSampleFile(pcmPath);
    const auto kmp = arranger::inspectPa5xSampleFile(kmpPath);
    assert(pcm.valid && pcm.objects.size() == 93 && kmp.valid && kmp.multisampleMappingDecoded);
    host::ArrangerHost instrument; instrument.prepare(outputRate, blockFrames);
    std::size_t rendered = 0, unknownRootKeys = 0; float smallestPeak = std::numeric_limits<float>::max();
    for (const auto& object : pcm.objects) {
        const auto metadata = std::find_if(kmp.samples.begin(), kmp.samples.end(), [&](const arranger::Pa5xKmpSample& sample) {
            return sample.resourceId == object.resourceId;
        });
        assert(metadata != kmp.samples.end());
        const bool loaded = instrument.loadPcmPreview(pcmPath, kmpPath, object.resourceId);
        if (!loaded) std::fprintf(stderr, "PCM preview load failed for %s (UID %016llX): %s\n",
            object.name.c_str(), static_cast<unsigned long long>(object.resourceId), instrument.pcmPreview().error.c_str());
        assert(loaded);
        const auto selected = instrument.pcmPreview();
        assert(selected.ready && selected.error.empty() && selected.name == object.name);
        assert(selected.sampleRate == object.sampleRate && selected.frames == object.encodedSampleCount);
        const int expectedRoot = metadata->originalNote <= 127 ? metadata->originalNote : -1;
        assert(selected.rootKey == expectedRoot); unknownRootKeys += expectedRoot < 0 ? 1U : 0U;
        assert(instrument.playPcmPreview());
        const auto maximumFrames = static_cast<std::uint64_t>(std::ceil(
            static_cast<double>(selected.frames) * outputRate / static_cast<double>(selected.sampleRate))) + 4096U;
        float peak = 0.0F;
        for (std::uint64_t frame = 0; frame < maximumFrames && peak < 0.0000001F; frame += blockFrames)
            peak = std::max(peak, block(instrument));
        if (!(peak >= 0.0000001F)) {
            std::fprintf(stderr, "No audible PCM preview for %s\n", selected.name.c_str());
            assert(false);
        }
        smallestPeak = std::min(smallestPeak, peak); ++rendered;
        stoppedIsSilent(instrument);
        if (rendered == 1) transientAssignmentIsNotSaved(instrument);
    }
    assert(rendered == 93 && unknownRootKeys == 2 && smallestPeak > 0.0F);

    // A failed request while a valid recording is sounding must stop that
    // recording and invalidate Play/Assign, rather than reuse a stale program.
    const auto uid = pcm.objects.front().resourceId;
    assert(instrument.loadPcmPreview(pcmPath, kmpPath, uid));
    assert(instrument.playPcmPreview()); (void)block(instrument);
    assert(!instrument.loadPcmPreview(pcmPath, kmpPath, std::numeric_limits<std::uint64_t>::max()));
    auto failed = instrument.pcmPreview();
    assert(!failed.ready && !failed.error.empty() && failed.name.empty() && failed.frames == 0);
    assert(!instrument.playPcmPreview() && !instrument.assignPcmPreview(0, 0));
    stoppedIsSilent(instrument);
    assert(instrument.loadPcmPreview(pcmPath, kmpPath, uid));
    assert(!instrument.loadPcmPreview(pcmPath, kmpPath + ".missing", uid));
    assert(!instrument.pcmPreview().ready && !instrument.playPcmPreview());
    stoppedIsSilent(instrument);
    instrument.stopStreaming();
    std::printf("PCM preview corpus: %zu original recordings produce finite nonzero audio at exact source metadata\n", rendered);
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 1 && argc != 3) { std::fputs("Usage: Pa5xPcmPreviewTests [RAM01.PCM RAM.KMP]\n", stderr); return 2; }
    unavailableSelectionFailsClosed();
    if (argc == 3) {
        allUploadedRecordingsRender(argv[1], argv[2]);
        std::puts("Pa5X PCM preview host: PASS (93 recordings, render/stop, selection safety, explicit transient assignment)");
    } else {
        std::puts("PCM preview corpus skipped: pass RAM01.PCM and RAM.KMP to exercise the supplied recordings");
        std::puts("Pa5X PCM preview host: PASS (empty selection and failure gates)");
    }
    return 0;
}
