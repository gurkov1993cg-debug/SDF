#include "silveton/host/ArrangerHost.h"
#include "silveton/sampler/SamplerEngine.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <unistd.h>

using namespace silveton;

static sampler::ProgramPtr testProgram() {
    auto sample = std::make_shared<sampler::SampleData>();
    sample->name = "Audio fixture";
    sample->sampleRate = 48000;
    sample->rootKey = 60;
    sample->interleaved.resize(48000);
    for (std::size_t i = 0; i < sample->interleaved.size(); ++i)
        sample->interleaved[i] = 0.3F * std::sin(static_cast<float>(i) * 0.034245F);
    auto multi = std::make_shared<sampler::Multisample>();
    sampler::SampleZone zone;
    zone.sample = sample;
    multi->zones.push_back(zone);
    auto program = std::make_shared<sampler::Program>();
    program->name = "Audio fixture";
    sampler::ProgramLayer layer;
    layer.multisample = multi;
    program->layers.push_back(layer);
    return program;
}

static void writeMidi(const std::filesystem::path& path) {
    std::vector<std::uint8_t> track;
    for (int channel = 0; channel < 8; ++channel)
        track.insert(track.end(), {0, static_cast<std::uint8_t>(0x90 + channel), 60, 100});
    track.insert(track.end(), {0x83, 0x60, 0x80, 60, 0});
    for (int channel = 1; channel < 8; ++channel)
        track.insert(track.end(), {0, static_cast<std::uint8_t>(0x80 + channel), 60, 0});
    track.insert(track.end(), {0, 0xFF, 0x2F, 0});
    std::vector<std::uint8_t> bytes{'M','T','h','d',0,0,0,6,0,0,0,1,1,0xE0,'M','T','r','k'};
    const auto count = static_cast<std::uint32_t>(track.size());
    for (int shift = 24; shift >= 0; shift -= 8) bytes.push_back(static_cast<std::uint8_t>(count >> shift));
    bytes.insert(bytes.end(), track.begin(), track.end());
    std::ofstream file(path, std::ios::binary);
    file.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    assert(file.good());
}

static void finalBusTest() {
    host::ArrangerHost host;
    host.prepare(48000, 64);
    sampler::GlobalState global;
    global.limiterEnabled = true;
    global.limiterCeilingDb = -6;
    host.syncGlobal(global);
    std::array<float, 128> audio;
    audio.fill(2.0F);
    host.renderAdd(audio.data(), 64, 48000);
    host.recordBlockCost(17.5F);
    const auto meters = host.combinedMeters({});
    const auto peak = *std::max_element(audio.begin(), audio.end());
    assert(peak <= std::pow(10.0F, -6.0F / 20.0F) + 0.000001F);
    assert(std::fabs(meters.peakLeft - peak) < 0.000001F);
    assert(std::fabs(meters.peakRight - peak) < 0.000001F);
    assert(meters.limiterGainReductionDb > 12.0F);
    assert(meters.cpuLoadPercent == 17.5F);
    global.limiterEnabled = false;
    host.syncGlobal(global);
    audio.fill(0.25F);
    host.renderAdd(audio.data(), 64, 48000);
    for (float v : audio) assert(v == 0.25F);
    assert(host.combinedMeters({}).limiterGainReductionDb == 0.0F);
    host.stopStreaming();
}

static void eighthTrackAndFilterTest(const std::filesystem::path& directory) {
    const auto midi = directory / "eight-tracks.mid";
    writeMidi(midi);
    host::ArrangerHost host;
    host.prepare(48000, 64);
    sampler::GlobalState global;
    global.midiInputChannelMask = 1;
    global.filterControlChange = true;
    global.damperPolarityReversed = true;
    host.syncGlobal(global);
    assert(host.loadStyle(0, midi.string()));
    assert(host.assignSound(0, 7, 1, testProgram()));
    assert(host.observeMidi(0x90, 48, 100));
    assert(host.start(0));
    std::array<float, 128> audio;
    double energy = 0;
    for (int block = 0; block < 20; ++block) {
        audio.fill(0);
        host.renderAdd(audio.data(), 64, 48000);
        for (float v : audio) energy += static_cast<double>(v) * v;
    }
    assert(energy > 0.01);
    assert(host.snapshot(0).tracks[7].assigned);
    assert(host.snapshot(0).tracks[7].peak > 0);
    assert(!host.snapshot(1).loaded);
    const auto setup = directory / "performance.SVARR";
    assert(host.saveSetup(setup.string()));
    assert(host.loadStyle(1, midi.string()));
    assert(host.snapshot(1).loaded);
    assert(host.loadSetup(setup.string()));
    audio.fill(0);
    host.renderAdd(audio.data(), 64, 48000);
    assert(!host.snapshot(1).loaded);
    host.stopStreaming();
}

int main() {
    char temporary[] = "/tmp/silveton-arranger-host-XXXXXX";
    const char* directory = ::mkdtemp(temporary);
    assert(directory != nullptr);
    finalBusTest();
    eighthTrackAndFilterTest(directory);
    std::filesystem::remove_all(directory);
    std::puts("Arranger host: PASS (final mix limiter/meters, eighth sample part, input filter isolation, setup clear)");
}
