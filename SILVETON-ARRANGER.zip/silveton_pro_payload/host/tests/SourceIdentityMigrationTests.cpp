#include "silveton/host/ArrangerHost.h"
#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "silveton/sampler/SvBankFormat.h"
#include "../../core/tests/fixtures/PaSeriesBankFixtures.h"

#include <array>
#include <cmath>
#include <filesystem>
#include <iomanip>
#include <iterator>
#include <sstream>

using namespace silveton;
using silveton::test::pa_series::check;
namespace {
constexpr int kTrack = 3;
constexpr int kSoundSlot = 1;
constexpr const char* kSourceUid = "Authored PCM identity migration UID";

void pump(host::ArrangerHost& arranger) {
    std::array<float,128> audio{};
    arranger.renderAdd(audio.data(),64,48000);
}
std::string readBytes(const std::filesystem::path& path) {
    std::ifstream file(path,std::ios::binary);
    check(bool(file),"saved migration fixture can be read");
    return {std::istreambuf_iterator<char>(file),{}};
}
void writeBytes(const std::filesystem::path& path,const std::string& bytes) {
    std::ofstream file(path,std::ios::binary);
    file.write(bytes.data(),static_cast<std::streamsize>(bytes.size()));
    check(bool(file),"saved migration fixture can be written");
}
std::string withHeader(std::string bytes,const char* from,const char* to) {
    const std::string prefix=std::string(from)+"\n";
    check(bytes.compare(0,prefix.size(),prefix)==0,"fixture has the expected current format header");
    bytes.replace(0,prefix.size(),std::string(to)+"\n");
    return bytes;
}
std::string digest(const std::string& bytes) {
    const auto hash=sampler::sha256(reinterpret_cast<const std::uint8_t*>(bytes.data()),bytes.size());
    constexpr char hex[]="0123456789abcdef";
    std::string out;
    for(const auto byte:hash){out+=hex[byte>>4U];out+=hex[byte&15U];}
    return out;
}

// Independently authored former/current importer results. Do not call the
// production compatibility projection to create the expected old identity.
sampler::ProgramPtr sound(bool retainedVelocityZone,const std::string& uid=kSourceUid,
                          float editedGain=0.0F) {
    auto pcm=std::make_shared<sampler::SampleData>();
    pcm->name="Authored PCM";pcm->sourceIdentity=uid;
    pcm->sampleRate=48000;pcm->channels=1;
    pcm->interleaved.assign(16U,uid==kSourceUid?0.1F:0.2F);
    auto multi=std::make_shared<sampler::Multisample>();
    multi->name="Authored shared multisample";
    sampler::SampleZone zone;zone.sample=pcm;multi->zones.push_back(zone);
    auto program=std::make_shared<sampler::Program>();
    program->name="Same named source Sound";
    program->sourceVoiceAssignment.present=true;
    program->sourceVoiceAssignment.resourceVersion=2U;
    const float headroom=-10.0F*std::log10(2.0F);
    for(unsigned i=0;i<2U;++i){
        sampler::ProgramLayer layer;layer.multisample=multi;
        layer.velocityLow=64U;layer.velocityHigh=127U;
        layer.sourcePortamento.present=true;layer.sourcePortamento.resourceVersion=2U;
        layer.sourceAmpEnvelope.present=true;
        layer.ampEnvelope={0.001F,0.0F,1.0F,0.015F};
        auto profile=std::make_shared<sampler::SourceOscillatorDsp>();
        profile->resourceVersion=2U;profile->layoutCorroborated=true;
        profile->oscillatorIndex=static_cast<std::uint8_t>(i);
        profile->scaledVelocityDecoded=true;profile->scaledVelocityRaw={{0U,127U}};
        profile->velocityZonePresent=retainedVelocityZone;
        profile->velocityZoneRaw=retainedVelocityZone?
            std::array<std::uint8_t,2>{{static_cast<std::uint8_t>(10U+10U*i),127U}}:
            std::array<std::uint8_t,2>{{0U,127U}};
        const auto bytes=sampler::encodeSourceOscillatorDsp(*profile);
        check(bytes.size()==(retainedVelocityZone?181U:178U)&&bytes[0]==(retainedVelocityZone?2U:1U),
              "fixture represents exact old SVOD schema1 and current schema2");
        layer.sourceOscillatorDsp=profile;
        // Before the original OSC input zones were retained, both oscillators
        // belonged to one identical-playback group and received extra headroom.
        layer.levelDb=retainedVelocityZone?headroom:headroom-10.0F*std::log10(2.0F);
        if(i==0U)layer.levelDb+=editedGain;
        program->layers.push_back(layer);
    }
    return program;
}

std::string trackIdentity(const std::string& session) {
    std::istringstream input(session);std::string line;
    while(std::getline(input,line)){
        std::istringstream row(line);std::string tag;int player=-1,track=-1;
        if(!(row>>tag>>player>>track)||tag!="TRACK"||player!=0||track!=kTrack)continue;
        int slot=0,mute=0,binding=0,mask=0;float db=0,pan=0;std::string identity;
        check(bool(row>>slot>>db>>pan>>mute>>binding>>mask>>std::quoted(identity)),
              "host emitted a complete fixed Sound assignment");
        check(slot==kSoundSlot&&binding==2&&identity.size()==64U,
              "host emitted the authentic stable Sound fingerprint");
        return identity;
    }
    check(false,"host session contains the assigned accompaniment track");return {};
}
std::string revisionName(const std::string& pointer) {
    std::istringstream input(pointer);std::string magic,name,path,identity,revision;
    int version=0,bank=0,position=0;
    check(bool(input>>magic>>version>>bank>>position>>std::quoted(name)>>std::quoted(path)>>
               std::quoted(identity)>>std::quoted(revision))&&magic=="SILVETON_STYLE_POINTER"&&version==1,
          "real saved Style pointer has a valid revision reference");
    return revision;
}
std::filesystem::path pointerPath(const std::filesystem::path& directory,int position=1) {
    return directory/(position==1?"ARRANGER_USER_STYLE_01_001.ref":"ARRANGER_USER_STYLE_01_002.ref");
}
void createLegacyStyle(const std::filesystem::path& current,const std::filesystem::path& legacy) {
    std::filesystem::create_directories(legacy);
    auto pointer=readBytes(pointerPath(current));
    const auto previous=revisionName(pointer);
    const auto bytes=withHeader(readBytes(current/previous),"SILVETON_STYLE_EDITS 14","SILVETON_STYLE_EDITS 13");
    const auto revision="ARRANGER_STYLE_REV_"+digest(bytes)+".svstyle";
    const auto offset=pointer.find(previous);
    check(offset!=std::string::npos,"saved Style revision occurs in its pointer");
    pointer.replace(offset,previous.size(),revision);
    writeBytes(legacy/revision,bytes);writeBytes(pointerPath(legacy),pointer);
}
void installBankSound(host::NativeSamplerEngine& native,const sampler::ProgramPtr& program) {
    check(native.nativeAssignPreparedKeyboardSound(0,program),"public sampler API accepts the prepared source Sound");
    check(native.nativeWriteProgram(0,0,kSoundSlot,0,program->name),"public sampler API writes the actual resolver bank slot");
    check(native.nativeProgramSlotOccupied(0,0,kSoundSlot),"resolver Sound slot exists");
}
void verifyCurrentSound(host::ArrangerHost& arranger,const sampler::ProgramPtr& expected) {
    std::uint64_t serial=0;const auto combi=arranger.styleTrackCombi(0,serial);
    check(combi&&serial!=0U,"actual Style Combi is committed");
    const auto& part=combi->part(kTrack);
    check(part.enabled&&part.soundSlotId==kSoundSlot&&part.program&&part.program->layers.size()==2U,
          "old saved assignment binds the current bank Sound");
    for(std::size_t i=0;i<2U;++i){
        const auto& layer=part.program->layers[i];const auto& current=expected->layers[i];
        check(layer.sourceOscillatorDsp&&layer.sourceOscillatorDsp->velocityZonePresent&&
              layer.sourceOscillatorDsp->velocityZoneRaw==current.sourceOscillatorDsp->velocityZoneRaw&&
              layer.levelDb==current.levelDb&&layer.multisample==current.multisample,
              "compatibility comparison does not publish the old projected playback Program");
    }
}
void verifySilent(host::ArrangerHost& arranger) {
    std::uint64_t serial=0;const auto combi=arranger.styleTrackCombi(0,serial);
    check(combi&&serial!=0U&&!combi->part(kTrack).enabled&&!combi->part(kTrack).program,
          "same slot and Sound name never alias a mismatched saved identity");
}
void rejectStyle(const std::filesystem::path& directory) {
    host::ArrangerHost arranger;arranger.prepare(48000,64);
    arranger.configureStyleEditStorage(directory.string());
    check(arranger.loadSavedStyleEdits(0,1,1),"valid Style with an unavailable exact Sound still loads");
    pump(arranger);verifySilent(arranger);arranger.stopStreaming();
}
void rejectSession(const std::string& session) {
    host::ArrangerHost arranger;arranger.prepare(48000,64);
    check(arranger.restorePersistentSession(session),"valid session with an unavailable exact Sound still restores");
    pump(arranger);check(arranger.persistentSessionRestoreCommitted(),"rejected Sound session commits its silent route");
    verifySilent(arranger);arranger.stopStreaming();
}
}

int main() {
    using namespace silveton::test::pa_series;
    File file("USER01.STY");file.write(styleBank());
    const auto parent=std::filesystem::path(file.path).parent_path();
    const auto currentDirectory=parent/"current-edits",legacyDirectory=parent/"legacy-edits";
    const auto oldSound=sound(false),currentSound=sound(true);
    std::string oldSession,currentFormatOldSession,currentIdentity;

    // NativeSamplerEngine owns the real global Sound resolver. Construct once,
    // before any local ArrangerHost, so later cases do not reset its bank.
    host::NativeSamplerEngine native;
    {
        host::ArrangerHost arranger;arranger.prepare(48000,64);
        arranger.configureStyleEditStorage(currentDirectory.string());
        check(arranger.loadStyle(0,file.path+"!/17"),"authored native Style loads");pump(arranger);
        check(arranger.assignSound(0,kTrack,kSoundSlot,oldSound),"public host assigns exact schema1 Sound");pump(arranger);
        currentFormatOldSession=arranger.persistentSession();
        const auto oldIdentity=trackIdentity(currentFormatOldSession);
        oldSession=withHeader(currentFormatOldSession,"SILVETON_ARRANGER 23","SILVETON_ARRANGER 20");
        const auto velocityStart=oldSession.find("VELOCITY ");check(velocityStart!=std::string::npos,"current session has velocity control");oldSession.erase(velocityStart,oldSession.find('\n',velocityStart)-velocityStart+1);
        const auto globalStart=oldSession.find("GLOBAL ");const auto globalEnd=oldSession.find('\n',globalStart);
        const auto field=oldSession.rfind(' ',globalEnd);oldSession.erase(field,globalEnd-field);
        check(arranger.saveStyleEdits(0,1,1,"Migration fixture"),"host saves authentic schema1 Sound fingerprint");
        createLegacyStyle(currentDirectory,legacyDirectory);
        check(arranger.assignSound(0,kTrack,kSoundSlot,currentSound),"public host assigns schema2 Sound");pump(arranger);
        currentIdentity=trackIdentity(arranger.persistentSession());
        check(currentIdentity!=oldIdentity,"retained velocity zones and corrected headroom change the actual fingerprint");
        arranger.stopStreaming();
    }
    installBankSound(native,currentSound);
    {
        host::ArrangerHost arranger;arranger.prepare(48000,64);
        arranger.configureStyleEditStorage(legacyDirectory.string());
        check(arranger.loadSavedStyleEdits(0,1,1),"style13 permits exact SVOD schema1 identity migration");pump(arranger);
        verifyCurrentSound(arranger,currentSound);
        check(trackIdentity(arranger.persistentSession())==currentIdentity,"migrated Style captures current Sound fingerprint");
        check(arranger.saveStyleEdits(0,1,2,"Migrated Sound"),"migrated Style can be saved in current format");
        const auto revision=revisionName(readBytes(pointerPath(legacyDirectory,2)));
        check(readBytes(legacyDirectory/revision).find("SILVETON_STYLE_EDITS 14\n")==0,
              "resaved migrated Style upgrades to style14");
        arranger.stopStreaming();
    }
    {
        host::ArrangerHost arranger;arranger.prepare(48000,64);
        arranger.configureStyleEditStorage(legacyDirectory.string());
        check(arranger.loadSavedStyleEdits(0,1,2),"resaved current-format Style uses the upgraded exact identity");
        pump(arranger);verifyCurrentSound(arranger,currentSound);arranger.stopStreaming();
    }
    std::string migratedSession;
    {
        host::ArrangerHost arranger;arranger.prepare(48000,64);
        check(arranger.restorePersistentSession(oldSession),"session20 permits exact SVOD schema1 identity migration");
        pump(arranger);check(arranger.persistentSessionRestoreCommitted(),"migrated session commits");
        verifyCurrentSound(arranger,currentSound);migratedSession=arranger.persistentSession();
        check(migratedSession.find("SILVETON_ARRANGER 23\n")==0&&trackIdentity(migratedSession)==currentIdentity,
              "migrated session upgrades both version and exact Sound fingerprint");
        arranger.stopStreaming();
    }
    {
        host::ArrangerHost arranger;arranger.prepare(48000,64);
        check(arranger.restorePersistentSession(migratedSession),"resaved session21 restores without a legacy comparison");
        pump(arranger);verifyCurrentSound(arranger,currentSound);arranger.stopStreaming();
    }
    // Identical bodies with current headers must not invoke old projection.
    rejectStyle(currentDirectory);rejectSession(currentFormatOldSession);
    // Same slot, name, lengths and oscillator metadata: changed source PCM UID
    // or manual gain must still fail the old-format compatibility comparison.
    installBankSound(native,sound(true,"Different authored PCM UID"));
    rejectStyle(legacyDirectory);rejectSession(oldSession);
    installBankSound(native,sound(true,kSourceUid,0.25F));
    rejectStyle(legacyDirectory);rejectSession(oldSession);
    std::filesystem::remove_all(currentDirectory);std::filesystem::remove_all(legacyDirectory);
    std::cout<<"Host Style/session SVOD identity migration and non-alias tests passed\n";
}
