#include "silveton/host/ArrangerHost.h"
#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/host/detail/Pa5xStyleReadCache.h"
#include "silveton/host/detail/ImportedLegatoPortamento.h"
#include "../../core/tests/fixtures/PaSeriesBankFixtures.h"

#include <array>
#include <cmath>
#include <filesystem>

using namespace silveton;
using namespace silveton::test::pa_series;
namespace {
void pump(host::ArrangerHost& host) {
    std::array<float,128> audio{};host.renderAdd(audio.data(),64,48000);
}
void verifyStyle(host::ArrangerHost& host,float cents,int transpose,int bend) {
    std::uint64_t serial=0;const auto combi=host.styleTrackCombi(0,serial);
    check(combi&&serial!=0,"host exposes the selected native Style mixer");
    const auto& part=combi->part(3);
    check(part.tuneCents==cents&&part.transposeSemitones==transpose&&part.pitchBendRange==bend,
          "native source tuning or saved manual override reaches the actual Style Combi");
}
void styleRecallAndManualSave() {
    File file("USER01.STY");file.write(styleBank());
    const auto directory=std::filesystem::path(file.path).parent_path()/"edits";
    const auto location=file.path+"!/17";
    host::ArrangerHost first;first.prepare(48000,64);first.configureStyleEditStorage(directory.string());
    check(first.loadStyle(0,location),"host loads original Style bank metadata without substituted PCM");pump(first);
    verifyStyle(first,-5.0F,-12,12);
    const auto session=first.persistentSession();
    check(!session.empty(),"host captures native source selection and mixer");
    host::ArrangerHost restored;restored.prepare(48000,64);restored.configureStyleEditStorage(directory.string());
    check(restored.restorePersistentSession(session),"native Style session restores");pump(restored);
    verifyStyle(restored,-5.0F,-12,12);

    std::uint64_t serial=0;auto current=first.styleTrackCombi(0,serial);
    check(first.editStyleCombi(0,serial,[](sampler::Combi& combi){
        auto& part=combi.part(3);part.tuneCents=17.0F;part.transposeSemitones=24;part.pitchBendRange=3;
    },current.get()),"user can edit the selected Style mixer");pump(first);
    int gtrElement=-1;
    for(int element=0;element<int(arranger::kElementCount);++element){
        const auto g=first.styleGuitar(0,serial,element,3);
        if(g.available){gtrElement=element;break;}
    }
    check(gtrElement>=0,"fixture contains a playable ACC pattern");
    check(first.editGuitar(0,serial,gtrElement,3,host::GuitarField::Mode,1),"ACC can be explicitly configured for Guitar Mode");
    check(first.editGuitar(0,serial,gtrElement,3,host::GuitarField::RxIntensity,37),"RX dynamics override is accepted");
    check(first.styleGuitar(0,serial,gtrElement,3).settings.rxIntensity==37,"RX override reaches the effective settings");
    check(first.saveStyleEdits(0,1,1,"Authored tuning"),"manual Style tuning saves into a User slot");
    host::ArrangerHost saved;saved.prepare(48000,64);saved.configureStyleEditStorage(directory.string());
    check(saved.loadSavedStyleEdits(0,1,1),"saved Style revision reloads");pump(saved);
    verifyStyle(saved,17.0F,24,3);
    std::uint64_t recalledSerial=0;saved.styleTrackCombi(0,recalledSerial);
    const auto guitar=saved.styleGuitar(0,recalledSerial,gtrElement,3);
    check(guitar.guitar&&guitar.settings.rxIntensity==37&&guitar.overrides.rxIntensity==37,
          "saved Style reload restores independent RX dynamics override");
    check(saved.editGuitar(0,recalledSerial,gtrElement,3,host::GuitarField::ResetSource,0),"Reset Source succeeds");
    const auto reset=saved.styleGuitar(0,recalledSerial,gtrElement,3);
    check(reset.overrides.rxIntensity==-1&&reset.settings.rxIntensity==127,"Reset Source restores inherited RX dynamics");
    first.stopStreaming();restored.stopStreaming();saved.stopStreaming();
    std::filesystem::remove_all(directory);
}

void keyboardNativeUnits() {
    File file;const auto bytes=bank(keyboard(0x09010108U));file.write(bytes);
    arranger::Pa5xKstIndex index;index.recognized=true;
    index.rootPath=std::filesystem::path(file.path).parent_path().string();
    index.resources.push_back({arranger::KstResourceKind::KeyboardSet,"USER02.PRF",bytes.size(),true,false});
    auto source=std::make_shared<arranger::Pa5xSetBank>();
    check(source->loadSoundDirectory(index),"metadata-only source bank has a completed empty Sound directory");
    host::ArrangerHost host;host.prepare(48000,64);
    check(host.installKorgSampleBank(source,{}, {},true),"source bank identity is installed without invented Sounds");
    host::ArrangerKeyboardSet result;
    check(host.prepareKeyboardSet(file.path+"!/17",result,0,true,true),"native keyboard metadata can be prepared silently for exact source recall");
    check(result.playableParts==0&&result.splitPoint==60,"missing PCM stays silent and saved C4 boundary survives");
    const int roles[]{6,0,1,2},cents[]{-64,0,63,-5},transpose[]{-36,0,36,-12};
    for(int i=0;i<4;++i){
        const auto& part=result.combi.part(roles[i]);
        check(part.tuneCents==static_cast<float>(cents[i])&&part.transposeSemitones==transpose[i]&&part.octave==0,
              "per-part native octave is applied once and native cents remain exact");
        check(part.pitchBendRange==(i==0?0:12)&&part.sourceFineTuneRaw==-1,
              "native zero bend is restored and native cents do not masquerade as RPN fine tuning");
        const float send=i==0?0.0F:static_cast<float>(127-i)/127.0F;
        check(std::fabs(part.fxSend1-send)<0.000001F,"original native master send reaches the keyboard Combi");
    }
    check(result.combi.part(6).keyHigh==60&&result.combi.part(0).keyLow==61,
          "native controls do not move the inclusive Lower C4 split");
    host.stopStreaming();
}

void keyboardThreeUpperOscillators(){
    using namespace sampler;
    auto sample=std::make_shared<SampleData>();sample->name="OSC fixture";sample->channels=1;
    sample->sampleRate=48000;sample->rootKey=60;sample->interleaved.resize(256U,.005F);
    sample->loop.enabled=true;sample->loop.endFrame=256;
    auto multi=std::make_shared<Multisample>();SampleZone zone;zone.sample=sample;zone.rootKey=60;multi->zones.push_back(zone);
    auto program=std::make_shared<Program>();program->name="24 OSC with two velocity branches";
    program->sourceVoiceAssignment={true,8U,0U};
    for(int osc=0;osc<24;++osc)for(int hi=0;hi<2;++hi){
        ProgramLayer layer;layer.multisample=multi;layer.name="OSC "+std::to_string(osc+1)+(hi?" High":" Low");
        layer.velocityLow=hi?64:1;layer.velocityHigh=hi?127:63;
        layer.ampEnvelope={.001F,0,1,.015F};layer.filter.mode=FilterMode::Bypass;
        layer.sourcePortamento.present=true;layer.sourcePortamento.resourceVersion=8;
        layer.sourcePortamento.flagsRaw=9;layer.sourcePortamento.timeRaw=50+osc;
        layer.sourcePortamento.extensionByteCount=2;
        program->layers.push_back(layer);
    }
    check(program->layers.size()==48&&arranger::paSampleProgramLayerCountSupported(*program),"valid Pa 48 velocity branches pass admission");
    auto tooLarge=*program;tooLarge.layers.push_back(program->layers.front());
    check(!arranger::paSampleProgramLayerCountSupported(tooLarge),"49 branches are rejected");
    auto nonPa=*program;nonPa.sourceVoiceAssignment={};
    check(!arranger::paSampleProgramLayerCountSupported(nonPa),"native limit is unchanged");
    host::NativeSamplerEngine native;
    auto output=std::make_unique<host::OfflineAudioOutput>(48000,128);auto* out=output.get();
    native.setBackends(std::move(output),std::make_unique<host::ManualMidiInput>());
    check(native.nativeAudioOpen()&&native.nativeAudioStart(),"offline audio starts");
    Combi combi;
    for(int i=0;i<3;++i){auto& part=combi.part(i);part.enabled=true;part.program=program;part.name=program->name;
        part.midiChannel=0;part.commonProcessing=true;part.sourceSoundEdits.setController(5,20+i*40);
        part.sourceSoundEdits.setController(65,i==1?0:127);part.sourceSoundEdits.setController(73,40+i*24);
    }
    check(native.nativeApplyKeyboardCombi(combi),"Keyboard Set accepts all 48 branches in each of three Upper parts");
    const auto loaded=native.nativeKeyboardCombi();
    for(int i=0;i<3;++i){const auto& part=loaded->part(i);
        check(part.program==program&&part.program->layers.size()==48,"each Upper retains exact shared program graph");
        check(part.sourceSoundEdits.controller(5)==20+i*40&&part.sourceSoundEdits.controller(65)==(i==1?0:127)&&
            part.sourceSoundEdits.controller(73)==40+i*24,"independent original part controllers survive recall");
    }
    for(int v:{63,64}){
        native.nativeMidi(0x90,60,v);out->pump(2048);
        check(native.nativeMeters().at(3)==72,"3 x 24 active OSC, not 3 x 48 velocity branches");
        native.nativeMidi(0x80,60,0);out->pump(12000);
        check(native.nativeMeters().at(3)==0,"all 72 oscillator voices release");
    }
    native.nativeAudioStop();native.nativeAudioClose();
}

void importedLegatoPortamentoRecall(){
    using namespace sampler;
    auto sound=std::make_shared<Program>();sound->name="Imported legato fixture";
    sound->sourceVoiceAssignment={true,8U,12U,true,1U,0U};
    sound->mono=true;sound->legato=true;
    auto sample=std::make_shared<SampleData>();sample->name="PCM";sample->channels=1;
    sample->sampleRate=48000;sample->rootKey=60;sample->interleaved.resize(256U,.005F);
    auto multi=std::make_shared<Multisample>();SampleZone zone;zone.sample=sample;zone.rootKey=60;multi->zones.push_back(zone);
    ProgramLayer layer;layer.multisample=multi;layer.sourcePortamento={true,false,8U,9U,91U,2U,{}};
    sound->layers.push_back(layer);
    UpperPart part;part.program=sound;part.sourceSoundEdits.setController(5,80);
    part.sourceSoundEdits.setController(73,55);
    check(!host::detail::applyImportedLegatoPortamentoDefault(part),"explicit Keyboard Set time has priority over default 30");
    check(part.sourceSoundEdits.controller(5)==80&&part.sourceSoundEdits.controller(73)==55&&
        sound->layers[0].sourcePortamento.timeRaw==91,"original OSC and saved part edits stay intact");
    check(sourcePortamentoPlaybackSeconds(sound->layers[0].sourcePortamento,part.sourceSoundEdits,true)==SourcePortamento::indexSeconds(80),"actual playback time law uses saved 80");
    part.sourceSoundEdits.setController(5,0);
    check(!host::detail::applyImportedLegatoPortamentoDefault(part)&&part.sourceSoundEdits.controller(5)==0,"explicit zero has priority");
    part.sourceSoundEdits.setController(5,-1);
    check(host::detail::applyImportedLegatoPortamentoDefault(part)&&part.sourceSoundEdits.controller(5)==30,"30 only when stored time is absent");
    part.sourceSoundEdits.setController(65,0);part.sourceSoundEdits.setController(5,80);
    check(!host::detail::applyImportedLegatoPortamentoDefault(part)&&part.sourceSoundEdits.controller(5)==80,"explicit OFF stays off");
    auto poly=std::make_shared<Program>(*sound);poly->mono=false;poly->legato=false;poly->sourceVoiceAssignment={true,8U,0U,true,0U,0U};
    auto off=std::make_shared<Program>(*sound);off->layers[0].sourcePortamento.flagsRaw=8;
    auto fingered=std::make_shared<Program>(*sound);fingered->layers[0].sourcePortamento.flagsRaw=11;
    auto disabled=std::make_shared<Program>(*sound);disabled->layers[0].enabled=false;
    for(const auto& other:{poly,off,disabled}){
        UpperPart p;p.program=other;p.sourceSoundEdits.setController(5,81);
        check(!host::detail::applyImportedLegatoPortamentoDefault(p)&&p.sourceSoundEdits.controller(5)==81,"non-qualifying part not overridden");
    }
    UpperPart f;f.program=fingered;
    check(host::detail::applyImportedLegatoPortamentoDefault(f)&&f.sourceSoundEdits.controller(5)==30&&
        sourcePortamentoPlaybackSeconds(fingered->layers[0].sourcePortamento,f.sourceSoundEdits,false)==0.0F,
        "fingered glide still requires a held key");
    host::NativeSamplerEngine native;
    check(native.nativeAssignPreparedKeyboardSound(0,sound),"original SOUND assigned through real host entry point");
    auto live=native.nativeKeyboardCombi();
    check(live&&live->part(0).sourceSoundEdits.controller(5)==30,"selected SOUND immediately shows effective 30");
    Combi edited=*live;edited.part(0).sourceSoundEdits.setController(5,44);
    check(native.nativeApplyKeyboardCombi(edited),"manual edit can be applied");
    check(native.nativeKeyboardCombi()->part(0).sourceSoundEdits.controller(5)==44,"manual time does not reset on ordinary recall");
    auto legacy=*native.nativeKeyboardCombi();
    legacy.part(0).sourcePortamentoInherit=false;legacy.part(0).portaMode=PortamentoMode::Kronos;legacy.part(0).portaTime=47;
    check(native.nativeApplyKeyboardCombi(legacy),"legacy manual portamento can migrate");
    live=native.nativeKeyboardCombi();
    check(live->part(0).sourcePortamentoInherit&&live->part(0).portamentoSec==0&&live->part(0).sourceSoundEdits.controller(5)==47&&live->part(0).sourceSoundEdits.controller(65)==127,"one working CC5/65 route replaces manual glide engine");
    auto restored=*live;host::detail::resetImportedKeyboardPortamento(restored.part(0));
    check(native.nativeApplyKeyboardCombi(restored),"restore original oscillator values");
    live=native.nativeKeyboardCombi();
    check(live->part(0).sourceSoundEdits.controller(5)==-1&&live->part(0).sourceSoundEdits.controller(65)==-1&&sound->layers[0].sourcePortamento.timeRaw==91,"reset does not rewrite original SOUND");
    check(native.nativeAssignPreparedKeyboardSound(0,poly),"select poly original SOUND after legato");
    live=native.nativeKeyboardCombi();
    check(live->part(0).sourceSoundEdits.controller(5)==-1&&live->part(0).voiceMode==UpperVoiceMode::Poly,
        "previous time does not leak into next SOUND");
}

void retainedPayloadBudget() {
    File file("USER01.STY");file.write(styleBank());
    auto read=std::make_shared<arranger::Pa5xStyleRead>(arranger::readPaStyleSlot(file.path+"!/17",nullptr));
    host::detail::Pa5xStyleReadCache cache;auto key=host::detail::Pa5xStyleReadCache::keyFor(file.path+"!/17",{});
    check(cache.insert(key,read),"native Style fits the bounded read cache");const auto complete=cache.estimatedMemoryBytes();
    auto stripped=std::make_shared<arranger::Pa5xStyleRead>(*read);stripped->sourceEffects.reset();
    for(auto& section:stripped->sections)for(auto& track:section.tracks)track.sourceNativeTrack.reset();
    cache.clear();check(cache.insert(key,stripped),"equivalent metadata without retained payloads fits");
    check(complete>cache.estimatedMemoryBytes()+2U*382U+73U,"cache charges retained native records and Style FX bytes");
}
}
int main(){styleRecallAndManualSave();keyboardNativeUnits();keyboardThreeUpperOscillators();importedLegatoPortamentoRecall();retainedPayloadBudget();
    std::cout<<"Native Pa source host recall, persistence and cache tests passed\n";}
