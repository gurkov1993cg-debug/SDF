#include "silveton/host/ArrangerHost.h"
#include "silveton/host/detail/Pa5xStyleReadCache.h"
#include "../../core/tests/fixtures/PaSeriesBankFixtures.h"

#include <array>
#include <cmath>
#include <filesystem>

using namespace silveton;
using namespace silveton::test::pa_series;
namespace {
void pump(host::ArrangerHost& host) {
    std::array<float,128> audio{};host.renderAdd(audio.data(),64,48000);
}
void verifyStyle(host::ArrangerHost& host,float cents,int transpose,int bend) {
    std::uint64_t serial=0;const auto combi=host.styleTrackCombi(0,serial);
    check(combi&&serial!=0,"host exposes the selected native Style mixer");
    const auto& part=combi->part(3);
    check(part.tuneCents==cents&&part.transposeSemitones==transpose&&part.pitchBendRange==bend,
          "native source tuning or saved manual override reaches the actual Style Combi");
}
void styleRecallAndManualSave() {
    File file("USER01.STY");file.write(styleBank());
    const auto directory=std::filesystem::path(file.path).parent_path()/"edits";
    const auto location=file.path+"!/17";
    host::ArrangerHost first;first.prepare(48000,64);first.configureStyleEditStorage(directory.string());
    check(first.loadStyle(0,location),"host loads original Style bank metadata without substituted PCM");pump(first);
    verifyStyle(first,-5.0F,-12,12);
    const auto session=first.persistentSession();
    check(!session.empty(),"host captures native source selection and mixer");
    host::ArrangerHost restored;restored.prepare(48000,64);restored.configureStyleEditStorage(directory.string());
    check(restored.restorePersistentSession(session),"native Style session restores");pump(restored);
    verifyStyle(restored,-5.0F,-12,12);

    std::uint64_t serial=0;auto current=first.styleTrackCombi(0,serial);
    check(first.editStyleCombi(0,serial,[](sampler::Combi& combi){
        auto& part=combi.part(3);part.tuneCents=17.0F;part.transposeSemitones=24;part.pitchBendRange=3;
    },current.get()),"user can edit the selected Style mixer");pump(first);
    int gtrElement=-1;
    for(int element=0;element<int(arranger::kElementCount);++element){
        const auto g=first.styleGuitar(0,serial,element,3);
        if(g.available){gtrElement=element;break;}
    }
    check(gtrElement>=0,"fixture contains a playable ACC pattern");
    check(first.editGuitar(0,serial,gtrElement,3,host::GuitarField::Mode,1),"ACC can be explicitly configured for Guitar Mode");
    check(first.editGuitar(0,serial,gtrElement,3,host::GuitarField::RxIntensity,37),"RX dynamics override is accepted");
    check(first.styleGuitar(0,serial,gtrElement,3).settings.rxIntensity==37,"RX override reaches the effective settings");
    check(first.saveStyleEdits(0,1,1,"Authored tuning"),"manual Style tuning saves into a User slot");
    host::ArrangerHost saved;saved.prepare(48000,64);saved.configureStyleEditStorage(directory.string());
    check(saved.loadSavedStyleEdits(0,1,1),"saved Style revision reloads");pump(saved);
    verifyStyle(saved,17.0F,24,3);
    std::uint64_t recalledSerial=0;saved.styleTrackCombi(0,recalledSerial);
    const auto guitar=saved.styleGuitar(0,recalledSerial,gtrElement,3);
    check(guitar.guitar&&guitar.settings.rxIntensity==37&&guitar.overrides.rxIntensity==37,
          "saved Style reload restores independent RX dynamics override");
    check(saved.editGuitar(0,recalledSerial,gtrElement,3,host::GuitarField::ResetSource,0),"Reset Source succeeds");
    const auto reset=saved.styleGuitar(0,recalledSerial,gtrElement,3);
    check(reset.overrides.rxIntensity==-1&&reset.settings.rxIntensity==127,"Reset Source restores inherited RX dynamics");
    first.stopStreaming();restored.stopStreaming();saved.stopStreaming();
    std::filesystem::remove_all(directory);
}

void keyboardNativeUnits() {
    File file;const auto bytes=bank(keyboard(0x09010108U));file.write(bytes);
    arranger::Pa5xKstIndex index;index.recognized=true;
    index.rootPath=std::filesystem::path(file.path).parent_path().string();
    index.resources.push_back({arranger::KstResourceKind::KeyboardSet,"USER02.PRF",bytes.size(),true,false});
    auto source=std::make_shared<arranger::Pa5xSetBank>();
    check(source->loadSoundDirectory(index),"metadata-only source bank has a completed empty Sound directory");
    host::ArrangerHost host;host.prepare(48000,64);
    check(host.installKorgSampleBank(source,{}, {},true),"source bank identity is installed without invented Sounds");
    host::ArrangerKeyboardSet result;
    check(host.prepareKeyboardSet(file.path+"!/17",result,0,true,true),"native keyboard metadata can be prepared silently for exact source recall");
    check(result.playableParts==0&&result.splitPoint==60,"missing PCM stays silent and saved C4 boundary survives");
    const int roles[]{6,0,1,2},cents[]{-64,0,63,-5},transpose[]{-36,0,36,-12};
    for(int i=0;i<4;++i){
        const auto& part=result.combi.part(roles[i]);
        check(part.tuneCents==static_cast<float>(cents[i])&&part.transposeSemitones==transpose[i]&&part.octave==0,
              "per-part native octave is applied once and native cents remain exact");
        check(part.pitchBendRange==(i==0?0:12)&&part.sourceFineTuneRaw==-1,
              "native zero bend is restored and native cents do not masquerade as RPN fine tuning");
        const float send=i==0?0.0F:static_cast<float>(127-i)/127.0F;
        check(std::fabs(part.fxSend1-send)<0.000001F,"original native master send reaches the keyboard Combi");
    }
    check(result.combi.part(6).keyHigh==60&&result.combi.part(0).keyLow==61,
          "native controls do not move the inclusive Lower C4 split");
    host.stopStreaming();
}

void retainedPayloadBudget() {
    File file("USER01.STY");file.write(styleBank());
    auto read=std::make_shared<arranger::Pa5xStyleRead>(arranger::readPaStyleSlot(file.path+"!/17",nullptr));
    host::detail::Pa5xStyleReadCache cache;auto key=host::detail::Pa5xStyleReadCache::keyFor(file.path+"!/17",{});
    check(cache.insert(key,read),"native Style fits the bounded read cache");const auto complete=cache.estimatedMemoryBytes();
    auto stripped=std::make_shared<arranger::Pa5xStyleRead>(*read);stripped->sourceEffects.reset();
    for(auto& section:stripped->sections)for(auto& track:section.tracks)track.sourceNativeTrack.reset();
    cache.clear();check(cache.insert(key,stripped),"equivalent metadata without retained payloads fits");
    check(complete>cache.estimatedMemoryBytes()+2U*382U+73U,"cache charges retained native records and Style FX bytes");
}
}
int main(){styleRecallAndManualSave();keyboardNativeUnits();retainedPayloadBudget();
    std::cout<<"Native Pa source host recall, persistence and cache tests passed\n";}
