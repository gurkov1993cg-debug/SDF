#include "silveton/host/ArrangerHost.h"
#include <array>
#include <cassert>
#include <iostream>
using silveton::host::ArrangerHost;
using silveton::sampler::GlobalState;
static void drain(ArrangerHost& h){std::array<float,128> a{};h.renderAdd(a.data(),64,48000);}
static void chord(ArrangerHost& h,bool down){for(int key:{48,52,55})assert(h.observeMidi(down?0x90:0x80,static_cast<std::uint8_t>(key),down?100:0));drain(h);}
static void cc(ArrangerHost& h,int number,int value,int channel=0){assert(h.observeMidi(static_cast<std::uint8_t>(0xB0|channel),static_cast<std::uint8_t>(number),static_cast<std::uint8_t>(value)));drain(h);}
static bool c(ArrangerHost& h){return h.snapshot(0).chordName=="C";}
static void reset(ArrangerHost& h,GlobalState& g){h.panic();g={};h.syncGlobal(g);assert(h.setMemory(false)&&h.setChordRecognitionMode(3)&&h.setChordScanArea(1)&&h.setSplitEnabled(true)&&h.setDamperLatch(true));drain(h);}
int main(){ArrangerHost h;h.prepare(48000,64);h.stopStreaming();GlobalState g;
 reset(h,g);chord(h,true);assert(c(h));cc(h,2,127);chord(h,false);assert(!c(h)); // breath is not a pedal
 reset(h,g);g.damperCc=66;h.syncGlobal(g);drain(h);chord(h,true);cc(h,64,127);chord(h,false);assert(!c(h)); // unassigned CC64
 chord(h,true);cc(h,66,127);chord(h,false);assert(c(h));cc(h,66,0);assert(!c(h)); // assigned pedal
 reset(h,g);g.damperCc=66;g.filterControlChange=true;h.syncGlobal(g);drain(h);chord(h,true);cc(h,66,127);chord(h,false);assert(!c(h)); // filtered new press
 reset(h,g);g.damperCc=66;g.midiInputChannelMask=1;h.syncGlobal(g);drain(h);chord(h,true);cc(h,66,127,1);chord(h,false);assert(!c(h)); // excluded pedal channel
 reset(h,g);g.damperCc=66;h.syncGlobal(g);drain(h);chord(h,true);cc(h,66,127);g.filterControlChange=true;g.midiInputChannelMask=0;h.syncGlobal(g);drain(h);chord(h,false);assert(c(h));cc(h,66,0);assert(!c(h)); // release survives both filter changes
 reset(h,g);g.damperCc=66;g.damperPolarityReversed=true;h.syncGlobal(g);drain(h);chord(h,true);cc(h,66,0);chord(h,false);assert(c(h));g.filterControlChange=true;g.midiInputChannelMask=0;h.syncGlobal(g);drain(h);cc(h,66,127);assert(!c(h)); // reversed polarity normalized
 reset(h,g);chord(h,true);cc(h,64,127);chord(h,false);assert(c(h));g.damperCc=2;h.syncGlobal(g);drain(h);assert(!c(h));chord(h,true);cc(h,2,127);chord(h,false);assert(c(h));cc(h,2,0);assert(!c(h)); // reassignment releases old latch; explicit CC2 works
 reset(h,g);chord(h,true);cc(h,64,127);chord(h,false);assert(c(h));g.damperPolarityReversed=true;h.syncGlobal(g);drain(h);assert(!c(h)); // polarity change releases old latch
 reset(h,g);g.damperCc=66;h.syncGlobal(g);drain(h);chord(h,true);cc(h,66,127);chord(h,false);assert(c(h));g.filterControlChange=true;g.midiInputChannelMask=0;h.syncGlobal(g);drain(h);cc(h,121,0);assert(!c(h)); // reset controllers remains a release
 std::cout<<"PASS configured damper CC/polarity, channel+CC filters, release admission, remap reset and breath isolation\n";
}
