// SILVETON SAMPLER for the Samsung Galaxy Tab A11 (SM-X130): a NativeActivity made only of C++ (no Kotlin, no Java).
// The C++ is the repository's top CMakeLists.txt (ANDROID branch): the sound core, the tablet's own sound / MIDI engine,
// the screens and the NativeActivity shell. The fonts of the screens travel as assets (resources/fonts).
plugins {
    id("com.android.application")
}

// The optional release key is supplied by the build environment, never the ZIP.
// Any partial configuration fails instead of silently signing with another key.
val releaseKeyPath = System.getenv("SILVETON_ANDROID_KEYSTORE_PATH").orEmpty()
val releaseStorePassword = System.getenv("SILVETON_ANDROID_KEYSTORE_PASSWORD").orEmpty()
val releaseKeyAlias = System.getenv("SILVETON_ANDROID_KEY_ALIAS").orEmpty()
val releaseKeyPassword = System.getenv("SILVETON_ANDROID_KEY_PASSWORD").orEmpty()
val releaseSigningValues = listOf(releaseKeyPath, releaseStorePassword, releaseKeyAlias, releaseKeyPassword)
val useReleaseKey = releaseSigningValues.any { it.isNotEmpty() }
if (useReleaseKey && releaseSigningValues.any { it.isEmpty() }) {
    throw GradleException("Incomplete SILVETON_ANDROID signing configuration; supply all four signing values.")
}
if (!useReleaseKey && System.getenv("CI") == "true") {
    logger.warn("SILVETON: CI debug test signing; an update over a differently signed installed APK is not guaranteed.")
}

android {
    namespace = "com.silveton.arranger"
    compileSdk = 35
    buildToolsVersion = "35.0.0"

    defaultConfig {
        // Separate installation preserves the original app and its private data.
        applicationId = "com.silveton.arranger.panel"
        minSdk = 26
        targetSdk = 35
        versionCode = 86
        versionName = "0.1.89"

        externalNativeBuild {
            cmake {
                targets += listOf("silveton_sampler")
                cppFlags += listOf("-std=c++17")
                // NDK r27 needs this explicitly for 16 KiB page-size compatible native libs.
                arguments += listOf("-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON", "-DANDROID_STL=c++_static")
            }
        }
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("../../CMakeLists.txt")
            version = "3.22.1"
        }
    }

    ndkVersion = "27.2.12479018"

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
    }

    sourceSets {
        getByName("main") {
            // resources/fonts -> assets/fonts inside the APK
            assets.srcDir("../../resources")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        if (useReleaseKey) {
            create("silvetonRelease") {
                storeFile = file(releaseKeyPath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (useReleaseKey) {
                signingConfig = signingConfigs.getByName("silvetonRelease")
            } else if (System.getenv("CI") == "true") {
                // Explicit CI test fallback. It cannot guarantee an in-place
                // update over an APK signed by a previous runner or private key.
                signingConfig = signingConfigs.getByName("debug")
            }
        }
    }
}
