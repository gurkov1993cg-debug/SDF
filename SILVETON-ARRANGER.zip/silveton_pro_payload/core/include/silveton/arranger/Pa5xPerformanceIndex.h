#pragma once
#include "silveton/arranger/KorgMidiInspection.h"
#include "silveton/arranger/KorgSourceEffects.h"
#include "silveton/arranger/PaSeriesTrackSettings.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

enum class Pa5xPerformanceKind : std::uint8_t { Unknown, KeyboardSet, Pad };

struct Pa5xPerformancePatch {
    std::uint32_t tick{0};
    int channel{-1};
    int msb{-1}, lsb{-1}, program{-1}; // raw MIDI values; -1 means not supplied
    bool addressComplete{false};
};
struct Pa5xPerformanceChannel {
    int channel{-1};
    int volumeRaw{-1}, panRaw{-1}, expressionRaw{-1};
};
struct Pa5xPerformanceCv {
    int number{0};
    std::string root, chord;
};
struct Pa5xPerformanceChordSelection {
    std::string chord;
    int cv{-1};
};

struct Pa5xPerformancePart {
    int track{0}; // KSC: 1=Lower, 2=Upper1, 3=Upper2, 4=Upper3; Pad: 1
    std::string name;
    std::string resourcePath;
    bool present{false};
    int mute{-1}; // explicit XML flag, never inferred from the filename
    int keyLow{-1}, keyHigh{-1}, velocityLow{-1}, velocityHigh{-1};
    int trackRoute{-1}, actuatorRaw{-1}, controllersRaw{-1};
    int transpositionRaw{0};
    bool transpositionDeclared{false};
    std::uint16_t ppq{0};
    std::uint32_t midiSpanTicks{0};
    std::size_t midiEventCount{0};
    bool hasNoteEvents{false};
    std::vector<Pa5xPerformancePatch> patches;
    std::vector<Pa5xPerformanceChannel> channels;
    // Original ordered setup/performance events; recall readers must not use
    // the flattened final controller values as if later events occurred at0.
    std::vector<KorgMidiChannelEvent> channelEvents;
    // Original messages are retained for decoding, never replayed as generic
    // MIDI. Their ordering shares the SMF ordinal used by channelEvents.
    std::vector<KorgMidiOpaqueEvent> opaqueMidiEvents;
    // Pad transposition/CV settings remain raw until their numeric enum
    // meanings and full Korg processing have been verified.
    std::string patternType;
    int ntt{-1}, ntr{-1}, retrigger{-1}, wrapAroundDegree{-1};
    int loopNumberRaw{0}, loopLengthRaw{0};
    bool loopDeclared{false};
    std::vector<Pa5xPerformanceCv> cvSources;
    std::vector<Pa5xPerformanceChordSelection> chordSelections;
    int rawFxGroup{-1},rawDryOff{-1};
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
    std::shared_ptr<const PaSeriesTrackSettings> sourceNativeTrack;
};

struct Pa5xPerformanceComplement {
    bool present{false};
    bool semanticsDecoded{false};
    // Exact RESOURCE@complement identity and complete original SMF. A valid
    // SMF inventory is not a decoded Korg effect/routing configuration.
    std::string resourcePath;
    std::vector<std::uint8_t> midiBytes;
    KorgMidiInspection midi;
};

struct Pa5xPerformanceInspection {
    bool recognized{false};
    bool valid{false}; // structural/index validity, not complete DSP playback
    bool playable{false};
    Pa5xPerformanceKind kind{Pa5xPerformanceKind::Unknown};
    std::string sourcePath;
    std::string displayName;
    int filenameOrdinal{-1}; // optional literal prefix; not an internal Sound ID
    bool stableResourceIdKnown{false};
    std::string stableResourceId;
    int version{-1}, release{-1}, subtype{-1};
    int splitPoint{-1}, useGlobalSplit{-1}, upperOctaveTransposeRaw{0};
    bool upperOctaveDeclared{false};
    int chordScanningRaw{-1}, keyboardModeRaw{-1}, lowerUseRaw{-1};
    // Explicit XML boolean. Absence must not become a new recall default.
    int bassInversionRaw{-1};
    std::vector<Pa5xPerformancePart> parts;
    Pa5xPerformanceComplement complement;
    std::vector<std::string> warnings;
    std::vector<std::string> playbackBlockers;
    std::string error;
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
};

Pa5xPerformanceInspection inspectPa5xPerformanceBytes(const std::vector<std::uint8_t>& bytes,
                                                     const std::string& sourcePath = {});
Pa5xPerformanceInspection inspectPa5xPerformanceFile(const std::string& path);

} // namespace silveton::arranger
