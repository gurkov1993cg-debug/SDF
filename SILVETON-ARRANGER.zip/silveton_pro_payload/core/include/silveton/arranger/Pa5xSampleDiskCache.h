#pragma once

#include "silveton/sampler/SampleStream.h"
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::arranger {

// Full source-content identity, computed once while the bank is already read.
// Reusing an unchanged UID after replacing PCM bytes must invalidate its cache.
std::string pa5xSampleContentHash(const std::uint8_t* data, std::size_t bytes);

// Worker/control thread only, before publishing an actually reversed sample.
// Faults only page entries inside its final16KiB. Ordinary cache opens and
// forward recordings do not visit the tail of every file in the SET.
void warmPa5xReverseSampleEntry(const silveton::sampler::SampleStream& stream) noexcept;

// Caller supplies an immutable resource identity including the source-file
// revision and KMP decoding metadata. No loop, root, gain or direction is baked
// into this raw, already-trimmed mono cache.
struct Pa5xSampleDiskSpec {
    std::string identity;
    std::uint64_t resourceId{0}, frameCount{0};
    std::uint32_t sampleRate{0};
};
struct Pa5xSampleDiskImport {
    std::shared_ptr<const silveton::sampler::SampleStream> stream;
    std::vector<float> attackPrefix;
    std::string path, error;
    bool cacheHit{false};
    explicit operator bool() const noexcept { return stream != nullptr; }
};

// Worker/control thread only. The first frames are copied into bounded resident
// memory while the remaining recording uses the existing SampleStream/prefetch
// path. A cache hit reads only the128-byte header and requested prefix while
// validating version, full identity, UID, rate and length. It does not scan or
// eagerly warm the rest of every recording.
Pa5xSampleDiskImport openPa5xSampleDiskCache(const std::string& directory,
    const Pa5xSampleDiskSpec& spec, std::size_t prefixFrames = 1024U);

// Writes a private temporary file and renames only after all data is complete.
// Mono data is IEEE float32, little-endian, matching MappedPcmStream's raw view.
Pa5xSampleDiskImport storePa5xSampleDiskCache(const std::string& directory,
    const Pa5xSampleDiskSpec& spec, const float* mono, std::size_t frameCount,
    const std::atomic<bool>* cancel = nullptr, std::size_t prefixFrames = 1024U);

} // namespace silveton::arranger
