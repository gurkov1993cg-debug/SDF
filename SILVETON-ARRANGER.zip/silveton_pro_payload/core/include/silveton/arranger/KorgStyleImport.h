#pragma once

#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/arranger/KorgMidiInspection.h"
#include "silveton/arranger/KorgSourceEffects.h"
#include <array>

namespace silveton::arranger {

// This is a structural index, not a declaration of Korg sound/NTT playback
// compatibility. Original resource addresses and per-element metadata survive.
struct KorgStyleCvSource {
    int number{0};
    std::string root;
    std::string chord;
    // Preserve declarations if present; an undocumented length unit is not
    // converted into MIDI ticks. Missing fields remain -1/0.
    int declaredLengthRaw{-1};
    int numerator{0};
    int denominatorExponent{-1};
};
// Source-compatible name retained for existing Style inspection consumers.
using KorgStyleOpaqueMidiEvent = KorgMidiOpaqueEvent;
struct KorgStyleChordSelection {
    std::string chord; // exact CHORD_TABLE symbol, e.g. Dom7, Minmaj7, MajNo3
    int cv{0};
};
struct KorgStyleClip {
    Element element{Element::Count};
    int track{-1}; // Drum, Perc, Bass, Acc1..5 = 0..7
    std::string path;
    std::string patternType;
    int version{-1}, release{-1};
    std::string originalRoot;
    std::string originalChord;
    int ntt{-1}, ntr{-1};
    // These are raw Pa5X XML values. Numeric NTT/NTR/trigger enums are not
    // assumed to match either the generic engine or the manual's list order.
    int retriggerMode{-1};
    bool keyRangeDeclared{false};
    bool keyRangeEnabled{false};
    int keyLow{-1}, keyHigh{-1}, wrapAroundDegree{-1};
    int declaredLoopLength{-1}, declaredLoopNumber{-1};
    int timeStretchingNumerator{-1}, timeStretchingDenominator{-1};
    int startFineSlide{-1};
    int appearingNumerator{0}, appearingDenominator{0};
    // Named Guitar fields belong to this element/track and apply to all its
    // CVs. The original string-selector codes are retained without assuming
    // that their zero-based menu indices equal physical string numbers.
    int guitarCapo{-1}, guitarStringHigh{-1}, guitarStringLow{-1};
    int guitarHumanize{-1}, guitarNoiseOffset{-1}, guitarTension{-1};
    bool guitarParametersValid{true};
    std::vector<KorgStyleCvSource> cvSources;
    std::vector<int> chordVariations;
    std::vector<KorgStyleChordSelection> chordSelections;
    std::vector<TrackInfo> patches;
    // Timed selections remain separate from the deduplicated complete-address
    // catalog above. Undeclared MIDI fields stay -1 instead of becoming GM0.
    std::vector<KorgMidiPatchSelection> patchSelections;
    // Original absolute SMF ticks and order, including setup. Runtime conversion
    // must use a separately proven CV boundary; no first-note trimming.
    std::vector<KorgMidiChannelEvent> channelEvents;
    std::vector<KorgMidiTrackInspection> midiTracks;
    std::vector<KorgMidiTempo> tempos;
    std::vector<KorgMidiTimeSignature> timeSignatures;
    // Retained verbatim for future Korg processing; generic MIDI output must
    // not interpret or silently claim support for these opaque payloads.
    std::vector<KorgStyleOpaqueMidiEvent> opaqueMidiEvents;
    std::uint16_t ppq{0};
    // Raw SMF span, including Korg's setup/pre-roll. This is NOT the CV length.
    std::uint32_t midiSpanTicks{0};
    // Known only for the supported setup-plus-CV-track Pa5X layout: non-note setup track
    // ends at one actual measure; physical MIDI track n contains CVn. Intentional
    // rests after this boundary are retained. performanceTicks is the whole
    // longest CV stream; each CV duration is its own EOT minus setupTicks.
    bool setupTimingKnown{false};
    std::uint32_t setupTicks{0}, performanceTicks{0};
    std::size_t eventCount{0};
    int rawDryOff{-1};
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
};
struct KorgStyleElement {
    Element element{Element::Count};
    int numerator{0}, denominator{0};
    std::vector<KorgStyleClip> clips;
};
struct KorgStyleInspection {
    bool recognized{false};
    bool valid{false};
    std::string name;
    double tempoBpm{0};
    // Explicit Stage TrackNParams mute flags, resolved through the outer
    // StyleClip tN bindings and inner scene RESOURCE track declarations.
    // Drum, Perc, Bass, Acc1..5; -1 means no unambiguous original declaration.
    std::array<int,kTracks> originalMuteRaw{{-1,-1,-1,-1,-1,-1,-1,-1}};
    std::array<int,kTracks> originalFxGroupRaw{{-1,-1,-1,-1,-1,-1,-1,-1}};
    std::string error;
    std::vector<KorgStyleElement> elements;
    std::vector<std::string> warnings;
    std::vector<std::string> playbackBlockers;
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
};

KorgStyleInspection inspectKorgStyleBytes(const std::vector<std::uint8_t>& bytes);
KorgStyleInspection inspectKorgStyleFile(const std::string& path);
std::string korgStyleDiagnostic(const KorgStyleInspection& inspection);

// Publishes a dedicated native per-track/CV graph. Drum notes retain original
// pitches; uncalibrated pitched modes are restricted to their exact recorded
// source chord. Explicit Guitar clips use the dedicated six-string renderer.
// Warnings describe unsupported source controls, Korg pitch, opaque MIDI and
// sound processing; this is not full Pa5X emulation.
ImportResult importKorgStyleBytes(const std::vector<std::uint8_t>& bytes);
ImportResult importKorgStyleFile(const std::string& path);
// Convert an already parsed, bounded STG inspection. Shared readers must not
// inflate and inspect the same ZIP/XML/SMF a second time just to build playback.
ImportResult importKorgStyleInspection(const KorgStyleInspection& inspection);

} // namespace silveton::arranger
