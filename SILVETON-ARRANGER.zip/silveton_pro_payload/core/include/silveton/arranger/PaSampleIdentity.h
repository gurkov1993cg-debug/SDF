#pragma once
#include <cstdint>
#include <limits>
#include <string>

namespace silveton::arranger {
// Stable User PCM identity. Work from the end to allow colons in SET paths.
inline std::uint64_t paSampleUid(const std::string& identity) noexcept {
    if(identity.compare(0,20,"Pa5xUserSampleCache2")!=0||identity.size()<=20||identity[20]!=':')return 0;
    auto end=identity.size();
    for(int i=0;i<10;++i){if(end==0)return 0;end=identity.rfind(':',end-1);if(end==std::string::npos)return 0;}
    if(end==0)return 0;
    auto begin=identity.rfind(':',end-1);
    if(begin==std::string::npos||identity.find(':',21)>=begin||begin+1==end||end-begin>21)return 0;
    std::uint64_t value=0;
    for(++begin;begin<end;++begin){
        const char c=identity[begin];if(c<'0'||c>'9')return 0;
        const unsigned d=static_cast<unsigned>(c-'0');
        if(value>(std::numeric_limits<std::uint64_t>::max()-d)/10)return 0;
        value=value*10+d;
    }
    return value;
}
}
