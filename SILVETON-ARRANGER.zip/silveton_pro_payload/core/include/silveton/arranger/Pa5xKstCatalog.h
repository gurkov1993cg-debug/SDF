#pragma once

#include "silveton/arranger/Pa5xKstIndex.h"
#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/arranger/Pa5xStyleSourceSettings.h"
#include <array>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace silveton::arranger {

class Pa5xSetBank;

struct Pa5xCatalogStyle {
    std::string name, path, relativePath;
    std::string categoryPath, bankName, fileName, metadataFileName, iconName;
    // A filename number is retained as a label, not inferred to be a fixed
    // empty-slot address. positionSlot follows the actual directory order.
    int positionOrdinal{-1}, positionSlot{-1};
    double bpm{0};
    int numerator{0}, denominator{0};
    // Loadable means the bounded native pattern graph is accepted by the
    // arranger. It does not mean all Korg pitch/DSP/sound dependencies play.
    bool loadable{false};
    std::string error;
    std::vector<std::string> warnings;
    Pa5xStyleSourceSettings originalSettings;
};
struct Pa5xCatalogStyleGroup {
    std::string name, relativePath, parentPath;
    std::size_t depth{0}, descendantStyleCount{0};
    bool metadataOrderUsed{false};
    std::vector<std::size_t> styleIndices, childGroups;
    // Explicit blank metadata cells are -1. Missing named references are
    // reported separately and never counted as discovered Style files.
    std::vector<int> slotStyleIndices;
    std::map<std::size_t,std::string> missingSlotFiles;
    std::vector<std::string> missingMetadataFiles;
};
struct Pa5xCatalogSound {
    std::string name, path, relativePath;
    int msb{-1}, lsb{-1}, program{-1};
    int internalBank{-1}, rawProgram{-1};
    std::array<std::uint8_t,2> resourceVersion{};
    bool addressKnown{false}, drumKit{false}, graphSupported{false};
    bool playable{false}; // Catalog/reference decoding never activates a Program.
    std::size_t oscillatorCount{0};
    std::string blocker;
};
struct Pa5xCatalogKeyboardSet {
    std::string name, path, relativePath;
    int ordinal{-1}, splitPoint{-1}, useGlobalSplit{-1};
    int upperOctaveTransposeRaw{0}, chordScanningRaw{-1}, keyboardModeRaw{-1};
    bool metadataSupported{false}, playable{false};
    std::vector<Pa5xPerformancePart> parts;
    std::string blocker;
};
struct Pa5xCatalogSample {
    std::string name, pcmPath, kmpPath, relativePath;
    std::uint64_t resourceId{0};
    std::uint32_t rate{0}, frames{0};
    int root{-1};
    bool previewable{false};
    std::string blocker;
};
struct Pa5xKstCatalog {
    std::string rootPath, name, error;
    bool recognized{false}, cancelled{false};
    std::uint64_t discoveredStyleFiles{0}, unavailableStyles{0};
    bool styleListComplete{false};
    std::vector<Pa5xCatalogStyle> styles;
    std::vector<Pa5xCatalogStyleGroup> styleGroups;
    std::vector<Pa5xCatalogSound> sounds;
    std::vector<Pa5xCatalogKeyboardSet> keyboardSets;
    std::vector<Pa5xCatalogSample> samples;
    std::vector<std::string> warnings;
};

// Worker/control thread only. Style/Sound/Keyboard Set entries do not depend
// on PCM being supplied. Missing/unsupported entries retain explicit blockers.
// The index overload avoids another directory walk after the UI's KST scan.
// With resourceBank supplied, PCM/KMP entries use its retained metadata only;
// absent or unsupported sample resources are never reopened by the catalog.
Pa5xKstCatalog buildPa5xKstCatalog(const Pa5xKstIndex& index,
    const std::function<void(const KstProgress&)>& progress = {},
    const std::atomic<bool>* cancel = nullptr,
    const Pa5xSetBank* resourceBank = nullptr);
Pa5xKstCatalog buildPa5xKstCatalog(const std::string& rootPath,
    const std::function<void(const KstProgress&)>& progress = {},
    const std::atomic<bool>* cancel = nullptr);

// Refresh only missing original-Style summaries from the catalog's retained
// paths. Each physical legacy STY bank is opened once. Failed/protected
// attempts are recorded as indexed/unreadable, avoiding startup retry loops.
// Categories, order and Sound/Keyboard Set/sample collections are preserved.
bool refreshPa5xKstStyleMetadata(Pa5xKstCatalog& catalog,
    const std::function<void(const KstProgress&)>& progress = {},
    const std::atomic<bool>* cancel = nullptr);

} // namespace silveton::arranger
