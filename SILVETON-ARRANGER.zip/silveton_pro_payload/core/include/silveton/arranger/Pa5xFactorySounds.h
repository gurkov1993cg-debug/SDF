#pragma once
#include <cstddef>
#include <cstdint>

namespace silveton::arranger {

enum class Pa5xFactorySoundKind : std::uint8_t { Sound, DrumKit };

struct Pa5xFactorySound {
    std::uint8_t msb{0}, lsb{0}, rawProgram{0};
    const char* name{nullptr};
    const char* category{nullptr};
    Pa5xFactorySoundKind kind{Pa5xFactorySoundKind::Sound};
    std::uint16_t printedPage{0};
};

struct Pa5xFactorySoundCatalogInfo {
    const char* manualTitle;
    const char* manualVersion;
    const char* manualEdition;
    const char* officialPage;
    const char* officialDownload;
    const char* sourcePdfSha256;
    std::uint16_t firstSoundPage, lastSoundPage;
    std::uint16_t firstDrumKitPage, lastDrumKitPage;
    std::uint16_t midiImplementationPage;
    bool programsAreZeroBased;
};

// Factual names/addresses from the official v1.5 Factory, Legacy and GM/XG
// tables. The table's PC values are already raw MIDI0..127, with no subtraction.
// Regional Local banks absent from that manual remain unknown. A catalog hit
// establishes a documented name, not ROM audio availability or installed DSP.
const Pa5xFactorySound* findPa5xFactorySound(int msb, int lsb, int rawProgram) noexcept;
const Pa5xFactorySound* pa5xFactorySounds() noexcept;
std::size_t pa5xFactorySoundCount() noexcept;
const Pa5xFactorySoundCatalogInfo& pa5xFactorySoundCatalogInfo() noexcept;

}
