#pragma once

#include "silveton/arranger/ChordRecognition.h"

#include <array>
#include <cstdint>

namespace silveton::arranger {

// Physical string numbers follow the Pa manuals: I/high e = 1, VI/low E = 6.
// Capo is the lowest available fret, not a transposition of the played chord.
struct GuitarPatternSettings {
    int capo{0}, highString{1}, lowString{6}, humanize{0};
    constexpr bool valid() const noexcept {
        return capo>=0&&capo<=12&&highString>=1&&highString<=6&&
            lowString>=highString&&lowString<=6&&humanize>=0&&humanize<=127;
    }
};
struct GuitarOverride {
    // -1: original track type; 0: normal accompaniment; 1: Guitar.
    int mode{-1}, capo{-1}, highString{-1}, lowString{-1}, humanize{-1};
    constexpr bool valid() const noexcept {
        return mode>=-1&&mode<=1&&capo>=-1&&capo<=12&&
            (highString==-1||(highString>=1&&highString<=6))&&
            (lowString==-1||(lowString>=1&&lowString<=6))&&
            (highString<0||lowString<0||highString<=lowString)&&
            humanize>=-1&&humanize<=127;
    }
};
GuitarPatternSettings resolveGuitarSettings(GuitarPatternSettings source,
                                           const GuitarOverride& edit) noexcept;

struct GuitarShape {
    int highString{1}, lowString{6}, position{0};
};
// C0/MIDI12 NoteOn velocity1..90. MIDI velocity-zero NoteOff is deliberately
// not decoded here; otherwise releasing C0 could reset a selected shape.
bool guitarShapeFromVelocity(int velocity,GuitarShape& shape) noexcept;

struct GuitarVoicing {
    // Internal order is low E, A, D, G, B, high e. -1 means a muted string.
    std::array<int,6> notes{{-1,-1,-1,-1,-1,-1}};
    int lowestFret{0};
};
// Bounded CAGED fingering selection for the recognized chord. This is an
// independent SILVETON renderer, not Korg's unpublished voicing table.
GuitarVoicing makeGuitarVoicing(Chord chord,int capo,int position) noexcept;

struct GuitarStrokeNote { int string{-1}, pitch{-1}; };
struct GuitarStroke {
    std::array<GuitarStrokeNote,6> notes{};
    int count{0};
    double spacingMs{0}, gateMs{-1};
    bool muteAll{false};
};
// Documented Pa-series command keys24..47. Timing and short muted gates are
// explicit SILVETON performance choices; no RX sound keys are fabricated.
GuitarStroke makeGuitarStroke(int command,int velocity,Chord chord,
    const GuitarPatternSettings& settings,const GuitarShape& shape,
    const GuitarVoicing& voicing,bool alternatingUp) noexcept;

} // namespace silveton::arranger
