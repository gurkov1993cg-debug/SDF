#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

// Native PRF/STS mixer-part records, not Pa5X XML Pitch or MIDI RPN values.
// Layout identity travels with the unchanged bytes, so a saved source record
// can be revalidated without assuming a keyboard model from a folder name.
struct PaSeriesTrackSettings {
    std::uint32_t tag{0}, trackIndex{0};
    bool recognized{false}, structurallyValid{false};
    std::vector<std::uint8_t> originalRecord;
    std::string error;

    // A zero is an explicit native value. Unknown/invalid fields have their
    // known flag clear or -1, while originalRecord preserves the source byte.
    bool detuneKnown{false}, octaveTransposeKnown{false};
    int detuneCents{0}, octaveTranspose{0};
    std::array<int,2> masterFxSendRaw{{-1,-1}};
    int pitchBendRangeSemitones{-1};
    int dryRaw{-1}; // Raw boolean only: routing/polarity is not yet decoded.
    std::array<int,3> eqGainHalfDb{{0,0,0}}; // low, middle, high; signed 0.5 dB
    std::uint8_t eqGainKnownMask{0};

    // All remaining controls, including Sound Edit/Insert FX extensions, stay
    // in originalRecord. This marker never asserts their DSP is implemented.
    bool semanticsComplete{false};
};

constexpr std::size_t kMaximumPaSeriesTrackRecordBytes=4096U;
PaSeriesTrackSettings readPaSeriesTrackSettings(std::uint32_t tag,
    const std::uint8_t* bytes,std::size_t size);

} // namespace silveton::arranger
