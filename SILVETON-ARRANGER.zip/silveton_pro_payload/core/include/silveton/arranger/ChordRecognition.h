#pragma once

#include <array>
#include <cstdint>
#include <string>

namespace silveton::arranger {

// Values 0..9 retain the original public enum and stored Style compatibility.
enum class ChordType : std::uint8_t {
    Major = 0, Minor, Seventh, Major7, Minor7, Diminished, Augmented,
    Sus2, Sus4, None,
    Major6, Minor6, SeventhSus4, MajorFlat5, SeventhFlat5, Major7Flat5,
    Major7Sus4, MinorMajor7, Diminished7, DiminishedMajor7, Minor7Flat5,
    Augmented7, AugmentedMajor7, RootOctave, RootFifth
};
struct Chord {
    int root{0};
    ChordType type{ChordType::None};
    int bass{0};
    constexpr bool valid() const noexcept { return type != ChordType::None; }
};
enum class ChordRecognitionMode : std::uint8_t {
    OneFinger = 0, OneFingerPlus, FingeredOneNote, FingeredThreeNotes, Advanced
};

std::string chordName(Chord chord); // UI/control thread only; may allocate
// Relative constituent pitch classes; bit 0 is the root. None/unknown -> 0.
std::uint16_t chordPitchClassMask(ChordType type) noexcept;

// Bounded, allocation-free recognition of documented modes and chord shapes,
// including only each diagram's explicitly allowed optional tension notes.
// simplifiedAllowed means the lower/split area permits one/two-key shortcuts.
// Otherwise at least three physical keys are required in every mode.
// The manual does not define priorities for all overlapping voicings, exact
// OneFingerPlus distance, or a complete Advanced rootless table. Those aspects
// cannot be claimed identical to a physical Pa5X; see implementation comments.
Chord recognizeChord(const std::array<bool, 128>& held, ChordRecognitionMode mode,
                     bool simplifiedAllowed = true, bool bassInversion = false,
                     Chord previous = {}) noexcept;
// Original nine-pattern detector, including its previous bass/slash behavior.
// Retained for source/behavior compatibility with existing callers and tests.
Chord detectChord(const std::array<bool, 128>& held) noexcept;

} // namespace silveton::arranger
