#pragma once

#include "silveton/arranger/KorgMidiInspection.h"
#include <array>
#include <memory>

namespace silveton::arranger {

enum class KorgSourceFxScope : std::uint8_t { KeyboardMaster, KeyboardPart, StyleMaster, StyleTrack };
enum class KorgSourceFxKind : std::uint8_t { Master, Insert, Unscoped };
enum class KorgSourceFxEncoding : std::uint8_t { Pa5xSysEx87, LegacyPrf78, Prf73 };
constexpr std::size_t kMaximumKorgSourceFxDefinitions=512;
constexpr std::size_t kMaximumKorgSourceFxSends=2048;
constexpr std::size_t kMaximumKorgSourceFxOpaqueBytes=64U*1024U;
constexpr std::size_t kMaximumKorgSourceFxOpaqueEvents=512;

struct KorgSourceFxDefinition {
    KorgSourceFxKind kind{KorgSourceFxKind::Master};
    KorgSourceFxEncoding encoding{KorgSourceFxEncoding::Pa5xSysEx87};
    std::uint8_t ownerRaw{0},slotRaw{0};
    std::uint16_t selector{0};
    // These three bytes are not named enable/routing/modulation until their
    // corresponding source meaning has independently been established.
    std::array<std::uint8_t,3> controlsRaw{}; // original payload[7..9]
    std::uint8_t controlsKnownMask{7}; // PRF has no proven equivalent for every byte
    std::array<std::uint8_t,64> parameters{};
    std::array<std::uint8_t,87> payload{}; // excludes F0; includes final F7
    // Legacy records retain their exact native framing. payload remains zero;
    // no invented Pa5X SysEx is manufactured for a PRF record.
    std::vector<std::uint8_t> originalRecord;
    std::uint32_t tick{0};
    std::uint16_t physicalTrack{0};
    std::uint64_t order{0};
};
struct KorgSourceFxSend {
    std::uint32_t tick{0};
    std::uint16_t physicalTrack{0};
    std::uint64_t order{0};
    std::uint8_t channel{0},slot{0},value{0}; // CC91/93/94 => slots0/1/2
};
struct KorgSourceFxContext {
    KorgSourceFxScope scope{KorgSourceFxScope::KeyboardMaster};
    std::string resourcePath;
    // Keyboard0=Lower,1..3=Upper1..3; Style0=Drum,1=Perc,2=Bass,3..7=ACC.
    // Master profiles have logicalPart=-1. Only StyleTrack has an Element.
    int logicalPart{-1},element{-1};
    int rawFxGroup{-1},rawDryOff{-1};
    std::uint16_t ppq{0};
    bool setupBoundaryKnown{false};
    std::uint32_t setupTicks{0};
};
struct KorgSourceEffects : KorgSourceFxContext {
    // complete means bounded extraction completed. It does NOT mean all
    // algorithms, raw controls or other original messages are implemented.
    bool complete{true};
    std::string error;
    std::size_t malformedFxMessages{0},unrecognizedFxMessages{0};
    // Each vector retains original SMF (tick,order) and physical-track scope.
    // Owner namespaces0..3 and20..23 remain distinct, including duplicates.
    std::vector<KorgSourceFxDefinition> definitions;
    std::vector<KorgSourceFxSend> sends;
    std::vector<KorgMidiOpaqueEvent> unknownMessages;
    bool valid() const noexcept;
};

// Pure control/worker-thread reduction; no DSP execution or generic SysEx
// replay. Validates the corroborated87-byte Pa5X frames and decodes the74
// seven-bit bytes into the original64-byte parameter block (MSB bit6 first).
std::shared_ptr<const KorgSourceEffects> makeKorgSourceEffects(
    const KorgSourceFxContext& context,
    const std::vector<KorgMidiChannelEvent>& channels,
    const std::vector<KorgMidiOpaqueEvent>& opaque);

std::shared_ptr<const KorgSourceEffects> unavailableKorgSourceEffects(
    const KorgSourceFxContext& context,const std::string& error);

struct KorgSourceFxRawRecord {
    std::uint32_t tag{0};
    std::uint64_t order{0};
    std::vector<std::uint8_t> bytes;
};
std::shared_ptr<const KorgSourceEffects> makeKorgPrfSourceEffects(
    const KorgSourceFxContext& context,const std::vector<KorgSourceFxRawRecord>& records);

} // namespace silveton::arranger
