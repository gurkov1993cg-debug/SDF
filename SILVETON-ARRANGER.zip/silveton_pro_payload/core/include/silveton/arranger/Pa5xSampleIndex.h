#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

enum class Pa5xSampleContainerKind { Unknown, PcmSamples, Multisamples };
enum class Pa5xPcmByteOrder { Unknown, BigEndian, LittleEndian };
enum class Pa5xSampleEndConvention {
    Unknown, InclusiveIndex, ExclusiveBoundary, InclusiveIndexOrCountBoundary,
    // Keep the legacy retained audio extent, but wrap BEFORE the stored end
    // point. Korg recordings can store loop-head guard points at/after it.
    KorgLoopBoundary
};

struct Pa5xSampleObject {
    std::string name;
    std::uint8_t objectType{0}, rawBank{0}, rawSlot{0};
    std::uint8_t versionMajor{0}, versionMinor{0};
    bool hasId{false}, idFromPayload{false};
    std::uint64_t resourceId{0};
    std::size_t payloadOffset{0}, payloadBytes{0};
    std::uint8_t payloadFlags{0};
    bool oc31Compressed{false}, encrypted{false}, containerDecoded{false};
    std::size_t decodedContainerBytes{0};
    std::string decodeError;
    bool audioMetadataDecoded{false};
    std::uint8_t sampleFormat{0}, channelTag{0};
    Pa5xPcmByteOrder pcmByteOrder{Pa5xPcmByteOrder::Unknown};
    std::uint32_t sampleRate{0}, encodedSampleCount{0}, loopStart{0};
    // Original standard-header words at offsets 18,22,...,62. The primary
    // reference names only offset50 (loop start); keep the other words raw.
    std::array<std::uint32_t, 12> rawAudioHeaderWords{};
    std::uint32_t endPositionRaw{0}, secondaryEndPositionRaw{0};
    std::size_t audioDataOffset{0}, audioDataBytes{0};
};

struct Pa5xKmpSample {
    std::string name;
    std::uint64_t resourceId{0};
    std::uint8_t bank{0}, originalNote{0};
    bool bankKnown{true}, predictorsKnown{true};
    // Version 8 predictor positions are derived from the paired PCM/KMP
    // corpus, not from a published Korg v8 specification.
    bool predictorsDerived{false};
    std::uint16_t packedData{0};
    std::int16_t predictor1{0}, predictor2{0};
    std::uint32_t sampleRate{0};
    // Version 8 removed/rearranged fields from the older prefix. Preserve the
    // exact bytes without pretending those sample/DSP parameters are decoded.
    std::array<std::uint8_t, 75> version8Prefix{};
};
struct Pa5xKmpDrumSample {
    std::string name;
    std::uint64_t resourceId{0};
    std::int32_t leftSample{-1}, rightSample{-1};
    std::uint8_t bank{0}, family{0};
    bool version8ReferencesPresent{false};
    // The old format explicitly names left/right; the v8 reference matrix's
    // stereo/layer semantics are not established by its integer boundaries.
    bool stereoPairingKnown{true};
    std::array<std::int32_t, 16> version8References{};
};
struct Pa5xKmpKeyZone {
    std::int32_t sampleIndex{-1};
    std::uint8_t highNote{0}, originalNote{0};
    std::int8_t level{0};
    std::int16_t pitch{0};
    bool pitchLevelDecoded{true};
    std::array<std::uint8_t, 20> version5Record{};
    std::array<std::uint8_t, 16> version8Record{};
};
struct Pa5xKmpMultisample {
    std::string name;
    std::uint64_t resourceId{0};
    std::uint32_t firstZone{0};
    std::array<std::uint8_t, 128> zoneIndices{};
    std::uint8_t zoneCount{0};
};

struct Pa5xSampleIndex {
    bool recognized{false}, valid{false};
    Pa5xSampleContainerKind kind{Pa5xSampleContainerKind::Unknown};
    std::string error;
    std::uint8_t tocVersionMajor{0}, tocVersionMinor{0};
    std::vector<Pa5xSampleObject> objects;
    std::vector<std::string> blockers;
    bool waveformDecoded{false};
    bool multisampleMappingDecoded{false};
    std::vector<Pa5xKmpSample> samples;
    std::vector<Pa5xKmpDrumSample> drumSamples;
    std::vector<Pa5xKmpKeyZone> keyZones;
    std::vector<Pa5xKmpMultisample> multisamples;
};

struct Pa5xLinearAudio {
    std::uint32_t sampleRate{0};
    std::vector<float> mono;
    std::string error;
    explicit operator bool() const noexcept { return error.empty() && !mono.empty(); }
};
using Pa5xSampleAudio = Pa5xLinearAudio;

struct Pa5xSamplePlaybackMetadata {
    bool flagsDecoded{false};
    bool reverse{false}, oneShotFlag{false}, loopEnabled{false};
    bool useLoopPitch{false}, twelveDbBoost{false}, doNotStream{false};
    std::uint8_t storedSampleType{0}, interpolationMode{0};
    bool rootKeyKnown{false};
    std::uint8_t rootKey{0};
    float gainDb{0.0F};
    Pa5xSampleEndConvention endConvention{Pa5xSampleEndConvention::Unknown};
    std::uint64_t sampleStartFrame{0}, sampleEndFrame{0}; // end exclusive
    std::uint64_t loopStartFrame{0}, loopEndFrame{0};     // end exclusive
    std::vector<std::string> uncertainties;
    std::string error;
    explicit operator bool() const noexcept { return error.empty() && flagsDecoded; }
};

// Partial audio mode preserves a structurally valid container when an individual
// PCM object's audio metadata is unsupported or malformed. That object remains
// unplayable with a decodeError; container, identifier and KMP checks stay strict.
Pa5xSampleIndex inspectPa5xSampleBytes(const std::vector<std::uint8_t>& bytes,
                                     bool allowPartialAudio = false);
Pa5xSampleIndex inspectPa5xSampleFile(const std::string& path);
// Ordinary, unencrypted format16 mono audio: v0.0 stores S16BE; the bounded
// v2.0 nested payload stores S16LE. Predictive/encrypted audio fails explicitly.
Pa5xLinearAudio decodePa5xLinearPcm(const std::vector<std::uint8_t>& bytes,
                                  const Pa5xSampleObject& object);
// Raw mono sample decoding only. The exact PCM UID and rate must match its KMP
// record; this does not apply PCG parameters, key-zone DSP or sample loops.
Pa5xSampleAudio decodePa5xSampleAudio(const std::vector<std::uint8_t>& bytes,
                                    const Pa5xSampleObject& object,
                                    const Pa5xKmpSample& sample,
                                    std::size_t maximumSamples = 16U * 1024U * 1024U);
// Decode the documented packed flags and convert offset54's end-like field
// under an explicit caller-selected convention. The default does not guess.
// InclusiveIndexOrCountBoundary additionally accepts a stored count as an
// exclusive-boundary sentinel, observed in the paired corpus. Its selection
// is an empirical policy, not a published Korg endpoint specification.
// KorgLoopBoundary retains that audio extent for existing cache files but
// uses offset54 itself as the exclusive loop end. This avoids replaying the
// loop-head guard points observed at/after that boundary in the paired data.
// oneShotFlag disables looping; it must not be taken to mean ignoring note-off.
// Zone Original Note remains authoritative over the sample's descriptive root.
Pa5xSamplePlaybackMetadata inspectPa5xSamplePlayback(
    const Pa5xSampleObject& object, const Pa5xKmpSample& sample,
    Pa5xSampleEndConvention endConvention = Pa5xSampleEndConvention::Unknown);
}
