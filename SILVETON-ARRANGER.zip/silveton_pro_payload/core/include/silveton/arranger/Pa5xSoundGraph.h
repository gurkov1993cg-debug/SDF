#pragma once

#include "silveton/arranger/Pa5xPcgIndex.h"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

enum class Pa5xMultisampleSource : std::uint8_t { Rom = 0, Ram = 1 };
struct Pa5xOscillatorSource {
    std::uint64_t multisampleId{0};
    std::uint16_t multisampleNumber{0};
    std::uint16_t numberFlagsRaw{0};
    Pa5xMultisampleSource source{Pa5xMultisampleSource::Rom};
    std::uint8_t levelRaw{0}, offsetRaw{0};
    bool reversed{false};
    bool levelDecoded{true}, reverseDecoded{true}, offsetDecoded{true};
    // Eligibility by velocity only; this does not decode trigger/DNC rules.
    bool velocityUseKnown{false}, velocityCanSelect{true};
    std::array<std::uint8_t,4> extensionRaw{};
    std::uint8_t extensionBytes{0};
};
struct Pa5xOscillatorEqualizerRaw {
    bool present{false};
    std::uint8_t enabledRaw{0}, trimRaw{0}, lowGainTimes2Raw{0};
    std::uint8_t frequencyRaw{0}, midGainTimes2Raw{0}, highGainTimes2Raw{0};
};
// These are saved parameter values, not values converted to seconds, Hz or
// linear gain. The retained Triton field layout is independently corroborated
// against same-name factory programs and the supplied legacy Pa corpus. This
// does not establish Pa AMS enum identities or the original DSP transfer laws.
struct Pa5xAmsParameterRaw {
    std::uint8_t source{0};
    std::int8_t intensity{0};
};
struct Pa5xKeyboardTrackingRaw {
    std::uint8_t lowKey{0}, highKey{0};
    std::int8_t lowRamp{0}, highRamp{0};
};
struct Pa5xEnvelopeParametersRaw {
    std::int16_t startLevel{0}, attackLevel{0}, breakLevel{0}, sustainLevel{0}, releaseLevel{0};
    std::uint8_t attackTime{0}, decayTime{0}, slopeTime{0}, releaseTime{0};
    bool hasReleaseLevel{false};
};
struct Pa5xEnvelopeModulationRaw {
    std::array<Pa5xAmsParameterRaw,2> time{};
    Pa5xAmsParameterRaw level{};
    // Each saved byte contains four two-bit direction selectors. Keep their
    // original codes: assigning an unverified Pa selector enum is unsafe.
    std::array<std::uint8_t,2> timeDirections{};
    std::uint8_t levelDirections{0};
};
struct Pa5xLfoParametersRaw {
    std::uint8_t waveformFlags{0}, frequency{0}, delay{0}, fade{0}, tempoSyncFlags{0};
    std::int8_t offset{0};
    std::array<Pa5xAmsParameterRaw,2> frequencyModulation{};
};
struct Pa5xFilterPathParametersRaw {
    std::uint8_t frequency{0};
    std::int8_t keyboardTrackingIntensity{0};
    std::array<Pa5xAmsParameterRaw,2> modulation{};
    std::int8_t envelopeIntensity{0}, velocityIntensity{0};
    std::array<std::int8_t,2> lfoIntensity{}, joystickLfoIntensity{}, lfoAmsIntensity{};
    std::int8_t envelopeAmsIntensity{0};
};
struct Pa5xOscillatorDspParametersRaw {
    bool fieldLayoutDecoded{false}, nominalRangesValid{false};
    bool legacyTritonLayoutCorroborated{false};
    bool newerPaLayoutCorroborated{false};
    bool timeGainLawsDecoded{false}, amsSourceMappingDecoded{false};
    bool amplitudeLevelEncodingDecoded{false}, portamentoEncodingDecoded{false};
    std::array<Pa5xLfoParametersRaw,2> lfos{};
    Pa5xAmsParameterRaw pitchModulation{}, pitchEnvelopeModulation{};
    std::uint8_t pitchTrackingSlope{0}, portamentoFlags{0}, portamentoTime{0};
    std::int8_t pitchEnvelopeIntensity{0};
    std::array<std::int8_t,2> pitchLfoIntensity{}, pitchJoystickLfoIntensity{}, pitchBendRange{};
    std::int8_t pitchRibbonIntensity{0};
    std::uint8_t pitchReserved{0};
    std::array<Pa5xAmsParameterRaw,2> pitchLfoModulation{};
    std::uint8_t filterType{0}, filterTrim{0}, filterResonance{0};
    Pa5xAmsParameterRaw filterResonanceModulation{};
    std::uint8_t filterEnvelopeAmsSource{0};
    std::array<std::uint8_t,2> filterLfoAmsSource{};
    std::array<Pa5xFilterPathParametersRaw,2> filters{};
    Pa5xEnvelopeParametersRaw filterEnvelope{}, amplitudeEnvelope{};
    Pa5xEnvelopeModulationRaw filterEnvelopeModulation{}, amplitudeEnvelopeModulation{};
    Pa5xKeyboardTrackingRaw filterKeyboardTracking{}, amplitudeKeyboardTracking{};
    std::uint8_t amplitudeLevel{0};
    std::int8_t amplitudeVelocityIntensity{0};
    Pa5xAmsParameterRaw amplitudeModulation{};
    std::array<std::int8_t,2> amplitudeLfoIntensity{};
    std::array<Pa5xAmsParameterRaw,2> amplitudeLfoModulation{};
    std::uint8_t amplitudeReserved{0};
};
struct Pa5xOscillatorReferences {
    std::size_t decodedBodyOffset{0};
    Pa5xOscillatorSource high, low;
    std::uint8_t delayRaw{0}, velocitySwitch{0};
    std::uint8_t velocityLow{0}, velocityHigh{127};
    std::uint8_t keyLow{0}, keyHigh{127};
    std::uint8_t triggerModeRaw{0}, controllerExceptionRaw{0};
    std::int8_t octaveRaw{0};
    std::uint8_t transposeRaw{0};
    std::int16_t tuneRaw{0};
    std::uint8_t scaledVelocityLow{0}, scaledVelocityHigh{127};
    std::array<std::uint8_t,90> opaqueDsp{};
    std::array<std::uint8_t,20> lfoRaw{};
    std::array<std::uint8_t,22> amplitudeEnvelopeRaw{};
    // Retained trailing common oscillator output bytes. Parameter-domain and
    // AMS support remain separate from this exact four-byte capture.
    std::array<std::uint8_t,4> outputRaw{};
    bool outputRawPresent{false};
    // Version5 adds three bytes within DSP; versions6..8 add another two
    // around portamento. Their meanings/units remain unassigned.
    std::array<std::uint8_t,5> additionalDspRaw{};
    std::uint8_t additionalDspBytes{0};
    Pa5xOscillatorDspParametersRaw dsp;
    bool staticPitchDecoded{false}, triggerFieldsDecoded{true}, scaledVelocityDecoded{true};
    std::int8_t transposeSemitones{0};
    int staticPitchOffsetCents{0};
    Pa5xOscillatorEqualizerRaw equalizer;
    // Complete original newer tail, including additional unassigned fields.
    // Legacy imports retain their formerly discarded final four output bytes
    // here; older legacy graph caches have an empty vector and stay unknown.
    // Corroborated retained parameter blocks also appear in dsp above.
    std::vector<std::uint8_t> undecodedTail;
};
enum class Pa5xVelocityLayer { Unknown, None, Low, High };
struct Pa5xSourceVelocityUse { bool known{false}, possible{true}; };
Pa5xSourceVelocityUse pa5xSourceVelocityUse(const Pa5xOscillatorReferences& oscillator,
                                          bool high) noexcept;
// Select a multisample layer for an already eligible oscillator. Trigger/DNC
// eligibility and amplitude response are separate, incompletely decoded rules.
Pa5xVelocityLayer pa5xVelocityLayer(const Pa5xOscillatorReferences& oscillator,
                                  int key, int velocity) noexcept;
// Original Sound FX records have their own framing. They are not Pa5X MIDI
// messages, and choosing one Sound must not replace a Keyboard Set/Style rack.
// Selector/parameter extraction is separate from activation and slot ownership.
struct Pa5xSoundFxRecordRaw {
    std::size_t decodedBodyOffset{0};
    std::uint8_t recordIndex{0}, recordBytes{0};
    std::uint8_t leadingRaw{0}, selectorLowRaw{0}, trailingControlRaw{0};
    bool trailingControlPresent{false};
    // Only the zero-leading-byte selector representation is corroborated.
    // A nonzero leading byte remains unknown, never silently discarded.
    bool selectorDecoded{false};
    std::uint16_t selector{0};
    std::array<std::uint8_t,64> parameters{};
};
struct Pa5xSoundEffectsRaw {
    bool framingDecoded{false};
    std::array<std::uint8_t,2> resourceVersion{};
    std::vector<Pa5xSoundFxRecordRaw> records;
    // These bytes follow the records. No Send, Dry, On/Off or routing meanings
    // are invented from the ranges/positions observed in the original files.
    std::size_t commonControlsBodyOffset{0};
    std::array<std::uint8_t,6> commonControlsRaw{};
    std::uint8_t commonControlsBytes{0};
    bool activationDecoded{false}, slotOwnershipDecoded{false}, routingDecoded{false};
    std::string error;
};
struct Pa5xSoundReferenceGraph {
    bool recognized{false};
    bool referenceGraphDecoded{false};
    // Parameter field extraction does not establish original DSP transfer
    // laws, effects, DNC/articulations, or a playable complete Program.
    bool parametersDecoded{false};
    std::array<std::uint8_t,2> resourceVersion{};
    std::string error;
    std::string bodyName;
    std::uint16_t multisampleMapRaw{0};
    std::uint8_t voiceFlagsRaw{0}, oscillatorFlagsRaw{0};
    std::size_t decodedBodyBytes{0};
    std::vector<Pa5xOscillatorReferences> oscillators;
    // Derived from commonRaw after a successful bounded Sound parse and after
    // snapshot restore. commonRaw remains the durable original-byte source.
    Pa5xSoundEffectsRaw effects;
    std::array<std::uint8_t,14> pitchEnvelopeRaw{};
    bool pitchEnvelopePresent{false}, pitchEnvelopeDecoded{false};
    bool corpusDerivedReferenceLayout{false};
    std::vector<std::uint8_t> commonRaw;
    std::vector<std::string> synthesisBlockers;
};

// Rebuilds only derived metadata; does not mutate commonRaw, oscillator data,
// Sound readiness or any active effect rack. Malformed framing stays unknown.
Pa5xSoundEffectsRaw inspectPa5xSoundEffects(const Pa5xSoundReferenceGraph& graph);
// Retained common Pitch EG layout: original levels/times, AMS pairs and packed
// directions. Decoding the layout does not authorize an unknown AMS source or
// claim the manufacturer's physical pitch/time transfer function.
void derivePa5xSoundCommonParameters(Pa5xSoundReferenceGraph& graph) noexcept;
// Optional Program metadata payload. Only original record/control bytes are
// stored; derived selector flags are rebuilt. No MIDI frame or DSP state is
// synthesized. The versioned payload is at most412bytes.
std::vector<std::uint8_t> encodePa5xSoundEffects(const Pa5xSoundEffectsRaw& effects);
bool decodePa5xSoundEffects(const std::vector<std::uint8_t>& bytes,
                           Pa5xSoundEffectsRaw& effects,std::string& error);

// Normal Sound source references in versions 0..3 and 5..8 (minor0). The caller
// supplies the structurally validated PCG descriptor and the same file bytes.
// Versions5..8 have corpus-derived, exact-length source/key/velocity layouts
// and corroborated retained oscillator DSP fields. New extensions, transfer
// laws and complete synthesis remain explicitly undecoded.
// All other versions, Drum Kits and incomplete/extra payload bytes fail closed.
// Unknown external bank addressing does not prevent the body from being decoded;
// the body voice-kind flag is checked independently of the directory kind.
Pa5xSoundReferenceGraph inspectPa5xSoundGraph(const std::vector<std::uint8_t>& pcgBytes,
                                            const Pa5xPcgSound& sound);
Pa5xSoundReferenceGraph inspectPa5xSoundGraphFile(const std::string& path,
                                                int internalBank, int rawProgram);
} // namespace silveton::arranger
