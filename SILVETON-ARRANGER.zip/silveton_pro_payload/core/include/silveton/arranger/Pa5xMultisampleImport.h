#pragma once

#include "silveton/arranger/Pa5xProgramImport.h"
#include "silveton/sampler/SamplerTypes.h"
#include <cstddef>
#include <cstdint>
#include <atomic>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace silveton::arranger {

struct Pa5xMultisampleBlocker {
    std::string code;
    std::uint64_t resourceId{0};
    std::size_t zoneIndex{0};
    std::string message;
};

struct Pa5xMultisampleBuildOptions {
    // Unknown is deliberately strict. A caller selecting an empirically
    // derived endpoint policy must retain that provenance in its own report.
    Pa5xSampleEndConvention endConvention{Pa5xSampleEndConvention::Unknown};
    std::size_t maximumSamplesPerWaveform{16U * 1024U * 1024U};
    std::size_t maximumTotalFrames{64U * 1024U * 1024U};
    const std::atomic<bool>* cancel{nullptr};
    // SET-level preparation can keep only attack prefixes resident, while
    // decoded recordings are shared from this private persistent disk cache.
    std::string streamCacheDirectory;
    std::size_t preloadFrames{1024U};
    // Disk streaming is the default performance policy. Whole-recording RAM
    // fallback/preload is opt-in, so a large SET cannot silently fill memory.
    bool allowMemoryFallback{false}, respectPreloadOnly{false};
};

struct Pa5xMultisampleImport;

// Scope this cache to one immutable KMP and PCM inventory. It stores fully
// validated native samples, including their explicitly selected loop policy.
struct Pa5xMultisampleCache {
    std::map<std::string, silveton::sampler::SamplePtr> samples;
    // Shared resident-frame budget for the entire SET, not per Sound. Streamed
    // recordings count only their copied attack prefixes against this budget.
    std::size_t maximumDecodedFrames{64U * 1024U * 1024U};
    std::size_t decodedFrames{0};
    // Only one encoded PCM file is retained while preparing a SET.
    std::string encodedPath;
    std::string encodedError;
    std::vector<std::uint8_t> encodedBytes;
    std::shared_ptr<const Pa5xSampleIndex> encodedIndex;
    std::map<std::string,std::shared_ptr<const Pa5xMultisampleImport>> sampleMultisamples;
    std::map<const silveton::sampler::Multisample*,silveton::sampler::MultisamplePtr> reverseMultisamples;
    std::map<std::string,std::string> sampleErrors;
    // Same-inventory failures only. A full PCM read/hash/container failure
    // must not be retried for every UID or again during Program construction.
    // Keys include the exact source path and its immutable content hash.
    // A new LOAD owns a new cache and may retry the original source.
    std::map<std::string,std::string> sourceErrors;
};

// The inventory and object index identify an exact UID-bearing PCM resource.
// The loader must return the raw waveform from that validated resource, using
// decodePa5xSampleAudio (or equivalent UID/rate/span checks). No note tuning,
// gain, looping or stereo pairing belongs in this callback.
using Pa5xSampleAudioLoader = std::function<Pa5xSampleAudio(
    const Pa5xPcmInventory&, std::size_t, const Pa5xKmpSample&)>;

struct Pa5xMultisampleImport {
    bool found{false}, parametersDecoded{false}, samplesDecoded{false}, ready{false};
    bool usesDerivedMetadata{false};
    std::uint64_t resourceId{0};
    std::string name;
    std::size_t mappedKeys{0}, silentKeys{0}, decodedSampleCount{0};
    silveton::sampler::MultisamplePtr multisample;
    std::vector<std::uint64_t> missingSampleIds;
    std::vector<Pa5xMultisampleBlocker> blockers;
    std::vector<std::string> warnings;
    explicit operator bool() const noexcept { return ready && multisample != nullptr; }
};

// Expands the exact 128-key KMP map. Missing data or unsupported playback
// parameters reject the whole multisample; no substitute zones are published.
// With an empty loader, files are read and revalidated one source at a time.
Pa5xMultisampleImport buildPa5xMultisample(
    const Pa5xSampleIndex& kmp, std::size_t multisampleIndex,
    const std::vector<Pa5xPcmInventory>& pcm,
    const Pa5xSampleAudioLoader& loader = {},
    Pa5xMultisampleCache* cache = nullptr,
    const Pa5xMultisampleBuildOptions& options = {});

}
