#pragma once

#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include <array>
#include <cstdint>
#include <limits>
#include <memory>
#include <string>
#include <vector>

namespace silveton::arranger {

struct Pa5xStyleSoundChange {
    // CV changes use ticks relative to the proven setup boundary. Entries in
    // setupSoundChanges instead use the original setup-track timebase.
    std::uint32_t tick{0}, originalTick{0};
    std::uint64_t order{0};
    std::uint8_t channel{0};
    int msb{-1}, lsb{-1}, program{-1};
    bool fromSetup{false};
    Pa5xSoundAddressRead sound;
};

struct Pa5xStyleTempoChange {
    std::uint32_t tick{0}, originalTick{0}, microsecondsPerQuarter{0};
    double bpm{0};
};
struct Pa5xStyleMeterChange {
    std::uint32_t tick{0}, originalTick{0};
    unsigned numerator{0}, denominator{0};
};

struct Pa5xStyleReadCv {
    int number{0}; // original CV1..CV6; array index is number-1
    bool available{false}, timingKnown{false}, hasNotes{false};
    std::uint32_t lengthTicks{0};
    std::string sourceRoot, sourceChord; // original XML declarations
    std::vector<Pa5xStyleSoundChange> soundChanges;
    std::vector<Pa5xStyleTempoChange> tempoChanges;
    std::vector<Pa5xStyleMeterChange> timeSignatureChanges;
    // Only original CC0, CC32 and Program Change events, with their physical
    // SMF track number, absolute ticks and order. A pending bank select does
    // not change the active Sound until its corresponding Program Change.
    std::vector<KorgMidiChannelEvent> bankProgramEvents;

    // Read one original performance pass. This is not a declaration that a
    // playback engine resets setup parameters at every later CV loop.
    const Pa5xStyleSoundChange* soundAt(std::uint8_t channel, std::uint32_t tick,
        std::uint64_t order = std::numeric_limits<std::uint64_t>::max()) const noexcept;
};

struct Pa5xStyleReadTrack {
    bool present{false}, setupTimingKnown{false};
    int track{-1};
    std::string path, patternType;
    std::uint16_t ppq{0};
    std::uint32_t setupTicks{0};
    std::vector<Pa5xStyleSoundChange> setupSoundChanges;
    std::vector<Pa5xStyleTempoChange> setupTempoChanges;
    std::vector<Pa5xStyleMeterChange> setupTimeSignatureChanges;
    std::vector<KorgMidiChannelEvent> setupBankProgramEvents;
    // For a structurally readable clip whose physical setup/CV mapping is not
    // proven, preserve these declarations without pretending they belong to CV1.
    std::vector<KorgMidiChannelEvent> unscopedBankProgramEvents;
    std::vector<KorgMidiTempo> unscopedTempoChanges;
    std::vector<KorgMidiTimeSignature> unscopedTimeSignatureChanges;
    std::array<Pa5xStyleReadCv, 6> cvs;
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
    std::shared_ptr<const PaSeriesTrackSettings> sourceNativeTrack;
};

struct Pa5xStyleReadSection {
    bool available{false}, meterKnown{false};
    int numerator{0}, denominator{0};
    std::array<Pa5xStyleReadTrack, kTracks> tracks;
};

struct Pa5xStyleKeyboardSetRead {
    int position{0}; // original Style Keyboard Set 1..4; array index is position-1
    int originalSceneNumber{-1}, originalTrack{-1};
    bool declared{false}, available{false};
    std::string name, resourcePath, error;
    std::shared_ptr<const Pa5xKeyboardSetRead> keyboardSet;
    // Unchanged original embedded branch payload with a standalone Root header.
    // This contains XML/MIDI only, never copied PCM or reconstructed DSP data.
    std::shared_ptr<const std::vector<std::uint8_t>> resourceBytes;
};

struct Pa5xStyleRead {
    // valid describes readable metadata, never original Sound/DSP playback.
    bool recognized{false}, valid{false};
    std::string name, sourcePath, error;
    double originalBpm{0};
    std::array<int,kTracks> originalMuteRaw{{-1,-1,-1,-1,-1,-1,-1,-1}};
    std::uint16_t ppq{0}; // common original PPQ, or zero if clips differ
    std::vector<std::string> warnings;
    // Supported mappings are explicit KeybSetArray c1..c4 declarations, or the
    // observed STAGE v1r2 main-session scenes25..28/track21 layout. Directory
    // labels and filename prefixes never determine a Keyboard Set position.
    bool keyboardSetMappingKnown{false};
    std::array<Pa5xStyleKeyboardSetRead,4> keyboardSets;
    std::array<Pa5xStyleReadSection, kElementCount> sections;
    std::shared_ptr<const Style> nativeStyle;
    std::shared_ptr<const KorgStyleInspection> inspection;
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
};

Pa5xStyleRead readPa5xStyleBytes(const std::vector<std::uint8_t>& bytes,
    const std::string& sourcePath = {}, const Pa5xSetBank* bank = nullptr);
Pa5xStyleRead readPa5xStyleFile(const std::string& path,
    const Pa5xSetBank* bank = nullptr);

} // namespace silveton::arranger
