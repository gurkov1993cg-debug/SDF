#pragma once

#include "silveton/arranger/Pa5xPcgIndex.h"
#include "silveton/arranger/Pa5xSampleIndex.h"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

struct Pa5xDrumKitKey {
    std::uint16_t firstLayer{0};
    std::uint16_t opaqueIndexRaw{0};
    std::uint8_t layerCount{0};
    std::array<std::uint8_t,5> velocitySwitchesRaw{};
    std::array<std::uint8_t,4> opaqueA{};
    std::uint8_t opaqueB{0}, legacyOpaque{0};
    std::array<std::uint8_t,2> opaqueC{};
    std::vector<std::uint8_t> velocitySwitchesExtendedRaw;
    std::vector<std::uint8_t> rawRecord;
};
struct Pa5xDrumKitLayer {
    std::uint8_t sampleBankRaw{0}, reverseRaw{0};
    std::uint16_t drumSampleNumber{0};
    bool hasDrumSampleId{false};
    std::uint64_t drumSampleId{0};
    bool layerParametersIdentified{false};
    std::int8_t levelRaw{0}, transposeRaw{0}, attackRaw{0}, cutoffRaw{0};
    std::uint8_t tuneRaw{0}, decayRaw{0}, resonanceRaw{0};
    // v0/1 has one opaque detail byte; v2/3 has eleven. This includes
    // versioned EQ/intensity fields without inventing gain/time/filter laws.
    std::array<std::uint8_t,14> detailRaw{};
    std::uint8_t detailBytes{0};
    std::vector<std::uint8_t> rawRecord;
};
struct Pa5xDrumKitInspection {
    bool recognized{false}, referenceGraphDecoded{false};
    bool parametersDecoded{false}, playable{false};
    std::array<std::uint8_t,2> resourceVersion{};
    std::string name, error;
    std::uint16_t multisampleMapRaw{0};
    std::uint8_t voiceFlagsRaw{0}, oscillatorFlagsRaw{0};
    std::size_t decodedBodyBytes{0}, drumTableOffset{0};
    bool layerIdsPresent{false};
    std::uint8_t drumTableFlagsRaw{0};
    std::vector<std::uint8_t> commonRaw;
    std::vector<std::vector<std::uint8_t>> commonOscillatorsRaw;
    std::array<Pa5xDrumKitKey,128> keys{};
    std::vector<Pa5xDrumKitLayer> layers;
    std::vector<std::string> blockers;
};
struct Pa5xDrumLayerSampleLink {
    std::size_t layer{0};
    bool ram{false}, resolved{false}, stereoPairingKnown{false};
    bool duplicateResolvedByNumber{false};
    std::uint64_t drumSampleId{0};
    std::vector<std::size_t> kmpDrumIndices;
    // v8 retains all sixteen reference positions. Their exact stereo/layer
    // meaning is not collapsed to the legacy left/right pair.
    std::vector<std::int32_t> sampleIndices;
    std::vector<std::uint64_t> sampleIds;
    std::string blocker;
};
struct Pa5xDrumKitSampleLinks {
    bool completeRamReferences{false}, parametersDecoded{false}, playable{false};
    std::vector<Pa5xDrumLayerSampleLink> layers;
    std::vector<std::string> blockers;
};

// Read the original per-key Exclusive Group number (0=None, 1..127).
// This uses only calibrated, versioned key records; it never derives groups
// from MIDI note numbers, sample names or GM conventions. On unsupported or
// malformed input it returns false and clears the complete output table.
// Single Trigger, Subgroup Choke Off and the original fade-time law are not
// decoded by this function. See docs/PA_DRUM_GROUP_LAYOUT.md for provenance.
bool decodePa5xDrumExclusiveGroups(const Pa5xDrumKitInspection& kit,
                                  std::array<std::uint8_t,128>& groups) noexcept;

// Normal common/OSC fields are walked structurally before the 128-key table.
// Proven Drum Kit reference layouts are version-gated and consume the exact
// body. Newer common/layer parameter spans remain opaque; no DSP is inferred.
Pa5xDrumKitInspection inspectPa5xDrumKitBytes(const std::vector<std::uint8_t>& pcgBytes,
                                           const Pa5xPcgSound& descriptor);
Pa5xDrumKitInspection inspectPa5xDrumKitFile(const std::string& path,
                                          int internalBank, int rawProgram);
Pa5xDrumKitSampleLinks linkPa5xDrumKitSamples(const Pa5xDrumKitInspection& kit,
                                            const Pa5xSampleIndex& kmp);

} // namespace silveton::arranger
