#pragma once

#include <cstddef>
#include <cstdint>
#include <limits>
#include <string>
#include <vector>

namespace silveton::arranger {

struct KorgMidiChannelEvent {
    std::uint32_t tick{0};
    std::uint16_t track{0};
    std::uint8_t status{0}, data1{0}, data2{0};
    std::uint64_t order{0};
};
// Original proprietary messages are inspection data only. Keeping their raw
// bytes does not establish an effect algorithm or authorize MIDI replay.
struct KorgMidiOpaqueEvent {
    std::uint32_t tick{0};
    std::uint16_t track{0};
    std::uint8_t status{0}; // F0/F7 SysEx, or FF sequencer-specific meta
    std::uint8_t metaType{0}; // 7F for sequencer-specific meta
    std::vector<std::uint8_t> payload;
    // Absolute SMF event ordinal, shared with channel events. Same-tick
    // channel/SysEx ordering must not be reconstructed from vector order.
    std::uint64_t order{0};
};
struct KorgMidiPatchSelection {
    std::uint32_t tick{0};
    std::uint8_t channel{0};
    // An absent declaration remains unknown. It is never silently bank/program0.
    int msb{-1}, lsb{-1}, program{-1};
    bool usedByNotes{false};
    std::uint16_t track{0};
    std::uint64_t order{0};
};

enum class KorgMidiPatchScope : std::uint8_t {
    // Ordinary SMF tracks share MIDI channels; preserve that default behavior.
    CombinedChannels,
    // Explicit Pa5X clip context: track0 setup, alternative CV tracks1..6.
    // The byte parser itself does not infer that topology from a generic SMF.
    SetupAndIndependentCvs
};
struct KorgMidiTrackInspection {
    std::uint32_t endTick{0};
    std::uint32_t firstChannelTick{std::numeric_limits<std::uint32_t>::max()};
    bool notes{false}, hasEnd{false}, meterKnown{false}, meterChanged{false};
    unsigned numerator{0}, denominator{0};
    std::string name;
};
struct KorgMidiTempo {
    std::uint32_t tick{0}, microsecondsPerQuarter{0};
    std::uint16_t track{0};
};
struct KorgMidiTimeSignature {
    std::uint32_t tick{0};
    std::uint16_t track{0};
    unsigned numerator{0}, denominator{0};
};
struct KorgMidiInspection {
    bool valid{false};
    std::string error;
    std::uint16_t format{0}, ppq{0};
    std::uint32_t spanTicks{0};
    std::size_t eventCount{0};
    std::vector<KorgMidiTrackInspection> tracks;
    std::vector<KorgMidiChannelEvent> channelEvents;
    std::vector<KorgMidiOpaqueEvent> opaqueMidiEvents;
    std::vector<KorgMidiPatchSelection> patches;
    std::vector<KorgMidiTempo> tempos;
    std::vector<KorgMidiTimeSignature> timeSignatures;
};

// Structural SMF inspection only. Patch changes, controller-only streams,
// empty note streams, tempo changes and original opaque SysEx/FF7F messages
// are preserved rather than flattened through the generic MIDI-style importer.
// Proprietary message meaning and runtime application remain unknown.
KorgMidiInspection inspectKorgMidiBytes(const std::vector<std::uint8_t>& bytes,
    KorgMidiPatchScope scope = KorgMidiPatchScope::CombinedChannels);

} // namespace silveton::arranger
