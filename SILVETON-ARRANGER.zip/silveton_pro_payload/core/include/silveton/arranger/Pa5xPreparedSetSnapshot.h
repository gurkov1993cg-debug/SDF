#pragma once
#include "silveton/arranger/Pa5xKstCatalog.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xProgramSnapshot.h"

namespace silveton::arranger {
class Pa5xSnapshotSourceState;
// Capture before parsing. Includes empty directories, so their first new file
// invalidates a saved catalog too. Full discovery happens only on fresh LOAD.
std::shared_ptr<const Pa5xSnapshotSourceState> capturePa5xPreparedSetSources(
    const std::string& root,const std::atomic<bool>* cancel=nullptr);
struct Pa5xPreparedSetSnapshot {
    Pa5xKstIndex index;
    Pa5xKstCatalog catalog;
    std::shared_ptr<Pa5xSetBank> bank;
    std::vector<Pa5xPreparedProgram> programs;
    std::vector<std::string> warnings;
};
// Automatic startup uses saved metadata and bounded prefixes. With a current
// catalog, validation only stats known original resources/directories. Older
// or missing Style metadata is read once from its original Style files,
// without rereading source PCM.
bool loadPa5xPreparedSetSnapshot(const std::string& root,const std::string& cacheDirectory,
    Pa5xPreparedSetSnapshot& result,const std::atomic<bool>* cancel=nullptr,
    const std::function<void(const KstProgress&)>& progress = {});
bool savePa5xPreparedSetSnapshot(const std::string& cacheDirectory,
    const Pa5xKstIndex& index,const Pa5xKstCatalog& catalog,const Pa5xSetBank& bank,
    const std::vector<Pa5xPreparedProgram>& programs,const std::vector<std::string>& warnings,
    const std::shared_ptr<const Pa5xSnapshotSourceState>& sourceState,
    const std::atomic<bool>* cancel=nullptr);
} // namespace silveton::arranger
