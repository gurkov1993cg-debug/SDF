#pragma once
#include "silveton/arranger/ChordRecognition.h"
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>

namespace silveton::arranger {
struct LiveEvent {
    const char* reason{}; // static literal owned by the program
    int player{-1},status{-1},key{-1},value{-1},mode{-1},area{-1},split{-1};
    std::array<std::uint32_t,4> held{};
    Chord detected{},sounding{};
    std::int64_t ms{};
};
inline std::int64_t liveClockMs() noexcept {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}
// One producer (arranger render), one consumer (session writer). Never wait
// for the writer; report omitted records if storage cannot keep up.
class LiveEventQueue {
    static constexpr unsigned capacity=2048;
    std::array<LiveEvent,capacity> records_{};
    std::atomic<unsigned> head_{0},tail_{0};
public:
    std::atomic<bool> enabled{false};
    std::atomic<std::uint64_t> omitted{0};
    void push(LiveEvent e) noexcept {
        if(!enabled.load(std::memory_order_relaxed))return;
        const auto head=head_.load(std::memory_order_relaxed);
        if(head-tail_.load(std::memory_order_acquire)>=capacity){omitted.fetch_add(1,std::memory_order_relaxed);return;}
        e.ms=liveClockMs();records_[head%capacity]=e;
        head_.store(head+1,std::memory_order_release);
    }
    bool pop(LiveEvent& e) noexcept {
        const auto tail=tail_.load(std::memory_order_relaxed);
        if(tail==head_.load(std::memory_order_acquire))return false;
        e=records_[tail%capacity];tail_.store(tail+1,std::memory_order_release);return true;
    }
};
inline LiveEventQueue liveEvents;
}
