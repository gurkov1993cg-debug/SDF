#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

enum class Pa5xPcgSoundKind : std::uint8_t { Unknown, Sound, DrumKit };
enum class Pa5xPcgAddressEvidence : std::uint8_t {
    Unknown,
    LegacyBankTableAndCorpus,
    CanonicalPa5xBankContext
};

struct Pa5xPcgSound {
    std::string name;
    std::array<std::uint8_t, 28> rawName{};
    std::uint8_t resourceClass{0};
    std::uint8_t internalBank{0};
    std::uint8_t rawProgram{0};
    Pa5xPcgSoundKind kind{Pa5xPcgSoundKind::Unknown};
    // Mapping requires an exact canonical filename, the observed internal bank
    // code and a supported resource revision. Extended Pa5X bank contexts are
    // distinguished from the older published bank table by addressEvidence.
    // Neither Sound names nor directory sorting participate in resolution.
    bool addressKnown{false};
    Pa5xPcgAddressEvidence addressEvidence{Pa5xPcgAddressEvidence::Unknown};
    std::uint8_t msb{0}, lsb{0};
    std::array<std::uint8_t, 2> resourceVersion{};
    std::uint32_t rawChecksum{0};
    std::uint64_t rawObjectId{0};
    bool objectIdPresent{false};
    std::size_t indexOrdinal{0};
    std::size_t recordOffset{0}, recordLength{0};
    std::size_t payloadOffset{0}, payloadLength{0};
    std::array<std::uint8_t, 4> payloadChunkTag{};
    bool oc31Encoded{false};
    bool parametersDecoded{false};
};

struct Pa5xPcgInspection {
    bool recognized{false};
    // Structural directory/object-boundary validity only. It does not mean
    // the compressed bodies or their DSP/sample dependencies are playable.
    bool valid{false};
    std::string sourcePath;
    std::string error;
    std::vector<std::string> warnings;
    std::array<std::uint8_t, 4> fileTag{};
    std::size_t fileSize{0};
    std::vector<Pa5xPcgSound> sounds;
};

Pa5xPcgInspection inspectPa5xPcgBytes(const std::vector<std::uint8_t>& bytes,
                                    const std::string& sourcePath = {});
Pa5xPcgInspection inspectPa5xPcgFile(const std::string& path);
const Pa5xPcgSound* findPa5xPcgSound(const Pa5xPcgInspection& index,
                                  int msb, int lsb, int rawProgram) noexcept;

} // namespace silveton::arranger
