#pragma once

#include <cstddef>
#include <cstdint>

namespace silveton::arranger {

// This catalog identifies the Pa5X OS 1.5 effect resources. It does not claim
// that a named algorithm, its parameter decoder or its modulation is playable.
// The original FX index is distinct from both menu order and EffectType.
enum class Pa5xFxSlotRule : std::uint8_t {
    Any,
    InsertOnly,
    MasterOneOnly,
    MasterTwoThreeOnly
};

struct Pa5xEffectInfo {
    std::uint16_t index{0};
    const char* firmwareName{nullptr};
    const char* manualId{nullptr};
    const char* manualName{nullptr};
    const char* category{nullptr};
    const char* functionBg{nullptr};
    Pa5xFxSlotRule slotRule{Pa5xFxSlotRule::Any};
    std::uint16_t firstManualPage{0}, lastManualPage{0};
    bool manualIdentityConfirmed{false};
    bool slotDocumentationConflict{false};
};

// Static, allocation-free facts. Contains the 153 production Sound FX and
// Bypass, never firmware debug-only resources. Safe to use for inspection.
[[nodiscard]] const Pa5xEffectInfo* pa5xEffectCatalog(std::size_t& count) noexcept;
[[nodiscard]] const Pa5xEffectInfo* findPa5xEffect(std::uint16_t index) noexcept;

// Uses the stricter documented rule where firmware and manual disagree.
// An unknown/out-of-range slot is never treated as a valid placement.
[[nodiscard]] bool pa5xEffectAllowed(const Pa5xEffectInfo& effect,
                                   bool master,int zeroBasedSlot) noexcept;
[[nodiscard]] const char* pa5xEffectSlotRuleText(Pa5xFxSlotRule rule) noexcept;

} // namespace silveton::arranger
