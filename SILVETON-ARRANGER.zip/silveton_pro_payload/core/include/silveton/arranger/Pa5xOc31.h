#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

struct Pa5xOc31Result {
    std::vector<std::uint8_t> data;
    std::string error;
    bool checksumVerified{false};
    explicit operator bool() const noexcept { return error.empty() && checksumVerified; }
};

// A bounded independent implementation of the documented OC31 byte format.
// Input includes OC31 magic, little-endian output size, token bytes and XOR
// checksum. This decompresses a resource container, not an audio sample codec.
Pa5xOc31Result decodePa5xOc31(const std::uint8_t* bytes, std::size_t size,
                            std::size_t maximumOutputBytes = 128U * 1024U * 1024U);
inline Pa5xOc31Result decodePa5xOc31(const std::vector<std::uint8_t>& bytes,
                                   std::size_t maximumOutputBytes = 128U * 1024U * 1024U) {
    return decodePa5xOc31(bytes.data(), bytes.size(), maximumOutputBytes);
}
}
