#pragma once

#include "silveton/arranger/Pa5xSampleProgram.h"
#include <memory>

namespace silveton::arranger {

// Complete immutable table for a supported original key graph, including a
// valid all-None table. Returns nullptr for unsupported/malformed metadata.
// Only Exclusive Group is imported; the other controls keep SILVETON defaults.
// This has no PCM dependency and also upgrades existing prepared bank graphs.
std::shared_ptr<const silveton::sampler::DrumKeyGroups> buildPa5xDrumKeyGroups(
    const Pa5xDrumKitInspection& kit);

// Only the earlier, structurally decoded KMP left/right references have
// verified stereo pairing. KMP v8 stores sixteen raw references whose roles
// remain unknown; never interpret the first two as L/R by accident.
bool pa5xDrumHasVerifiedStereoPair(const Pa5xDrumLayerSampleLink& link) noexcept;

// Temporary playback of the available User recordings at the kit's original
// key/velocity positions. Missing regions stay silent. This does not recreate
// the kit's EG, filtering, ambience or round-robin processing. Supported
// original Exclusive Group numbers are applied by the sampler's choke runtime.
Pa5xSampleProgramImport buildPa5xDrumSampleProgram(
    const Pa5xSetBank& bank, int msb, int lsb, int program,
    const Pa5xMultisampleBuildOptions& options = {},
    Pa5xMultisampleCache* cache = nullptr);

} // namespace silveton::arranger
