#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

struct KorgResourceLeaf {
    std::vector<std::string> path;
    std::size_t offset{0}, length{0};
};
struct KorgResourceContainer {
    bool recognized{false}, valid{false};
    std::string error;
    std::vector<KorgResourceLeaf> leaves;
};
inline std::string korgResourcePath(const std::vector<std::string>& path) {
    std::string result;
    for (const auto& part : path) { if (!result.empty()) result += '/'; result += part; }
    return result;
}
inline std::string korgResourceText(const std::vector<std::uint8_t>& bytes, const KorgResourceLeaf& leaf) {
    if (leaf.offset > bytes.size() || leaf.length > bytes.size() - leaf.offset) return {};
    if (leaf.length == 0) return {};
    return std::string(reinterpret_cast<const char*>(bytes.data() + leaf.offset), leaf.length);
}

// Shared bounded Pa5X resource-tree reader for STG, KSC and PDC. Leaf payloads
// remain opaque; structural success does not imply playable sound data.
inline KorgResourceContainer inspectKorgResourceContainer(const std::vector<std::uint8_t>& bytes,
    std::size_t maximumBytes = 64U * 1024U * 1024U) {
    KorgResourceContainer result;
    const std::uint8_t magic[]{'R','o','o','t',0};
    if (bytes.size() < 11 || !std::equal(std::begin(magic), std::end(magic), bytes.begin())) {
        result.error = "Not a Korg Root/Branch/Leaf container"; return result;
    }
    result.recognized = true;
    if (bytes.size() > maximumBytes) { result.error = "Korg container exceeds its inspection size limit"; return result; }
    if (bytes[5] != 1 || bytes[6] != 0) { result.error = "Unsupported Korg Root container revision"; return result; }
    std::uint32_t length = 0;
    for (std::size_t i = 7; i < 11; ++i) length = (length << 8U) | bytes[i];
    if (length != bytes.size() - 11) { result.error = "Korg Root length does not match the file"; return result; }
    struct Walker {
        const std::vector<std::uint8_t>& bytes;
        KorgResourceContainer& result;
        std::size_t resources{0};
        bool name(std::size_t& cursor, std::size_t end, std::string& value) {
            const auto start = cursor;
            while (cursor < end && bytes[cursor] != 0 && cursor - start <= 1024) ++cursor;
            if (cursor == end || cursor - start > 1024) { result.error = "Unterminated Korg resource name"; return false; }
            value.assign(reinterpret_cast<const char*>(bytes.data() + start), cursor - start); ++cursor; return true;
        }
        bool walk(std::size_t cursor, std::size_t end, std::vector<std::string>& path, unsigned depth) {
            if (depth > 32) { result.error = "Korg resource nesting exceeds 32 levels"; return false; }
            while (cursor < end) {
                if (++resources > 100000) { result.error = "Korg file contains too many resources"; return false; }
                std::string kind, label;
                if (!name(cursor,end,kind) || !name(cursor,end,label)) return false;
                if (end - cursor < 4) { result.error = "Truncated Korg resource length"; return false; }
                std::uint32_t size = 0;
                for (int n=0;n<4;++n) size=(size<<8U)|bytes[cursor++];
                if (size > end - cursor) { result.error = "Korg resource exceeds its parent boundary"; return false; }
                path.push_back(label);
                if (kind == "Branch") { if (!walk(cursor,cursor+size,path,depth+1)) return false; }
                else if (kind == "Leaf") result.leaves.push_back({path,cursor,size});
                else { result.error = "Unknown Korg container resource type"; return false; }
                path.pop_back(); cursor += size;
            }
            return cursor == end;
        }
    } walker{bytes,result,0};
    std::vector<std::string> path;
    result.valid = walker.walk(11,bytes.size(),path,0);
    return result;
}
} // namespace silveton::arranger
