#pragma once

#include "silveton/arranger/Pa5xKstCatalog.h"
#include "silveton/arranger/Pa5xKstIndex.h"

#include <string>

namespace silveton::arranger {

// Private, versioned startup metadata. Samples remain in their existing disk
// cache; this snapshot preserves the original catalog order and diagnostics.
bool savePa5xCatalogSnapshot(const std::string& path,
    const Pa5xKstIndex& index, const Pa5xKstCatalog& catalog);
// CAT3 adds exact bounded native Keyboard Set mixer records. CAT1/CAT2
// remain readable; CAT1 has no per-track Style source settings.
// A valid CAT2 envelope/base with an invalid appendix also requests a refresh;
// no partial source settings are returned. The prepared-SET loader upgrades
// only this metadata without rebuilding samples. needsNativeTrackUpgrade
// marks older catalogs whose Keyboard Set native records must be re-read.
bool loadPa5xCatalogSnapshot(const std::string& path,
    Pa5xKstIndex& index, Pa5xKstCatalog& catalog,
    bool* needsStyleMetadataUpgrade = nullptr,
    bool* needsNativeTrackUpgrade = nullptr);

} // namespace silveton::arranger
