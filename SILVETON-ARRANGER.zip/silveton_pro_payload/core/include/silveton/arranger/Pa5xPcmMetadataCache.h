#pragma once

#include "silveton/arranger/Pa5xSampleIndex.h"
#include <atomic>
#include <cstdint>
#include <string>

namespace silveton::arranger {

// Captured before the original PCM read. A cache is reusable only while every
// field still matches the same regular file, including nanosecond change time.
struct Pa5xPcmSourceStamp {
    std::string canonicalPath;
    std::uint64_t size{0}, device{0}, inode{0};
    std::int64_t mtimeSeconds{0}, ctimeSeconds{0};
    std::uint32_t mtimeNanoseconds{0}, ctimeNanoseconds{0};
    bool valid{false};
};

Pa5xPcmSourceStamp inspectPa5xPcmSourceStamp(const std::string& sourcePath);
bool samePa5xPcmSourceStamp(const Pa5xPcmSourceStamp& left,
                           const Pa5xPcmSourceStamp& right) noexcept;

struct Pa5xPcmMetadataImport {
    Pa5xSampleIndex index;
    std::string contentHash, error;
    Pa5xPcmSourceStamp sourceStamp;
    bool cacheHit{false};
    explicit operator bool() const noexcept { return cacheHit; }
};

// Worker thread only. A hit reads the small metadata sidecar and stats the
// source; it never reads or hashes source PCM bytes. Invalid/missing sidecars
// are ordinary misses and require the original full inspection path.
Pa5xPcmMetadataImport loadPa5xPcmMetadataCache(const std::string& sourcePath,
                                             const std::string& cacheDirectory);

// Store only a successfully inspected PCM index and the SHA256 of the entire
// original read. The before-read stamp must still match immediately before
// publication. Writes use a private temporary file and atomic rename.
bool storePa5xPcmMetadataCache(const std::string& sourcePath,
                              const std::string& cacheDirectory,
                              const Pa5xSampleIndex& index,
                              const std::string& contentHash,
                              const Pa5xPcmSourceStamp& expectedSource,
                              const std::atomic<bool>* cancel = nullptr);

} // namespace silveton::arranger
