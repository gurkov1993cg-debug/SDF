#pragma once

#include "silveton/arranger/ArrangerEngine.h"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

struct KorgStyleInspection;
struct Pa5xStyleRead;

constexpr std::size_t kPa5xStyleSourceMaximumTracks = kElementCount * kTracks;
constexpr std::size_t kPa5xStyleSourceMaximumSounds = 7U * 16U;
constexpr std::size_t kPa5xStyleSourceMaximumTypeBytes = 256U;
constexpr std::size_t kPa5xStyleSourceMaximumErrorBytes = 8192U;

struct Pa5xStyleSourceSound {
    // Initial selection for one MIDI channel. 0 is setup; 1..6 are CVs.
    // A CV inherits setup unless it explicitly selects another Sound at its
    // beginning. varies reports later selections without retaining events.
    int cv{0}, channel{-1}, msb{-1}, lsb{-1}, program{-1};
    bool varies{false};
    bool addressKnown() const noexcept {
        return msb>=0&&msb<=127&&lsb>=0&&lsb<=127&&program>=0&&program<=127;
    }
};

struct Pa5xStyleSourceTrack {
    int element{-1}, track{-1}; // Element enum; Drum/Perc/Bass/ACC1..5 = 0..7
    std::string declaredType; // Exact named type, or proven legacy Guitar type.
    NativePatternMode nativeMode{NativePatternMode::Unsupported};
    bool available{false}; // Supported native mode with an available pattern/CV.
    bool capoKnown{false}, humanizeKnown{false};
    int capo{-1}, humanize{-1};
    // Raw source codes are inspection data, never guessed physical strings or
    // mapped Korg NTT/NTR/retrigger enums. Missing declarations remain -1.
    int stringHighRaw{-1}, stringLowRaw{-1}, nttRaw{-1}, ntrRaw{-1}, retriggerRaw{-1};
    bool keyRangeKnown{false}, keyRangeEnabled{false};
    int keyLow{-1}, keyHigh{-1}, wrapRaw{-1}, noiseOffsetRaw{-1}, tensionRaw{-1};
    std::vector<Pa5xStyleSourceSound> sounds;
};

struct Pa5xStyleSourceSettings {
    // indexed means the bounded attempt completed, including an unreadable or
    // protected source. Old catalogs have indexed=false and need one refresh.
    bool indexed{false}, readable{false};
    std::uint8_t muteKnownMask{0}, muteMask{0};
    std::string error;
    std::vector<Pa5xStyleSourceTrack> tracks;
    bool valid() const noexcept;
};

// Pure control/worker-thread reduction of already parsed metadata. These
// retain no Style/MIDI/PCM owners and perform no file access or playback.
Pa5xStyleSourceSettings summarizePa5xStyleSourceSettings(const KorgStyleInspection&,
    const Style* nativeStyle = nullptr);
Pa5xStyleSourceSettings summarizePa5xStyleSourceSettings(const Pa5xStyleRead&);
Pa5xStyleSourceSettings summarizePa5xStyleSourceSettings(const Style&);
Pa5xStyleSourceSettings unavailablePa5xStyleSourceSettings(const std::string& error);

} // namespace silveton::arranger
