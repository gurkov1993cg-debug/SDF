#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <atomic>
#include <string>
#include <vector>

namespace silveton::arranger {
struct Pa5xPreparedProgram {
    int msb{-1}, lsb{-1}, program{-1};
    sampler::ProgramPtr sound;
};

// Private prepared graph, not a new sample format. Each shared waveform and
// multisample is recorded once. Streamed audio stays in the decoded PCM cache.
bool savePa5xProgramSnapshot(const std::string& path,
    const std::vector<Pa5xPreparedProgram>& programs,
    const std::vector<std::string>& warnings);
// Control/worker thread only. Restores graph references and saved attack
// prefixes, validates/maps cache files, and never rereads original Korg PCM.
// On any failure the caller's outputs remain unchanged.
bool loadPa5xProgramSnapshot(const std::string& path,
    const std::string& cacheDirectory,
    std::vector<Pa5xPreparedProgram>& programs,
    std::vector<std::string>& warnings,
    const std::atomic<bool>* cancel = nullptr);
} // namespace silveton::arranger
