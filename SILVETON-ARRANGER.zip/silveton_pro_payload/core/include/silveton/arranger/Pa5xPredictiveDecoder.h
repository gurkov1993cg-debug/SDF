#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

struct Pa5xPredictiveAudio {
    std::vector<std::int16_t> samples;
    std::string error;
    explicit operator bool() const noexcept { return error.empty() && !samples.empty(); }
};

// Strict second-order stability in the stored Q14 coefficient domain. Unknown
// or marginally stable predictor forms are rejected rather than guessed.
bool pa5xPredictiveCoefficientsStable(std::int16_t predictor1,
                                    std::int16_t predictor2) noexcept;

// One signed residual byte produces one signed mono sample. The caller must
// first validate the PCM container, audio span and matching KMP sample ID/rate.
// This independent decoder is checked against the public reference decoding
// model; it does not establish equivalence to the original keyboard hardware.
Pa5xPredictiveAudio decodePa5xPredictive(
    const std::uint8_t* encoded, std::size_t encodedBytes,
    std::size_t expectedSamples, std::int16_t predictor1, std::int16_t predictor2,
    std::size_t maximumSamples = 16U * 1024U * 1024U, bool coefficientsFromDeclaredFields = false);

}
