#pragma once
#include "silveton/arranger/detail/ChordTransition.h"

#include "silveton/arranger/ChordRecognition.h"
#include "silveton/arranger/GuitarMode.h"
#include "silveton/arranger/LiveTrace.h"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::arranger {

constexpr int kPlayers = 2;
constexpr int kTracks = 8;
enum class Element : std::uint8_t {
    Intro1, Intro2, Intro3, Var1, Var2, Var3, Var4,
    Fill1, Fill2, Fill3, Fill4, Break, Ending1, Ending2, Ending3, Count
};
constexpr std::size_t kElementCount = static_cast<std::size_t>(Element::Count);
const char* elementName(Element e) noexcept;

enum class TrackRole : std::uint8_t { Drums, Percussion, Bass, Accompaniment };
struct TrackInfo {
    bool used{false};
    TrackRole role{TrackRole::Accompaniment};
    std::uint8_t sourceChannel{0};
    std::uint8_t msb{0}, lsb{0}, program{0}; // original raw MIDI addresses, never remapped
    bool addressKnown{false}, addressVaries{false};
    std::string name;
};
struct MidiEvent {
    std::uint32_t tick{0};
    std::uint8_t track{0}, status{0x90}, data1{0}, data2{0};
};
struct StyleTempoEvent { std::uint32_t tick{0}; double bpm{120}; };
enum class NativePatternMode : std::uint8_t {
    Drum, RecordedSourceOnly, Unsupported, Guitar
};
struct ChordVariation {
    bool available{false};
    std::uint32_t lengthTicks{0};
    int sourceRoot{0};
    bool sourceRootKnown{false};
    ChordType sourceChord{ChordType::None};
    std::vector<MidiEvent> events;
    std::vector<StyleTempoEvent> tempoEvents;
};
struct TrackPattern {
    bool present{false};
    NativePatternMode mode{NativePatternMode::Unsupported};
    int rawNtt{-1}, rawNtr{-1}, rawRetrigger{-1};
    bool keyRangeEnabled{false};
    int keyLow{0}, keyHigh{127}, wrapAroundDegree{-1};
    GuitarPatternSettings guitar;
    bool legacyGuitarProgression{false};
    // Values are original CV numbers1..6; zero means no declared mapping.
    std::array<std::uint8_t,25> chordCv{};
    std::array<ChordVariation,6> cvs;
    std::vector<MidiEvent> setupEvents;
};
// The section owns its note range. The track-wide wrap override, if set,
// supersedes the wrap point recorded in the original section.
struct PhraseRange {
    int enabled{-1}, low{0}, high{127}, wrap{0};
};
struct Section {
    bool available{false};
    std::uint8_t numerator{4}, denominator{4};
    std::uint32_t lengthTicks{0};
    std::vector<MidiEvent> events; // prepared/sorted on the loading thread
    bool nativePatterns{false};
    std::array<TrackPattern,kTracks> patterns;
};
struct Style {
    std::string name;
    std::uint16_t ppq{480};
    double tempoBpm{120.0};
    int sourceRoot{0};
    ChordType sourceChord{ChordType::Major};
    bool nativeKorg{false};
    std::uint8_t initialMuteMask{0}, initialMuteKnownMask{0};
    std::vector<std::string> playbackWarnings;
    std::array<TrackInfo, kTracks> tracks;
    std::array<Section, kElementCount> sections;
};
struct ImportResult { std::shared_ptr<const Style> style; std::string error; std::vector<std::string> warnings; explicit operator bool() const noexcept { return style != nullptr; } };
// Standard MIDI format 0/1 only. Named markers INTRO1..3, VAR1..4, FILL1..4,
// BREAK, ENDING1..3 define sections. Without markers the entire file is VAR1.
// Korg STG/STY/KST and compressed PCM are not decoded by this importer.
ImportResult importMidiFile(const std::string& path);
ImportResult importMidiBytes(const std::vector<std::uint8_t>& bytes, const std::string& name);

enum class CommandType : std::uint8_t {
    Play, Stop, TogglePlay, SelectElement, SetTempo, SetSplit,
    SetMemory, SetSyncStart, SetAutoFill, SetTrackMute, SetChordScan,
    Midi, Panic, SetChordRecognition, SetChordScanArea, SetSplitEnabled,
    SetBassInversion, SetDamperLatch, ApplyChordControls, SetTempoLock, SetSamplePlaybackMode,
    SetChordScanZone, ToggleTempoLock, ToggleMemory, ToggleAutoFill, ToggleSyncStart,
    ToggleChordSplit, ToggleBassInversion, ToggleDamperLatch, SetAutoFillMode,
    ResetPosition, StartWithTempo, SetSyncStop, ToggleSyncStop, SetSyncStartAutoOff,
    ToggleSectionLoop, Fade, SetFadeTimes, CycleAutoFillMode, ToggleSyncStartAutoOff, AdjustFadeTimes,
    SetKeyboardSplit, ToggleChordScanAreaBit, ApplyKeyboardRecall
};
struct Command {
    CommandType type{CommandType::Stop};
    int player{0};
    int index{0}; // element / track / MIDI status
    // ApplyKeyboardRecall: bit0 split enabled, bit1 scan present,
    // bits2..3 scan area, bit4 bass inversion present, bit5 bass inversion on.
    // Absent optional values must have zero value bits; data2 is the positive
    // 31-bit recall serial, acknowledged after the controls are published.
    double value{0}; // bpm / split / bool / MIDI data1
    int data2{0};
    const Style* sourceStyle{nullptr}; // scoped control changes must match this immutable graph
};
struct PlayerSnapshot {
    // Borrowed on the single control/loading thread, valid until its next
    // installStyle/stageStyle call. Retain a separate Style owner to keep it.
    const Style* style{nullptr};
    const Style* pendingStyle{nullptr};
    const void* styleCommitToken{nullptr};
    const void* pendingStyleCommitToken{nullptr};
    bool playing{false}, syncStart{false}, syncStop{false}, autoFill{true};
    Element loopElement{Element::Count};
    int fadeDirection{0}; // -1 out, 0 inactive, 1 in
    float fadeGain{1.0F};
    Element element{Element::Var1}, queued{Element::Count};
    Element returnVariation{Element::Var1};
    double tempoBpm{120};
    std::uint32_t bar{1}, beat{1};
    std::uint64_t transportMeasure{0}; // musical boundaries; never resets on a pattern loop
    std::uint8_t numerator{4}, denominator{4};
    std::uint8_t muteMask{0};
    std::uint8_t blockedTrackMask{0};
    std::array<int,kTracks> selectedCvs{}; // one-based; zero is unavailable
    std::array<std::uint32_t,kTracks> cvTicks{};
    Chord chord;
};

struct RenderCallbacks {
    virtual ~RenderCallbacks() = default;
    // A local mixer can keep musical time and held keys while its output is muted.
    virtual bool rendersTrackMutes() const noexcept {return false;}
    virtual void liveEvent(const LiveEvent&) noexcept {}
    // Audio thread context. Default no-ops preserve other MIDI/render clients.
    virtual void sourceStyle(int player, const Style* style) noexcept { (void)player; (void)style; }
    // Brackets only a playing, staged Style handoff. Cleanup MIDI through the
    // finished hook releases old voices; new notes are emitted afterwards.
    virtual void styleChanging(int player, const Style* next) noexcept { (void)player; (void)next; }
    // Exactly at a prepared Style handoff, after old note releases and before
    // sourceStyle/new setup. The opaque token is retained by the control owner.
    virtual void styleCommitted(int player, const Style* style, const void* token) noexcept {
        (void)player; (void)style; (void)token;
    }
    // The prepared host may carry explicit saved/user overrides for the exact
    // committed graph. Read once after activation, before its first setup/note.
    virtual std::uint8_t committedStyleMuteMask(int player, const void* token,
            std::uint8_t fallback) noexcept { (void)player; (void)token; return fallback; }
    virtual Element committedStyleElement(int player,const void* token,bool playing,Element fallback) noexcept {
        (void)player;(void)token;(void)playing;return fallback;
    }
    virtual bool committedStyleAutoFill(int player,const void* token,bool fallback) noexcept {
        (void)player;(void)token;return fallback;
    }
    // A synthetic playback baseline, separate from original setup/CV declarations.
    virtual void initializeStyleControllers(int player) noexcept {
        for(int track=0;track<kTracks;++track){
            midi(player,track,0xB0,7,127);
            midi(player,track,0xB0,10,64);
            midi(player,track,0xB0,11,127);
        }
    }
    virtual void styleChangeFinished(int player) noexcept { (void)player; }
    virtual void patternStart(int player, int track) noexcept { (void)player; (void)track; }
    virtual void transportGain(int player,float first,float last) noexcept { (void)player;(void)first;(void)last; }
    // Actual musical tempo after any event at this subspan boundary. A Sound
    // LFO must follow its owning player's tempo, including native CV changes.
    virtual void sourceTempo(int player,double bpm,bool playing) noexcept { (void)player;(void)bpm;(void)playing; }
    virtual PhraseRange phraseRange(const void*,Element,int) const noexcept {return {};}
    virtual GuitarOverride guitarSettings(const void*,Element,int) const noexcept {return {};}
    virtual int manualFillMode(const void*,int) const noexcept {return 0;}
    // Audio thread: render all sound engines for precisely this subspan.
    virtual void render(std::uint32_t offset, std::uint32_t frames) noexcept = 0;
    // Audio thread: emit to the given player and logical track (0..7).
    // Original channel bits are preserved for setup/program routing. The host
    // still chooses its internal output channel for the logical Style track.
    virtual void midi(int player, int track, std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept = 0;
};

class ArrangerEngine {
public:
    ArrangerEngine() noexcept;
    ~ArrangerEngine();
    ArrangerEngine(const ArrangerEngine&) = delete;
    ArrangerEngine& operator=(const ArrangerEngine&) = delete;

    // Single control/loading thread. Validation is done before publication.
    // Active/pending Styles stay pinned until audio publishes their replacement.
    // Retired Style graphs are reclaimed only by the next control installation;
    // no resource is destroyed in process(). Stop audio before engine destruction.
    bool installStyle(int player, std::shared_ptr<const Style> style); // nullptr clears this player on the next block
    // Prebuilt live selection. The last request wins; when playing it commits
    // at the next bar of the old Style without stopping the transport.
    bool stageStyle(int player, std::shared_ptr<const Style> style,
                    bool samplePlaybackMode, const void* commitToken = nullptr);
    bool post(const Command& command) noexcept; // bounded multi-producer queue
    bool postMidi(int status, int data1, int data2) noexcept;
    bool postChordControls(int mode, int area, bool splitEnabled, bool bassInversion,
                           bool damperLatch, int splitNote, bool memory) noexcept;
    void process(std::uint32_t frames, double sampleRate, RenderCallbacks& callbacks) noexcept;
    PlayerSnapshot snapshot(int player) const noexcept;
    std::uint64_t droppedCommands() const noexcept { return dropped_.load(std::memory_order_relaxed); }
    int splitNote() const noexcept { return publishedSplit_.load(std::memory_order_relaxed); }
    bool memory() const noexcept { return publishedMemory_.load(std::memory_order_relaxed); }
    int recognitionMode() const noexcept { return publishedRecognitionMode_.load(std::memory_order_relaxed); }
    int chordScanArea() const noexcept { return publishedScanArea_.load(std::memory_order_relaxed); }
    bool splitEnabled() const noexcept { return publishedSplitEnabled_.load(std::memory_order_relaxed) != 0; }
    bool bassInversion() const noexcept { return publishedBassInversion_.load(std::memory_order_relaxed) != 0; }
    std::uint32_t keyboardRecallCommittedSerial() const noexcept { return publishedKeyboardRecallSerial_.load(std::memory_order_acquire); }
    bool damperLatch() const noexcept { return publishedDamperLatch_.load(std::memory_order_relaxed) != 0; }
    bool tempoLock() const noexcept { return publishedTempoLock_.load(std::memory_order_relaxed) != 0; }
    int autoFillMode() const noexcept { return publishedAutoFillMode_.load(std::memory_order_relaxed); } // Current=0, Target=1
    bool syncStartAutoOff() const noexcept { return publishedSyncStartAutoOff_.load(std::memory_order_relaxed); }
    float fadeInSeconds() const noexcept { return publishedFadeInSeconds_.load(std::memory_order_relaxed); }
    float fadeOutSeconds() const noexcept { return publishedFadeOutSeconds_.load(std::memory_order_relaxed); }

private:
    static constexpr std::size_t kQueueSize = 1024;
    struct QueueSlot { std::atomic<std::size_t> sequence{0}; Command command; };
    std::array<QueueSlot, kQueueSize> queue_;
    alignas(64) std::atomic<std::size_t> enqueue_{0};
    alignas(64) std::atomic<std::size_t> dequeue_{0};
    std::atomic<std::uint64_t> dropped_{0};
    std::atomic<bool> panicPending_{false};
    std::atomic<unsigned> inputResetMask_{0};
    bool pop(Command& command) noexcept;

    struct StyleInstallation {
        const Style* style{nullptr};
        const void* commitToken{nullptr};
        bool samplePlaybackMode{false}, quantized{false};
        std::shared_ptr<const Style> owner; // control thread only
        mutable std::atomic<bool> retired{false};
    };
    struct Player {
        const Style* style{nullptr};
        const StyleInstallation* styleInstallation{nullptr};
        const StyleInstallation* pendingStyle{nullptr};
        const void* styleCommitToken{nullptr};
        double styleSwitchTicksRemaining{0};
        bool playing{false}, syncStart{false}, syncStop{false}, syncStopReady{false}, autoFill{true};
        Element loopElement{Element::Count};
        Element lastElementPress{Element::Count};
        int fadeDirection{0};
        double fadeGain{1.0};
        bool samplePlaybackMode{false}; // explicit simplified sample audition, never Korg NTT parity
        Element element{Element::Var1}, queued{Element::Count}, returnTo{Element::Var1};
        double tempo{120}, tick{0};
        std::uint64_t transportMeasure{0};
        std::size_t eventIndex{0};
        struct PatternCursor { int cv{-1}; double tick{0}; std::size_t eventIndex{0}, tempoIndex{0}; };
        std::array<PatternCursor,kTracks> cursors;
        std::array<std::uint8_t,kTracks> styleDamper{};
        std::uint8_t blockedTrackMask{0};
        std::uint8_t muteMask{0};
        std::array<std::array<std::uint16_t,128>,kTracks> active{};
        std::array<std::array<std::uint8_t,128>,kTracks> velocities{};
        // Several source notes can transpose onto the same MIDI output key.
        std::array<std::array<std::uint8_t,128>,kTracks> outputOwners{};
        struct GuitarString {
            int pitch{-1}, sourceKey{-1};
            double ageMs{0}, releaseMs{-1};
            bool damp{false};
            int pendingPitch{-1}, pendingSource{-1};
            std::uint8_t pendingVelocity{0};
            double attackMs{-1}, pendingGateMs{-1};
            bool pendingDamp{false};
        };
        struct GuitarRuntime {
            bool configured{false}, enabled{false}, alternatingUp{false};
            GuitarPatternSettings settings;
            GuitarShape shape;
            GuitarVoicing voicing;
            Chord voicingChord;
            Chord progression;
            int voicingCapo{-1}, voicingPosition{-1};
            std::uint32_t randomState{0x6D2B79F5U};
            std::array<GuitarString,6> strings;
        };
        std::array<GuitarRuntime,kTracks> guitars;
    };
    struct Published {
        std::atomic<std::uint64_t> revision{0};
        std::atomic<const Style*> style{nullptr};
        std::atomic<const Style*> pendingStyle{nullptr};
        std::atomic<const void*> styleCommitToken{nullptr}, pendingStyleCommitToken{nullptr};
        std::atomic<int> playing{0}, syncStart{0}, syncStop{0}, autoFill{1}, element{3}, queued{15}, loopElement{15},fadeDirection{0};
        std::atomic<int> returnVariation{3};
        std::atomic<float> fadeGain{1.0F};
        std::atomic<double> tempo{120};
        std::atomic<std::uint32_t> bar{1}, beat{1};
        std::atomic<std::uint64_t> transportMeasure{0};
        std::atomic<int> numerator{4}, denominator{4}, muteMask{0};
        std::atomic<int> blockedTrackMask{0};
        std::array<std::atomic<int>,kTracks> selectedCvs{};
        std::array<std::atomic<std::uint32_t>,kTracks> cvTicks{};
        std::atomic<int> chordRoot{0}, chordType{static_cast<int>(ChordType::None)}, chordBass{0};
    };
    std::array<Player,kPlayers> players_;
    std::array<Published,kPlayers> published_;
    std::array<std::atomic<const StyleInstallation*>,kPlayers> pending_{};
    // Tiny installation records have stable addresses for this session; their
    // heavy Style ownership is released after off-audio retirement acknowledgement.
    std::vector<std::unique_ptr<StyleInstallation>> retainedInstallations_; // control thread only
    std::array<std::array<std::uint8_t,128>,16> held_{};
    Chord chord_,lastDetected_;
    detail::ChordTransition transition_;
    detail::KeyMask latchAttacks_{};
    std::array<std::uint32_t,4> scannedNotes_{};
    int split_{60};
    bool memory_{true}, splitEnabled_{true}, bassInversion_{false}, damperLatch_{false};
    std::uint32_t lastKeyboardRecallSerial_{0}; // audio-owned; acknowledged with published controls
    int scanArea_{1}, previousScanArea_{1}; // Off, Lower, Upper, full keyboard
    ChordRecognitionMode recognitionMode_{ChordRecognitionMode::FingeredOneNote};
    std::array<bool,16> damperDown_{};
    bool chordLatched_{false};
    bool pitchedGateClosed_{false};
    bool chordKeysDown_{false};
    bool tempoLock_{false};
    bool autoFill_{true}; // global preference, independent of the selected Style/Player
    bool syncStartAutoOff_{true};
    float fadeInSeconds_{5.0F},fadeOutSeconds_{5.0F}; // explicit SILVETON durations, adjustable by the user
    int autoFillMode_{1}; // Smart requires a verified transition table
    double lockedTempo_{120};
    std::atomic<int> publishedTempoLock_{0};
    std::atomic<int> publishedAutoFillMode_{1};
    std::atomic<bool> publishedSyncStartAutoOff_{true};
    std::atomic<float> publishedFadeInSeconds_{5.0F},publishedFadeOutSeconds_{5.0F};
    std::atomic<int> publishedRecognitionMode_{2}, publishedScanArea_{1};
    std::atomic<int> publishedSplitEnabled_{1}, publishedBassInversion_{0}, publishedDamperLatch_{0};
    std::atomic<int> publishedSplit_{60}, publishedMemory_{1}, publishedChordRoot_{0}, publishedChordType_{static_cast<int>(ChordType::None)}, publishedBass_{0};
    std::atomic<std::uint32_t> publishedKeyboardRecallSerial_{0};
    void handle(const Command&, RenderCallbacks&) noexcept;
    bool scansKey(int key) const noexcept;
    void observeMidi(int status, int data1, int data2, RenderCallbacks&, bool=false) noexcept;
    void phraseNote(int player, int track, int sourceKey, int outputKey,
                    std::uint8_t attack, std::uint8_t release, RenderCallbacks&) noexcept;
    enum class ScanReason { Control, Attack, Release, Recovery };
    void refreshChord(RenderCallbacks&,ScanReason reason=ScanReason::Control) noexcept;
    void applyChord(Chord chord, RenderCallbacks&) noexcept;
    bool anyDamperDown() const noexcept;
    void normalizeChordControls() noexcept;
    void setTempo(int player,double bpm) noexcept;
    bool publishStyleInstallation(int player,std::shared_ptr<const Style> style,
                                 bool samplePlaybackMode,const void* token,bool quantized);
    void reclaimRetiredStyleOwners(); // single control/loading thread
    void commitStyle(int player,const StyleInstallation&,bool keepPlaying,RenderCallbacks&) noexcept;
    void commitStoppedSelection(int player,RenderCallbacks&) noexcept;
    int chosenCv(const TrackPattern&,int previous) const noexcept;
    int nativeNote(const TrackPattern&,const ChordVariation&,int key,Chord chord,TrackRole role,bool samplePlaybackMode,PhraseRange range,bool guitarMode=false) const noexcept;
    void configureGuitar(int player,int track,const TrackPattern&,const ChordVariation*,RenderCallbacks&) noexcept;
    void restoreGuitarShape(int player,int track,const TrackPattern&,const ChordVariation*,std::size_t before) noexcept;
    void releaseGuitarString(int player,int track,std::size_t string,RenderCallbacks&,bool damp=false) noexcept;
    void releaseGuitarVoices(int player,int track,RenderCallbacks&,bool damp=false) noexcept;
    void guitarEvent(int player,int track,const TrackPattern&,const ChordVariation&,const MidiEvent&,RenderCallbacks&) noexcept;
    Chord guitarChord(const Player&,int track,const ChordVariation&) const noexcept;
    void drainGuitarEvents(int player,int track,RenderCallbacks&) noexcept;
    double nextGuitarEventMs(const Player&) const noexcept;
    void advanceGuitarEvents(Player&,double elapsedMs) noexcept;
    void selectPatternCvs(int player,RenderCallbacks&,bool reset) noexcept;
    void sendStyleMessage(int player,int track,const MidiEvent& event,RenderCallbacks&) noexcept;
    void emitNative(int player,int track,const MidiEvent&,RenderCallbacks&) noexcept;
    void drainPatternEvents(int player,RenderCallbacks&) noexcept;
    double patternBoundary(const Player&) const noexcept;
    void publish() noexcept;
    void silence(int player, RenderCallbacks&, int track = -1, bool immediate = false) noexcept;
    void begin(int player, Element, RenderCallbacks&) noexcept;
    void beginAt(int player, Element, double tick, RenderCallbacks&) noexcept;
    void boundary(int player, RenderCallbacks&) noexcept;
    void emit(int player, const MidiEvent&, RenderCallbacks&) noexcept;
    const Section* section(const Player&) const noexcept;
};
} // namespace silveton::arranger
