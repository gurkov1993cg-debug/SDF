#pragma once
#include "silveton/arranger/Pa5xStyleRead.h"
#include <functional>

namespace silveton::arranger {
bool paStyleBankPath(const std::string& path);
bool paStyleSlot(const std::string& path, std::string* bank = nullptr, int* slot = nullptr);
bool paPerformanceBankPath(const std::string& path);
bool paKeyboardLocation(const std::string& path,std::string* physical=nullptr);
using PaKeyboardVisitor=std::function<bool(int,const Pa5xPerformanceInspection&)>;
bool inspectPaPadBank(const std::string& path,const std::function<bool(const std::string&,bool)>& visit,std::string& error);
bool inspectPaPerformanceBank(const std::string& path,const PaKeyboardVisitor& visit,std::string& error);
Pa5xPerformanceInspection readPaKeyboardLocation(const std::string& path);
using PaStyleVisitor = std::function<bool(int slot, const std::string& name, const Pa5xStyleRead&)>;
bool inspectPaStyleBank(const std::string& path, const PaStyleVisitor& visit, std::string& error);
Pa5xStyleRead readPaStyleSlot(const std::string& path, const Pa5xSetBank* sounds);
}
