#pragma once
#include <array>
#include <cstdint>

namespace silveton::arranger::detail {
using KeyMask = std::array<std::uint32_t,4>;

// Note On is always recognized immediately. Recent attacks distinguish the
// old fingers of a legato change from a staggered lift of the new chord.
class ChordTransition {
public:
    constexpr void advance(double milliseconds) noexcept {
        ageMs_+=milliseconds;
        if(ageMs_>=releaseWindowMs)clear();
    }
    constexpr void clear() noexcept {
        older_={};ageMs_=releaseWindowMs;overlapping_=false;
    }
    constexpr void attack(const KeyMask& before,int key,bool previousChord) noexcept {
        if(ageMs_>=attackGroupMs || !(before[0]|before[1]|before[2]|before[3])){
            older_=before;
            overlapping_=previousChord && (before[0]|before[1]|before[2]|before[3]);
        }
        older_[static_cast<unsigned>(key)/32]&=~(1U<<(key%32));
        ageMs_=0;
    }
    constexpr void release(int key) noexcept {
        if(!(older_[static_cast<unsigned>(key)/32]&(1U<<(key%32))))overlapping_=false;
    }
    constexpr bool resolving() const noexcept {return overlapping_;}
private:
    static constexpr double attackGroupMs=45.0,releaseWindowMs=100.0;
    KeyMask older_{};
    double ageMs_{releaseWindowMs};
    bool overlapping_{false};
};
}
