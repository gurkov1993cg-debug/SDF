#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace silveton::arranger {

class Pa5xKstMetadataCache;

enum class KstResourceKind : std::uint8_t {
    Style, Sound, Multisample, Sample, KeyboardSet, Pad, SongBook, Other, Count
};
const char* kstResourceKindName(KstResourceKind kind) noexcept;

struct KstResourceEntry {
    KstResourceKind kind{KstResourceKind::Other};
    std::string relativePath;
    std::uint64_t sizeBytes{0};
    bool readable{false};
    bool indexed{false};
};

enum class KstResolution : std::uint8_t {
    ExactUserSound, MissingUserSound, FactorySoundRequired,
    AmbiguousSound, UnsupportedSoundAddress
};
struct KstSoundReference {
    KstResourceKind resourceKind{KstResourceKind::Style};
    // Retained field name for existing UI/API consumers; this is the source
    // resource path for Styles, Keyboard Sets and Pads alike.
    std::string stylePath;
    std::string element;
    std::string track;
    int msb{-1}, lsb{-1}, program{-1};
    KstResolution resolution{KstResolution::UnsupportedSoundAddress};
    std::string soundPath;
    std::string soundName;
};

enum class KstSeverity : std::uint8_t { Info, Warning, Blocking };
struct KstDiagnostic {
    KstSeverity severity{KstSeverity::Info};
    std::string code;
    std::string relativePath;
    std::string message;
};
struct KstProgress {
    std::uint64_t done{0}, total{0};
    std::string phase;
    std::string relativePath;
};

struct Pa5xKstIndex {
    std::string rootPath;
    std::string name;
    bool recognized{false};
    bool structurallyValid{false};
    bool playable{false};
    bool cancelled{false};
    // Discovery-only mode leaves PCM/KMP payload inspection to the shared
    // bank loader. Their resource entries remain discovered but not indexed.
    bool sampleResourcesDeferred{false};
    std::uint64_t totalBytes{0};
    std::array<std::uint64_t, static_cast<std::size_t>(KstResourceKind::Count)> counts{};
    std::vector<KstResourceEntry> resources;
    std::vector<KstSoundReference> soundReferences;
    std::vector<KstDiagnostic> diagnostics;
    std::uint64_t indexedSounds{0}, indexedMultisamples{0}, indexedSamples{0};
    std::uint64_t indexedKeyboardSets{0}, indexedPads{0};
    std::uint64_t resolvedUserReferences{0}, missingUserReferences{0}, factoryReferences{0};
    // Transient, bounded metadata reuse for one load operation. Never archived
    // and never shared between separate explicit Load requests. The worker
    // releases it after constructing the bank and resource catalog.
    std::shared_ptr<Pa5xKstMetadataCache> metadataReadCache;
};

// Fast selection check: an explicit .KST directory, or a resource-root folder
// containing real canonical STYLE+SOUND or KEYBOARDSET+SOUND directories.
// It does not recursively search arbitrary parent folders or infer playability.
bool canSelectPa5xKstDirectory(const std::string& directory);

// Control/worker thread only. The current performance is never changed by
// indexing. A structural index is not an authorization to play undecoded data.
Pa5xKstIndex indexPa5xKst(const std::string& directory,
    const std::function<void(const KstProgress&)>& progress = {},
    const std::atomic<bool>* cancel = nullptr,
    bool deferSampleResources = false);
std::string pa5xKstSummary(const Pa5xKstIndex& index);

} // namespace silveton::arranger
