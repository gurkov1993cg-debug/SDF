#pragma once

#include "silveton/arranger/Pa5xKstIndex.h"
#include "silveton/arranger/Pa5xProgramImport.h"
#include "silveton/arranger/Pa5xMultisampleImport.h"
#include "silveton/arranger/Pa5xDrumKit.h"
#include <memory>

namespace silveton::arranger {

struct Pa5xSetBankIssue {
    std::string code, path, message;
    std::uint64_t resourceId{0};
};
struct Pa5xSetBankSound {
    std::string path;
    Pa5xPcgSound descriptor;
    Pa5xSoundReferenceGraph graph;
    Pa5xDrumKitInspection drumKit;
};
struct Pa5xSetBankStatus {
    std::string rootPath;
    bool recognized{false}, indexed{false}, cancelled{false};
    bool soundDirectoryComplete{false};
    std::size_t pcmFiles{0}, pcmSamples{0}, kmpFiles{0}, sounds{0};
    std::uint64_t pcmFileBytes{0};
    bool samplePreparationComplete{false};
    std::size_t samplesAttempted{0}, samplesReady{0}, samplesFailed{0}, samplesUnlinked{0}, samplesRamFallbacks{0};
    std::size_t pcmSourceFilesRead{0}, pcmMetadataCacheHits{0}, samplesDiskCacheHits{0}, samplesDecoded{0};
    std::vector<Pa5xSetBankIssue> samplePreparationIssues;
    // This bank indexes the actual files; DSP/program readiness is a separate
    // strict import result. It never reports indexing as a playable full SET.
    std::vector<Pa5xSetBankIssue> issues;
};

// One actual PCM resource file, not one sample recording or one Sound. Counts
// below describe recording objects inside this file; the existing bank totals
// still count unique attempted sample UIDs. Completion means the pass finished,
// not that all recordings succeeded. Old snapshots may supply only an indexed
// inventory with preparationComplete=false; callers must not label it loaded.
struct Pa5xPcmFileStatus {
    std::string path;
    bool indexed{false}, preparationComplete{false};
    bool sourceRead{false}, metadataCacheHit{false}, restored{false};
    std::size_t samples{0}, attempted{0}, ready{0}, failed{0}, unlinked{0};
    std::string error;
};

// A Sound address is metadata, independent of whether its waveform and DSP can
// already play. A broken/missing PCM must not erase a valid PCG Sound name.
struct Pa5xSoundAddressRead {
    bool addressComplete{false};
    int msb{-1}, lsb{-1}, program{-1};
    KstResolution resolution{KstResolution::UnsupportedSoundAddress};
    Pa5xPcgSoundKind soundKind{Pa5xPcgSoundKind::Unknown};
    std::string name, path, message;
    bool graphDecoded{false}, parametersDecoded{false}, audioDataAvailable{false};
};

// Basic User-sample playback, explicitly separate from original PCG DSP.
// Reverse and boost are applied by the caller's zone, not baked into audio.
struct Pa5xSampleImport {
    silveton::sampler::SamplePtr sample;
    float gainDb{0.0F};
    bool reverse{false}, usesDerivedMetadata{false}, ramFallback{false};
    bool diskCacheHit{false}, decodedFromSource{false}, sourceFileRead{false};
    std::vector<std::string> warnings;
    std::string error;
    explicit operator bool() const noexcept { return sample != nullptr && sample->valid(); }
};

// Loading/control thread only. Keeps resource indexes and original Sound
// addresses, while audio bytes are read on demand. A multi-gigabyte SET does
// not allocate a decoded float buffer for every recording at startup.
class Pa5xSetBank {
public:
    Pa5xSetBank();
    ~Pa5xSetBank();
    Pa5xSetBank(const Pa5xSetBank&) = delete;
    Pa5xSetBank& operator=(const Pa5xSetBank&) = delete;
    bool load(const std::string& root,
              const std::function<void(const KstProgress&)>& progress = {},
              const std::atomic<bool>* cancel = nullptr);
    bool load(const Pa5xKstIndex& index,
              const std::function<void(const KstProgress&)>& progress = {},
              const std::atomic<bool>* cancel = nullptr);
    // Read-only Sound-name/address directory. Does not scan/decode PCM or
    // publish an audio-ready bank; valid PCG names survive unrelated PCM errors.
    bool loadSoundDirectory(const Pa5xKstIndex& index,
              const std::function<void(const KstProgress&)>& progress = {},
              const std::atomic<bool>* cancel = nullptr);
    bool loadForSamplePlayback(const Pa5xKstIndex& index,
              const std::function<void(const KstProgress&)>& progress = {},
              const std::atomic<bool>* cancel = nullptr,
              const Pa5xMultisampleBuildOptions* sampleOptions = nullptr,
              Pa5xMultisampleCache* sampleCache = nullptr);
    // Private, versioned metadata snapshot. Restoring does not read original
    // PCG/KMP/PCM resources or rebuild Programs; the caller restores the
    // corresponding prepared Programs separately before publishing this bank.
    bool saveSnapshot(const std::string& path) const;
    bool loadSnapshot(const std::string& path, const std::string& expectedRoot);
    Pa5xSetBankStatus status() const;
    const std::vector<Pa5xPcmFileStatus>& pcmFileStatuses() const noexcept;
    const std::vector<Pa5xSetBankSound>& sounds() const noexcept;
    // Same-load catalog reuse. Returns false when this file was not inspected
    // here or its device/inode/size/mtime/ctime revision no longer matches.
    // A true result can contain an explicit original parse error and no rows.
    bool soundMetadataForPath(const std::string& path,
        std::vector<const Pa5xSetBankSound*>& sounds,std::string& error) const;
    const Pa5xSetBankSound* findSound(int msb, int lsb, int program) const noexcept;
    const Pa5xSetBankSound* findSampleSound(int msb, int lsb, int program) const noexcept;
    Pa5xSoundAddressRead resolveSoundAddress(int msb, int lsb, int program) const;
    Pa5xProgramCandidate inspectSound(int msb, int lsb, int program) const;
    Pa5xDrumKitSampleLinks inspectDrumKit(int msb, int lsb, int program) const;
    Pa5xDrumKitSampleLinks sampleDrumKitLinks(int msb, int lsb, int program) const;
    Pa5xSampleAudio decodeSample(std::uint64_t resourceId,
        std::size_t maximumFrames = 16U * 1024U * 1024U) const;
    std::vector<Pa5xPcmInventory> pcmInventories() const;
    std::vector<Pa5xPcmInventory> sampleResourceInventories() const;
    const Pa5xSampleIndex* multisampleIndex(std::uint64_t multisampleId) const noexcept;
    Pa5xMultisampleImport buildMultisample(std::uint64_t multisampleId,
        const Pa5xMultisampleBuildOptions& options = {},
        Pa5xMultisampleCache* cache = nullptr) const;
    // Missing User resources leave silent zones instead of rejecting every
    // available sample. These methods do not reconstruct original Sound DSP.
    Pa5xSampleImport buildSample(std::uint64_t resourceId,
        const Pa5xMultisampleBuildOptions& options = {},
        Pa5xMultisampleCache* cache = nullptr) const;
    Pa5xMultisampleImport buildSampleMultisample(std::uint64_t multisampleId,
        const Pa5xMultisampleBuildOptions& options = {},
        Pa5xMultisampleCache* cache = nullptr) const;
private:
    bool loadResources(const Pa5xKstIndex& index,
        const std::function<void(const KstProgress&)>& progress,
        const std::atomic<bool>* cancel, bool allowPartial,
        const Pa5xMultisampleBuildOptions* sampleOptions = nullptr,
        Pa5xMultisampleCache* sampleCache = nullptr);
    struct Impl;
    Pa5xSampleImport buildSampleFrom(const Impl& bank, std::uint64_t resourceId,
        const Pa5xMultisampleBuildOptions& options, Pa5xMultisampleCache* cache) const;
    std::unique_ptr<Impl> impl_;
};
} // namespace silveton::arranger
