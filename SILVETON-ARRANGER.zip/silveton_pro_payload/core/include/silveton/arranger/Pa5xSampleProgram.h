#pragma once

#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/sampler/SamplerTypes.h"
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {

// A normal Pa Sound can contain 24 OSC, each with separate High/Low
// recordings. The admission limit counts sample branches, not active voices.
inline constexpr std::size_t kMaxPaSampleLayers=48U;
inline bool paSampleProgramLayerCountSupported(const sampler::Program& program) noexcept {
    if(program.layers.size()<=static_cast<std::size_t>(sampler::kMaxProgramLayers))return true;
    return program.layers.size()<=kMaxPaSampleLayers&&program.sourceVoiceAssignment.present&&
        program.sourceVoiceAssignment.valid();
}

// Audible playback of the User recordings present in this bank. Missing/ROM
// sources remain silent; a present exact UID is never replaced by another one.
// Static zero-sustain Amp EG segments use approximate timing; complete Korg DSP is unavailable.
struct Pa5xSampleProgramImport {
    bool found{false}, ready{false}, partial{false}, originalDspApplied{false};
    int msb{-1}, lsb{-1}, programNumber{-1};
    std::string name;
    silveton::sampler::ProgramPtr program;
    std::size_t sourceCount{0}, loadedSources{0}, skippedRomSources{0};
    std::size_t missingSources{0}, decodedSampleCount{0};
    std::vector<std::string> warnings;
    explicit operator bool() const noexcept { return ready&&program!=nullptr; }
};

Pa5xSampleProgramImport buildPa5xSampleProgram(
    const Pa5xSetBank& bank,int msb,int lsb,int program,
    const Pa5xMultisampleBuildOptions& options = {},
    Pa5xMultisampleCache* cache = nullptr,
    bool legacySampleOnly = true);

// Compatibility identity only, on the control thread. Reconstruct the exact
// 0.1.69 sampled-control projection of an original imported normal Sound.
// Never publish this as playback state. A caller must also gate the older
// saved-file version and compare its complete existing fingerprint exactly.
// Missing provenance/old decay evidence returns an empty pointer.
silveton::sampler::ProgramPtr projectPa5xSampleProgramLegacy69(
    const silveton::sampler::ProgramPtr& source);

// Identity-only projection for pre-velocity-zone SVOD schema1 imports.
// Caller must allow only older saved records and compare the full fingerprint.
silveton::sampler::ProgramPtr projectPa5xSampleProgramLegacyOscillator1(
    const silveton::sampler::ProgramPtr& source);

struct Pa5xSampleWarmStatus {
    std::size_t entries{0},warmedEntries{0},warmedBytes{0},touchedPages{0};
    std::size_t failedEntries{0},budgetSkippedEntries{0};
};

struct Pa5xSampleWarmTotals {
    std::uint64_t batches{0},entries{0},warmedEntries{0},warmedBytes{0},touchedPages{0};
    std::uint64_t failedEntries{0},budgetSkippedEntries{0},cancelledBatches{0};
};

// Process lifetime only; warmedBytes counts successful requested ranges while
// touchedPages counts actual prefault page reads, not permanently resident RAM.
Pa5xSampleWarmTotals pa5xSampleWarmTotals() noexcept;

// Control/background preparation only: make the first streamed range of the
// selected Programs resident before publishing them. This is not a SET-wide
// preload or a promise that the OS will retain these pages indefinitely.
// Duplicate stream entries share an OS-page-rounded batch budget; reverse
// entries warm the tail. Successful byte counters retain logical range sizes.
Pa5xSampleWarmStatus warmPa5xSamplePrograms(
    const std::vector<silveton::sampler::ProgramPtr>& programs,
    std::size_t maximumBytes=16U*1024U*1024U,
    const std::atomic<bool>* cancel=nullptr);

} // namespace silveton::arranger
