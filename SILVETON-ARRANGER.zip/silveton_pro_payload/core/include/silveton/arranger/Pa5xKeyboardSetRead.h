#pragma once
#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/sampler/SourcePerformanceControls.h"
#include <array>
#include <string>
#include <vector>

namespace silveton::arranger {
class Pa5xSetBank;
enum class Pa5xKeyboardSetSoundStatus {
    Unknown, ExactUserSound, FactorySoundRequired, MissingUserSound,
    AmbiguousSound, IncompleteAddress, InvalidSetup, BankUnavailable, UnsupportedSoundAddress
};
const char* pa5xKeyboardSetSoundStatusName(Pa5xKeyboardSetSoundStatus status) noexcept;
struct Pa5xKeyboardSetPartRead {
    int role{0}; //1Lower,2Upper1,3Upper2,4Upper3; never a sampler slot
    std::string name, resourcePath;
    bool present{false}, recallSetupValid{false}, addressKnown{false};
    int channel{-1}, msb{-1}, lsb{-1}, program{-1};
    std::uint32_t setupLastTick{0};
    std::string soundName, soundPath, soundMessage;
    Pa5xKeyboardSetSoundStatus status{Pa5xKeyboardSetSoundStatus::Unknown};
    int mute{-1}, keyLow{-1}, keyHigh{-1}, velocityLow{-1}, velocityHigh{-1};
    int volumeRaw{-1}, panRaw{-1}, expressionRaw{-1};
    // Explicit supported RPN 0/1/2 declarations; -1 remains absent/unknown.
    // Bend is integer semitones (0..12, explicitly zero cents); fine is the
    // complete 14-bit MIDI value; coarse is the MIDI MSB (64 = no offset).
    int pitchBendRangeSemitones{-1}, fineTuneRaw{-1}, coarseTuneRaw{-1};
    sampler::SourceSoundEdits sourceSoundEdits{};
    // Original Pa5X CC91/93/94: three separate MFX send slots, not algorithm IDs.
    std::array<int,3> masterFxSendRaw{{-1,-1,-1}};
    std::vector<KorgMidiOpaqueEvent> opaqueMidiEvents;
    bool octaveTransposeKnown{false};
    int octaveTranspose{0}; // saved common Upper octave; Lower unaffected
    bool partTranspositionDeclared{false};
    int partTranspositionRaw{0}; // no inferred units for uncalibrated XML Pitch
    std::vector<std::string> issues;
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
    // Legacy PRF/STS cents and octaves retain their native units. They must
    // never be confused with XML Pitch or quantized into synthetic RPN data.
    std::shared_ptr<const PaSeriesTrackSettings> sourceNativeTrack;
};
struct Pa5xKeyboardSetRead {
    bool recognized{false}, valid{false}, readComplete{false};
    bool soundActivationSupported{false};
    std::string sourcePath, name, error;
    int splitPoint{-1}, useGlobalSplit{-1};
    bool upperOctaveTransposeKnown{false};
    int upperOctaveTranspose{0}, lowerUseRaw{-1}, bassInversionRaw{-1};
    std::array<Pa5xKeyboardSetPartRead,4> parts{};
    // Exact complement resource retained for decoding; never replayed as DSP commands.
    Pa5xPerformanceComplement complement;
    std::vector<std::string> issues;
    std::shared_ptr<const KorgSourceEffects> sourceEffects;
};
// Reads the complete note-free recall setup, including nonzero setup ticks.
// Different committed addresses or multiple MIDI channels are not guessed.
// Sound names resolve through the SET bank's exact original address catalogue.
Pa5xKeyboardSetRead readPa5xKeyboardSet(const std::string& path,
                                      const Pa5xSetBank* bank = nullptr);
Pa5xKeyboardSetRead readPa5xKeyboardSet(const Pa5xPerformanceInspection& inspection,
                                      const Pa5xSetBank* bank = nullptr);
Pa5xKeyboardSetRead readPa5xKeyboardSetBytes(const std::vector<std::uint8_t>& bytes,
                                           const std::string& sourcePath = {},
                                           const Pa5xSetBank* bank = nullptr);
} // namespace silveton::arranger
