#pragma once
#include "silveton/arranger/Pa5xSampleIndex.h"
#include "silveton/arranger/Pa5xSoundGraph.h"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::arranger {
struct Pa5xPcmInventory {
    std::string sourcePath;
    const Pa5xSampleIndex* index{nullptr}; // borrowed only during inspection
};
struct Pa5xProgramSampleDependency {
    std::uint64_t resourceId{0};
    std::size_t kmpSampleIndex{0};
    std::string name;
    bool pcmPresent{false}, ambiguous{false}, audioMetadataDecoded{false}, encrypted{false};
    std::uint8_t sampleFormat{0};
    std::string pcmSourcePath;
    std::size_t pcmObjectIndex{0};
};
struct Pa5xProgramMultisampleDependency {
    std::size_t oscillatorIndex{0};
    bool high{true}, resolved{false};
    std::uint64_t resourceId{0};
    std::string name;
    std::size_t kmpMultisampleIndex{0}, mappedKeys{0}, emptyKeys{0};
    std::vector<std::uint64_t> sampleIds;
};
struct Pa5xProgramCandidate {
    bool found{false}, referenceGraphDecoded{false};
    bool ramDependenciesComplete{false}, hasRomDependencies{false};
    bool allSampleHeadersDecoded{false};
    // This API inventories resources; it never invents envelopes or builds a
    // playable sampler Program from incompletely understood Korg DSP fields.
    bool programActivationSupported{false}, parametersDecoded{false};
    bool conservativeWholeMultisampleCoverage{true};
    int msb{-1}, lsb{-1}, program{-1};
    std::string name;
    Pa5xSoundReferenceGraph graph;
    std::vector<Pa5xProgramMultisampleDependency> multisamples;
    std::vector<Pa5xProgramSampleDependency> samples;
    std::size_t velocityDisabledSources{0};
    std::vector<std::string> blockers;
};
// Original Korg addresses only. No fixed SILVETON slot is allocated or inferred.
Pa5xProgramCandidate inspectPa5xProgramCandidate(
    const std::vector<std::uint8_t>& pcgBytes, const Pa5xPcgInspection& pcg,
    int msb, int lsb, int program, const Pa5xSampleIndex& kmp,
    const std::vector<Pa5xPcmInventory>& pcm);
// Dependency-only overload for an already validated descriptor/reference graph.
// Every mapped key of each declared RAM multisample is included conservatively:
// unresolved oscillator tuning/key-tracking must not hide a needed sample.
Pa5xProgramCandidate inspectPa5xProgramCandidate(
    const Pa5xPcgSound& sound, const Pa5xSoundReferenceGraph& graph,
    const Pa5xSampleIndex& kmp, const std::vector<Pa5xPcmInventory>& pcm);
} // namespace silveton::arranger
