#pragma once
#include "silveton/sampler/NumberedFxRuntime.h"
#include <memory>

namespace silveton::sampler {
NumberedFxSupport numberedCombinedFxSupport(std::uint16_t index) noexcept;
bool initializeNumberedCombinedFx(std::uint16_t index, NumberedFxState& state) noexcept;
bool numberedCombinedFxCanRender(const NumberedFxState& state) noexcept;

// Two documented processors, including their local mixes and routing, followed
// by the overall Wet/Dry. The caller owns the prepared, shared slot workspace.
class NumberedCombinedFx {
public:
    NumberedCombinedFx();
    ~NumberedCombinedFx();
    NumberedCombinedFx(const NumberedCombinedFx&) = delete;
    NumberedCombinedFx& operator=(const NumberedCombinedFx&) = delete;
    void prepare(double sampleRate, float* workspace, std::size_t samples);
    void reset() noexcept;
    void configure(const NumberedFxState&) noexcept;
    void process(float, float, float&, float&) noexcept;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
