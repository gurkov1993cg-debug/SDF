#pragma once

#include "silveton/sampler/NumberedFxKernel.h"
#include <array>

namespace silveton::sampler {

// Own stereo six-band EQ used by209/210: HP + four configurable bands + LP.
// The existing RBJ-form biquads and the following Butterworth cutoff design
// are SILVETON choices, not recovered Korg coefficients or packed SET data.
// Config.trim is a linear input gain. Wet/Dry and limiter output gain belong
// to the caller and are deliberately absent from this helper.
class NumberedSixBandEq {
public:
    enum class BandType { Peak, LowShelf, HighShelf };
    struct Band {
        BandType type{BandType::Peak};
        double hz{1000.0}, q{1.0}, gainDb{0.0};
    };
    struct Config {
        double trim{1.0};
        std::array<Band,4> bands{};
        // Hz0 is Thru. The caller translates its semantic Thru enum here.
        double highPassHz{0.0}, lowPassHz{0.0};
        // Own choices0..3:12/24/36/48dB/oct, i.e. orders2/4/6/8.
        int highPassSlope{0}, lowPassSlope{0};
    };

    void prepare(double sampleRate) noexcept {
        sampleRate_=numbered_fx::boundedRate(sampleRate);
        configure(Config{});
        reset();
    }

    void configure(const Config& config) noexcept {
        trim_=std::isfinite(config.trim)?std::clamp(config.trim,0.0,1.0):1.0;
        for(std::size_t band=0;band<4;++band){
            const auto& next=config.bands[band];
            const double hz=std::isfinite(next.hz)?std::clamp(next.hz,20.0,20000.0):1000.0;
            const double q=std::isfinite(next.q)?std::clamp(next.q,.1,50.0):1.0;
            const double gain=std::isfinite(next.gainDb)?std::clamp(next.gainDb,-60.0,60.0):0.0;
            const bool active=gain!=0.0;
            const auto type=next.type==BandType::LowShelf?Biquad::Type::LowShelf:
                next.type==BandType::HighShelf?Biquad::Type::HighShelf:Biquad::Type::Peak;
            for(std::size_t channel=0;channel<2;++channel){
                auto& filter=bands_[channel][band];
                if(active!=bandActive_[band]||next.type!=bandType_[band])filter.reset();
                if(active)filter.configure(type,sampleRate_,hz,q,gain);
                else filter.identity();
            }
            bandActive_[band]=active;bandType_[band]=next.type;
        }
        configureCut(highPass_,highPassStages_,config.highPassHz,config.highPassSlope,Biquad::Type::HighPass);
        configureCut(lowPass_,lowPassStages_,config.lowPassHz,config.lowPassSlope,Biquad::Type::LowPass);
    }

    void reset() noexcept {
        for(auto& channel:bands_)for(auto& filter:channel)filter.reset();
        for(auto& channel:highPass_)for(auto& filter:channel)filter.reset();
        for(auto& channel:lowPass_)for(auto& filter:channel)filter.reset();
    }

    // Fixed-size state only: no allocation, descriptor lookup, coefficient
    // construction, locks or I/O in this per-sample stereo operation.
    void process(float& left,float& right) noexcept {
        std::array<float,2> signal{{left,right}};
        for(std::size_t channel=0;channel<2;++channel){
            float value=static_cast<float>(numbered_fx::finite(signal[channel])*trim_);
            for(unsigned stage=0;stage<highPassStages_;++stage)value=highPass_[channel][stage].process(value);
            for(std::size_t band=0;band<4;++band)if(bandActive_[band])value=bands_[channel][band].process(value);
            for(unsigned stage=0;stage<lowPassStages_;++stage)value=lowPass_[channel][stage].process(value);
            signal[channel]=numbered_fx::finite(value);
        }
        left=signal[0];right=signal[1];
    }

private:
    using Biquad=numbered_fx::Biquad;
    using StereoCascade=std::array<std::array<Biquad,4>,2>;

    void configureCut(StereoCascade& filters,unsigned& previousStages,
                      double hz,int slope,Biquad::Type type) noexcept {
        const unsigned stages=std::isfinite(hz)&&hz>0?
            static_cast<unsigned>(std::clamp(slope,0,3)+1):0U;
        const bool changedOrder=stages!=previousStages;
        const double cutoff=stages?std::clamp(hz,20.0,std::min(20000.0,sampleRate_*.475)):20.0;
        for(unsigned stage=0;stage<4;++stage){
            // For an even Butterworth order N=2*stages the conjugate pole
            // pairs give Q_k=1/[2*cos((2k+1)*pi/(2N))], k=0..stages-1.
            // The lowest-Q section comes first to limit internal peaks. For
            // order4 the Qs are0.5411961 and1.3065630, not two Q=.707 stages.
            const double q=stage<stages?1.0/(2.0*std::cos(
                (2.0*stage+1.0)*numbered_fx::pi/(4.0*stages))):1.0;
            for(std::size_t channel=0;channel<2;++channel){
                auto& filter=filters[channel][stage];
                if(changedOrder||stage>=stages)filter.reset();
                if(stage<stages)filter.configure(type,sampleRate_,cutoff,q);
                else filter.identity();
            }
        }
        previousStages=stages;
    }

    double sampleRate_{48000.0},trim_{1.0};
    StereoCascade bands_{},highPass_{},lowPass_{};
    std::array<bool,4> bandActive_{};
    std::array<BandType,4> bandType_{};
    unsigned highPassStages_{0},lowPassStages_{0};
};

} // namespace silveton::sampler
