#pragma once

#include "silveton/sampler/NumberedFxRuntime.h"
#include <cstddef>
#include <memory>

namespace silveton::sampler {

// SILVETON implementations of the documented time/reverberation functions.
// The public numbers identify the functions, not proprietary DSP or a decoder
// for the original packed parameter bytes. See NUMBERED_TIME_FX_COVERAGE.json.
[[nodiscard]] NumberedFxSupport numberedTimeFxSupport(std::uint16_t index) noexcept;
bool initializeNumberedTimeFx(std::uint16_t index, NumberedFxState& state) noexcept;
[[nodiscard]] bool numberedTimeFxCanRender(const NumberedFxState& state) noexcept;

class NumberedTimeFx {
public:
    NumberedTimeFx();
    ~NumberedTimeFx();
    NumberedTimeFx(const NumberedTimeFx&) = delete;
    NumberedTimeFx& operator=(const NumberedTimeFx&) = delete;
    NumberedTimeFx(NumberedTimeFx&&) noexcept;
    NumberedTimeFx& operator=(NumberedTimeFx&&) noexcept;

    // Only prepare allocates the small control object. The caller owns the
    // full-rate workspace and keeps it alive until this processor is stopped.
    // Required reservation: ceil(sampleRate * 11.3) + 64 floats, shared by all
    // algorithm families of this slot; exactly one family may use it at a time.
    void prepare(double sampleRate, float* workspace, std::size_t samples);
    void reset() noexcept;
    // Serialized with process at a render-block boundary. No allocation,
    // locks, I/O, or history-sized clears. Manual Hold REC/RST are transitions.
    void configure(const NumberedFxState& state) noexcept;
    // Full internal Wet/Dry mixture, including the Auto Reverse direct mix.
    // The owner applies only the outer master return level, never a second mix.
    void process(float inL, float inR, float& outL, float& outR) noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton::sampler
