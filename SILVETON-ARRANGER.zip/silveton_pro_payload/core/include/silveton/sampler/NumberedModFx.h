#pragma once

#include "silveton/sampler/NumberedFxRuntime.h"
#include <cstddef>
#include <memory>

namespace silveton::sampler {

// Own signal-processing implementations for the documented modulation/pitch
// identities. No original packed FX parameters or manufacturer code are used.
[[nodiscard]] NumberedFxSupport numberedModFxSupport(std::uint16_t index) noexcept;
bool initializeNumberedModFx(std::uint16_t index, NumberedFxState& state) noexcept;
[[nodiscard]] bool numberedModFxCanRender(const NumberedFxState& state) noexcept;

class NumberedModFx {
public:
    NumberedModFx();
    ~NumberedModFx();
    NumberedModFx(const NumberedModFx&) = delete;
    NumberedModFx& operator=(const NumberedModFx&) = delete;
    NumberedModFx(NumberedModFx&&) noexcept;
    NumberedModFx& operator=(NumberedModFx&&) noexcept;

    // Control thread, stopped renderer. This is the only allocating method.
    // The caller retains one workspace of ceil(sampleRate*11.3)+64 floats
    // for a numbered slot. Other families can reuse it when this one is idle.
    void prepare(double sampleRate, float* workspace, std::size_t samples);
    void reset() noexcept;
    void configure(const NumberedFxState& state) noexcept;
    // configure -> real owning-part snapshot -> process, once per MIDI block.
    // Envelope34/37 and Scratch42 are the only current consumers.
    void setControlFrame(const NumberedFxControlFrame& frame) noexcept;
    // Complete internal Wet/Dry output. The caller must not mix dry twice.
    void process(float inL, float inR, float& outL, float& outR) noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton::sampler
