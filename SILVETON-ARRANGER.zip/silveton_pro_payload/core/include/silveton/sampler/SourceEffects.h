#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/NumberedFxRuntime.h"
#include "silveton/arranger/KorgSourceEffects.h"

namespace silveton::arranger {struct Pa5xSoundFxRecordRaw;}

namespace silveton::sampler {

// Source data and the playable translation are separate. Retaining an original
// selector/parameter block never means the proprietary Korg DSP is implemented.
enum class SourceFxStatus : std::uint8_t { Off, Applied, Unsupported };
struct SourceFxSlotStatus {
    bool master{true};
    // For Sound records, slot is the original record ordinal, not an IFX/MFX
    // assignment. This provenance survives parameter-only inspection.
    bool soundRecord{false};
    bool selectorKnown{true};
    int part{-1}, slot{-1}, ownerRaw{-1};
    std::uint16_t selector{0};
    SourceFxStatus status{SourceFxStatus::Unsupported};
    std::string name, functionBg, detail;
    // Derived source values are available for inspection even when an owner,
    // insertion point or live modulation prevents audio execution. Never
    // initialize these from a manually selected SILVETON preset.
    NumberedFxState decoded{};
    bool parameterLayoutKnown{false};
    bool parameterBlockValid{false};
    bool parametersComplete{false};
    std::string parameterDetail;
};

// Read-only parameter interpretation for a bounded PCG Sound record. It never
// makes a source MIDI frame, mutates a rack or declares unknown Sound routing
// active. The returned slot is explicitly unscoped and remains Unsupported.
SourceFxSlotStatus inspectSoundEffectParameters(const arranger::Pa5xSoundFxRecordRaw& record);
struct SourceFxRenderParameters {
    bool active{false};
    // Derived, runtime-only semantic translation of a verified source block.
    // It is rebuilt from SVFX, never stored as a manual EffectSlot/SVNF state.
    // Only the source decoder may establish its Decoded values/known mask.
    NumberedFxState numbered{};
    float reverbSeconds{0.0F};
    float preDelayThru{0.0F};
    float inputTrim{1.0F};
    float eqLowGainDb{0.0F},eqHighGainDb{0.0F};
    float eqLowHz{0.0F},eqHighHz{0.0F};
    float earlyLevel{1.0F},reverbLevel{1.0F};
    float masterToFirst{0.0F};
};
inline bool sameSourceFxRender(const SourceFxRenderParameters& a,const SourceFxRenderParameters& b) noexcept {
    return a.active==b.active&&sameNumberedFx(a.numbered,b.numbered)&&
        a.reverbSeconds==b.reverbSeconds&&a.preDelayThru==b.preDelayThru&&
        a.inputTrim==b.inputTrim&&a.eqLowGainDb==b.eqLowGainDb&&a.eqHighGainDb==b.eqHighGainDb&&
        a.eqLowHz==b.eqLowHz&&a.eqHighHz==b.eqHighHz&&a.earlyLevel==b.earlyLevel&&
        a.reverbLevel==b.reverbLevel&&a.masterToFirst==b.masterToFirst;
}
struct SourceEffectsState {
    std::vector<std::shared_ptr<const arranger::KorgSourceEffects>> profiles;
    std::array<int,8> logicalToSampler{{-1,-1,-1,-1,-1,-1,-1,-1}};
    bool style{false};
    bool followMidiSends{false};
    std::array<bool,kPartCount> dryOff{};
    std::array<SourceFxRenderParameters,kFxSendSlots> masterRender{};
    std::vector<SourceFxSlotStatus> slots;
    std::string note;
    // Original routing/parameters unsupported by the translation remain in
    // profiles and are displayed; they are not replaced with guessed presets.
    [[nodiscard]] std::string summary() const;
};

// Worker/control thread only. Replaces the owner's effect rack, never Sounds,
// sample resources, split, mix/EQ or another Player/Keyboard Set's ownership.
void applySourceEffects(Combi& combi,
    const std::vector<std::shared_ptr<const arranger::KorgSourceEffects>>& profiles,
    const std::array<int,8>& logicalToSampler,bool style);

// Bounded optional SET extension. Saved source effects can be reconstructed
// without reopening a SET archive or touching a PCM/sample cache.
[[nodiscard]] std::vector<std::uint8_t> encodeSourceEffects(const SourceEffectsState& state);
bool decodeSourceEffects(const std::vector<std::uint8_t>& bytes,Combi& combi,std::string& error);

} // namespace silveton::sampler
