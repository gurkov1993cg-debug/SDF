#pragma once

#include "silveton/sampler/SourceModulation.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "silveton/sampler/SourcePerformanceControls.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>

namespace silveton::sampler {

constexpr unsigned kSourceControlStride=32U;
inline float sourceIndexTimeSeconds(float index) noexcept {
    return static_cast<float>(.001*std::expm1(static_cast<double>(std::clamp(index,0.0F,99.0F))*
        std::log(2.0)/7.5));
}
inline float sourceCutoffHz(float index) noexcept {
    // The retained Triton index doubles cutoff every10steps (PG208).
    // The20Hz origin is our calibration, not a measured Korg endpoint.
    return 20.0F*std::exp2(std::clamp(index,-20.0F,119.0F)*.1F);
}
constexpr float sourceDelaySeconds(std::uint8_t raw) noexcept {
    // Official normal Program table1-5;97 is the distinct KeyOff trigger.
    return raw<=25U?static_cast<float>(raw)*.002F:
        raw<=40U?.05F+static_cast<float>(raw-25U)*.01F:
        raw<=56U?.2F+static_cast<float>(raw-40U)*.05F:
        raw<=96U?1.0F+static_cast<float>(raw-56U)*.1F:0.0F;
}

inline bool sourceScaledVelocitySupported(const SourceOscillatorDsp& source) noexcept {
    if(!source.layoutCorroborated||!source.framingValid()||
       !source.scaledVelocityDecoded||!source.velocityZonePresent)return false;
    const auto& zone=source.velocityZoneRaw;
    const auto& scaled=source.scaledVelocityRaw;
    if(zone[0]>zone[1]||zone[1]>127U||scaled[0]>scaled[1]||scaled[1]>127U)return false;
    // A single input value cannot establish interpolation between distinct
    // output endpoints. A constant output is unambiguous, including0.
    return zone[0]!=zone[1]||scaled[0]==scaled[1];
}

inline float sourceScaledVelocity(const SourceOscillatorDsp* source,std::uint8_t received) noexcept {
    const float original=static_cast<float>(std::min<unsigned>(received,127U));
    if(source==nullptr||!sourceScaledVelocitySupported(*source))return original;
    const auto& zone=source->velocityZoneRaw;
    const auto& scaled=source->scaledVelocityRaw;
    // Pa5X User Manual1106-1107: the OSC's input zone is remapped to the
    // Scaled Velocity Bottom/Top, including intermediate velocities. Keep
    // the fractional result for AMS; a MIDI byte is only a fallback for APIs
    // that do not accept the existing float velocityPosition input.
    if(zone==scaled)return original;
    if(scaled[0]==scaled[1])return static_cast<float>(scaled[0]);
    const float position=std::clamp((original-static_cast<float>(zone[0]))/
        static_cast<float>(zone[1]-zone[0]),0.0F,1.0F);
    return static_cast<float>(scaled[0])+position*static_cast<float>(scaled[1]-scaled[0]);
}

struct SourceOscillatorSupport {
    bool pitch{false},pitchEnvelope{false},filter{false},filterEnvelope{false};
    std::array<bool,2> lfo{};
    bool amplitude{false},level{false},multisampleLevel{false},pan{false};
    bool scaledVelocity{false};
    bool equalizerTrim{false},equalizerShelves{false},equalizerComplete{false};
    bool amplitudeSecondUnknown{false},equalizerUnknown{false},delayUnknown{false};
};

inline SourceOscillatorSupport sourceOscillatorSupport(const SourceOscillatorDsp& source) noexcept {
    SourceOscillatorSupport support;
    if(!source.layoutCorroborated||!source.framingValid())return support;
    support.scaledVelocity=sourceScaledVelocitySupported(source);
    const auto& d=source.dspRaw;
    const auto s=[&](unsigned offset){return sourceSignedByte(d[offset]);};
    const auto validSigned=[&](unsigned offset,int limit=99){return s(offset)>=-limit&&s(offset)<=limit;};
    const auto route=[&](unsigned offset,int limit=99){return sourceAmsRouteValid(d[offset],s(offset+1U),limit);};
    support.pitch=!source.overridden(SourceOscillatorModule::Pitch)&&route(0U,115)&&s(2U)>=-10&&s(2U)<=20&&
        validSigned(6U,115)&&validSigned(7U,115)&&s(10U)>=-60&&s(10U)<=12&&
        s(11U)>=-60&&s(11U)<=12&&validSigned(12U,12)&&d[13U]==0U&&
        validSigned(14U,115)&&validSigned(15U,115)&&route(16U,115)&&route(18U,115);
    const auto& p=source.pitchEnvelopeRaw;
    support.pitchEnvelope=source.pitchEnvelopePresent&&!source.overridden(SourceOscillatorModule::PitchEnvelope)&&
        validSigned(3U,115)&&route(4U,115)&&p[1]<=99U&&p[3]<=99U&&p[4]<=99U&&
        sourceAmsRouteValid(p[6],sourceSignedByte(p[7]))&&sourceAmsRouteValid(p[8],sourceSignedByte(p[9]))&&
        sourceAmsRouteValid(p[10],sourceSignedByte(p[11]))&&sourceDirectionsValid(p[12],4U)&&
        sourceDirectionsValid(p[13],2U);
    for(const auto i:{0U,2U,5U})if(sourceSignedByte(p[i])< -99||sourceSignedByte(p[i])>99)support.pitchEnvelope=false;
    support.filter=!source.overridden(SourceOscillatorModule::Filter)&&d[20]<=1U&&d[21]<=99U&&d[22]<=99U&&route(23U);
    for(unsigned path=0U;path<2U;++path){
        if(path==1U&&d[20]==0U)break;
        const unsigned at=28U+15U*path;
        if(d[at]>99U||!validSigned(at+1U)||!route(at+2U)||!route(at+4U))support.filter=false;
        for(unsigned j=6U;j<15U;++j)if(!validSigned(at+j))support.filter=false;
        if(!sourceAmsRouteValid(d[25],s(at+12U))||!sourceAmsRouteValid(d[26],s(at+13U))||
            !sourceAmsRouteValid(d[27],s(at+14U)))support.filter=false;
    }
    if(d[76]>d[78]||d[78]>127U||!validSigned(77U)||!validSigned(79U))support.filter=false;
    support.filterEnvelope=!source.overridden(SourceOscillatorModule::FilterEnvelope)&&
        sourceDirectionsValid(d[67],4U)&&sourceDirectionsValid(d[68],4U)&&sourceDirectionsValid(d[69],3U)&&
        route(70U)&&route(72U)&&route(74U);
    for(unsigned i=58U;i<=66U;++i){
        if((i&1U)!=0U){if(d[i]>99U)support.filterEnvelope=false;}
        else if(!validSigned(i))support.filterEnvelope=false;
    }
    for(unsigned i=0U;i<2U;++i){
        const unsigned at=10U*i;const auto& l=source.lfoRaw;
        support.lfo[i]=!source.overridden(i==0U?SourceOscillatorModule::Lfo1:SourceOscillatorModule::Lfo2)&&
            (l[at]&31U)<=20U&&(l[at]&96U)==0U&&l[at+1U]<=99U&&
            sourceSignedByte(l[at+2U])>=-99&&sourceSignedByte(l[at+2U])<=99&&
            l[at+3U]<=99U&&l[at+4U]<=99U&&
            sourceAmsRouteValid(l[at+6U],sourceSignedByte(l[at+7U]))&&
            sourceAmsRouteValid(l[at+8U],sourceSignedByte(l[at+9U]));
    }
    const auto& a=source.amplitudeEnvelopeRaw;
    support.amplitude=!source.overridden(SourceOscillatorModule::Amplitude)&&validSigned(81U)&&route(82U)&&
        validSigned(84U)&&validSigned(85U)&&route(86U)&&route(88U)&&a[18]<=a[20]&&a[20]<=127U&&
        sourceSignedByte(a[19])>=-99&&sourceSignedByte(a[19])<=99&&sourceSignedByte(a[21])>=-99&&sourceSignedByte(a[21])<=99;
    const unsigned ampExtension=source.resourceVersion==5U?0U:2U;
    const bool amp16=source.resourceVersion>=5U;
    const unsigned level=amp16?(static_cast<unsigned>(d[80])<<8U)|source.additionalDspRaw[ampExtension]:d[80];
    support.level=!source.overridden(SourceOscillatorModule::Level)&&!source.overridden(SourceOscillatorModule::Amplitude)&&
        level<=(amp16?32767U:127U);
    support.multisampleLevel=!source.overridden(SourceOscillatorModule::Level)&&!source.overridden(SourceOscillatorModule::Amplitude)&&
        source.multisampleLevelDecoded&&source.multisampleLevelRaw<=127U;
    support.amplitudeSecondUnknown=amp16&&source.additionalDspRaw[ampExtension+2U]!=0U;
    support.pan=source.outputRawPresent&&!source.overridden(SourceOscillatorModule::Pan)&&source.outputRaw[0]==0U&&
        source.outputRaw[1]<=127U&&sourceAmsRouteValid(source.outputRaw[2],sourceSignedByte(source.outputRaw[3]));
    if(source.equalizerPresent&&!source.overridden(SourceOscillatorModule::Equalizer)){
        const auto& e=source.equalizerRaw;
        if(e[0]==0U)support.equalizerComplete=true; // saved bypass, no DSP required
        else if(e[0]==1U){
            const auto gainValid=[](std::uint8_t raw) noexcept {
                const auto signedValue=sourceSignedByte(raw);return signedValue>=-36&&signedValue<=36;
            };
            support.equalizerTrim=e[1]<=99U;
            support.equalizerShelves=gainValid(e[2])&&gainValid(e[5]);
            // The mid-frequency byte is an index, with active examples over
            //127. Its conversion table is uncorroborated. A zero mid gain
            // is an exact bypass regardless of that unused frequency index.
            support.equalizerComplete=support.equalizerTrim&&support.equalizerShelves&&e[4]==0U;
            support.equalizerUnknown=!support.equalizerComplete;
        }else support.equalizerUnknown=true;
    }
    support.delayUnknown=source.delayRaw>96U;
    return support;
}

// Signed multistage EG, used by the original Filter and common Pitch EG.
// Segment interpolation and index-to-seconds are our DSP. Pitch time AMS is
// sampled at each segment boundary, as described in Pa5X manual p.1133.
class SourceEnvelopeCursor {
public:
    enum class Stage : std::uint8_t {Idle,Attack,Decay,Slope,Sustain,Release,Released};
    Stage stage{Stage::Idle};
    float value{0.0F};
    void prepare(bool pitch) noexcept { *this=SourceEnvelopeCursor{};pitch_=pitch; }
    void configure(const std::array<float,5>& levels,const std::array<float,4>& seconds,double rate) noexcept {
        levels_=levels;nextSeconds_=seconds;sampleRate_=std::max(1.0,rate);
        if(stage==Stage::Sustain){value=levels_[3];position_=value;}
        // A held modulation changes an endpoint without restarting its stage.
        if(stage==Stage::Attack||stage==Stage::Decay||stage==Stage::Slope||stage==Stage::Release){
            const float target=targetFor(stage);
            if(target!=target_){target_=target;step_=(target_-position_)/static_cast<double>(std::max<std::uint64_t>(1U,remaining_));}
        }
    }
    void trigger() noexcept {started_=false;value=levels_[0];position_=value;enter(Stage::Attack);}
    void release() noexcept {
        if(stage==Stage::Idle||stage==Stage::Release||stage==Stage::Released)return;
        if(!started_){stage=Stage::Idle;value=0.0F;return;}
        enter(Stage::Release);
    }
    float process() noexcept {
        if(stage==Stage::Idle)return value=0.0F;
        started_=true;
        for(;;){
            if(stage==Stage::Sustain||stage==Stage::Released)return value;
            if(remaining_==0U){
                value=target_;position_=value;
                if(stage==Stage::Release){stage=Stage::Released;return value;}
                if(stage==Stage::Slope||(pitch_&&stage==Stage::Decay)){stage=Stage::Sustain;value=levels_[3];position_=value;return value;}
                enter(stage==Stage::Attack?Stage::Decay:Stage::Slope);continue;
            }
            value=static_cast<float>(position_);position_+=step_;--remaining_;return value;
        }
    }
private:
    bool pitch_{false},started_{false};
    std::array<float,5> levels_{};
    std::array<float,4> nextSeconds_{};
    double sampleRate_{48000.0},position_{0.0},step_{0.0};
    float target_{0.0F};std::uint64_t remaining_{0U};
    float targetFor(Stage next) const noexcept {
        if(next==Stage::Attack)return levels_[1];
        if(next==Stage::Decay)return pitch_?levels_[3]:levels_[2];
        return next==Stage::Slope?levels_[3]:levels_[4];
    }
    void enter(Stage next) noexcept {
        stage=next;target_=targetFor(next);position_=value;
        const unsigned index=next==Stage::Attack?0U:next==Stage::Decay?1U:next==Stage::Slope?2U:3U;
        remaining_=static_cast<std::uint64_t>(std::llround(std::clamp(static_cast<double>(nextSeconds_[index]),0.0,60.0)*sampleRate_));
        step_=(static_cast<double>(target_)-position_)/static_cast<double>(std::max<std::uint64_t>(1U,remaining_));
    }
};

struct SourceLfoCursor {
    double phase{0.0},age{0.0},increment{0.0},periodScale{1.0};
    float value{0.0F},randomFrom{0.0F},randomTo{0.0F},offset{0.0F};
    double delay{0.0},fade{0.0};
    std::uint32_t randomState{1U};std::uint8_t waveform{0U};

    float random() noexcept {
        randomState=randomState*1664525U+1013904223U;
        return static_cast<float>(randomState>>8U)/8388608.0F-1.0F;
    }
    void reset(const std::uint8_t* raw,std::uint32_t seed) noexcept {
        *this=SourceLfoCursor{};randomState=seed==0U?1U:seed;waveform=raw[0]&31U;
        phase=waveform==1U?.25:waveform==2U?static_cast<double>(random()+1.0F)*.5:waveform==4U?.5:0.0;
        randomFrom=random();randomTo=random();
    }
    void configure(const std::uint8_t* raw,const SourceModulationValues& inputs,
                   const SourceSoundEdits& edits,float tempo,double rate) noexcept {
        waveform=raw[0]&31U;offset=static_cast<float>(sourceSignedByte(raw[2]))/99.0F;
        delay=static_cast<double>(sourceSoundEditTimeMs(sourceIndexTimeSeconds(raw[3])*1000.0F,edits.controller(78)))*.001;
        fade=sourceIndexTimeSeconds(raw[4]);
        double frequency=0.0;
        if((raw[5]&128U)!=0U){
            constexpr std::array<double,8> beats{{.25,1.0/3.0,.5,2.0/3.0,1.0,4.0/3.0,2.0,4.0}};
            const unsigned division=(raw[5]>>4U)&7U;
            const unsigned times=(raw[5]&15U)+1U; // wire0..15 / official PG[01..16]
            frequency=static_cast<double>(std::clamp(tempo,1.0F,999.0F))/(60.0*beats[division]*static_cast<double>(times));
        }else{
            const float octaves=sourceModulationOctaves(static_cast<float>(sourceSignedByte(raw[7])))*inputs[raw[6]]+
                sourceModulationOctaves(static_cast<float>(sourceSignedByte(raw[9])))*inputs[raw[8]];
            // Own base-index calibration; documented modulation ratios retained.
            frequency=.03*std::exp2(static_cast<double>(raw[1])/9.0+std::clamp(static_cast<double>(octaves),-16.0,16.0));
        }
        frequency*=sourceSoundEditRateScale(edits.controller(76));
        increment=std::clamp(frequency,.00001,500.0)/std::max(1.0,rate);
    }
    float process(double rate) noexcept {
        const double seconds=1.0/std::max(1.0,rate);
        const double previousAge=age;age+=seconds;
        if(previousAge<delay)return value=0.0F;
        const double p=phase;
        const float tri=static_cast<float>(1.0-4.0*std::abs(std::fmod(p+.25,1.0)-.5));
        float x=0.0F;
        switch(waveform){
            case 0U:case 1U:case 2U:x=tri;break;
            case 3U:case 4U:x=static_cast<float>(1.0-2.0*p);break;
            case 5U:x=p<.5?1.0F:-1.0F;break;
            case 6U:x=static_cast<float>(std::sin(6.283185307179586*p));break;
            case 7U:x=static_cast<float>(.5-.5*std::cos(6.283185307179586*p));break;
            case 8U:x=std::copysign(tri*tri,tri);break;
            case 9U:x=static_cast<float>(2.0*(1.0-p)*(1.0-p)-1.0);break;
            case 10U:x=static_cast<float>(2.0*p*p-1.0);break;
            case 11U:case 12U:{const float steps=waveform==11U?3.0F:5.0F;x=std::round((tri+1.0F)*.5F*steps)/steps*2.0F-1.0F;break;}
            case 13U:case 14U:{const double steps=waveform==13U?4.0:6.0;x=static_cast<float>(1.0-2.0*std::floor(p*steps)/(steps-1.0));break;}
            case 15U:case 16U:case 17U:x=randomTo;break;
            default:{const float mix=static_cast<float>(p*p*(3.0-2.0*p));x=randomFrom+(randomTo-randomFrom)*mix;break;}
        }
        phase+=increment*periodScale;
        if(phase>=1.0){
            phase-=std::floor(phase);randomFrom=randomTo;
            const bool alternating=waveform==17U||waveform==20U;
            randomTo=alternating?(randomTo>=0.0F?-1.0F:1.0F):random();
            periodScale=(waveform==16U||waveform==17U||waveform==19U||waveform==20U)?
                .5+static_cast<double>(random()+1.0F)*.75:1.0;
        }
        const float fadeGain=fade>0.0?static_cast<float>(std::clamp((previousAge-delay)/fade,0.0,1.0)):1.0F;
        return value=(x+offset)*fadeGain;
    }
};

// Stable TPT state-variable sections. LP24 uses two cascaded low-pass
// sections; LP12+HP12 uses the documented serial topology. This is original
// SILVETON code, not a reconstruction of a proprietary filter implementation.
struct SourceFilterSection {
    double a1{1.0},a2{0.0},a3{0.0},k{1.4142135623730951};
    std::array<double,2> ic1{},ic2{};
    void set(float hz,double q,double rate) noexcept {
        const double g=std::tan(3.141592653589793*std::clamp(static_cast<double>(hz),5.0,.45*rate)/std::max(1.0,rate));
        k=1.0/std::clamp(q,.5,16.0);a1=1.0/(1.0+g*(g+k));a2=g*a1;a3=g*a2;
    }
    float process(float input,unsigned channel,bool highPass) noexcept {
        const double v3=static_cast<double>(input)-ic2[channel];
        const double v1=a1*ic1[channel]+a2*v3;
        const double v2=ic2[channel]+a2*ic1[channel]+a3*v3;
        ic1[channel]=2.0*v1-ic1[channel];ic2[channel]=2.0*v2-ic2[channel];
        if(std::abs(ic1[channel])<1.0e-30)ic1[channel]=0.0;
        if(std::abs(ic2[channel])<1.0e-30)ic2[channel]=0.0;
        return static_cast<float>(highPass?static_cast<double>(input)-k*v1-v2:v2);
    }
};

// Own, unity-slope shelving biquads. The saved half-dB gain is retained;
//120Hz/8kHz corners are explicitly SILVETON calibration, not decoded source
// frequencies. Double state and independent channels keep boosted tails
// stable without clipping otherwise valid audio or coupling stereo history.
struct SourceEqualizerShelf {
    bool enabled{false};
    double b0{1.0},b1{0.0},b2{0.0},a1{0.0},a2{0.0};
    std::array<double,2> z1{},z2{};

    void configure(bool high,float gainDb,double rate) noexcept {
        *this=SourceEqualizerShelf{};
        if(gainDb==0.0F||!std::isfinite(gainDb)||!std::isfinite(rate)||rate<=0.0)return;
        const double gain=std::clamp(static_cast<double>(gainDb),-18.0,18.0);
        const double a=std::pow(10.0,gain/40.0);
        const double frequency=std::min(high?8000.0:120.0,.45*rate);
        const double omega=2.0*3.14159265358979323846*frequency/rate;
        const double c=std::cos(omega);
        const double beta=std::sqrt(2.0*a)*std::sin(omega);
        const double plus=a+1.0,minus=a-1.0;
        double divisor=1.0;
        if(high){
            divisor=plus-minus*c+beta;
            b0=a*(plus+minus*c+beta);b1=-2.0*a*(minus+plus*c);b2=a*(plus+minus*c-beta);
            a1=2.0*(minus-plus*c);a2=plus-minus*c-beta;
        }else{
            divisor=plus+minus*c+beta;
            b0=a*(plus-minus*c+beta);b1=2.0*a*(minus-plus*c);b2=a*(plus-minus*c-beta);
            a1=-2.0*(minus+plus*c);a2=plus+minus*c-beta;
        }
        b0/=divisor;b1/=divisor;b2/=divisor;a1/=divisor;a2/=divisor;enabled=true;
    }

    float process(float input,unsigned channel) noexcept {
        if(!enabled)return input;
        const double output=b0*static_cast<double>(input)+z1[channel];
        const double next1=b1*static_cast<double>(input)-a1*output+z2[channel];
        const double next2=b2*static_cast<double>(input)-a2*output;
        if(!std::isfinite(output)||std::abs(output)>std::numeric_limits<float>::max()||
           !std::isfinite(next1)||!std::isfinite(next2)){
            z1[channel]=z2[channel]=0.0;return 0.0F;
        }
        z1[channel]=std::abs(next1)<1.0e-30?0.0:next1;
        z2[channel]=std::abs(next2)<1.0e-30?0.0:next2;
        return static_cast<float>(output);
    }
};

struct SourceOscillatorRuntime {
    const SourceOscillatorDsp* source{nullptr};
    SourceOscillatorSupport support{};
    SourceEnvelopeCursor pitchEnvelope{},filterEnvelope{};
    std::array<SourceLfoCursor,2> lfo{};
    SourceModulationValues inputs{};
    SourceFilterSection filterA{},filterB{};
    SourceEqualizerShelf equalizerLow{},equalizerHigh{};
    unsigned controlCountdown{0U};
    float pitchSemitones{0.0F},amplitudeGain{1.0F},pan{0.0F},filterTrim{1.0F};
    float randomPan{0.0F},levelGain{1.0F};
    float equalizerTrim{1.0F};
    bool started{false};
    bool filterReplacedByTone{false};

    void prepare(const SourceOscillatorDsp* original,std::uint32_t seed,float randomValue) noexcept {
        *this=SourceOscillatorRuntime{};source=original;randomPan=randomValue;
        if(source==nullptr)return;
        support=sourceOscillatorSupport(*source);pitchEnvelope.prepare(true);filterEnvelope.prepare(false);
        for(unsigned i=0U;i<2U;++i)lfo[i].reset(source->lfoRaw.data()+10U*i,seed+7919U*i);
        if(support.level){
            const auto& d=source->dspRaw;const bool extended=source->resourceVersion>=5U;
            const unsigned ext=source->resourceVersion==5U?0U:2U;
            const float raw=extended?static_cast<float>((static_cast<unsigned>(d[80])<<8U)|source->additionalDspRaw[ext])/258.0F:
                static_cast<float>(d[80]);
            const float normalized=std::clamp(raw/127.0F,0.0F,1.0F);
            levelGain=normalized*normalized; // own gain law; exact original words remain stored
        }
        if(support.multisampleLevel){
            const float normalized=static_cast<float>(source->multisampleLevelRaw)/127.0F;
            levelGain*=normalized*normalized;
        }
        if(support.pan)pan=source->outputRaw[1]==0U?randomPan:(static_cast<float>(source->outputRaw[1])-64.0F)/63.0F;
    }

    void configureEnvelopes(const SourceSoundEdits& edits,double rate) noexcept {
        if(source==nullptr)return;
        if(support.pitchEnvelope){
            const auto& p=source->pitchEnvelopeRaw;
            std::array<float,5> level{{static_cast<float>(sourceSignedByte(p[0])),static_cast<float>(sourceSignedByte(p[2])),0.0F,0.0F,static_cast<float>(sourceSignedByte(p[5]))}};
            for(unsigned route=0U;route<2U;++route)for(unsigned point=0U;point<2U;++point)
                level[point]+=sourceDirection(p[12],2U*route+point)*static_cast<float>(sourceSignedByte(p[7U+2U*route]))*inputs[p[6U+2U*route]];
            for(auto& value:level)value=std::clamp(value,-99.0F,99.0F)/99.0F;
            std::array<float,4> seconds{{sourceIndexTimeSeconds(p[1]),sourceIndexTimeSeconds(p[3]),0.0F,sourceIndexTimeSeconds(p[4])}};
            for(unsigned point=0U;point<2U;++point)seconds[point]*=std::exp2(std::clamp(
                sourceDirection(p[13],point)*sourceModulationOctaves(static_cast<float>(sourceSignedByte(p[11])))*inputs[p[10]],-16.0F,16.0F));
            pitchEnvelope.configure(level,seconds,rate);
        }
        if(support.filterEnvelope){
            const auto& d=source->dspRaw;
            std::array<float,5> level{};std::array<float,4> time{};
            for(unsigned i=0U;i<5U;++i)level[i]=static_cast<float>(sourceSignedByte(d[58U+2U*i]));
            for(unsigned i=0U;i<4U;++i)time[i]=d[59U+2U*i];
            for(unsigned i=0U;i<3U;++i)level[i]+=sourceDirection(d[69],i)*static_cast<float>(sourceSignedByte(d[75]))*inputs[d[74]];
            for(unsigned route=0U;route<2U;++route)for(unsigned i=0U;i<4U;++i)
                time[i]+=sourceDirection(d[67U+route],i)*static_cast<float>(sourceSignedByte(d[71U+2U*route]))*inputs[d[70U+2U*route]];
            for(auto& value:level)value=std::clamp(value,-99.0F,99.0F)/99.0F;
            for(auto& value:time)value=sourceIndexTimeSeconds(value);
            time[0]=sourceSoundEditTimeMs(time[0]*1000.0F,edits.controller(73))*.001F;
            time[1]=sourceSoundEditTimeMs(time[1]*1000.0F,edits.controller(75))*.001F;
            time[2]=sourceSoundEditTimeMs(time[2]*1000.0F,edits.controller(75))*.001F;
            time[3]=sourceSoundEditTimeMs(time[3]*1000.0F,edits.controller(72))*.001F;
            filterEnvelope.configure(level,time,rate);
        }
    }

    void start(const SourceModulationContext& context,const SourceSoundEdits& edits,double rate) noexcept {
        if(source!=nullptr){
            const auto& e=source->equalizerRaw;
            if(support.equalizerTrim)equalizerTrim=static_cast<float>(e[1])/99.0F; // own linear trim law
            if(support.equalizerShelves){
                equalizerLow.configure(false,static_cast<float>(sourceSignedByte(e[2]))*.5F,rate);
                equalizerHigh.configure(true,static_cast<float>(sourceSignedByte(e[5]))*.5F,rate);
            }
        }
        inputs=sourceModulationValues(context);configureEnvelopes(edits,rate);
        if(support.pitchEnvelope)pitchEnvelope.trigger();
        if(support.filterEnvelope)filterEnvelope.trigger();
        controlCountdown=0U;
    }
    void release() noexcept {if(support.pitchEnvelope)pitchEnvelope.release();if(support.filterEnvelope)filterEnvelope.release();}

    void tick(SourceModulationContext context,const SourceSoundEdits& edits,double rate,
              const std::array<float,2>& sharedValues,const std::array<bool,2>& shared) noexcept {
        if(source==nullptr)return;
        started=true;
        context.pitchEnvelope=support.pitchEnvelope?pitchEnvelope.value:context.pitchEnvelope;
        context.filterEnvelope=support.filterEnvelope?filterEnvelope.value:context.filterEnvelope;
        for(unsigned i=0U;i<2U;++i)if(support.lfo[i])context.lfo[i]=shared[i]?sharedValues[i]:lfo[i].value;
        const bool control=controlCountdown==0U;
        if(control){
            inputs=sourceModulationValues(context);
            controlCountdown=kSourceControlStride;configureEnvelopes(edits,rate);
            for(unsigned i=0U;i<2U;++i)if(support.lfo[i]&&!shared[i])
                lfo[i].configure(source->lfoRaw.data()+10U*i,inputs,edits,context.tempoBpm,rate);
        }
        --controlCountdown;
        inputs.value[1]=context.pitchEnvelope;inputs.value[2]=context.filterEnvelope;
        inputs.value[3]=context.amplitudeEnvelope;inputs.value[4]=context.lfo[0];inputs.value[5]=context.lfo[1];
        if(support.pitchEnvelope)inputs.value[1]=pitchEnvelope.process();
        if(support.filterEnvelope)inputs.value[2]=filterEnvelope.process();
        for(unsigned i=0U;i<2U;++i)if(support.lfo[i])inputs.value[4U+i]=shared[i]?sharedValues[i]:lfo[i].process(rate);
        const auto& d=source->dspRaw;
        const auto raw=[&](unsigned at){return static_cast<float>(sourceSignedByte(d[at]));};
        pitchSemitones=0.0F;
        if(support.pitch){
            pitchSemitones=(static_cast<float>(context.key)-60.0F)*(raw(2U)*.1F-1.0F)+
                sourcePitchSemitones(d[1])*inputs[d[0]]+raw(12U)*inputs[24U];
            // The visible Upper bend range remains authoritative. Original
            // per-OSC bend ranges are retained until separate inheritance is
            // represented; adding both would apply pitch bend twice.
            for(unsigned i=0U;i<2U;++i){
                if(source->overridden(i==0U?SourceOscillatorModule::Lfo1:SourceOscillatorModule::Lfo2))continue;
                const float sourceDepth=sourcePitchSemitones(d[6U+i])*100.0F;
                const float depth=i==0U||sourceDepth!=0.0F?
                    std::copysign(sourceSoundEditDepthCents(std::abs(sourceDepth),edits.controller(77)),sourceDepth):0.0F;
                const float amount=depth*.01F+sourcePitchSemitones(d[14U+i])*inputs[19U]+
                    sourcePitchSemitones(d[17U+2U*i])*inputs[d[16U+2U*i]];
                pitchSemitones+=inputs[4U+i]*amount;
            }
        }
        if(support.pitchEnvelope)pitchSemitones+=inputs[1U]*(sourcePitchSemitones(d[3])+
            sourcePitchSemitones(d[5])*inputs[d[4]]);
        amplitudeGain=levelGain;
        if(support.amplitude){
            const float velocity=inputs[15U],velocityIntensity=raw(81U)/99.0F*std::clamp(context.velocityLevelScale,0.0F,1.0F);
            const float velocityGain=velocityIntensity>=0.0F?1.0F-velocityIntensity*(1.0F-velocity):
                1.0F+velocityIntensity*velocity;
            float adjustment=raw(83U)*inputs[d[82]]/99.0F+inputs[10U];
            const float amsGain=adjustment>=0.0F?1.0F+7.0F*adjustment:std::max(0.0F,1.0F+adjustment);
            float tremolo=1.0F;
            for(unsigned i=0U;i<2U;++i)if(!source->overridden(i==0U?SourceOscillatorModule::Lfo1:SourceOscillatorModule::Lfo2))
                tremolo+=inputs[4U+i]*(raw(84U+i)+raw(87U+2U*i)*inputs[d[86U+2U*i]])/99.0F;
            amplitudeGain=std::clamp(levelGain*velocityGain*amsGain*std::max(0.0F,tremolo),0.0F,1.0F);
        }
        if(support.pan){
            const auto& p=source->outputRaw;
            const float base=p[1]==0U?randomPan:(static_cast<float>(p[1])-64.0F)/63.0F;
            pan=std::clamp(base+static_cast<float>(sourceSignedByte(p[3]))*.02F*inputs[p[2]],-1.0F,1.0F);
        }
        if(support.filter&&control){
            filterReplacedByTone=context.filterReplacedByTone;
            std::array<float,2> cutoff{};
            for(unsigned i=0U;i<2U;++i){
                const unsigned at=28U+15U*i;
                float index=static_cast<float>(d[at])+raw(at+1U)*inputs[6U]+raw(at+3U)*inputs[d[at+2U]]+
                    raw(at+5U)*inputs[d[at+4U]];
                index+=inputs[2U]*(raw(at+6U)+raw(at+7U)*inputs[15U]+raw(at+12U)*inputs[d[25]]);
                for(unsigned l=0U;l<2U;++l)if(!source->overridden(l==0U?SourceOscillatorModule::Lfo1:SourceOscillatorModule::Lfo2))
                    index+=inputs[4U+l]*(raw(at+8U+l)+raw(at+10U+l)*inputs[20U]+raw(at+13U+l)*inputs[d[26U+l]]);
                const float base=i==0U&&context.manualCutoffHz>=0.0F?context.manualCutoffHz:
                    sourceCutoffHz(static_cast<float>(d[at]))*std::exp2(sourceSoundEditCutoffOctaves(edits.controller(74)));
                cutoff[i]=base*std::exp2((index-static_cast<float>(d[at]))*.1F+context.filterExtraOctaves);
            }
            const float resonanceBase=context.manualResonance>=0.0F?context.manualResonance:
                static_cast<float>(d[22])/99.0F+sourceSoundEditResonance(edits.controller(71));
            const float resonance=std::clamp(resonanceBase+raw(24U)*inputs[d[23]]/99.0F+context.resonanceExtra,0.0F,1.0F);
            if(d[20]==0U){filterA.set(cutoff[0],.5411961+11.0*resonance*resonance,rate);filterB.set(cutoff[0],1.306563,rate);}
            else{filterA.set(cutoff[0],context.manualResonance>=0.0F?.70710678+11.0*resonance*resonance:.70710678,rate);filterB.set(cutoff[1],.70710678,rate);}
            filterTrim=static_cast<float>(d[21])/99.0F;
        }
    }

    void processFilter(float& left,float& right) noexcept {
        if(source==nullptr||!support.filter||filterReplacedByTone)return;
        const bool highPass=source->dspRaw[20]==1U;
        left=filterB.process(filterA.process(left*filterTrim,0U,false),0U,highPass);
        right=filterB.process(filterA.process(right*filterTrim,1U,false),1U,highPass);
    }

    void processEqualizer(float& left,float& right) noexcept {
        if(equalizerTrim==1.0F&&!equalizerLow.enabled&&!equalizerHigh.enabled)return;
        left=equalizerHigh.process(equalizerLow.process(left*equalizerTrim,0U),0U);
        right=equalizerHigh.process(equalizerLow.process(right*equalizerTrim,1U),1U);
    }
};

} // namespace silveton::sampler
