#pragma once

#include "silveton/sampler/NumberedFx.h"
#include "silveton/sampler/NumberedFxControl.h"
#include <memory>

namespace silveton::sampler {

// Availability means an explicit own-code binding exists, never that the
// proprietary Pa5X transfer function or its packed SET parameters are known.
struct NumberedFxSupport {
    bool selectable{false};
    std::uint64_t editableMask{0};
    const char* limitation{"Звуковата реализация още не е свързана."};
};

[[nodiscard]] NumberedFxSupport numberedFxSupport(std::uint16_t index) noexcept;
bool initializeNumberedFx(std::uint16_t index, NumberedFxState& state) noexcept;
bool setNumberedFxValue(NumberedFxState& state, std::size_t row, double value) noexcept;
[[nodiscard]] bool numberedFxCanRender(const NumberedFxState& state) noexcept;
[[nodiscard]] float numberedFxWet(const NumberedFxState& state) noexcept;
// Global mix row for the persistent editor footer. Component-local mix rows
// stay in their own sections. CX-3 uses its detailed, documented mix block.
[[nodiscard]] int numberedFxPrimaryWetRow(std::uint16_t index) noexcept;
[[nodiscard]] bool sameNumberedFx(const NumberedFxState& a, const NumberedFxState& b) noexcept;

// One independent processor per audio slot. prepare() is the only allocator
// and is called while the engine is stopped. configure() is called once at a
// render-block boundary. process() returns the internal Wet/Dry mixture;
// Master return gain remains the outer EffectSlot::wet control.
class NumberedFxProcessor {
public:
    NumberedFxProcessor();
    ~NumberedFxProcessor();
    NumberedFxProcessor(const NumberedFxProcessor&) = delete;
    NumberedFxProcessor& operator=(const NumberedFxProcessor&) = delete;
    NumberedFxProcessor(NumberedFxProcessor&&) noexcept;
    NumberedFxProcessor& operator=(NumberedFxProcessor&&) noexcept;

    void prepare(double sampleRate);
    void reset() noexcept;
    void configure(const NumberedFxState& state) noexcept;
    // Audio-thread snapshot after configure and before process for this block.
    // Only explicitly wired algorithms consume it; it never unlocks DMS in
    // the other families or supplies original packed SET parameter values.
    void setControlFrame(const NumberedFxControlFrame& frame) noexcept;
    [[nodiscard]] bool active() const noexcept;
    void process(float inL, float inR, float& outL, float& outR) noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton::sampler
