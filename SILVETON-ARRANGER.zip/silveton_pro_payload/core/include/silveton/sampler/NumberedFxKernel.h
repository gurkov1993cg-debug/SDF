#pragma once

#include "silveton/sampler/NumberedFxRuntime.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdint>

namespace silveton::sampler::numbered_fx {

inline constexpr double pi = 3.1415926535897932384626433832795;

// Helpers operate in SILVETON semantic units. Nothing here decodes original
// packed SET bytes or supplies a value for an unknown original parameter.
inline double value(const NumberedFxState& s, const char* row, double fallback = 0) noexcept {
    const auto* p = findNumberedFxParam(s.index, row);
    return p && s.known(p->ordinal) ? s.values[p->ordinal] : fallback;
}

inline bool setInitial(NumberedFxState& s, const char* row, double v) noexcept {
    const auto* p = findNumberedFxParam(s.index, row);
    if (!p || !numberedFxValueValid(*p, v)) return false;
    s.values[p->ordinal] = v;
    s.knownMask |= std::uint64_t{1} << p->ordinal;
    return true;
}

inline std::uint64_t completeMask(const NumberedFxDescriptor& d) noexcept {
    std::uint64_t mask = 0;
    for (std::size_t i = 0; i < d.parameterCount; ++i)
        if (d.parameters[i].domainComplete && d.parameters[i].kind != NumberedFxValueKind::Reference)
            mask |= std::uint64_t{1} << d.parameters[i].ordinal;
    return mask;
}

// A source decoder can use the same DSP families as an explicitly selected
// effect only after it has supplied every original semantic row. The manual
// initializer's completeMask intentionally omits unresolved reference rows;
// those omissions must not make an original source block appear complete.
// OwnDesign/sv_ rows are authored controls, never recovered SET parameters.
inline bool decodedSourceStateComplete(const NumberedFxState& state) noexcept {
    if (state.origin != NumberedFxOrigin::Decoded || state.index == 0) return false;
    const auto* d = findNumberedFx(state.index);
    if (!d || !d->manualIdentityConfirmed || !d->parameters || d->parameterCount == 0 ||
        d->parameterCount > kNumberedFxValueCount ||
        (d->completeness != NumberedFxCompleteness::Table &&
         d->completeness != NumberedFxCompleteness::ReferencedTable) || !state.valid()) return false;
    std::uint64_t expected = 0;
    for (std::size_t i = 0; i < d->parameterCount; ++i) {
        const auto& p = d->parameters[i];
        if (p.ordinal != i || !p.rowId || !*p.rowId || std::strncmp(p.rowId, "sv_", 3) == 0 ||
            !p.domainComplete || p.kind == NumberedFxValueKind::Reference || !state.known(p.ordinal))
            return false;
        expected |= std::uint64_t{1} << p.ordinal;
    }
    return state.knownMask == expected;
}

// An original amount/switch setting remains a real saved value even when its
// explicitly linked DMS source is Off (the manual defines Off as no
// modulation). The kernels' static branches do not consume these dormant
// DMS controls. Do not zero them, accept an unknown source, or reinterpret a
// loosely labelled Parameter row as a modulation amount.
inline bool decodedModulationInactive(const NumberedFxState& state,
                                      const NumberedFxParamDescriptor& parameter) noexcept {
    if (state.origin != NumberedFxOrigin::Decoded ||
        (parameter.role != NumberedFxParamRole::ModulationAmount &&
         parameter.role != NumberedFxParamRole::ModulationSwitchMode)) return false;
    const auto* d = findNumberedFx(state.index);
    const int sourceRow = parameter.modulationSourceRow;
    if (!d || parameter.ordinal >= d->parameterCount || &d->parameters[parameter.ordinal] != &parameter ||
        !state.known(parameter.ordinal) || sourceRow < 0 || sourceRow >= d->parameterCount) return false;
    const auto& source = d->parameters[static_cast<std::size_t>(sourceRow)];
    if (source.role != NumberedFxParamRole::ModulationSource || !state.known(source.ordinal) ||
        state.values[source.ordinal] != 0.0 || !source.choices) return false;
    for (std::size_t choice = 0; choice < source.choiceCount; ++choice)
        if (source.choices[choice].value == 0.0 && source.choices[choice].label &&
            std::strcmp(source.choices[choice].label, "Off") == 0) return true;
    return false;
}

inline std::uint64_t editableMainMask(std::uint16_t index) noexcept {
    const auto* d = findNumberedFx(index);
    if (!d) return 0;
    std::uint64_t mask = 0;
    for (std::size_t i = 0; i < d->parameterCount; ++i) {
        const auto& p = d->parameters[i];
        if (p.role == NumberedFxParamRole::Parameter && p.domainComplete &&
            p.kind != NumberedFxValueKind::Reference)
            mask |= std::uint64_t{1} << p.ordinal;
    }
    return mask;
}

inline void lockRow(std::uint64_t& mask, std::uint16_t index, const char* row) noexcept {
    const auto* p = findNumberedFxParam(index, row);
    if (p) mask &= ~(std::uint64_t{1} << p->ordinal);
}

// Only explicitly choosing a manual effect calls this initializer. The base
// convention is our own neutral finite value, subsequently overridden by the
// concrete algorithm. It is never a manufacturer factory preset.
inline bool initializeKnown(std::uint16_t index, NumberedFxState& state) noexcept {
    const auto* d = findNumberedFx(index);
    if (!d || (d->completeness != NumberedFxCompleteness::Table &&
               d->completeness != NumberedFxCompleteness::ReferencedTable &&
               d->completeness != NumberedFxCompleteness::OwnDesign)) return false;
    NumberedFxState next;
    next.index = index;
    next.origin = NumberedFxOrigin::Initial;
    for (std::size_t i = 0; i < d->parameterCount; ++i) {
        const auto& p = d->parameters[i];
        if (!p.domainComplete || p.kind == NumberedFxValueKind::Reference) continue;
        double v = p.rangeKnown ? std::clamp(0.0, p.minimum, p.maximum) :
            (p.choiceCount ? p.choices[0].value : 0.0);
        if (p.kind == NumberedFxValueKind::WetDry || p.kind == NumberedFxValueKind::BipolarWetDry) v = 100;
        if (p.role != NumberedFxParamRole::Parameter) v = 0;
        if (!setInitial(next, p.rowId, v)) return false;
    }
    if (!next.valid()) return false;
    state = next;
    return true;
}

// A concrete algorithm may whitelist individual modulation rows only when a
// real control path exists. The default remains strict DMS-Off for all others.
// A family may also identify newly described rows absent from old manual
// presets, but only while its explicit mode makes them dormant. No value is
// manufactured; original Decoded states never receive this compatibility path.
inline bool baseStateValid(const NumberedFxState& state,
                           std::uint64_t connectedModulationRows = 0,
                           std::uint64_t dormantManualRows = 0) noexcept {
    if (state.origin == NumberedFxOrigin::Decoded) {
        if (!decodedSourceStateComplete(state)) return false;
        // Manual 34/37/42 controller bindings do not establish the original
        // source's controller owner. Source selectors stay explicitly Off;
        // their known dormant amounts/switch settings are retained below.
        connectedModulationRows = 0;
        dormantManualRows = 0;
    } else if (state.origin != NumberedFxOrigin::Initial && state.origin != NumberedFxOrigin::Manual) return false;
    const auto* d = findNumberedFx(state.index);
    if (!d || (d->completeness != NumberedFxCompleteness::Table &&
               d->completeness != NumberedFxCompleteness::ReferencedTable &&
               d->completeness != NumberedFxCompleteness::OwnDesign) || !state.valid() ||
        (state.knownMask | dormantManualRows) != completeMask(*d)) return false;
    for (std::size_t i = 0; i < d->parameterCount; ++i)
        if (d->parameters[i].role != NumberedFxParamRole::Parameter && state.known(i) && state.values[i] != 0 &&
            (connectedModulationRows & (std::uint64_t{1} << i)) == 0 &&
            !decodedModulationInactive(state, d->parameters[i]))
            return false;
    return true;
}

inline double wet(const NumberedFxState& state) noexcept {
    const auto* d = findNumberedFx(state.index);
    if (!d) return 1;
    for (std::size_t i = d->parameterCount; i > 0; --i) {
        const auto& p = d->parameters[i - 1];
        if ((p.kind == NumberedFxValueKind::WetDry || p.kind == NumberedFxValueKind::BipolarWetDry) && state.known(i - 1))
            return state.values[i - 1] * .01;
    }
    return 1;
}

inline float mix(float dry, float processed, double amount) noexcept {
    amount = std::clamp(amount, -1.0, 1.0);
    return static_cast<float>(dry * (1.0 - std::abs(amount)) + processed * amount);
}

inline double db(double v) noexcept { return std::pow(10.0, std::clamp(v, -160.0, 60.0) / 20.0); }
inline float finite(float v) noexcept { return std::isfinite(v) ? v : 0.0F; }
inline double boundedRate(double sr) noexcept { return std::isfinite(sr) && sr > 1000 ? sr : 48000; }

// A borrowed slice of the one prepared slot workspace. A logical reset costs
// O(1); unread history is zero until it has been written in the current epoch.
// read(1) returns the last written sample; read(0) is clamped to that sample.
struct Ring {
    float* data{nullptr};
    std::size_t size{0}, head{0}, valid{0};
    void attach(float* p, std::size_t n) noexcept { data = p; size = n; reset(); }
    void reset() noexcept { head = valid = 0; }
    void push(float sample) noexcept {
        if (!data || !size) return;
        data[head] = finite(sample);
        if (++head == size) head = 0;
        if (valid < size) ++valid;
    }
    float at(std::size_t delay) const noexcept {
        if (!data || delay < 1 || delay > valid || delay > size) return 0;
        return data[head >= delay ? head - delay : size + head - delay];
    }
    float read(double delay) const noexcept {
        if (!data || size < 3 || !std::isfinite(delay)) return 0;
        delay = std::clamp(delay, 1.0, static_cast<double>(size - 1));
        const auto n = static_cast<std::size_t>(delay);
        const float frac = static_cast<float>(delay - n);
        const float a = at(n);
        return a + (at(n + 1) - a) * frac;
    }
};

// RBJ-form biquads written here for our kernels; no manufacturer coefficients
// or firmware code. Coefficients are prepared on configuration, not per sample.
struct Biquad {
    enum class Type { LowPass, HighPass, BandPass, Notch, Peak, LowShelf, HighShelf };
    double b0{1}, b1{0}, b2{0}, a1{0}, a2{0}, z1{0}, z2{0};
    void reset() noexcept { z1 = z2 = 0; }
    void identity() noexcept { b0 = 1; b1 = b2 = a1 = a2 = 0; }
    void configure(Type type, double sr, double hz, double q = .7071067811865476, double gainDb = 0) noexcept {
        sr = boundedRate(sr);
        hz = std::clamp(hz, 5.0, sr * .475);
        q = std::clamp(q, .1, 50.0);
        const double omega = 2 * pi * hz / sr;
        const double c = std::cos(omega), s = std::sin(omega), alpha = s / (2 * q);
        const double a = std::pow(10.0, std::clamp(gainDb, -60.0, 60.0) / 40.0);
        double n0 = 1, n1 = 0, n2 = 0, d0 = 1, d1 = 0, d2 = 0;
        switch (type) {
            case Type::LowPass: n0 = (1-c)/2; n1 = 1-c; n2 = n0; d0 = 1+alpha; d1 = -2*c; d2 = 1-alpha; break;
            case Type::HighPass: n0 = (1+c)/2; n1 = -(1+c); n2 = n0; d0 = 1+alpha; d1 = -2*c; d2 = 1-alpha; break;
            case Type::BandPass: n0 = alpha; n2 = -alpha; d0 = 1+alpha; d1 = -2*c; d2 = 1-alpha; break;
            case Type::Notch: n0 = 1; n1 = -2*c; n2 = 1; d0 = 1+alpha; d1 = -2*c; d2 = 1-alpha; break;
            case Type::Peak: n0 = 1+alpha*a; n1 = -2*c; n2 = 1-alpha*a; d0 = 1+alpha/a; d1 = -2*c; d2 = 1-alpha/a; break;
            case Type::LowShelf: {
                const double t = 2*std::sqrt(a)*alpha;
                n0 = a*((a+1)-(a-1)*c+t); n1 = 2*a*((a-1)-(a+1)*c); n2 = a*((a+1)-(a-1)*c-t);
                d0 = (a+1)+(a-1)*c+t; d1 = -2*((a-1)+(a+1)*c); d2 = (a+1)+(a-1)*c-t; break;
            }
            case Type::HighShelf: {
                const double t = 2*std::sqrt(a)*alpha;
                n0 = a*((a+1)+(a-1)*c+t); n1 = -2*a*((a-1)+(a+1)*c); n2 = a*((a+1)+(a-1)*c-t);
                d0 = (a+1)-(a-1)*c+t; d1 = 2*((a-1)-(a+1)*c); d2 = (a+1)-(a-1)*c-t; break;
            }
        }
        b0 = n0/d0; b1 = n1/d0; b2 = n2/d0; a1 = d1/d0; a2 = d2/d0;
    }
    float process(float x) noexcept {
        const double y = b0*x + z1;
        z1 = b1*x - a1*y + z2;
        z2 = b2*x - a2*y;
        if (!std::isfinite(y) || std::abs(y) > 1.e8) { reset(); return 0; }
        if (std::abs(z1) < 1.e-25) z1 = 0;
        if (std::abs(z2) < 1.e-25) z2 = 0;
        return static_cast<float>(y);
    }
};

} // namespace silveton::sampler::numbered_fx
