#pragma once

#include <thread>
#ifdef __ANDROID__
#include <cstdio>
#include <cstring>
#include <sys/system_properties.h>
#endif

namespace silveton::sampler {

enum class CpuLayout { General, CapacityPair, FrequencyPair, GalaxyA11 };

struct CpuWorkPolicy {
    unsigned cores;
    int renderThreads, audioCpu, backgroundLastCpu;
    int streamFirstCpu, streamLastCpu, midiFirstCpu, midiLastCpu;
    CpuLayout layout;
    constexpr int renderCpu(int worker) const noexcept { return audioCpu - 1 - worker; }
};

constexpr CpuWorkPolicy cpuWorkPolicy(unsigned reportedCores, CpuLayout layout = CpuLayout::General) noexcept {
    const unsigned cores = reportedCores == 0U ? 1U : reportedCores;
    if (cores == 8U && layout != CpuLayout::General)
        return {8U, 2, 7, 2, 3, 4, 5, 5, layout};
    const int threads = cores >= 8U ? 4 : (cores >= 6U ? 3 : (cores >= 4U ? 2 : 1));
    const int top = static_cast<int>(cores) - 1;
    const int last = top >= threads ? top - threads : 0;
    const int background = last >= 3 ? last - 2 : last;
    return {cores, threads, top, background, last >= 3 ? last - 1 : 0, last, 0, background, CpuLayout::General};
}

#ifdef __ANDROID__
// Compare the complete eight-core layout. Instantaneous frequency depends on load.
inline bool hasFastUpperPair(const char* sysfs, const char* attribute) noexcept {
    long highestSmall = 0;
    for (int cpu = 0; cpu < 8; ++cpu) {
        char path[256];
        std::snprintf(path, sizeof(path), "%s/cpu%d/%s", sysfs, cpu, attribute);
        auto* file = std::fopen(path, "r");
        if (!file) return false;
        long value = 0;
        const bool valid = std::fscanf(file, "%ld", &value) == 1 && value > 0;
        std::fclose(file);
        if (!valid) return false;
        if (cpu < 6) { if (value > highestSmall) highestSmall = value; }
        else if (value <= highestSmall) return false;
    }
    return true;
}

inline CpuLayout detectCpuLayout(unsigned cores, const char* sysfs, const char* model) noexcept {
    if (cores != 8U) return CpuLayout::General;
    if (hasFastUpperPair(sysfs, "cpu_capacity")) return CpuLayout::CapacityPair;
    if (hasFastUpperPair(sysfs, "cpufreq/cpuinfo_max_freq")) return CpuLayout::FrequencyPair;
    return std::strcmp(model, "SM-X130") == 0 ? CpuLayout::GalaxyA11 : CpuLayout::General;
}
#endif

// Initialized before the app pins the UI thread or starts audio and MIDI.
inline const CpuWorkPolicy& deviceCpuWorkPolicy() noexcept {
    static const CpuWorkPolicy placement = [] {
        const unsigned cores = std::thread::hardware_concurrency();
#ifdef __ANDROID__
        char model[PROP_VALUE_MAX]{};
        __system_property_get("ro.product.model", model);
        return cpuWorkPolicy(cores, detectCpuLayout(cores, "/sys/devices/system/cpu", model));
#else
        return cpuWorkPolicy(cores);
#endif
    }();
    return placement;
}

} // namespace silveton::sampler
