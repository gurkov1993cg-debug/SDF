#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace silveton::sampler {

// Our semantic selector numbers match NumberedFxData.inc's displayed choices.
// They are not Korg wire values or offsets in the original SET parameter block.
enum class NumberedFxControlSource : std::uint8_t {
    Off = 0, Gate1 = 1, Gate1Damper = 2, Gate2 = 3, Gate2Damper = 4,
    NoteNumber = 5, Velocity = 6, ExponentialVelocity = 7,
    AfterTouch = 8, JoystickX = 9, JoystickYPositive = 10,
    JoystickYNegative = 11, CC04 = 12, CC12 = 13, CC13 = 14,
    RibbonCC16 = 15, CC18 = 16, CC17 = 17, CC19 = 18, CC20 = 19,
    CC21 = 20, CC17Plus = 21, CC19Plus = 22, CC20Plus = 23,
    CC21Plus = 24, DamperCC64 = 25, PortamentoCC65 = 26,
    SostenutoCC66 = 27, CC67 = 28, CC80 = 29, CC81 = 30,
    CC82 = 31, CC83 = 32, CC85 = 33, CC86 = 34, CC87 = 35,
    CC88 = 36, Tempo = 37
};

inline constexpr std::size_t kNumberedFxControlSourceCount = 38;

// Only sources with a real, understood input are exposed by this first control
// path. No note-priority rule, exponential law, CC+ transform or tempo signal is
// inferred from the list order. Those sources stay unavailable.
[[nodiscard]] inline constexpr bool numberedFxControlSourceSupported(int source) noexcept {
    return (source >= 0 && source <= 4) ||
           (source >= 8 && source <= 20) ||
           (source >= 25 && source <= 36);
}

[[nodiscard]] inline constexpr int numberedFxControlSourceCc(int source) noexcept {
    switch (source) {
        case 10: return 1; case 11: return 2; case 12: return 4;
        case 13: return 12; case 14: return 13; case 15: return 16;
        case 16: return 18; case 17: return 17; case 18: return 19;
        case 19: return 20; case 20: return 21;
        case 25: return 64; case 26: return 65; case 27: return 66;
        case 28: return 67; case 29: return 80; case 30: return 81;
        case 31: return 82; case 32: return 83; case 33: return 85;
        case 34: return 86; case 35: return 87; case 36: return 88;
        default: return -1;
    }
}

// A snapshot of one logical performance part, made by the audio thread after
// its existing ordered MIDI drain. RealtimeEvent has no sample timestamp: this
// is explicitly block-rate input, not an invented sample-accurate time line.
// A/B outgoing FX tails keep their last snapshot, with frozen=true. They must
// not receive new-owner events or continue recording a new silent input.
struct NumberedFxControlFrame {
    // Physical position in [0,1]. CCs use MIDI/127. Joystick X uses separate
    // negative/positive 14-bit slopes so centre is exactly0.5 and endpoints0/1.
    std::array<float, kNumberedFxControlSourceCount> values{};
    std::array<std::uint64_t, kNumberedFxControlSourceCount> rises{};
    // Baseline before this block's event drain. A newly assigned algorithm may
    // consume real events from this block without synthesizing an edge merely
    // because a controller was already high in a preceding block.
    std::array<std::uint64_t, kNumberedFxControlSourceCount> blockStartRises{};
    std::uint64_t availableMask{0};
    // Nominal source >=64. CCs use the exact63/64 boundary; joystick X crosses
    // at raw pitch-bend zero (its nominal centre64), independently of position.
    std::uint64_t highMask{0};
    // Unique binding epoch for a logical part; changes on owner recall or
    // channel rebind. Distinct parts have distinct epochs even in one owner.
    std::uint64_t ownerGeneration{0};
    bool frozen{false};

    [[nodiscard]] bool available(int source) const noexcept {
        return source >= 0 && source < static_cast<int>(kNumberedFxControlSourceCount) &&
               (availableMask & (std::uint64_t{1} << source)) != 0;
    }
    [[nodiscard]] float position(int source) const noexcept {
        return available(source) ? values[static_cast<std::size_t>(source)] : 0.0F;
    }
    [[nodiscard]] bool high(int source) const noexcept {
        return available(source) && (highMask & (std::uint64_t{1} << source)) != 0;
    }
    [[nodiscard]] std::uint64_t triggerSerial(int source) const noexcept {
        return available(source) ? rises[static_cast<std::size_t>(source)] : 0;
    }
};

} // namespace silveton::sampler
