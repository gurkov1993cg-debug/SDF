#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>

namespace silveton::sampler {

// This namespace is independent of EffectType and of the original Korg packed
// parameter bytes. Values are SILVETON semantic values in the displayed units.
// Enumeration values below are our own stable choices, never Korg wire enums.
inline constexpr std::size_t kNumberedFxValueCount = 64;
inline constexpr std::uint16_t kNumberedFxSchema = 1;
inline constexpr std::uint16_t kUnboundNumberedFxIndex = 0xffff;

enum class NumberedFxOrigin : std::uint8_t {
    Unknown = 0,
    Initial = 1, // Explicit SILVETON initialization, not a Korg factory default.
    Decoded = 2, // Only fields established by a separate source decoder.
    Manual = 3
};

struct NumberedFxState {
    std::uint16_t schema{kNumberedFxSchema};
    std::uint16_t index{0};
    std::uint64_t knownMask{0};
    std::array<double, kNumberedFxValueCount> values{};
    NumberedFxOrigin origin{NumberedFxOrigin::Unknown};

    [[nodiscard]] bool known(std::size_t row) const noexcept {
        return row < kNumberedFxValueCount && (knownMask & (std::uint64_t{1} << row)) != 0;
    }
    [[nodiscard]] bool valid() const noexcept;
};

enum class NumberedFxValueKind : std::uint8_t {
    Numeric,
    Enumeration,
    RangeWithChoices, // Finite numeric range plus explicitly labelled sentinels.
    WetDry,           // 0 = Dry, 100 = Wet; displayed between as wet:dry.
    BipolarWetDry,    // -100..100, negative wet has inverted polarity.
    Reference        // Exact printed domain retained, not safely enumerated.
};
enum class NumberedFxParamRole : std::uint8_t {
    Parameter, ModulationSource, ModulationAmount, ModulationSwitchMode
};
enum class NumberedFxValueFormat : std::uint8_t {
    Plain, RatioToOne, Multiplier, SignedPan, NoteName, Balance
};
enum class NumberedFxCompleteness : std::uint8_t {
    Table, CrossReferenceOnly, UnconfirmedIdentity, Bypass,
    ReferencedTable, // Own shared controls inferred from an explicit stereo/base cross-reference.
    OwnDesign // Explicit authored controls under the exact official index/name; not Korg domains.
};

// Finite semantic sentinels; these values are neither physical magnitudes nor
// original serialized enums. They remain separate from the normal value range.
inline constexpr double kNumberedFxChoiceBase = -1000000.0;
struct NumberedFxChoice {
    const char* label;
    double value;
};

struct NumberedFxParamDescriptor {
    std::uint8_t ordinal;
    const char* rowId;       // Stable manual anchor or authored "sv_" ID; never a byte offset.
    const char* label;
    const char* group;
    const char* section;
    const char* description;
    const char* printedRange;
    const char* unit;
    NumberedFxValueKind kind;
    NumberedFxParamRole role;
    NumberedFxValueFormat format;
    double minimum;
    double maximum;
    const NumberedFxChoice* choices;
    std::uint16_t choiceCount;
    std::uint16_t manualPage;
    std::int16_t groupFirstRow;
    std::int16_t modulationSourceRow; // -1 when no source relationship is established.
    std::int16_t modulationTargetRow; // -1 for a group/relationship not uniquely resolved.
    std::uint8_t displayDecimals;
    bool domainComplete;
    bool rangeKnown;
    // The manual does not generally give increments or factory defaults.
    // Display precision is not asserted to be the original knob increment.
    bool stepKnown;
    double step;
};

struct NumberedFxDescriptor {
    std::uint16_t index;
    const char* name;
    const char* manualId;
    const char* manualName;
    const char* category;
    const char* functionBg;
    const char* limitation;
    const NumberedFxParamDescriptor* parameters;
    std::uint8_t parameterCount;
    std::uint16_t firstManualPage;
    std::uint16_t lastManualPage;
    NumberedFxCompleteness completeness;
    bool manualIdentityConfirmed;
};

// The production catalog contains 0 (Bypass) plus all 153 official indices,
// preserving gaps and duplicate names. Authored rows are marked OwnDesign and
// never presented as recovered original manual/serialized parameter fields.
[[nodiscard]] const NumberedFxDescriptor* numberedFxDescriptors(std::size_t& count) noexcept;
[[nodiscard]] const NumberedFxDescriptor* findNumberedFx(std::uint16_t index) noexcept;
[[nodiscard]] const NumberedFxParamDescriptor* findNumberedFxParam(
    std::uint16_t index, const char* rowId) noexcept;
// Includes the two unbound manual Amp Modded OD tables without assigning them
// to the unconfirmed firmware Amp XTC identities.
[[nodiscard]] const NumberedFxDescriptor* findNumberedFxManual(const char* manualId) noexcept;
[[nodiscard]] bool numberedFxValueValid(const NumberedFxParamDescriptor& parameter, double value) noexcept;
[[nodiscard]] bool numberedFxStateValid(const NumberedFxState& state) noexcept;

// UI/control thread only. Missing values display as unknown, never as zero.
[[nodiscard]] std::string formatNumberedFxValue(const NumberedFxParamDescriptor& parameter, double value);
[[nodiscard]] std::string formatNumberedFxValue(const NumberedFxState& state, std::size_t row);
[[nodiscard]] const char* numberedFxOriginName(NumberedFxOrigin origin) noexcept;

} // namespace silveton::sampler
