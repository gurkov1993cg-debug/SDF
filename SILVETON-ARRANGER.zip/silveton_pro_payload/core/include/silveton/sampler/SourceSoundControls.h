#pragma once

#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::sampler {

// Saved Pa oscillator controls remain attached to each ProgramLayer. They are
// not an Upper-wide portamento override: one Sound can contain oscillators with
// different Enable, Fingered and Time settings.
struct SourcePortamento {
    bool present{false};
    bool encodingSupported{false};
    std::uint8_t resourceVersion{0};
    std::uint8_t flagsRaw{0};
    std::uint8_t timeRaw{0};
    std::uint8_t extensionByteCount{0};
    std::array<std::uint8_t,2> extensionRaw{};

    bool valid() const noexcept {
        if(!present)return !encodingSupported;
        if(resourceVersion==4U||resourceVersion>8U||extensionByteCount>2U)return false;
        // Only the corroborated legacy two-bit encoding is executable. Pa's
        // extra mode bit and newer adjacent fields are retained, not guessed.
        return !encodingSupported||(resourceVersion<=3U&&flagsRaw<=3U&&
            timeRaw<=127U&&extensionByteCount==0U);
    }
    bool basicPlaybackSupported() const noexcept {
        if(!present||!valid()||flagsRaw>3U||timeRaw>127U)return false;
        if(encodingSupported)return true;
        return resourceVersion>=6U&&resourceVersion<=8U&&extensionByteCount==2U&&
            extensionRaw[0]==0U&&extensionRaw[1]==0U;
    }
    bool enabled() const noexcept {
        return basicPlaybackSupported()&&(flagsRaw&1U)!=0U;
    }
    bool fingered() const noexcept {return (flagsRaw&2U)!=0U;}

    // SILVETON's own fixed-time glide. This is an explicitly authored playback
    // scale, not a decoded Korg time law or an inferred Rate/Time flag. The
    // original 0..127 index is preserved; 0 is immediate, 127 is five seconds.
    float seconds() const noexcept {
        if(!enabled())return 0.0F;
        const float normalized=static_cast<float>(timeRaw)/127.0F;
        return 5.0F*std::pow(normalized,2.2F);
    }
    bool operator==(const SourcePortamento& other) const noexcept {
        return present==other.present&&encodingSupported==other.encodingSupported&&
            resourceVersion==other.resourceVersion&&flagsRaw==other.flagsRaw&&
            timeRaw==other.timeRaw&&extensionByteCount==other.extensionByteCount&&
            extensionRaw==other.extensionRaw;
    }
};

enum class SourceNotePriority : std::uint8_t { Low, High, Last, Unknown=255U };
enum class SourceLegatoMode : std::uint8_t { Off, Legato, Offset, Unknown=255U };

struct SourceVoiceAssignment {
    bool present{false};
    std::uint8_t resourceVersion{0};
    std::uint8_t flagsRaw{0};
    // Revision 8 inserts these two original common bytes immediately before
    // Pitch EG. Their presence is explicit so a legacy SVSP v1 snapshot does
    // not acquire a mode that was never retained in that snapshot.
    bool legatoModePresent{false};
    std::uint8_t legatoModeRaw{0};
    std::uint8_t legatoExtensionRaw{0};

    bool valid() const noexcept {
        if(!present)return !legatoModePresent;
        return resourceVersion!=4U&&resourceVersion<=8U&&(flagsRaw&2U)==0U&&
            (!legatoModePresent||resourceVersion==8U);
    }
    // Independently corroborated by paired original Pa Mono/Poly programs,
    // including otherwise identical revision-8 common blocks.
    bool mono() const noexcept {return present&&valid()&&(flagsRaw&4U)!=0U;}
    // The legacy common byte retains the corroborated Legato/Priority fields.
    bool legacyControlsSupported() const noexcept {
        return present&&valid()&&resourceVersion<=3U;
    }
    bool legatoControlsSupported() const noexcept {
        if(legacyControlsSupported())return true;
        // Pa's own GUI declares Off/Legato/Offset in this order. In all 212
        // original revision-8 Sounds, value 1 exactly mirrors the older Legato
        // bit, while 0 and 2 clear it. The unassigned adjacent byte must be 0.
        return present&&valid()&&resourceVersion==8U&&legatoModePresent&&
            legatoModeRaw<=2U&&legatoExtensionRaw==0U&&
            (((flagsRaw&8U)!=0U)==(legatoModeRaw==1U));
    }
    SourceLegatoMode legatoMode() const noexcept {
        if(legacyControlsSupported())
            return (flagsRaw&8U)!=0U?SourceLegatoMode::Legato:SourceLegatoMode::Off;
        return legatoControlsSupported()?static_cast<SourceLegatoMode>(legatoModeRaw):
            SourceLegatoMode::Unknown;
    }
    bool legatoPlaybackSupported() const noexcept {
        const auto mode=legatoMode();
        return mode==SourceLegatoMode::Off||mode==SourceLegatoMode::Legato;
    }
    bool legato() const noexcept {
        return mono()&&legatoMode()==SourceLegatoMode::Legato;
    }
    bool legatoOffset() const noexcept {
        return mono()&&legatoMode()==SourceLegatoMode::Offset;
    }
    SourceNotePriority priority() const noexcept {
        const auto value=static_cast<std::uint8_t>((flagsRaw>>4U)&3U);
        return legacyControlsSupported()&&value<=2U?
            static_cast<SourceNotePriority>(value):SourceNotePriority::Unknown;
    }
};

} // namespace silveton::sampler
