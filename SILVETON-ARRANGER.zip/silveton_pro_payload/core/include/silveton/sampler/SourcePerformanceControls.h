#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include "silveton/sampler/SourceSoundControls.h"

namespace silveton::sampler {

// Original performance edits belong to a track/Keyboard Set part, never to
// the shared Program. Pa5X User Manual v1.5 pp.487,615-617: CC71..78 are
// Resonance, Release, Attack, Cutoff, Decay, Vibrato Speed/Depth/Delay.
// The stored MIDI value is exact; 64 is the neutral offset. -1 is absent.
struct SourceSoundEdits {
    std::array<std::int16_t,8> raw{{-1,-1,-1,-1,-1,-1,-1,-1}};
    std::int16_t portamentoTimeRaw{-1}; // CC5, 0..127
    std::int16_t portamentoOnRaw{-1};   // CC65, <64 off, >=64 on

    bool valid() const noexcept {
        const auto value=[](int v) noexcept {return v>=-1&&v<=127;};
        if(!value(portamentoTimeRaw)||!value(portamentoOnRaw))return false;
        for(const auto v:raw)if(!value(v))return false;
        return true;
    }
    bool present() const noexcept {
        if(portamentoTimeRaw>=0||portamentoOnRaw>=0)return true;
        for(const auto v:raw)if(v>=0)return true;
        return false;
    }
    int controller(int cc) const noexcept {
        if(cc>=71&&cc<=78)return raw[static_cast<std::size_t>(cc-71)];
        if(cc==5)return portamentoTimeRaw;
        if(cc==65)return portamentoOnRaw;
        return -1;
    }
    bool setController(int cc,int value) noexcept {
        if(value< -1||value>127)return false;
        if(cc>=71&&cc<=78)raw[static_cast<std::size_t>(cc-71)]=static_cast<std::int16_t>(value);
        else if(cc==5)portamentoTimeRaw=static_cast<std::int16_t>(value);
        else if(cc==65)portamentoOnRaw=static_cast<std::int16_t>(value);
        else return false;
        return true;
    }
    bool operator==(const SourceSoundEdits& other) const noexcept {
        return raw==other.raw&&portamentoTimeRaw==other.portamentoTimeRaw&&
            portamentoOnRaw==other.portamentoOnRaw;
    }
    bool operator!=(const SourceSoundEdits& other) const noexcept {return !(*this==other);}
};

// Shared resolution for playback and the Keyboard Set editor. Explicit Off
// is authoritative. An explicit time alone does not enable an oscillator.
inline bool sourcePortamentoOn(const SourcePortamento& source,const SourceSoundEdits& edits) noexcept {
    const int on=edits.controller(65);
    return on>=0?on>=64:source.enabled();
}
inline int sourcePortamentoTimeIndex(const SourcePortamento& source,const SourceSoundEdits& edits) noexcept {
    const int time=edits.controller(5);
    if(time>=0)return time;
    return source.basicPlaybackSupported()?source.timeRaw:-1;
}
inline float sourcePortamentoPlaybackSeconds(const SourcePortamento& source,const SourceSoundEdits& edits,bool previousKeyHeld) noexcept {
    if(!sourcePortamentoOn(source,edits))return 0.0F;
    if(source.basicPlaybackSupported()&&source.fingered()&&!previousKeyHeld)return 0.0F;
    return SourcePortamento::indexSeconds(sourcePortamentoTimeIndex(source,edits));
}

// One ordered MIDI channel stream. NRPN and RPN families never share a
// partially selected parameter. Only the documented unambiguous NRPN1
// aliases below are applied. In particular NRPN1/10 says "Vibrato Decay"
// while CC78 says "initial delay"; they are not silently equated.
struct SourceSoundEditReader {
    enum class Family : std::uint8_t {None,Rpn,Nrpn};
    Family family{Family::None};
    int msb{-1},lsb{-1};
    bool incompleteSelection{false},relativeValueUnknown{false};

    bool controller(SourceSoundEdits& edits,int cc,int value) noexcept {
        if(cc<0||cc>127||value<0||value>127)return false;
        if(edits.setController(cc,value))return true;
        if(cc==99||cc==98||cc==101||cc==100){
            const auto next=cc==99||cc==98?Family::Nrpn:Family::Rpn;
            if(next!=family){msb=-1;lsb=-1;}
            family=next;
            if(cc==99||cc==101)msb=value;else lsb=value;
            return false;
        }
        if(cc==121){
            // Reset selection and the portamento switch, not Sound edits.
            // Sound Controllers70..79 retain their values (MMA RP-015;
            // also AMEI/MMA M2-113-UM v1.0 Appendix A, pp.7-9).
            family=Family::None;msb=-1;lsb=-1;
            return edits.setController(65,0);
        }
        if(cc!=6&&cc!=96&&cc!=97)return false;
        if(family!=Family::Nrpn||(msb==127&&lsb==127))return false;
        if(msb<0||lsb<0){incompleteSelection=true;return false;}
        if(msb!=1)return false;
        int target=-1;
        switch(lsb){
            case 9:target=77;break;
            case 32:target=74;break;
            case 33:target=71;break;
            case 99:target=73;break;
            case 100:target=75;break;
            case 102:target=72;break;
            default:return false;
        }
        if(cc==96||cc==97){
            // No guessed starting value or manufacturer-specific increment.
            relativeValueUnknown=true;return edits.setController(target,-1);
        }
        return edits.setController(target,value); // CC6 is the complete 7-bit value.
    }
};

// SILVETON's own continuous response laws. These preserve the exact source
// MIDI value but do not claim Korg's undocumented physical transfer curves.
inline float sourceSoundEditOffset(int raw) noexcept {
    return raw>=0&&raw<=127?static_cast<float>(raw-64):0.0F;
}
inline float sourceSoundEditTimeMs(float originalMs,int raw) noexcept {
    if(!std::isfinite(originalMs))return 0.0F;
    if(raw<0||raw==64)return std::clamp(originalMs,0.0F,60000.0F);
    // The 1ms anchor permits a positive edit of an originally instant stage.
    return std::clamp((std::max(0.0F,originalMs)+1.0F)*
        std::exp2(sourceSoundEditOffset(raw)/16.0F)-1.0F,0.0F,60000.0F);
}
inline float sourceSoundEditRateScale(int raw) noexcept {
    return std::exp2(sourceSoundEditOffset(raw)/32.0F);
}
inline float sourceSoundEditDepthCents(float originalCents,int raw) noexcept {
    if(!std::isfinite(originalCents))return 0.0F;
    // A missing/neutral source edit cannot narrow an existing native LFO.
    // Native PROGRAM depth permits up to2400cents; the caller preserves sign.
    if(raw<0||raw>127||raw==64)return originalCents;
    return std::clamp(originalCents+sourceSoundEditOffset(raw),0.0F,2400.0F);
}
inline float sourceSoundEditCutoffOctaves(int raw) noexcept {
    return sourceSoundEditOffset(raw)/16.0F;
}
inline float sourceSoundEditResonance(int raw) noexcept {
    return sourceSoundEditOffset(raw)/64.0F;
}

} // namespace silveton::sampler
