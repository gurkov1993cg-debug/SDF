#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::sampler {

enum class SourceOscillatorModule : std::uint16_t {
    Pitch=1U, PitchEnvelope=2U, Filter=4U, FilterEnvelope=8U,
    Lfo1=16U, Lfo2=32U, Amplitude=64U, Pan=128U, Equalizer=256U, Level=512U
};

// Immutable original Sound controls. The normalized retained block keeps the
// original byte values; normalization only removes documented versioned
// insertions, which are retained separately. No seconds, Hz, gain or derived
// "applied" state is serialized here. Each runtime module validates the fields
// it actually consumes. Unknown fields remain visible and round-trip intact.
struct SourceOscillatorDsp {
    std::uint8_t resourceVersion{0U};
    std::uint8_t oscillatorIndex{0U};
    bool highSource{true};
    bool layoutCorroborated{false};
    std::array<std::uint8_t,90> dspRaw{};
    std::array<std::uint8_t,20> lfoRaw{};
    std::array<std::uint8_t,22> amplitudeEnvelopeRaw{};
    std::array<std::uint8_t,5> additionalDspRaw{};
    std::uint8_t additionalDspBytes{0U};
    std::array<std::uint8_t,14> pitchEnvelopeRaw{};
    bool pitchEnvelopePresent{false};
    std::array<std::uint8_t,4> outputRaw{};
    bool outputRawPresent{false};
    std::array<std::uint8_t,6> equalizerRaw{};
    bool equalizerPresent{false};
    std::uint8_t multisampleLevelRaw{0U};
    bool multisampleLevelDecoded{false};
    std::uint8_t delayRaw{0U};
    std::array<std::uint8_t,2> scaledVelocityRaw{{0U,127U}};
    bool scaledVelocityDecoded{false};
    // Original OSC zone, before the High/Low multisample switch divides it
    // into ProgramLayers. Those divided ranges cannot reconstruct this input
    // interval. Schema1 did not retain it, so absence stays explicit.
    std::array<std::uint8_t,2> velocityZoneRaw{{0U,127U}};
    bool velocityZonePresent{false};
    // Explicit native Program edits replace only their own original module.
    // This is user state, not an inferred decoder/playback capability flag.
    std::uint16_t manualOverrideMask{0U};

    constexpr bool overridden(SourceOscillatorModule module) const noexcept {
        return (manualOverrideMask&static_cast<std::uint16_t>(module))!=0U;
    }

    constexpr bool framingValid() const noexcept {
        const bool old=resourceVersion<=3U;
        const bool newer=resourceVersion>=5U&&resourceVersion<=8U;
        if(!old&&!newer)return false;
        const unsigned expected=old?0U:resourceVersion==5U?3U:5U;
        return additionalDspBytes==expected&&(manualOverrideMask&~1023U)==0U;
    }
    bool samePlaybackSettings(const SourceOscillatorDsp& other) const noexcept {
        return resourceVersion==other.resourceVersion&&layoutCorroborated==other.layoutCorroborated&&
            dspRaw==other.dspRaw&&lfoRaw==other.lfoRaw&&amplitudeEnvelopeRaw==other.amplitudeEnvelopeRaw&&
            additionalDspRaw==other.additionalDspRaw&&additionalDspBytes==other.additionalDspBytes&&
            pitchEnvelopeRaw==other.pitchEnvelopeRaw&&pitchEnvelopePresent==other.pitchEnvelopePresent&&
            outputRaw==other.outputRaw&&outputRawPresent==other.outputRawPresent&&
            equalizerRaw==other.equalizerRaw&&equalizerPresent==other.equalizerPresent&&
            multisampleLevelRaw==other.multisampleLevelRaw&&multisampleLevelDecoded==other.multisampleLevelDecoded&&
            delayRaw==other.delayRaw&&scaledVelocityRaw==other.scaledVelocityRaw&&
            scaledVelocityDecoded==other.scaledVelocityDecoded&&
            velocityZonePresent==other.velocityZonePresent&&
            (!velocityZonePresent||velocityZoneRaw==other.velocityZoneRaw)&&
            manualOverrideMask==other.manualOverrideMask;
    }
    bool operator==(const SourceOscillatorDsp& other) const noexcept {
        return oscillatorIndex==other.oscillatorIndex&&highSource==other.highSource&&samePlaybackSettings(other);
    }
};

// SVOD schema1 is fixed178bytes. Schema2 appends the retained original OSC
// velocity zone (flag, bottom, top). Older source profiles still emit exactly
// schema1, preserving their identity and bytes. Both schemas are independent
// of compiler struct layout and the SET/prepared snapshot ABI.
inline std::vector<std::uint8_t> encodeSourceOscillatorDsp(const SourceOscillatorDsp& source) {
    if(!source.framingValid())return {};
    std::vector<std::uint8_t> bytes;
    bytes.reserve(source.velocityZonePresent?181U:178U);
    const auto flag=[](bool value){return static_cast<std::uint8_t>(value?1U:0U);};
    bytes.push_back(source.velocityZonePresent?2U:1U);bytes.push_back(source.resourceVersion);bytes.push_back(source.oscillatorIndex);
    bytes.push_back(flag(source.highSource));bytes.push_back(flag(source.layoutCorroborated));
    const auto append=[&](const auto& values){bytes.insert(bytes.end(),values.begin(),values.end());};
    append(source.dspRaw);append(source.lfoRaw);append(source.amplitudeEnvelopeRaw);
    bytes.push_back(source.additionalDspBytes);append(source.additionalDspRaw);
    bytes.push_back(flag(source.pitchEnvelopePresent));append(source.pitchEnvelopeRaw);
    bytes.push_back(flag(source.outputRawPresent));append(source.outputRaw);
    bytes.push_back(flag(source.equalizerPresent));append(source.equalizerRaw);
    bytes.push_back(source.multisampleLevelRaw);bytes.push_back(flag(source.multisampleLevelDecoded));
    bytes.push_back(source.delayRaw);append(source.scaledVelocityRaw);bytes.push_back(flag(source.scaledVelocityDecoded));
    bytes.push_back(static_cast<std::uint8_t>(source.manualOverrideMask&255U));
    bytes.push_back(static_cast<std::uint8_t>(source.manualOverrideMask>>8U));
    if(source.velocityZonePresent){
        bytes.push_back(flag(source.velocityZonePresent));append(source.velocityZoneRaw);
    }
    return bytes;
}

inline bool decodeSourceOscillatorDsp(const std::vector<std::uint8_t>& bytes,
                                      SourceOscillatorDsp& source,std::string& error) {
    // Exact exhaustion rejects truncated, extended and incompatible payloads.
    const bool schema1=bytes.size()==178U&&bytes[0]==1U;
    const bool schema2=bytes.size()==181U&&bytes[0]==2U;
    if(!schema1&&!schema2){error="Invalid source oscillator metadata framing";return false;}
    SourceOscillatorDsp next;
    std::size_t at=1U;
    bool valid=true;
    const auto byte=[&]() noexcept {return bytes[at++];};
    const auto flag=[&]() noexcept {const auto value=byte();if(value>1U)valid=false;return value==1U;};
    const auto read=[&](auto& values) noexcept {for(auto& value:values)value=byte();};
    next.resourceVersion=byte();next.oscillatorIndex=byte();
    next.highSource=flag();next.layoutCorroborated=flag();
    read(next.dspRaw);read(next.lfoRaw);read(next.amplitudeEnvelopeRaw);
    next.additionalDspBytes=byte();read(next.additionalDspRaw);
    next.pitchEnvelopePresent=flag();read(next.pitchEnvelopeRaw);
    next.outputRawPresent=flag();read(next.outputRaw);
    next.equalizerPresent=flag();read(next.equalizerRaw);
    next.multisampleLevelRaw=byte();next.multisampleLevelDecoded=flag();
    next.delayRaw=byte();read(next.scaledVelocityRaw);next.scaledVelocityDecoded=flag();
    const auto maskLow=byte();const auto maskHigh=byte();
    next.manualOverrideMask=static_cast<std::uint16_t>(static_cast<unsigned>(maskLow)|
        (static_cast<unsigned>(maskHigh)<<8U));
    if(schema2){
        next.velocityZonePresent=flag();read(next.velocityZoneRaw);
        // The writer uses schema1 for absent zones. Reject noncanonical2/0
        // instead of accepting bytes that would silently lose their tail.
        if(!next.velocityZonePresent)valid=false;
    }
    if(!valid||at!=bytes.size()||!next.framingValid()){
        error="Invalid source oscillator metadata fields";return false;
    }
    source=next;error.clear();return true;
}

} // namespace silveton::sampler
