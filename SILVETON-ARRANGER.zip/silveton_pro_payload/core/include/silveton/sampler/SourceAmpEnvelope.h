#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/SourceModulation.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::sampler {

struct SourceAmpNoteIndices {
    std::array<float,4> levels{},times{};
};

inline SourceAmpNoteIndices sourceAmpNoteIndices(const SourceAmpEnvelope& source,
                                                const SourceModulationValues& inputs) noexcept {
    SourceAmpNoteIndices note;
    for(unsigned i=0;i<4U;++i){note.levels[i]=source.levels[i];note.times[i]=source.times[i];}
    if(!source.modulationEncodingSupported)return note;
    for(unsigned route=0;route<source.amsSources.size();++route){
        const float amount=static_cast<float>(source.amsIntensities[route])*inputs[source.amsSources[route]];
        auto& indices=route==2U?note.levels:note.times;
        for(unsigned segment=0;segment<(route==2U?3U:4U);++segment){
            const auto code=(static_cast<unsigned>(source.amsDirections[route])>>(2U*segment))&3U;
            const float direction=code==1U?1.0F:code==3U?-1.0F:0.0F;
            indices[segment]+=direction*amount;
        }
    }
    // Sum independent AMS routes before clamping. Raw saved values and their
    // signs remain untouched; fractional modulation is not quantized to bytes.
    for(unsigned i=0;i<4U;++i){
        note.levels[i]=std::clamp(note.levels[i],0.0F,99.0F);
        note.times[i]=std::clamp(note.times[i],0.0F,99.0F);
    }
    return note;
}

inline SourceAmpNoteIndices sourceAmpNoteIndices(const SourceAmpEnvelope& source,
                                                std::uint8_t key,std::uint8_t velocity) noexcept {
    SourceModulationContext context;context.key=key;context.velocity=velocity;
    context.amplitudeKeys=source.keyboardKeys;context.amplitudeRamps=source.keyboardRamps;
    context.filterKeys=source.filterKeyboardKeys;context.filterRamps=source.filterKeyboardRamps;
    return sourceAmpNoteIndices(source,sourceModulationValues(context));
}

// Per-voice, allocation-free realization of the saved four-level Sound EG.
// Linear segments, squared level gain and the index-to-time curve are our own
// approximation. Only explicitly corroborated AMS sources/directions enter it.
class SourceAmpCursor {
public:
    enum class Stage : std::uint8_t { Idle, Attack, Decay, Slope, Sustain, Release };
    Stage stage{Stage::Idle};
    float value{0.0F};
    EnvelopeParams defaults{};

    void prepare(const SourceAmpEnvelope& source,std::uint8_t key,std::uint8_t velocity) noexcept {
        forceOff();frames_={};targets_={};
        rekey(source,key,velocity);
        targets_[2]=defaults.sustain;
    }

    void rekey(const SourceAmpEnvelope& source,std::uint8_t key,std::uint8_t velocity,
               const SourceModulationValues* modulation=nullptr) noexcept {
        const auto note=modulation==nullptr?sourceAmpNoteIndices(source,key,velocity):sourceAmpNoteIndices(source,*modulation);
        start_ = SourceAmpEnvelope::levelGain(note.levels[0]);
        const float attack=SourceAmpEnvelope::levelGain(note.levels[1]);
        const float breakpoint=SourceAmpEnvelope::levelGain(note.levels[2]);
        const bool targetChanged=(stage==Stage::Attack&&targets_[0]!=attack)||
            (stage==Stage::Decay&&targets_[1]!=breakpoint);
        targets_[0]=attack;targets_[1]=breakpoint;
        const float decay=SourceAmpEnvelope::timeSeconds(note.times[1]);
        defaults={SourceAmpEnvelope::timeSeconds(note.times[0]),
            decay+SourceAmpEnvelope::timeSeconds(note.times[2]),
            SourceAmpEnvelope::levelGain(note.levels[3]),SourceAmpEnvelope::timeSeconds(note.times[3])};
        // The performer's Decay edit scales Decay and Slope together, keeping
        // their source-modulated proportions and the original Break endpoint.
        decayShare_ = defaults.decaySec > 0.0F ? decay / defaults.decaySec : 0.5F;
        if(targetChanged)retime();
    }

    void configure(float attackMs, float decayMs, float sustain, float releaseMs,
                   double rate) noexcept {
        const double sampleRate = std::max(1.0, rate);
        const auto frames = [sampleRate](float ms) noexcept {
            return std::isfinite(ms) ? std::clamp(static_cast<double>(ms), 0.0, 60000.0) * .001 * sampleRate : 0.0;
        };
        const double decayFrames = frames(decayMs);
        const std::array<double,4> nextFrames{frames(attackMs), decayFrames * decayShare_,
            decayFrames * (1.0 - decayShare_), frames(releaseMs)};
        const float nextSustain = std::isfinite(sustain) ? std::clamp(sustain, 0.0F, 1.0F) : 0.0F;
        const int index = segmentIndex(stage);
        const bool changed = index >= 0 && (frames_[static_cast<std::size_t>(index)] != nextFrames[static_cast<std::size_t>(index)] ||
            (stage == Stage::Slope && targets_[2] != nextSustain));
        const bool sustainChanged = targets_[2] != nextSustain;
        frames_ = nextFrames;
        targets_[2] = nextSustain;
        if (changed) retime();
        else if (stage == Stage::Sustain && sustainChanged) {
            // A live Sustain control edit reaches its new gain in 10 ms.
            // It changes neither the original Start/Attack/Break nor the cursor.
            position_ = value;
            remaining_ = frameCount(.010 * sampleRate);
            step_ = (static_cast<double>(targets_[2]) - position_) /
                static_cast<double>(std::max<std::uint64_t>(1U, remaining_));
        }
    }

    void trigger() noexcept { started_=false; position_ = value = start_; enter(Stage::Attack); }

    void release() noexcept {
        if (stage == Stage::Idle || stage == Stage::Release) return;
        // A delayed oscillator has not sounded its Start level yet. Releasing
        // its gate before the first rendered frame cancels it without a tail.
        if (!started_ || value <= 0.0F) { forceOff(); return; }
        // Freeze the sounding level, including a NoteOff during Attack, Decay
        // or Slope. The engine calls this only when the damper releases the gate.
        position_ = value;
        enter(Stage::Release);
    }

    void continueAt(float level) noexcept {
        // A legato change of recording starts at the preceding audible level,
        // then keeps the new oscillator's Break, Slope and Sustain settings.
        started_=false;
        position_ = value = std::clamp(level, 0.0F, 1.0F);
        enter(Stage::Decay);
    }

    void forceOff() noexcept {
        stage = Stage::Idle; value = 0.0F; position_ = 0.0;
        started_=false;
        remaining_ = 0U; step_ = progress_ = progressStep_ = 0.0;
    }

    float process() noexcept {
        started_=true;
        // At most three zero-time held segments, or a zero-time Release, can
        // complete in one frame. Each transition advances a finite state.
        for (;;) {
            if (stage == Stage::Idle) return value = 0.0F;
            if (stage == Stage::Sustain) {
                if (remaining_ == 0U) {
                    position_ = value = targets_[2];
                    if (value == 0.0F) forceOff();
                    return value;
                }
                value = static_cast<float>(position_);
                position_ += step_;
                --remaining_;
                return value;
            }
            if (remaining_ == 0U) {
                const int segment=segmentIndex(stage);
                if(segment<0){forceOff();return value;}
                const auto index = static_cast<std::size_t>(segment);
                position_ = value = targets_[index];
                if (stage == Stage::Release) { forceOff(); return value; }
                if (stage == Stage::Slope) {
                    stage = Stage::Sustain;
                    continue;
                }
                enter(stage == Stage::Attack ? Stage::Decay : Stage::Slope);
                continue;
            }
            value = static_cast<float>(position_);
            position_ += step_;
            progress_ = std::min(1.0, progress_ + progressStep_);
            --remaining_;
            return value;
        }
    }

private:
    float start_{0.0F}, decayShare_{0.5F};
    std::array<float,4> targets_{};
    std::array<double,4> frames_{};
    double position_{0.0}, step_{0.0}, progress_{0.0}, progressStep_{0.0};
    std::uint64_t remaining_{0U};
    bool started_{false};

    static int segmentIndex(Stage current) noexcept {
        switch (current) {
            case Stage::Attack: return 0;
            case Stage::Decay: return 1;
            case Stage::Slope: return 2;
            case Stage::Release: return 3;
            default: return -1;
        }
    }
    static std::uint64_t frameCount(double frames) noexcept {
        return static_cast<std::uint64_t>(std::llround(std::max(0.0, frames)));
    }
    void enter(Stage next) noexcept { stage = next; progress_ = 0.0; retime(); }
    void retime() noexcept {
        const int segment=segmentIndex(stage);
        if(segment<0){remaining_=0U;step_=progressStep_=0.0;return;}
        const auto index = static_cast<std::size_t>(segment);
        const double fraction = std::clamp(1.0 - progress_, 0.0, 1.0);
        // A live time edit retains both progress and sounding amplitude. It
        // retimes only the unfinished part, without restarting the envelope.
        position_ = value;
        remaining_ = frameCount(frames_[index] * fraction);
        if (remaining_ > 0U) {
            step_ = (static_cast<double>(targets_[index]) - position_) / static_cast<double>(remaining_);
            progressStep_ = fraction / static_cast<double>(remaining_);
        } else step_ = progressStep_ = 0.0;
    }
};

} // namespace silveton::sampler
