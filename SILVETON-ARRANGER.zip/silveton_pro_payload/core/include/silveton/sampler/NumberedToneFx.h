#pragma once

#include "silveton/sampler/NumberedFxRuntime.h"
#include <cstddef>
#include <memory>

namespace silveton::sampler {

// SILVETON implementations of the confirmed tone/filter/amplifier tables.
// The public index identifies the documented function; the filters, nonlinear
// curves, cabinet responses and initial settings are our own designs. This
// interface neither reads Korg packed parameters nor claims measured parity.
[[nodiscard]] NumberedFxSupport numberedToneFxSupport(std::uint16_t index) noexcept;
bool initializeNumberedToneFx(std::uint16_t index, NumberedFxState& state) noexcept;
[[nodiscard]] bool numberedToneFxCanRender(const NumberedFxState& state) noexcept;

class NumberedToneFx {
public:
    NumberedToneFx();
    ~NumberedToneFx();
    NumberedToneFx(const NumberedToneFx&) = delete;
    NumberedToneFx& operator=(const NumberedToneFx&) = delete;
    NumberedToneFx(NumberedToneFx&&) noexcept;
    NumberedToneFx& operator=(NumberedToneFx&&) noexcept;

    // Stopped/control thread only. The slot owns this workspace and guarantees
    // that no other family uses it while this family is active. No operation
    // below allocates after prepare. At least ceil(sampleRate*.25)+8 floats
    // are needed; the common slot's 11.3-second reservation is sufficient.
    void prepare(double sampleRate, float* workspace, std::size_t samples);
    void reset() noexcept;
    void configure(const NumberedFxState& state) noexcept;
    // Returns the complete internal Wet/Dry mix. The MFX return stays outside.
    void process(float inL, float inR, float& outL, float& outR) noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton::sampler
