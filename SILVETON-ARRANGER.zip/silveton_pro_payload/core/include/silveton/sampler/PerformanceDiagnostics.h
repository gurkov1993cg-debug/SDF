#pragma once

#include <atomic>
#include <cmath>
#include <cstdint>
#include <limits>

#if defined(__linux__) || defined(__ANDROID__)
#include <fstream>
#include <sstream>
#include <string>
#endif

namespace silveton::sampler::diagnostics {

// Session-cumulative measurements. Recording functions below are lock-free,
// allocation-free and do not perform I/O. A snapshot combines independent
// atomic observations; it is not an exact, simultaneous hardware trace.
struct Snapshot {
    std::uint64_t audioBlocks{0}, audioDeadlineMisses{0};
    double audioLastUs{0}, audioWorstUs{0}, audioBudgetUs{0};
    std::uint64_t clippedSamples{0};
    float outputPeakAbs{0};
    std::uint64_t voiceSteals{0}, hardVoiceSteals{0};
    int audioThreadId{0};
    std::uint64_t uiFrames{0};
    double uiFps{0};
    double uiTickLastUs{0}, uiTickWorstUs{0};
    double uiRecordLastUs{0}, uiRecordWorstUs{0};
    double uiRenderWallLastUs{0}, uiRenderWallWorstUs{0};
    std::uint64_t uiOperationCount{0}, uiWorstOperationCount{0};
    bool pageFaultsValid{false};
    std::uint64_t audioMinorFaults{0}, audioMajorFaults{0};
    // Deltas are relative to the first successful sample of the current TID,
    // not to application startup. Kernel totals above are per-thread totals.
    std::uint64_t audioMinorFaultDelta{0}, audioMajorFaultDelta{0};
};

namespace detail {
static_assert(std::atomic<std::uint64_t>::is_always_lock_free,
    "Audio diagnostics require lock-free 64-bit atomics");
static_assert(std::atomic<double>::is_always_lock_free,
    "Audio diagnostics require lock-free double atomics");
static_assert(std::atomic<float>::is_always_lock_free,
    "Audio diagnostics require lock-free float atomics");
struct Counters {
    std::atomic<std::uint64_t> audioBlocks{0}, audioDeadlineMisses{0};
    std::atomic<double> audioLastUs{0}, audioWorstUs{0}, audioBudgetUs{0};
    std::atomic<std::uint64_t> clippedSamples{0};
    std::atomic<float> outputPeakAbs{0};
    std::atomic<std::uint64_t> voiceSteals{0}, hardVoiceSteals{0};
    std::atomic<int> audioThreadId{0};
    std::atomic<std::uint64_t> uiFrames{0}, uiWindowFrames{0};
    std::atomic<std::int64_t> uiWindowStartedMs{0};
    std::atomic<double> uiFps{0};
    std::atomic<double> uiTickLastUs{0}, uiTickWorstUs{0};
    std::atomic<double> uiRecordLastUs{0}, uiRecordWorstUs{0};
    std::atomic<double> uiRenderWallLastUs{0}, uiRenderWallWorstUs{0};
    std::atomic<std::uint64_t> uiOperationCount{0}, uiWorstOperationCount{0};
    std::atomic<bool> pageFaultsValid{false};
    std::atomic<int> pageFaultThreadId{0};
    std::atomic<std::uint64_t> audioMinorFaults{0}, audioMajorFaults{0};
    std::atomic<std::uint64_t> minorFaultBaseline{0}, majorFaultBaseline{0};
    std::atomic<std::uint64_t> audioMinorFaultDelta{0}, audioMajorFaultDelta{0};
    // Used only by the explicitly non-realtime /proc sampling function.
    std::atomic_flag pageFaultSampling = ATOMIC_FLAG_INIT;
};
inline Counters counters;
template<class T> inline void maximum(std::atomic<T>& target, T value) noexcept {
    T previous = target.load(std::memory_order_relaxed);
    while (value > previous && !target.compare_exchange_weak(previous, value,
            std::memory_order_relaxed, std::memory_order_relaxed)) {}
}
inline double measuredTime(double value) noexcept {
    return std::isfinite(value) && value > 0.0 ? value : 0.0;
}
} // namespace detail

inline void recordAudioBlock(double elapsedMs, std::uint32_t frames, double rate) noexcept {
    if (frames == 0 || !std::isfinite(rate) || rate <= 0.0 ||
        !std::isfinite(elapsedMs) || elapsedMs < 0.0) return;
    auto& c = detail::counters;
    const double us = elapsedMs * 1000.0;
    const double budget = static_cast<double>(frames) * 1000000.0 / rate;
    c.audioLastUs.store(us, std::memory_order_relaxed);
    c.audioBudgetUs.store(budget, std::memory_order_relaxed);
    detail::maximum(c.audioWorstUs, us);
    c.audioBlocks.fetch_add(1, std::memory_order_relaxed);
    if (us > budget) c.audioDeadlineMisses.fetch_add(1, std::memory_order_relaxed);
}

inline void recordOutput(std::uint64_t clippedSampleCount, float peakAbs) noexcept {
    auto& c = detail::counters;
    if (clippedSampleCount != 0) c.clippedSamples.fetch_add(clippedSampleCount, std::memory_order_relaxed);
    if (!std::isnan(peakAbs) && peakAbs >= 0.0F) detail::maximum(c.outputPeakAbs, peakAbs);
}

inline void recordVoiceSteal(bool hard) noexcept {
    auto& c = detail::counters;
    c.voiceSteals.fetch_add(1, std::memory_order_relaxed);
    if (hard) c.hardVoiceSteals.fetch_add(1, std::memory_order_relaxed);
}

inline void setAudioThreadId(int tid) noexcept {
    auto& c = detail::counters;
    if (tid <= 0) tid = 0;
    if (c.audioThreadId.exchange(tid, std::memory_order_relaxed) != tid)
        c.pageFaultsValid.store(false, std::memory_order_relaxed);
}

inline void recordUiTick(double tickUs) noexcept {
    auto& c = detail::counters;
    tickUs = detail::measuredTime(tickUs);
    c.uiTickLastUs.store(tickUs, std::memory_order_relaxed);
    detail::maximum(c.uiTickWorstUs, tickUs);
}

// One UI writer. Call once per real draw-list/render attempt, not on tick-only
// polls. renderWallUs includes driver/VSync/swap wait; it is not GPU execution.
inline void recordUiFrame(double tickUs, double recordUs, double renderWallUs,
        std::int64_t nowMs, std::uint64_t operationCount) noexcept {
    auto& c = detail::counters;
    tickUs = detail::measuredTime(tickUs);
    recordUs = detail::measuredTime(recordUs);
    renderWallUs = detail::measuredTime(renderWallUs);
    c.uiTickLastUs.store(tickUs, std::memory_order_relaxed);
    c.uiRecordLastUs.store(recordUs, std::memory_order_relaxed);
    c.uiRenderWallLastUs.store(renderWallUs, std::memory_order_relaxed);
    detail::maximum(c.uiTickWorstUs, tickUs);
    detail::maximum(c.uiRecordWorstUs, recordUs);
    detail::maximum(c.uiRenderWallWorstUs, renderWallUs);
    c.uiOperationCount.store(operationCount, std::memory_order_relaxed);
    detail::maximum(c.uiWorstOperationCount, operationCount);
    c.uiFrames.fetch_add(1, std::memory_order_relaxed);
    auto start = c.uiWindowStartedMs.load(std::memory_order_relaxed);
    if (start == 0 || nowMs < start) {
        c.uiWindowStartedMs.store(nowMs, std::memory_order_relaxed);
        c.uiWindowFrames.store(0, std::memory_order_relaxed);
    } else {
        const auto count = c.uiWindowFrames.fetch_add(1, std::memory_order_relaxed) + 1;
        if (nowMs - start >= 1000) {
            c.uiFps.store(static_cast<double>(count) * 1000.0 / static_cast<double>(nowMs - start),
                std::memory_order_relaxed);
            c.uiWindowFrames.store(0, std::memory_order_relaxed);
            c.uiWindowStartedMs.store(nowMs, std::memory_order_relaxed);
        }
    }
}

// Metrics only. In-flight measurements may straddle this atomic reset; the
// audio thread, its state, buffers and voices are never stopped or changed.
// On the control thread, follow with sampleAudioPageFaults() to establish the
// new fault window before reproducing a problem.
inline void resetStatistics() noexcept {
    auto& c = detail::counters;
    c.audioBlocks.store(0, std::memory_order_relaxed);
    c.audioDeadlineMisses.store(0, std::memory_order_relaxed);
    c.audioLastUs.store(0, std::memory_order_relaxed);
    c.audioWorstUs.store(0, std::memory_order_relaxed);
    c.audioBudgetUs.store(0, std::memory_order_relaxed);
    c.clippedSamples.store(0, std::memory_order_relaxed);
    c.outputPeakAbs.store(0, std::memory_order_relaxed);
    c.voiceSteals.store(0, std::memory_order_relaxed);
    c.hardVoiceSteals.store(0, std::memory_order_relaxed);
    c.uiFrames.store(0, std::memory_order_relaxed);
    c.uiFps.store(0, std::memory_order_relaxed);
    c.uiWindowFrames.store(0, std::memory_order_relaxed);
    c.uiWindowStartedMs.store(0, std::memory_order_relaxed);
    c.uiTickLastUs.store(0, std::memory_order_relaxed);
    c.uiTickWorstUs.store(0, std::memory_order_relaxed);
    c.uiRecordLastUs.store(0, std::memory_order_relaxed);
    c.uiRecordWorstUs.store(0, std::memory_order_relaxed);
    c.uiRenderWallLastUs.store(0, std::memory_order_relaxed);
    c.uiRenderWallWorstUs.store(0, std::memory_order_relaxed);
    c.uiOperationCount.store(0, std::memory_order_relaxed);
    c.uiWorstOperationCount.store(0, std::memory_order_relaxed);
    c.pageFaultsValid.store(false, std::memory_order_relaxed);
    c.pageFaultThreadId.store(0, std::memory_order_relaxed);
    c.audioMinorFaultDelta.store(0, std::memory_order_relaxed);
    c.audioMajorFaultDelta.store(0, std::memory_order_relaxed);
}

// NON-REALTIME ONLY: opens and parses /proc. Call explicitly from diagnostics
// UI/control code, never from render(), an audio callback or a DSP worker.
// The first successful sample establishes a per-TID baseline. Failure or a
// thread change invalidates this sample; no missing value is reported as zero.
inline void sampleAudioPageFaults() {
    auto& c = detail::counters;
    if (c.pageFaultSampling.test_and_set(std::memory_order_acquire)) return;
    struct Release {
        std::atomic_flag& flag;
        ~Release() { flag.clear(std::memory_order_release); }
    } release{c.pageFaultSampling};
    c.pageFaultsValid.store(false, std::memory_order_relaxed);
#if defined(__linux__) || defined(__ANDROID__)
    const int tid = c.audioThreadId.load(std::memory_order_relaxed);
    if (tid <= 0) return;
    std::ifstream file("/proc/self/task/" + std::to_string(tid) + "/stat");
    std::string line;
    if (!std::getline(file, line)) return;
    // comm (field2) is parenthesized and may itself contain spaces or ')'.
    const auto close = line.rfind(')');
    if (close == std::string::npos || close + 1 >= line.size()) return;
    std::istringstream fields(line.substr(close + 1));
    std::string value;
    std::uint64_t minor = 0, major = 0;
    for (unsigned field = 3; field <= 12; ++field) {
        if (!(fields >> value)) return;
        if (field == 10 || field == 12) {
            if (value.empty()) return;
            std::uint64_t number = 0;
            for (const char digit : value) {
                if (digit < '0' || digit > '9') return;
                const auto next = static_cast<unsigned>(digit - '0');
                if (number > (std::numeric_limits<std::uint64_t>::max() - next) / 10U) return;
                number = number * 10U + next;
            }
            if (field == 10) minor = number; else major = number;
        }
    }
    if (c.audioThreadId.load(std::memory_order_relaxed) != tid) return;
    auto baselineMinor = c.minorFaultBaseline.load(std::memory_order_relaxed);
    auto baselineMajor = c.majorFaultBaseline.load(std::memory_order_relaxed);
    if (c.pageFaultThreadId.load(std::memory_order_relaxed) != tid ||
        minor < baselineMinor || major < baselineMajor) {
        baselineMinor = minor; baselineMajor = major;
        c.minorFaultBaseline.store(minor, std::memory_order_relaxed);
        c.majorFaultBaseline.store(major, std::memory_order_relaxed);
    }
    c.audioMinorFaults.store(minor, std::memory_order_relaxed);
    c.audioMajorFaults.store(major, std::memory_order_relaxed);
    c.audioMinorFaultDelta.store(minor - baselineMinor, std::memory_order_relaxed);
    c.audioMajorFaultDelta.store(major - baselineMajor, std::memory_order_relaxed);
    c.pageFaultThreadId.store(tid, std::memory_order_relaxed);
    c.pageFaultsValid.store(true, std::memory_order_release);
#endif
}

inline Snapshot snapshot() noexcept {
    const auto& c = detail::counters;
    Snapshot s;
    s.audioBlocks = c.audioBlocks.load(std::memory_order_relaxed);
    s.audioLastUs = c.audioLastUs.load(std::memory_order_relaxed);
    s.audioWorstUs = c.audioWorstUs.load(std::memory_order_relaxed);
    s.audioBudgetUs = c.audioBudgetUs.load(std::memory_order_relaxed);
    s.audioDeadlineMisses = c.audioDeadlineMisses.load(std::memory_order_relaxed);
    s.clippedSamples = c.clippedSamples.load(std::memory_order_relaxed);
    s.outputPeakAbs = c.outputPeakAbs.load(std::memory_order_relaxed);
    s.voiceSteals = c.voiceSteals.load(std::memory_order_relaxed);
    s.hardVoiceSteals = c.hardVoiceSteals.load(std::memory_order_relaxed);
    s.audioThreadId = c.audioThreadId.load(std::memory_order_relaxed);
    s.uiFrames = c.uiFrames.load(std::memory_order_relaxed);
    s.uiFps = c.uiFps.load(std::memory_order_relaxed);
    s.uiTickLastUs = c.uiTickLastUs.load(std::memory_order_relaxed);
    s.uiTickWorstUs = c.uiTickWorstUs.load(std::memory_order_relaxed);
    s.uiRecordLastUs = c.uiRecordLastUs.load(std::memory_order_relaxed);
    s.uiRecordWorstUs = c.uiRecordWorstUs.load(std::memory_order_relaxed);
    s.uiRenderWallLastUs = c.uiRenderWallLastUs.load(std::memory_order_relaxed);
    s.uiRenderWallWorstUs = c.uiRenderWallWorstUs.load(std::memory_order_relaxed);
    s.uiOperationCount = c.uiOperationCount.load(std::memory_order_relaxed);
    s.uiWorstOperationCount = c.uiWorstOperationCount.load(std::memory_order_relaxed);
    s.pageFaultsValid = c.pageFaultsValid.load(std::memory_order_acquire) && s.audioThreadId > 0 &&
        c.pageFaultThreadId.load(std::memory_order_relaxed) == s.audioThreadId;
    s.audioMinorFaults = c.audioMinorFaults.load(std::memory_order_relaxed);
    s.audioMajorFaults = c.audioMajorFaults.load(std::memory_order_relaxed);
    s.audioMinorFaultDelta = c.audioMinorFaultDelta.load(std::memory_order_relaxed);
    s.audioMajorFaultDelta = c.audioMajorFaultDelta.load(std::memory_order_relaxed);
    return s;
}

} // namespace silveton::sampler::diagnostics
