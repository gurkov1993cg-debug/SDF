#pragma once

#include "silveton/sampler/VelocityShape.h"   // SILVETON_VELOCITY_V1
#include "silveton/sampler/EngineDefs.h"      // SILVETON_ENGINES_V1
#include "silveton/sampler/NumberedFx.h"
#include "silveton/sampler/SourceSoundControls.h"
#include "silveton/sampler/SourcePerformanceControls.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <memory>
#include <string>
#include <vector>

namespace silveton::arranger {struct Pa5xSoundEffectsRaw;}

namespace silveton::sampler {

class SampleStream;
struct SourceEffectsState;
struct SourceOscillatorDsp;

constexpr int kMidiKeys = 128;
constexpr int kUpperCount = 7;
// SILVETON_ENGINE_SLOTS_V1: the ENGINES stand on their own - eight engine slots next to the 7 Uppers (the Uppers keep the samples).
// Part 0..6 = Upper 1..7, part 7..14 = engine slot 1..8 (inside the COMBI, so a COMBI keeps its engines).
constexpr int kEngineSlotCount = 8;
constexpr int kPartCount = kUpperCount + kEngineSlotCount;
constexpr int kMaxVoices = 128;
constexpr int kMaxProgramLayers = 32;
constexpr int kMaxZonesPerMultisample = 512;
constexpr int kMaxListSlots = 256;
constexpr int kMaxUpperControllerRoutes = 8;
constexpr std::uint16_t kFixedSoundSlotCount = 500U;
constexpr std::uint16_t kFixedCombiSlotCount = 500U;
constexpr std::uint16_t kNoSoundSlot = 0U;
// SILVETON_POLYSIX_V1: built-in single-cycle waves live at these SOUND slots (not in the bank).
constexpr std::uint16_t kBuiltinWaveFirstSlot = 9001U;
constexpr int kBuiltinWaveCount = 6;

struct LoopRegion {
    bool enabled{false};
    std::uint64_t startFrame{0};
    std::uint64_t endFrame{0}; // exclusive
    std::uint32_t crossfadeFrames{0};
};

struct SampleData {
    std::string name;
    std::string sourcePath;
    std::string sourceIdentity; // stable import identity; backing file path may change after SET packaging
    std::uint32_t sampleRate{48000};
    std::uint16_t channels{1};
    std::uint8_t rootKey{60};
    float fineTuneCents{0.0F};
    std::vector<float> interleaved; // optional full sample or preloaded attack prefix
    std::shared_ptr<const SampleStream> stream; // optional mmap-backed sustain/full source
    std::uint64_t totalFrames{0U};
    LoopRegion loop{};

    [[nodiscard]] std::uint64_t preloadedFrameCount() const noexcept {
        if (channels == 0U) return 0U;
        // Called for every sample of every voice: avoid the division for mono/stereo.
        if (channels == 1U) return static_cast<std::uint64_t>(interleaved.size());
        if (channels == 2U) return static_cast<std::uint64_t>(interleaved.size() >> 1U);
        return static_cast<std::uint64_t>(interleaved.size() / static_cast<std::size_t>(channels));
    }

    [[nodiscard]] std::uint64_t frameCount() const noexcept {
        return totalFrames > 0U ? totalFrames : preloadedFrameCount();
    }

    [[nodiscard]] bool valid() const noexcept {
        return channels >= 1U && channels <= 2U && sampleRate > 0U && frameCount() > 0U;
    }
};

using SamplePtr = std::shared_ptr<const SampleData>;

struct SampleZone {
    SamplePtr sample;
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    std::uint8_t rootKey{60};
    std::int8_t transposeSemitones{0};
    float tuneCents{0.0F};
    float gainDb{0.0F};
    float pan{0.0F}; // -1..+1
    bool oneShot{false};
    bool reverse{false};
    bool nonTranspose{false};
    std::int8_t sourceLevelRaw{0};
    std::int8_t sourceFilterRaw{0};

    [[nodiscard]] bool matches(std::uint8_t key, std::uint8_t velocity) const noexcept {
        return sample != nullptr && key >= keyLow && key <= keyHigh &&
               velocity >= velocityLow && velocity <= velocityHigh;
    }
};

struct Multisample {
    std::string name;
    std::vector<SampleZone> zones;
    std::string sourceIdentity; // stable KMP/KSC import identity
};

using MultisamplePtr = std::shared_ptr<const Multisample>;

enum class FilterMode : std::uint8_t { LowPass, HighPass, BandPass, Bypass };
enum class LfoWave : std::uint8_t { Sine, Triangle, SawUp, SawDown, Square, RandomHold };
enum class UpperVoiceMode : std::uint8_t { Poly, Mono, Legato };

struct EnvelopeParams {
    float attackSec{0.005F};
    float decaySec{0.08F};
    float sustain{1.0F};
    float releaseSec{0.12F};
};

struct FilterParams {
    FilterMode mode{FilterMode::Bypass};
    float cutoffHz{20000.0F};
    float resonance{0.0F}; // 0..1
    float keyTrack{0.0F}; // -1..1
    float velocityAmount{0.0F}; // octaves, bipolar
    float envelopeAmount{0.0F}; // octaves, bipolar
    float lfoAmount{0.0F}; // octaves, bipolar
};

struct LfoParams {
    LfoWave wave{LfoWave::Sine};
    float frequencyHz{5.0F};
    float delaySec{0.0F};
    float fadeSec{0.0F};
    bool keySync{true};
    float pitchCents{0.0F};
    float filterOctaves{0.0F};
    float ampDepth{0.0F};
};

// A sampled instrument can reach permanent silence while the damper is held.
struct SampleDecayEnvelope {
    float start{-1.0F};
    std::array<float, 3> targets{};
    std::array<float, 3> seconds{};
    bool enabled() const noexcept { return start >= 0.0F; }
    bool valid() const noexcept {
        if (start == -1.0F) return true;
        if (!(start >= 0.0F && start <= 1.0F) || targets.back() != 0.0F) return false;
        for (unsigned i = 0; i < targets.size(); ++i)
            if (!(targets[i] >= 0.0F && targets[i] <= 1.0F && seconds[i] >= 0.0F && seconds[i] <= 60.0F)) return false;
        return true;
    }
};

// Original Sound Amp EG indices, retained separately from the native ADSR.
// The field layout is decoded; the Pa time/gain transfer laws are not. Keep
// the saved bytes intact so a later calibration need not reinterpret our DSP.
struct SourceAmpEnvelope {
    bool present{false};
    bool enabled{false};
    bool modulationEncodingSupported{false};
    std::array<std::uint8_t, 4> levels{}; // Start, Attack, Break, Sustain
    std::array<std::uint8_t, 4> times{};  // Attack, Decay, Slope, Release
    // Exact retained normal-Sound AMS fields, in Time1, Time2, Level order.
    std::array<std::uint8_t, 3> amsSources{};
    std::array<std::int8_t, 3> amsIntensities{};
    std::array<std::uint8_t, 3> amsDirections{};
    std::array<std::uint8_t, 2> keyboardKeys{{0U,127U}};
    std::array<std::int8_t, 2> keyboardRamps{};
    bool filterKeyboardTrackingPresent{false};
    std::array<std::uint8_t, 2> filterKeyboardKeys{{0U,127U}};
    std::array<std::int8_t, 2> filterKeyboardRamps{};

    constexpr bool playbackSupported() const noexcept {
        for (unsigned route=0;route<amsSources.size();++route) {
            const auto directions=static_cast<unsigned>(amsDirections[route]) & (route==2U?0x3FU:0xFFU);
            if (amsIntensities[route]==0) continue;
            if (!modulationEncodingSupported) return false;
            if (amsSources[route]==0U || directions==0U) continue;
            // Official normal Program AMS0..42 and retained Pa5X GUI choices
            // corroborate0..45. Runtime supplies actual voice/controller state.
            if (amsSources[route]>45U ||
                amsIntensities[route]<-99 || amsIntensities[route]>99) return false;
            for (unsigned shift=0;shift<(route==2U?6U:8U);shift+=2U)
                if (((directions>>shift)&3U)==2U) return false;
            if (amsSources[route]>=6U&&amsSources[route]<=13U) {
                const bool filter=amsSources[route]<=9U;
                if(filter&&!filterKeyboardTrackingPresent)return false;
                const auto& keys=filter?filterKeyboardKeys:keyboardKeys;
                const auto& ramps=filter?filterKeyboardRamps:keyboardRamps;
                if(keys[0]>keys[1]||keys[1]>127U||ramps[0]<-99||ramps[0]>99||
                   ramps[1]<-99||ramps[1]>99)return false;
            }
        }
        return true;
    }

    constexpr bool valid() const noexcept {
        if (enabled && !present) return false;
        for (const auto level : levels) if (level > 99U) return false;
        for (const auto time : times) if (time > 99U) return false;
        return !enabled || playbackSupported();
    }
    bool sameAs(const SourceAmpEnvelope& other) const noexcept {
        return present == other.present && enabled == other.enabled && levels == other.levels && times == other.times &&
            modulationEncodingSupported == other.modulationEncodingSupported && amsSources == other.amsSources &&
            amsIntensities == other.amsIntensities && amsDirections == other.amsDirections &&
            keyboardKeys == other.keyboardKeys && keyboardRamps == other.keyboardRamps &&
            filterKeyboardTrackingPresent == other.filterKeyboardTrackingPresent &&
            filterKeyboardKeys == other.filterKeyboardKeys && filterKeyboardRamps == other.filterKeyboardRamps;
    }
    // SILVETON approximations, not measured Korg seconds or gain. A zero
    // time index is instantaneous; the original 0..99 index is never changed.
    static float timeSeconds(float index) noexcept {
        return static_cast<float>(0.001 * std::expm1(static_cast<double>(std::clamp(index,0.0F,99.0F)) * std::log(2.0) / 7.5));
    }
    static constexpr float levelGain(float level) noexcept {
        const float normalized = std::clamp(level,0.0F,99.0F) / 99.0F;
        return normalized * normalized;
    }
};

inline EnvelopeParams sourceAmpEnvelopeParams(const SourceAmpEnvelope& source) noexcept {
    return {SourceAmpEnvelope::timeSeconds(source.times[0]),
        SourceAmpEnvelope::timeSeconds(source.times[1]) + SourceAmpEnvelope::timeSeconds(source.times[2]),
        SourceAmpEnvelope::levelGain(source.levels[3]),
        SourceAmpEnvelope::timeSeconds(source.times[3])};
}

struct ProgramLayer {
    std::string name;
    MultisamplePtr multisample;
    bool enabled{true};
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    std::int8_t transposeSemitones{0};
    float tuneCents{0.0F};
    float levelDb{0.0F};
    float pan{0.0F};
    // Velocity crossfade widths in MIDI velocity steps. Zero = hard zone edge.
    std::uint8_t velocityFadeIn{0};
    std::uint8_t velocityFadeOut{0};
    // Delay before this layer starts sounding; envelopes/LFOs wait with it.
    float delaySec{0.0F};
    // Layer-level damper gate, combined with the COMBI Upper damper enable.
    bool damperEnabled{true};
    EnvelopeParams ampEnvelope{};
    SampleDecayEnvelope sampleDecay{};
    SourceAmpEnvelope sourceAmpEnvelope{};
    SourcePortamento sourcePortamento{};
    std::shared_ptr<const SourceOscillatorDsp> sourceOscillatorDsp;
    EnvelopeParams filterEnvelope{0.001F, 0.15F, 0.0F, 0.15F};
    EnvelopeParams pitchEnvelope{0.001F, 0.05F, 0.0F, 0.05F};
    float pitchEnvelopeCents{0.0F};
    FilterParams filter{};
    LfoParams lfo1{};
    LfoParams lfo2{};

    [[nodiscard]] bool matches(std::uint8_t key, std::uint8_t velocity) const noexcept {
        return enabled && multisample != nullptr && key >= keyLow && key <= keyHigh &&
               velocity >= velocityLow && velocity <= velocityHigh;
    }
};

// The imported flat, unity amplitude envelope has no audible decay stage.
// Give it an editable time only when the performer overrides Decay or Sustain.
inline bool needsEditableEnvelope(const ProgramLayer& layer) noexcept {
    return layer.sourceAmpEnvelope.enabled || layer.sampleDecay.enabled() ||
        (layer.ampEnvelope.decaySec==0 && layer.ampEnvelope.sustain==1);
}
inline EnvelopeParams editableAmpEnvelope(const ProgramLayer& layer) noexcept {
    if(layer.sourceAmpEnvelope.enabled)return sourceAmpEnvelopeParams(layer.sourceAmpEnvelope);
    auto env=layer.ampEnvelope;
    const auto& curve=layer.sampleDecay;
    if(curve.enabled()){
        env.attackSec=std::max(env.attackSec,curve.seconds[0]);
        env.decaySec=curve.seconds[1]+curve.seconds[2];
        env.sustain=curve.targets.back();
    }else if(needsEditableEnvelope(layer)){
        env.decaySec=EnvelopeParams{}.decaySec;
    }
    return env;
}

// A Drum Kit key owns these controls across all of its velocity layers.
// The explicit fade duration is SILVETON milliseconds, not a decoded Korg
// parameter value. A missing table keeps the existing sampled Sound behavior.
struct DrumKeyGroup {
    std::uint8_t exclusiveGroup{0}; // 0 = None; 1..127 = shared choke group
    bool singleTrigger{false};
    float chokeFadeOutMs{4.0F};
    bool subgroupChokeOff{false};
    bool valid() const noexcept {
        return exclusiveGroup<=127 && chokeFadeOutMs>=0.0F && chokeFadeOutMs<=10000.0F;
    }
};
using DrumKeyGroups=std::array<DrumKeyGroup,kMidiKeys>;

struct Program {
    std::string name;
    std::vector<ProgramLayer> layers;
    bool mono{false};
    bool legato{false};
    float portamentoSec{0.0F};
    std::shared_ptr<const DrumKeyGroups> drumKeyGroups;
    SourceVoiceAssignment sourceVoiceAssignment{};
    // Sound-owned original metadata for inspection/recall. It does not replace
    // the active Keyboard Set/Style rack or imply an enabled IFX/MFX assignment.
    std::shared_ptr<const arranger::Pa5xSoundEffectsRaw> sourceSoundEffects;
};

using ProgramPtr = std::shared_ptr<const Program>;

enum class ControllerSource : std::uint8_t {
    Off,
    Breath,
    Expression,
    Aftertouch,
    JoystickX,   // MIDI pitch-bend axis, normalized bipolar
    JoystickY,   // CC selected by cc field (CC1 by default)
    ControlChange
};

enum class ModDestination : std::uint8_t {
    LevelDb,
    Pan,
    PitchSemitones,
    FilterCutoffOctaves,
    FilterResonance,
    LfoDepth,
    FxSend1,
    FxSend2,
    FxSend3,   // SILVETON_FX_V3
    FxSend4
};

struct UpperControllerRoute {
    ControllerSource source{ControllerSource::Off};
    ModDestination destination{ModDestination::LevelDb};
    std::uint8_t cc{1U};
    float amount{0.0F};
    bool bipolar{false};
};

// Absolute TONE values of an Upper. A negative value means "not set":
// the PROGRAM layer envelope (times its Easy Edit scale) is used instead.
constexpr float kToneMaxTimeMs = 20000.0F;
constexpr float kToneCutoffOpenHz = 20000.0F; // 20 kHz = tone filter off

// SILVETON_TONE_V2: the rest of the TONE page of one sound (the basic sound of
// an Upper or one of its layers). Everything here is absolute (no PROGRAM fallback).
constexpr float kToneMaxStartMs = 2000.0F;
// SILVETON_OFS_V1: OFS of every velocity layer of a sound, like the Korg OSC Start Offset: MS1 = the hardest layer .. MS4 =
// the softest (a sound with more than four layers: the softer ones share MS4)
constexpr int kOfsZones = 4;
struct ToneExtra {
    float startMs{0.0F};          // SAMPLE START offset (ms), snapped to a zero crossing
    std::array<float, kOfsZones> zoneStartMs{{-1.0F, -1.0F, -1.0F, -1.0F}};   // SILVETON_OFS_V1: -1 = as START
    float endMs{0.0F};            // SAMPLE END (ms from the sample start); 0 = whole sample
    float filterEnvOctaves{0.0F}; // FILTER ENV amount, octaves (bipolar)
    float filterEnvMs{120.0F};    // FILTER ENV time (decay to zero)
    float velToLevel{1.0F};       // 0 = velocity does not change the level, 1 = fully
    float velToCutoff{0.0F};      // octaves the cutoff drops at velocity 1 (0 = none)
    float highPassHz{0.0F};       // HIGH-PASS of this sound, 0 = off
    float lfoRateHz{5.5F};        // vibrato LFO
    float lfoDepthCents{0.0F};    // 0 = no vibrato
    float lfoDelayMs{0.0F};
    float lfoFadeMs{300.0F};
    bool lfoModWheel{true};       // true = the depth follows the modulation wheel (CC1)
    float eqLowDb{0.0F};          // 3-band EQ of this sound (shelf 120 Hz / peak 1.2 kHz / shelf 7 kHz)
    float eqMidDb{0.0F};
    float eqHighDb{0.0F};
    // SILVETON_POLYSIX_V1: synthesizer functions on the recording (a Polysix whose oscillator is the sample).
    float pwmWidth{0.0F};         // 0 = off; 0.05..0.95 = the recording minus itself shifted by WIDTH x period (PWM)
    float pwmDepth{0.0F};         // LFO movement of the width (0..0.45)
    float pwmRateHz{0.5F};
    float pwmMix{1.0F};           // how much of the shifted copy is subtracted (1 = full pulse)
    float subLevel{0.0F};         // SUB: the same recording one/two octaves down, mixed in (0..1)
    std::int8_t subOctave{1};     // 1 or 2
    std::int8_t unisonVoices{1};  // 1..4 copies per note
    float unisonDetuneCents{8.0F};
    float unisonSpread{0.5F};     // stereo spread of the copies 0..1
    float drive{0.0F};            // soft saturation before the filter 0..1
    std::int8_t filterType{0};    // CUTOFF filter: 0 clean SVF, 1 POLYSIX 4-pole ladder, 2 KORG35 (MS-20)
    float filterKeyTrack{0.0F};   // -1..1: cutoff follows the key (1 = fully)
    std::int8_t filter2Type{0};   // second filter: 0 off, 1 LP, 2 HP, 3 BP, 4 BR (12 dB)
    float filter2Hz{1000.0F};
    float filter2Res{0.0F};
    bool filter2Parallel{false};  // false = after filter 1 (series), true = beside it
    bool analogFeel{false};       // tiny random detune / cutoff per note, like a real analog
    // SILVETON_SYNTH_BYPASS_V1: true = the whole SYNTH + MATRIX section is skipped (sound exactly
    // as before Polysix), knob settings kept. Switches without a click while playing.
    bool synthBypass{false};
    // SILVETON_TRANSWAVE_V1: a row of single-cycle frames cut from the user's own recordings; the sound morphs through them while the key is held.
    // This section does not depend on SYNTH ИЗКЛ: it has its own switch (waveMode).
    std::int8_t waveMode{0};      // 0 off, 1 AUTO (the recording of the sound is cut into frames), 2 MULTI (every frame is another SOUND)
    std::int8_t waveFrames{16};   // AUTO: how many frames (2..32)
    std::int8_t waveSource{0};    // what moves the position: 0 none (manual), 1 ENV, 2 LFO, 3 VELOCITY, 4 MOD WHEEL, 5 AFTERTOUCH, 6 NOTE
    float wavePos{0.0F};          // 0..1 position in the row (the starting point when something moves it)
    float waveStart{0.0F};        // 0..1 where in the recording the first frame is taken
    float waveSpan{1.0F};         // AUTO: 0..1 how much of the recording is cut into frames
    float waveSmooth{1.0F};       // 0 = steps from frame to frame, 1 = smooth morph
    float waveAmount{0.5F};       // -1..1 how far the source moves the position
    float waveTimeMs{1500.0F};    // ENV: time to travel the whole amount
    float waveRateHz{0.5F};       // LFO speed
    std::array<std::uint16_t, 8> waveSlot{};   // MULTI: SOUND slots of the frames (0 = empty)
    std::shared_ptr<const std::vector<ProgramPtr>> waveSources;   // MULTI: the programs of waveSlot (filled by the host, not saved)
};

// SILVETON_POLYSIX_V1: modulation matrix of one sound - "everything to everything".
enum class ModSource : std::uint8_t { Off, Velocity, Note, Aftertouch, ModWheel, Breath, Expression, Pedal, Bend, Lfo, FilterEnv, AmpEnv, Random };
enum class ModTarget : std::uint8_t { Cutoff, Resonance, Cutoff2, Level, Pan, Pitch, LfoDepth, LfoRate, PwmWidth, Drive, Attack, Release };
constexpr int kModSourceCount = 13;
constexpr int kModTargetCount = 12;
constexpr int kModRoutes = 8;
struct ModRoute {
    ModSource source{ModSource::Off};
    ModTarget target{ModTarget::Cutoff};
    float amount{0.0F};           // -1..1 of the target's full range
    bool bipolar{false};          // unipolar source mapped to -1..1
};
struct ModMatrix {
    std::array<ModRoute, kModRoutes> route{};
};

// Full TONE of one sound. The six legacy values keep their "-1 = PROGRAM" rule.
struct SoundTone {
    float attackMs{-1.0F};
    float decayMs{-1.0F};
    float sustain{-1.0F};
    float releaseMs{-1.0F};
    float cutoffHz{-1.0F};
    float resonance{-1.0F};
    ToneExtra x{};
    ModMatrix mod{};              // SILVETON_POLYSIX_V1
};

// SILVETON_LAYERS_V1: one of the four extra layers of an Upper. A layer is a
// whole sound of its own (SOUND, level, pan, tuning, range, TONE, 3-band EQ + HP);
// the sum of the basic sound and its layers then goes through the common Upper
// processing (level, pan, ON/SOLO/MUTE, 5-band EQ, POLY/MONO/LEG, portamento, T/Q, split, controllers).
constexpr int kUpperLayers = 4;
namespace solo { struct Model; }
// One source assignment for MAIN and L1..L4. Processing stays on the sound/Upper.
struct SoundAssignment {
    ProgramPtr program;
    std::uint16_t soundSlotId{kNoSoundSlot};
    std::string name;
    EngineParams engine{};
    std::shared_ptr<const solo::Model> soloModel;
    bool commonProcessing{false}; // false reads older SOLO sets without changing their envelope
    bool hasSource() const noexcept { return program != nullptr || engine.chosen(); }
};
struct UpperLayer : SoundAssignment {
    bool enabled{false};
    float levelDb{0.0F};
    float pan{0.0F};
    std::int8_t transposeSemitones{0};
    std::int8_t octave{0};
    float tuneCents{0.0F};
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    // Independent dynamics for this COMBI layer (defaults preserve older SETs).
    std::uint8_t velocityFadeIn{0};
    std::uint8_t velocityFadeOut{0};
    float velocityResponse{1.0F};
    VelocityShape velocityShape{};   // SILVETON_VELOCITY_V1: curve, compress / expand, velocity -> attack, crossfade
    SoundTone tone{};

    [[nodiscard]] bool matches(std::uint8_t key, std::uint8_t velocity) const noexcept {
        return enabled && hasSource() && key >= keyLow && key <= keyHigh &&
               velocity >= velocityLow && velocity <= velocityHigh;
    }
};

// SILVETON_EQ5_V1: common EQ of an Upper. Band 1 is a low shelf, band 5 a high
// shelf, 2..4 are peaks; plus HIGH-PASS and LOW-PASS (12 or 24 dB/oct).
// A band at 0 dB (or off) costs nothing.
constexpr int kUpperEqBands = 5;
struct EqBand {
    bool on{true};
    float freqHz{1000.0F};
    float gainDb{0.0F};
    float q{0.7F};
};
struct ChannelGate {
    bool enabled{},fastAttack{},expand{};
    float thresholdDb{-30},rangeDb{20},holdSec{.05F},releaseSec{.30F};
    bool operator==(const ChannelGate& g) const noexcept {
        return enabled==g.enabled&&fastAttack==g.fastAttack&&expand==g.expand&&
            thresholdDb==g.thresholdDb&&rangeDb==g.rangeDb&&holdSec==g.holdSec&&releaseSec==g.releaseSec;
    }
};
struct UpperEq {
    bool on{true};
    std::array<EqBand, kUpperEqBands> band{{
        {true, 120.0F, 0.0F, 0.7F}, {true, 400.0F, 0.0F, 1.0F}, {true, 1200.0F, 0.0F, 0.75F},
        {true, 3500.0F, 0.0F, 1.0F}, {true, 7000.0F, 0.0F, 0.7F}}};
    bool hpOn{false};
    float hpHz{40.0F};
    std::uint8_t hpSlopeDb{12};   // 12 or 24
    bool lpOn{false};
    float lpHz{18000.0F};
    std::uint8_t lpSlopeDb{12};
};

// SILVETON_PORTA_MODES_V1
// SILVETON_BASS_PORTA_V1/V2: Bass = a portamento of its own for bass sounds (own button on the VOICE page, TIME 0..127). A held line
// keeps the recording it started with: no other articulation on the new key, no fresh recording blended in, no kill when the new key
// has no zone of its own - the voice only moves its pitch. When the line went silent (the recording ended), the next key strikes
// again and glides from the previous key. Silveton, Kronos and Instrument are not touched by it.
enum class PortamentoMode : std::uint8_t { Silveton, Kronos, Instrument, Bass };
// An instrument-specific sample-oscillator transition style. This is NOT an
// additional sample generator; existing samples, pitches and envelopes stay intact.
enum class OscillatorMode : std::uint8_t { Neutral, Bass, Bowed, Woodwind, Brass, Plucked, Synth };

namespace solo {struct Model;}
// Arranger render metadata. Authored Style data is stored by the host, never
// in the shared PCM or the Keyboard Set file. Negative envelope values inherit.
struct LiveDrumKey {
    int attack{-1},decay{-1},sustain{-1},release{-1},gainDb{},pan{},tune{},gate{-1};
};
using LiveDrumKeys=std::array<LiveDrumKey,kMidiKeys>;

struct UpperPart : SoundAssignment {
    bool livePartMix{false};
    int liveGate{-1};
    std::shared_ptr<const LiveDrumKeys> liveDrumKeys;
    bool enabled{false};
    bool mute{false};
    bool solo{false};
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    // Runtime performance boundary (for example, arranger SPLIT), independent
    // of the Sound's own key/velocity zones. Rebuilt by the performance owner;
    // not serialized into Sound, bank or SET formats.
    std::uint8_t performanceKeyLow{0};
    std::uint8_t performanceKeyHigh{127};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    std::uint8_t velocityFadeIn{0};
    std::uint8_t velocityFadeOut{0};
    float velocityResponse{1.0F};
    VelocityShape velocityShape{};   // SILVETON_VELOCITY_V1: the same for the basic sound (the layers have their own)
    float levelDb{0.0F};
    float pan{0.0F};
    // Original Keyboard Set mix belongs to this part, independently of the
    // shared physical MIDI input channel and the user's level/pan trims.
    // -1 is an absent declaration (unity gain / unchanged intrinsic pan).
    int sourceVolumeRaw{-1};
    int sourcePanRaw{-1};
    int sourceExpressionRaw{-1};
    // Original channel tuning from explicit RPN2/RPN1. These pitch offsets
    // remain separate from the editable +/-100-cent trim and never choose a
    // different sample zone. -1 is absent; centres are 64 and 8192.
    int sourceCoarseTuneRaw{-1}; // MIDI 0..127, one semitone per step
    int sourceFineTuneRaw{-1};  // MIDI 0..16383, one 1/8192 semitone per step
    SourceSoundEdits sourceSoundEdits{};
    std::int8_t transposeSemitones{0};
    float tuneCents{0.0F};
    std::int8_t octave{0};
    std::int8_t pitchBendRange{1};   // SILVETON_TUNE_RANGES_V1: default 1 semitone
    bool damperEnabled{true};
    bool expressionEnabled{true};
    bool breathEnabled{false};
    bool aftertouchEnabled{false};
    std::uint8_t midiChannel{0};
    float eqLowDb{0.0F};
    float eqMidDb{0.0F};
    float eqHighDb{0.0F};
    float fxSend1{0.0F};
    float fxSend2{0.0F};
    // COMBI Easy Edit modifiers. These are intentionally stored on the Upper,
    // so changing a stage setup never mutates the underlying PROGRAM.
    float ampAttackScale{1.0F};
    float ampDecayScale{1.0F};
    float ampReleaseScale{1.0F};
    float ampSustainScale{1.0F};
    float filterCutoffOctaves{0.0F};
    float filterResonanceOffset{0.0F};
    float lfoRateScale{1.0F};
    float lfoDepthScale{1.0F};
    float portamentoSec{0.0F};
    float toneAttackMs{-1.0F};
    float toneDecayMs{-1.0F};
    float toneSustain{-1.0F};
    float toneReleaseMs{-1.0F};
    float toneCutoffHz{-1.0F};
    float toneResonance{-1.0F};
    ToneExtra toneExtra{};                               // SILVETON_TONE_V2: rest of the basic sound's TONE
    float evenDecayMs{0.0F};                             // SILVETON_EVEN_DECAY_LIVE_V1 (the Manager's copy): ЗАТИХВАНЕ, 0 = off
    ModMatrix toneMod{};                                 // SILVETON_POLYSIX_V1: matrix of the basic sound
    std::array<UpperLayer, kUpperLayers> layers{};       // SILVETON_LAYERS_V1
    ChannelGate channelGate{};
    UpperEq eq{};                                        // SILVETON_EQ5_V1 (eqLow/Mid/HighDb above = bands 1/3/5)
    // SILVETON_PORTA_MODES_V1: KRONOS portamento (used when portaMode == Kronos)
    PortamentoMode portaMode{PortamentoMode::Silveton};
    OscillatorMode oscillatorMode{OscillatorMode::Neutral};
    // SILVETON_ENGINES_V1: the ENGINE of this Upper (OFF = the plain recording, as before). One per Upper, on every voice of it.
    // New COMBI projects use each sound's own note and velocity zones.
    // Old SETs load with false, retaining their original common UPPER gate.
    bool independentLayerRanges{true};
    bool portaFingered{false};         // glide only when another key is still held
    bool portaRateMode{false};         // false = TIME (same time for any interval), true = RATE (time per octave)
    bool sourcePortamentoInherit{true}; // explicit performer edits, including Off, override saved oscillator controls
    bool sourceVoiceInherit{true}; // source Program changes can carry their own Mono/Poly policy
    std::uint8_t portaTime{40};        // 0..127 like Kronos
    float fxSend3{0.0F};               // SILVETON_FX_V3: sends 3 and 4
    float fxSend4{0.0F};
    UpperVoiceMode voiceMode{UpperVoiceMode::Poly};
    // Per-Upper realtime controller matrix. Routes are evaluated in the audio
    // callback without allocations; each Upper can use different sources/destinations.
    std::array<UpperControllerRoute, kMaxUpperControllerRoutes> controllerRoutes{};

    [[nodiscard]] bool hasAnySound() const noexcept {
        if (hasSource()) return true;
        for (const auto& l : layers) if (l.enabled && l.hasSource()) return true;
        return false;
    }
    [[nodiscard]] bool matches(std::uint8_t key, std::uint8_t velocity,bool bypassSwitch=false) const noexcept {
        return (bypassSwitch||(enabled&&!mute)) && hasAnySound() &&
               key >= performanceKeyLow && key <= performanceKeyHigh &&
               (independentLayerRanges || (key >= keyLow && key <= keyHigh &&
                velocity >= velocityLow && velocity <= velocityHigh));
    }
};

inline SoundAssignment& soundSource(UpperPart& u, int sound) noexcept {
    return sound == 0 ? static_cast<SoundAssignment&>(u) : static_cast<SoundAssignment&>(u.layers[static_cast<std::size_t>(sound - 1)]);
}
inline const SoundAssignment& soundSource(const UpperPart& u, int sound) noexcept {
    return sound == 0 ? static_cast<const SoundAssignment&>(u) : static_cast<const SoundAssignment&>(u.layers[static_cast<std::size_t>(sound - 1)]);
}

// SILVETON_FX_V3. The first four values keep their old numbers (old sets):
// Delay = DIGITAL delay, Reverb = PLATE.
enum class EffectType : std::uint8_t {
    Off, Delay, Chorus, Reverb,
    Hall, Room, Chamber, Spring,                  // reverbs
    TapeDelay, PingPong, MultiTap, DuckDelay,     // delays
    Flanger, Phaser, Rotary,                      // modulation
    Compressor, Drive,                            // dynamics / colour (mostly as INSERT)
    Ensemble                                      // SILVETON_POLYSIX_V1: the Polysix / string-machine ensemble
};
constexpr int kEffectTypeCount = 18;
[[nodiscard]] constexpr bool effectIsReverb(EffectType t) noexcept {
    return t == EffectType::Reverb || t == EffectType::Hall || t == EffectType::Room ||
           t == EffectType::Chamber || t == EffectType::Spring;
}
[[nodiscard]] constexpr bool effectIsDelay(EffectType t) noexcept {
    return t == EffectType::Delay || t == EffectType::TapeDelay || t == EffectType::PingPong ||
           t == EffectType::MultiTap || t == EffectType::DuckDelay;
}

// One effect. What the fields mean per type:
//  reverbs:   feedback = DECAY (0..0.95 -> 0.6..12 s), tone = TONE, preDelayMs,
//             damping = DAMPING (high-frequency loss in the tail), size = SIZE, mod = MOD
//  delays:    timeMs = TIME (or tempoBpm x division when tempoSync), feedback, tone;
//             mod = wow/flutter (TAPE), depth = DUCK amount (DUCKING) / tap spread (MULTI-TAP)
//  chorus:    rateHz, depth, tone; param1 = voices (2..4)
//  flanger:   rateHz, depth, feedback
//  phaser:    rateHz, depth, feedback; param1 = stages (4/6/8)
//  rotary:    rateHz = slow speed, param1 = fast speed, depth = horn/drum balance, param2 = 1 fast / 0 slow
//  compressor: param1 = threshold dB (-40..0), param2 = ratio (1..20), timeMs = attack ms, param3 = release ms, tone = makeup dB
//  drive:     depth = drive amount, tone = tone, param1 = output dB
struct EffectSlot {
    EffectType type{EffectType::Off};
    float wet{0.0F};
    float timeMs{320.0F};
    float feedback{0.25F};
    float rateHz{0.8F};
    float depth{0.35F};
    float tone{0.5F};
    float preDelayMs{10.0F};
    float damping{0.4F};
    float size{0.5F};
    float mod{0.3F};
    bool tempoSync{false};
    float tempoBpm{120.0F};
    float division{0.25F};   // of a whole note: 0.25 = quarter, 0.125 = eighth, 0.1875 = dotted eighth ...
    float param1{0.0F};
    float param2{0.0F};
    float param3{0.0F};
    // Independent semantic namespace. Native EffectType 0..17 and its legacy
    // serialized fields retain their meanings. A numbered assignment is made
    // only by an explicit editor action, never by casting a source selector.
    NumberedFxState numbered{};
    // Manual numbered MFX controller owner: -1 = Off, 0..7 = logical Combi
    // part (not a MIDI channel or an original Korg serialized selector).
    // IFX always stores -1 and uses its own part. Legacy records default Off.
    std::int8_t numberedModulatingPart{-1};
};

enum class EffectRouting : std::uint8_t { Parallel, Fx1IntoFx2 };

constexpr int kFxSendSlots = 4;   // SILVETON_FX_V3: four common send effects

// Optional per-blend keyboard tuning. Absent in legacy COMBIs, which keep the
// previous global tuning behavior. Cents are absolute played pitch classes;
// tonic is editor metadata, never an additional DSP transposition.
struct BlendScale {
    bool stored{false};
    bool enabled{true};
    std::uint16_t targets{0};
    std::uint8_t tonic{0};
    std::array<float, 12> cents{};
    std::string name;
};

struct Combi {
    std::string name;
    std::array<UpperPart, kUpperCount> uppers{};
    std::array<UpperPart, kEngineSlotCount> engineSlots{};   // SILVETON_ENGINE_SLOTS_V1: engines with no sample, one per slot, any mix
    std::array<EffectSlot, kFxSendSlots> fx{};        // fx[0] / fx[1] were FX1 / FX2
    std::array<EffectSlot, kUpperCount> insert{};     // one INSERT per Upper (runs before the sends)
    std::array<EffectSlot, kEngineSlotCount> engineInsert{};   // SILVETON_PLACE_FX_V1: one INSERT per SILVETON SYNTH place (runs before the sends)
    EffectRouting fxRouting{EffectRouting::Parallel}; // FX1 into FX2
    std::shared_ptr<const SourceEffectsState> sourceEffects;
    BlendScale scale{};

    // SILVETON_PLACE_FX_V1: the INSERT of part 0..6 (Upper) or 7..14 (SILVETON SYNTH place)
    [[nodiscard]] EffectSlot& insertOf(int index) noexcept {
        return index < kUpperCount ? insert[static_cast<std::size_t>(index)] : engineInsert[static_cast<std::size_t>(index - kUpperCount)];
    }
    [[nodiscard]] const EffectSlot& insertOf(int index) const noexcept {
        return index < kUpperCount ? insert[static_cast<std::size_t>(index)] : engineInsert[static_cast<std::size_t>(index - kUpperCount)];
    }

    // SILVETON_ENGINE_SLOTS_V1: part 0..6 = Upper, 7..14 = engine slot (the same UpperPart: level, pan, MONO / LEGATO, portamento...)
    [[nodiscard]] UpperPart& part(int index) noexcept {
        return index < kUpperCount ? uppers[static_cast<std::size_t>(index)] : engineSlots[static_cast<std::size_t>(index - kUpperCount)];
    }
    [[nodiscard]] const UpperPart& part(int index) const noexcept {
        return index < kUpperCount ? uppers[static_cast<std::size_t>(index)] : engineSlots[static_cast<std::size_t>(index - kUpperCount)];
    }
};

struct GlobalState {
    float masterTuneHz{440.0F};
    std::int8_t transposeSemitones{0};
    float masterGainDb{-6.0F};       // SILVETON_MASTER_6DB_V1: the program starts at -6 dB, no limiter
    float eqLowDb{0.0F};
    float eqMidDb{0.0F};
    float eqHighDb{0.0F};
    bool limiterEnabled{false};      // optional stereo peak limiter; default keeps the original bypass
    float limiterCeilingDb{-6.0F};
    std::uint8_t velocityCurve{0};
    // Global controller assignment. These apply to the whole instrument;
    // individual Upper enable flags still decide whether that controller affects it.
    std::uint8_t breathCc{2};
    std::uint8_t expressionCc{11};
    std::uint8_t damperCc{64};
    bool pitchBendEnabled{true};
    bool aftertouchEnabled{true};

    // GLOBAL tuning. The 12 offsets are interpreted relative to scaleRoot,
    // allowing quarter-tone/custom scales without modifying PROGRAM data.
    std::uint8_t scaleRoot{0}; // 0=C ... 11=B
    std::array<float, 12> scaleOffsetsCents{};

    // GLOBAL MIDI filtering/routing. Bit 0 = MIDI ch 1, bit 15 = MIDI ch 16.
    std::uint16_t midiInputChannelMask{0xFFFFU};
    bool filterNotes{false};
    bool filterControlChange{false};
    bool filterPitchBend{false};
    bool filterAftertouch{false};

    // GLOBAL controller calibration. Values are normalized 0..1 and then
    // shaped with pow(x, curve); curve=1 is linear.
    float breathMin{0.0F};
    float breathMax{1.0F};
    float breathCurve{1.0F};
    float expressionMin{0.0F};
    float expressionMax{1.0F};
    float expressionCurve{1.0F};
    bool damperPolarityReversed{false};
};

struct ListEntry {
    std::uint16_t number{0};
    std::string name;
    std::uint16_t combiBank{0};
    std::uint16_t combiPage{0};
    std::uint16_t combiSlot{0};
};

struct SetList {
    std::string name;
    std::vector<ListEntry> entries;
};

struct EngineState {
    Combi combi{};
    GlobalState global{};
    // SILVETON_FX_TAIL_V1: changes only when another COMBI / BLEND is called up
    // (not on live edits), so the old effect can ring out instead of stopping.
    std::uint32_t combiGeneration{0U};
};

// ---------------------------------------------------------------------------------------------
// SILVETON_SOUND_BY_NAME_V1
// A BLEND remembers its sounds by the NAME of the sound (and by the bank place, 1..500, only
// as a hint). When the bank is replaced (update) or the saved BLENDS are loaded, the sound is
// found again by its name wherever it sits now - so a bank with re-ordered sounds never makes a
// BLEND play a different sound. A sound that is not in the bank any more is reported as missing
// (the part goes off) - it is never replaced by whatever happens to sit on the old place.


struct SoundCandidate {
    std::uint16_t slot{0};
    std::string name;
};

struct SoundResolveResult {
    bool found{false};
    bool moved{false};          // found, but not on the remembered place
    std::uint16_t slot{0};      // the place the sound has now (valid when found)
};

// The engine names a part "Upper 3" / "Layer 2" before any sound is put on it. Such a name says
// nothing about a sound, so for it only the remembered place can be used.
[[nodiscard]] inline bool isPlaceholderSoundName(const std::string& name) {
    if (name.empty()) return true;
    for (const char* prefix : {"Upper ", "Layer "}) {
        const std::string p(prefix);
        if (name.size() > p.size() && name.compare(0U, p.size(), p) == 0) {
            bool digits = true;
            for (std::size_t i = p.size(); i < name.size(); ++i) {
                if (name[i] < '0' || name[i] > '9') { digits = false; break; }
            }
            if (digits) return true;
        }
    }
    return false;
}

// bankSounds: every sound of the current bank with the place it has now.
// SILVETON_SOUND_BY_NUMBER_V2 (Цветомир, 27.10.2026): a BLEND remembers its sound ONLY by its NUMBER (place 1..500). A sound never
// moves from its place; a new sound takes the first empty number. The name is kept for the screens, it is not looked at here (the earlier
// SILVETON_SOUND_BY_NAME_V1 fallback - find the name on another place - is gone). `moved` is therefore never set. A deleted place is
// forgotten by every blend that used it (SamplerHost::forgetPlacesInCombi), so an old blend never plays a new sound on that number.
[[nodiscard]] inline SoundResolveResult resolveSoundByName(std::uint16_t savedSlot,
                                                           const std::string& savedName,
                                                           const std::vector<SoundCandidate>& bankSounds) {
    (void)savedName;
    SoundResolveResult out;
    for (const auto& c : bankSounds) {
        if (c.slot == savedSlot) { out.found = true; out.slot = c.slot; return out; }
    }
    return out;
}

} // namespace silveton::sampler
