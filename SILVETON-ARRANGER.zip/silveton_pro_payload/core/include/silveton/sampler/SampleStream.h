#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace silveton::sampler {

// Owns an mmap until the non-realtime collector can release it. The registry
// also lets the prefetch worker safely fault an address range in on kernels
// without MADV_POPULATE_READ, even when a bank is being replaced concurrently.
// Opening, prefaulting and collection are control/background operations only.
class MappedSampleRegion final {
public:
    static std::shared_ptr<const MappedSampleRegion> own(void* mapping, std::size_t bytes);
    static bool prefault(std::uintptr_t begin, std::size_t bytes, std::size_t* pagesTouched = nullptr) noexcept;
    static void collectUnused() noexcept;
    ~MappedSampleRegion();

    MappedSampleRegion(const MappedSampleRegion&) = delete;
    MappedSampleRegion& operator=(const MappedSampleRegion&) = delete;

private:
    MappedSampleRegion(void* mapping, std::size_t bytes) noexcept : mapping_(mapping), bytes_(bytes) {}
    void* mapping_{nullptr};
    std::size_t bytes_{0U};
};

// Direct read-only view of interleaved little-endian sample memory (normally
// the memory-mapped bank). data == nullptr means "not available".
struct RawPcmView {
    static constexpr std::uint8_t kNone = 0U;
    static constexpr std::uint8_t kPcm16 = 1U;
    static constexpr std::uint8_t kPcm24 = 2U;
    static constexpr std::uint8_t kFloat32 = 3U;

    const std::uint8_t* data{nullptr}; // first byte of frame 0
    std::uint64_t frames{0};
    std::uint16_t channels{0};
    std::uint8_t format{kNone};

    [[nodiscard]] std::size_t bytesPerSample() const noexcept {
        return format == kPcm16 ? 2U : (format == kPcm24 ? 3U : (format == kFloat32 ? 4U : 0U));
    }
    [[nodiscard]] std::size_t frameBytes() const noexcept { return bytesPerSample() * channels; }
};

class SampleStream {
public:
    virtual ~SampleStream() = default;
    [[nodiscard]] virtual std::uint64_t frameCount() const noexcept = 0;
    [[nodiscard]] virtual std::uint16_t channels() const noexcept = 0;
    [[nodiscard]] virtual std::uint32_t sampleRate() const noexcept = 0;
    [[nodiscard]] virtual float readFrame(std::uint64_t frame, std::uint16_t channel) const noexcept = 0;
    [[nodiscard]] virtual RawPcmView rawView() const noexcept { return {}; }
};

struct MappedPcmSpec {
    std::uint64_t dataOffset{0};
    std::uint64_t frameCount{0};
    std::uint32_t sampleRate{0};
    std::uint16_t channels{0};
    std::uint16_t bitDepth{0};
    std::uint16_t formatTag{0}; // WAV: 1 PCM, 3 IEEE float
    bool bigEndian{false};
};

class MappedPcmStream final : public SampleStream {
public:
    static std::shared_ptr<MappedPcmStream> open(const std::string& path, const MappedPcmSpec& spec, std::string& error);
    ~MappedPcmStream() override;

    [[nodiscard]] std::uint64_t frameCount() const noexcept override { return spec_.frameCount; }
    [[nodiscard]] std::uint16_t channels() const noexcept override { return spec_.channels; }
    [[nodiscard]] std::uint32_t sampleRate() const noexcept override { return spec_.sampleRate; }
    [[nodiscard]] float readFrame(std::uint64_t frame, std::uint16_t channel) const noexcept override;
    [[nodiscard]] RawPcmView rawView() const noexcept override;

private:
    MappedPcmStream() = default;
    MappedPcmSpec spec_{};
    int fd_{-1};
    void* mapping_{nullptr};
    std::uint64_t mappingSize_{0};
    std::shared_ptr<const MappedSampleRegion> region_;
};

} // namespace silveton::sampler
