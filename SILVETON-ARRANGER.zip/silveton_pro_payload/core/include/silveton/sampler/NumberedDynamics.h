#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton::sampler {

// Semantic controls for SILVETON's own implementation of the seven numbered
// Dynamics functions. These are not Korg packed fields, DSP coefficients or
// factory defaults. Manual references: Pa5X v1.5, printed pages 1380-1393.
enum class NumberedDynamicsDetector : std::uint8_t {
    Mix, Left, Right, Independent
};
enum class NumberedDynamicsLowShelf : std::uint8_t { Low, MidLow };
enum class NumberedDynamicsHighShelf : std::uint8_t { High, MidHigh };

struct NumberedDynamicsConfig {
    std::uint16_t index{1}; // 1, 2, 3, 4, 5, 154 or 171 only.
    NumberedDynamicsDetector detector{NumberedDynamicsDetector::Mix};

    float sensitivity{50.0F}; // Compressor 1/171, displayed 1..100.
    float attack{20.0F};      // Displayed 1..100, not milliseconds.
    float release{50.0F};     // Limiter/gate displayed 1..100.
    float ratio{4.0F};        // Limiter 1:1..50:1; infinity is separate.
    bool infiniteRatio{false};
    float thresholdDb{-12.0F}; // -40..0, or -30..0 for mastering.

    float eqTrim{1.0F}; // Stereo Compressor only; displayed EQ Trim / 100.
    NumberedDynamicsLowShelf lowShelf{NumberedDynamicsLowShelf::Low};
    NumberedDynamicsHighShelf highShelf{NumberedDynamicsHighShelf::High};
    float lowShelfGainDb{0.0F};  // -15..15.
    float highShelfGainDb{0.0F}; // -15..15.

    bool sideEqEnabled{false}; // Stereo Limiter / Stereo Gate detector only.
    bool triggerMonitor{false};
    float sideEqHz{1000.0F}; // 20..12000 Hz, additionally limited by Nyquist.
    float sideEqQ{1.0F};     // 0.5..10.
    float sideEqGainDb{0.0F}; // -18..18.

    // Low/mid/high detector gains, never output EQ or band makeup gains.
    std::array<float, 3> bandOffsetDb{{0.0F, 0.0F, 0.0F}}; // -40..0.

    float ceilingDb{-0.3F}; // Mastering output ceiling, -30..0 dBFS.
    float masteringReleaseMs{100.0F}; // 0.5..1000 ms.

    bool gateDmod{false}; // false = Input, true = supplied gateControl.
    bool gateNegativePolarity{false};
    float gateThreshold{10.0F}; // Displayed 0..100; own amplitude law below.
    float gateDelayMs{0.0F};    // 0..100 ms, main path only.
};

struct NumberedDynamicsModulation {
    // The caller resolves the selected DMS and its polarity/range. The gate
    // treats this normalized value as closed below 0.5 and open at/above 0.5.
    float gateControl{0.0F};
    // Optional, already-selected FX Control Bus. Only algorithms 2/5 use it.
    // Providing one never changes the main signal or its channel ownership.
    bool externalSidechain{false};
    float sidechainL{0.0F};
    float sidechainR{0.0F};
};

// The returned signal is fully processed (100% wet). The owner applies the
// manual Output Level / Gain Adjust, its DMS and Wet/Dry exactly once outside
// this module. Out Ceiling is intrinsic to algorithm 4 and is applied here.
// Compressor sensitivity includes its own intrinsic automatic makeup law.
//
// Explicit SILVETON choices where the manual does not specify a DSP law:
// - sensitivity 1..100 maps to a 0..-36 dB threshold at 4:1, with automatic
//   makeup that retains the steady full-scale level;
// - compressor Attack preserves transients via a 0.2..40 ms logarithmic time;
//   its release is 120 ms. Other Attack/Release scales use the functions below;
// - compressor shelf choices use 100/400 Hz and 8/3 kHz, slope 1;
// - multiband crossovers are phase-compensated fourth-order Linkwitz-Riley
//   at 200 Hz and 2 kHz. Their unity-gain sum is all-pass, not zero-phase;
// - mastering is a linked sample-peak limiter, not an inter-sample true-peak
//   model; its attack is immediate and introduces no look-ahead latency;
// - gate Threshold 1..100 maps logarithmically from -80..0 dBFS; 0 admits any
//   nonzero input. A 20 ms detector fall time prevents zero-crossing chatter.
// None of these choices asserts the proprietary Korg transfer function.
// The Config initializers are explicit SILVETON starting values only.
class NumberedDynamics {
public:
    using Config = NumberedDynamicsConfig;
    using Modulation = NumberedDynamicsModulation;
    using Detector = NumberedDynamicsDetector;
    using LowShelf = NumberedDynamicsLowShelf;
    using HighShelf = NumberedDynamicsHighShelf;

    // Call while rendering is stopped. This is the only allocating method;
    // reserve covers the entire 100 ms gate range at the prepared sample rate.
    void prepare(double sampleRate);
    // The owner serializes configuration with processing at block boundaries.
    // No allocation, locks or I/O. A changed algorithm resets prior history.
    void configure(const Config& config) noexcept;
    void reset() noexcept;
    void process(float inL, float inR, float& outL, float& outR,
                 const Modulation& modulation = {}) noexcept;

    [[nodiscard]] static bool supports(std::uint16_t index) noexcept;
    [[nodiscard]] const Config& config() const noexcept { return config_; }
    [[nodiscard]] static double attackMilliseconds(std::uint16_t index,
                                                   float value) noexcept;
    [[nodiscard]] static double releaseMilliseconds(std::uint16_t index,
                                                    float value) noexcept;
    [[nodiscard]] static double gateThresholdAmplitude(float value) noexcept;

private:
    struct Biquad {
        double b0{1.0}, b1{0.0}, b2{0.0}, a1{0.0}, a2{0.0};
        double z1{0.0}, z2{0.0};
        void identity() noexcept;
        void lowPass(double sampleRate, double hz) noexcept;
        void highPass(double sampleRate, double hz) noexcept;
        void allPass(double sampleRate, double hz) noexcept;
        void shelf(double sampleRate, double hz, double gainDb, bool high) noexcept;
        void peak(double sampleRate, double hz, double q, double gainDb) noexcept;
        void clear() noexcept;
        double tick(double value) noexcept;
    };
    struct Crossover {
        std::array<Biquad, 2> low1{}, high1{}, mid2{}, high2{};
        Biquad lowPhase2{};
        void configure(double sampleRate) noexcept;
        void clear() noexcept;
        void split(double input, std::array<double, 3>& bands) noexcept;
    };

    void trigger(double inL, double inR, const Modulation& modulation,
                 double& left, double& right) noexcept;
    double compress(double signal, double detector, std::size_t cell) noexcept;
    void delayed(double inL, double inR, double& outL, double& outR) noexcept;

    Config config_{};
    double sampleRate_{48000.0};
    bool prepared_{false};
    bool configured_{false};
    std::array<Biquad, 2> lowShelf_{}, highShelf_{}, sideEq_{};
    std::array<Crossover, 2> crossovers_{};
    std::array<double, 6> gain_{{1.0, 1.0, 1.0, 1.0, 1.0, 1.0}};
    std::array<double, 3> bandOffset_{{1.0, 1.0, 1.0}};
    double threshold_{1.0};
    double compressionExponent_{0.75};
    double automaticMakeup_{1.0};
    double attackCoefficient_{0.0};
    double releaseCoefficient_{0.0};
    double ceiling_{1.0};
    double masterDrive_{1.0};
    double masterGain_{1.0};
    double gateThreshold_{0.0};
    double gateDetector_{0.0};
    double gateDetectorFall_{0.0};
    double gateGain_{0.0};
    double delaySamples_{0.0};
    std::vector<float> delayLeft_{}, delayRight_{};
    std::size_t delayWrite_{0}, delayValid_{0};
};

} // namespace silveton::sampler
