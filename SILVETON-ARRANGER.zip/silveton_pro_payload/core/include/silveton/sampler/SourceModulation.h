#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>

namespace silveton::sampler {

constexpr std::size_t kSourceAmsCount=46U;
constexpr bool sourceAmsSupported(unsigned source) noexcept {return source<kSourceAmsCount;}
constexpr int sourceSignedByte(std::uint8_t value) noexcept {
    return value<128U?static_cast<int>(value):static_cast<int>(value)-256;
}
constexpr float sourceDirection(std::uint8_t packed,unsigned segment) noexcept {
    const auto code=(static_cast<unsigned>(packed)>>(2U*segment))&3U;
    return code==1U?1.0F:code==3U?-1.0F:0.0F;
}
constexpr bool sourceDirectionsValid(std::uint8_t packed,unsigned count) noexcept {
    for(unsigned i=0U;i<count;++i)if(((static_cast<unsigned>(packed)>>(2U*i))&3U)==2U)return false;
    return count==4U||(static_cast<unsigned>(packed)>>(2U*count))==0U;
}
constexpr bool sourceAmsRouteValid(std::uint8_t source,int intensity,int limit=99) noexcept {
    return intensity>=-limit&&intensity<=limit&&(intensity==0||sourceAmsSupported(source));
}

struct SourceModulationValues {
    std::array<float,kSourceAmsCount> value{};
    float operator[](unsigned id) const noexcept {return id<value.size()?value[id]:0.0F;}
};

struct SourceModulationContext {
    const std::array<float,128>* controllers{nullptr};
    const std::array<bool,128>* controllersSeen{nullptr};
    std::uint8_t key{60U},velocity{127U},releaseVelocity{64U};
    bool released{false},controlEnabled{true},pressureEnabled{true},bendEnabled{true};
    bool damper{false};
    float pressure{0.0F},polyPressure{0.0F},pitchBend{0.0F},tempoBpm{120.0F};
    float velocityPosition{-1.0F},velocityLevelScale{1.0F};
    int portamentoSwitch{-1};
    float manualCutoffHz{-1.0F},manualResonance{-1.0F};
    float filterExtraOctaves{0.0F},resonanceExtra{0.0F};
    bool filterReplacedByTone{false};
    float pitchEnvelope{0.0F},filterEnvelope{0.0F},amplitudeEnvelope{0.0F};
    std::array<float,2> lfo{};
    std::array<std::uint8_t,2> filterKeys{{0U,127U}},amplitudeKeys{{0U,127U}};
    std::array<std::int8_t,2> filterRamps{},amplitudeRamps{};

    float controller(unsigned cc,bool bipolar=false) const noexcept {
        if(!controlEnabled||controllers==nullptr||cc>=128U)return 0.0F;
        // A never-received bipolar controller starts at its neutral centre.
        // This is our explicit runtime default, not an invented saved value.
        if(bipolar&&controllersSeen!=nullptr&&!(*controllersSeen)[cc])return 0.0F;
        const float value=std::clamp((*controllers)[cc],0.0F,1.0F);
        if(!bipolar)return value;
        const float raw=value*127.0F;
        return raw>=64.0F?(raw-64.0F)/63.0F:(raw-64.0F)/64.0F;
    }
};

inline std::array<float,2> sourceKeyboardRamps(std::uint8_t key,
        const std::array<std::uint8_t,2>& keys,const std::array<std::int8_t,2>& ramps) noexcept {
    const float played=static_cast<float>(std::min<unsigned>(key,127U));
    const float low=static_cast<float>(keys[0]),high=static_cast<float>(keys[1]);
    // Own normalized straight ramps, preserving the documented centres,
    // signs and zero plateau. No claim of the manufacturer's taper is made.
    return {{played<low?(low-played)/std::max(1.0F,low)*static_cast<float>(ramps[0])/99.0F:0.0F,
        played>high?(played-high)/std::max(1.0F,127.0F-high)*static_cast<float>(ramps[1])/99.0F:0.0F}};
}

inline SourceModulationValues sourceModulationValues(const SourceModulationContext& context) noexcept {
    SourceModulationValues result;
    auto& value=result.value;
    value[1]=context.pitchEnvelope;value[2]=context.filterEnvelope;value[3]=context.amplitudeEnvelope;
    value[4]=context.lfo[0];value[5]=context.lfo[1];
    const auto filter=sourceKeyboardRamps(context.key,context.filterKeys,context.filterRamps);
    const auto amp=sourceKeyboardRamps(context.key,context.amplitudeKeys,context.amplitudeRamps);
    for(unsigned kind=0U;kind<2U;++kind){
        const auto& ramp=kind==0U?filter:amp;const auto base=6U+4U*kind;
        value[base]=std::clamp(ramp[0]+ramp[1],-1.0F,1.0F);
        value[base+1U]=std::clamp(ramp[0]-ramp[1],-1.0F,1.0F);
        value[base+2U]=std::clamp(ramp[1],-1.0F,1.0F);
        value[base+3U]=std::clamp(ramp[0],-1.0F,1.0F);
    }
    const float note=static_cast<float>(context.key)-60.0F;
    value[14]=note/24.0F; // PG209: C2/C4/C6 correspond to-1/0/+1
    const float velocity=context.velocityPosition>=0.0F?std::clamp(context.velocityPosition,0.0F,1.0F):
        static_cast<float>(context.velocity)/127.0F;
    value[15]=velocity;
    value[16]=context.pressureEnabled?std::clamp(context.polyPressure,0.0F,1.0F):0.0F;
    value[17]=context.pressureEnabled?std::clamp(context.pressure,0.0F,1.0F):0.0F;
    value[18]=context.bendEnabled?std::clamp(context.pitchBend,-1.0F,1.0F):0.0F;
    value[19]=context.controller(1U);value[20]=context.controller(2U);
    value[21]=std::clamp(value[19]+value[17]*.5F,0.0F,1.0F);
    value[22]=std::clamp(value[20]+value[17]*.5F,0.0F,1.0F);
    value[23]=context.controller(4U);value[24]=context.controller(16U,true);
    value[25]=context.controller(18U);
    constexpr std::array<unsigned,4> knobs{{17U,19U,20U,21U}};
    for(unsigned i=0U;i<4U;++i){
        value[26U+i]=context.controller(knobs[i],true);
        // Official TR/Triton Le PG: the [+] variant starts at zero at the
        // far-left position and uses the complete positive controller range.
        value[30U+i]=context.controller(knobs[i]);
    }
    value[34]=context.damper?1.0F:0.0F;
    value[35]=context.controlEnabled&&context.portamentoSwitch>=0?(context.portamentoSwitch>=64?1.0F:0.0F):
        (context.controller(65U)>=64.0F/127.0F?1.0F:0.0F);
    value[36]=context.controller(66U)>=64.0F/127.0F?1.0F:0.0F;
    value[37]=context.controller(67U)>=64.0F/127.0F?1.0F:0.0F;
    for(unsigned i=0U;i<4U;++i)value[38U+i]=context.controller(80U+i)>=64.0F/127.0F?1.0F:0.0F;
    // Official Triton PG208 anchors Tempo at120:60=-1,240=+1.
    value[42]=std::log2(std::clamp(context.tempoBpm,1.0F,999.0F)/120.0F);
    value[43]=context.released?static_cast<float>(context.releaseVelocity)/127.0F:velocity;
    // The source identities/functions are corroborated by the official Pa5X
    // GUI. The exponential/logarithmic response functions below are our own.
    value[44]=velocity*velocity;
    value[45]=std::log1p(9.0F*velocity)/std::log(10.0F);
    return result;
}

// Official Triton normal Program table1-7. These bytes encode a segmented
// semitone scale; treating the raw signed byte as cents loses the source value.
constexpr float sourcePitchSemitones(std::uint8_t raw) noexcept {
    const int signedValue=sourceSignedByte(raw);
    const int magnitude=signedValue<0?-signedValue:signedValue;
    const float value=magnitude<=50?static_cast<float>(magnitude)*.01F:
        magnitude<=60?.5F+static_cast<float>(magnitude-50)*.05F:
        1.0F+static_cast<float>(magnitude-60)*.2F;
    return signedValue<0?-value:value;
}

// Pa5X manual pp.1133 and1161 gives exact maximum factors for these index
// anchors. Linear interpolation between log2 anchors is our continuous law.
inline float sourceModulationOctaves(float intensity) noexcept {
    constexpr std::array<float,7> index{{0.0F,16.0F,33.0F,49.0F,66.0F,82.0F,99.0F}};
    const float x=std::clamp(std::abs(intensity),0.0F,99.0F);
    unsigned hi=1U;while(hi+1U<index.size()&&x>index[hi])++hi;
    const float y=static_cast<float>(hi-1U)+(x-index[hi-1U])/(index[hi]-index[hi-1U]);
    return intensity<0.0F?-y:y;
}

} // namespace silveton::sampler
