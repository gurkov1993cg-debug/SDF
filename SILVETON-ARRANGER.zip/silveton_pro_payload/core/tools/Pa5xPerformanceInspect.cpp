// Read-only extraction of a Pa5X Keyboard Set/Pad and its original MIDI/XML.
// Proprietary payload preservation is not effect algorithm or DSP execution.
#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/arranger/KorgResourceContainer.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

namespace {
using namespace silveton::arranger;
// Small JSON writer: integer bytes are emitted as numbers, never characters.
class Json {
public:
    explicit Json(std::ostream& out) : out_(out) {}
    void object() { before(); out_ << '{'; levels_.push_back({true, true, false}); }
    void array() { before(); out_ << '['; levels_.push_back({false, true, false}); }
    void end() {
        if (levels_.empty() || levels_.back().awaiting)
            throw std::logic_error("Incomplete JSON container");
        const auto level = levels_.back(); levels_.pop_back();
        if (!level.first) newline();
        out_ << (level.object ? '}' : ']');
    }
    void key(const char* name) {
        if (levels_.empty() || !levels_.back().object || levels_.back().awaiting)
            throw std::logic_error("Invalid JSON key");
        auto& level = levels_.back();
        if (!level.first) out_ << ',';
        level.first = false; newline(); quote(name); out_ << ": "; level.awaiting = true;
    }
    void value(const std::string& value) { before(); quote(value); }
    void value(const char* value) { this->value(std::string(value)); }
    void value(bool value) { before(); out_ << (value ? "true" : "false"); }
    template<class T, typename std::enable_if<std::is_integral<T>::value &&
            !std::is_same<T, bool>::value, int>::type = 0>
    void value(T number) {
        before();
        if constexpr (std::is_signed<T>::value) out_ << static_cast<long long>(number);
        else out_ << static_cast<unsigned long long>(number);
    }
    void null() { before(); out_ << "null"; }
    template<class T> void field(const char* name, const T& value) { key(name); this->value(value); }
    template<class Range> void numbers(const char* name, const Range& values) {
        key(name); array(); for (const auto value : values) this->value(value); end();
    }
    void strings(const char* name, const std::vector<std::string>& values) {
        key(name); array(); for (const auto& value : values) this->value(value); end();
    }
private:
    struct Level { bool object, first, awaiting; };
    std::ostream& out_;
    std::vector<Level> levels_;
    void newline() { out_ << '\n' << std::string(levels_.size() * 2, ' '); }
    void before() {
        if (levels_.empty()) return;
        auto& level = levels_.back();
        if (level.object) {
            if (!level.awaiting) throw std::logic_error("Missing JSON object key");
            level.awaiting = false;
        } else {
            if (!level.first) out_ << ',';
            level.first = false; newline();
        }
    }
    void quote(const std::string& text) {
        constexpr char hex[] = "0123456789abcdef";
        out_ << '"';
        for (std::size_t i = 0; i < text.size(); ++i) {
            const auto c = static_cast<unsigned char>(text[i]);
            if (c == '"' || c == '\\') { out_ << '\\' << static_cast<char>(c); continue; }
            if (c >= 32 && c < 127) { out_ << static_cast<char>(c); continue; }
            // Preserve valid UTF-8; encode an isolated non-UTF8 byte explicitly.
            std::size_t count = c >= 0xC2 && c <= 0xDF ? 2 :
                c >= 0xE0 && c <= 0xEF ? 3 : c >= 0xF0 && c <= 0xF4 ? 4 : 0;
            bool utf8 = count != 0 && count <= text.size() - i;
            for (std::size_t n = 1; utf8 && n < count; ++n) {
                const auto next = static_cast<unsigned char>(text[i + n]);
                utf8 = (next & 0xC0U) == 0x80U;
            }
            if (utf8 && count >= 3) {
                const auto next = static_cast<unsigned char>(text[i + 1]);
                utf8 = !(c == 0xE0 && next < 0xA0) && !(c == 0xED && next >= 0xA0) &&
                    !(c == 0xF0 && next < 0x90) && !(c == 0xF4 && next >= 0x90);
            }
            if (utf8) { out_.write(text.data() + i, static_cast<std::streamsize>(count)); i += count - 1; }
            else out_ << "\\u00" << hex[c >> 4U] << hex[c & 15U];
        }
        out_ << '"';
    }
};

template<class Range> std::string hexBytes(const Range& bytes, std::size_t count = std::numeric_limits<std::size_t>::max()) {
    constexpr char hex[] = "0123456789abcdef";
    std::string result; count = std::min(count, bytes.size()); result.reserve(count * 2);
    for (std::size_t i = 0; i < count; ++i) {
        const auto byte = static_cast<unsigned char>(bytes[i]);
        result.push_back(hex[byte >> 4U]); result.push_back(hex[byte & 15U]);
    }
    return result;
}

void channelEvent(Json& j,const KorgMidiChannelEvent& event) {
    j.object();j.field("kind","channel");j.field("tick",event.tick);j.field("track",event.track);
    j.field("order",event.order);j.field("status",event.status);j.field("channel_zero_based",event.status&15U);
    j.field("data1",event.data1);j.field("data2",event.data2);
    if((event.status&0xF0U)==0xB0U){j.field("controller",event.data1);j.field("controller_value",event.data2);}
    j.end();
}
void opaqueEvent(Json& j,const KorgMidiOpaqueEvent& event) {
    j.object();j.field("kind","opaque");j.field("tick",event.tick);j.field("track",event.track);
    j.field("order",event.order);j.field("status",event.status);j.field("meta_type",event.metaType);
    j.field("payload_size_bytes",event.payload.size());j.field("payload_hex",hexBytes(event.payload));
    j.field("semantics_decoded",false);j.end();
}
void channelEvents(Json& j,const char* name,const std::vector<KorgMidiChannelEvent>& events) {
    j.key(name);j.array();for(const auto& event:events)channelEvent(j,event);j.end();
}
void opaqueEvents(Json& j,const char* name,const std::vector<KorgMidiOpaqueEvent>& events) {
    j.key(name);j.array();for(const auto& event:events)opaqueEvent(j,event);j.end();
}
void orderedEvents(Json& j,const std::vector<KorgMidiChannelEvent>& channels,
        const std::vector<KorgMidiOpaqueEvent>& opaque) {
    struct EventRef {std::uint32_t tick;std::uint64_t order;std::size_t index;bool opaque;};
    std::vector<EventRef> refs;refs.reserve(channels.size()+opaque.size());
    for(std::size_t i=0;i<channels.size();++i)refs.push_back({channels[i].tick,channels[i].order,i,false});
    for(std::size_t i=0;i<opaque.size();++i)refs.push_back({opaque[i].tick,opaque[i].order,i,true});
    std::stable_sort(refs.begin(),refs.end(),[](const auto& a,const auto& b){return a.tick<b.tick||(a.tick==b.tick&&a.order<b.order);});
    j.key("ordered_channel_and_opaque_events");j.array();
    for(const auto& ref:refs){if(ref.opaque)opaqueEvent(j,opaque[ref.index]);else channelEvent(j,channels[ref.index]);}
    j.end();
}
void midiInspection(Json& j,const KorgMidiInspection& midi) {
    j.object();j.field("valid",midi.valid);j.field("error",midi.error);j.field("format",midi.format);
    j.field("ppq",midi.ppq);j.field("span_ticks",midi.spanTicks);j.field("event_count",midi.eventCount);
    j.key("tracks");j.array();for(const auto& track:midi.tracks){
        j.object();j.field("end_tick",track.endTick);j.key("first_channel_tick");
        if(track.firstChannelTick==std::numeric_limits<std::uint32_t>::max())j.null();else j.value(track.firstChannelTick);
        j.field("has_notes",track.notes);j.field("has_end",track.hasEnd);j.field("meter_known",track.meterKnown);
        j.field("meter_changed",track.meterChanged);j.field("numerator",track.numerator);j.field("denominator",track.denominator);
        j.field("name",track.name);j.end();
    }j.end();
    j.key("patch_selections");j.array();for(const auto& patch:midi.patches){
        j.object();j.field("tick",patch.tick);j.field("track",patch.track);j.field("order",patch.order);
        j.field("channel_zero_based",patch.channel);j.field("msb",patch.msb);j.field("lsb",patch.lsb);
        j.field("program",patch.program);j.field("used_by_notes",patch.usedByNotes);j.end();
    }j.end();
    channelEvents(j,"channel_events",midi.channelEvents);opaqueEvents(j,"opaque_midi_events",midi.opaqueMidiEvents);
    orderedEvents(j,midi.channelEvents,midi.opaqueMidiEvents);
    j.key("tempos");j.array();for(const auto& tempo:midi.tempos){j.object();j.field("tick",tempo.tick);
        j.field("track",tempo.track);j.field("microseconds_per_quarter",tempo.microsecondsPerQuarter);j.end();}j.end();
    j.key("time_signatures");j.array();for(const auto& meter:midi.timeSignatures){j.object();j.field("tick",meter.tick);
        j.field("track",meter.track);j.field("numerator",meter.numerator);j.field("denominator",meter.denominator);j.end();}j.end();
    j.end();
}
void complement(Json& j,const Pa5xPerformanceComplement& value) {
    j.object();j.field("present",value.present);j.field("semantics_decoded",value.semanticsDecoded);
    j.field("resource_path",value.resourcePath);j.field("original_smf_size_bytes",value.midiBytes.size());
    j.field("original_smf_hex",hexBytes(value.midiBytes));j.key("midi");midiInspection(j,value.midi);j.end();
}
void part(Json& j,const Pa5xPerformancePart& value) {
    j.object();j.field("role_track",value.track);j.field("name",value.name);j.field("resource_path",value.resourcePath);
    j.field("present",value.present);j.field("mute_raw",value.mute);j.field("key_low",value.keyLow);j.field("key_high",value.keyHigh);
    j.field("velocity_low",value.velocityLow);j.field("velocity_high",value.velocityHigh);j.field("track_route_raw",value.trackRoute);
    j.field("actuator_raw",value.actuatorRaw);j.field("controllers_raw",value.controllersRaw);
    j.field("transposition_declared",value.transpositionDeclared);j.field("transposition_raw",value.transpositionRaw);
    j.field("ppq",value.ppq);j.field("midi_span_ticks",value.midiSpanTicks);j.field("midi_event_count",value.midiEventCount);
    j.field("has_note_events",value.hasNoteEvents);
    j.key("patches");j.array();for(const auto& patch:value.patches){
        j.object();j.field("tick",patch.tick);j.field("channel_zero_based",patch.channel);j.field("msb",patch.msb);
        j.field("lsb",patch.lsb);j.field("program",patch.program);j.field("address_complete",patch.addressComplete);j.end();
    }j.end();
    j.key("channel_final_values");j.array();for(const auto& channel:value.channels){
        j.object();j.field("channel_zero_based",channel.channel);j.field("volume_raw",channel.volumeRaw);
        j.field("pan_raw",channel.panRaw);j.field("expression_raw",channel.expressionRaw);j.end();
    }j.end();
    channelEvents(j,"channel_events",value.channelEvents);opaqueEvents(j,"opaque_midi_events",value.opaqueMidiEvents);
    orderedEvents(j,value.channelEvents,value.opaqueMidiEvents);
    j.field("pattern_type",value.patternType);j.field("ntt_raw",value.ntt);j.field("ntr_raw",value.ntr);
    j.field("retrigger_raw",value.retrigger);j.field("wrap_around_degree_raw",value.wrapAroundDegree);
    j.field("loop_declared",value.loopDeclared);j.field("loop_number_raw",value.loopNumberRaw);j.field("loop_length_raw",value.loopLengthRaw);
    j.key("cv_sources");j.array();for(const auto& cv:value.cvSources){j.object();j.field("number",cv.number);j.field("root",cv.root);j.field("chord",cv.chord);j.end();}j.end();
    j.key("chord_selections");j.array();for(const auto& chord:value.chordSelections){j.object();j.field("chord",chord.chord);j.field("cv",chord.cv);j.end();}j.end();j.end();
}
void performance(Json& j,const Pa5xPerformanceInspection& value) {
    j.object();j.field("recognized",value.recognized);j.field("valid",value.valid);j.field("playable",value.playable);
    j.field("kind_code",static_cast<unsigned>(value.kind));j.field("source_path",value.sourcePath);j.field("display_name",value.displayName);
    j.field("filename_ordinal",value.filenameOrdinal);j.field("stable_resource_id_known",value.stableResourceIdKnown);
    j.field("stable_resource_id",value.stableResourceId);j.field("version",value.version);j.field("release",value.release);j.field("subtype",value.subtype);
    j.field("split_point",value.splitPoint);j.field("use_global_split_raw",value.useGlobalSplit);
    j.field("upper_octave_declared",value.upperOctaveDeclared);j.field("upper_octave_transpose_raw",value.upperOctaveTransposeRaw);
    j.field("chord_scanning_raw",value.chordScanningRaw);j.field("keyboard_mode_raw",value.keyboardModeRaw);j.field("lower_use_raw",value.lowerUseRaw);
    j.field("bass_inversion_raw",value.bassInversionRaw);
    j.key("parts");j.array();for(const auto& valuePart:value.parts)part(j,valuePart);j.end();
    j.strings("warnings",value.warnings);j.strings("playback_blockers",value.playbackBlockers);j.field("error",value.error);j.end();
}
void recall(Json& j,const Pa5xKeyboardSetRead& value) {
    j.object();j.field("recognized",value.recognized);j.field("valid",value.valid);j.field("read_complete",value.readComplete);
    j.field("sound_activation_supported",value.soundActivationSupported);j.field("name",value.name);j.field("error",value.error);
    j.field("split_point",value.splitPoint);j.field("use_global_split_raw",value.useGlobalSplit);
    j.field("upper_octave_transpose_known",value.upperOctaveTransposeKnown);j.field("upper_octave_transpose",value.upperOctaveTranspose);
    j.field("lower_use_raw",value.lowerUseRaw);j.strings("issues",value.issues);
    j.field("bass_inversion_raw",value.bassInversionRaw);
    j.key("parts");j.array();for(const auto& valuePart:value.parts){
        j.object();j.field("role",valuePart.role);j.field("name",valuePart.name);j.field("resource_path",valuePart.resourcePath);
        j.field("present",valuePart.present);j.field("recall_setup_valid",valuePart.recallSetupValid);j.field("address_known",valuePart.addressKnown);
        j.field("channel_zero_based",valuePart.channel);j.field("msb",valuePart.msb);j.field("lsb",valuePart.lsb);j.field("program",valuePart.program);
        j.field("setup_last_tick",valuePart.setupLastTick);j.field("sound_status",pa5xKeyboardSetSoundStatusName(valuePart.status));
        j.field("sound_name",valuePart.soundName);j.field("sound_path",valuePart.soundPath);j.field("sound_message",valuePart.soundMessage);
        j.field("mute_raw",valuePart.mute);j.field("key_low",valuePart.keyLow);j.field("key_high",valuePart.keyHigh);
        j.field("velocity_low",valuePart.velocityLow);j.field("velocity_high",valuePart.velocityHigh);
        j.field("volume_raw",valuePart.volumeRaw);j.field("pan_raw",valuePart.panRaw);j.field("expression_raw",valuePart.expressionRaw);
        j.field("pitch_bend_range_semitones",valuePart.pitchBendRangeSemitones);
        j.field("source_coarse_tune_raw",valuePart.coarseTuneRaw);j.field("source_fine_tune_raw",valuePart.fineTuneRaw);
        j.numbers("source_sound_edit_cc71_78_raw",valuePart.sourceSoundEdits.raw);
        j.field("source_portamento_cc5_raw",valuePart.sourceSoundEdits.portamentoTimeRaw);
        j.field("source_portamento_cc65_raw",valuePart.sourceSoundEdits.portamentoOnRaw);
        j.numbers("master_fx_send_raw",valuePart.masterFxSendRaw);
        j.field("octave_transpose_known",valuePart.octaveTransposeKnown);j.field("octave_transpose",valuePart.octaveTranspose);
        j.field("part_transposition_declared",valuePart.partTranspositionDeclared);j.field("part_transposition_raw",valuePart.partTranspositionRaw);
        opaqueEvents(j,"opaque_midi_events",valuePart.opaqueMidiEvents);j.strings("issues",valuePart.issues);j.end();
    }j.end();j.end();
}
std::vector<std::uint8_t> readFile(const std::string& path) {
    std::ifstream file(path,std::ios::binary|std::ios::ate);if(!file)throw std::runtime_error("Cannot open performance file");
    const auto size=file.tellg();if(size<0||size>static_cast<std::streamoff>(64U*1024U*1024U))
        throw std::runtime_error("Performance file exceeds the 64 MiB inspection limit");
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));file.seekg(0);
    if(!bytes.empty())file.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    if(!file)throw std::runtime_error("Performance file read failed");
    return bytes;
}
bool xmlPath(const std::vector<std::string>& path) {
    if(path.empty()||path.back().size()<4U)return false;
    std::string name=path.back();std::transform(name.begin(),name.end(),name.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    return name.compare(name.size()-4U,4U,".xml")==0;
}
void xmlResources(Json& j,const KorgResourceContainer& container,const std::vector<std::uint8_t>& bytes) {
    j.key("xml_resources");j.array();if(container.valid)for(const auto& leaf:container.leaves)if(xmlPath(leaf.path)){
        if(leaf.offset>bytes.size()||leaf.length>bytes.size()-leaf.offset)throw std::runtime_error("XML resource exceeds source file");
        const std::vector<std::uint8_t> raw(bytes.begin()+static_cast<std::ptrdiff_t>(leaf.offset),bytes.begin()+static_cast<std::ptrdiff_t>(leaf.offset+leaf.length));
        j.object();j.field("resource_path",korgResourcePath(leaf.path));j.field("file_offset",leaf.offset);
        j.field("length_bytes",leaf.length);j.field("text",korgResourceText(bytes,leaf));j.field("raw_hex",hexBytes(raw));j.end();
    }j.end();
}
void notes(Json& j) {
    j.key("interpretation");j.object();
    j.field("operation","Read-only extraction; no changes to the file, no DSP activation and no proprietary MIDI replay.");
    j.field("source_scope","Pa5X Root/Branch/Leaf KeyboardSetClip/PadClip. Legacy PRF banks are not assumed compatible.");
    j.field("unknown_values","Absent MIDI address, mix and FX-send declarations remain -1. Other optional numeric fields may have a stored structure default; inspect their declared/known flags. No default Sound address, mix or FX-send value is invented.");
    j.field("event_order","Order is the original global SMF event ordinal; sort by tick then order to merge channel and opaque messages. Unexported ordinary meta events may leave ordinal gaps.");
    j.field("effect_sends","Keyboard Set recall master_fx_send_raw slots1/2/3 correspond to CC91/93/94. These are sends, not effect algorithm identities or calibrated gain values.");
    j.field("channel_final_values","Performance channel_final_values are inspection summaries, not proof every later MIDI event occurs at recall tick0. Canonical note-free recall results are supplied separately.");
    j.field("fx_algorithms","Original complement SysEx, effect algorithm IDs, routing and parameter packing remain uninterpreted. The complete SMF and original opaque bytes are preserved.");
    j.field("catalog_resolution","No SET bank is supplied to this standalone tool. Exact original addresses and recall setup can be read even when Sound catalogue resolution remains unavailable.");
    j.field("strings","Valid UTF-8 is preserved; isolated non-UTF8 bytes are escaped as U+00xx. XML raw_hex retains exact original bytes.");j.end();
}
} // namespace

int main(int argc,char** argv) {
    if(argc!=2){std::cerr<<"Usage: silveton_pa5x_performance_inspect FILE.ksc\n";return 2;}
    try{
        const std::string path(argv[1]);const auto bytes=readFile(path);
        const auto container=inspectKorgResourceContainer(bytes);
        const auto inspection=inspectPa5xPerformanceBytes(bytes,path);
        const auto keyboard=readPa5xKeyboardSet(inspection,nullptr);
        Json j(std::cout);j.object();j.field("schema","silveton.pa5x.performance-inspection.v1");
        j.field("source_file",path);j.field("file_size_bytes",bytes.size());notes(j);
        j.key("container");j.object();j.field("recognized",container.recognized);j.field("valid",container.valid);
        j.field("error",container.error);j.field("leaf_count",container.leaves.size());j.end();
        j.key("performance");performance(j,inspection);j.key("keyboard_set_recall");recall(j,keyboard);
        j.key("complement");complement(j,inspection.complement);xmlResources(j,container,bytes);
        j.end();std::cout<<'\n';return inspection.valid?0:1;
    }catch(const std::exception& error){std::cerr<<"Performance inspection failed: "<<error.what()<<'\n';return 1;}
}
