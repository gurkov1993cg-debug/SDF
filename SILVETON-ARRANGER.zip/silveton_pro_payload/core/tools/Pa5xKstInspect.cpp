#include "silveton/arranger/Pa5xKstIndex.h"
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    const bool summaryOnly = argc == 3 && std::string(argv[1]) == "--summary";
    if (argc != 2 && !summaryOnly) {
        std::cerr << "Usage: silveton_pa5x_kst_inspect [--summary] /path/to/Set.KST\n";
        return 2;
    }
    const auto index = silveton::arranger::indexPa5xKst(argv[summaryOnly ? 2 : 1]);
    std::cout << silveton::arranger::pa5xKstSummary(index) << '\n';
    if (summaryOnly) return index.recognized && index.structurallyValid ? 0 : 1;
    for (const auto& ref : index.soundReferences) {
        std::cout << silveton::arranger::kstResourceKindName(ref.resourceKind) << " | " << ref.stylePath << " | " << ref.element << " | " << ref.track
                  << " | " << ref.msb << '/' << ref.lsb << '/' << ref.program
                  << " | " << ref.soundName << '\n';
    }
    for (const auto& d : index.diagnostics)
        std::cout << d.code << " | " << d.relativePath << " | " << d.message << '\n';
    // Success means the check ran, not that an exact Korg player exists.
    return index.recognized && index.structurallyValid ? 0 : 1;
}
