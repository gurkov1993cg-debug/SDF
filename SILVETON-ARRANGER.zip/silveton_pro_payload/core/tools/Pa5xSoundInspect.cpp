// Read-only extraction of one original PCG Sound. No DSP conversion or playback.
#include "silveton/arranger/Pa5xPcgIndex.h"
#include "silveton/arranger/Pa5xSoundGraph.h"
#include "silveton/arranger/Pa5xOc31.h"
#include "silveton/sampler/SourceEffects.h"

#include <algorithm>
#include <cstdint>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

namespace {
using namespace silveton::arranger;

// Small JSON writer: integer bytes are emitted as numbers, never characters.
class Json {
public:
    explicit Json(std::ostream& out) : out_(out) {}
    void object() { before(); out_ << '{'; levels_.push_back({true, true, false}); }
    void array() { before(); out_ << '['; levels_.push_back({false, true, false}); }
    void end() {
        if (levels_.empty() || levels_.back().awaiting)
            throw std::logic_error("Incomplete JSON container");
        const auto level = levels_.back(); levels_.pop_back();
        if (!level.first) newline();
        out_ << (level.object ? '}' : ']');
    }
    void key(const char* name) {
        if (levels_.empty() || !levels_.back().object || levels_.back().awaiting)
            throw std::logic_error("Invalid JSON key");
        auto& level = levels_.back();
        if (!level.first) out_ << ',';
        level.first = false; newline(); quote(name); out_ << ": "; level.awaiting = true;
    }
    void value(const std::string& value) { before(); quote(value); }
    void value(const char* value) { this->value(std::string(value)); }
    void value(bool value) { before(); out_ << (value ? "true" : "false"); }
    void value(double number) {
        if(!std::isfinite(number))throw std::logic_error("Non-finite JSON number");
        before();out_<<std::setprecision(17)<<number;
    }
    template<class T, typename std::enable_if<std::is_integral<T>::value &&
            !std::is_same<T, bool>::value, int>::type = 0>
    void value(T number) {
        before();
        if constexpr (std::is_signed<T>::value) out_ << static_cast<long long>(number);
        else out_ << static_cast<unsigned long long>(number);
    }
    void null() { before(); out_ << "null"; }
    template<class T> void field(const char* name, const T& value) { key(name); this->value(value); }
    template<class Range> void numbers(const char* name, const Range& values) {
        key(name); array(); for (const auto value : values) this->value(value); end();
    }
    void strings(const char* name, const std::vector<std::string>& values) {
        key(name); array(); for (const auto& value : values) this->value(value); end();
    }
private:
    struct Level { bool object, first, awaiting; };
    std::ostream& out_;
    std::vector<Level> levels_;
    void newline() { out_ << '\n' << std::string(levels_.size() * 2, ' '); }
    void before() {
        if (levels_.empty()) return;
        auto& level = levels_.back();
        if (level.object) {
            if (!level.awaiting) throw std::logic_error("Missing JSON object key");
            level.awaiting = false;
        } else {
            if (!level.first) out_ << ',';
            level.first = false; newline();
        }
    }
    void quote(const std::string& text) {
        constexpr char hex[] = "0123456789abcdef";
        out_ << '"';
        for (std::size_t i = 0; i < text.size(); ++i) {
            const auto c = static_cast<unsigned char>(text[i]);
            if (c == '"' || c == '\\') { out_ << '\\' << static_cast<char>(c); continue; }
            if (c >= 32 && c < 127) { out_ << static_cast<char>(c); continue; }
            // Preserve valid UTF-8; encode an isolated non-UTF8 byte explicitly.
            std::size_t count = c >= 0xC2 && c <= 0xDF ? 2 :
                c >= 0xE0 && c <= 0xEF ? 3 : c >= 0xF0 && c <= 0xF4 ? 4 : 0;
            bool utf8 = count != 0 && count <= text.size() - i;
            for (std::size_t n = 1; utf8 && n < count; ++n) {
                const auto next = static_cast<unsigned char>(text[i + n]);
                utf8 = (next & 0xC0U) == 0x80U;
            }
            if (utf8 && count >= 3) {
                const auto next = static_cast<unsigned char>(text[i + 1]);
                utf8 = !(c == 0xE0 && next < 0xA0) && !(c == 0xED && next >= 0xA0) &&
                    !(c == 0xF0 && next < 0x90) && !(c == 0xF4 && next >= 0x90);
            }
            if (utf8) { out_.write(text.data() + i, static_cast<std::streamsize>(count)); i += count - 1; }
            else out_ << "\\u00" << hex[c >> 4U] << hex[c & 15U];
        }
        out_ << '"';
    }
};

template<class Range> std::string hexBytes(const Range& bytes, std::size_t count = std::numeric_limits<std::size_t>::max()) {
    constexpr char hex[] = "0123456789abcdef";
    std::string result; count = std::min(count, bytes.size()); result.reserve(count * 2);
    for (std::size_t i = 0; i < count; ++i) {
        const auto byte = static_cast<unsigned char>(bytes[i]);
        result.push_back(hex[byte >> 4U]); result.push_back(hex[byte & 15U]);
    }
    return result;
}
std::string hexId(std::uint64_t id) {
    constexpr char hex[] = "0123456789abcdef";
    std::string result(16, '0');
    for (std::size_t i = 0; i < 16; ++i) { result[15 - i] = hex[id & 15U]; id >>= 4U; }
    return result;
}
void ams(Json& j, const Pa5xAmsParameterRaw& value) {
    j.object(); j.field("source_code_raw", value.source); j.field("intensity_raw", value.intensity); j.end();
}
template<std::size_t N> void amsArray(Json& j, const char* name, const std::array<Pa5xAmsParameterRaw, N>& values) {
    j.key(name); j.array(); for (const auto& value : values) ams(j, value); j.end();
}
void tracking(Json& j, const Pa5xKeyboardTrackingRaw& value) {
    j.object(); j.field("low_key", value.lowKey); j.field("high_key", value.highKey);
    j.field("low_ramp_raw", value.lowRamp); j.field("high_ramp_raw", value.highRamp); j.end();
}
void envelope(Json& j, const Pa5xEnvelopeParametersRaw& value) {
    j.object();
    j.field("start_level_raw", value.startLevel); j.field("attack_time_raw", value.attackTime);
    j.field("attack_level_raw", value.attackLevel); j.field("decay_time_raw", value.decayTime);
    j.field("break_level_raw", value.breakLevel); j.field("slope_time_raw", value.slopeTime);
    j.field("sustain_level_raw", value.sustainLevel); j.field("release_time_raw", value.releaseTime);
    j.field("has_release_level", value.hasReleaseLevel);
    j.key("release_level_raw"); if (value.hasReleaseLevel) j.value(value.releaseLevel); else j.null();
    j.end();
}
void envelopeModulation(Json& j, const Pa5xEnvelopeModulationRaw& value) {
    j.object(); amsArray(j, "time_ams", value.time); j.key("level_ams"); ams(j, value.level);
    j.numbers("time_directions_packed_raw", value.timeDirections);
    j.field("level_directions_packed_raw", value.levelDirections); j.end();
}
void lfo(Json& j, const Pa5xLfoParametersRaw& value) {
    j.object(); j.field("waveform_flags_raw", value.waveformFlags); j.field("frequency_raw", value.frequency);
    j.field("offset_raw", value.offset); j.field("delay_raw", value.delay); j.field("fade_raw", value.fade);
    j.field("tempo_sync_flags_raw", value.tempoSyncFlags); amsArray(j, "frequency_ams", value.frequencyModulation); j.end();
}
void filter(Json& j, const Pa5xFilterPathParametersRaw& value) {
    j.object(); j.field("frequency_raw", value.frequency);
    j.field("keyboard_tracking_intensity_raw", value.keyboardTrackingIntensity);
    amsArray(j, "modulation_ams", value.modulation);
    j.field("envelope_intensity_raw", value.envelopeIntensity); j.field("velocity_intensity_raw", value.velocityIntensity);
    j.numbers("lfo_intensity_raw", value.lfoIntensity); j.numbers("joystick_lfo_intensity_raw", value.joystickLfoIntensity);
    j.field("envelope_ams_intensity_raw", value.envelopeAmsIntensity); j.numbers("lfo_ams_intensity_raw", value.lfoAmsIntensity); j.end();
}
void dsp(Json& j, const Pa5xOscillatorDspParametersRaw& p) {
    j.object();
    j.field("field_layout_decoded", p.fieldLayoutDecoded); j.field("nominal_ranges_valid", p.nominalRangesValid);
    j.field("legacy_triton_layout_corroborated", p.legacyTritonLayoutCorroborated);
    j.field("newer_pa_layout_corroborated", p.newerPaLayoutCorroborated);
    j.field("time_gain_laws_decoded", p.timeGainLawsDecoded); j.field("ams_source_mapping_decoded", p.amsSourceMappingDecoded);
    j.field("amplitude_level_encoding_decoded", p.amplitudeLevelEncodingDecoded);
    j.field("portamento_encoding_decoded", p.portamentoEncodingDecoded);
    j.key("lfos"); j.array(); for (const auto& value : p.lfos) lfo(j, value); j.end();
    j.key("pitch_modulation_ams"); ams(j, p.pitchModulation);
    j.key("pitch_envelope_modulation_ams"); ams(j, p.pitchEnvelopeModulation);
    j.field("pitch_tracking_slope_raw", p.pitchTrackingSlope); j.field("pitch_envelope_intensity_raw", p.pitchEnvelopeIntensity);
    j.numbers("pitch_lfo_intensity_raw", p.pitchLfoIntensity); j.numbers("pitch_joystick_lfo_intensity_raw", p.pitchJoystickLfoIntensity);
    j.field("portamento_flags_raw", p.portamentoFlags); j.field("portamento_time_raw", p.portamentoTime);
    j.numbers("pitch_bend_range_raw", p.pitchBendRange); j.field("pitch_ribbon_intensity_raw", p.pitchRibbonIntensity);
    j.field("pitch_reserved_raw", p.pitchReserved); amsArray(j, "pitch_lfo_modulation_ams", p.pitchLfoModulation);
    j.field("filter_type_code_raw", p.filterType); j.field("filter_trim_raw", p.filterTrim); j.field("filter_resonance_raw", p.filterResonance);
    j.key("filter_resonance_modulation_ams"); ams(j, p.filterResonanceModulation);
    j.field("filter_envelope_ams_source_code_raw", p.filterEnvelopeAmsSource); j.numbers("filter_lfo_ams_source_codes_raw", p.filterLfoAmsSource);
    j.key("filters"); j.array(); for (const auto& value : p.filters) filter(j, value); j.end();
    j.key("filter_envelope"); envelope(j, p.filterEnvelope);
    j.key("filter_envelope_modulation"); envelopeModulation(j, p.filterEnvelopeModulation);
    j.key("filter_keyboard_tracking"); tracking(j, p.filterKeyboardTracking);
    j.field("amplitude_level_raw", p.amplitudeLevel); j.field("amplitude_velocity_intensity_raw", p.amplitudeVelocityIntensity);
    j.key("amplitude_modulation_ams"); ams(j, p.amplitudeModulation);
    j.numbers("amplitude_lfo_intensity_raw", p.amplitudeLfoIntensity); amsArray(j, "amplitude_lfo_modulation_ams", p.amplitudeLfoModulation);
    j.key("amplitude_envelope"); envelope(j, p.amplitudeEnvelope);
    j.key("amplitude_envelope_modulation"); envelopeModulation(j, p.amplitudeEnvelopeModulation);
    j.key("amplitude_keyboard_tracking"); tracking(j, p.amplitudeKeyboardTracking);
    j.field("amplitude_reserved_raw", p.amplitudeReserved); j.end();
}
void source(Json& j, const Pa5xOscillatorSource& value) {
    j.object();
    // Decimal string and hex preserve all 64 bits in JSON/JavaScript consumers.
    j.field("multisample_uid_decimal", std::to_string(value.multisampleId)); j.field("multisample_uid_hex", hexId(value.multisampleId));
    j.field("multisample_number_raw", value.multisampleNumber); j.field("number_flags_raw", value.numberFlagsRaw);
    j.field("source_code_raw", static_cast<unsigned>(value.source));
    j.field("source_kind", value.source == Pa5xMultisampleSource::Ram ? "RAM" : "ROM");
    j.field("level_raw", value.levelRaw); j.field("level_encoding_decoded", value.levelDecoded);
    j.field("offset_raw", value.offsetRaw); j.field("offset_encoding_decoded", value.offsetDecoded);
    j.field("reverse_encoding_decoded", value.reverseDecoded);
    j.key("reversed"); if (value.reverseDecoded) j.value(value.reversed); else j.null();
    j.field("velocity_use_known", value.velocityUseKnown);
    j.key("velocity_can_select"); if (value.velocityUseKnown) j.value(value.velocityCanSelect); else j.null();
    j.field("extension_byte_count", value.extensionBytes); j.field("extension_hex", hexBytes(value.extensionRaw, value.extensionBytes));
    j.end();
}
void blockOffsets(Json& j, const Pa5xOscillatorReferences& osc, int version) {
    const std::size_t start = osc.decodedBodyOffset;
    const std::size_t lfo = version == 0 ? 35U : version == 1 ? 37U : version <= 3 ? 43U : version <= 6 ? 47U : 49U;
    const std::size_t pitch = lfo + 20U, base = pitch + 4U;
    const std::size_t amp = version == 0 ? 151U : version == 1 ? 153U : version <= 3 ? 159U :
        version == 5 ? 166U : version == 6 ? 168U : 170U;
    j.key("parameter_block_locations"); j.object();
    j.field("offset_basis", "Absolute byte offsets within the decompressed Sound body, not the compressed PCG file.");
    j.field("lfo20_decoded_body_offset", start + lfo);
    j.field("static_pitch4_decoded_body_offset", start + pitch);
    j.field("normalized_dsp90_contiguous", version <= 3);
    j.key("normalized_dsp90_decoded_body_offsets"); j.array();
    for (std::size_t i = 0; i < 90; ++i) {
        const std::size_t insertion = version <= 3 ? 0U : version == 5 ?
            (i < 81U ? 0U : i < 84U ? 1U : 3U) : (i < 10U ? 0U : i < 81U ? 2U : i < 84U ? 3U : 5U);
        j.value(start + base + i + insertion);
    }
    j.end(); j.field("scaled_velocity2_decoded_body_offset", start + amp - 2U);
    j.field("amp_eg22_decoded_body_offset", start + amp);
    j.key("equalizer6_decoded_body_offset"); if (osc.equalizer.present) j.value(start + amp + 22U); else j.null();
    j.end();
}
void oscillator(Json& j, const Pa5xOscillatorReferences& osc, std::size_t ordinal, int version,
        const std::vector<std::uint8_t>& body, std::size_t recordEnd) {
    if (osc.decodedBodyOffset >= recordEnd || recordEnd > body.size())
        throw std::runtime_error("Original oscillator record span is outside the decoded Sound body");
    const std::vector<std::uint8_t> record(body.begin() + static_cast<std::ptrdiff_t>(osc.decodedBodyOffset),
        body.begin() + static_cast<std::ptrdiff_t>(recordEnd));
    const bool legacyTail = version <= 3;
    if (legacyTail && record.size() < 4U)
        throw std::runtime_error("Legacy oscillator record is too short for its opaque four-byte tail");
    j.object(); j.field("oscillator_number", ordinal + 1); j.field("decoded_body_offset", osc.decodedBodyOffset);
    j.field("original_record_length_bytes", record.size()); j.field("original_record_hex", hexBytes(record));
    j.key("opaque_legacy_tail4"); j.object(); j.field("present", legacyTail);
    j.field("meaning_decoded", false);
    j.field("note", "Original four bytes skipped by the legacy structural parser. Their parameter meanings are unknown; no pan, gain, trigger or other setting is assigned.");
    j.key("decoded_body_offset"); if (legacyTail) j.value(recordEnd - 4U); else j.null();
    std::vector<std::uint8_t> tail;
    if (legacyTail) tail.assign(record.end() - 4, record.end());
    j.numbers("bytes_raw", tail); j.field("hex", hexBytes(tail)); j.end();
    blockOffsets(j, osc, version);
    j.key("high_source"); source(j, osc.high); j.key("low_source"); source(j, osc.low);
    j.field("delay_raw", osc.delayRaw); j.field("velocity_switch", osc.velocitySwitch);
    j.field("velocity_low", osc.velocityLow); j.field("velocity_high", osc.velocityHigh);
    j.field("key_low", osc.keyLow); j.field("key_high", osc.keyHigh);
    j.field("trigger_fields_decoded", osc.triggerFieldsDecoded);
    j.field("trigger_mode_raw", osc.triggerModeRaw); j.field("controller_exception_raw", osc.controllerExceptionRaw);
    j.field("octave_raw", osc.octaveRaw); j.field("transpose_raw", osc.transposeRaw); j.field("tune_raw", osc.tuneRaw);
    j.field("static_pitch_decoded", osc.staticPitchDecoded);
    j.key("transpose_semitones"); if (osc.staticPitchDecoded) j.value(osc.transposeSemitones); else j.null();
    j.key("static_pitch_offset_cents"); if (osc.staticPitchDecoded) j.value(osc.staticPitchOffsetCents); else j.null();
    j.field("scaled_velocity_decoded", osc.scaledVelocityDecoded);
    j.field("scaled_velocity_low_raw", osc.scaledVelocityLow); j.field("scaled_velocity_high_raw", osc.scaledVelocityHigh);
    j.key("dsp_parameters_raw"); dsp(j, osc.dsp);
    j.key("equalizer_raw"); j.object(); j.field("present", osc.equalizer.present);
    j.field("enabled_raw", osc.equalizer.enabledRaw); j.field("trim_raw", osc.equalizer.trimRaw);
    j.field("low_gain_times2_raw", osc.equalizer.lowGainTimes2Raw); j.field("frequency_raw", osc.equalizer.frequencyRaw);
    j.field("mid_gain_times2_raw", osc.equalizer.midGainTimes2Raw); j.field("high_gain_times2_raw", osc.equalizer.highGainTimes2Raw); j.end();
    j.field("normalized_dsp90_hex", hexBytes(osc.opaqueDsp)); j.field("amp_eg22_hex", hexBytes(osc.amplitudeEnvelopeRaw));
    j.field("lfo20_hex", hexBytes(osc.lfoRaw)); j.field("additional_dsp_byte_count", osc.additionalDspBytes);
    j.field("additional_dsp_hex", hexBytes(osc.additionalDspRaw, osc.additionalDspBytes));
    j.field("undecoded_tail_hex", hexBytes(osc.undecodedTail)); j.end();
}
void descriptor(Json& j, const Pa5xPcgSound& sound) {
    j.object(); j.field("name", sound.name); j.field("raw_name28_hex", hexBytes(sound.rawName));
    j.field("internal_bank_raw", sound.internalBank); j.field("program_raw", sound.rawProgram);
    j.field("address_known", sound.addressKnown); j.field("address_evidence_code", static_cast<unsigned>(sound.addressEvidence));
    j.key("bank_msb"); if (sound.addressKnown) j.value(sound.msb); else j.null();
    j.key("bank_lsb"); if (sound.addressKnown) j.value(sound.lsb); else j.null();
    j.field("resource_class", sound.resourceClass); j.numbers("resource_version", sound.resourceVersion);
    j.field("kind_code", static_cast<unsigned>(sound.kind)); j.field("raw_checksum", sound.rawChecksum);
    j.field("object_id_present", sound.objectIdPresent);
    j.key("object_id_decimal"); if (sound.objectIdPresent) j.value(std::to_string(sound.rawObjectId)); else j.null();
    j.key("object_id_hex"); if (sound.objectIdPresent) j.value(hexId(sound.rawObjectId)); else j.null();
    j.field("index_ordinal", sound.indexOrdinal); j.field("record_offset", sound.recordOffset); j.field("record_length", sound.recordLength);
    j.field("payload_offset", sound.payloadOffset); j.field("payload_length", sound.payloadLength);
    j.field("payload_chunk_tag_hex", hexBytes(sound.payloadChunkTag)); j.field("oc31_encoded", sound.oc31Encoded);
    j.field("index_parameters_decoded", sound.parametersDecoded); j.end();
}
void graphSummary(Json& j, const Pa5xSoundReferenceGraph& graph) {
    j.object(); j.field("recognized", graph.recognized); j.field("reference_graph_decoded", graph.referenceGraphDecoded);
    j.field("parameters_decoded", graph.parametersDecoded); j.numbers("resource_version", graph.resourceVersion);
    j.field("oscillator_count", graph.oscillators.size()); j.field("decoded_body_bytes", graph.decodedBodyBytes);
    j.field("corpus_derived_reference_layout", graph.corpusDerivedReferenceLayout);
    j.field("body_name", graph.bodyName); j.field("error", graph.error); j.strings("synthesis_blockers", graph.synthesisBlockers); j.end();
}
void effectBlocks(Json& j, const Pa5xSoundReferenceGraph& graph) {
    const auto& effects=graph.effects;
    j.key("original_effect_blocks"); j.object();
    j.field("framing_recognized",effects.framingDecoded);
    j.field("activation_decoded",effects.activationDecoded);j.field("slot_ownership_decoded",effects.slotOwnershipDecoded);
    j.field("routing_decoded",effects.routingDecoded);j.field("error",effects.error);
    j.field("note", "Records use the shared bounded Sound decoder. Known selectors and parameter values are inspected separately from unknown activation, IFX/MFX assignment and routing. No Sound effect is applied by this inspector.");
    j.field("common_controls_decoded_body_offset",effects.commonControlsBodyOffset);
    j.field("common_controls_bytes",effects.commonControlsBytes);
    j.field("common_controls_raw_hex",hexBytes(effects.commonControlsRaw,effects.commonControlsBytes));
    j.key("slots"); j.array();
    if(effects.framingDecoded)for(const auto& record:effects.records) {
        const auto status=silveton::sampler::inspectSoundEffectParameters(record);
        j.object();j.field("record",static_cast<unsigned>(record.recordIndex)+1U);j.field("index",record.recordIndex);
        j.field("decoded_body_offset",record.decodedBodyOffset);j.field("block_length_bytes",record.recordBytes);
        j.field("first_byte_raw",record.leadingRaw);j.field("selector_low_raw",record.selectorLowRaw);
        j.field("selector_decoded",record.selectorDecoded);j.key("selector");
        if(record.selectorDecoded)j.value(record.selector);else j.null();
        j.field("name",status.name);j.field("playback_applied",false);j.field("playback_detail",status.detail);
        j.field("parameter_bytes_decoded_body_offset",record.decodedBodyOffset+1U);
        j.numbers("parameter_bytes_raw",record.parameters);j.field("parameter_bytes64_hex",hexBytes(record.parameters));
        j.key("extra_byte_raw");if(record.trailingControlPresent)j.value(record.trailingControlRaw);else j.null();
        j.field("parameter_layout_known",status.parameterLayoutKnown);j.field("parameter_block_valid",status.parameterBlockValid);
        j.field("parameters_complete",status.parametersComplete);j.field("parameter_detail",status.parameterDetail);
        j.key("decoded_parameters");j.array();
        const auto* descriptor=silveton::sampler::findNumberedFx(status.decoded.index);
        if(descriptor&&status.parameterBlockValid)for(std::size_t i=0;i<descriptor->parameterCount;++i) {
            const auto& parameter=descriptor->parameters[i];
            j.object();j.field("id",parameter.rowId);j.field("label",parameter.label);
            j.field("known",status.decoded.known(i));j.key("value");
            if(status.decoded.known(i))j.value(status.decoded.values[i]);else j.null();
            j.end();
        }
        j.end();j.end();
    }
    j.end(); j.end();
}
int number(const char* text, int maximum) {
    const std::string input(text); std::size_t consumed = 0;
    const int value = std::stoi(input, &consumed, 10);
    if (consumed != input.size() || value < 0 || value > maximum) throw std::invalid_argument("Bank/program outside its raw range");
    return value;
}
std::vector<std::uint8_t> readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) throw std::runtime_error("Cannot open PCG file");
    const auto length = file.tellg();
    if (length < 0 || length > static_cast<std::streamoff>(64U * 1024U * 1024U))
        throw std::runtime_error("PCG file exceeds the 64 MiB inspector limit");
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length)); file.seekg(0);
    if (!bytes.empty()) file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!file) throw std::runtime_error("PCG file read failed");
    return bytes;
}
void notes(Json& j) {
    j.key("interpretation"); j.object();
    j.field("operation", "Read-only extraction; no Sound activation or audio equivalence claim.");
    j.field("parameter_values", "Saved raw values: not converted to Hz, milliseconds, seconds, dB, or linear gain. Static pitch fields are explicitly named separately.");
    j.field("codes", "Filter type, LFO waveform/flags, trigger, packed directions and AMS source IDs are numeric codes; no unverified enum names are assigned.");
    j.field("new_revision_extensions", "For revisions 5-8, adjacent unknown bytes may extend source level/direction/offset, amplitude level and portamento encodings; inspect their decoded flags.");
    j.field("effects", "Original Sound FX record framing and supported selector/parameter values are decoded separately. Activation, exact IFX/MFX ownership and Sound routing remain unknown; original bytes are retained.");
    j.field("raw_defaults", "A field whose decoded/present flag is false may contain the structure's default value, not an extracted parameter. Original blocks remain available as hex.");
    j.field("strings", "Valid UTF-8 is preserved; isolated non-UTF8 bytes are escaped as U+00xx. Original Sound name bytes are also supplied as hex.");
    j.end();
}
} // namespace

int main(int argc, char** argv) {
    const bool list = argc == 3 && std::string(argv[1]) == "--list";
    if (!list && argc != 4) {
        std::cerr << "Usage: silveton_pa5x_sound_inspect --list FILE.PCG\n"
                     "       silveton_pa5x_sound_inspect FILE.PCG RAW_BANK RAW_PROGRAM\n";
        return 2;
    }
    try {
        const std::string path(argv[list ? 2 : 1]);
        const auto bytes = readFile(path); const auto index = inspectPa5xPcgBytes(bytes, path);
        Json j(std::cout); j.object(); j.field("schema", "silveton.pa5x.sound-inspection.v1");
        j.field("source_file", path); j.field("file_size_bytes", bytes.size());
        j.field("index_recognized", index.recognized); j.field("index_valid", index.valid);
        j.field("index_error", index.error); j.strings("index_warnings", index.warnings); notes(j);
        if (!index.valid) { j.end(); std::cout << '\n'; return 1; }
        if (list) {
            j.key("normal_sound_candidates"); j.array();
            for (const auto& sound : index.sounds) {
                if (sound.kind == Pa5xPcgSoundKind::DrumKit) continue;
                const auto graph = inspectPa5xSoundGraph(bytes, sound);
                j.object(); j.key("sound"); descriptor(j, sound); j.key("graph"); graphSummary(j, graph); j.end();
            }
            j.end(); j.end(); std::cout << '\n'; return 0;
        }
        const int bank = number(argv[2], 255), program = number(argv[3], 127);
        const Pa5xPcgSound* selected = nullptr;
        for (const auto& sound : index.sounds) if (sound.internalBank == bank && sound.rawProgram == program) {
            if (selected) throw std::runtime_error("Raw bank/program matches multiple PCG objects; selection is ambiguous");
            selected = &sound;
        }
        if (!selected) throw std::runtime_error("Raw bank/program is absent from the PCG directory");
        const auto graph = inspectPa5xSoundGraph(bytes, *selected);
        Pa5xOc31Result decoded;
        if (graph.referenceGraphDecoded) {
            if (selected->payloadOffset > bytes.size() || selected->payloadLength > bytes.size() - selected->payloadOffset)
                throw std::runtime_error("Selected Sound payload is outside its PCG file");
            decoded = decodePa5xOc31(bytes.data() + selected->payloadOffset, selected->payloadLength, 65536U);
            if (!decoded) throw std::runtime_error("Selected Sound body extraction failed: " + decoded.error);
            if (decoded.data.size() != graph.decodedBodyBytes)
                throw std::runtime_error("Selected Sound body size differs from its inspected graph");
            for (std::size_t i = 0; i < graph.oscillators.size(); ++i) {
                const auto start = graph.oscillators[i].decodedBodyOffset;
                const auto end = i + 1 < graph.oscillators.size() ? graph.oscillators[i + 1].decodedBodyOffset : decoded.data.size();
                if (start >= end || end > decoded.data.size() || (graph.resourceVersion[0] <= 3 && end - start < 4U))
                    throw std::runtime_error("Selected Sound has an invalid original oscillator record span");
            }
        }
        j.key("sound"); descriptor(j, *selected); j.key("graph"); graphSummary(j, graph);
        j.field("multisample_map_raw", graph.multisampleMapRaw); j.field("voice_flags_raw", graph.voiceFlagsRaw);
        j.field("oscillator_flags_raw", graph.oscillatorFlagsRaw); j.field("common_raw_hex", hexBytes(graph.commonRaw));
        effectBlocks(j, graph);
        j.key("oscillators"); j.array();
        for (std::size_t i = 0; i < graph.oscillators.size(); ++i) {
            const auto end = i + 1 < graph.oscillators.size() ? graph.oscillators[i + 1].decodedBodyOffset : decoded.data.size();
            oscillator(j, graph.oscillators[i], i, graph.resourceVersion[0], decoded.data, end);
        }
        j.end(); j.end(); std::cout << '\n'; return graph.referenceGraphDecoded ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "Sound inspection failed: " << error.what() << '\n'; return 1;
    }
}
