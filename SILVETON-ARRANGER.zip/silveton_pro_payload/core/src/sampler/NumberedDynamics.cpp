#include "silveton/sampler/NumberedDynamics.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler {
namespace {

constexpr double kPi = 3.1415926535897932384626433832795;
constexpr double kSqrtTwo = 1.4142135623730950488016887242097;
// These recovery bounds are far outside normal audio, not musical clipping or
// an emulation of any numbered effect's saturation behavior.
constexpr double kSignalBound = 1000000.0;
constexpr double kStateBound = 1000000000000.0;

double finiteRange(double value, double low, double high, double fallback) noexcept {
    return std::isfinite(value) ? std::clamp(value, low, high) : fallback;
}

double audio(double value) noexcept {
    if (!std::isfinite(value)) return 0.0;
    return std::clamp(value, -kSignalBound, kSignalBound);
}

double flushSmall(double value) noexcept {
    return std::abs(value) < 1.0e-24 ? 0.0 : value;
}

double frequency(double sampleRate, double hz) noexcept {
    return finiteRange(hz, 5.0, sampleRate * 0.45, 1000.0);
}

double amplitude(double db) noexcept {
    return std::pow(10.0, db * 0.05);
}

double coefficient(double milliseconds, double sampleRate) noexcept {
    return std::exp(-1.0 / (milliseconds * 0.001 * sampleRate));
}

double logarithmicTime(float value, double firstMs, double lastMs) noexcept {
    const double position = (finiteRange(value, 1.0, 100.0, 20.0) - 1.0) / 99.0;
    return firstMs * std::pow(lastMs / firstMs, position);
}

bool sameConfig(const NumberedDynamicsConfig& a, const NumberedDynamicsConfig& b) noexcept {
    return a.index == b.index && a.detector == b.detector &&
           a.sensitivity == b.sensitivity && a.attack == b.attack &&
           a.release == b.release && a.ratio == b.ratio &&
           a.infiniteRatio == b.infiniteRatio && a.thresholdDb == b.thresholdDb &&
           a.eqTrim == b.eqTrim && a.lowShelf == b.lowShelf &&
           a.highShelf == b.highShelf && a.lowShelfGainDb == b.lowShelfGainDb &&
           a.highShelfGainDb == b.highShelfGainDb &&
           a.sideEqEnabled == b.sideEqEnabled && a.triggerMonitor == b.triggerMonitor &&
           a.sideEqHz == b.sideEqHz && a.sideEqQ == b.sideEqQ &&
           a.sideEqGainDb == b.sideEqGainDb && a.bandOffsetDb == b.bandOffsetDb &&
           a.ceilingDb == b.ceilingDb && a.masteringReleaseMs == b.masteringReleaseMs &&
           a.gateDmod == b.gateDmod && a.gateNegativePolarity == b.gateNegativePolarity &&
           a.gateThreshold == b.gateThreshold && a.gateDelayMs == b.gateDelayMs;
}

NumberedDynamicsConfig sanitized(NumberedDynamicsConfig value) noexcept {
    using Detector = NumberedDynamicsDetector;
    if (static_cast<unsigned>(value.detector) > static_cast<unsigned>(Detector::Independent))
        value.detector = Detector::Mix;
    if (value.index == 1 && value.detector != Detector::Mix && value.detector != Detector::Independent)
        value.detector = Detector::Mix;
    if (value.index == 5 && value.detector == Detector::Independent)
        value.detector = Detector::Mix;
    if (value.lowShelf != NumberedDynamicsLowShelf::Low && value.lowShelf != NumberedDynamicsLowShelf::MidLow)
        value.lowShelf = NumberedDynamicsLowShelf::Low;
    if (value.highShelf != NumberedDynamicsHighShelf::High && value.highShelf != NumberedDynamicsHighShelf::MidHigh)
        value.highShelf = NumberedDynamicsHighShelf::High;
    const auto bounded = [](float x, double lo, double hi, double fallback) noexcept {
        return static_cast<float>(finiteRange(x, lo, hi, fallback));
    };
    value.sensitivity = bounded(value.sensitivity, 1.0, 100.0, 50.0);
    value.attack = bounded(value.attack, 1.0, 100.0, 20.0);
    value.release = bounded(value.release, 1.0, 100.0, 50.0);
    value.ratio = bounded(value.ratio, 1.0, 50.0, 4.0);
    value.thresholdDb = bounded(value.thresholdDb, value.index == 4 ? -30.0 : -40.0, 0.0, -12.0);
    value.eqTrim = bounded(value.eqTrim, 0.0, 1.0, 1.0);
    value.lowShelfGainDb = bounded(value.lowShelfGainDb, -15.0, 15.0, 0.0);
    value.highShelfGainDb = bounded(value.highShelfGainDb, -15.0, 15.0, 0.0);
    value.sideEqHz = bounded(value.sideEqHz, 20.0, 12000.0, 1000.0);
    value.sideEqQ = bounded(value.sideEqQ, 0.5, 10.0, 1.0);
    value.sideEqGainDb = bounded(value.sideEqGainDb, -18.0, 18.0, 0.0);
    for (auto& offset : value.bandOffsetDb) offset = bounded(offset, -40.0, 0.0, 0.0);
    value.ceilingDb = bounded(value.ceilingDb, -30.0, 0.0, -0.3);
    value.masteringReleaseMs = bounded(value.masteringReleaseMs, 0.5, 1000.0, 100.0);
    value.gateThreshold = bounded(value.gateThreshold, 0.0, 100.0, 10.0);
    value.gateDelayMs = bounded(value.gateDelayMs, 0.0, 100.0, 0.0);
    return value;
}

} // namespace

bool NumberedDynamics::supports(std::uint16_t index) noexcept {
    return index == 1 || index == 2 || index == 3 || index == 4 ||
           index == 5 || index == 154 || index == 171;
}

double NumberedDynamics::attackMilliseconds(std::uint16_t index, float value) noexcept {
    if (index == 1 || index == 171) return logarithmicTime(value, 0.2, 40.0);
    if (index == 5) return logarithmicTime(value, 0.1, 200.0);
    return logarithmicTime(value, 0.1, 100.0);
}

double NumberedDynamics::releaseMilliseconds(std::uint16_t index, float value) noexcept {
    if (index == 1 || index == 171) return 120.0;
    if (index == 5) return logarithmicTime(value, 5.0, 3000.0);
    return logarithmicTime(value, 10.0, 2000.0);
}

double NumberedDynamics::gateThresholdAmplitude(float value) noexcept {
    const double setting = finiteRange(value, 0.0, 100.0, 10.0);
    if (setting <= 0.0) return 0.0;
    // Manual values are 0..100, but no published dB calibration is asserted.
    return amplitude(-80.0 + 80.0 * (std::max(1.0, setting) - 1.0) / 99.0);
}

void NumberedDynamics::Biquad::identity() noexcept {
    b0 = 1.0;
    b1 = b2 = a1 = a2 = 0.0;
    clear();
}

void NumberedDynamics::Biquad::lowPass(double sampleRate, double hz) noexcept {
    const double omega = 2.0 * kPi * frequency(sampleRate, hz) / sampleRate;
    const double cosine = std::cos(omega);
    const double alpha = std::sin(omega) / kSqrtTwo;
    const double denominator = 1.0 + alpha;
    b0 = (1.0 - cosine) * 0.5 / denominator;
    b1 = (1.0 - cosine) / denominator;
    b2 = b0;
    a1 = -2.0 * cosine / denominator;
    a2 = (1.0 - alpha) / denominator;
}

void NumberedDynamics::Biquad::highPass(double sampleRate, double hz) noexcept {
    const double omega = 2.0 * kPi * frequency(sampleRate, hz) / sampleRate;
    const double cosine = std::cos(omega);
    const double alpha = std::sin(omega) / kSqrtTwo;
    const double denominator = 1.0 + alpha;
    b0 = (1.0 + cosine) * 0.5 / denominator;
    b1 = -(1.0 + cosine) / denominator;
    b2 = b0;
    a1 = -2.0 * cosine / denominator;
    a2 = (1.0 - alpha) / denominator;
}

void NumberedDynamics::Biquad::allPass(double sampleRate, double hz) noexcept {
    lowPass(sampleRate, hz);
    // LP4 + HP4 is this second-order all-pass. Applying the same all-pass
    // to the unsplit low branch aligns all three bands at the second split.
    b0 = a2;
    b1 = a1;
    b2 = 1.0;
}

void NumberedDynamics::Biquad::shelf(double sampleRate, double hz, double gainDb, bool high) noexcept {
    if (gainDb == 0.0) {
        identity();
        return;
    }
    const double a = std::pow(10.0, gainDb / 40.0);
    const double omega = 2.0 * kPi * frequency(sampleRate, hz) / sampleRate;
    const double cosine = std::cos(omega);
    const double beta = kSqrtTwo * std::sqrt(a) * std::sin(omega);
    const double plus = a + 1.0;
    const double minus = a - 1.0;
    double denominator;
    if (high) {
        denominator = plus - minus * cosine + beta;
        b0 = a * (plus + minus * cosine + beta) / denominator;
        b1 = -2.0 * a * (minus + plus * cosine) / denominator;
        b2 = a * (plus + minus * cosine - beta) / denominator;
        a1 = 2.0 * (minus - plus * cosine) / denominator;
        a2 = (plus - minus * cosine - beta) / denominator;
    } else {
        denominator = plus + minus * cosine + beta;
        b0 = a * (plus - minus * cosine + beta) / denominator;
        b1 = 2.0 * a * (minus - plus * cosine) / denominator;
        b2 = a * (plus - minus * cosine - beta) / denominator;
        a1 = -2.0 * (minus + plus * cosine) / denominator;
        a2 = (plus + minus * cosine - beta) / denominator;
    }
}

void NumberedDynamics::Biquad::peak(double sampleRate, double hz, double q, double gainDb) noexcept {
    if (gainDb == 0.0) {
        identity();
        return;
    }
    const double a = std::pow(10.0, gainDb / 40.0);
    const double omega = 2.0 * kPi * frequency(sampleRate, hz) / sampleRate;
    const double cosine = std::cos(omega);
    const double alpha = std::sin(omega) / (2.0 * q);
    const double denominator = 1.0 + alpha / a;
    b0 = (1.0 + alpha * a) / denominator;
    b1 = -2.0 * cosine / denominator;
    b2 = (1.0 - alpha * a) / denominator;
    a1 = b1;
    a2 = (1.0 - alpha / a) / denominator;
}

void NumberedDynamics::Biquad::clear() noexcept {
    z1 = z2 = 0.0;
}

double NumberedDynamics::Biquad::tick(double value) noexcept {
    const double result = b0 * value + z1;
    const double next1 = b1 * value - a1 * result + z2;
    const double next2 = b2 * value - a2 * result;
    if (!std::isfinite(result) || !std::isfinite(next1) || !std::isfinite(next2) ||
        std::abs(result) > kStateBound || std::abs(next1) > kStateBound || std::abs(next2) > kStateBound) {
        clear();
        return 0.0;
    }
    z1 = flushSmall(next1);
    z2 = flushSmall(next2);
    return flushSmall(result);
}

void NumberedDynamics::Crossover::configure(double sampleRate) noexcept {
    // The manual exposes no crossover controls or cutoff values. These are
    // explicit SILVETON design constants, not inferred Korg parameter fields.
    for (auto& filter : low1) filter.lowPass(sampleRate, 200.0);
    for (auto& filter : high1) filter.highPass(sampleRate, 200.0);
    for (auto& filter : mid2) filter.lowPass(sampleRate, 2000.0);
    for (auto& filter : high2) filter.highPass(sampleRate, 2000.0);
    lowPhase2.allPass(sampleRate, 2000.0);
}

void NumberedDynamics::Crossover::clear() noexcept {
    for (auto& filter : low1) filter.clear();
    for (auto& filter : high1) filter.clear();
    for (auto& filter : mid2) filter.clear();
    for (auto& filter : high2) filter.clear();
    lowPhase2.clear();
}

void NumberedDynamics::Crossover::split(double input, std::array<double, 3>& bands) noexcept {
    const double low = low1[1].tick(low1[0].tick(input));
    const double upper = high1[1].tick(high1[0].tick(input));
    bands[0] = lowPhase2.tick(low);
    bands[1] = mid2[1].tick(mid2[0].tick(upper));
    bands[2] = high2[1].tick(high2[0].tick(upper));
}

void NumberedDynamics::prepare(double sampleRate) {
    const double rate = finiteRange(sampleRate, 8000.0, 384000.0, 48000.0);
    const std::size_t capacity = static_cast<std::size_t>(std::ceil(rate * 0.1)) + 2;
    // Complete both allocations before replacing a previously prepared lane.
    std::vector<float> left(capacity, 0.0F), right(capacity, 0.0F);
    delayLeft_.swap(left);
    delayRight_.swap(right);
    sampleRate_ = rate;
    prepared_ = true;
    configured_ = false;
    for (auto& crossover : crossovers_) crossover.configure(sampleRate_);
    configure(config_);
    reset();
}

void NumberedDynamics::configure(const Config& config) noexcept {
    const Config next = sanitized(config);
    if (configured_ && sameConfig(config_, next)) return;
    const bool algorithmChanged = config_.index != next.index;
    const bool detectorChanged = config_.detector != next.detector ||
        config_.sideEqEnabled != next.sideEqEnabled;
    config_ = next;
    configured_ = true;
    if (algorithmChanged) reset();
    if (detectorChanged) {
        for (auto& filter : sideEq_) filter.clear();
        gateDetector_ = 0.0;
    }

    const bool compressor = config_.index == 1 || config_.index == 171;
    if (compressor) {
        const double thresholdDb = -36.0 * (static_cast<double>(config_.sensitivity) - 1.0) / 99.0;
        compressionExponent_ = 0.75; // Own fixed 4:1 sensitivity compressor.
        threshold_ = amplitude(thresholdDb);
        automaticMakeup_ = amplitude(-thresholdDb * compressionExponent_);
    } else {
        compressionExponent_ = config_.infiniteRatio ? 1.0 : 1.0 - 1.0 / config_.ratio;
        threshold_ = amplitude(config_.thresholdDb);
        automaticMakeup_ = 1.0;
    }
    attackCoefficient_ = coefficient(attackMilliseconds(config_.index, config_.attack), sampleRate_);
    releaseCoefficient_ = coefficient(
        config_.index == 4 ? config_.masteringReleaseMs : releaseMilliseconds(config_.index, config_.release),
        sampleRate_);
    for (std::size_t band = 0; band < bandOffset_.size(); ++band)
        bandOffset_[band] = amplitude(config_.bandOffsetDb[band]);

    const double lowHz = config_.lowShelf == LowShelf::MidLow ? 400.0 : 100.0;
    const double highHz = config_.highShelf == HighShelf::MidHigh ? 3000.0 : 8000.0;
    for (std::size_t channel = 0; channel < 2; ++channel) {
        lowShelf_[channel].shelf(sampleRate_, lowHz, config_.lowShelfGainDb, false);
        highShelf_[channel].shelf(sampleRate_, highHz, config_.highShelfGainDb, true);
        if (config_.sideEqEnabled)
            sideEq_[channel].peak(sampleRate_, config_.sideEqHz, config_.sideEqQ, config_.sideEqGainDb);
        else
            sideEq_[channel].identity();
    }
    ceiling_ = amplitude(config_.ceilingDb);
    masterDrive_ = amplitude(-config_.thresholdDb);
    gateThreshold_ = gateThresholdAmplitude(config_.gateThreshold);
    gateDetectorFall_ = coefficient(20.0, sampleRate_);
    delaySamples_ = static_cast<double>(config_.gateDelayMs) * 0.001 * sampleRate_;
}

void NumberedDynamics::reset() noexcept {
    for (auto& filter : lowShelf_) filter.clear();
    for (auto& filter : highShelf_) filter.clear();
    for (auto& filter : sideEq_) filter.clear();
    for (auto& crossover : crossovers_) crossover.clear();
    gain_.fill(1.0);
    masterGain_ = 1.0;
    gateDetector_ = gateGain_ = 0.0;
    // Invalidating history is O(1); old samples are never read until replaced.
    // In particular, a reset at an audio boundary never clears a large vector.
    delayWrite_ = delayValid_ = 0;
}

void NumberedDynamics::trigger(double inL, double inR, const Modulation& modulation,
                               double& left, double& right) noexcept {
    const bool sideChainFunction = config_.index == 2 || config_.index == 5;
    left = sideChainFunction && modulation.externalSidechain ? audio(modulation.sidechainL) : inL;
    right = sideChainFunction && modulation.externalSidechain ? audio(modulation.sidechainR) : inR;
    switch (config_.detector) {
    case Detector::Mix: left = right = (left + right) * 0.5; break;
    case Detector::Left: right = left; break;
    case Detector::Right: left = right; break;
    case Detector::Independent: break;
    }
    if (sideChainFunction && config_.sideEqEnabled) {
        left = sideEq_[0].tick(left);
        right = sideEq_[1].tick(right);
    }
}

double NumberedDynamics::compress(double signal, double detector, std::size_t cell) noexcept {
    const double level = std::abs(detector);
    double wanted = 1.0;
    if (level > threshold_ && compressionExponent_ > 0.0) {
        const double relative = threshold_ / level;
        if (compressionExponent_ >= 1.0)
            wanted = relative;
        else if (compressionExponent_ == 0.75)
            wanted = std::sqrt(relative) * std::sqrt(std::sqrt(relative));
        else
            wanted = std::pow(relative, compressionExponent_);
    }
    const double time = wanted < gain_[cell] ? attackCoefficient_ : releaseCoefficient_;
    gain_[cell] = std::clamp(wanted + time * (gain_[cell] - wanted), 0.0, 1.0);
    return signal * gain_[cell] * automaticMakeup_;
}

void NumberedDynamics::delayed(double inL, double inR, double& outL, double& outR) noexcept {
    const std::size_t capacity = delayLeft_.size();
    if (capacity < 2 || delayRight_.size() != capacity) {
        outL = inL;
        outR = inR;
        return;
    }
    delayLeft_[delayWrite_] = static_cast<float>(inL);
    delayRight_[delayWrite_] = static_cast<float>(inR);
    delayValid_ = std::min(delayValid_ + 1, capacity);
    const double delay = std::clamp(delaySamples_, 0.0, static_cast<double>(capacity - 2));
    const std::size_t whole = static_cast<std::size_t>(delay);
    const double fraction = delay - static_cast<double>(whole);
    const std::size_t now = delayWrite_ >= whole ? delayWrite_ - whole : capacity + delayWrite_ - whole;
    const std::size_t previous = now == 0 ? capacity - 1 : now - 1;
    const auto read = [&](const std::vector<float>& buffer) noexcept {
        const double first = whole < delayValid_ ? buffer[now] : 0.0;
        const double second = whole + 1 < delayValid_ ? buffer[previous] : 0.0;
        return first + fraction * (second - first);
    };
    outL = read(delayLeft_);
    outR = read(delayRight_);
    if (++delayWrite_ == capacity) delayWrite_ = 0;
}

void NumberedDynamics::process(float inL, float inR, float& outL, float& outR,
                               const Modulation& modulation) noexcept {
    const double left = audio(inL);
    const double right = audio(inR);
    double resultL = left;
    double resultR = right;
    if (!prepared_ || !supports(config_.index)) {
        outL = static_cast<float>(left);
        outR = static_cast<float>(right);
        return;
    }

    switch (config_.index) {
    case 1:  // Stereo Compressor: pre-EQ wet path, detector before that EQ.
    case 171: { // Dynamic Compressor: only the documented sensitivity/attack.
        double detectorL, detectorR;
        trigger(left, right, modulation, detectorL, detectorR);
        double wetL = left, wetR = right;
        if (config_.index == 1) {
            wetL = highShelf_[0].tick(lowShelf_[0].tick(left * config_.eqTrim));
            wetR = highShelf_[1].tick(lowShelf_[1].tick(right * config_.eqTrim));
        }
        resultL = compress(wetL, detectorL, 0);
        resultR = config_.detector == Detector::Independent
            ? compress(wetR, detectorR, 1) : wetR * gain_[0] * automaticMakeup_;
        break;
    }
    case 2: {
        double detectorL, detectorR;
        trigger(left, right, modulation, detectorL, detectorR);
        resultL = compress(left, detectorL, 0);
        resultR = config_.detector == Detector::Independent
            ? compress(right, detectorR, 1) : right * gain_[0];
        if (config_.triggerMonitor) {
            resultL = detectorL;
            resultR = detectorR;
        }
        break;
    }
    case 3: { // Manual diagram explicitly specifies Mono In / Mono Out wet.
        std::array<double, 3> bands{};
        crossovers_[0].split((left + right) * 0.5, bands);
        resultL = 0.0;
        for (std::size_t band = 0; band < bands.size(); ++band)
            resultL += compress(bands[band], bands[band] * bandOffset_[band], band);
        resultR = resultL;
        break;
    }
    case 154: { // Three independent detectors per channel, as in the diagram.
        std::array<double, 3> leftBands{}, rightBands{};
        crossovers_[0].split(left, leftBands);
        crossovers_[1].split(right, rightBands);
        resultL = resultR = 0.0;
        for (std::size_t band = 0; band < leftBands.size(); ++band) {
            resultL += compress(leftBands[band], leftBands[band] * bandOffset_[band], band);
            resultR += compress(rightBands[band], rightBands[band] * bandOffset_[band], band + 3);
        }
        break;
    }
    case 4: {
        // A linked peak gain prevents either channel crossing Out Ceiling.
        // Threshold supplies the intrinsic mastering drive; this is separate
        // from the caller's common wet/return gain and has no double makeup.
        const double drivenL = left * masterDrive_;
        const double drivenR = right * masterDrive_;
        const double peak = std::max(std::abs(drivenL), std::abs(drivenR));
        const double wanted = peak > 1.0 ? 1.0 / peak : 1.0;
        if (wanted < masterGain_) masterGain_ = wanted;
        else masterGain_ = wanted + releaseCoefficient_ * (masterGain_ - wanted);
        masterGain_ = std::clamp(masterGain_, 0.0, 1.0);
        resultL = std::clamp(drivenL * masterGain_ * ceiling_, -ceiling_, ceiling_);
        resultR = std::clamp(drivenR * masterGain_ * ceiling_, -ceiling_, ceiling_);
        break;
    }
    case 5: {
        double detectorL, detectorR;
        trigger(left, right, modulation, detectorL, detectorR);
        // Trigger is undelayed. Delay Time affects only the main audio path.
        gateDetector_ = flushSmall(std::max(std::abs(detectorL), gateDetector_ * gateDetectorFall_));
        bool open = config_.gateDmod
            ? finiteRange(modulation.gateControl, 0.0, 1.0, 0.0) >= 0.5
            : gateDetector_ > gateThreshold_;
        if (config_.gateNegativePolarity) open = !open;
        const double wanted = open ? 1.0 : 0.0;
        const double time = wanted > gateGain_ ? attackCoefficient_ : releaseCoefficient_;
        gateGain_ = flushSmall(wanted + time * (gateGain_ - wanted));
        delayed(left, right, resultL, resultR);
        resultL *= gateGain_;
        resultR *= gateGain_;
        if (config_.triggerMonitor) {
            resultL = detectorL;
            resultR = detectorR;
        }
        break;
    }
    default: break;
    }
    outL = static_cast<float>(audio(resultL));
    outR = static_cast<float>(audio(resultR));
}

} // namespace silveton::sampler
