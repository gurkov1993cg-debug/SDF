#include "silveton/sampler/NumberedModFx.h"
#include "silveton/sampler/NumberedFxKernel.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <initializer_list>
#include <limits>
#include <utility>

namespace silveton::sampler {
namespace {
using namespace numbered_fx;

bool inFamily(std::uint16_t index) noexcept {
    return (index>=26&&index<=54&&index!=40)||(index>=161&&index<=164)||
        (index>=173&&index<=178)||index==189||index==207;
}
bool controlled(std::uint16_t index) noexcept { return index==34||index==37||index==42; }

std::uint64_t connectedSourceRows(std::uint16_t index) noexcept {
    if(!controlled(index))return 0;
    std::uint64_t mask=0;
    const auto add=[&](const char* id){
        const auto* row=findNumberedFxParam(index,id);
        if(row&&row->domainComplete&&row->role==NumberedFxParamRole::ModulationSource)
            mask|=std::uint64_t{1}<<row->ordinal;
    };
    add("c_2");
    if(index==42)add("a_1");
    return mask;
}

const char* syncRow(std::uint16_t index) noexcept {
    switch(index){
    case 26:case 27:case 47:return "c_1";
    case 32:case 33:case 48:return "e_1";
    case 35:case 36:case 41:case 43:case 44:case 46:case 52:return "d_1";
    case 38:return "f_1";
    default:return nullptr;
    }
}

const char* stepNoteRow(std::uint16_t index) noexcept {
    return index==33?"f_1":index==36?"e_1":nullptr;
}

// Older explicitly authored presets had no value for these note rows while
// MIDI Sync was locked Off. Keep exactly that dormant absence; do not insert a
// default into a saved original source or into the persisted manual state.
std::uint64_t dormantLegacyNotes(const NumberedFxState& state) noexcept {
    if(state.origin!=NumberedFxOrigin::Initial&&state.origin!=NumberedFxOrigin::Manual)return 0;
    const auto* sync=syncRow(state.index);
    const auto* sw=sync?findNumberedFxParam(state.index,sync):nullptr;
    if(!sw||!state.known(sw->ordinal)||state.values[sw->ordinal]!=0)return 0;
    std::uint64_t mask=0;
    const auto allow=[&](const char* id){
        const auto* row=findNumberedFxParam(state.index,id);
        if(row&&!state.known(row->ordinal))mask|=std::uint64_t{1}<<row->ordinal;
    };
    char note[]{sync[0],'_','3','\0'};allow(note);
    if(const auto* step=stepNoteRow(state.index))allow(step);
    return mask;
}

// Physical note fractions are separate from the original packed 0..9 codes.
// A whole note spans four quarter-note beats; Times multiplies that duration.
// The MIDI sentinel remains unavailable without an actual bound owner clock.
double syncedRate(const NumberedFxState& state,const char* step=nullptr) noexcept {
    const auto* sync=syncRow(state.index);
    if(!sync)return std::numeric_limits<double>::quiet_NaN();
    char bpm[]{sync[0],'_','2','\0'},note[]{sync[0],'_','3','\0'},times[]{sync[0],'_','4','\0'};
    if(step){note[0]=step[0];note[2]='1';times[0]=step[0];times[2]='2';}
    const double tempo=value(state,bpm),fraction=value(state,note),count=value(state,times);
    if(tempo<40||tempo>300||fraction<=0||count<1||count>32)
        return std::numeric_limits<double>::quiet_NaN();
    return tempo/(240.0*fraction*count);
}

const char* limitation(std::uint16_t index) noexcept {
    switch(index){
    case 34:case 37:return "Собствен Envelope EG / Direct D-mod с реален Gate, joystick, aftertouch или поддържан MIDI CC от назначената партия. EG се задейства при реалния праг 63→64; Gate2 повтаря при всяко note-on. Източник под прага изключва wet пътя. Входът е на MIDI блокове, не sample-accurate. Скоростите и фазовите криви са SILVETON. Wet/Dry DMS е Off; няма оригинален SET decode.";
    case 42:return "Собствен Scratch: реалният controller задава позицията в моно запис до 2730 ms. Input или поддържан DMS управлява записа; Response задава собствена скорост/край. MFX изисква избрана Mod. партия. Статичен controller не възпроизвежда автоматичен loop. Записът не се пази в preset; Wet/Dry DMS е Off.";
    case 38:case 39:return "Собствен LFO алгоритъм. AutoFade trigger и DMS са изключени; активен е статичният D-mod Off клон. Параметрите за неактивния fade са заключени.";
    case 41:return "Собствен движещ се източник в Loop режим. Base Note и Times задават скоростта при ръчно BPM; външен MIDI Clock, One-shot/reset DMS не са свързани.";
    case 48:return "Собствен ring modulator с Fixed oscillator. Note/Key Follow и DMS изискват реален нотен контекст и са заключени.";
    case 51:case 163:return "Собствен двуглав pitch shifter. BPM използва ръчно темпо и фиксирания видим endpoint 1/32 нота; пълното Base Note меню остава неизвестно. Над 5290 ms промяната се отказва. DMS е Off.";
    case 207:return "Собствен двулентов rotary модел. Подробният d Wet/Dry използва Pre/Post-Xover dry; повтореният t Wet/Dry е заключен на Wet, без двойно смесване. DMS/FastOverride са Off; модели и скали са SILVETON.";
    case 53:return "Собствен фазов scanner с шест собствени V/C начални комбинации. Няма твърдение за оригиналните Korg preset коефициенти. DMS е Off.";
    case 161:return "Собствени шест отделни модулирани taps с документираните panning patterns. DMS е Off; Dm tap statuses използват действителната нулева модулация.";
    default:return syncRow(index)?
        "Собствен SILVETON алгоритъм. Base Note, Times и ръчно BPM управляват LFO; външен MIDI Clock и DMS не са свързани. Разчитането на параметри не установява само по себе си оригиналното FX свързване или идентичен звук.":
        "Собствен SILVETON алгоритъм и реални основни контроли. DMS е Off; неподдържаните sync/reset контроли са заключени. Няма оригинален SET decode или обещание за идентичен Korg звук.";
    }
}

void lock(std::uint64_t& mask,std::uint16_t index,std::initializer_list<const char*> rows) noexcept {
    for(const auto* row:rows)lockRow(mask,index,row);
}

double feedbackAmount(double percent) noexcept { return std::clamp(percent*.01,-.985,.985); }
double unit(double percent) noexcept { return std::clamp(percent*.01,0.0,1.0); }
double warp(double bipolar,double shape) noexcept {
    if(shape==0)return std::clamp(bipolar,-1.0,1.0);
    const double u=std::clamp((bipolar+1.0)*.5,0.0,1.0);
    const double exponent=std::pow(4.0,std::clamp(shape,-100.0,100.0)*.01);
    return 2*std::pow(u,exponent)-1;
}
double wave(double phase,int type,double shape=0) noexcept {
    phase-=std::floor(phase);
    double result=0;
    switch(type){
    case 0:result=1-4*std::abs(phase-.5);break; // triangle
    case 1:result=std::sin(2*pi*phase);break;
    case 2:{const double v=(1+std::sin(2*pi*phase))*.5;result=2*v*v-1;break;}
    case 3:result=2*phase-1;break;
    case 4:result=1-2*phase;break;
    default:result=phase<.5?1:-1;break;
    }
    return warp(result,shape);
}
double bounded(double v) noexcept { return std::isfinite(v)?std::clamp(v,-64.0,64.0):0.0; }
double fraction(double v) noexcept { return v-std::floor(v); }
double coefficient(double sr,double seconds) noexcept { return 1-std::exp(-1/(sr*std::max(.0001,seconds))); }
double ownSpeed(double v) noexcept { return .08+11.92*std::pow(unit(v),2); }
double ownAcceleration(double v) noexcept { return .04+7.96*std::pow(1-unit(v),2); }

} // namespace

NumberedFxSupport numberedModFxSupport(std::uint16_t index) noexcept {
    if(!inFamily(index))return {};
    const auto* d=findNumberedFx(index);
    if(!d||d->completeness!=NumberedFxCompleteness::Table)return {};
    auto mask=editableMainMask(index)|connectedSourceRows(index);
    switch(index){
    case 31:case 43:lock(mask,index,{"a_3"});break; // Printed Amt misclassified in source catalog.
    case 38:lock(mask,index,{"b_1","b_2","d_1"});break;
    case 39:lock(mask,index,{"a_2","a_3","b_1","b_2"});break;
    case 41:lock(mask,index,{"a_1","b_1"});break;
    case 48:lock(mask,index,{"a_1","c_1","c_2"});break;
    case 49:lock(mask,index,{"d_1"});break;
    case 50:lock(mask,index,{"g_1"});break;
    case 51:lock(mask,index,{"d_2","e_1","h_1"});break;
    case 162:lock(mask,index,{"h_1"});break;
    case 163:lock(mask,index,{"d_2","d_3","e_1","f_1","i_1"});break;
    case 177:lock(mask,index,{"e_2"});break;
    case 207:lock(mask,index,{"j_1","t_1"});break;
    default:break;
    }
    return {true,mask,limitation(index)};
}

bool initializeNumberedModFx(std::uint16_t index,NumberedFxState& state) noexcept {
    if(!numberedModFxSupport(index).selectable)return false;
    NumberedFxState next;if(!initializeKnown(index,next))return false;
    bool ok=true;
    const auto set=[&](const char* row,double v){ok=setInitial(next,row,v)&&ok;};
    if(const auto* sync=syncRow(index)){
        set(sync,0);char row[]{sync[0],'_','2','\0'};set(row,120);
        row[2]='3';set(row,1);row[2]='4';set(row,1);
    }
    if(const auto* step=stepNoteRow(index))set(step,1);
    // All settings below are our explicit starting points, not factory data.
    switch(index){
    case 26:set("a_1",1);set("a_2",90);set("b_1",.8);set("d_1",8);set("d_2",11);set("e_1",35);set("f_1",100);set("i_1",50);break;
    case 27:set("a_1",1);set("a_2",90);set("b_1",.7);set("d_1",8);set("e_1",40);set("f_1",45);set("g_1",10);set("g_2",20);set("h_1",100);set("h_2",100);set("i_1",50);break;
    case 28:set("a_1",1);set("a_2",0);set("a_3",1);set("b_1",.6);set("c_1",1.3);set("d_1",30);set("e_1",20);set("f_1",8);set("f_2",12);set("g_1",15);set("g_2",20);set("h_1",50);break;
    case 29:{set("a_1",.7);for(int i=0;i<4;++i){char row[]{static_cast<char>('b'+i),'_','1','\0'};set(row,18+i*11);row[2]='2';set(row,8);row[2]='3';set(row,30);row[2]='4';set(row,-6+i*4);}set("f_1",12);set("g_1",50);break;}
    case 30:set("a_1",35);set("b_1",40);set("c_1",35);set("d_1",50);break;
    case 31:set("a_1",45);set("a_3",0);set("b_1",50);break;
    case 32:set("a_1",2);set("b_1",1);set("c_1",90);set("d_1",.35);set("f_1",50);set("g_1",45);set("g_2",25);set("h_1",50);break;
    case 33:set("a_1",2);set("b_1",1);set("b_2",90);set("c_1",.3);set("d_1",5);set("f_2",1);set("g_1",45);set("h_1",40);set("h_2",25);set("i_1",50);break;
    case 34:
        set("a_1",.5);set("a_2",8);set("b_1",1);set("b_2",12);
        set("c_1",0);set("c_2",static_cast<int>(NumberedFxControlSource::Gate1));
        set("d_1",60);set("d_2",40);set("e_1",40);set("f_1",25);set("g_1",50);break;
    case 35:set("a_1",1);set("b_1",90);set("c_1",.4);set("e_1",50);set("f_1",55);set("h_1",30);set("h_2",15);set("j_1",50);break;
    case 36:set("a_1",2);set("a_2",90);set("b_1",.35);set("c_1",5);set("e_2",1);set("f_1",50);set("g_1",55);set("h_1",30);set("h_2",15);set("i_1",50);break;
    case 37:
        set("a_1",20);set("a_2",80);set("b_1",30);set("b_2",90);
        set("c_1",0);set("c_2",static_cast<int>(NumberedFxControlSource::Gate1));
        set("d_1",60);set("d_2",40);set("e_1",40);set("f_1",20);set("g_1",50);break;
    case 38:set("b_2",1);set("c_1",1);set("d_1",0);set("e_1",5);set("g_1",30);set("h_1",100);break;
    case 39:set("a_3",1);set("c_1",1);set("d_1",90);set("e_1",.8);set("f_1",25);set("f_2",35);set("g_1",45);set("h_1",15);set("h_2",25);set("i_1",50);break;
    case 41:set("a_1",0);set("b_1",0);set("c_1",.25);set("e_1",40);set("f_1",85);set("g_1",65);break;
    case 42:
        set("a_1",static_cast<int>(NumberedFxControlSource::JoystickX));
        set("b_1",65);set("c_1",1);set("c_2",0);set("d_1",5);
        set("e_1",70);set("f_1",2);set("g_1",100);break;
    case 43:set("a_1",25);set("a_3",0);set("c_1",4);set("e_1",100);break;
    case 44:set("a_1",1);set("b_1",0);set("c_1",4);set("e_1",60);set("f_1",100);break;
    case 45:set("a_1",55);set("b_1",1);set("d_1",5);set("d_2",-3);set("e_1",65);set("e_2",-40);set("f_1",100);break;
    case 46:set("a_1",1);set("b_1",0);set("c_1",.8);set("e_1",100);set("f_1",100);break;
    case 47:set("a_1",0);set("a_2",90);set("b_1",.7);set("d_1",50);set("d_2",30);set("e_1",50);set("f_1",50);set("h_1",45);set("i_1",100);break;
    case 48:set("a_1",0);set("a_2",20);set("b_1",120);set("d_1",.5);set("f_1",15);set("g_1",65);break;
    case 49:set("a_1",9);set("b_1",12);set("c_1",10);set("c_2",20);set("d_1",0);set("e_1",50);break;
    case 50:set("a_1",1);set("b_1",7);set("d_1",100);set("e_1",1);set("f_1",15);set("f_2",20);set("g_1",0);set("h_1",65);break;
    case 51:set("a_1",1);set("b_1",7);set("d_1",120);set("d_2",0);set("e_2",8);set("f_1",1);set("g_1",20);set("g_2",20);set("h_1",0);set("i_1",50);break;
    case 52:set("a_1",7);set("b_1",0);set("c_1",.8);set("e_1",18);set("f_1",50);set("g_1",75);break;
    case 53:set("a_1",100);set("b_1",0);set("c_1",3);set("d_1",100);set("e_1",50);set("f_1",6.7);set("g_1",100);break;
    case 54:set("a_1",0);set("b_1",0);set("d_1",60);set("d_2",1);set("e_1",40);set("e_2",1);set("f_1",50);set("g_1",35);set("g_2",70);set("h_1",100);break;
    case 161:{set("a_1",.6);for(int i=0;i<6;++i){char row[]{static_cast<char>('b'+i),'_','1','\0'};set(row,20+i*12);row[2]='2';set(row,7);row[2]='3';set(row,0);}set("h_1",0);set("i_1",15);set("j_1",50);break;}
    case 162:set("a_1",1);set("a_2",1);set("b_1",5);set("d_1",75);set("e_1",110);set("f_1",15);set("f_2",20);set("g_1",1);set("g_2",100);set("h_1",0);set("i_1",60);break;
    case 163:set("a_1",1);set("a_2",1);set("b_1",5);set("d_1",120);set("d_2",0);set("d_3",0);set("e_2",8);set("f_2",12);set("g_1",1);set("g_2",100);set("h_1",20);set("h_2",20);set("i_1",0);set("j_1",50);break;
    case 164:set("a_1",1);set("b_1",30);set("b_2",80);set("C_1",9);set("C_2",1);set("d_1",0);set("e_1",0);set("f_1",50);set("g_1",60);set("g_2",1);set("h_1",40);set("h_2",1);set("i_1",35);set("i_2",70);set("j_1",100);break;
    case 173:set("a_1",40);set("b_1",65);set("c_1",50);set("d_1",100);break;
    case 174:set("a_1",.8);set("b_1",60);set("c_1",26);set("d_1",45);set("e_1",50);break;
    case 175:set("a_1",1);set("c_1",0);set("e_1",50);break;
    case 176:set("a_1",.8);set("b_1",50);set("c_1",45);set("d_1",1);set("e_1",100);break;
    case 177:set("a_1",.4);set("b_1",55);set("c_1",45);set("d_1",45);set("e_2",0);set("f_1",50);break;
    case 178:set("a_1",4);set("b_1",55);set("c_1",35);set("d_1",99);set("e_1",100);break;
    case 189:set("a_1",.7);set("a_4",50);set("b_1",0);set("c_1",1);set("d_1",100);set("e_1",1);set("f_1",100);break;
    case 207:
        set("a_1",0);set("c_1",1);set("d_1",100);set("f_1",0);set("h_1",0);set("j_1",0);
        for(const auto group:{'k','n'})for(int i=1;i<=6;++i){char row[]{group,'_',static_cast<char>('0'+i),'\0'};set(row,i==1?70:i==2?20:i==3?60:i==4?40:i==5?55:35);}
        set("l_1",35);set("l_2",70);set("m_1",0);set("m_2",0);set("o_1",45);set("o_2",60);set("p_1",0);set("p_2",0);set("q_1",50);set("r_1",1);set("r_2",0);set("s_1",0);set("t_1",100);break;
    default:return false;
    }
    if(!ok||!numberedModFxCanRender(next))return false;
    state=next;return true;
}

bool numberedModFxCanRender(const NumberedFxState& s) noexcept {
    // Original SET ownership does not yet bind the real control bus needed
    // by these algorithms. Their unbound dry bypass is not an applied source
    // MFX result (Scratch may explicitly require Direct Mix=Always Off).
    if(s.origin==NumberedFxOrigin::Decoded&&controlled(s.index))return false;
    if(!inFamily(s.index)||!baseStateValid(s,connectedSourceRows(s.index),dormantLegacyNotes(s)))return false;
    if(const auto* sync=syncRow(s.index)){
        // The manual defines these fields as dormant when Sync is Off. Their
        // exact saved values remain known and validated, not reset to120/x1.
        if(value(s,sync)!=0&&(!std::isfinite(syncedRate(s))||
            (stepNoteRow(s.index)&&!std::isfinite(syncedRate(s,stepNoteRow(s.index))))))return false;
    }
    switch(s.index){
    case 31:case 43:return value(s,"a_3")==0;
    case 34:case 37:
        return numberedFxControlSourceSupported(static_cast<int>(value(s,"c_2")));
    case 38:return value(s,"d_1")==0&&value(s,"b_1")==0&&value(s,"b_2")==1;
    case 39:return value(s,"b_1")==0&&value(s,"b_2")==0&&value(s,"a_2")==0&&value(s,"a_3")==1;
    case 41:return value(s,"a_1")==0&&value(s,"b_1")==0;
    case 42:
        return numberedFxControlSourceSupported(static_cast<int>(value(s,"a_1")))&&
            numberedFxControlSourceSupported(static_cast<int>(value(s,"c_2")));
    case 48:return value(s,"a_1")==0&&value(s,"c_1")==0&&value(s,"c_2")==0;
    case 49:return value(s,"d_1")==0;
    case 50:return value(s,"g_1")==0;
    case 51:case 163:{
        const double bpm=value(s,"d_1");
        const double left=value(s,"e_2");
        const double right=s.index==163?value(s,"f_2"):left;
        return bpm>=40&&bpm<=300&&7500.0*std::max(left,right)/bpm<=5290.0&&
            value(s,s.index==51?"h_1":"i_1")==0&&value(s,"d_2")==0&&(s.index!=163||value(s,"d_3")==0);
    }
    case 162:return value(s,"h_1")==0;
    case 177:return value(s,"e_2")==0;
    case 207:return value(s,"t_1")==100&&value(s,"j_1")==0;
    default:return true;
    }
}

// DSP implementation follows below. All nonlinear scales not specified by the
// manual are explicit SILVETON choices, documented in the coverage artifact.

struct NumberedModFx::Impl {
    struct Rotor {
        double fast{6.8},slow{.8},accel{1},decel{1},start{1},stop{1};
        double accelCoefficient{1},decelCoefficient{1},startCoefficient{1},stopCoefficient{1};
        double distance{.35},spread{.7},stopPhase{0};bool lockPhase{false};
    };
    struct Config {
        std::uint16_t index{0};
        double wet{1},frequency{.8},frequency2{1.3},stepFrequency{5},phase{0},shape{0};
        double depth{.4},depth2{.2},delay[2]{8,10},feedback{0},damping{0};
        double manual{.5},pitchCents{0},pitchDepth{0},windowMs{40},pan{.5},spread{1};
        double inputGain{1},level{1},lowLevel{1},highLevel{1},internalMix{.5},shimmer{0};
        double envelopeSensitivity{1},envelopeShape{0},envelopeFrequency{0},envelopeDepth{0};
        double rangeBottom[2]{0,0},rangeTop[2]{1,1};
        double egAttackStep{1},egDecayStep{1},controlResponse{1},recordRelease{1},recordThreshold{.05},recordEndFade{1};
        double tapTime[6]{},tapDepth[6]{},tapLevel[6]{},tapPan[6]{};
        int waveform{1},waveform2{1},mode{0},feedbackPosition{1},stages{6},tapCount{0},outputMode{0};
        int controlSource{0},recordSource{0};
        bool oppositePitch{false},rotate{true},fast{false},switchOn{true},dryPost{false};
        bool overdrive{false},speakerSim{false};
        double drive{1},driveLevel{1},balance{.5};int speakerType{0},ampType{0};
        Rotor rotor[2]{};
    } c;

    double sr{48000};float* workspace{nullptr};std::size_t workspaceSamples{0};
    bool prepared{false},enabled{false};
    Ring delay[2],pitch[2];
    std::array<Biquad,2> eqLow{},eqHigh{},inputLow{},splitLow{};
    std::array<Biquad,2> rotaryLow{},rotaryHigh{};
    Biquad driveTone{},speakerLow{},speakerHigh{},speakerPeak{};
    double phase{0},phase2{.25},stepPhase{0},carrierPhase{0};std::uint64_t cycles{0};
    double sampledLfo[2]{0,0},lastStepPosition[2]{-1,-1};
    double allpass[2][12]{},allpassCoefficient[2][12]{};
    double feedbackState[2]{0,0},dampState[2]{0,0},dampCoefficient{1};
    double pitchPhase[2]{0,.25},pitchRatio[2]{1,1},rotorPhase[2]{0,.25},rotorSpeed[2]{0,0};
    bool rotorStarting[2]{true,true};
    double delaySmoothed[2]{0,0},pitchSmoothed{0},wetSmoothed{1},smoothing{.001};
    double envelope{0},envelopeAttack{1},envelopeRelease{1},vibeLfo{0};
    unsigned controlCounter{0};
    // Four fixed borrowed grain buffers (record/play × stereo). No block copy
    // or resize happens in process; recording and playback advance one sample.
    float* grain[2][2]{};std::size_t grainCapacity{0},grainWrite{0},grainValid{0};
    std::size_t grainLength{0},grainStart{0},grainPlay{0};int grainRecord{0},grainPlaying{1};
    // Real block-rate MIDI control. This snapshot is copied once per block,
    // never once per sample; only34/37/42 use it.
    NumberedFxControlFrame controls{};
    bool controlReady{false},controlBound{false},controlEpochKnown{false},pendingControlRise{false};
    std::uint64_t lastControlRise{0};
    double egLevel{0},sweepPosition{0},controlGate{0};int egStage{0};
    // Scratch borrows a mono2730ms window of the same prepared arena. It has
    // independent logical validity, so no captured audio survives a new owner.
    Ring scratch;
    bool scratchRecording{false},scratchPositionReady{false};
    double scratchPosition{0},scratchActivity{0},recordEnvelope{0};
    double scratchDcInput{0},scratchDcOutput{0},scratchDcCoefficient{0};

    void reset() noexcept {
        for(auto& r:delay)r.reset();for(auto& r:pitch)r.reset();
        for(auto* set:{&eqLow,&eqHigh,&inputLow,&splitLow,&rotaryLow,&rotaryHigh})for(auto& f:*set)f.reset();
        driveTone.reset();speakerLow.reset();speakerHigh.reset();speakerPeak.reset();
        phase=0;phase2=.25;stepPhase=carrierPhase=0;cycles=0;controlCounter=0;envelope=vibeLfo=0;
        for(int channel=0;channel<2;++channel){
            sampledLfo[channel]=0;lastStepPosition[channel]=-1;
            feedbackState[channel]=dampState[channel]=0;
            pitchPhase[channel]=channel?.25:0;pitchRatio[channel]=1;rotorPhase[channel]=channel?.25:0;rotorSpeed[channel]=0;
            rotorStarting[channel]=c.rotate;
            delaySmoothed[channel]=c.delay[channel];
            for(int stage=0;stage<12;++stage){allpass[channel][stage]=0;allpassCoefficient[channel][stage]=0;}
        }
        pitchSmoothed=c.pitchCents;wetSmoothed=c.wet;
        grainWrite=grainValid=grainLength=grainStart=grainPlay=0;grainRecord=0;grainPlaying=1;
        controlReady=controlBound=controlEpochKnown=pendingControlRise=false;lastControlRise=0;
        egLevel=sweepPosition=controlGate=0;egStage=0;
        scratch.reset();scratchRecording=scratchPositionReady=false;
        scratchPosition=scratchActivity=recordEnvelope=scratchDcInput=scratchDcOutput=0;
    }

    void configure(const NumberedFxState& state) noexcept {
        const auto oldIndex=c.index;const bool wasEnabled=enabled,wasRotating=c.rotate;
        const int oldSource=c.controlSource,oldRecordSource=c.recordSource,oldMode=c.mode;
        enabled=prepared&&numberedModFxCanRender(state);
        if(!enabled){if(oldIndex!=state.index)reset();c.index=state.index;return;}
        c=Config{};c.index=state.index;c.wet=wet(state);
        const auto v=[&](const char* row,double fallback=0){return value(state,row,fallback);};
        const auto commonLfo=[&](const char* frequency,const char* waveform,const char* phase,const char* shape,const char* depth){
            c.frequency=v(frequency);if(waveform)c.waveform=static_cast<int>(v(waveform));
            if(phase)c.phase=v(phase)/360.0;if(shape)c.shape=v(shape);if(depth)c.depth=v(depth)*.01;
        };
        for(auto* set:{&eqLow,&eqHigh,&inputLow,&splitLow,&rotaryLow,&rotaryHigh})for(auto& f:*set)f.identity();
        driveTone.identity();speakerLow.identity();speakerHigh.identity();speakerPeak.identity();
        switch(c.index){
        case 26:
            commonLfo("b_1","a_1","a_2",nullptr,"e_1");c.delay[0]=v("d_1");c.delay[1]=v("d_2");c.inputGain=unit(v("f_1"));
            for(int i=0;i<2;++i){eqLow[i].configure(Biquad::Type::LowShelf,sr,v("g_1")==0?100:400,.707,v("h_1"));eqHigh[i].configure(Biquad::Type::HighShelf,sr,v("g_2")==0?8000:3000,.707,v("h_2"));}break;
        case 27:
            commonLfo("b_1","a_1","a_2",nullptr,"e_1");c.delay[0]=c.delay[1]=v("d_1");c.feedback=feedbackAmount(v("g_1"));c.damping=unit(v("g_2"));
            c.lowLevel=unit(v("h_1"));c.highLevel=unit(v("h_2"));
            for(auto& f:splitLow)f.configure(Biquad::Type::LowPass,sr,150*std::pow(40.0,unit(v("f_1"))),.707);break;
        case 28:
            c.frequency=v("b_1");c.frequency2=v("c_1");c.waveform=static_cast<int>(v("a_1"));c.waveform2=static_cast<int>(v("a_2"));c.phase=v("a_3")*.5;
            c.depth=unit(v("d_1"));c.depth2=unit(v("e_1"));c.delay[0]=v("f_1");c.delay[1]=v("f_2");c.feedback=feedbackAmount(v("g_1"));c.damping=unit(v("g_2"));break;
        case 29:
            c.frequency=v("a_1");c.tapCount=4;c.feedback=feedbackAmount(v("f_1"));
            for(int i=0;i<4;++i){char row[]{static_cast<char>('b'+i),'_','1','\0'};c.tapTime[i]=v(row);row[2]='2';c.tapDepth[i]=v(row)*.3;row[2]='3';c.tapLevel[i]=v(row)/120.0;row[2]='4';c.tapPan[i]=v(row)/6.0;}break;
        case 30:c.frequency=ownSpeed(v("a_1"));c.depth=unit(v("b_1"));c.shimmer=unit(v("c_1"));break;
        case 31:c.frequency=.61;c.frequency2=6.8;c.depth=unit(v("a_1"));break;
        case 32:commonLfo("d_1","b_1","c_1","b_2","f_1");c.delay[0]=c.delay[1]=v("a_1");c.feedback=feedbackAmount(v("g_1"));c.damping=unit(v("g_2"));break;
        case 33:commonLfo("c_1","b_1","b_2",nullptr,"g_1");c.delay[0]=c.delay[1]=v("a_1");c.stepFrequency=v("d_1");c.feedback=feedbackAmount(v("h_1"));c.damping=unit(v("h_2"));break;
        case 34:case 37:{
            const double scale=c.index==37?.01:1;
            c.rangeBottom[0]=v("a_1")*scale;c.rangeTop[0]=v("a_2")*scale;
            c.rangeBottom[1]=v("b_1")*scale;c.rangeTop[1]=v("b_2")*scale;
            c.mode=static_cast<int>(v("c_1"));c.controlSource=static_cast<int>(v("c_2"));
            // The manual gives1..100 speed, not seconds. Our speed law is
            // explicitly1=5seconds,100=1ms, logarithmic between those ends.
            const auto seconds=[](double speed){return 5*std::pow(.0002,(speed-1)/99);};
            c.egAttackStep=1/(sr*seconds(v("d_1")));c.egDecayStep=1/(sr*seconds(v("d_2")));
            c.feedback=feedbackAmount(v("e_1"));c.damping=unit(v("f_1"));
            c.controlResponse=coefficient(sr,.001);break;
        }
        case 35:commonLfo("c_1","a_1","b_1","a_2","f_1");c.manual=unit(v("e_1"));c.feedback=feedbackAmount(v("h_1"));c.damping=unit(v("h_2"));break;
        case 36:commonLfo("b_1","a_1","a_2",nullptr,"g_1");c.stepFrequency=v("c_1");c.manual=unit(v("f_1"));c.feedback=feedbackAmount(v("h_1"));c.damping=unit(v("h_2"));break;
        case 38:commonLfo("e_1","c_1",nullptr,"c_2","g_1");c.delay[0]=c.delay[1]=2;break;
        case 39:commonLfo("e_1","c_1","d_1","c_2","g_1");c.delay[0]=v("f_1");c.delay[1]=v("f_2");c.feedback=feedbackAmount(v("h_1"));c.damping=unit(v("h_2"));break;
        case 41:c.frequency=v("c_1");c.depth=unit(v("e_1"));c.spread=v("f_1")*.01;break;
        case 42:
            c.controlSource=static_cast<int>(v("a_1"));c.mode=static_cast<int>(v("c_1"));
            c.recordSource=static_cast<int>(v("c_2"));c.recordThreshold=unit(v("d_1"));
            c.outputMode=static_cast<int>(v("f_1"));
            // Own response laws:1..200ms position smoothing,1..1000ms
            // end-of-record release. High parameter values respond faster.
            c.controlResponse=coefficient(sr,.001+.199*std::pow(1-unit(v("b_1")),2));
            c.recordEndFade=sr*(.001+.999*std::pow(1-unit(v("e_1")),2));
            c.recordRelease=1/std::max(1.0,c.recordEndFade);
            scratchDcCoefficient=std::exp(-2*pi*8/sr);break;
        case 43:c.frequency=v("c_1");c.depth=unit(v("a_1"));break;
        case 44:commonLfo("c_1","a_1","b_1","a_2","e_1");break;
        case 45:
            commonLfo("d_1","b_1","c_1","b_2","e_1");c.envelopeSensitivity=std::pow(10.0,v("a_1")/40.0-1);
            c.envelopeShape=v("a_2");c.envelopeFrequency=v("d_2");c.envelopeDepth=v("e_2")*.01;break;
        case 46:commonLfo("c_1","a_1","b_1","a_2","e_1");break;
        case 47:
            c.mode=static_cast<int>(v("a_1"));c.phase=v("a_2")/360;c.frequency=v("b_1");c.manual=unit(v("d_1"));c.feedback=feedbackAmount(v("d_2"));c.depth=unit(v("e_1"));
            c.internalMix=v("f_1")*.01;c.shape=v("g_1");c.depth2=unit(v("h_1"));break;
        case 48:
            c.frequency=v("d_1");c.frequency2=v("b_1");c.depth=unit(v("f_1"));
            for(auto& f:inputLow)f.configure(Biquad::Type::LowPass,sr,20000*std::pow(.01,unit(v("a_2"))),.707);break;
        case 49:c.pitchCents=v("a_1");c.windowMs=80;c.delay[0]=c.delay[1]=v("b_1");c.feedback=feedbackAmount(v("c_1"));c.damping=unit(v("c_2"));c.feedbackPosition=1;break;
        case 50:case 51:case 162:case 163:{
            c.mode=static_cast<int>(v("a_1"));c.windowMs=c.mode==0?80:c.mode==1?40:20;c.pitchCents=v("b_1")*100+v("c_1");
            c.oppositePitch=(c.index==162||c.index==163)&&v("a_2")==1;
            if(c.index==50){c.delay[0]=c.delay[1]=v("d_1");c.feedbackPosition=static_cast<int>(v("e_1"));c.feedback=feedbackAmount(v("f_1"));c.damping=unit(v("f_2"));}
            if(c.index==51){c.delay[0]=c.delay[1]=7500*v("e_2")/v("d_1");c.feedbackPosition=static_cast<int>(v("f_1"));c.feedback=feedbackAmount(v("g_1"));c.damping=unit(v("g_2"));}
            if(c.index==162){c.delay[0]=v("d_1");c.delay[1]=v("e_1");c.feedbackPosition=static_cast<int>(v("g_1"));c.spread=v("g_2")*.01;c.feedback=feedbackAmount(v("f_1"));c.damping=unit(v("f_2"));}
            if(c.index==163){c.delay[0]=7500*v("e_2")/v("d_1");c.delay[1]=7500*v("f_2")/v("d_1");c.feedbackPosition=static_cast<int>(v("g_1"));c.spread=v("g_2")*.01;c.feedback=feedbackAmount(v("h_1"));c.damping=unit(v("h_2"));}
            break;
        }
        case 52:c.pitchCents=v("a_1");c.waveform=v("b_1")==0?0:5;c.frequency=v("c_1");c.pitchDepth=v("e_1");c.pan=unit(v("f_1"));c.windowMs=40;break;
        case 53:
            c.inputGain=unit(v("a_1"));c.mode=static_cast<int>(v("b_1"));
            if(c.mode==0){const int type=static_cast<int>(v("c_1"));c.depth=.25+.25*(type/2);c.internalMix=(type%2)? .5:0;c.frequency=6.7;}
            else{c.depth=unit(v("e_1"));c.internalMix=unit(v("d_1"))*.5;c.frequency=v("f_1");}break;
        case 54:case 164:{
            const bool od=c.index==164;
            c.rotate=v(od?"d_1":"a_1")==0;c.fast=v(od?"e_1":"b_1")==1;c.balance=unit(v(od?"f_1":"f_1"));
            const double hornRatio=v(od?"g_2":"d_2"),rotorRatio=v(od?"h_2":"e_2");
            const double hr=hornRatio<=kNumberedFxChoiceBase?0:hornRatio,rr=rotorRatio<=kNumberedFxChoiceBase?0:rotorRatio;
            c.rotor[0].fast=6.8*hr;c.rotor[0].slow=.8*hr;c.rotor[1].fast=5.8*rr;c.rotor[1].slow=.7*rr;
            for(int r=0;r<2;++r){auto& rc=c.rotor[r];const double acceleration=v(r?(od?"h_1":"e_1"):(od?"g_1":"d_1"));rc.accel=rc.decel=rc.start=rc.stop=ownAcceleration(acceleration);rc.distance=unit(v(od?"i_1":"g_1"));rc.spread=unit(v(od?"i_2":"g_2"));}
            if(od){c.overdrive=v("a_1")==1;c.drive=1+29*unit(v("b_1"));c.driveLevel=unit(v("b_2"));c.speakerSim=v("C_2")==1;driveTone.configure(Biquad::Type::LowPass,sr,400+11600*std::pow(v("C_1")/15,2));}
            break;
        }
        case 161:{
            c.frequency=v("a_1");c.tapCount=6;c.feedback=feedbackAmount(v("i_1"));c.mode=static_cast<int>(v("h_1"));
            static constexpr int positions[4][6]{{0,1,2,3,4,5},{0,5,0,5,0,5},{0,3,1,4,2,5},{0,5,4,1,2,3}};
            for(int i=0;i<6;++i){char row[]{static_cast<char>('b'+i),'_','1','\0'};c.tapTime[i]=v(row);row[2]='2';c.tapDepth[i]=v(row)*.3;row[2]='3';const int status=static_cast<int>(v(row));c.tapLevel[i]=(status==0||status==2)?1.0/6:0;c.tapPan[i]=-1+positions[c.mode][i]*.4;}break;
        }
        case 173:c.frequency=ownSpeed(v("a_1"));c.depth=unit(v("b_1"));c.internalMix=unit(v("c_1"));c.manual=.5;c.feedback=.3;c.stages=4;break;
        case 174:c.frequency=v("a_1");c.depth=unit(v("b_1"));c.feedback=feedbackAmount(v("c_1"));c.manual=unit(v("d_1"));c.stages=4;break;
        case 175:c.frequency=v("a_1");c.mode=static_cast<int>(v("c_1"));c.depth=c.mode?.85:.6;c.manual=.45;c.feedback=c.mode?.7:.12;c.stages=4;break;
        case 176:c.frequency=v("a_1");c.depth=unit(v("b_1"));c.manual=v("c_1")/99;c.outputMode=static_cast<int>(v("d_1"));break;
        case 177:c.frequency=v("a_1");c.depth=unit(v("b_1"));c.manual=unit(v("d_1"));c.feedback=feedbackAmount(v("c_1"));break;
        case 178:c.frequency=v("a_1");c.depth=unit(v("b_1"));c.phase=unit(v("c_1"))*.5;c.level=v("d_1")/99;c.waveform=2;break;
        case 189:c.frequency=v("a_1");c.depth=unit(v("a_4"));c.mode=static_cast<int>(v("b_1"));c.depth2=v("c_1")*.5;c.inputGain=unit(v("d_1"));c.outputMode=static_cast<int>(v("e_1"));c.feedback=c.mode==2?c.depth*.96:0;break;
        case 207:
            c.switchOn=v("a_1")==0;c.dryPost=v("c_1")==1;c.wet=v("d_1")*.01;c.rotate=v("f_1")==0;c.fast=v("h_1")==1;
            for(int r=0;r<2;++r){auto& rc=c.rotor[r];const char group=r?'n':'k';char row[]{group,'_','1','\0'};rc.fast=2+8*unit(v(row));row[2]='2';rc.slow=.05+1.95*unit(v(row));row[2]='3';rc.accel=ownAcceleration(v(row));row[2]='4';rc.decel=ownAcceleration(v(row));row[2]='5';rc.start=ownAcceleration(v(row));row[2]='6';rc.stop=ownAcceleration(v(row));rc.distance=unit(v(r?"o_1":"l_1"));rc.spread=unit(v(r?"o_2":"l_2"));rc.lockPhase=v(r?"p_1":"m_1")==1;rc.stopPhase=v(r?"p_2":"m_2")/360.0;}
            c.balance=unit(v("q_1"));c.speakerSim=v("r_1")==1;c.speakerType=static_cast<int>(v("r_2"));c.ampType=static_cast<int>(v("s_1"));break;
        default:enabled=false;break;
        }
        if(const auto* sync=syncRow(c.index);sync&&v(sync)!=0){
            c.frequency=syncedRate(state);
            if(const auto* step=stepNoteRow(c.index))c.stepFrequency=syncedRate(state,step);
        }
        if(c.index==54||c.index==164||c.index==207){
            if(c.rotate&&!wasRotating)for(auto& starting:rotorStarting)starting=true;
            if(!c.rotate)for(auto& starting:rotorStarting)starting=false;
            for(auto& r:c.rotor){r.accelCoefficient=coefficient(sr,r.accel);r.decelCoefficient=coefficient(sr,r.decel);r.startCoefficient=coefficient(sr,r.start);r.stopCoefficient=coefficient(sr,r.stop);}
            for(auto& f:rotaryLow)f.configure(Biquad::Type::LowPass,sr,800,.7071067811865476);
            for(auto& f:rotaryHigh)f.configure(Biquad::Type::HighPass,sr,800,.7071067811865476);
            const int model=c.speakerType==6?3:c.speakerType/2;
            speakerHigh.configure(Biquad::Type::HighPass,sr,model==3?100:60,.707);
            speakerLow.configure(Biquad::Type::LowPass,sr,model==2?12000:model==3?4500:6000,.707);
            speakerPeak.configure(Biquad::Type::Peak,sr,model==1?1800:1100,model==1?1.1:.7,model==1?4:model==3?2:0);
        }
        const double dampHz=18000*std::pow(.0125,c.damping);
        dampCoefficient=c.damping==0?1:1-std::exp(-2*pi*std::min(dampHz,sr*.45)/sr);
        smoothing=coefficient(sr,.01);envelopeAttack=coefficient(sr,.002);envelopeRelease=coefficient(sr,.10);
        if(oldIndex!=c.index||!wasEnabled)reset();
        else if(controlled(c.index)&&(oldSource!=c.controlSource||oldRecordSource!=c.recordSource||oldMode!=c.mode)){
            // A different controller is reanchored, never heard as an
            // unsolicited jump through a recording. Preserve this owner's
            // captured window; a real subsequent recording replaces it.
            controlReady=controlBound=pendingControlRise=false;lastControlRise=0;
            egLevel=sweepPosition=controlGate=0;egStage=0;
            scratchPositionReady=scratchRecording=false;recordEnvelope=scratchActivity=0;
            scratchDcInput=scratchDcOutput=0;
        }
    }

    void setControlFrame(const NumberedFxControlFrame& frame) noexcept {
        if(!controlled(c.index))return;
        if(controlEpochKnown&&controls.ownerGeneration!=frame.ownerGeneration)reset();
        if(controlEpochKnown&&!sourceAvailable(c.controlSource)&&
           (c.controlSource==0||frame.available(c.controlSource))){
            controlBound=false;pendingControlRise=false;scratchPositionReady=false;
        }
        const bool first=!controlBound;
        const auto source=static_cast<std::size_t>(c.controlSource);
        const auto serial=frame.triggerSerial(c.controlSource);
        const auto previous=first?frame.blockStartRises[source]:lastControlRise;
        if(frame.frozen||!frame.available(c.controlSource))pendingControlRise=false;
        else if(serial>previous)pendingControlRise=true;
        controls=frame;lastControlRise=serial;controlBound=controlReady=controlEpochKnown=true;
        // An unavailable primary source bypasses processing even for IFX.
        // End that recording session here, so re-enabling cannot append
        // across blocks that never reached scratchEffect().
        if(frame.frozen||(c.controlSource!=0&&!frame.available(c.controlSource))){
            scratchRecording=false;recordEnvelope=0;
        }
        if(c.index==42&&!scratchPositionReady){
            scratchPosition=controlPosition(c.controlSource);scratchPositionReady=true;
            // Rebinding to a stationary real position must not replay the
            // activity/DC residual from the formerly available controller.
            scratchActivity=scratchDcInput=scratchDcOutput=0;
        }
    }

    bool sourceAvailable(int source) const noexcept {return source==0||controls.available(source);}
    double controlPosition(int source) const noexcept {
        const double p=controls.position(source);
        return std::isfinite(p)?std::clamp(p,0.0,1.0):0.0;
    }
    double envelopeSweep() noexcept {
        if(c.mode==0){
            if(pendingControlRise){egLevel=0;egStage=1;}
            if(egStage==1){egLevel=std::min(1.0,egLevel+c.egAttackStep);if(egLevel>=1)egStage=2;}
            else if(egStage==2){egLevel=std::max(0.0,egLevel-c.egDecayStep);if(egLevel<=0)egStage=0;}
        }
        pendingControlRise=false;
        const double target=c.mode==0?egLevel:controlPosition(c.controlSource);
        sweepPosition+=c.controlResponse*(target-sweepPosition);
        // Documented nominal63/64 on/off boundary is separate from the
        // physical continuous position (notably joystick centre).
        controlGate+=smoothing*((controls.high(c.controlSource)?1.0:0.0)-controlGate);
        return std::clamp(sweepPosition,0.0,1.0);
    }

    double scratchEffect(double input) noexcept {
        // Recording is controlled solely by real input or a real source.
        // Input mode measures a peak envelope with the chosen end response.
        // D-mod mode stops capturing immediately below the nominal64 boundary;
        // Response then controls only a read-time end-window fade. It cannot
        // append input after the real DMS gate is off.
        bool recording=false;
        if(!controls.frozen){
            if(c.mode==1){
                const double level=std::min(1.0,std::abs(input));
                if(level>=recordEnvelope)recordEnvelope=level;
                else recordEnvelope=std::max(level,recordEnvelope-c.recordRelease);
                recording=recordEnvelope>c.recordThreshold;
            }else recording=sourceAvailable(c.recordSource)&&controls.high(c.recordSource);
        }else recordEnvelope=0;
        if(recording&&!scratchRecording){scratch.reset();scratchActivity=0;scratchDcInput=scratchDcOutput=0;}
        scratchRecording=recording;
        if(recording)scratch.push(static_cast<float>(bounded(input)));

        const double target=controlPosition(c.controlSource),old=scratchPosition;
        scratchPosition+=c.controlResponse*(target-scratchPosition);
        // Read-head speed is created only by movement of the selected real
        // controller. A held value does not replay or sustain a DC sample.
        const double travel=scratch.valid>1?std::abs(scratchPosition-old)*(scratch.valid-1):0;
        const double moving=std::clamp(travel*8,0.0,1.0);
        scratchActivity+=smoothing*(moving-scratchActivity);
        double sample=0;
        if(scratch.valid>1&&scratchActivity>1.e-8){
            const double at=std::clamp(scratchPosition,0.0,1.0)*(scratch.valid-1);
            const double quarter=static_cast<double>(scratch.valid)*.25;
            const double startEdge=std::max(1.0,std::min(sr*.003,quarter));
            const double endEdge=std::max(1.0,std::min(scratchRecording?sr*.003:c.recordEndFade,quarter));
            const double fade=std::clamp(std::min(at/startEdge,(static_cast<double>(scratch.valid-1)-at)/endEdge),0.0,1.0);
            const auto frame=static_cast<std::size_t>(at);
            const double a=scratch.at(scratch.valid-frame);
            const double b=frame+1<scratch.valid?scratch.at(scratch.valid-frame-1):a;
            sample=(a+(b-a)*(at-frame))*fade*scratchActivity;
        }
        const double filtered=sample-scratchDcInput+scratchDcCoefficient*scratchDcOutput;
        scratchDcInput=sample;scratchDcOutput=std::abs(filtered)<1.e-25?0:bounded(filtered);
        if(c.outputMode==0)return input+scratchDcOutput; // Always On
        if(c.outputMode==1)return scratchDcOutput;       // Always Off
        return input*(1-std::clamp(scratchActivity,0.0,1.0))+scratchDcOutput; // Cross Fade
    }

    double damp(int channel,double input) noexcept {
        dampState[channel]+=dampCoefficient*(input-dampState[channel]);
        if(std::abs(dampState[channel])<1.e-25)dampState[channel]=0;
        return dampState[channel];
    }
    double delayed(int channel,double input,double milliseconds) noexcept {
        delay[channel].push(static_cast<float>(bounded(input+c.feedback*feedbackState[channel])));
        const double out=delay[channel].read(1+std::max(0.0,milliseconds)*sr*.001);
        feedbackState[channel]=damp(channel,out);return out;
    }
    static double randomValue(std::uint64_t n) noexcept {
        n+=0x9e3779b97f4a7c15ULL;n=(n^(n>>30))*0xbf58476d1ce4e5b9ULL;n=(n^(n>>27))*0x94d049bb133111ebULL;n^=n>>31;
        return static_cast<double>((n>>32)&0xffffffffULL)/2147483647.5-1;
    }
    double randomWave(double position) noexcept {
        const double base=std::floor(position),part=position-base;
        const auto n=static_cast<std::uint64_t>(base+1048576.0);
        const double a=randomValue(n),b=randomValue(n+1);
        return a+(b-a)*(part*part*(3-2*part));
    }
    double lfo(int channel) noexcept {
        const double offset=channel?c.phase:0;
        if(c.index!=33&&c.index!=36)return wave(phase+offset,c.waveform,c.shape);
        const double stepPosition=fraction(stepPhase+offset);
        if(lastStepPosition[channel]<0||stepPosition<lastStepPosition[channel]){
            const bool random=c.index==33?c.waveform==1:c.waveform==2;
            sampledLfo[channel]=random?randomWave(static_cast<double>(cycles)+phase+offset):wave(phase+offset,c.index==36&&c.waveform==1?1:0);
        }
        lastStepPosition[channel]=stepPosition;return sampledLfo[channel];
    }
    double phaser(int channel,double input,double modulation,bool absolute=false) noexcept {
        if((controlCounter&15U)==0){
            const double normalized=absolute?modulation:c.manual+.5*c.depth*modulation;
            const double center=60*std::pow(100.0,std::clamp(normalized,0.0,1.0));
            static constexpr double spread[]{.55,.78,1.0,1.36,1.85,2.5,3.1,3.8,4.5,5.2,6,7};
            static constexpr double vibe[]{.24,.52,1.0,2.05};
            for(int stage=0;stage<c.stages;++stage){
                const double hz=std::clamp(center*(c.index==173?vibe[stage]:spread[stage]),15.0,sr*.44);
                const double t=std::tan(pi*hz/sr);allpassCoefficient[channel][stage]=(t-1)/(t+1);
            }
        }
        double x=bounded(input+c.feedback*feedbackState[channel]);
        for(int stage=0;stage<c.stages;++stage){const double a=allpassCoefficient[channel][stage];const double y=a*x+allpass[channel][stage];allpass[channel][stage]=x-a*y;x=y;}
        feedbackState[channel]=damp(channel,x);return x;
    }
    double shifted(int channel,double input,double cents) noexcept {
        pitch[channel].push(static_cast<float>(bounded(input)));
        const double size=std::max(32.0,c.windowMs*sr*.001);
        if((controlCounter&15U)==0)pitchRatio[channel]=std::pow(2.0,std::clamp(cents,-2500.0,2500.0)/1200.0);
        const double ratio=pitchRatio[channel];
        auto& p=pitchPhase[channel];p=fraction(p+(1-ratio)/size);
        const double q=fraction(p+.5);const double w=.5-.5*std::cos(2*pi*p);
        return w*pitch[channel].read(2+p*size)+(1-w)*pitch[channel].read(2+q*size);
    }
    void pitchEffect(double inL,double inR,double& outL,double& outR,double cents) noexcept {
        const bool stereo=c.index==162||c.index==163;
        const double mono=(inL+inR)*.5;
        double result[2]{};
        for(int channel=0;channel<(stereo?2:1);++channel){
            const double input=stereo?(channel?inR:inL):mono;
            const double before=input+(c.feedbackPosition==0?c.feedback*feedbackState[channel]:0);
            const double shiftedSample=shifted(channel,before,channel&&c.oppositePitch?-cents:cents);
            const double after=shiftedSample+(c.feedbackPosition==1?c.feedback*feedbackState[channel]:0);
            delaySmoothed[channel]+=smoothing*(c.delay[channel]-delaySmoothed[channel]);
            delay[channel].push(static_cast<float>(bounded(after)));
            result[channel]=delay[channel].read(1+delaySmoothed[channel]*sr*.001);
            feedbackState[channel]=damp(channel,result[channel]);
        }
        if(!stereo)result[1]=result[0];
        const double mid=(result[0]+result[1])*.5,side=(result[0]-result[1])*.5*c.spread;
        outL=mid+side;outR=mid-side;
    }
    void granular(double inL,double inR,double& outL,double& outR,bool newCycle) noexcept {
        if(!grainCapacity){outL=outR=0;return;}
        grain[grainRecord][0][grainWrite]=static_cast<float>(inL);grain[grainRecord][1][grainWrite]=static_cast<float>(inR);
        if(++grainWrite==grainCapacity)grainWrite=0;if(grainValid<grainCapacity)++grainValid;
        const auto requested=std::clamp<std::size_t>(static_cast<std::size_t>((.002+.248*c.depth*c.depth)*sr),16,grainCapacity);
        if((!grainLength&&grainValid>=requested)||(newCycle&&grainValid>=16)){
            grainLength=std::min(requested,grainValid);grainStart=(grainWrite+grainCapacity-grainLength)%grainCapacity;
            grainPlaying=grainRecord;grainRecord=1-grainPlaying;grainWrite=grainValid=grainPlay=0;
        }
        if(!grainLength){outL=outR=0;return;}
        const auto at=(grainStart+grainPlay)%grainCapacity;
        const auto edge=std::max<std::size_t>(1,std::min<std::size_t>(32,grainLength/8));
        const double gain=std::min({1.0,static_cast<double>(grainPlay+1)/edge,static_cast<double>(grainLength-grainPlay)/edge});
        outL=grain[grainPlaying][0][at]*gain;outR=grain[grainPlaying][1][at]*gain;
        if(++grainPlay==grainLength)grainPlay=0;
    }
    double scanner(int channel,double input) noexcept {
        double tap[9]{};tap[0]=input;
        static constexpr double frequencies[]{180,300,500,800,1200,1900,3000,4700};
        if((controlCounter&15U)==0)for(int stage=0;stage<8;++stage){const double t=std::tan(pi*std::min(frequencies[stage],sr*.4)/sr);allpassCoefficient[channel][stage]=(t-1)/(t+1);}
        for(int stage=0;stage<8;++stage){const double a=allpassCoefficient[channel][stage];tap[stage+1]=a*tap[stage]+allpass[channel][stage];allpass[channel][stage]=tap[stage]-a*tap[stage+1];}
        const double position=4+4*c.depth*std::sin(2*pi*phase);
        const auto a=std::min(7,static_cast<int>(std::floor(position)));const double frac=position-a;
        const double processed=tap[a]+(tap[a+1]-tap[a])*frac;
        return processed*(1-c.internalMix)+input*c.internalMix;
    }
    void rotary(double inL,double inR,double& dryL,double& dryR,double& outL,double& outR) noexcept {
        const double original=(inL+inR)*.5;double input=original;
        if(c.overdrive)input=driveTone.process(static_cast<float>(std::tanh(input*c.drive)/std::tanh(c.drive)*c.driveLevel));
        if(c.ampType)input=std::tanh(input*(c.ampType==1?1.8:3.2))/(c.ampType==1?1.8:3.2);
        if(c.speakerSim){
            const double filtered=speakerLow.process(speakerPeak.process(speakerHigh.process(static_cast<float>(input))));
            input=(c.speakerType<6&&(c.speakerType&1))?filtered*.8+input*.2:filtered;
        }
        const double low=rotaryLow[1].process(rotaryLow[0].process(static_cast<float>(input)));
        const double high=rotaryHigh[1].process(rotaryHigh[0].process(static_cast<float>(input)));
        if(c.index==207&&c.dryPost)dryL=dryR=low+high;
        const double bands[2]{high,low};outL=outR=0;
        for(int r=0;r<2;++r){
            const auto& rc=c.rotor[r];const double target=c.rotate?(c.fast?rc.fast:rc.slow):0;
            const double ramp=target==0?rc.stopCoefficient:rotorStarting[r]?rc.startCoefficient:target>rotorSpeed[r]?rc.accelCoefficient:rc.decelCoefficient;
            rotorSpeed[r]+=ramp*(target-rotorSpeed[r]);
            if(rotorStarting[r]&&target>0&&std::abs(target-rotorSpeed[r])<=std::max(.001,target*.01))rotorStarting[r]=false;
            if(std::abs(rotorSpeed[r])<1.e-7)rotorSpeed[r]=0;
            rotorPhase[r]=fraction(rotorPhase[r]+rotorSpeed[r]/sr);
            if(!c.rotate&&rc.lockPhase&&rotorSpeed[r]<.05){double delta=fraction(rc.stopPhase-rotorPhase[r]+.5)-.5;rotorPhase[r]=fraction(rotorPhase[r]+delta*envelopeRelease);}
            pitch[r].push(static_cast<float>(bands[r]));
            const double bandGain=r?2*(1-c.balance):2*c.balance;
            for(int side=0;side<2;++side){
                const double theta=2*pi*(rotorPhase[r]+(side?1:-1)*rc.spread*.25);
                const double near=1-rc.distance;
                const double milliseconds=.25+(r?.7:1.4)*near*(.5+.5*std::sin(theta));
                const double amplitude=1-(.15+.65*near)*(.5+.5*std::cos(theta));
                const double sample=pitch[r].read(1+milliseconds*sr*.001)*amplitude*bandGain;
                (side?outR:outL)+=sample;
            }
        }
        if(!c.switchOn){outL=dryL;outR=dryR;}
    }
    void process(float inputL,float inputR,float& resultL,float& resultR) noexcept;
};

void NumberedModFx::Impl::process(float inputL,float inputR,float& resultL,float& resultR) noexcept {
    const double inL=bounded(finite(inputL)),inR=bounded(finite(inputR));
    if(!enabled){resultL=static_cast<float>(inL);resultR=static_cast<float>(inR);return;}
    if(controlled(c.index)&&(!controlReady||!sourceAvailable(c.controlSource))){
        resultL=static_cast<float>(inL);resultR=static_cast<float>(inR);return;
    }
    double dryL=inL,dryR=inR,outL=inL,outR=inR,frequency=c.frequency;
    const double lfoL=lfo(0),lfoR=lfo(1);
    wetSmoothed+=smoothing*(c.wet-wetSmoothed);
    switch(c.index){
    case 26:{
        const double left=eqHigh[0].process(eqLow[0].process(static_cast<float>(inL*c.inputGain)));
        const double right=eqHigh[1].process(eqLow[1].process(static_cast<float>(inR*c.inputGain)));
        outL=delayed(0,left,c.delay[0]+4*c.depth*(1+lfoL));outR=delayed(1,right,c.delay[1]+4*c.depth*(1+lfoR));break;
    }
    case 27:{
        const double lowL=splitLow[0].process(static_cast<float>(inL)),lowR=splitLow[1].process(static_cast<float>(inR));
        outL=lowL*c.lowLevel+delayed(0,inL-lowL,c.delay[0]+4*c.depth*(1+lfoL))*c.highLevel;
        outR=lowR*c.lowLevel+delayed(1,inR-lowR,c.delay[1]+4*c.depth*(1+lfoR))*c.highLevel;break;
    }
    case 28:
        outL=delayed(0,inL,c.delay[0]+4*c.depth*(1+lfoL)+3*c.depth2*(1+wave(phase2,c.waveform2)));
        outR=delayed(1,inR,c.delay[1]+4*c.depth*(1+lfoR)+3*c.depth2*(1+wave(phase2+c.phase,c.waveform2)));break;
    case 29:case 161:{
        delay[0].push(static_cast<float>(bounded((inL+inR)*.5+c.feedback*feedbackState[0])));
        static constexpr double fourPhases[]{0,.5,.25,.75};
        static constexpr double sixPhases[]{0,.5,1.0/6,4.0/6,2.0/6,5.0/6};
        outL=outR=0;
        for(int tap=0;tap<c.tapCount;++tap){
            const double movement=std::sin(2*pi*(phase+(c.tapCount==4?fourPhases[tap]:sixPhases[tap])));
            const double sample=delay[0].read(1+(c.tapTime[tap]+c.tapDepth[tap]*(1+movement))*sr*.001);
            if(!tap)feedbackState[0]=sample;
            const double angle=(c.tapPan[tap]+1)*pi*.25;
            outL+=sample*c.tapLevel[tap]*std::cos(angle);outR+=sample*c.tapLevel[tap]*std::sin(angle);
        }
        break;
    }
    case 30:case 31:{
        delay[0].push(static_cast<float>(inL));delay[1].push(static_cast<float>(inR));outL=outR=0;
        for(int channel=0;channel<2;++channel)for(int tap=0;tap<3;++tap){
            const double offset=static_cast<double>(tap)/3+channel*.17,base=2*pi*(phase+offset);
            const double movement=c.index==30?
                (std::sin(base)+.35*c.shimmer*std::sin(3*base+.7*std::sin(2*pi*phase2)))/(1+.35*c.shimmer):
                (std::sin(base)+.3*std::sin(2*pi*(phase2+offset)))/1.3;
            const double sample=delay[channel].read(1+((c.index==30?12:9)+7*c.depth*(1+movement))*sr*.001)/3;
            (channel?outR:outL)+=sample;
        }
        break;
    }
    case 32:case 33:
        outL=delayed(0,inL,c.delay[0]+3*c.depth*(1+lfoL));outR=delayed(1,inR,c.delay[1]+3*c.depth*(1+lfoR));break;
    case 34:case 37:{
        const double sweep=envelopeSweep();
        const double left=c.rangeBottom[0]+(c.rangeTop[0]-c.rangeBottom[0])*sweep;
        const double right=c.rangeBottom[1]+(c.rangeTop[1]-c.rangeBottom[1])*sweep;
        if(c.index==34){outL=delayed(0,inL,left);outR=delayed(1,inR,right);}
        else{outL=phaser(0,inL,left,true);outR=phaser(1,inR,right,true);}
        break;
    }
    case 35:case 36:outL=phaser(0,inL,lfoL);outR=phaser(1,inR,lfoR);break;
    case 38:outL=delayed(0,inL,2+2*c.depth*lfoL);outR=delayed(1,inR,2+2*c.depth*lfoL);break;
    case 39:
        outL=delayed(0,inL,c.delay[0]+6*c.depth*(1+lfoL));outR=delayed(1,inR,c.delay[1]+6*c.depth*(1+lfoR));break;
    case 41:{
        const double position=2*phase-1,distance=std::sqrt(position*position+.04);
        const double sample=delayed(0,(inL+inR)*.5,2+60*c.depth*distance)/(1+3*std::abs(position));
        const double angle=(std::clamp(position*c.spread,-1.0,1.0)+1)*pi*.25;
        outL=sample*std::cos(angle);outR=sample*std::sin(angle);break;
    }
    case 42:outL=outR=scratchEffect((inL+inR)*.5);break;
    case 43:granular(inL,inR,outL,outR,phase+frequency/sr>=1);break;
    case 44:outL=inL*(1-c.depth*(.5+.5*lfoL));outR=inR*(1-c.depth*(.5+.5*lfoR));break;
    case 45:{
        const double level=std::clamp(std::max(std::abs(inL),std::abs(inR))*c.envelopeSensitivity,0.0,1.0);
        envelope+=(level>envelope?envelopeAttack:envelopeRelease)*(level-envelope);
        const double shaped=(warp(2*envelope-1,c.envelopeShape)+1)*.5;
        frequency=std::clamp(c.frequency+c.envelopeFrequency*shaped,.02,20.0);
        const double depth=std::clamp(c.depth+c.envelopeDepth*shaped,0.0,1.0);
        outL=inL*(1-depth*(.5+.5*lfoL));outR=inR*(1-depth*(.5+.5*lfoR));break;
    }
    case 46:{
        const double leftAngle=c.depth*(1+lfoL)*pi*.25,rightAngle=(2-c.depth*(1-lfoR))*pi*.25;
        outL=inL*std::cos(leftAngle)+inR*std::cos(rightAngle);
        outR=inL*std::sin(leftAngle)+inR*std::sin(rightAngle);break;
    }
    case 47:{
        const double phaseL=std::sin(2*pi*phase),phaseR=std::sin(2*pi*(phase+(c.mode>=3?.5:0)));
        const double phasedL=mix(static_cast<float>(inL),static_cast<float>(phaser(0,inL,phaseL)),c.internalMix);
        const double phasedR=mix(static_cast<float>(inR),static_cast<float>(phaser(1,inR,phaseR)),c.internalMix);
        const int tremoloMode=c.mode%3;const double rightOffset=tremoloMode==1?.25:tremoloMode==2?.5:0;
        const double tremL=wave(phase+c.phase,1,c.shape),tremR=wave(phase+c.phase+rightOffset,1,c.shape);
        outL=phasedL*(1-c.depth2*(.5+.5*tremL));outR=phasedR*(1-c.depth2*(.5+.5*tremR));break;
    }
    case 48:{
        const double hz=std::clamp(c.frequency2*(1+c.depth*lfoL),0.0,sr*.45);
        carrierPhase=fraction(carrierPhase+hz/sr);const double carrier=std::sin(2*pi*carrierPhase);
        outL=inputLow[0].process(static_cast<float>(inL))*carrier;outR=inputLow[1].process(static_cast<float>(inR))*carrier;break;
    }
    case 49:case 50:case 51:case 162:case 163:
        pitchSmoothed+=smoothing*(c.pitchCents-pitchSmoothed);pitchEffect(inL,inR,outL,outR,pitchSmoothed);break;
    case 52:{
        pitchSmoothed+=smoothing*(c.pitchCents+c.pitchDepth*lfoL-pitchSmoothed);
        const double mono=(inL+inR)*.5,processed=shifted(0,mono,pitchSmoothed),angle=c.pan*pi*.5;
        // The diagram mixes the direct voice opposite the shifted voice.
        outL=processed*std::cos(angle)+mono*std::sin(angle);outR=processed*std::sin(angle)+mono*std::cos(angle);break;
    }
    case 53:outL=scanner(0,inL*c.inputGain);outR=scanner(1,inR*c.inputGain);break;
    case 54:case 164:case 207:rotary(inL,inR,dryL,dryR,outL,outR);break;
    case 173:
        vibeLfo+=envelopeRelease*(std::sin(2*pi*phase)+.2*std::sin(4*pi*phase)-vibeLfo);
        outL=mix(static_cast<float>(inL),static_cast<float>(phaser(0,inL,std::clamp(vibeLfo,-1.0,1.0))),c.internalMix);
        outR=mix(static_cast<float>(inR),static_cast<float>(phaser(1,inR,std::clamp(vibeLfo,-1.0,1.0))),c.internalMix);break;
    case 174:case 175:outL=phaser(0,inL,std::sin(2*pi*phase));outR=phaser(1,inR,std::sin(2*pi*phase));break;
    case 176:{
        const double mono=(inL+inR)*.5,center=(4+14*c.manual)*(1-c.depth)+12*c.depth;
        const double processed=delayed(0,mono,center+10*c.depth*std::sin(2*pi*phase));
        outL=c.outputMode==0?processed:mono;outR=processed;break;
    }
    case 177:{
        const double mono=(inL+inR)*.5,center=(.2+8*c.manual)*(1-c.depth)+6*c.depth;
        outL=outR=delayed(0,mono,center+5.5*c.depth*std::sin(2*pi*phase));break;
    }
    case 178:outL=inL*(1-c.depth*(.5+.5*lfoL))*c.level;outR=inR*(1-c.depth*(.5+.5*lfoR))*c.level;break;
    case 189:{
        const double mono=(inL+inR)*.5;
        for(int channel=0;channel<2;++channel){
            const double input=(c.outputMode==1?(channel?inR:inL):mono)*c.inputGain;
            const double movement=std::sin(2*pi*(phase+(channel&&c.outputMode==1?.25:0)));
            double output;
            if(c.mode==0){const double chorus=delayed(channel,input,8+6*c.depth*c.depth2*(1+movement));output=input*(1-.5*c.depth)+chorus*.5*c.depth;}
            else if(c.mode==1)output=delayed(channel,input,4+3.8*c.depth*c.depth2*movement);
            else{const double flange=delayed(channel,input,.4+3*c.depth2*(1+movement));output=.5*(input+flange);}
            (channel?outR:outL)=output;
        }
        break;
    }
    default:break;
    }
    const double nextPhase=phase+frequency/sr;if(nextPhase>=1)++cycles;phase=fraction(nextPhase);
    phase2=fraction(phase2+c.frequency2/sr);stepPhase=fraction(stepPhase+c.stepFrequency/sr);++controlCounter;
    const double effectiveWet=wetSmoothed*((c.index==34||c.index==37)?controlGate:1.0);
    resultL=finite(mix(static_cast<float>(bounded(dryL)),static_cast<float>(bounded(outL)),effectiveWet));
    resultR=finite(mix(static_cast<float>(bounded(dryR)),static_cast<float>(bounded(outR)),effectiveWet));
}

NumberedModFx::NumberedModFx()=default;
NumberedModFx::~NumberedModFx()=default;
NumberedModFx::NumberedModFx(NumberedModFx&&) noexcept=default;
NumberedModFx& NumberedModFx::operator=(NumberedModFx&&) noexcept=default;

void NumberedModFx::prepare(double sampleRate,float* workspace,std::size_t samples) {
    if(!impl_)impl_=std::make_unique<Impl>();
    auto& p=*impl_;p.sr=boundedRate(sampleRate);p.workspace=workspace;p.workspaceSamples=samples;
    p.prepared=p.enabled=false;
    // Both long delay lines are independent; the two short lines contain the
    // dual-head pitch shifters. The same storage is borrowed by Grain Shifter,
    // which is never processed concurrently with a delay/pitch algorithm.
    const double longCount=std::ceil(p.sr*5.3)+4,shortCount=std::ceil(p.sr*.3)+8;
    if(!workspace||!std::isfinite(longCount)||!std::isfinite(shortCount)||
       longCount<3||shortCount<3||2*(longCount+shortCount)>static_cast<double>(samples))return;
    const auto longSize=static_cast<std::size_t>(longCount),shortSize=static_cast<std::size_t>(shortCount);
    p.delay[0].attach(workspace,longSize);p.delay[1].attach(workspace+longSize,longSize);
    p.pitch[0].attach(workspace+2*longSize,shortSize);p.pitch[1].attach(workspace+2*longSize+shortSize,shortSize);
    p.grainCapacity=static_cast<std::size_t>(std::ceil(p.sr*.25))+4;
    if(p.grainCapacity>samples/4)return;
    for(int bank=0;bank<2;++bank)for(int channel=0;channel<2;++channel)
        p.grain[bank][channel]=workspace+(bank*2+channel)*p.grainCapacity;
    const auto scratchSize=static_cast<std::size_t>(std::floor(p.sr*2.730));
    if(scratchSize<3||scratchSize>samples)return;
    p.scratch.attach(workspace,scratchSize);
    p.prepared=true;p.reset();
}
void NumberedModFx::reset() noexcept {if(impl_)impl_->reset();}
void NumberedModFx::configure(const NumberedFxState& state) noexcept {if(impl_)impl_->configure(state);}
void NumberedModFx::setControlFrame(const NumberedFxControlFrame& frame) noexcept {if(impl_)impl_->setControlFrame(frame);}
void NumberedModFx::process(float inL,float inR,float& outL,float& outR) noexcept {
    if(impl_)impl_->process(inL,inR,outL,outR);else{outL=finite(inL);outR=finite(inR);}
}

} // namespace silveton::sampler
