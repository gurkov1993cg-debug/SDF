// Included only by SourceEffects.cpp inside its anonymous namespace.
// Parameter layout, semantic conversion, slot ownership and DSP execution
// are distinct stages. Preserve the original bytes throughout all stages.

unsigned sourceFxBits(const std::array<std::uint8_t,64>& bytes,
                      unsigned first,unsigned width) noexcept {
    unsigned value=0;
    for(unsigned bit=0;bit<width;++bit)
        value|=static_cast<unsigned>((bytes[(first+bit)/8U]>>((first+bit)%8U))&1U)<<bit;
    return value;
}

int sourceFxSignedBits(const std::array<std::uint8_t,64>& bytes,
                       unsigned first,unsigned width) noexcept {
    const auto value=sourceFxBits(bytes,first,width);
    return (value&(1U<<(width-1U)))!=0U?
        static_cast<int>(static_cast<std::int64_t>(value)-(std::int64_t{1}<<width)):
        static_cast<int>(value);
}

bool sourceFxTailIsZero(const std::array<std::uint8_t,64>& bytes,unsigned first) noexcept {
    for(unsigned bit=first;bit<512U;++bit)
        if(((bytes[bit/8U]>>(bit%8U))&1U)!=0U)return false;
    return true;
}

#include "SourceEffectsWire.inc"

bool translateSourceEffect(const KorgSourceFxDefinition& source,EffectSlot& out,
                           SourceFxSlotStatus& status,SourceFxRenderParameters& render) {
    out={};render={};status.status=SourceFxStatus::Unsupported;
    if(source.selector==0U){
        status.status=SourceFxStatus::Off;status.detail="Off in source";return false;
    }
    if(source.kind!=arranger::KorgSourceFxKind::Master){
        status.detail="Original insert execution is not implemented";return false;
    }
    if((source.controlsKnownMask&1U)==0U){
        status.detail="Original master activation control is unavailable";return false;
    }
    if(source.controlsRaw[0]==0U){
        status.status=SourceFxStatus::Off;
        status.detail="Inactive master convention from original records; saved parameters retained";
        return false;
    }
    if(source.controlsRaw[0]!=1U){
        status.detail="Unrecognized original master activation control";return false;
    }
    if((source.controlsKnownMask&2U)==0U||source.controlsRaw[1]!=0U){
        status.detail="Original inter-effect routing is not established; decoded values retained";return false;
    }
    if(!status.parameterLayoutKnown||!status.parameterBlockValid||!status.parametersComplete){
        status.detail=status.parameterDetail;return false;
    }
    if(source.selector==34U||source.selector==37U||source.selector==42U){
        status.detail="Saved parameters decoded; the original effect controller owner is not connected";
        return false;
    }
    if(!numberedFxCanRender(status.decoded)){
        status.detail="Saved parameters decoded; original modulation or selected mode is not supported by the renderer";
        return false;
    }
    render.active=true;render.numbered=status.decoded;
    // Only the decoded numbered processor handles the signal, including its
    // own Wet/Dry. No manual preset is assigned to the independent SVNF rack.
    out.wet=numberedFxWet(status.decoded);
    out.tempoSync=false;
    if(source.selector>=70U&&source.selector<=75U){
        // Keep the historical native reverb summary for explicit manual-rack
        // detachment. It does not run alongside the original numbered effect.
        const bool room=source.selector>=74U;
        const auto get=[&](const char* row){
            const auto* p=findNumberedFxParam(source.selector,row);
            return p&&status.decoded.known(p->ordinal)?status.decoded.values[p->ordinal]:0.0;
        };
        out.type=room?EffectType::Room:(source.selector>=72U?EffectType::Reverb:EffectType::Hall);
        render.reverbSeconds=static_cast<float>(get("a_1"));
        out.preDelayMs=static_cast<float>(get("b_1"));
        out.damping=static_cast<float>(get("a_2")*.01);
        out.feedback=0.95F*std::log(std::clamp(render.reverbSeconds,0.6F,12.0F)/0.6F)/std::log(20.0F);
        render.preDelayThru=static_cast<float>(get("b_2")*.01);
        render.inputTrim=static_cast<float>(get(room?"e_1":"c_1")*.01);
        render.earlyLevel=room?static_cast<float>(get("c_1")*.01):1.0F;
        render.reverbLevel=room?static_cast<float>(get("d_1")*.01):1.0F;
    }
    status.detail="Original saved parameters applied to SILVETON FX #"+
        std::to_string(source.selector)+"; "+status.parameterDetail;
    return true;
}
