#include "silveton/sampler/SourceEffects.h"
#include "silveton/arranger/Pa5xEffectCatalog.h"
#include "silveton/arranger/Pa5xSoundGraph.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <tuple>

namespace silveton::sampler {
namespace {
using arranger::KorgSourceEffects;
using arranger::KorgSourceFxDefinition;
using arranger::KorgSourceFxEncoding;
using arranger::KorgSourceFxKind;
using arranger::KorgSourceFxScope;

#include "SourceEffectsDecode.inc"

bool sameDefinition(const KorgSourceFxDefinition& a,const KorgSourceFxDefinition& b) {
    return a.kind==b.kind&&a.ownerRaw==b.ownerRaw&&a.slotRaw==b.slotRaw&&
        a.selector==b.selector&&a.controlsRaw==b.controlsRaw&&
        a.controlsKnownMask==b.controlsKnownMask&&a.parameters==b.parameters;
}
struct Candidate {
    KorgSourceFxDefinition value;
    int logicalPart{-1};
    bool ambiguous{false},late{false},invalid{false};
};
constexpr std::size_t kMaximumProfiles=128;
constexpr std::size_t kMaximumStoredSourceFxBytes=16U*1024U*1024U;
constexpr std::size_t kMaximumStoredDefinitions=16384;
constexpr std::size_t kMaximumStoredEvents=65536;

struct BytesWriter {
    std::vector<std::uint8_t> bytes;
    void raw(const std::uint8_t* p,std::size_t n) {
        if(n>kMaximumStoredSourceFxBytes-bytes.size())throw std::runtime_error("Original effects are too large to save");
        if(n)bytes.insert(bytes.end(),p,p+n);
    }
    void u8(unsigned n){const auto b=static_cast<std::uint8_t>(n);raw(&b,1);}
    void u16(unsigned n){u8(n&255U);u8((n>>8U)&255U);}
    void u32(std::uint32_t n){for(unsigned i=0;i<4;++i)u8((n>>(i*8U))&255U);}
    void u64(std::uint64_t n){u32(static_cast<std::uint32_t>(n));u32(static_cast<std::uint32_t>(n>>32U));}
    void text(const std::string& s){if(s.size()>4096U)throw std::runtime_error("Original effect text is too long");u16(static_cast<unsigned>(s.size()));raw(reinterpret_cast<const std::uint8_t*>(s.data()),s.size());}
};
struct BytesReader {
    const std::vector<std::uint8_t>& bytes;
    std::size_t at{0};
    void raw(std::uint8_t* p,std::size_t n){if(n>bytes.size()-at)throw std::runtime_error("Truncated original effects");if(n)std::copy_n(bytes.data()+at,n,p);at+=n;}
    unsigned u8(){std::uint8_t n=0;raw(&n,1);return n;}
    unsigned u16(){const auto a=u8(),b=u8();return a|(b<<8U);}
    std::uint32_t u32(){std::uint32_t n=0;for(unsigned i=0;i<4;++i)n|=static_cast<std::uint32_t>(u8())<<(i*8U);return n;}
    std::uint64_t u64(){const auto a=u32(),b=u32();return a|(static_cast<std::uint64_t>(b)<<32U);}
    int signedRaw(){const auto n=u32();return n<=0x7FFFFFFFU?static_cast<int>(n):static_cast<int>(static_cast<std::int64_t>(n)-0x100000000LL);}
    bool flag(){const auto n=u8();if(n>1)throw std::runtime_error("Invalid original effect flag");return n!=0;}
    int optional(){const auto n=u8();return n==255U?-1:static_cast<int>(n);}
    std::string text(){const auto n=u16();if(n>4096U)throw std::runtime_error("Original effect text is too long");std::string s(n,'\0');raw(reinterpret_cast<std::uint8_t*>(s.data()),n);if(s.find('\0')!=std::string::npos)throw std::runtime_error("Invalid original effect text");return s;}
};
} // namespace

SourceFxSlotStatus inspectSoundEffectParameters(const arranger::Pa5xSoundFxRecordRaw& record) {
    SourceFxSlotStatus status;status.soundRecord=true;status.master=false;
    status.slot=record.recordIndex;status.ownerRaw=-1;status.part=-1;
    status.detail="Sound FX record retained; activation, IFX/MFX ownership and routing are not established. Keyboard Set/Style effects remain the active owner.";
    if(record.recordIndex>=6U||(record.recordBytes!=66U&&record.recordBytes!=67U)||
       record.trailingControlPresent!=(record.recordBytes==67U)||
       !record.selectorDecoded||record.leadingRaw!=0U||record.selector!=record.selectorLowRaw) {
        status.selectorKnown=false;
        status.name="Sound FX: unknown selector";
        status.parameterDetail="Original selector representation is not established; both raw selector bytes are retained";
        return status;
    }
    status.selector=record.selector;
    const auto* identity=arranger::findPa5xEffect(record.selector);
    status.name=identity?identity->firmwareName:"Korg FX #"+std::to_string(record.selector);
    if(identity)status.functionBg=identity->functionBg;
    if(record.selector==0U) {
        status.parameterDetail="Zero selector in the Sound record; saved control bytes and slot assignment remain separate";
        return status;
    }
    if(!identity) {
        status.parameterDetail="Original index is absent from the Pa5X production FX catalog; source retained";
        return status;
    }
    // Parameter-only entry point: no invented SysEx/profile/owner is needed.
    // The same bounded bit decoder serves PCG, PRF and KSC source parameters.
    decodeSourceParameterBlock(record.selector,record.parameters,status);
    return status;
}

std::string SourceEffectsState::summary() const {
    unsigned applied=0,unsupported=0,off=0;
    for(const auto& s:slots){if(s.status==SourceFxStatus::Applied)++applied;else if(s.status==SourceFxStatus::Unsupported)++unsupported;else ++off;}
    std::ostringstream out;out<<"SET FX: "<<applied<<" applied / "<<unsupported<<" unsupported";
    if(off)out<<" / "<<off<<" off";
    if(applied)out<<" — SILVETON DSP translation";
    if(!note.empty())out<<". "<<note;
    return out.str();
}

void applySourceEffects(Combi& combi,
        const std::vector<std::shared_ptr<const KorgSourceEffects>>& profiles,
        const std::array<int,8>& logicalToSampler,bool style) {
    if(profiles.empty()){combi.sourceEffects.reset();return;}
    auto state=std::make_shared<SourceEffectsState>();state->style=style;
    state->followMidiSends=style;state->logicalToSampler=logicalToSampler;
    // A new original owner must not inherit an old owner's effects. Its sample
    // graph, part EQ, level, pan and keyboard split are deliberately untouched.
    combi.fx={};combi.fxRouting=EffectRouting::Parallel;
    // Restoring the original whole-owner rack also leaves the separate manual
    // numbered namespace. Extra SILVETON parts have no original Pa assignment;
    // keeping a hidden numbered insert there would create mixed provenance.
    for(int part=0;part<kPartCount;++part){
        auto& effect=combi.insertOf(part);effect.numbered={};effect.numberedModulatingPart=-1;
    }
    for(int part:logicalToSampler)if(part>=0&&part<kPartCount)combi.insertOf(part)={};
    std::map<std::tuple<int,int,int,int>,Candidate> candidates;
    std::array<int,kPartCount> dry{};dry.fill(-1);
    std::array<std::array<int,3>,kPartCount> sends{};
    for(auto& part:sends)part.fill(-1);
    bool invalid=false,unknown=false;
    for(const auto& profile:profiles){
        if(!profile)continue;
        if(state->profiles.size()>=kMaximumProfiles){invalid=true;break;}
        state->profiles.push_back(profile);
        if(!profile->valid()||!profile->complete){invalid=true;continue;}
        if(profile->unrecognizedFxMessages)unknown=true;
        const bool master=profile->scope==KorgSourceFxScope::KeyboardMaster||profile->scope==KorgSourceFxScope::StyleMaster;
        const bool expectedScope=style?(profile->scope==KorgSourceFxScope::StyleMaster||profile->scope==KorgSourceFxScope::StyleTrack):
            (profile->scope==KorgSourceFxScope::KeyboardMaster||profile->scope==KorgSourceFxScope::KeyboardPart);
        if(!expectedScope){invalid=true;continue;}
        int part=-1;
        if(profile->logicalPart>=0&&profile->logicalPart<8)part=logicalToSampler[static_cast<std::size_t>(profile->logicalPart)];
        if(!master&&(part<0||part>=kPartCount)){invalid=true;continue;}
        if(part>=0){
            auto& d=dry[static_cast<std::size_t>(part)];
            if(profile->rawDryOff>=0){if(d==-1)d=profile->rawDryOff;else if(d!=profile->rawDryOff)d=-2;}
            if(!style){
                std::array<int,3> local{{-1,-1,-1}};std::array<int,3> channels{{-1,-1,-1}};
                for(const auto& send:profile->sends){
                    const auto slot=static_cast<std::size_t>(send.slot);
                    if(channels[slot]==-1)channels[slot]=send.channel;
                    else if(channels[slot]!=send.channel){local[slot]=-2;continue;}
                    if(local[slot]!=-2)local[slot]=send.value;
                }
                for(std::size_t s=0;s<3;++s){
                    auto& v=sends[static_cast<std::size_t>(part)][s];
                    if(local[s]==-2)v=-2;else if(local[s]>=0){if(v==-1)v=local[s];else if(v!=local[s])v=-2;}
                }
            }
        }
        for(const auto& def:profile->definitions){
            const int kind=static_cast<int>(def.kind);
            const auto key=std::make_tuple(kind,part,static_cast<int>(def.ownerRaw),static_cast<int>(def.slotRaw));
            auto found=candidates.find(key);
            if(found==candidates.end())found=candidates.emplace(key,Candidate{def,profile->logicalPart,false,false,false}).first;
            auto& c=found->second;
            if(!sameDefinition(c.value,def))c.ambiguous=true;
            // Only an initial declaration can configure a static rack. Future
            // event/section changes stay visible; never flatten them to first.
            if(def.tick!=0||def.physicalTrack!=0)c.late=true;
            if((def.kind==KorgSourceFxKind::Master)!=master&&def.kind!=KorgSourceFxKind::Unscoped)c.invalid=true;
            if(def.kind==KorgSourceFxKind::Master&&def.ownerRaw!=(style?0U:1U))c.invalid=true;
        }
    }
    for(int part:logicalToSampler)if(part>=0&&part<kPartCount){
        const auto p=static_cast<std::size_t>(part);
        state->dryOff[p]=dry[p]==1;
        if(dry[p]==-2)unknown=true;
        if(!style){
            auto& u=combi.part(part);
            float* values[3]{&u.fxSend1,&u.fxSend2,&u.fxSend3};
            for(std::size_t s=0;s<3;++s){if(sends[p][s]>=0)*values[s]=static_cast<float>(sends[p][s])/127.0F;else if(sends[p][s]==-2)unknown=true;}
        }
    }
    std::array<bool,3> masterOccupied{};
    for(const auto& item:candidates){
        const auto& c=item.second;const auto& def=c.value;
        SourceFxSlotStatus status;status.master=def.kind==KorgSourceFxKind::Master;
        status.part=std::get<1>(item.first);status.ownerRaw=def.ownerRaw;status.slot=def.slotRaw;status.selector=def.selector;
        const auto* identity=arranger::findPa5xEffect(def.selector);
        status.name=identity?identity->firmwareName:"Korg FX #"+std::to_string(def.selector);
        if(identity)status.functionBg=identity->functionBg;
        // Decode settings independently of audio placement. An IFX whose
        // pre-fader binding is pending can still show its actual saved values.
        // Changing/ambiguous definitions never become a chosen first state.
        if(identity&&def.selector!=0&&!c.ambiguous&&!c.late)
            decodeSourceEffectParameters(def,status);
        if(c.invalid){status.detail="Source owner or scope is not supported";}
        else if(c.ambiguous||c.late){status.detail="Original definitions change by section/CV/time; retained, not flattened";}
        else if(def.selector==0){status.status=SourceFxStatus::Off;status.detail="Off in source";}
        else if(!identity){status.detail="Original index is absent from the Pa5X production FX catalog; source retained";}
        else if(def.kind!=KorgSourceFxKind::Unscoped&&(status.slot<0||status.slot>2)){
            status.detail="Original effect slot number is not mapped; source retained";
        }
        else if(def.kind!=KorgSourceFxKind::Unscoped&&
                !arranger::pa5xEffectAllowed(*identity,status.master,status.slot)){
            status.detail=std::string("Pa5X placement restriction: ")+arranger::pa5xEffectSlotRuleText(identity->slotRule);
            if(identity->slotDocumentationConflict)status.detail+="; stricter manual restriction retained";
        }
        else if(!status.master){status.detail=def.kind==KorgSourceFxKind::Unscoped?
            "Original PRF insert binding is not established":"Original insert chain is retained; pre-fader execution is not implemented";}
        else if(status.slot<0||status.slot>2||masterOccupied[static_cast<std::size_t>(status.slot)]){status.detail="Ambiguous original master slot";}
        else {
            const auto s=static_cast<std::size_t>(status.slot);masterOccupied[s]=true;
            EffectSlot prepared;SourceFxRenderParameters render;
            if(translateSourceEffect(def,prepared,status,render)){
                combi.fx[s]=prepared;state->masterRender[s]=render;
                status.status=SourceFxStatus::Applied;
            }
        }
        state->slots.push_back(std::move(status));
    }
    if(invalid)state->note="Some original FX resources are incomplete or invalid";
    if(unknown){if(!state->note.empty())state->note+="; ";state->note+="additional original routing/control data is retained but unsupported";}
    combi.sourceEffects=std::move(state);
}

std::vector<std::uint8_t> encodeSourceEffects(const SourceEffectsState& state) {
    if(state.profiles.empty()||state.profiles.size()>kMaximumProfiles)throw std::runtime_error("Invalid original effect profile count");
    BytesWriter w;w.u32(1);w.u8(state.style?1U:0U);
    for(int p:state.logicalToSampler){if(p < -1||p>=kPartCount)throw std::runtime_error("Invalid original effect part map");w.u8(static_cast<unsigned>(p));}
    w.u16(static_cast<unsigned>(state.profiles.size()));
    std::size_t definitions=0,events=0;
    for(const auto& ptr:state.profiles){
        if(!ptr||!ptr->valid())throw std::runtime_error("Invalid original effect profile");const auto& p=*ptr;
        definitions+=p.definitions.size();events+=p.sends.size()+p.unknownMessages.size();
        if(definitions>kMaximumStoredDefinitions||events>kMaximumStoredEvents)throw std::runtime_error("Original effect event limit exceeded");
        w.u8(static_cast<unsigned>(p.scope));w.text(p.resourcePath);w.u8(static_cast<unsigned>(p.logicalPart));w.u8(static_cast<unsigned>(p.element));
        w.u32(static_cast<std::uint32_t>(p.rawFxGroup));w.u32(static_cast<std::uint32_t>(p.rawDryOff));w.u16(p.ppq);
        w.u8(p.setupBoundaryKnown?1U:0U);w.u32(p.setupTicks);w.u8(p.complete?1U:0U);w.text(p.error);
        w.u32(static_cast<std::uint32_t>(p.malformedFxMessages));w.u32(static_cast<std::uint32_t>(p.unrecognizedFxMessages));
        w.u16(static_cast<unsigned>(p.definitions.size()));
        for(const auto& d:p.definitions){
            w.u8(static_cast<unsigned>(d.kind));w.u8(static_cast<unsigned>(d.encoding));w.u8(d.ownerRaw);w.u8(d.slotRaw);w.u16(d.selector);
            w.raw(d.controlsRaw.data(),d.controlsRaw.size());w.u8(d.controlsKnownMask);w.raw(d.parameters.data(),d.parameters.size());w.raw(d.payload.data(),d.payload.size());
            w.u16(static_cast<unsigned>(d.originalRecord.size()));w.raw(d.originalRecord.data(),d.originalRecord.size());w.u32(d.tick);w.u16(d.physicalTrack);w.u64(d.order);
        }
        w.u16(static_cast<unsigned>(p.sends.size()));
        for(const auto& s:p.sends){w.u32(s.tick);w.u16(s.physicalTrack);w.u64(s.order);w.u8(s.channel);w.u8(s.slot);w.u8(s.value);}
        w.u16(static_cast<unsigned>(p.unknownMessages.size()));
        for(const auto& e:p.unknownMessages){w.u32(e.tick);w.u16(e.track);w.u8(e.status);w.u8(e.metaType);w.u64(e.order);w.u32(static_cast<std::uint32_t>(e.payload.size()));w.raw(e.payload.data(),e.payload.size());}
    }
    return std::move(w.bytes);
}

bool decodeSourceEffects(const std::vector<std::uint8_t>& bytes,Combi& combi,std::string& error) {
    try {
        if(bytes.empty()||bytes.size()>kMaximumStoredSourceFxBytes)throw std::runtime_error("Invalid original effect extension size");
        BytesReader r{bytes};if(r.u32()!=1)throw std::runtime_error("Unsupported original effect extension version");
        const bool style=r.flag();std::array<int,8> map{};
        for(auto& p:map){p=r.optional();if(p>=kPartCount)throw std::runtime_error("Invalid original effect part map");}
        const auto count=r.u16();if(count==0||count>kMaximumProfiles)throw std::runtime_error("Invalid original effect profile count");
        std::vector<std::shared_ptr<const KorgSourceEffects>> profiles;profiles.reserve(count);
        std::size_t definitions=0,events=0;
        for(unsigned i=0;i<count;++i){
            auto p=std::make_shared<KorgSourceEffects>();p->scope=static_cast<KorgSourceFxScope>(r.u8());p->resourcePath=r.text();p->logicalPart=r.optional();p->element=r.optional();
            p->rawFxGroup=r.signedRaw();p->rawDryOff=r.signedRaw();p->ppq=static_cast<std::uint16_t>(r.u16());p->setupBoundaryKnown=r.flag();p->setupTicks=r.u32();p->complete=r.flag();p->error=r.text();
            p->malformedFxMessages=r.u32();p->unrecognizedFxMessages=r.u32();
            const auto n=r.u16();definitions+=n;if(n>arranger::kMaximumKorgSourceFxDefinitions||definitions>kMaximumStoredDefinitions)throw std::runtime_error("Original effect definition limit exceeded");
            p->definitions.resize(n);
            for(auto& d:p->definitions){
                d.kind=static_cast<KorgSourceFxKind>(r.u8());d.encoding=static_cast<KorgSourceFxEncoding>(r.u8());d.ownerRaw=static_cast<std::uint8_t>(r.u8());d.slotRaw=static_cast<std::uint8_t>(r.u8());d.selector=static_cast<std::uint16_t>(r.u16());
                r.raw(d.controlsRaw.data(),d.controlsRaw.size());d.controlsKnownMask=static_cast<std::uint8_t>(r.u8());r.raw(d.parameters.data(),d.parameters.size());r.raw(d.payload.data(),d.payload.size());
                const auto raw=r.u16();if(raw>78U)throw std::runtime_error("Invalid original PRF effect size");d.originalRecord.resize(raw);r.raw(d.originalRecord.data(),raw);d.tick=r.u32();d.physicalTrack=static_cast<std::uint16_t>(r.u16());d.order=r.u64();
            }
            const auto sendCount=r.u16();events+=sendCount;if(sendCount>arranger::kMaximumKorgSourceFxSends||events>kMaximumStoredEvents)throw std::runtime_error("Original effect-send limit exceeded");
            p->sends.resize(sendCount);for(auto& s:p->sends){s.tick=r.u32();s.physicalTrack=static_cast<std::uint16_t>(r.u16());s.order=r.u64();s.channel=static_cast<std::uint8_t>(r.u8());s.slot=static_cast<std::uint8_t>(r.u8());s.value=static_cast<std::uint8_t>(r.u8());}
            const auto opaque=r.u16();events+=opaque;if(opaque>arranger::kMaximumKorgSourceFxOpaqueEvents||events>kMaximumStoredEvents)throw std::runtime_error("Original effect-message limit exceeded");
            p->unknownMessages.resize(opaque);std::size_t total=0;
            for(auto& e:p->unknownMessages){e.tick=r.u32();e.track=static_cast<std::uint16_t>(r.u16());e.status=static_cast<std::uint8_t>(r.u8());e.metaType=static_cast<std::uint8_t>(r.u8());e.order=r.u64();const auto length=r.u32();
                if(length>arranger::kMaximumKorgSourceFxOpaqueBytes-total)throw std::runtime_error("Original opaque effect data is too large");total+=length;e.payload.resize(length);r.raw(e.payload.data(),length);}
            if(!p->valid())throw std::runtime_error("Invalid original effect profile content");profiles.push_back(std::move(p));
        }
        if(r.at!=bytes.size())throw std::runtime_error("Trailing original effect extension data");
        applySourceEffects(combi,profiles,map,style);return true;
    }catch(const std::exception& e){error=e.what();return false;}
}
} // namespace silveton::sampler
