#include "silveton/sampler/NumberedToneFx.h"
#include "silveton/sampler/NumberedFxKernel.h"
#include "silveton/sampler/NumberedSixBandEq.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <initializer_list>
#include <utility>

namespace silveton::sampler {
namespace {
namespace nf = numbered_fx;
using Filter = nf::Biquad;
using FilterType = Filter::Type;
constexpr double pi = nf::pi;

bool toneIndex(std::uint16_t index) noexcept {
    switch (index) {
    case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13:
    case 14: case 15: case 16: case 17: case 18: case 19: case 20: case 21:
    case 22: case 23: case 24: case 25: case 40: case 155: case 156: case 157:
    case 158: case 159: case 160: case 172: case 184: case 185: case 186: case 187:
    case 188: case 190: case 193: case 195: case 196: case 197: case 198:
    case 208: case 210: return true;
    default: return false;
    }
}

bool ampMenuMatches(std::uint16_t index) noexcept {
    // These two multiword model names were once split by the text extractor.
    // Refuse a mismatched semantic menu instead of clamping a valid-looking
    // enumerator onto another model and silently changing the user's choice.
    static constexpr const char* bass[]{"LA STUDIO","JAZZ","GOLD PANEL","SCOOPED","VALVE2","VALVE","CLASSIC"};
    static constexpr const char* tube[]{"STUDIO COMBO","VOX AC100","UK MAJOR"};
    const char* const* expected=nullptr;std::size_t count=0;
    if(index==21||index==22){expected=bass;count=7;}
    else if(index==159){expected=tube;count=3;}
    else return true;
    const auto* parameter=findNumberedFxParam(index,"a_1");
    if(!parameter||parameter->choiceCount!=count)return false;
    for(std::size_t i=0;i<count;++i)
        if(std::strcmp(parameter->choices[i].label,expected[i])!=0||parameter->choices[i].value!=static_cast<double>(i))return false;
    return true;
}

struct FixedRow { std::uint16_t index; const char* row; double value; };
// Inactive external controls are fixed in the state, not just hidden by the UI.
// The graphical note-menu Reference rows stay unknown. Sync is consequently
// Off; a guessed note value or a guessed owner note/pedal is never substituted.
constexpr FixedRow fixedRows[] = {
    {9,"d_3",0},{9,"e_3",0},{9,"f_3",0},
    {10,"e_1",0},{10,"e_2",120},{10,"e_4",1},
    {11,"g_1",0},{11,"g_2",120},{11,"g_4",1},
    {12,"d_1",0},{12,"d_2",120},{12,"d_4",1},{12,"e_2",1},
    {13,"c_3",0},{13,"f_1",0},{13,"f_2",120},{13,"f_4",1},
    {14,"a_1",1},{14,"b_1",0},{14,"b_2",0},
    {15,"h_1",0},{15,"h_2",120},{15,"h_4",1},
    {16,"d_1",0},{16,"d_2",120},{16,"d_4",1},
    {18,"b_1",0},
    {40,"c_1",0},{40,"c_2",120},{40,"c_4",1},
    {155,"b_1",0},{156,"c_1",0},{157,"b_1",0},{208,"d_4",0}
};

double amplitude(double gainDb) noexcept {
    return gainDb <= kNumberedFxChoiceBase ? 0.0 : nf::db(gainDb);
}
double unit(double v) noexcept { return std::clamp(v * .01, 0.0, 1.0); }
double safeSample(double v) noexcept {
    return std::isfinite(v) ? std::clamp(v, -1.e6, 1.e6) : 0.0;
}
double timeCoefficient(double ms, double sr) noexcept {
    return std::exp(-1.0 / (std::max(.02, ms) * .001 * sr));
}
double logScale(double position, double low, double high) noexcept {
    return low * std::pow(high / low, std::clamp(position, 0.0, 1.0));
}
double shaped(double position, double shape) noexcept {
    return std::pow(std::clamp(position, 0.0, 1.0), std::exp2(-shape * .02));
}
double wrap(double phase) noexcept { return phase - std::floor(phase); }
double sine(double phase) noexcept { return std::sin(2.0 * pi * wrap(phase)); }
double triangle(double phase) noexcept { return 1.0 - 4.0 * std::abs(wrap(phase) - .5); }

std::uint32_t hash(std::uint32_t x) noexcept {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15;
    x *= 0x846ca68bU; x ^= x >> 16; return x;
}
double randomValue(std::uint32_t& seed) noexcept {
    seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
    return static_cast<double>(seed) / 2147483648.0 - 1.0;
}

// A topology-preserving state variable filter for genuinely moving wah/filter
// coefficients. Coefficients update on a bounded 16-sample control grid; the
// audio loop never performs a descriptor lookup or heap allocation.
struct MovingFilter {
    double g{0}, k{1.4142135623730951}, a1{1}, a2{0}, a3{0}, ic1{0}, ic2{0};
    void reset() noexcept { ic1 = ic2 = 0; }
    void set(double sr, double hz, double q) noexcept {
        g = std::tan(pi * std::clamp(hz, 5.0, sr * .45) / sr);
        k = 1.0 / std::clamp(q, .4, 30.0);
        a1 = 1.0 / (1.0 + g * (g + k)); a2 = g * a1; a3 = g * a2;
    }
    double process(double x, int type) noexcept {
        const double v3 = x - ic2;
        const double bp = a1 * ic1 + a2 * v3;
        const double lp = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0 * bp - ic1; ic2 = 2.0 * lp - ic2;
        if (!std::isfinite(ic1) || !std::isfinite(ic2) ||
            std::abs(ic1) > 1.e9 || std::abs(ic2) > 1.e9) { reset(); return 0; }
        if (std::abs(ic1) < 1.e-25) ic1 = 0;
        if (std::abs(ic2) < 1.e-25) ic2 = 0;
        const double hp = x - k * bp - lp;
        switch (type) {
        case 1: return hp;
        case 2: return bp * k; // Constant peak gain, including high resonance.
        case 3: return lp + hp;
        default: return lp;
        }
    }
};

struct ThreeBand {
    std::array<Filter,2> low{}, high{}, middle{}, upper{};
    Filter phase;
    void set(double sr, double lower, double higher) noexcept {
        for (auto& f : low) f.configure(FilterType::LowPass,sr,lower);
        for (auto& f : high) f.configure(FilterType::HighPass,sr,lower);
        for (auto& f : middle) f.configure(FilterType::LowPass,sr,higher);
        for (auto& f : upper) f.configure(FilterType::HighPass,sr,higher);
        phase.configure(FilterType::LowPass,sr,higher);
        phase.b0 = phase.a2; phase.b1 = phase.a1; phase.b2 = 1;
    }
    void reset() noexcept {
        for (auto& f : low) f.reset(); for (auto& f : high) f.reset();
        for (auto& f : middle) f.reset(); for (auto& f : upper) f.reset(); phase.reset();
    }
    double process(double x, const std::array<double,3>& gains) noexcept {
        const float in = static_cast<float>(x);
        const float lo = phase.process(low[1].process(low[0].process(in)));
        const float hi = high[1].process(high[0].process(in));
        return lo*gains[0] + middle[1].process(middle[0].process(hi))*gains[1] +
               upper[1].process(upper[0].process(hi))*gains[2];
    }
};

// Four substeps reduce aliasing of our nonlinear stages. Linear interpolation
// supplies the substeps; a fourth-order low-pass precedes decimation. This is
// an explicit own design, not a circuit-identical tube or transistor model.
struct Saturator {
    std::array<Filter,2> antiAlias{};
    double previous{0}, drive{1}, bias{0}, dc{0}, blend{0}, character{0};
    void prepare(double sr) noexcept {
        antiAlias[0].configure(FilterType::LowPass,sr*4,sr*.43,.541196100146197);
        antiAlias[1].configure(FilterType::LowPass,sr*4,sr*.43,1.30656296487638);
    }
    void reset() noexcept { previous=0; for(auto& f:antiAlias)f.reset(); }
    void set(double gain, double amount, double offset, double asymmetry=0) noexcept {
        const double nextBlend=std::clamp(amount,0.0,1.0);
        if((blend==0)!=(nextBlend==0))for(auto& filter:antiAlias)filter.reset();
        drive=std::clamp(gain,.01,1000.0);blend=nextBlend;
        bias=std::clamp(offset,0.0,.8);character=std::clamp(asymmetry,-.6,.6);
        dc=std::tanh(bias*drive);
    }
    double process(double x) noexcept {
        if (blend==0) { previous=x; return x*drive; }
        float result=0;
        for(int sub=1;sub<=4;++sub) {
            const double up=previous+(x-previous)*(static_cast<double>(sub)*.25);
            const double linear=up*drive;
            const double curved=std::tanh((up+bias)*drive)-dc;
            const double asymmetric=curved*(1.0+character*curved);
            const double y=linear*(1.0-blend)+asymmetric*blend;
            result=antiAlias[1].process(antiAlias[0].process(static_cast<float>(y)));
        }
        previous=x;return result;
    }
};

// Asymmetric clipping can create DC even after subtracting its zero-input
// bias. This independent 2-Hz blocker is an authored stability stage, not a
// guessed manufacturer filter or a replacement for the user's HP/LP controls.
struct DcBlock {
    double previousIn{0},previousOut{0},pole{.9997};
    void prepare(double sr) noexcept {pole=std::exp(-2*pi*2/sr);reset();}
    void reset() noexcept {previousIn=previousOut=0;}
    double process(double x) noexcept {
        const double y=x-previousIn+pole*previousOut;
        previousIn=x;previousOut=std::abs(y)<1.e-25?0:y;
        if(!std::isfinite(y)||std::abs(y)>1.e8){reset();return 0;}
        return y;
    }
};

struct Gate {
    double threshold{0}, attack{0}, release{0}, detector{0}, gain{1}, fall{0};
    bool enabled{false};
    void set(double sr, bool on, double t, double a, double r) noexcept {
        if(enabled!=on){gain=on?0:1;detector=0;}
        enabled=on;threshold=t;attack=timeCoefficient(a,sr);
        release=timeCoefficient(r,sr);fall=timeCoefficient(20,sr);
    }
    void reset() noexcept {detector=0;gain=enabled?0:1;}
    double tick(double peak) noexcept {
        if(!enabled)return 1;
        detector=std::max(std::abs(peak),detector*fall);
        const double wanted=detector>threshold?1:0;
        const double time=wanted>gain?attack:release;
        gain=wanted+time*(gain-wanted);
        if(std::abs(gain)<1.e-25)gain=0;
        return gain;
    }
};

// Each cabinet has its own pass band, low resonance, cone breakup and notch.
// These analytic design parameters are authored coefficients, never
// borrowed impulse responses or asserted manufacturer measurements.
struct CabinetProfile {double hp,lowHz,lowDb,midHz,midDb,notch,lp;};
constexpr CabinetProfile guitarCabinets[] = {
 {76,125,3.2,1800,1.8,3300,5100},{66,160,2.4,2350,2.2,3900,5900},
 {72,135,1.8,2500,2.8,4400,6500},{62,105,3.8,1900,1.2,3600,5800},
 {88,155,1.4,2400,3.4,4200,7000},{74,130,2.5,2200,3.0,4000,6600},
 {58,95,4.5,2100,2.0,3400,5600},{65,115,3.0,2800,3.2,4700,6200},
 {57,90,4.0,2700,1.6,3900,5800},{60,105,3.6,3000,3.8,4900,6500}
};
constexpr CabinetProfile bassCabinets[] = {
 {38,80,3,950,1.5,2800,5200},{40,95,2.5,1800,3,4100,7200},
 {37,85,4,1500,2,3300,6500},{30,65,4.5,1000,1,3000,4800},
 {42,105,3,1400,2.8,3300,5400},{34,68,4,750,-1,2300,3900},
 {40,85,2,1200,2,3400,5000},{28,60,4,700,1,2100,3700},
 {31,72,5,850,1.8,2500,4200},{27,58,4.5,1100,2,2800,4600},
 {24,48,5.5,600,-1.5,1800,3100},{28,62,4,1550,2,3200,5300}
};
struct Cabinet {
    std::array<Filter,7> filters{};
    double air{0};
    void set(double sr, bool bass, int model, double distance) noexcept {
        const auto& p=bass?bassCabinets[std::clamp(model,0,11)]:guitarCabinets[std::clamp(model,0,9)];
        air=unit(distance);
        filters[0].configure(FilterType::HighPass,sr,p.hp);
        filters[1].configure(FilterType::Peak,sr,p.lowHz,1.15,p.lowDb);
        filters[2].configure(FilterType::Peak,sr,p.midHz,1.8,p.midDb);
        filters[3].configure(FilterType::Peak,sr,p.notch,4,-5);
        filters[4].configure(FilterType::LowPass,sr,p.lp*(1-.25*air),.63);
        filters[5].configure(FilterType::LowPass,sr,p.lp*(1-.15*air),1.05);
        filters[6].configure(FilterType::HighShelf,sr,2600,.707,-6*air);
    }
    void reset() noexcept {for(auto& f:filters)f.reset();}
    double process(double x) noexcept {
        float y=static_cast<float>(x);for(auto& f:filters)y=f.process(y);return y;
    }
};

// Independent own profiles for all sixteen named guitar amp choices and the
// three later combo functions. Shared primitives do not collapse the models:
// their headroom, bias, sag, filters and tone-stack centers differ explicitly.
struct AmpProfile {double hp,drive,bias,asymmetry,sag,bassHz,midHz,midQ,trebleHz,lp;};
constexpr AmpProfile guitarAmps[] = {
 {55,7,.02,.06,.10,160,1100,.8,3200,10500},
 {60,9,.03,.08,.12,150,1400,.7,3800,12000},
 {48,8,.02,.05,.12,130,1000,.9,3000,10000},
 {52,11,.03,.09,.15,130,1300,.7,3600,11500},
 {65,12,.06,.12,.20,110,750,1,2800,8500},
 {72,16,.04,.10,.14,100,900,1.1,3300,10500},
 {82,25,.05,.12,.12,110,1100,1.2,3600,11000},
 {90,35,.05,.15,.10,95,850,1.15,3900,10500},
 {95,45,.03,.09,.08,100,700,1.1,4000,10500},
 {80,42,.04,.12,.12,90,600,1.2,3500,10000},
 {88,50,.07,.18,.10,95,850,1.2,4200,11000},
 {65,22,.08,.16,.24,120,950,.8,3200,9000},
 {50,5,.03,.06,.12,140,800,.8,3300,11500},
 {45,4,.01,.02,.07,100,650,.8,3500,13500},
 {65,14,.10,.22,.30,150,800,.7,2800,8000},
 {60,12,.08,.17,.26,130,950,.75,3000,8500},
 {38,3.5,.015,.03,.05,90,620,.9,3700,14500}, // Clean Combo
 {45,9,.07,.13,.22,105,540,.7,3100,10200},   // California
 {58,16,.12,.24,.34,135,850,.75,2700,8200}   // Tweed
};
constexpr AmpProfile bassAmps[] = {
 {25,2,.01,.02,.04,80,650,.8,2800,16000},
 {32,2.3,.01,.02,.03,100,900,.8,3000,18000},
 {24,1.8,0,0,.02,70,700,.7,3200,18000},
 {30,2,.02,.03,.04,75,1100,.7,3400,15000},
 {35,8,.06,.12,.18,90,800,.9,2600,10000},
 {23,7,.08,.15,.22,60,700,.9,2400,8500},
 {28,10,.10,.18,.26,80,550,1.0,2200,8000},
 {25,9,.10,.18,.28,65,650,.8,2100,7500}, // Studio tube
 {28,8,.05,.12,.18,80,900,.8,2700,9500}, // AC100 character
 {31,12,.08,.16,.22,90,750,1.0,2900,10000}
};

// A dedicated authored high-gain topology for the official XTC identity.
// It is not an alias to a guitarAmps model or a claim about a Korg circuit.
// Two differently biased preamp stages, interstage bass/treble limiting,
// a tone stack and a separate sagged power stage make all six controls real.
struct XtcProfile {
    double inputHp, interstageHp, interstageLp, bassHz, midHz, midQ;
    double trebleHz, presenceHz, outputLp, sag;
    std::array<double,3> lowDrive, highDrive, bias, asymmetry;
};
constexpr XtcProfile xtcProfile{
    72,135,9200,125,820,.78,2800,4200,11000,.24,
    {{1.8,1.2,1.35}},{{18,12,3}},{{.035,.075,.015}},{{.12,-.18,.05}}
};

// The manual lists these twelve spans but prints no per-type center table.
// These are explicit SILVETON centers. Low/Mid/High together cover 21 centers
// from 80 Hz to 18 kHz; they are not claimed to be the hidden Korg center sets.
constexpr double graphicCenters[12][7] = {
 {80,200,500,1250,3150,8000,18000},{100,250,630,1600,4000,10000,18000},
 {125,315,800,2000,5000,12500,18000},{80,160,315,630,1250,2500,5000},
 {160,315,630,1250,2500,5000,10000},{315,630,1250,2500,5000,10000,18000},
 {80,100,125,160,200,250,315},{80,125,200,315,500,800,1250},
 {400,500,630,800,1000,1250,1600},{200,400,800,1600,3150,6300,12500},
 {2000,2500,3150,4000,6300,10000,18000},{500,1000,2000,4000,8000,12500,18000}
};
constexpr double vowelFormants[5][3] = {
 {800,1150,2900},{350,2000,2800},{325,700,2530},{450,1750,2600},{450,800,2830}
};

} // namespace

NumberedFxSupport numberedToneFxSupport(std::uint16_t index) noexcept {
    if(!toneIndex(index)||!ampMenuMatches(index))return {};
    auto mask=nf::editableMainMask(index);
    for(const auto& fixed:fixedRows)if(fixed.index==index)nf::lockRow(mask,index,fixed.row);
    const char* limitation="Собствен SILVETON DSP по основните функции; DMS е Off. Точният Korg звук и SET параметри не са потвърдени.";
    if(index>=10&&index<=16)limitation="Собствен SILVETON DSP. DMS и MIDI Sync са Off; неразчетените нотни менюта не се отгатват.";
    if(index==14)limitation="Собствен Sub Oscillator само във Fixed режим. Note Key Follow изисква потвърден собственик на нотата; не се измисля MIDI вход.";
    if(index==18||index==157)limitation="Собствен OD/Hi-Gain или Hyper-Gain, EQ и статичен Wah. Wah Sweep Range е фиксиран без външен DMS.";
    if(index==24||index==160)limitation="Самостоятелни L/R DSP вериги. Контролите са изведени от изрично посочения базов ефект в мануала; няма отделна отпечатана таблица или потвърден SET layout.";
    if(index==40)limitation="Два собствени настроени резонатора с Manual/LFO. DMS и MIDI Sync са Off; няма предположени нотни менюта.";
    if(index==155)limitation="Собствен резонанс на пианно тяло. Damper Depth е 0 при DMS Off; педал не се назначава по предположение.";
    if(index==156)limitation="Реален собствен filter-bank vocoder с входния звук като carrier и Input modulator. FX Control 1/2 изискват отделен аудио вход и са недостъпни.";
    if(index==208)limitation="Собствен органен усилвател и EQ, статични Expression/Minimum. Външният DMS и Expression Mode са фиксирани.";
    if(index==188||index==198)limitation="Официален номер и име; отделен собствен SILVETON XTC усилвател с три нелинейни стъпала. Контролите, кривите и началните стойности са наши; няма Modded OD alias, оригинален SET decode или твърдение за еднакъв Korg звук.";
    if(index==210)limitation="Собствен стерео шестлентов EQ: четири Peak/Shelf ленти и отделни HP/LP. Cutoff20–20000Hz/Thru и12/24/36/48dB/oct са наши явно означени контроли, а не разчетена оригинална таблица. DMS остава Off.";
    return {true,mask,limitation};
}

bool numberedToneFxCanRender(const NumberedFxState& state) noexcept {
    if(!toneIndex(state.index)||!ampMenuMatches(state.index)||!nf::baseStateValid(state))return false;
    for(const auto& fixed:fixedRows)
        if(fixed.index==state.index&&nf::value(state,fixed.row)!=fixed.value)return false;
    if(state.index==10&&nf::value(state,"b_1")==1)return false;
    if(state.index==40&&nf::value(state,"a_1")==2)return false;
    return true;
}

bool initializeNumberedToneFx(std::uint16_t index, NumberedFxState& state) noexcept {
    if(!toneIndex(index))return false;
    NumberedFxState next;
    if(!nf::initializeKnown(index,next))return false;
    bool ok=true;
    const auto put=[&](const char* row,double v){ok=nf::setInitial(next,row,v)&&ok;};
    const auto putMany=[&](std::initializer_list<std::pair<const char*,double>> values){
        for(const auto& v:values)put(v.first,v.second);
    };
    const auto choice=[&](const char* row,const char* name){
        const auto* p=findNumberedFxParam(index,row);
        if(!p){ok=false;return;}
        for(std::size_t i=0;i<p->choiceCount;++i)
            if(std::strcmp(p->choices[i].label,name)==0){put(row,p->choices[i].value);return;}
        ok=false;
    };
    switch(index){
    case 6:case 210:
        putMany({{"a_1",100},{"e_1",100},{"e_2",1},{"f_1",500},{"f_2",1},
                 {"g_1",2500},{"g_2",1},{"h_1",9000},{"h_2",1}});
        if(index==210)putMany({{"sv_hp_hz",kNumberedFxChoiceBase},{"sv_lp_hz",kNumberedFxChoiceBase},
                              {"sv_hp_slope",0},{"sv_lp_slope",0}});break;
    case 7:put("b_1",100);break;
    case 8:
        putMany({{"a_1",15},{"b_1",35},{"c_1",5},{"d_1",7},{"e_1",25},{"f_1",100}});break;
    case 9:putMany({{"a_1",100},{"b_1",250},{"c_1",3500}});break;
    case 10:
        putMany({{"a_1",25},{"a_2",80},{"b_3",60},{"c_1",50},{"d_1",1},
                 {"f_1",40},{"g_1",100}});break;
    case 11:
        putMany({{"b_1",25},{"b_2",85},{"c_1",35},{"c_2",75},{"d_3",50},
                 {"e_1",50},{"e_2",60},{"f_1",1},{"h_1",100}});break;
    case 12:
        putMany({{"a_2",90},{"b_1",.5},{"c_1",8},{"f_1",50},{"g_1",40},{"h_1",40}});break;
    case 13:
        putMany({{"a_2",100},{"b_1",60},{"c_1",25},{"d_1",1},{"e_1",1},
                 {"g_2",100},{"h_1",20}});break;
    case 14:putMany({{"c_1",40},{"d_1",50},{"e_1",50},{"f_1",30}});break;
    case 15:
        putMany({{"a_1",1},{"b_1",50},{"c_1",0},{"d_1",1},{"e_1",2},
                 {"f_2",50},{"g_1",.8}});break;
    case 16:
        putMany({{"a_1",1},{"a_2",25},{"b_1",12000},{"c_1",1},{"f_1",12},{"g_1",100}});break;
    case 17:
        putMany({{"b_1",8},{"c_1",10},{"c_2",60},{"d_1",8},{"e_1",5},{"f_1",100},
                 {"g_1",1000},{"g_2",1}});break;
    case 18:case 157:
        putMany({{"d_1",index==157?30.0:20.0},{"d_2",2},{"e_1",35},
                 {"f_1",120},{"g_1",900},{"g_2",.7},{"h_1",4500},{"h_2",1},{"i_2",1}});break;
    case 19:case 190:
        putMany({{"a_1",100},{"c_1",15}});
        if(index==190)choice("ungrouped_1","Off");break;
    case 20:put("a_1",100);break;
    case 21:case 22:
        putMany({{"b_1",80},{"c_1",50},{"d_1",50},{"d_2",2},{"e_1",50},{"f_1",50}});
        if(index==22)put("g_1",1);break;
    case 23:case 24:
        choice("a_1","Thru");choice("a_2","Thru");choice("e_1","Thru");choice("e_2","Thru");
        putMany({{"b_2",25},{"f_2",25},{"h_1",-3}});break;
    case 25:case 160:
        choice("c_1","Thru");choice("c_2","Thru");putMany({{"d_2",15},{"f_1",-3}});break;
    case 40:
        putMany({{"a_2",1},{"b_1",.5},{"d_1",50},{"d_2",50},{"e_1",60},{"e_3",60},
                 {"f_1",50},{"f_2",40},{"f_3",-3},{"g_1",67},{"g_3",60},
                 {"h_1",45},{"h_2",40},{"h_3",3}});break;
    case 155:putMany({{"a_1",40},{"c_1",50},{"d_1",18}});break;
    case 156:putMany({{"a_1",100},{"b_1",100},{"f_1",40},{"h_1",10}});break;
    case 158:
        putMany({{"a_2",30},{"b_1",80},{"c_1",50},{"c_2",50},{"d_1",50},{"d_2",50},
                 {"e_1",1},{"f_1",100},{"f_2",.7},{"g_1",500},{"g_2",.7},
                 {"h_1",2500},{"h_2",.7},{"i_1",8000},{"i_2",.7}});break;
    case 159:
        putMany({{"b_1",25},{"c_1",80},{"d_1",50},{"e_1",50},{"f_1",50},{"g_1",50},
                 {"h_1",1},{"i_1",5}});break;
    case 172:
        putMany({{"b_1",90},{"b_2",10},{"d_2",50},{"e_1",50},{"e_3",50}});break;
    case 184:putMany({{"a_1",25},{"b_1",70},{"c_1",55}});break;
    case 185:case 186:case 187:case 195:case 196:case 197:
        putMany({{"a_1",25},{"b_1",80},{"c_1",50},{"c_2",50},{"d_1",50},{"d_2",50}});
        if(index>=195)putMany({{"f_1",100},{"g_1",15},{"h_1",1},{"h_2",20},{"h_3",5},{"h_4",40}});break;
    case 188:case 198:
        putMany({{"sv_drive",42},{"sv_volume",70},{"sv_bass",50},{"sv_middle",50},
                 {"sv_treble",50},{"sv_presence",50},{"sv_wet",100}});
        if(index==198)putMany({{"sv_cab_type",9},{"sv_cab_trim",100},{"sv_cab_air",15},
            {"sv_gate_on",1},{"sv_gate_threshold",-60},{"sv_gate_attack",2},{"sv_gate_release",120}});
        break;
    case 193:
        putMany({{"b_1",30},{"c_1",80},{"d_1",50},{"d_2",50},{"d_3",50},{"d_4",50},
                 {"e_2",100},{"e_3",15},{"f_1",1},{"f_2",20},{"f_3",5},{"f_4",40}});break;
    case 208:putMany({{"a_2",20},{"c_1",80},{"d_2",100}});break;
    default:return false;
    }
    for(const auto& fixed:fixedRows)if(fixed.index==index)put(fixed.row,fixed.value);
    if(!ok||!numberedToneFxCanRender(next))return false;
    state=next;return true;
}

struct NumberedToneFx::Impl {
    struct Settings {
        std::uint16_t index{0};
        double input{1},output{1},wet{1},cabTrim{1},stageOutput{1};
        bool mono{false},cabinet{false},postEq{false},driveOn{false},lowPass{false};
        bool invert{false},preset{false},phaseInvert{false},preFilter{false};
        int mode{0},type{0},wave{0},eqCount{0},vowelTop{0},vowelCenter{1},vowelBottom{2};
        double bottom{0},top{100},resBottom{30},resTop{30},resonance{30},manual{50};
        double shape{0},sensitivity{1},response{0},release{0},depth{0};
        double lfoHz{1},phaseOffset{0},stepHz{1},shift{0},direct{0},sag{0};
        double sampleHz{48000},resolution{32768},highDamp{0},noise{0},click{0};
        double density{0},noiseTone{0},flutter{0},noiseFall{0},clickFall{0},hiss{0};
        std::array<double,2> delay{},resDelay{},resFeedback{},resDamping{},resLevel{};
        std::array<double,2> panL{{.707,.707}},panR{{.707,.707}};
        std::array<double,3> bands{{1,1,1}};
    } cfg;

    double sampleRate{48000},smoothing{1},wetNow{1},gainNow{1};
    bool prepared{false},enabled{false},cached{false};
    NumberedFxState state{};
    std::array<nf::Ring,2> delay{};
    std::array<std::array<Filter,12>,2> eq{};
    std::array<std::array<MovingFilter,3>,2> moving{};
    std::array<ThreeBand,2> split{};
    std::array<std::array<Saturator,2>,2> nonlinear{};
    Saturator xtcPower;
    NumberedSixBandEq sixBandEq;
    std::array<DcBlock,2> dc{};
    std::array<Cabinet,2> cabinet{};
    Gate gate;
    std::array<Filter,16> vocoderMod{},vocoderCarrier{};
    std::array<double,16> vocoderEnvelope{};
    std::array<Filter,24> body{};
    std::array<double,24> bodyGain{};
    std::array<double,2> envelope{},held{},position{},resLow{};
    double phase{0},stepPhase{0},samplePhase{0},noiseEnvelope{0},clickEnvelope{0},sagEnvelope{0},currentSampleHz{48000};
    std::uint32_t cycles{0},control{0},seed{0x9e3779b9U};
    bool firstStep{true};

    void clear() noexcept {
        for(auto& channel:eq)for(auto& f:channel)f.reset();
        for(auto& channel:moving)for(auto& f:channel)f.reset();
        for(auto& f:split)f.reset();for(auto& f:cabinet)f.reset();
        for(auto& channel:nonlinear)for(auto& f:channel)f.reset();
        xtcPower.reset();sixBandEq.reset();
        for(auto& f:dc)f.reset();
        for(auto& f:vocoderMod)f.reset();for(auto& f:vocoderCarrier)f.reset();
        for(auto& f:body)f.reset();for(auto& ring:delay)ring.reset();
        vocoderEnvelope.fill(0);envelope.fill(0);held.fill(0);position.fill(0);resLow.fill(0);
        phase=stepPhase=samplePhase=noiseEnvelope=clickEnvelope=sagEnvelope=0;
        cycles=control=0;seed=0x9e3779b9U;firstStep=true;gate.reset();
    }

    void setEq(std::size_t at,FilterType type,double hz,double q=.7071067811865476,double gain=0) noexcept {
        for(auto& channel:eq)channel[at].configure(type,sampleRate,hz,q,gain);
    }
    void passEq(std::size_t at) noexcept {
        for(auto& channel:eq){channel[at].identity();channel[at].reset();}
    }
    void cutoff(std::size_t at,FilterType type,double hz) noexcept {
        if(hz<=kNumberedFxChoiceBase)passEq(at);else setEq(at,type,hz);
    }
    double chain(int channel,double x,int first,int count) noexcept {
        float result=static_cast<float>(x);
        for(int i=0;i<count;++i)result=eq[static_cast<std::size_t>(channel)][static_cast<std::size_t>(first+i)].process(result);
        return result;
    }
    void setCabinet(bool bass,int model,double air) noexcept {
        cfg.cabinet=true;for(auto& c:cabinet)c.set(sampleRate,bass,model,air);
    }
    double cab(int channel,double x) noexcept {
        if(!cfg.cabinet)return x;
        const auto ch=static_cast<std::size_t>(channel);
        const double filtered=cabinet[ch].process(x*cfg.cabTrim);
        delay[ch].push(static_cast<float>(filtered));
        const double distance=cabinet[ch].air;
        return filtered*(1-.15*distance)+.15*distance*delay[ch].read(1+distance*sampleRate*.006);
    }
    void setAmp(const AmpProfile& profile,double drive,double bass,double mid,double treble,
                double presence,bool presenceCut,double midHz=0) noexcept {
        cfg.mono=true;cfg.sag=profile.sag;
        const double d=unit(drive);
        setEq(0,FilterType::HighPass,profile.hp);
        setEq(1,FilterType::LowShelf,profile.bassHz,.707,(bass-50)*.24);
        setEq(2,FilterType::Peak,midHz>0?midHz:profile.midHz,profile.midQ,(mid-50)*.24);
        setEq(3,FilterType::HighShelf,profile.trebleHz,.707,(treble-50)*.24);
        setEq(4,FilterType::HighShelf,5500,.707,presenceCut?-presence*.12:(presence-50)*.16);
        setEq(5,FilterType::LowPass,profile.lp);
        for(auto& channel:nonlinear){
            channel[0].set(logScale(d,1,profile.drive),d,profile.bias,profile.asymmetry);
            channel[1].set(1+d*2,.6*d,profile.bias*.5,profile.asymmetry*.5);
        }
    }
    double amp(double x) noexcept {
        const double fall=cfg.release;
        sagEnvelope=std::max(std::abs(x),sagEnvelope*fall);
        double result=chain(0,x/(1+cfg.sag*sagEnvelope),0,1);
        result=nonlinear[0][0].process(result);
        result=chain(0,result,1,4);
        result=dc[0].process(nonlinear[0][1].process(result));
        return chain(0,result,5,1);
    }

    void setXtc(double drive,double bass,double mid,double treble,double presence) noexcept {
        const auto& profile=xtcProfile;
        const double d=unit(drive);
        cfg.mono=true;cfg.sag=profile.sag;cfg.release=timeCoefficient(110,sampleRate);
        // Authored headroom compensation; Volume remains a separate smoothed
        // output level. No measured loudness matching is claimed.
        cfg.stageOutput=.72/(1+.3*d);
        setEq(0,FilterType::HighPass,profile.inputHp);
        setEq(1,FilterType::HighPass,profile.interstageHp);
        setEq(2,FilterType::LowPass,profile.interstageLp);
        setEq(3,FilterType::LowShelf,profile.bassHz,.707,(bass-50)*.24);
        setEq(4,FilterType::Peak,profile.midHz,profile.midQ,(mid-50)*.24);
        setEq(5,FilterType::HighShelf,profile.trebleHz,.707,(treble-50)*.22);
        setEq(6,FilterType::HighShelf,profile.presenceHz,.707,(presence-50)*.18);
        setEq(7,FilterType::LowPass,profile.outputLp);
        nonlinear[0][0].set(logScale(d,profile.lowDrive[0],profile.highDrive[0]),
            .7+.3*d,profile.bias[0],profile.asymmetry[0]);
        nonlinear[0][1].set(logScale(d,profile.lowDrive[1],profile.highDrive[1]),
            1,profile.bias[1],profile.asymmetry[1]);
        xtcPower.set(logScale(d,profile.lowDrive[2],profile.highDrive[2]),
            .65+.35*d,profile.bias[2],profile.asymmetry[2]);
    }
    double xtcAmp(double x) noexcept {
        double y=nonlinear[0][0].process(chain(0,x,0,1));
        y=nonlinear[0][1].process(chain(0,y,1,2));
        y=chain(0,dc[1].process(y),3,3);
        sagEnvelope=std::max(std::abs(y),sagEnvelope*cfg.release);
        y=dc[0].process(xtcPower.process(y/(1+cfg.sag*sagEnvelope)));
        return chain(0,y,6,2);
    }

    void configureValues(const NumberedFxState& s) noexcept {
        const Settings previous=cfg;
        cfg=Settings{};cfg.index=s.index;cfg.wet=nf::wet(s);
        cfg.release=timeCoefficient(160,sampleRate);
        const auto v=[&](const char* row,double fallback=0){return nf::value(s,row,fallback);};
        const auto i=[&](const char* row){return static_cast<int>(v(row));};
        const auto p=[&](const char* row){return unit(v(row));};
        const auto peq=[&](int at,const char* frequency,const char* q,const char* gain){
            setEq(static_cast<std::size_t>(at),FilterType::Peak,v(frequency),v(q),v(gain));
        };
        const auto shelves=[&](const char* low,const char* high,const char* lowGain,const char* highGain){
            setEq(0,FilterType::LowShelf,i(low)==1?400:100,.707,v(lowGain));
            setEq(1,FilterType::HighShelf,i(high)==1?3000:8000,.707,v(highGain));
        };
        if(s.index!=190&&s.index!=193&&s.index!=195&&s.index!=196&&s.index!=197&&s.index!=198)
            gate.set(sampleRate,false,0,1,100);
        switch(s.index){
        case 6: {
            cfg.input=p("a_1");cfg.eqCount=4;
            setEq(0,i("b_1")==1?FilterType::LowShelf:FilterType::Peak,v("e_1"),v("e_2"),v("e_3"));
            peq(1,"f_1","f_2","f_3");peq(2,"g_1","g_2","g_3");
            setEq(3,i("c_1")==1?FilterType::HighShelf:FilterType::Peak,v("h_1"),v("h_2"),v("h_3"));
            break;
        }
        case 210: {
            cfg.input=p("a_1");
            NumberedSixBandEq::Config eqConfig;
            // Input Trim was already applied by render(); the shared helper
            // owns the six filters only. Wet/Dry is mixed by process() once.
            eqConfig.trim=1;
            eqConfig.bands[0]={i("b_1")==1?NumberedSixBandEq::BandType::LowShelf:
                NumberedSixBandEq::BandType::Peak,v("e_1"),v("e_2"),v("e_3")};
            eqConfig.bands[1]={NumberedSixBandEq::BandType::Peak,v("f_1"),v("f_2"),v("f_3")};
            eqConfig.bands[2]={NumberedSixBandEq::BandType::Peak,v("g_1"),v("g_2"),v("g_3")};
            eqConfig.bands[3]={i("c_1")==1?NumberedSixBandEq::BandType::HighShelf:
                NumberedSixBandEq::BandType::Peak,v("h_1"),v("h_2"),v("h_3")};
            eqConfig.highPassHz=v("sv_hp_hz")<=kNumberedFxChoiceBase?0:v("sv_hp_hz");
            eqConfig.lowPassHz=v("sv_lp_hz")<=kNumberedFxChoiceBase?0:v("sv_lp_hz");
            eqConfig.highPassSlope=i("sv_hp_slope");eqConfig.lowPassSlope=i("sv_lp_slope");
            sixBandEq.configure(eqConfig);break;
        }
        case 7: {
            cfg.input=p("b_1");cfg.eqCount=7;
            const auto* centers=graphicCenters[std::clamp(i("a_1"),0,11)];
            static constexpr const char* gains[]{"c_1","d_1","e_1","f_1","g_1","h_1","i_1"};
            for(int band=0;band<7;++band){
                const double ratio=band==6?centers[6]/centers[5]:centers[band+1]/centers[band];
                const double q=1.0/(2.0*std::sinh(std::log(ratio)*.5));
                setEq(static_cast<std::size_t>(band),FilterType::Peak,centers[band],q,v(gains[band]));
            }
            break;
        }
        case 8: {
            cfg.input=p("f_1");cfg.direct=v("a_1")*.01;cfg.depth=p("e_1");
            cfg.delay={{v("c_1")*.001*sampleRate,v("d_1")*.001*sampleRate}};
            shelves("g_1","g_2","h_1","h_2");
            // The documented emphasis direction is inverted: larger values
            // emphasize lower frequencies. Negative Blend also changes bias,
            // producing a different harmonic pattern, not just polarity.
            setEq(2,FilterType::HighPass,logScale(1-v("b_1")/70.0,350,6500));
            setEq(3,FilterType::HighPass,30);
            for(auto& n:nonlinear)n[0].set(3.5,1,cfg.direct<0?.22:0,cfg.direct<0?.35:0);
            break;
        }
        case 9:
            cfg.input=p("a_1");cfg.bands={{amplitude(v("d_1")),amplitude(v("e_1")),amplitude(v("f_1"))}};
            for(auto& f:split)f.set(sampleRate,v("b_1"),v("c_1"));break;
        case 10:
            cfg.bottom=v("a_1");cfg.top=v("a_2");cfg.mode=i("b_1");
            cfg.response=timeCoefficient(logScale(1-p("b_3"),.6,120),sampleRate);
            cfg.sensitivity=1+19*p("c_1");cfg.shape=v("c_2");cfg.lfoHz=v("d_1");
            cfg.resonance=v("f_1");cfg.lowPass=i("f_2")!=0;cfg.output=p("g_1");
            setEq(0,FilterType::LowPass,5500);break;
        case 11:
            cfg.preset=i("a_1")==0;cfg.shape=v("a_2");cfg.invert=i("a_3")!=0;
            cfg.bottom=cfg.preset?22:v("b_1");cfg.top=cfg.preset?86:v("b_2");
            cfg.resBottom=cfg.preset?38:v("c_1");cfg.resTop=cfg.preset?72:v("c_2");
            cfg.mode=i("d_1");cfg.manual=v("d_3");cfg.sensitivity=1+19*p("e_1");
            cfg.response=timeCoefficient(logScale(1-p("e_2"),.6,120),sampleRate);
            cfg.lfoHz=v("f_1");cfg.output=p("h_1");setEq(0,FilterType::LowPass,6500);break;
        case 12:
            cfg.wave=i("a_1");cfg.phaseOffset=v("a_2")/360;cfg.lfoHz=v("b_1");cfg.stepHz=v("c_1");
            cfg.manual=v("f_1");cfg.depth=v("g_1");cfg.resonance=v("h_1");break;
        case 13:
            cfg.type=i("a_1");cfg.input=p("a_2");cfg.manual=v("b_1");cfg.resonance=v("c_1");
            cfg.wave=i("d_1");cfg.phaseOffset=v("d_2")/360;cfg.depth=v("d_3");cfg.lfoHz=v("e_1");
            cfg.driveOn=i("g_1")!=0;cfg.output=p("g_2");
            setEq(0,FilterType::LowShelf,100,.707,v("h_2")*.12);
            for(auto& n:nonlinear)n[0].set(logScale(p("h_1"),1,18),p("h_1"),.03,.08);break;
        case 14:
            cfg.lfoHz=v("c_1");cfg.sensitivity=2*p("e_1");cfg.shape=v("e_2");
            cfg.response=timeCoefficient(8,sampleRate);cfg.release=timeCoefficient(100,sampleRate);
            setEq(0,FilterType::LowPass,logScale((v("d_1")-1)/99,40,2000));break;
        case 15:
            cfg.mono=true;cfg.mode=i("a_1");cfg.manual=v("b_1");
            cfg.vowelTop=i("c_1");cfg.vowelCenter=i("d_1");cfg.vowelBottom=i("e_1");
            cfg.shift=std::exp2(v("f_1")*.01);cfg.resonance=v("f_2");cfg.lfoHz=v("g_1");break;
        case 16:
            cfg.preFilter=i("a_1")!=0;cfg.highDamp=p("a_2");cfg.sampleHz=v("b_1");
            cfg.lfoHz=v("c_1");cfg.depth=p("e_1");cfg.resolution=std::exp2(v("f_1")-1);cfg.output=p("g_1");break;
        case 17: {
            static constexpr double speeds[]{(100.0/3.0)/60.0,45.0/60.0,78.0/60.0};
            cfg.lfoHz=speeds[std::clamp(i("a_1"),0,2)];cfg.flutter=p("b_1");
            cfg.density=v("c_1")*2/sampleRate;cfg.noiseTone=p("c_2");cfg.noise=p("d_1")*.04;cfg.click=p("e_1")*.08;
            cfg.hiss=.15*std::sqrt(p("c_1"));
            cfg.input=p("f_1");peq(0,"g_1","g_2","g_3");
            setEq(1,FilterType::LowPass,logScale(cfg.noiseTone,500,16000));
            cfg.noiseFall=timeCoefficient(.3+2*(1-cfg.noiseTone),sampleRate);
            cfg.clickFall=timeCoefficient(1.5,sampleRate);break;
        }
        case 18:case 157: {
            cfg.mono=true;cfg.mode=i("c_1");cfg.driveOn=i("a_1")!=0;
            cfg.direct=v("i_1")*.02;cfg.stageOutput=v("e_1")*.02;
            if(v("d_2")>0)setEq(0,FilterType::HighPass,logScale(v("d_2")*.1,45,600));else passEq(0);
            setEq(1,FilterType::LowShelf,v("f_1"),.707,v("f_2"));
            peq(2,"g_1","g_2","g_3");peq(3,"h_1","h_2","h_3");
            moving[0][0].set(sampleRate,900,2.8);
            const double drive=(v("d_1")-1)/(s.index==157?119:99);
            const double maximum=cfg.mode==0?14:(s.index==157?85:40);
            nonlinear[0][0].set(logScale(drive,1,maximum),.7+.3*drive,cfg.mode==0?.07:.025,cfg.mode==0?.18:.03);
            nonlinear[0][1].set(cfg.mode==0?1:2.5,cfg.mode==0?0:.7,s.index==157?.12:.035,s.index==157?.2:.06);
            if(i("i_2"))setCabinet(false,s.index==157?9:3,0);break;
        }
        case 19:case 20:case 190:
            cfg.input=p("a_1");setCabinet(s.index==20,i("b_1"),s.index==20?0:v("c_1"));
            if(s.index==190){const double nr=v("ungrouped_1");gate.set(sampleRate,nr>kNumberedFxChoiceBase,
                nf::db(-90+70*unit(nr)),.5,90);}break;
        case 21:case 22:
            setAmp(bassAmps[std::clamp(i("a_1"),0,6)],35,v("c_1"),v("d_1"),v("e_1"),v("f_1"),false,
                   200*std::exp2(v("d_2")));
            cfg.output=p("b_1");if(s.index==22&&i("g_1"))setCabinet(true,i("h_1"),0);break;
        case 23:case 24:
            cfg.mono=s.index==23;cutoff(0,FilterType::HighPass,v("a_1"));cutoff(1,FilterType::LowPass,v("a_2"));
            cutoff(2,FilterType::HighPass,v("e_1"));cutoff(3,FilterType::LowPass,v("e_2"));
            for(auto& channel:nonlinear){
                channel[0].set(nf::db(v("b_1")),p("b_2"),p("c_1")*.7);
                channel[1].set(nf::db(v("f_1")),p("f_2"),p("g_1")*.7);
            }
            cfg.phaseInvert=i("d_1")==1;cfg.output=nf::db(v("h_1"));break;
        case 25:case 160: {
            struct Mic {double hp,low,lowGain,presence,presenceGain,top;};
            static constexpr Mic microphones[]{
                {65,160,1.5,3600,3.5,11000},{35,140,.5,5200,1.5,18000},
                {80,220,-1,6500,3,19000},{75,180,2,4200,4.5,12000},
                {90,170,2.5,3200,4,12500},{55,200,1,4700,2.5,14000},
                {50,140,1,7500,3,18500},{35,130,2,4800,2,16000},
                {28,85,5,3500,3,9000}
            };
            const auto& mic=microphones[std::clamp(i("a_1"),0,8)];
            const int positionIndex=std::clamp(i("b_1"),0,3);
            static constexpr double low[]{3,1,.5,-1},high[]{0,-1,-5,-3},level[]{1,.95,.85,.7};
            cfg.mono=s.index==25;cfg.input=level[positionIndex];cfg.output=nf::db(v("f_1"));
            setEq(0,FilterType::HighPass,mic.hp);
            setEq(1,FilterType::LowShelf,mic.low,.707,mic.lowGain+low[positionIndex]);
            setEq(2,FilterType::Peak,mic.presence,1.2,mic.presenceGain);
            setEq(3,FilterType::HighShelf,5000,.707,high[positionIndex]);
            setEq(4,FilterType::LowPass,mic.top);
            cutoff(5,FilterType::HighPass,v("c_1"));cutoff(6,FilterType::LowPass,v("c_2"));
            for(auto& channel:nonlinear)channel[0].set(nf::db(v("d_1")),p("d_2"),p("e_1")*.7);break;
        }
        case 40: {
            cfg.mode=i("a_1");cfg.invert=i("a_2")!=0;cfg.lfoHz=v("b_1");cfg.depth=v("d_1")*.0095;
            cfg.input=p("d_2");
            static constexpr const char* pitch[]{"e_1","g_1"};static constexpr const char* fine[]{"e_2","g_2"};
            static constexpr const char* level[]{"e_3","g_3"};static constexpr const char* feedback[]{"f_1","h_1"};
            static constexpr const char* damp[]{"f_2","h_2"};static constexpr const char* pan[]{"f_3","h_3"};
            for(int voice=0;voice<2;++voice){
                const auto n=static_cast<std::size_t>(voice);
                // NoteName's documented semantic C0 is 0, not MIDI note 0.
                const double hz=16.351597831287414*std::exp2(v(pitch[voice])/12+v(fine[voice])/1200);
                cfg.resDelay[n]=sampleRate/std::min(hz,sampleRate*.4);
                cfg.resFeedback[n]=v(feedback[voice])*.0095;cfg.resLevel[n]=p(level[voice]);
                cfg.resDamping[n]=std::exp(-2*pi*std::min(logScale(1-p(damp[voice]),700,18000),sampleRate*.4)/sampleRate);
                const double angle=(v(pan[voice])+6)*(pi/24);
                cfg.panL[n]=std::cos(angle);cfg.panR[n]=std::sin(angle);
            }
            break;
        }
        case 155: {
            cfg.depth=p("a_1");const double tuning=std::exp2(v("e_1")/1200);
            const double tone=(v("c_1")-1)/99;
            static constexpr double frequencies[]{85,112,147,195,252,317,405,505,635,790,985,1240,
                1550,1960,2470,3100,3900,4900,6150,7730,9100,10500,12000,13800};
            for(std::size_t mode=0;mode<body.size();++mode){
                body[mode].configure(FilterType::BandPass,sampleRate,frequencies[mode]*tuning,12+35*tone);
                bodyGain[mode]=.11*std::pow(.92,static_cast<double>(mode))*
                    std::pow(.25+.75*tone,static_cast<double>(mode)/8);
            }
            setEq(0,FilterType::Peak,120*std::exp2(v("d_1")/12),1,4);
            setEq(1,FilterType::LowPass,logScale(tone,1200,15000));break;
        }
        case 156: {
            cfg.input=p("a_1");cfg.sensitivity=p("b_1");cfg.mode=i("d_1");
            cfg.shift=std::exp2(v("e_1")*.5);cfg.noise=p("g_1")*.25;cfg.direct=p("h_1");
            const double ms=logScale(1-p("f_1"),2,120);
            cfg.response=timeCoefficient(ms,sampleRate);cfg.release=timeCoefficient(ms*4,sampleRate);
            for(std::size_t band=0;band<vocoderMod.size();++band){
                const double center=logScale(static_cast<double>(band)/15,150,7000);
                vocoderMod[band].configure(FilterType::BandPass,sampleRate,center,3.4);
                vocoderCarrier[band].configure(FilterType::BandPass,sampleRate,center*cfg.shift,3.4);
            }
            setEq(0,FilterType::HighPass,3500);
            setEq(1,FilterType::LowShelf,250,.707,v("i_1"));setEq(2,FilterType::HighShelf,3500,.707,v("i_2"));break;
        }
        case 158:
            setAmp(guitarAmps[std::clamp(i("a_1"),0,15)],v("a_2"),v("c_1"),v("c_2"),v("d_1"),v("d_2"),i("a_1")<4);
            cfg.output=p("b_1");cfg.postEq=i("e_1")!=0;
            peq(8,"f_1","f_2","f_3");peq(9,"g_1","g_2","g_3");peq(10,"h_1","h_2","h_3");peq(11,"i_1","i_2","i_3");break;
        case 159:
            setAmp(bassAmps[7+std::clamp(i("a_1"),0,2)],v("b_1"),v("d_1"),v("e_1"),v("f_1"),v("g_1"),false);
            cfg.output=p("c_1");if(i("h_1"))setCabinet(true,i("i_1"),0);break;
        case 172:
            cfg.type=i("a_1");cfg.bottom=v("b_2")*100/99;cfg.top=v("b_1")*100/99;
            cfg.mode=i("c_1");cfg.manual=v("d_2")*100/99;cfg.sensitivity=1+19*p("e_1");cfg.invert=i("e_2")!=0;
            cfg.response=timeCoefficient(logScale(v("e_3")/99,.3,180),sampleRate);
            cfg.release=timeCoefficient(120,sampleRate);setEq(0,FilterType::LowPass,cfg.type==0?6500:8500);break;
        case 184:
            cfg.output=v("b_1")/99;setEq(0,FilterType::HighPass,logScale(p("c_1"),180,1600));
            setEq(1,FilterType::LowPass,logScale(p("c_1"),2200,15000));
            for(auto& n:nonlinear)n[0].set(logScale(v("a_1")/99,1,14),.25+.5*v("a_1")/99,.09,.20);break;
        case 185:case 186:case 187:case 195:case 196:case 197: {
            const int model=16+(s.index>=195?s.index-195:s.index-185);
            setAmp(guitarAmps[model],v("a_1"),v("c_1"),v("c_2"),v("d_1"),v("d_2"),false);
            cfg.output=p("b_1");
            if(s.index>=195){
                setCabinet(false,i("e_1"),v("g_1"));cfg.cabTrim=p("f_1");
                gate.set(sampleRate,i("h_1")==0,nf::db(-80+.8*v("h_2")),
                    logScale((v("h_3")-1)/99,.1,100),logScale((v("h_4")-1)/99,5,3000));
            }
            break;
        }
        case 188:case 198:
            setXtc(v("sv_drive"),v("sv_bass"),v("sv_middle"),v("sv_treble"),v("sv_presence"));
            cfg.output=p("sv_volume")*cfg.stageOutput;
            if(s.index==198){
                setCabinet(false,i("sv_cab_type"),v("sv_cab_air"));cfg.cabTrim=p("sv_cab_trim");
                gate.set(sampleRate,i("sv_gate_on")!=0,nf::db(v("sv_gate_threshold")),
                    v("sv_gate_attack"),v("sv_gate_release"));
            }
            break;
        case 193:
            setAmp(guitarAmps[std::clamp(i("a_1"),0,15)],v("b_1"),v("d_1"),v("d_2"),v("d_3"),v("d_4"),i("a_1")<4);
            cfg.output=p("c_1");setCabinet(false,i("e_1"),v("e_3"));cfg.cabTrim=p("e_2");
            gate.set(sampleRate,i("f_1")==0,nf::db(-80+.8*v("f_2")),
                logScale((v("f_3")-1)/99,.1,100),logScale((v("f_4")-1)/99,5,3000));break;
        case 208:
            cfg.type=i("a_1");cfg.driveOn=cfg.type<2&&v("a_2")>0;
            cfg.input=std::max(p("d_1"),p("d_2"));cfg.output=p("c_1");
            setEq(0,FilterType::LowShelf,140,.707,v("b_1"));setEq(1,FilterType::Peak,850,.8,v("b_2"));
            setEq(2,FilterType::HighShelf,3000,.707,v("b_3"));
            if(cfg.type==2)passEq(3);else setEq(3,FilterType::LowPass,cfg.type==0?5000:11000);
            for(auto& n:nonlinear)n[0].set(logScale(p("a_2"),1,cfg.type==0?20:12),p("a_2"),cfg.type==0?.06:.025,cfg.type==0?.18:.05);break;
        default:break;
        }
        // A re-enabled static wah/pre-filter must not expose a stale input
        // history that stopped advancing while it was bypassed.
        if(previous.index==cfg.index){
            if((cfg.index==18||cfg.index==157)&&previous.driveOn!=cfg.driveOn)moving[0][0].reset();
            if(cfg.index==16&&previous.preFilter!=cfg.preFilter)for(auto& channel:eq)channel[0].reset();
            if(cfg.index==16&&(previous.highDamp==0)!=(cfg.highDamp==0))for(auto& channel:eq)channel[1].reset();
        }
        control=0;
    }

    void updateMoving() noexcept;
    void render(double left,double right,double& outL,double& outR) noexcept;
};

void NumberedToneFx::Impl::updateMoving() noexcept {
    switch(cfg.index){
    case 10:case 11:
        for(std::size_t ch=0;ch<2;++ch){
            double sweep=cfg.mode==2?.5+.5*sine(phase):position[ch];
            sweep=shaped(sweep,cfg.shape);if(cfg.invert)sweep=1-sweep;
            const double f=(cfg.bottom+(cfg.top-cfg.bottom)*sweep)*.01;
            const double r=cfg.index==11?cfg.resBottom+(cfg.resTop-cfg.resBottom)*sweep:cfg.resonance;
            const double q=.6+15*unit(r)*unit(r);
            moving[ch][0].set(sampleRate,logScale(f,cfg.index==11?140:120,cfg.index==11?6000:5500),q);
        }
        break;
    case 12:
        for(std::size_t ch=0;ch<2;++ch){
            const double frequency=(cfg.manual+.5*cfg.depth*held[ch])*.01;
            moving[ch][0].set(sampleRate,logScale(frequency,40,12000),.5+20*unit(cfg.resonance)*unit(cfg.resonance));
        }
        break;
    case 13:
        for(std::size_t ch=0;ch<2;++ch){
            const double at=phase+(ch?cfg.phaseOffset:0);
            const double lfo=cfg.wave==0?triangle(at):sine(at);
            moving[ch][0].set(sampleRate,logScale((cfg.manual+.5*cfg.depth*lfo)*.01,20,18000),
                .5+18*unit(cfg.resonance)*unit(cfg.resonance));
        }
        break;
    case 15: {
        const double positionValue=cfg.mode==1?.5+.5*sine(phase):unit(cfg.manual);
        const int first=positionValue<.5?cfg.vowelBottom:cfg.vowelCenter;
        const int second=positionValue<.5?cfg.vowelCenter:cfg.vowelTop;
        const double portion=positionValue<.5?positionValue*2:(positionValue-.5)*2;
        for(std::size_t band=0;band<3;++band){
            const double f1=vowelFormants[std::clamp(first,0,4)][band];
            const double f2=vowelFormants[std::clamp(second,0,4)][band];
            const double frequency=f1*std::pow(f2/f1,portion)*cfg.shift;
            moving[0][band].set(sampleRate,frequency,2+18*unit(cfg.resonance));
        }
        break;
    }
    case 16:
        currentSampleHz=std::clamp(cfg.sampleHz*(1-.95*cfg.depth*(.5+.5*sine(phase))),1000.0,sampleRate);
        if(cfg.preFilter)setEq(0,FilterType::LowPass,currentSampleHz*.45);
        if(cfg.highDamp>0)setEq(1,FilterType::LowPass,logScale(1-cfg.highDamp,500,std::min(18000.0,sampleRate*.45)));
        break;
    case 172:
        for(std::size_t ch=0;ch<2;++ch){
            double sweep=cfg.mode==1?unit(cfg.manual):position[ch];
            if(cfg.mode==0&&cfg.invert)sweep=1-sweep;
            const double normalized=(cfg.bottom+(cfg.top-cfg.bottom)*sweep)*.01;
            const double frequency=logScale(normalized,cfg.type==0?220:160,cfg.type==0?4500:6000);
            moving[ch][0].set(sampleRate,frequency,(cfg.type==0?2.5:3.5)+(cfg.type==0?8:10)*sweep*sweep);
        }
        break;
    default:break;
    }
}

void NumberedToneFx::Impl::render(double left,double right,double& outL,double& outR) noexcept {
    const std::array<double,2> input{{left*cfg.input,right*cfg.input}};
    const double mono=(input[0]+input[1])*.5;
    std::array<double,2> result{{0,0}};

    if(cfg.index==10||cfg.index==11||cfg.index==172){
        for(std::size_t ch=0;ch<2;++ch){
            const double level=std::abs(input[ch]);
            const double coefficient=cfg.index==172&&level<envelope[ch]?cfg.release:cfg.response;
            envelope[ch]=level+coefficient*(envelope[ch]-level);
            double target=std::clamp(envelope[ch]*cfg.sensitivity,0.0,1.0);
            if(cfg.index==11&&cfg.mode==1)target=unit(cfg.manual);
            position[ch]=target+cfg.response*(position[ch]-target);
        }
    }
    if(cfg.index==12){
        stepPhase+=cfg.stepHz/sampleRate;
        if(firstStep||stepPhase>=1){
            firstStep=false;stepPhase=wrap(stepPhase);
            for(std::size_t ch=0;ch<2;++ch){
                const double at=phase+(ch?cfg.phaseOffset:0);
                if(cfg.wave==0)held[ch]=triangle(at);
                else {
                    // A continuous deterministic random lattice is sampled by
                    // the separate step clock. Both speed controls and stereo
                    // phase therefore retain a real, independent function.
                    const double lattice=(static_cast<double>(cycles)+at)*16;
                    const double base=std::floor(lattice),part=lattice-base;
                    const auto cell=static_cast<std::uint32_t>(static_cast<std::int64_t>(base));
                    const double a=static_cast<double>(hash(cell))/2147483648.0-1;
                    const double b=static_cast<double>(hash(cell+1))/2147483648.0-1;
                    const double smooth=part*part*(3-2*part);
                    held[ch]=a+(b-a)*smooth;
                }
            }
        }
    }
    if(control==0){updateMoving();control=16;}
    --control;

    switch(cfg.index){
    case 6:case 7:
        for(int ch=0;ch<2;++ch)result[static_cast<std::size_t>(ch)]=chain(ch,input[static_cast<std::size_t>(ch)],0,cfg.eqCount);
        break;
    case 210: {
        float eqLeft=static_cast<float>(input[0]),eqRight=static_cast<float>(input[1]);
        sixBandEq.process(eqLeft,eqRight);result[0]=eqLeft;result[1]=eqRight;break;
    }
    case 8: {
        std::array<double,2> excited{},delayed{};
        for(int ch=0;ch<2;++ch){
            const auto n=static_cast<std::size_t>(ch);
            const double clean=chain(ch,input[n],0,2);
            const double high=chain(ch,clean,2,1);
            const double harmonic=nonlinear[n][0].process(high)/3.5-high;
            excited[n]=clean+2*cfg.direct*chain(ch,harmonic,3,1);
            delay[n].push(static_cast<float>(excited[n]));
            delayed[n]=cfg.delay[n]<=0?excited[n]:delay[n].read(1+cfg.delay[n]);
        }
        result[0]=excited[0]+.5*cfg.depth*(delayed[0]-delayed[1]);
        result[1]=excited[1]+.5*cfg.depth*(delayed[1]-delayed[0]);
        break;
    }
    case 9:
        for(std::size_t ch=0;ch<2;++ch)result[ch]=split[ch].process(input[ch],cfg.bands);break;
    case 10:case 11:case 172:
        for(int ch=0;ch<2;++ch){
            const auto n=static_cast<std::size_t>(ch);
            result[n]=moving[n][0].process(input[n],2);
            if(cfg.lowPass||cfg.index==11||cfg.index==172)result[n]=chain(ch,result[n],0,1);
        }
        break;
    case 12:
        for(std::size_t ch=0;ch<2;++ch)result[ch]=moving[ch][0].process(input[ch],2);break;
    case 13:
        for(int ch=0;ch<2;++ch){
            const auto n=static_cast<std::size_t>(ch);
            result[n]=moving[n][0].process(input[n],cfg.type);
            const double driven=dc[n].process(nonlinear[n][0].process(chain(ch,result[n],0,1)));
            if(cfg.driveOn)result[n]=driven;
        }
        break;
    case 14: {
        const double oscillator=sine(phase);
        for(int ch=0;ch<2;++ch){
            const auto n=static_cast<std::size_t>(ch);
            const double trigger=std::abs(chain(ch,input[n],0,1));
            const double coefficient=trigger>envelope[n]?cfg.response:cfg.release;
            envelope[n]=trigger+coefficient*(envelope[n]-trigger);
            result[n]=oscillator*shaped(std::clamp(envelope[n]*cfg.sensitivity,0.0,1.0),cfg.shape);
        }
        break;
    }
    case 15:
        result[0]=1.3*(moving[0][0].process(mono,2)*.65+moving[0][1].process(mono,2)*.35+
                        moving[0][2].process(mono,2)*.20);result[1]=result[0];break;
    case 16: {
        std::array<double,2> pre=input;
        if(cfg.preFilter)for(int ch=0;ch<2;++ch)pre[static_cast<std::size_t>(ch)]=chain(ch,pre[static_cast<std::size_t>(ch)],0,1);
        samplePhase+=currentSampleHz/sampleRate;
        if(firstStep||samplePhase>=1){
            firstStep=false;samplePhase=wrap(samplePhase);
            for(std::size_t ch=0;ch<2;++ch)held[ch]=std::clamp(std::round(pre[ch]*cfg.resolution),-cfg.resolution,cfg.resolution-1)/cfg.resolution;
        }
        for(int ch=0;ch<2;++ch){const auto n=static_cast<std::size_t>(ch);
            result[n]=cfg.highDamp>0?chain(ch,held[n],1,1):held[n];}
        break;
    }
    case 17: {
        const bool scratch=phase+cfg.lfoHz/sampleRate>=1;
        if(scratch)clickEnvelope=randomValue(seed)<0?-1:1;
        else clickEnvelope*=cfg.clickFall;
        if((randomValue(seed)+1)*.5<cfg.density)noiseEnvelope=randomValue(seed);
        else noiseEnvelope*=cfg.noiseFall;
        const double wobble=cfg.flutter*(.004+.003*sine(phase)+.0004*sine(phase*7));
        for(int ch=0;ch<2;++ch){const auto n=static_cast<std::size_t>(ch);
            const double clean=chain(ch,input[n],0,1);delay[n].push(static_cast<float>(clean));
            const double warped=cfg.flutter>0?delay[n].read(1+wobble*sampleRate):clean;
            const double surface=chain(ch,randomValue(seed)*cfg.hiss+noiseEnvelope,1,1);
            result[n]=warped+surface*cfg.noise+clickEnvelope*cfg.click;
        }
        break;
    }
    case 18:case 157: {
        double driven=chain(0,mono,0,1);
        if(cfg.driveOn)driven=moving[0][0].process(driven,2);
        driven=nonlinear[0][0].process(driven);driven=dc[0].process(nonlinear[0][1].process(driven));
        driven=chain(0,driven,1,3);driven=cab(0,driven);
        result[0]=driven*cfg.stageOutput+mono*cfg.direct;result[1]=result[0];break;
    }
    case 19:case 20:case 190: {
        const double gain=gate.tick(std::max(std::abs(input[0]),std::abs(input[1])));
        for(int ch=0;ch<2;++ch)result[static_cast<std::size_t>(ch)]=cab(ch,input[static_cast<std::size_t>(ch)]*gain);break;
    }
    case 21:case 22:case 158:case 159:case 185:case 186:case 187:case 193:case 195:case 196:case 197: {
        double processed=amp(mono*gate.tick(std::abs(mono)));
        if(cfg.postEq)processed=chain(0,processed,8,4);
        processed=cab(0,processed);result[0]=result[1]=processed;break;
    }
    case 188:case 198: {
        const double processed=xtcAmp(mono*gate.tick(std::abs(mono)));
        result[0]=result[1]=cab(0,processed);break;
    }
    case 23:case 24: {
        const int channels=cfg.mono?1:2;
        for(int channel=0;channel<channels;++channel){
            const auto ch=static_cast<std::size_t>(channel);
            double tube=nonlinear[ch][0].process(chain(channel,cfg.mono?mono:input[ch],0,2));
            if(cfg.phaseInvert)tube=-tube;
            result[ch]=dc[ch].process(nonlinear[ch][1].process(chain(channel,tube,2,2)));
        }
        if(cfg.mono)result[1]=result[0];break;
    }
    case 25:case 160:
        for(int channel=0;channel<(cfg.mono?1:2);++channel){const auto ch=static_cast<std::size_t>(channel);
            result[ch]=dc[ch].process(nonlinear[ch][0].process(chain(channel,cfg.mono?mono:input[ch],0,7)));}
        if(cfg.mono)result[1]=result[0];break;
    case 40: {
        const double modulation=sine(phase);
        for(std::size_t voice=0;voice<2;++voice){
            const double feedback=cfg.mode==0?cfg.resFeedback[voice]:
                cfg.depth*modulation*(voice==1&&cfg.invert?-1:1);
            const double tap=delay[voice].read(cfg.resDelay[voice]);
            resLow[voice]=tap+cfg.resDamping[voice]*(resLow[voice]-tap);
            const double resonated=safeSample(mono+std::clamp(feedback,-.95,.95)*resLow[voice]);
            delay[voice].push(static_cast<float>(resonated));
            const double sound=resonated*(1-.6*std::abs(feedback))*cfg.resLevel[voice];
            result[0]+=sound*cfg.panL[voice];result[1]+=sound*cfg.panR[voice];
        }
        break;
    }
    case 155: {
        double l=0,r=0;
        for(std::size_t mode=0;mode<body.size();++mode){
            const double resonated=body[mode].process(static_cast<float>(mono))*bodyGain[mode];
            l+=resonated*(mode%2?.6:1);r+=resonated*(mode%2?1:.6);
        }
        result[0]=mono+cfg.depth*chain(0,l,0,2);result[1]=mono+cfg.depth*chain(1,r,0,2);break;
    }
    case 156: {
        const double carrier=mono+randomValue(seed)*cfg.noise;
        const double modulator=(cfg.mode==1?left:cfg.mode==2?right:(left+right)*.5)*cfg.sensitivity;
        double vocoded=0;
        for(std::size_t band=0;band<vocoderMod.size();++band){
            const double level=std::abs(vocoderMod[band].process(static_cast<float>(modulator)));
            const double coefficient=level>vocoderEnvelope[band]?cfg.response:cfg.release;
            vocoderEnvelope[band]=level+coefficient*(vocoderEnvelope[band]-level);
            vocoded+=vocoderCarrier[band].process(static_cast<float>(carrier))*std::min(8.0,vocoderEnvelope[band]*8);
        }
        vocoded+=cfg.direct*chain(0,modulator,0,1);
        result[0]=chain(0,vocoded,1,2);result[1]=result[0];break;
    }
    case 184:
        for(int ch=0;ch<2;++ch){const auto n=static_cast<std::size_t>(ch);
            result[n]=chain(ch,dc[n].process(nonlinear[n][0].process(chain(ch,input[n],0,1))),1,1);}
        break;
    case 208:
        for(int ch=0;ch<2;++ch){const auto n=static_cast<std::size_t>(ch);
            const double nonlinearValue=dc[n].process(nonlinear[n][0].process(input[n]));
            const double driven=cfg.driveOn?nonlinearValue:input[n];
            result[n]=chain(ch,driven,0,4);}
        break;
    default:break;
    }
    const double next=phase+cfg.lfoHz/sampleRate;
    if(next>=1){phase=wrap(next);++cycles;}else phase=next;
    outL=safeSample(result[0]);outR=safeSample(result[1]);
}

NumberedToneFx::NumberedToneFx()=default;
NumberedToneFx::~NumberedToneFx()=default;
NumberedToneFx::NumberedToneFx(NumberedToneFx&&) noexcept=default;
NumberedToneFx& NumberedToneFx::operator=(NumberedToneFx&&) noexcept=default;

void NumberedToneFx::prepare(double sr,float* workspace,std::size_t samples) {
    if(!impl_)impl_=std::make_unique<Impl>();
    impl_->sampleRate=std::clamp(nf::boundedRate(sr),4000.0,384000.0);
    const auto minimum=static_cast<std::size_t>(std::ceil(impl_->sampleRate*.25))+8;
    impl_->prepared=workspace!=nullptr&&samples>=minimum;
    if(impl_->prepared){
        const std::size_t half=samples/2;
        impl_->delay[0].attach(workspace,half);impl_->delay[1].attach(workspace+half,samples-half);
    }else for(auto& ring:impl_->delay)ring.attach(nullptr,0);
    for(auto& channel:impl_->nonlinear)for(auto& n:channel)n.prepare(impl_->sampleRate);
    impl_->xtcPower.prepare(impl_->sampleRate);impl_->sixBandEq.prepare(impl_->sampleRate);
    for(auto& filter:impl_->dc)filter.prepare(impl_->sampleRate);
    impl_->smoothing=1-timeCoefficient(8,impl_->sampleRate);
    reset();
}

void NumberedToneFx::reset() noexcept {
    if(!impl_)return;
    impl_->clear();impl_->enabled=impl_->cached=false;impl_->state={};
    impl_->wetNow=impl_->gainNow=1;
}

void NumberedToneFx::configure(const NumberedFxState& state) noexcept {
    if(!impl_||!impl_->prepared||(impl_->cached&&sameNumberedFx(impl_->state,state)))return;
    const bool fresh=!impl_->enabled||impl_->state.index!=state.index;
    const bool valid=numberedToneFxCanRender(state);
    if(!valid){if(impl_->enabled)impl_->clear();impl_->enabled=false;impl_->cached=true;impl_->state=state;return;}
    if(fresh)impl_->clear();
    impl_->configureValues(state);impl_->state=state;impl_->enabled=impl_->cached=true;
    if(fresh){impl_->wetNow=impl_->cfg.wet;impl_->gainNow=impl_->cfg.output;}
}

void NumberedToneFx::process(float inL,float inR,float& outL,float& outR) noexcept {
    if(!impl_||!impl_->enabled){outL=nf::finite(inL);outR=nf::finite(inR);return;}
    const double left=safeSample(inL),right=safeSample(inR);
    double l=0,r=0;impl_->render(left,right,l,r);
    impl_->wetNow+=(impl_->cfg.wet-impl_->wetNow)*impl_->smoothing;
    impl_->gainNow+=(impl_->cfg.output-impl_->gainNow)*impl_->smoothing;
    outL=nf::mix(static_cast<float>(left),static_cast<float>(safeSample(l*impl_->gainNow)),impl_->wetNow);
    outR=nf::mix(static_cast<float>(right),static_cast<float>(safeSample(r*impl_->gainNow)),impl_->wetNow);
    if(!std::isfinite(outL)||!std::isfinite(outR)){outL=outR=0;impl_->clear();}
}

} // namespace silveton::sampler
