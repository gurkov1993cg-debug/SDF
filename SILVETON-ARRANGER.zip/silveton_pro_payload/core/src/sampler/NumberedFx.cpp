#include "silveton/sampler/NumberedFx.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iterator>

namespace silveton::sampler {
namespace {

#include "NumberedFxData.inc"

std::string numberText(double value, unsigned decimals) {
    // Preserve a meaningful edited fraction even for an integer-looking manual
    // range. Printed precision is not an assertion about the device's step.
    if (std::abs(value - std::round(value)) > 0.000001)
        decimals = std::max(decimals, 3U);
    char text[64]{};
    std::snprintf(text, sizeof(text), "%.*f", static_cast<int>(std::min(decimals, 6U)), value);
    std::string result(text);
    if (result.find('.') != std::string::npos) {
        while (!result.empty() && result.back() == '0') result.pop_back();
        if (!result.empty() && result.back() == '.') result.pop_back();
    }
    return result;
}

} // namespace

const NumberedFxDescriptor* numberedFxDescriptors(std::size_t& count) noexcept {
    count = sizeof(kNumberedFxDescriptors) / sizeof(kNumberedFxDescriptors[0]);
    return kNumberedFxDescriptors;
}

const NumberedFxDescriptor* findNumberedFx(std::uint16_t index) noexcept {
    const auto first = std::begin(kNumberedFxDescriptors);
    const auto last = std::end(kNumberedFxDescriptors);
    const auto found = std::lower_bound(first, last, index,
        [](const NumberedFxDescriptor& entry, std::uint16_t value) { return entry.index < value; });
    return found != last && found->index == index ? found : nullptr;
}

const NumberedFxParamDescriptor* findNumberedFxParam(std::uint16_t index, const char* rowId) noexcept {
    const auto* effect = findNumberedFx(index);
    if (!effect || !rowId) return nullptr;
    for (std::size_t row = 0; row < effect->parameterCount; ++row)
        if (std::strcmp(effect->parameters[row].rowId, rowId) == 0) return &effect->parameters[row];
    return nullptr;
}

const NumberedFxDescriptor* findNumberedFxManual(const char* manualId) noexcept {
    if (!manualId || !*manualId) return nullptr;
    for (const auto& effect : kNumberedFxDescriptors)
        if (std::strcmp(effect.manualId, manualId) == 0) return &effect;
    for (const auto& effect : kUnboundManualFxDescriptors)
        if (std::strcmp(effect.manualId, manualId) == 0) return &effect;
    return nullptr;
}

bool numberedFxValueValid(const NumberedFxParamDescriptor& parameter, double value) noexcept {
    if (!std::isfinite(value) || !parameter.domainComplete || parameter.kind == NumberedFxValueKind::Reference)
        return false;
    for (std::size_t i = 0; i < parameter.choiceCount; ++i)
        if (value == parameter.choices[i].value) return true;
    if (parameter.kind == NumberedFxValueKind::Enumeration || !parameter.rangeKnown)
        return false;
    if (value < parameter.minimum || value > parameter.maximum) return false;
    if (parameter.format == NumberedFxValueFormat::NoteName && value != std::floor(value)) return false;
    if (parameter.stepKnown && parameter.step > 0.0) {
        const double steps = (value - parameter.minimum) / parameter.step;
        if (std::abs(steps - std::round(steps)) > 0.000001) return false;
    }
    return true;
}

bool numberedFxStateValid(const NumberedFxState& state) noexcept {
    if (state.schema != kNumberedFxSchema || static_cast<unsigned>(state.origin) > static_cast<unsigned>(NumberedFxOrigin::Manual))
        return false;
    const auto* effect = findNumberedFx(state.index);
    if (!effect || effect->parameterCount > kNumberedFxValueCount) return false;
    const auto count = effect->parameterCount;
    const std::uint64_t allowed = count == kNumberedFxValueCount ? ~std::uint64_t{0} : ((std::uint64_t{1} << count) - 1);
    if ((state.knownMask & ~allowed) != 0 || (state.origin == NumberedFxOrigin::Unknown && state.knownMask != 0))
        return false;
    for (std::size_t row = 0; row < count; ++row)
        if (state.known(row) && !numberedFxValueValid(effect->parameters[row], state.values[row])) return false;
    return true;
}

bool NumberedFxState::valid() const noexcept { return numberedFxStateValid(*this); }

std::string formatNumberedFxValue(const NumberedFxParamDescriptor& parameter, double value) {
    if (!numberedFxValueValid(parameter, value)) return "—";
    for (std::size_t i = 0; i < parameter.choiceCount; ++i)
        if (value == parameter.choices[i].value) return parameter.choices[i].label;
    if (parameter.kind == NumberedFxValueKind::WetDry || parameter.kind == NumberedFxValueKind::BipolarWetDry ||
        parameter.format == NumberedFxValueFormat::Balance) {
        const auto wet = std::abs(value);
        return (value < 0.0 ? "-" : "") + numberText(wet, 0) + ":" + numberText(100.0 - wet, 0);
    }
    if (parameter.format == NumberedFxValueFormat::RatioToOne)
        return numberText(value, parameter.displayDecimals) + " : 1";
    if (parameter.format == NumberedFxValueFormat::Multiplier)
        return "x" + numberText(value, parameter.displayDecimals);
    if (parameter.format == NumberedFxValueFormat::SignedPan)
        return std::string(value < 0.0 ? "L" : "R") + numberText(std::abs(value), 0);
    if (parameter.format == NumberedFxValueFormat::NoteName) {
        static constexpr const char* names[]{"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        const auto note = static_cast<unsigned>(value);
        return std::string(names[note % 12]) + std::to_string(note / 12);
    }
    return numberText(value, parameter.displayDecimals);
}

std::string formatNumberedFxValue(const NumberedFxState& state, std::size_t row) {
    const auto* effect = findNumberedFx(state.index);
    if (!effect || row >= effect->parameterCount || !state.known(row)) return "—";
    return formatNumberedFxValue(effect->parameters[row], state.values[row]);
}

const char* numberedFxOriginName(NumberedFxOrigin origin) noexcept {
    switch (origin) {
    case NumberedFxOrigin::Initial: return "SILVETON начални";
    case NumberedFxOrigin::Decoded: return "Оригинал — декодирано";
    case NumberedFxOrigin::Manual: return "Ръчно";
    default: return "Неизвестно";
    }
}

} // namespace silveton::sampler
