#include "silveton/sampler/SampleStreamPrefetcher.h"
#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <limits>
#include <sys/mman.h>
#include <unistd.h>

#if defined(__linux__) || defined(__ANDROID__)
#include <pthread.h>
#include <sched.h>
#ifndef MADV_POPULATE_READ
#define MADV_POPULATE_READ 22
#endif
#endif

namespace silveton::sampler {
namespace {

constexpr std::int64_t kRefreshMs = 100;   // re-assert residency of an unchanged window
constexpr auto kPassInterval = std::chrono::milliseconds(2);   // while voices play
constexpr auto kIdleInterval = std::chrono::milliseconds(10);  // nothing to read ahead

struct PrefetchCounters {
    std::atomic<std::uint64_t> requestedRanges{0U}, populateReadRanges{0U};
    std::atomic<std::uint64_t> leasedTouchRanges{0U}, leasedTouchPages{0U};
    std::atomic<std::uint64_t> unleasedRanges{0U}, failedWillNeedRanges{0U};
    std::atomic<std::uint64_t> unsupportedPopulateWorkers{0U};
};
PrefetchCounters prefetchCounters;

std::uintptr_t pageSize() noexcept {
    static const std::uintptr_t size = [] {
        const long v = ::sysconf(_SC_PAGESIZE);
        return static_cast<std::uintptr_t>(v > 0 ? v : 4096L);
    }();
    return size;
}

std::int64_t nowMs() noexcept {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

} // namespace

SamplePrefetchStatus samplePrefetchStatus() noexcept {
    SamplePrefetchStatus status;
    status.requestedRanges = prefetchCounters.requestedRanges.load(std::memory_order_relaxed);
    status.populateReadRanges = prefetchCounters.populateReadRanges.load(std::memory_order_relaxed);
    status.leasedTouchRanges = prefetchCounters.leasedTouchRanges.load(std::memory_order_relaxed);
    status.leasedTouchPages = prefetchCounters.leasedTouchPages.load(std::memory_order_relaxed);
    status.unleasedRanges = prefetchCounters.unleasedRanges.load(std::memory_order_relaxed);
    status.failedWillNeedRanges = prefetchCounters.failedWillNeedRanges.load(std::memory_order_relaxed);
    status.unsupportedPopulateWorkers = prefetchCounters.unsupportedPopulateWorkers.load(std::memory_order_relaxed);
    return status;
}

bool SampleStreamPrefetcher::start() noexcept {
    if (run_.load(std::memory_order_acquire)) return true;
    for (auto& c : cache_) c = SlotCache{};
    lastCollectionMs_ = 0;
    run_.store(true, std::memory_order_release);
    try {
        thread_ = std::thread(&SampleStreamPrefetcher::loop, this);
    } catch (...) {
        run_.store(false, std::memory_order_release);
        return false;
    }
    return true;
}

void SampleStreamPrefetcher::stop() noexcept {
    run_.store(false, std::memory_order_release);
    if (thread_.joinable()) thread_.join();
    MappedSampleRegion::collectUnused();
}

void SampleStreamPrefetcher::runOnce() noexcept {
    const std::uintptr_t page = pageSize();
    const std::int64_t now = nowMs();
    bool work = false;
    for (std::size_t slot = 0; slot < SamplerEngine::kMaxStreamWindows; ++slot) {
        SamplerEngine::StreamWindow w{};
        if (!engine_.readStreamWindow(slot, w) || w.begin == 0U || w.bytes == 0U) {
            cache_[slot] = SlotCache{};
            continue;
        }
        work = true;
        const auto maximum = std::numeric_limits<std::uintptr_t>::max();
        if (w.begin > maximum - (page - 1U) || w.bytes > maximum - w.begin - (page - 1U)) {
            cache_[slot] = SlotCache{};
            continue;
        }
        const std::uintptr_t b = w.begin & ~(page - 1U);
        const std::uintptr_t e = (w.begin + w.bytes + page - 1U) & ~(page - 1U);
        SlotCache& c = cache_[slot];
        const bool fresh = c.end != 0U && (now - c.stampMs) < kRefreshMs;
        if (fresh && b >= c.begin && e <= c.end) continue;   // already resident
        std::uintptr_t from = b;
        std::uintptr_t to = e;
        if (fresh && b >= c.begin && b < c.end) from = c.end; // only the new part
        else if (fresh && e <= c.end && e > c.begin) to = c.begin; // reverse: only the new left edge
        if (to > from) {
            void* addr = reinterpret_cast<void*>(from);
            const std::size_t len = static_cast<std::size_t>(to - from);
            int rc = -1;
            prefetchCounters.requestedRanges.fetch_add(1U, std::memory_order_relaxed);
#if defined(__linux__) || defined(__ANDROID__)
            if (advice_.load(std::memory_order_relaxed) == 0) {
                // Synchronously fault the pages in here, so the audio thread
                // finds them mapped. Returns ENOMEM (no crash) for unmapped memory.
                rc = ::madvise(addr, len, MADV_POPULATE_READ);
                if (rc == 0) {
                    populateWorked_ = true;
                    prefetchCounters.populateReadRanges.fetch_add(1U, std::memory_order_relaxed);
                } else if (errno == EINVAL && !populateWorked_) {
                    advice_.store(1, std::memory_order_relaxed); // kernel < 5.14: never supported
                    prefetchCounters.unsupportedPopulateWorkers.fetch_add(1U, std::memory_order_relaxed);
                }
            }
#else
            (void)populateWorked_; // MADV_POPULATE_READ exists only on Linux/Android
#endif
            if (rc != 0) {
                // WILLNEED alone is asynchronous and does not install the PTEs:
                // the audio callback can still fault on its first sample read.
                // A retained region lets this ordinary worker do those reads
                // synchronously without racing bank unload or needing mlock.
                std::size_t touched = 0U;
                if (MappedSampleRegion::prefault(from, len, &touched)) {
                    prefetchCounters.leasedTouchRanges.fetch_add(1U, std::memory_order_relaxed);
                    prefetchCounters.leasedTouchPages.fetch_add(static_cast<std::uint64_t>(touched), std::memory_order_relaxed);
                } else {
                    prefetchCounters.unleasedRanges.fetch_add(1U, std::memory_order_relaxed);
                    if (::madvise(addr, len, MADV_WILLNEED) != 0)
                        prefetchCounters.failedWillNeedRanges.fetch_add(1U, std::memory_order_relaxed);
                }
            }
            requests_.fetch_add(1U, std::memory_order_relaxed);
        }
        c.begin = b;
        c.end = e;
        // Extending a cached window in either direction must not refresh its
        // age forever: the unchanged overlap is reasserted at kRefreshMs.
        if (from == b && to == e) c.stampMs = now;
    }
    lastPassHadWork_ = work;
    if (lastCollectionMs_ == 0 || now - lastCollectionMs_ >= kRefreshMs) {
        MappedSampleRegion::collectUnused();
        lastCollectionMs_ = now;
    }
}

void SampleStreamPrefetcher::loop() noexcept {
#if defined(__linux__) || defined(__ANDROID__)
    (void)::pthread_setname_np(::pthread_self(), "SilvPrefetch");
    if (firstCpu_ >= 0 && lastCpu_ >= firstCpu_) {
        cpu_set_t set;
        CPU_ZERO(&set);
        for (int cpu = firstCpu_; cpu <= lastCpu_; ++cpu) CPU_SET(cpu, &set);
        (void)::sched_setaffinity(0, sizeof(set), &set);
    }
#endif
    while (run_.load(std::memory_order_acquire)) {
        runOnce();
        std::this_thread::sleep_for(lastPassHadWork_ ? kPassInterval : kIdleInterval);
    }
}

} // namespace silveton::sampler
