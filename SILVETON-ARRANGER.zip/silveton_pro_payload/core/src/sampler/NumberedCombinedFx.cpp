#include "silveton/sampler/NumberedCombinedFx.h"
#include "silveton/sampler/NumberedDynamics.h"
#include "silveton/sampler/NumberedFxKernel.h"
#include "silveton/sampler/NumberedSixBandEq.h"
#include <array>
#include <cmath>
#include <iterator>

namespace silveton::sampler {
namespace {
using namespace numbered_fx;
enum class Kind { Equalizer, Exciter, Wah, Chorus, Phaser, Delay, Compressor,
    Limiter, Amp, Overdrive, Tremolo, Decimator, Reverb, Gate };
enum class Key { Trim, Sensitivity, Attack, Output, Ratio, Threshold, Release, Gain,
    LowGain, HighGain, Blend, Emphasis, Bottom, Top, Sweep, Rate, Resonance, LowPass,
    Wave, DelayMs, Depth, Feedback, OutputMode, Manual, Tap1Ms, Tap1Level, Tap2Ms,
    Damping, DriveMode, Drive, AmpType, PreLpf, SampleHz, Bits, Shape, Decay, PreDelay,
    ReverbBalance, LowFc, HighFc, Envelope, DetectorMix, Polarity, Routing, Wet,
    Band0Hz, Band0Q, Band0Gain, Band1Hz, Band1Q, Band1Gain,
    Band2Hz, Band2Q, Band2Gain, Band3Hz, Band3Q, Band3Gain, Count };
struct Binding { const char* row; unsigned component; Key key; double initial; bool editable; };
struct Recipe { std::uint16_t index; Kind first, second; const Binding* rows; std::size_t count; };
#include "NumberedCombinedFxData.inc"

//209 keeps the official Stereo Limiter+6BandEQ identity. Its confirmed manual
// reference is89, so the existing22-row descriptor/20 main bindings supply
// limiter, four PEQ bands, routing and mix. Four explicitly own HP/LP controls
// are added separately; the generated77..108 recipe table is unchanged.
constexpr Recipe kStereoLimiterSixBand{209,Kind::Limiter,Kind::Equalizer,
    kBindings89,std::size(kBindings89)};
constexpr const char* kSixBandCutRows[]{"sv_hp_hz","sv_lp_hz","sv_hp_slope","sv_lp_slope"};

const Recipe* recipe(std::uint16_t index) noexcept {
    if(index==209)return &kStereoLimiterSixBand;
    if (index < 77 || index > 108) return nullptr;
    const auto& r = kRecipes[index - 77];
    return r.index == index ? &r : nullptr;
}

struct Config {
    std::array<double, static_cast<unsigned>(Key::Count)> values{};
    std::array<bool, static_cast<unsigned>(Key::Count)> known{};
    void set(Key key, double v) noexcept { values[static_cast<unsigned>(key)] = v; known[static_cast<unsigned>(key)] = true; }
    double get(Key key, double fallback = 0) const noexcept {
        const auto n = static_cast<unsigned>(key); return known[n] ? values[n] : fallback;
    }
};

double waveform(double phase, int type, double shape = 0) noexcept {
    phase -= std::floor(phase);
    double w = 0;
    switch (type) {
        case 1: w = std::sin(2*pi*phase); break;
        case 2: w = std::tanh(2.5*std::sin(2*pi*phase)) / std::tanh(2.5); break;
        case 3: w = 2*phase-1; break;
        case 4: w = 1-2*phase; break;
        default: w = 1-4*std::abs(phase-.5); break;
    }
    if (shape != 0) w = std::copysign(std::pow(std::abs(w), std::pow(4.0, shape*.01)), w);
    return w;
}

// Feedback recovery bounds sit far above an ordinary unity input. The loop
// coefficient itself is kept below one to avoid uncontrolled accumulation at
// the printed +/-100 endpoints; this is an explicit own-code stability choice.
float loopBound(double x) noexcept { return static_cast<float>(8*std::tanh(x/8)); }

struct Component {
    Kind kind{Kind::Equalizer};
    Config config;
    double rate{48000}, phase{0}, envelope{0}, gate{0}, samplePhase{0};
    double gain{1}, trim{1}, localWet{1}, frequency{.4}, feedback{0}, lfoShape{0};
    double decay{1.5}, damping{.5}, attack{.01}, release{.001}, threshold{.01};
    double sampleHz{12000}, quantScale{2048}, outputScale{1};
    float held{0}, previousInput{0}, previousWet{0}, dampState{0}, preDelayed{0}, rawReverb{0};
    float phaserFeedback{0};
    unsigned controlCounter{0};
    bool lowPass{false}, preLpf{false}, negative{false}, infiniteRatio{false};
    int wave{0}, outputMode{0}, sweep{0}, driveMode{0}, ampType{0};
    double wahHz{1000}, phaserA{0}, filterEnvelope{0}, motionAttack{.003}, motionRelease{.0005};
    std::array<float,6> allpassState{};
    std::array<Biquad,4> eq{};
    Biquad lowShelf, highShelf, lowpass, highpass, motionFilter;
    Ring line;
    std::array<Ring,8> comb{};
    std::array<double,8> combDelay{}, combGain{};
    std::array<float,8> combDamp{};
    NumberedDynamics dynamics;

    void prepare(double sr, float* workspace, std::size_t count) {
        rate = boundedRate(sr);
        motionAttack=1-std::exp(-1/(rate*.005));
        motionRelease=1-std::exp(-1/(rate*.06));
        dynamics.prepare(rate);
        const auto common = std::min(count, static_cast<std::size_t>(std::ceil(rate*1.5))+8);
        line.attach(workspace,common);
        std::size_t offset = common;
        static constexpr double lengths[]{.0297,.0371,.0411,.0437,.0479,.0533,.0593,.0671};
        for (unsigned i=0;i<8;++i) {
            auto n = static_cast<std::size_t>(std::ceil(rate*lengths[i]))+3;
            if (offset+n>count) n = offset<count ? count-offset : 0;
            comb[i].attach(n ? workspace+offset : nullptr,n);
            combDelay[i] = n>3 ? static_cast<double>(n-3) : 1;
            offset += n;
        }
        reset();
    }
    void reset() noexcept {
        phase=envelope=gate=samplePhase=filterEnvelope=0;
        held=previousInput=previousWet=dampState=preDelayed=rawReverb=phaserFeedback=0;
        controlCounter=0; allpassState.fill(0); combDamp.fill(0); line.reset();
        for(auto& ring:comb)ring.reset();
        for(auto& f:eq)f.reset();
        lowShelf.reset();highShelf.reset();lowpass.reset();highpass.reset();motionFilter.reset();
        dynamics.reset();
    }
    void configure(Kind type, const Config& next) noexcept {
        if(kind!=type)reset();
        kind=type; config=next;
        trim=config.get(Key::Trim,100)*.01;
        localWet=config.get(Key::Wet,100)*.01;
        frequency=config.get(Key::Rate,.4);
        wave=static_cast<int>(config.get(Key::Wave));
        outputMode=static_cast<int>(config.get(Key::OutputMode));
        feedback=std::clamp(config.get(kind==Kind::Phaser?Key::Resonance:Key::Feedback)*.01,-.995,.995);
        lfoShape=config.get(Key::Shape);
        lowPass=config.get(Key::LowPass)!=0;preLpf=config.get(Key::PreLpf)!=0;
        sweep=static_cast<int>(config.get(Key::Sweep));
        driveMode=static_cast<int>(config.get(Key::DriveMode));
        ampType=static_cast<int>(config.get(Key::AmpType));
        gain=config.get(Key::Gain)<=kNumberedFxChoiceBase?0:db(config.get(Key::Gain));
        outputScale=config.get(Key::Output,100)*.01;
        if(kind==Kind::Overdrive)outputScale=config.get(Key::Output,25)*.04;
        lowShelf.configure(Biquad::Type::LowShelf,rate,config.get(Key::LowFc)==1?400:100,.707,config.get(Key::LowGain));
        highShelf.configure(Biquad::Type::HighShelf,rate,config.get(Key::HighFc)==1?3000:8000,.707,config.get(Key::HighGain));
        for(unsigned b=0;b<4;++b) {
            static constexpr double hz[]{120,600,2500,8000};
            const auto key=static_cast<unsigned>(Key::Band0Hz)+3*b;
            eq[b].configure(kind==Kind::Overdrive&&b==0?Biquad::Type::LowShelf:Biquad::Type::Peak,rate,
                config.get(static_cast<Key>(key),hz[b]),config.get(static_cast<Key>(key+1),1),config.get(static_cast<Key>(key+2)));
        }
        // The documented Emphasis direction moves toward lower frequencies
        // as the value increases. Our exact cutoff curve remains authored.
        highpass.configure(Biquad::Type::HighPass,rate,350*std::pow(6500.0/350.0,1-config.get(Key::Emphasis,35)/70.0));
        lowpass.configure(Biquad::Type::LowPass,rate,18000*std::pow(1.0/36.0,config.get(Key::Damping,25)*.01));
        damping=1-std::exp(-2*pi*(18000*std::pow(1.0/36.0,config.get(Key::Damping,25)*.01))/rate);
        decay=config.get(Key::Decay,1.5);
        for(unsigned i=0;i<8;++i)combGain[i]=std::pow(.001,combDelay[i]/rate/std::max(.1,decay));
        sampleHz=std::clamp(config.get(Key::SampleHz,12000),1.0,rate);
        quantScale=std::pow(2.0,std::clamp(std::round(config.get(Key::Bits,12)),4.0,24.0)-1);
        if(kind==Kind::Decimator)motionFilter.configure(Biquad::Type::LowPass,rate,std::min(rate*.45,sampleHz*.45));
        if(kind==Kind::Amp) {
            highpass.configure(Biquad::Type::HighPass,rate,20);
            lowShelf.configure(Biquad::Type::LowShelf,rate,ampType==1?180:120,.707,ampType==1?-2:ampType==2?2:0);
            highShelf.configure(Biquad::Type::HighShelf,rate,ampType==1?2200:3200,.707,ampType==1?3:ampType==2?-1:0);
            lowpass.configure(Biquad::Type::LowPass,rate,ampType==1?6500:ampType==2?5800:9000);
        }
        if(kind==Kind::Overdrive) {
            lowpass.configure(Biquad::Type::LowPass,rate,driveMode?6200:10000);
            highpass.configure(Biquad::Type::HighPass,rate,20);
        }
        attack=1-std::exp(-1/(rate*(.0002+.040*std::pow(config.get(Key::Attack,20)*.01,2))));
        release=1-std::exp(-1/(rate*(.005+2*std::pow(config.get(Key::Release,40)*.01,2))));
        threshold=db(-80+config.get(Key::Threshold,10)*.8);
        negative=config.get(Key::Polarity)!=0;
        if(kind==Kind::Compressor||kind==Kind::Limiter) {
            NumberedDynamics::Config c;
            c.index=kind==Kind::Compressor?1:2;
            c.sensitivity=static_cast<float>(config.get(Key::Sensitivity,35));
            c.attack=static_cast<float>(config.get(Key::Attack,20));
            c.release=static_cast<float>(config.get(Key::Release,40));
            c.thresholdDb=static_cast<float>(config.get(Key::Threshold,-12));
            const double ratio=config.get(Key::Ratio,4);
            c.infiniteRatio=ratio<=kNumberedFxChoiceBase;
            c.ratio=static_cast<float>(c.infiniteRatio?50:ratio);
            c.eqTrim=static_cast<float>(trim);
            c.lowShelfGainDb=static_cast<float>(config.get(Key::LowGain));
            c.highShelfGainDb=static_cast<float>(config.get(Key::HighGain));
            dynamics.configure(c);
        }
    }
    float shelves(float x) noexcept { return highShelf.process(lowShelf.process(static_cast<float>(x*trim))); }
    double lfo() noexcept {
        const double result=waveform(phase,wave,lfoShape);
        phase+=frequency/rate;phase-=std::floor(phase);
        return result;
    }
    float distort(float x) noexcept {
        const double drive=1+config.get(Key::Drive,35)*.3;
        const auto shaper=[&](double a) {
            if(driveMode) {
                const double first=std::tanh(a*drive+.12)-std::tanh(.12);
                return std::tanh(2.5*first)*.8;
            }
            return std::tanh(a*drive)/std::tanh(drive);
        };
        const double y=.5*(shaper((previousInput+x)*.5)+shaper(x));
        previousInput=x;
        float out=lowpass.process(highpass.process(static_cast<float>(y)));
        for(unsigned i=0;i<3;++i)out=eq[i].process(out);
        return static_cast<float>(out*outputScale);
    }
    void process(float x,float& left,float& right) noexcept {
        const float dry=x;
        float y=x;
        double waveValue=0;
        switch(kind) {
            case Kind::Equalizer:
                y=static_cast<float>(x*trim);for(auto& f:eq)y=f.process(y);break;
            case Kind::Exciter: {
                const float base=shelves(x);const float high=highpass.process(base);
                const double blend=config.get(Key::Blend)*.01;
                const double bias=blend<0?.22:0;
                const float harmonics=static_cast<float>(std::tanh((high+bias)*3)-std::tanh(bias*3)-high);
                // Negative Blend has its own asymmetric harmonic pattern;
                // merely reversing the polarity would miss that function.
                y=base+static_cast<float>(std::abs(blend))*harmonics;break;
            }
            case Kind::Wah: {
                waveValue=lfo();
                const double level=std::min(1.0,std::abs(static_cast<double>(x))*4);
                filterEnvelope+=(level-filterEnvelope)*(level>filterEnvelope?motionAttack:motionRelease);
                const double position=sweep==2?(waveValue+1)*.5:filterEnvelope;
                const double pct=config.get(Key::Bottom,20)+(config.get(Key::Top,80)-config.get(Key::Bottom,20))*position;
                if((controlCounter++&31U)==0) {
                    wahHz=100*std::pow(80.0,std::clamp(pct,0.0,100.0)*.01);
                    motionFilter.configure(lowPass?Biquad::Type::LowPass:Biquad::Type::BandPass,rate,wahHz,
                        .5+config.get(Key::Resonance,30)*.095);
                }
                y=motionFilter.process(x);break;
            }
            case Kind::Compressor:case Kind::Limiter: {
                float other=0;dynamics.process(x,x,y,other);
                y=static_cast<float>(y*(kind==Kind::Compressor?outputScale:gain));break;
            }
            case Kind::Chorus: {
                waveValue=lfo();x=shelves(x);
                const double delay=config.get(Key::DelayMs,12)+7.5*config.get(Key::Depth,35)*.01*waveValue;
                y=line.read(std::max(0.0,delay)*rate*.001);
                line.push(loopBound(x+y*feedback));
                left=mix(x,y,localWet);right=mix(x,outputMode?-y:y,localWet);return;
            }
            case Kind::Phaser: {
                waveValue=lfo();
                if((controlCounter++&31U)==0) {
                    const double pct=std::clamp(config.get(Key::Manual,45)+config.get(Key::Depth,35)*.5*waveValue,0.0,100.0);
                    const double hz=std::min(rate*.4,80*std::pow(100.0,pct*.01));
                    const double tangent=std::tan(pi*hz/rate);phaserA=(1-tangent)/(1+tangent);
                }
                y=loopBound(x+phaserFeedback*feedback);
                for(auto& z:allpassState) {const float out=static_cast<float>(-phaserA*y+z);z=y+static_cast<float>(phaserA*out);y=out;}
                phaserFeedback=y;
                left=mix(x,y,localWet);right=mix(x,outputMode?-y:y,localWet);return;
            }
            case Kind::Delay: {
                const double d1=config.get(Key::Tap1Ms,240)*rate*.001;
                const double d2=config.get(Key::Tap2Ms,480)*rate*.001;
                const float tap1=d1<1?x:line.read(d1);
                const float tap2=d2<1?x:line.read(d2);
                dampState+=static_cast<float>((tap2-dampState)*damping);
                line.push(loopBound(x+dampState*feedback));
                y=static_cast<float>(tap1*config.get(Key::Tap1Level,60)*.01+tap2);break;
            }
            case Kind::Overdrive:y=distort(x);break;
            case Kind::Amp: {
                x=lowShelf.process(x);double z=x;
                if(ampType==1)z=(std::tanh(x*2.8+.18)-std::tanh(.18))/.96;
                else if(ampType==2)z=std::tanh(x*1.8)+.07*(std::tanh(x*3)*std::tanh(x*3));
                else z=x/(1+.18*std::abs(x));
                y=lowpass.process(highShelf.process(highpass.process(static_cast<float>(z))));break;
            }
            case Kind::Tremolo:
                waveValue=lfo();y=static_cast<float>(x*(1-config.get(Key::Depth,35)*.01*(1-waveValue)*.5));break;
            case Kind::Decimator:
                if(preLpf)x=motionFilter.process(x);
                samplePhase+=sampleHz/rate;
                if(samplePhase>=1) {samplePhase-=std::floor(samplePhase);held=static_cast<float>(std::round(std::clamp(static_cast<double>(x),-1.0,1.0)*quantScale)/quantScale);}
                y=static_cast<float>(lowpass.process(held)*outputScale);break;
            case Kind::Reverb: {
                const double delay=config.get(Key::PreDelay,20)*rate*.001;
                preDelayed=delay<1?x:line.read(delay);line.push(x);
                const float input=shelves(preDelayed);
                std::array<float,8> taps{};double sum=0;
                for(unsigned i=0;i<8;++i) {
                    taps[i]=comb[i].read(combDelay[i]);
                    combDamp[i]+=static_cast<float>((taps[i]-combDamp[i])*damping);sum+=combDamp[i];
                }
                double wetSum=0;
                for(unsigned i=0;i<8;++i) {
                    const double reflected=combDamp[i]-.25*sum;
                    comb[i].push(loopBound(input*.35+reflected*combGain[i]));
                    wetSum+=taps[i]*(i&1?-.353553390593:.353553390593);
                }
                rawReverb=static_cast<float>(wetSum);y=rawReverb;break;
            }
            case Kind::Gate:break; // Reverb Gate is handled with its separate, delayed detector.
        }
        left=right=mix(dry,y,localWet);
    }
    float reverbGate(float dry,float reverb,double balance) noexcept {
        const double detector=dry*(1-config.get(Key::DetectorMix)*.01)+reverb*config.get(Key::DetectorMix)*.01;
        const double level=std::abs(detector);
        envelope+=(level-envelope)*(level>envelope?attack:release);
        double target=envelope>=threshold?1:0;if(negative)target=1-target;
        gate+=(target-gate)*(target>gate?attack:release);
        return mix(dry,static_cast<float>(reverb*gate),balance);
    }
};
}

NumberedFxSupport numberedCombinedFxSupport(std::uint16_t index) noexcept {
    const auto* r=recipe(index);if(!r)return {};
    std::uint64_t mask=0;
    for(std::size_t i=0;i<r->count;++i)if(r->rows[i].editable) {
        const auto* p=findNumberedFxParam(index,r->rows[i].row);
        if(p&&p->domainComplete)mask|=std::uint64_t{1}<<p->ordinal;
    }
    if(index==209){
        for(const auto* row:kSixBandCutRows){
            const auto* p=findNumberedFxParam(index,row);
            if(p&&p->domainComplete)mask|=std::uint64_t{1}<<p->ordinal;
        }
        return {true,mask,"Собствен стерео limiter и четири PEQ ленти с HP/LP. Свързан peak detector, избираем ред и еднократен Wet/Dry. HP/LP диапазоните и наклоните са SILVETON избори; DMS е Off. Няма твърдение за Korg звуково съвпадение или оригинален SET decode."};
    }
    return {true,mask,"Два собствени свързани процесора; основни контроли и Routing. DMS е Off; Wah приема Auto/LFO, Gate използва Input. При Chorus/Phaser преди моно процесора Output Mode трябва да е Normal. Korg звуково съвпадение и оригинален SET decode не са установени."};
}

bool initializeNumberedCombinedFx(std::uint16_t index,NumberedFxState& state) noexcept {
    const auto* r=recipe(index);if(!r)return false;
    NumberedFxState next;if(!initializeKnown(index,next))return false;
    for(std::size_t i=0;i<r->count;++i)
        if(!setInitial(next,r->rows[i].row,r->rows[i].initial))return false;
    if(index==209&&(!setInitial(next,"sv_hp_hz",kNumberedFxChoiceBase)||
        !setInitial(next,"sv_lp_hz",kNumberedFxChoiceBase)||
        !setInitial(next,"sv_hp_slope",0)||!setInitial(next,"sv_lp_slope",0)))return false;
    if(!numberedCombinedFxCanRender(next))return false;
    state=next;return true;
}

bool numberedCombinedFxCanRender(const NumberedFxState& state) noexcept {
    const auto* r=recipe(state.index);if(!r||!baseStateValid(state))return false;
    bool reverse=false,inverted=false;
    for(std::size_t i=0;i<r->count;++i) {
        const auto& b=r->rows[i];const double v=value(state,b.row);
        if(!b.editable&&v!=b.initial)return false;
        if(b.key==Key::Sweep&&v==1)return false;
        // Bit depth and enum domains are meaningful discrete settings. Decimal
        // input is not silently rounded to a different saved control value.
        if(b.key==Key::Bits&&v!=std::floor(v))return false;
        if(b.key==Key::Routing)reverse=v!=0;
        if(b.key==Key::OutputMode)inverted=v!=0;
    }
    // The manual forces Normal when the stereo modulation output feeds a
    // mono compressor/limiter/drive stage. Reject the incompatible pair rather
    // than persist an inverted label while silently playing a different mode.
    return !(reverse&&inverted);
}

struct NumberedCombinedFx::Impl {
    std::array<Component,2> parts;
    NumberedSixBandEq sixBand;
    const Recipe* current{nullptr};
    NumberedFxState state;
    bool enabled{false},reverse{false};
    double wet{1},targetWet{1},smoothing{1};
};
NumberedCombinedFx::NumberedCombinedFx()=default;
NumberedCombinedFx::~NumberedCombinedFx()=default;
void NumberedCombinedFx::prepare(double sr,float* workspace,std::size_t samples) {
    if(!impl_)impl_=std::make_unique<Impl>();
    const auto half=samples/2;
    impl_->parts[0].prepare(sr,workspace,half);
    impl_->parts[1].prepare(sr,workspace?workspace+half:nullptr,samples-half);
    impl_->sixBand.prepare(sr);
    impl_->smoothing=1-std::exp(-1/(boundedRate(sr)*.008));
    reset();
}
void NumberedCombinedFx::reset() noexcept {
    if(!impl_)return;
    for(auto& part:impl_->parts)part.reset();
    impl_->sixBand.reset();
    impl_->enabled=false;impl_->current=nullptr;impl_->state={};impl_->wet=impl_->targetWet=1;impl_->reverse=false;
}
void NumberedCombinedFx::configure(const NumberedFxState& state) noexcept {
    if(!impl_)return;
    if(impl_->enabled&&sameNumberedFx(impl_->state,state))return;
    const auto* r=recipe(state.index);
    if(!r||!numberedCombinedFxCanRender(state)) {reset();return;}
    Config configs[3];
    for(std::size_t i=0;i<r->count;++i) {
        const auto& b=r->rows[i];configs[b.component].set(b.key,value(state,b.row,b.initial));
    }
    const bool reverse=configs[2].get(Key::Routing)!=0;
    if(!impl_->enabled||impl_->current!=r||impl_->reverse!=reverse) {
        for(auto& part:impl_->parts)part.reset();
        impl_->sixBand.reset();
        impl_->wet=configs[2].get(Key::Wet,100)*.01;
    }
    impl_->parts[0].configure(r->first,configs[0]);
    if(state.index==209){
        NumberedSixBandEq::Config eq;
        eq.trim=configs[1].get(Key::Trim,100)*.01;
        for(unsigned band=0;band<4;++band){
            const auto key=static_cast<unsigned>(Key::Band0Hz)+3*band;
            eq.bands[band].hz=configs[1].get(static_cast<Key>(key),1000);
            eq.bands[band].q=configs[1].get(static_cast<Key>(key+1),1);
            eq.bands[band].gainDb=configs[1].get(static_cast<Key>(key+2));
        }
        const double highPass=value(state,"sv_hp_hz",kNumberedFxChoiceBase);
        const double lowPass=value(state,"sv_lp_hz",kNumberedFxChoiceBase);
        eq.highPassHz=highPass==kNumberedFxChoiceBase?0:highPass;
        eq.lowPassHz=lowPass==kNumberedFxChoiceBase?0:lowPass;
        eq.highPassSlope=static_cast<int>(value(state,"sv_hp_slope"));
        eq.lowPassSlope=static_cast<int>(value(state,"sv_lp_slope"));
        impl_->sixBand.configure(eq);
    }else impl_->parts[1].configure(r->second,configs[1]);
    impl_->state=state;impl_->current=r;impl_->reverse=reverse;impl_->enabled=true;
    impl_->targetWet=configs[2].get(Key::Wet,100)*.01;
}
void NumberedCombinedFx::process(float inL,float inR,float& outL,float& outR) noexcept {
    if(!impl_||!impl_->enabled) {outL=inL;outR=inR;return;}
    inL=finite(inL);inR=finite(inR);
    float l=0,r=0;
    const float mono=(inL+inR)*.5F;
    if(impl_->current->index==209){
        l=inL;r=inR;
        if(impl_->reverse)impl_->sixBand.process(l,r);
        // Link gain using the larger absolute channel peak, not an L+R sum:
        // opposite-polarity stereo must not disappear from the detector.
        // Reuse the existing prepared limiter; no extra allocating instance.
        NumberedDynamics::Modulation detector;
        detector.externalSidechain=true;
        detector.sidechainL=detector.sidechainR=std::max(std::abs(l),std::abs(r));
        auto& limiter=impl_->parts[0];
        limiter.dynamics.process(l,r,l,r,detector);
        l=finite(static_cast<float>(l*limiter.gain));
        r=finite(static_cast<float>(r*limiter.gain));
        if(!impl_->reverse)impl_->sixBand.process(l,r);
    }else if(impl_->current->index==108) {
        auto& reverb=impl_->parts[0];auto& gate=impl_->parts[1];
        reverb.process(mono,l,r);
        l=r=gate.reverbGate(reverb.preDelayed,reverb.rawReverb,reverb.config.get(Key::ReverbBalance,75)*.01);
    } else {
        auto& first=impl_->parts[impl_->reverse?1:0];auto& second=impl_->parts[impl_->reverse?0:1];
        first.process(mono,l,r);second.process((l+r)*.5F,l,r);
    }
    impl_->wet+=(impl_->targetWet-impl_->wet)*impl_->smoothing;
    outL=finite(mix(inL,l,impl_->wet));outR=finite(mix(inR,r,impl_->wet));
}
}
