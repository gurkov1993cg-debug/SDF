#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SourceEffects.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "silveton/sampler/NumberedFx.h"
#include "silveton/sampler/AudioFileLoader.h"
#include "silveton/sampler/SampleStream.h"
#include "silveton/sampler/KorgImporter.h"
#include "silveton/arranger/Pa5xSoundGraph.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include "silveton/sampler/FsCompat.h"
#include <fstream>
#include <limits>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace silveton::sampler {
namespace {

// Preserve the current SOLO identifier; retired engines load as OFF.
EngineType keptEngineType(std::uint8_t t,bool currentEra) noexcept {return currentEra?engineTypeOf(t):EngineType::Off;}

constexpr std::uint32_t kVersion = 19U;   // SILVETON_SET_V19: INSERT and sends of every SILVETON SYNTH place (SILVETON_PLACE_FX_V1)   // SILVETON_SET_V18: OFS of the velocity layers of every sound (SILVETON_OFS_V1)   // SILVETON_SET_V17: velocity curve / compress / attack / crossfade of every sound of an Upper     // SILVETON_SET_V15: TRANSWAVE   // SILVETON_SET_V14: SYNTH bypass   // SILVETON_SET_V13: Polysix functions on samples + modulation matrix   // SILVETON_SET_V12: layers, TONE v2, EQ5, porta modes, FX v3
constexpr std::uint32_t kSampleDecayVersion = 20U;
constexpr std::uint32_t kSourceAmpMark = 0x45415653U; // SVAE
constexpr std::uint32_t kSourceAmpVersion = 3U;
constexpr std::uint32_t kSourceSoundFxMark = 0x46535653U; // SVSF
constexpr std::uint32_t kSourcePortamentoMark = 0x50535653U; // SVSP
constexpr std::uint32_t kSourcePortamentoVersion = 2U;
constexpr std::uint32_t kSourceSoundEditsMark = 0x45535653U; // SVSE
constexpr std::uint32_t kSourceOscillatorDspMark = 0x444F5653U; // SVOD
constexpr std::uint32_t kMaximumSourceOscillatorDspBytes = 512U;
constexpr std::uint32_t kSourceProgramMetadataVersion = 1U;
constexpr std::uint32_t kMaximumSourceAmpRecords = 1000000U;
constexpr std::uint32_t kMaximumSourceSoundFxBytes = 412U;
constexpr std::array<char,8> kMagic{{'S','I','L','V','S','E','T','1'}};

struct Writer {
    std::ofstream f;
    std::string* memory{nullptr};
    bool memoryOkay{true};
    explicit Writer(const silveton::fsx::path& p) : f(p.string(), std::ios::binary) {}
    explicit Writer(std::string& destination) : memory(&destination) {}
    [[nodiscard]] bool ok() const noexcept { return memory?memoryOkay:static_cast<bool>(f); }
    void bytes(const void* p, std::size_t n) {
        if(memory){
            constexpr std::size_t maximum=16U*1024U*1024U;
            if(!memoryOkay||memory->size()>maximum||n>maximum-memory->size()){memoryOkay=false;return;}
            memory->append(static_cast<const char*>(p),n);
        }else f.write(static_cast<const char*>(p), static_cast<std::streamsize>(n));
    }
    void u8(std::uint8_t v) { bytes(&v,1U); }
    void i8(std::int8_t v) { bytes(&v,1U); }
    void u16(std::uint16_t v) { std::array<std::uint8_t,2> b{{static_cast<std::uint8_t>(v), static_cast<std::uint8_t>(v>>8U)}}; bytes(b.data(),2U); }
    void u32(std::uint32_t v) { std::array<std::uint8_t,4> b{{static_cast<std::uint8_t>(v), static_cast<std::uint8_t>(v>>8U), static_cast<std::uint8_t>(v>>16U), static_cast<std::uint8_t>(v>>24U)}}; bytes(b.data(),4U); }
    void f32(float v) { std::uint32_t u=0U; static_assert(sizeof(u)==sizeof(v)); std::memcpy(&u,&v,sizeof(v)); u32(u); }
    void str(const std::string& s) { u32(static_cast<std::uint32_t>(s.size())); if(!s.empty()) bytes(s.data(),s.size()); }
};

struct Reader {
    std::ifstream f;
    std::string error;
    explicit Reader(const silveton::fsx::path& p) : f(p.string(), std::ios::binary) {}
    bool bytes(void* p, std::size_t n) { if(error.empty() && f.read(static_cast<char*>(p), static_cast<std::streamsize>(n))) return true; if(error.empty()) error="Unexpected end of SET manifest"; return false; }
    std::uint8_t u8() { std::uint8_t v=0U; bytes(&v,1U); return v; }
    std::int8_t i8() { std::int8_t v=0; bytes(&v,1U); return v; }
    std::uint16_t u16() { std::array<std::uint8_t,2>b{}; bytes(b.data(),2U); return static_cast<std::uint16_t>(b[0]) | static_cast<std::uint16_t>(static_cast<std::uint16_t>(b[1])<<8U); }
    std::uint32_t u32() { std::array<std::uint8_t,4>b{}; bytes(b.data(),4U); return static_cast<std::uint32_t>(b[0]) | (static_cast<std::uint32_t>(b[1])<<8U) | (static_cast<std::uint32_t>(b[2])<<16U) | (static_cast<std::uint32_t>(b[3])<<24U); }
    // SILVETON_SET_FINITE_V1: a number that is not a number (NaN / infinite) in a file never gets into the state - it would be drawn as a
    // knob with no angle (a crash of the screen) and heard as a note with no pitch. Such a value reads as 0 (every reader clamps after this).
    float f32() { const auto u=u32(); float v=0.0F; std::memcpy(&v,&u,sizeof(v)); return std::isfinite(v)?v:0.0F; }
    std::string str() { const auto n=u32(); if(n>16U*1024U*1024U){ if(error.empty())error="String field too large"; return {}; } std::string s(n,'\0'); if(n>0U)bytes(s.data(),n); return s; }
};

bool hasSourcePortamentoOverride(const Combi& combi) noexcept {
    for(int part=0;part<kPartCount;++part)
        if(combi.part(part).sourceVoiceInherit||!combi.part(part).sourcePortamentoInherit)return true;
    return false;
}

void writeSourcePortamentoInherit(Writer& writer,const Combi& combi){
    for(int part=0;part<kPartCount;++part){
        writer.u8(combi.part(part).sourcePortamentoInherit?1U:0U);
        writer.u8(combi.part(part).sourceVoiceInherit?1U:0U);
    }
}

void writeEnvelope(Writer& w,const EnvelopeParams& p){w.f32(p.attackSec);w.f32(p.decaySec);w.f32(p.sustain);w.f32(p.releaseSec);} 
EnvelopeParams readEnvelope(Reader& r){EnvelopeParams p; p.attackSec=r.f32();p.decaySec=r.f32();p.sustain=r.f32();p.releaseSec=r.f32();return p;}
void writeFilter(Writer& w,const FilterParams& p){w.u8(static_cast<std::uint8_t>(p.mode));w.f32(p.cutoffHz);w.f32(p.resonance);w.f32(p.keyTrack);w.f32(p.velocityAmount);w.f32(p.envelopeAmount);w.f32(p.lfoAmount);} 
FilterParams readFilter(Reader& r){FilterParams p; p.mode=static_cast<FilterMode>(r.u8());p.cutoffHz=r.f32();p.resonance=r.f32();p.keyTrack=r.f32();p.velocityAmount=r.f32();p.envelopeAmount=r.f32();p.lfoAmount=r.f32();return p;}
void writeLfo(Writer&w,const LfoParams&p){w.u8(static_cast<std::uint8_t>(p.wave));w.f32(p.frequencyHz);w.f32(p.delaySec);w.f32(p.fadeSec);w.u8(p.keySync?1U:0U);w.f32(p.pitchCents);w.f32(p.filterOctaves);w.f32(p.ampDepth);} 
LfoParams readLfo(Reader&r){LfoParams p;p.wave=static_cast<LfoWave>(r.u8());p.frequencyHz=r.f32();p.delaySec=r.f32();p.fadeSec=r.f32();p.keySync=r.u8()!=0U;p.pitchCents=r.f32();p.filterOctaves=r.f32();p.ampDepth=r.f32();return p;}
void writeFx(Writer&w,const EffectSlot&p){w.u8(static_cast<std::uint8_t>(p.type));w.f32(p.wet);w.f32(p.timeMs);w.f32(p.feedback);w.f32(p.rateHz);w.f32(p.depth);w.f32(p.tone);
    w.f32(p.preDelayMs);w.f32(p.damping);w.f32(p.size);w.f32(p.mod);w.u8(p.tempoSync?1U:0U);w.f32(p.tempoBpm);w.f32(p.division);w.f32(p.param1);w.f32(p.param2);w.f32(p.param3);}
EffectSlot readFx(Reader&r,std::uint32_t version){EffectSlot p;const auto t=r.u8();p.type=t<static_cast<std::uint8_t>(kEffectTypeCount)?static_cast<EffectType>(t):EffectType::Off;p.wet=r.f32();p.timeMs=r.f32();p.feedback=r.f32();p.rateHz=r.f32();p.depth=r.f32();p.tone=r.f32();
    if(version>=12U){p.preDelayMs=r.f32();p.damping=r.f32();p.size=r.f32();p.mod=r.f32();p.tempoSync=r.u8()!=0U;p.tempoBpm=r.f32();p.division=r.f32();p.param1=r.f32();p.param2=r.f32();p.param3=r.f32();}
    else if(p.type==EffectType::Reverb){p.damping=1.0F-std::clamp(p.tone,0.0F,1.0F);p.tone=0.6F;}   // the old PLATE used TONE as damping
    return p;}

// SVNF is SILVETON semantic state, not a Korg parameter serializer. Its values
// are keyed by stable manual row IDs; absent rows remain explicitly unknown.
// Keep the legacy writeFx/readFx bytes and native-only COMBI identity unchanged.
constexpr std::uint32_t kNumberedFxMark=0x464E5653U; // SVNF
constexpr std::uint32_t kNumberedFxVersion=2U;
constexpr std::size_t kMaximumNumberedFxCombiBytes=128U*1024U;
constexpr std::size_t kMaximumNumberedFxTotalBytes=16U*1024U*1024U;
constexpr std::size_t kMaximumNumberedFxAssignments=65536U;
constexpr int kNumberedFxSlotCount=kFxSendSlots+kPartCount;
constexpr int kNumberedFxModulatingMasterSlots=3; // Official MFX1..3, not native MFX4.

bool numberedFxPresent(const NumberedFxState& state) noexcept {
    return state.schema!=kNumberedFxSchema||state.index!=0||state.knownMask!=0||
        state.origin!=NumberedFxOrigin::Unknown;
}
bool numberedFxModulatingValid(const EffectSlot& effect,int slot) noexcept {
    const int part=effect.numberedModulatingPart;
    // IFX follows its own part; only a non-Bypass MFX1..3 assignment has a selector.
    return part>=-1&&part<=7&&
        (part==-1||(slot<kNumberedFxModulatingMasterSlots&&effect.numbered.index!=0&&
                    numberedFxPresent(effect.numbered)));
}
bool numberedFxRowIdValid(const std::string& id) noexcept {
    return !id.empty()&&id.size()<=63U&&std::all_of(id.begin(),id.end(),[](unsigned char c){
        return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.';
    });
}
const EffectSlot& numberedFxSlot(const Combi& combi,int slot) {
    return slot<kFxSendSlots?combi.fx[static_cast<std::size_t>(slot)]:combi.insertOf(slot-kFxSendSlots);
}
EffectSlot& numberedFxSlot(Combi& combi,int slot) {
    return slot<kFxSendSlots?combi.fx[static_cast<std::size_t>(slot)]:combi.insertOf(slot-kFxSendSlots);
}
std::string encodeNumberedFxCombi(const Combi& combi,std::uint32_t version=kNumberedFxVersion) {
    if(version!=1U&&version!=kNumberedFxVersion)throw std::runtime_error("Invalid numbered FX encoding version");
    unsigned count=0;
    for(int slot=0;slot<kNumberedFxSlotCount;++slot){
        const auto& effect=numberedFxSlot(combi,slot);const auto& state=effect.numbered;
        if(!state.valid()||!numberedFxModulatingValid(effect,slot)||
           (version==1U&&effect.numberedModulatingPart!=-1))
            throw std::runtime_error("Invalid numbered FX state or Modulating Track");
        if(numberedFxPresent(state))++count;
    }
    if(count==0)return {};
    if(combi.sourceEffects)throw std::runtime_error("Original SET FX and manual numbered FX cannot share an owner");
    std::string bytes;Writer out(bytes);out.u8(static_cast<std::uint8_t>(count));
    for(int slot=0;slot<kNumberedFxSlotCount;++slot){
        const auto& effect=numberedFxSlot(combi,slot);const auto& state=effect.numbered;
        if(!numberedFxPresent(state))continue;
        const auto* descriptor=findNumberedFx(state.index);
        if(!descriptor)throw std::runtime_error("Unknown numbered FX identity");
        unsigned known=0;for(std::size_t row=0;row<kNumberedFxValueCount;++row)if(state.known(row))++known;
        out.u8(static_cast<std::uint8_t>(slot));out.u16(state.schema);out.u16(state.index);
        out.u8(static_cast<std::uint8_t>(state.origin));
        // SVNF2: own logical part selector, not a Korg controller/wire value.
        if(version>=2U)out.u8(static_cast<std::uint8_t>(effect.numberedModulatingPart+1));
        out.u8(static_cast<std::uint8_t>(known));
        std::uint64_t written=0;
        for(unsigned row=0;row<descriptor->parameterCount;++row){
            const auto& parameter=descriptor->parameters[row];
            if(parameter.ordinal>=kNumberedFxValueCount||!state.known(parameter.ordinal))continue;
            const auto bit=std::uint64_t{1}<<parameter.ordinal;
            const std::string id=parameter.rowId?parameter.rowId:"";
            if((written&bit)!=0||!numberedFxRowIdValid(id)||
               findNumberedFxParam(state.index,id.c_str())!=&parameter)
                throw std::runtime_error("Invalid numbered FX parameter identity");
            written|=bit;
            out.u8(static_cast<std::uint8_t>(id.size()));out.bytes(id.data(),id.size());
            std::uint64_t bits=0;const double value=state.values[parameter.ordinal];
            static_assert(sizeof(bits)==sizeof(value));std::memcpy(&bits,&value,sizeof(bits));
            out.u32(static_cast<std::uint32_t>(bits));out.u32(static_cast<std::uint32_t>(bits>>32U));
        }
        if(written!=state.knownMask)throw std::runtime_error("Invalid numbered FX known-value mask");
    }
    if(!out.ok()||bytes.size()>kMaximumNumberedFxCombiBytes)
        throw std::runtime_error("Numbered FX metadata is too large");
    return bytes;
}
struct PendingNumberedFx {
    std::size_t owner{0}; // COMBI index; COMBI count identifies the performance.
    unsigned slot{0};
    NumberedFxState state;
    std::int8_t modulatingPart{-1};
};
bool decodeNumberedFxCombi(const std::string& bytes,std::size_t owner,std::uint32_t version,
                          std::vector<PendingNumberedFx>& pending,std::string& error) {
    if(bytes.empty())return true;
    const auto fail=[&](const char* message){error=message;return false;};
    if(bytes.size()>kMaximumNumberedFxCombiBytes)return fail("Numbered FX metadata is too large");
    std::size_t at=0;
    const auto read=[&](unsigned width,std::uint64_t& value){
        if(width>8U||at>bytes.size()||width>bytes.size()-at)return false;
        value=0;for(unsigned i=0;i<width;++i)value|=std::uint64_t{static_cast<unsigned char>(bytes[at++])}<<(8U*i);
        return true;
    };
    std::uint64_t count=0;
    if(!read(1,count)||count==0||count>static_cast<unsigned>(kNumberedFxSlotCount)||
       count>kMaximumNumberedFxAssignments-pending.size())return fail("Invalid numbered FX slot count");
    std::array<bool,kNumberedFxSlotCount> seen{};
    for(std::uint64_t entry=0;entry<count;++entry){
        std::uint64_t slot=0,schema=0,index=0,origin=0,modulating=0,known=0;
        // SVNF1 had no selector and always restores Off.
        if(!read(1,slot)||!read(2,schema)||!read(2,index)||!read(1,origin)||
           (version>=2U&&!read(1,modulating))||!read(1,known)||
           slot>=seen.size()||seen[static_cast<std::size_t>(slot)]||schema!=kNumberedFxSchema||
           origin>static_cast<unsigned>(NumberedFxOrigin::Manual)||known>kNumberedFxValueCount||
           modulating>8U||(modulating!=0U&&(slot>=kNumberedFxModulatingMasterSlots||index==0U)))
            return fail("Invalid numbered FX slot header");
        seen[static_cast<std::size_t>(slot)]=true;
        NumberedFxState state;state.schema=static_cast<std::uint16_t>(schema);state.index=static_cast<std::uint16_t>(index);
        state.origin=static_cast<NumberedFxOrigin>(origin);
        const auto* descriptor=findNumberedFx(state.index);
        if(!descriptor||known>descriptor->parameterCount)return fail("Invalid numbered FX parameter count");
        for(std::uint64_t field=0;field<known;++field){
            std::uint64_t length=0,bits=0;
            if(!read(1,length)||length==0||length>63U||length>bytes.size()-at)
                return fail("Invalid numbered FX parameter ID");
            const std::string id=bytes.substr(at,static_cast<std::size_t>(length));at+=static_cast<std::size_t>(length);
            if(!numberedFxRowIdValid(id)||!read(8,bits))return fail("Invalid numbered FX parameter value");
            const auto* parameter=findNumberedFxParam(state.index,id.c_str());
            if(!parameter||parameter->ordinal>=kNumberedFxValueCount||state.known(parameter->ordinal))
                return fail("Unknown or duplicate numbered FX parameter");
            double value=0;std::memcpy(&value,&bits,sizeof(value));
            // Unlike the legacy f32 reader, never turn non-finite data into zero.
            if(!std::isfinite(value)||!numberedFxValueValid(*parameter,value))
                return fail("Numbered FX parameter is outside its domain");
            state.values[parameter->ordinal]=value;state.knownMask|=std::uint64_t{1}<<parameter->ordinal;
        }
        if(!state.valid()||!numberedFxPresent(state))return fail("Invalid numbered FX state");
        pending.push_back({owner,static_cast<unsigned>(slot),state,
            static_cast<std::int8_t>(static_cast<int>(modulating)-1)});
    }
    return at==bytes.size()||fail("Unexpected trailing numbered FX metadata");
}
void writeToneExtra(Writer&w,const ToneExtra&x){w.f32(x.startMs);w.f32(x.endMs);w.f32(x.filterEnvOctaves);w.f32(x.filterEnvMs);w.f32(x.velToLevel);w.f32(x.velToCutoff);w.f32(x.highPassHz);w.f32(x.lfoRateHz);w.f32(x.lfoDepthCents);w.f32(x.lfoDelayMs);w.f32(x.lfoFadeMs);w.u8(x.lfoModWheel?1U:0U);w.f32(x.eqLowDb);w.f32(x.eqMidDb);w.f32(x.eqHighDb);
    // SILVETON_SET_V13
    w.f32(x.pwmWidth);w.f32(x.pwmDepth);w.f32(x.pwmRateHz);w.f32(x.pwmMix);w.f32(x.subLevel);w.i8(x.subOctave);w.i8(x.unisonVoices);w.f32(x.unisonDetuneCents);w.f32(x.unisonSpread);w.f32(x.drive);w.i8(x.filterType);w.f32(x.filterKeyTrack);w.i8(x.filter2Type);w.f32(x.filter2Hz);w.f32(x.filter2Res);w.u8(x.filter2Parallel?1U:0U);w.u8(x.analogFeel?1U:0U);w.u8(x.synthBypass?1U:0U);
    // SILVETON_SET_V15: TRANSWAVE
    w.i8(x.waveMode);w.i8(x.waveFrames);w.i8(x.waveSource);w.f32(x.wavePos);w.f32(x.waveStart);w.f32(x.waveSpan);w.f32(x.waveSmooth);w.f32(x.waveAmount);w.f32(x.waveTimeMs);w.f32(x.waveRateHz);for(const auto id:x.waveSlot)w.u16(id);
    // SILVETON_SET_V18: OFS of the velocity layers
    for(const auto z:x.zoneStartMs)w.f32(z);}
void writeMod(Writer&w,const ModMatrix&m){for(const auto&r:m.route){w.u8(static_cast<std::uint8_t>(r.source));w.u8(static_cast<std::uint8_t>(r.target));w.f32(r.amount);w.u8(r.bipolar?1U:0U);}}
ModMatrix readMod(Reader&r){ModMatrix m;for(auto&t:m.route){const auto src=r.u8();const auto dst=r.u8();t.source=src<static_cast<std::uint8_t>(kModSourceCount)?static_cast<ModSource>(src):ModSource::Off;t.target=dst<static_cast<std::uint8_t>(kModTargetCount)?static_cast<ModTarget>(dst):ModTarget::Cutoff;t.amount=std::clamp(r.f32(),-1.0F,1.0F);if(!std::isfinite(t.amount))t.amount=0.0F;t.bipolar=r.u8()!=0U;}return m;}
ToneExtra readToneExtra(Reader&r,std::uint32_t version){ToneExtra x;x.startMs=r.f32();x.endMs=r.f32();x.filterEnvOctaves=r.f32();x.filterEnvMs=r.f32();x.velToLevel=r.f32();x.velToCutoff=r.f32();x.highPassHz=r.f32();x.lfoRateHz=r.f32();x.lfoDepthCents=r.f32();x.lfoDelayMs=r.f32();x.lfoFadeMs=r.f32();x.lfoModWheel=r.u8()!=0U;x.eqLowDb=r.f32();x.eqMidDb=r.f32();x.eqHighDb=r.f32();
    if(version>=13U){x.pwmWidth=std::clamp(r.f32(),0.0F,0.98F);x.pwmDepth=std::clamp(r.f32(),0.0F,0.45F);x.pwmRateHz=std::clamp(r.f32(),0.02F,20.0F);x.pwmMix=std::clamp(r.f32(),0.0F,1.0F);x.subLevel=std::clamp(r.f32(),0.0F,1.0F);x.subOctave=static_cast<std::int8_t>(std::clamp<int>(r.i8(),1,2));x.unisonVoices=static_cast<std::int8_t>(std::clamp<int>(r.i8(),1,4));x.unisonDetuneCents=std::clamp(r.f32(),0.0F,100.0F);x.unisonSpread=std::clamp(r.f32(),0.0F,1.0F);x.drive=std::clamp(r.f32(),0.0F,1.0F);x.filterType=static_cast<std::int8_t>(std::clamp<int>(r.i8(),0,2));x.filterKeyTrack=std::clamp(r.f32(),-1.0F,1.0F);x.filter2Type=static_cast<std::int8_t>(std::clamp<int>(r.i8(),0,4));x.filter2Hz=std::clamp(r.f32(),20.0F,20000.0F);x.filter2Res=std::clamp(r.f32(),0.0F,1.0F);x.filter2Parallel=r.u8()!=0U;x.analogFeel=r.u8()!=0U;if(version>=14U)x.synthBypass=r.u8()!=0U;
        const auto fin=[](float&v,float d){if(!std::isfinite(v))v=d;};fin(x.pwmWidth,0.0F);fin(x.pwmDepth,0.0F);fin(x.pwmRateHz,0.5F);fin(x.pwmMix,1.0F);fin(x.subLevel,0.0F);fin(x.unisonDetuneCents,8.0F);fin(x.unisonSpread,0.5F);fin(x.drive,0.0F);fin(x.filterKeyTrack,0.0F);fin(x.filter2Hz,1000.0F);fin(x.filter2Res,0.0F);}
    if(version>=15U){x.waveMode=static_cast<std::int8_t>(std::clamp<int>(r.i8(),0,2));x.waveFrames=static_cast<std::int8_t>(std::clamp<int>(r.i8(),2,32));x.waveSource=static_cast<std::int8_t>(std::clamp<int>(r.i8(),0,6));
        x.wavePos=std::clamp(r.f32(),0.0F,1.0F);x.waveStart=std::clamp(r.f32(),0.0F,1.0F);x.waveSpan=std::clamp(r.f32(),0.0F,1.0F);x.waveSmooth=std::clamp(r.f32(),0.0F,1.0F);x.waveAmount=std::clamp(r.f32(),-1.0F,1.0F);x.waveTimeMs=std::clamp(r.f32(),10.0F,20000.0F);x.waveRateHz=std::clamp(r.f32(),0.02F,30.0F);
        for(auto&id:x.waveSlot){const auto v=r.u16();id=(v<=kFixedSoundSlotCount||(v>=kBuiltinWaveFirstSlot&&v<kBuiltinWaveFirstSlot+static_cast<std::uint16_t>(kBuiltinWaveCount)))?v:static_cast<std::uint16_t>(0U);}
        const auto fw=[](float&v,float d){if(!std::isfinite(v))v=d;};fw(x.wavePos,0.0F);fw(x.waveStart,0.0F);fw(x.waveSpan,1.0F);fw(x.waveSmooth,1.0F);fw(x.waveAmount,0.5F);fw(x.waveTimeMs,1500.0F);fw(x.waveRateHz,0.5F);}
    if(version>=18U){for(auto&z:x.zoneStartMs){const float v=r.f32();z=(std::isfinite(v)&&v>=0.0F)?std::min(v,kToneMaxStartMs):-1.0F;}}   // SILVETON_SET_V18
    const auto fin=[](float&v,float d){if(!std::isfinite(v))v=d;};fin(x.startMs,0.0F);fin(x.endMs,0.0F);fin(x.filterEnvOctaves,0.0F);fin(x.filterEnvMs,120.0F);fin(x.velToLevel,1.0F);fin(x.velToCutoff,0.0F);fin(x.highPassHz,0.0F);fin(x.lfoRateHz,5.5F);fin(x.lfoDepthCents,0.0F);fin(x.lfoDelayMs,0.0F);fin(x.lfoFadeMs,300.0F);fin(x.eqLowDb,0.0F);fin(x.eqMidDb,0.0F);fin(x.eqHighDb,0.0F);return x;}
void writeSoundTone(Writer&w,const SoundTone&t){w.f32(t.attackMs);w.f32(t.decayMs);w.f32(t.sustain);w.f32(t.releaseMs);w.f32(t.cutoffHz);w.f32(t.resonance);writeToneExtra(w,t.x);writeMod(w,t.mod);}
SoundTone readSoundTone(Reader&r,std::uint32_t version){SoundTone t;const auto tone=[&r](float hi){const float v=r.f32();return(std::isfinite(v)&&v>=0.0F)?std::min(v,hi):-1.0F;};
    t.attackMs=tone(kToneMaxTimeMs);t.decayMs=tone(kToneMaxTimeMs);t.sustain=tone(1.0F);t.releaseMs=tone(kToneMaxTimeMs);t.cutoffHz=tone(kToneCutoffOpenHz);t.resonance=tone(1.0F);t.x=readToneExtra(r,version);if(version>=13U)t.mod=readMod(r);return t;}
void writeEq(Writer&w,const UpperEq&e){w.u8(e.on?1U:0U);for(const auto&b:e.band){w.u8(b.on?1U:0U);w.f32(b.freqHz);w.f32(b.gainDb);w.f32(b.q);}w.u8(e.hpOn?1U:0U);w.f32(e.hpHz);w.u8(e.hpSlopeDb);w.u8(e.lpOn?1U:0U);w.f32(e.lpHz);w.u8(e.lpSlopeDb);}
UpperEq readEq(Reader&r){UpperEq e;e.on=r.u8()!=0U;for(auto&b:e.band){b.on=r.u8()!=0U;b.freqHz=std::clamp(r.f32(),20.0F,20000.0F);b.gainDb=std::clamp(r.f32(),-18.0F,18.0F);b.q=std::clamp(r.f32(),0.1F,10.0F);}
    e.hpOn=r.u8()!=0U;e.hpHz=std::clamp(r.f32(),10.0F,2000.0F);e.hpSlopeDb=r.u8()>=24U?24U:12U;e.lpOn=r.u8()!=0U;e.lpHz=std::clamp(r.f32(),1000.0F,20000.0F);e.lpSlopeDb=r.u8()>=24U?24U:12U;return e;}
void writeAddress(Writer&w,const SlotAddress&a){w.u16(a.bank);w.u16(a.page);w.u16(a.slot);} 
SlotAddress readAddress(Reader&r){return {r.u16(),r.u16(),r.u16()};}

bool writeFloatWav(const silveton::fsx::path& p,const SampleData& s,std::string& error) {
    const auto fail=[&](const char* message){error=message;return false;};
    if(!s.valid()||s.interleaved.size()%s.channels!=0U)return fail("Invalid embedded sample metadata");
    const auto frames=s.frameCount(),resident=s.preloadedFrameCount();
    const auto frameBytes=static_cast<std::uint64_t>(s.channels)*sizeof(float);
    if(resident>frames||frames>(std::numeric_limits<std::uint32_t>::max()-36U)/frameBytes||
       s.sampleRate>std::numeric_limits<std::uint32_t>::max()/frameBytes)
        return fail("Embedded sample exceeds the supported WAV size or rate");
    RawPcmView raw;
    if(resident<frames){
        if(!s.stream||s.stream->frameCount()<frames||s.stream->channels()!=s.channels||s.stream->sampleRate()!=s.sampleRate)
            return fail("Embedded sample has no complete source for its remaining frames");
        raw=s.stream->rawView();
        // This is the synchronous, bounded mapping of the complete recording.
        // Never export through a realtime readFrame fallback that can return
        // silence for a missing page, or save only the resident attack prefix.
        if(!raw.data||raw.frames<frames||raw.channels!=s.channels||raw.bytesPerSample()==0U||
           frames>std::numeric_limits<std::size_t>::max()/raw.frameBytes())
            return fail("Embedded sample has no complete synchronous PCM view");
        const auto bytes=static_cast<std::size_t>(frames)*raw.frameBytes();
        if(bytes>std::numeric_limits<std::uintptr_t>::max()-reinterpret_cast<std::uintptr_t>(raw.data))
            return fail("Embedded sample PCM view exceeds addressable memory");
    }
    std::ofstream f(p.string(),std::ios::binary);if(!f)return fail("Cannot create embedded sample WAV");
    const auto dataBytes=static_cast<std::uint32_t>(frames*frameBytes);
    const std::uint32_t riffSize=4U+(8U+16U)+(8U+dataBytes);
    auto le16=[&](std::uint16_t v){std::array<char,2>b{{static_cast<char>(v&0xFFU),static_cast<char>((v>>8U)&0xFFU)}};f.write(b.data(),2);};
    auto le32=[&](std::uint32_t v){std::array<char,4>b{{static_cast<char>(v&0xFFU),static_cast<char>((v>>8U)&0xFFU),static_cast<char>((v>>16U)&0xFFU),static_cast<char>((v>>24U)&0xFFU)}};f.write(b.data(),4);};
    f.write("RIFF",4);le32(riffSize);f.write("WAVE",4);f.write("fmt ",4);le32(16U);le16(3U);le16(s.channels);le32(s.sampleRate);le32(s.sampleRate*static_cast<std::uint32_t>(s.channels)*4U);le16(static_cast<std::uint16_t>(s.channels*4U));le16(32U);f.write("data",4);le32(dataBytes);
    std::array<char,32768U> buffer{};std::size_t used=0U;
    for(std::uint64_t frame=0U;frame<frames;++frame)for(std::uint16_t channel=0U;channel<s.channels;++channel){
        float value=0.0F;
        if(frame<resident)value=s.interleaved[static_cast<std::size_t>(frame)*s.channels+channel];
        else{
            const auto* input=raw.data+static_cast<std::size_t>(frame)*raw.frameBytes()+channel*raw.bytesPerSample();
            std::uint32_t bits=static_cast<std::uint32_t>(input[0])|(static_cast<std::uint32_t>(input[1])<<8U);
            if(raw.format==RawPcmView::kPcm16){
                const auto signedValue=bits<32768U?static_cast<std::int32_t>(bits):static_cast<std::int32_t>(bits)-65536;
                value=static_cast<float>(signedValue)/32768.0F;
            }else{
                bits|=static_cast<std::uint32_t>(input[2])<<16U;
                if(raw.format==RawPcmView::kPcm24){
                    const auto signedValue=bits<8388608U?static_cast<std::int32_t>(bits):static_cast<std::int32_t>(bits)-16777216;
                    value=static_cast<float>(signedValue)/8388608.0F;
                }else{
                    bits|=static_cast<std::uint32_t>(input[3])<<24U;std::memcpy(&value,&bits,sizeof(value));
                }
            }
        }
        if(!std::isfinite(value))return fail("Embedded sample contains non-finite audio");
        std::uint32_t bits=0U;std::memcpy(&bits,&value,sizeof(value));
        for(unsigned shift=0U;shift<32U;shift+=8U)buffer[used++]=static_cast<char>(bits>>shift);
        if(used==buffer.size()){f.write(buffer.data(),static_cast<std::streamsize>(used));used=0U;
            if(!f)return fail("Failed to write complete embedded sample audio");}
    }
    if(used!=0U)f.write(buffer.data(),static_cast<std::streamsize>(used));
    f.flush();if(!f)return fail("Failed to finish embedded sample WAV");
    error.clear();return true;
}

SamplePtr loadAsset(const silveton::fsx::path& p,std::string& error) {
    auto ext=p.extension().string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    if(ext==".ksf"){auto r=KorgImporter::loadKsfStreaming(p.string()); if(!r.ok()){error=r.error;return nullptr;} return r.sample;}
    AudioLoadResult r;
    if(ext==".wav"||ext==".wave") r=AudioFileLoader::loadWavStreaming(p.string());
    else if(ext==".aif"||ext==".aiff"||ext==".aifc") r=AudioFileLoader::loadAiffStreaming(p.string());
    else r=AudioFileLoader::load(p.string());
    if(!r.ok()){error=r.error;return nullptr;}return r.sample;
}

struct Graph {
    std::vector<SamplePtr> samples;
    std::vector<MultisamplePtr> multisamples;
    std::vector<ProgramPtr> programs;
    std::unordered_map<const SampleData*,std::uint32_t> sampleIds;
    std::unordered_map<const Multisample*,std::uint32_t> multisampleIds;
    std::unordered_map<const Program*,std::uint32_t> programIds;

    std::uint32_t addSample(const SamplePtr& p){if(!p)return 0xFFFFFFFFU;auto it=sampleIds.find(p.get());if(it!=sampleIds.end())return it->second;auto id=static_cast<std::uint32_t>(samples.size());samples.push_back(p);sampleIds.emplace(p.get(),id);return id;}
    std::uint32_t addMs(const MultisamplePtr& p){if(!p)return 0xFFFFFFFFU;auto it=multisampleIds.find(p.get());if(it!=multisampleIds.end())return it->second;auto id=static_cast<std::uint32_t>(multisamples.size());multisamples.push_back(p);multisampleIds.emplace(p.get(),id);for(const auto&z:p->zones)addSample(z.sample);return id;}
    std::uint32_t addProgram(const ProgramPtr& p){if(!p)return 0xFFFFFFFFU;auto it=programIds.find(p.get());if(it!=programIds.end())return it->second;auto id=static_cast<std::uint32_t>(programs.size());programs.push_back(p);programIds.emplace(p.get(),id);for(const auto&l:p->layers)addMs(l.multisample);return id;}
};

void writeGlobal(Writer&w,const GlobalState&g){
    w.f32(g.masterTuneHz);w.i8(g.transposeSemitones);w.f32(g.masterGainDb);w.f32(g.eqLowDb);w.f32(g.eqMidDb);w.f32(g.eqHighDb);w.u8(g.limiterEnabled?1U:0U);w.f32(g.limiterCeilingDb);w.u8(g.velocityCurve);w.u8(g.breathCc);w.u8(g.expressionCc);w.u8(g.damperCc);w.u8(g.pitchBendEnabled?1U:0U);w.u8(g.aftertouchEnabled?1U:0U);
    w.u8(g.scaleRoot);for(float cents:g.scaleOffsetsCents)w.f32(cents);
    w.u16(g.midiInputChannelMask);w.u8(g.filterNotes?1U:0U);w.u8(g.filterControlChange?1U:0U);w.u8(g.filterPitchBend?1U:0U);w.u8(g.filterAftertouch?1U:0U);
    w.f32(g.breathMin);w.f32(g.breathMax);w.f32(g.breathCurve);w.f32(g.expressionMin);w.f32(g.expressionMax);w.f32(g.expressionCurve);w.u8(g.damperPolarityReversed?1U:0U);
}
GlobalState readGlobal(Reader&r,std::uint32_t version){
    GlobalState g;g.masterTuneHz=r.f32();g.transposeSemitones=r.i8();g.masterGainDb=r.f32();g.eqLowDb=r.f32();g.eqMidDb=r.f32();g.eqHighDb=r.f32();g.limiterEnabled=r.u8()!=0U;g.limiterCeilingDb=r.f32();g.velocityCurve=r.u8();
    if(version>=3U){g.breathCc=r.u8();g.expressionCc=r.u8();g.damperCc=r.u8();g.pitchBendEnabled=r.u8()!=0U;g.aftertouchEnabled=r.u8()!=0U;}
    if(version>=5U){
        g.scaleRoot=static_cast<std::uint8_t>(r.u8()%12U);for(float& cents:g.scaleOffsetsCents)cents=std::clamp(r.f32(),-100.0F,100.0F);
        g.midiInputChannelMask=r.u16();g.filterNotes=r.u8()!=0U;g.filterControlChange=r.u8()!=0U;g.filterPitchBend=r.u8()!=0U;g.filterAftertouch=r.u8()!=0U;
        g.breathMin=std::clamp(r.f32(),0.0F,1.0F);g.breathMax=std::clamp(r.f32(),0.0F,1.0F);g.breathCurve=std::clamp(r.f32(),0.1F,8.0F);
        g.expressionMin=std::clamp(r.f32(),0.0F,1.0F);g.expressionMax=std::clamp(r.f32(),0.0F,1.0F);g.expressionCurve=std::clamp(r.f32(),0.1F,8.0F);g.damperPolarityReversed=r.u8()!=0U;
        if(g.breathMax<=g.breathMin)g.breathMax=std::min(1.0F,g.breathMin+0.0001F);
        if(g.expressionMax<=g.expressionMin)g.expressionMax=std::min(1.0F,g.expressionMin+0.0001F);
    }
    return g;
}

void writeSampleDecay(Writer& w, const SampleDecayEnvelope& env) {
    w.f32(env.start);
    if (!env.enabled()) return;
    for (auto level : env.targets) w.f32(level);
    for (auto sec : env.seconds) w.f32(sec);
}
void readSampleDecay(Reader& r, SampleDecayEnvelope& env) {
    env.start = r.f32();
    if (env.enabled()) {
        for (auto& level : env.targets) level = r.f32();
        for (auto& sec : env.seconds) sec = r.f32();
    }
    if (!env.valid()) r.error = "Invalid sampled instrument envelope";
}
void writeProgramBody(Writer&w,const Program&p,const Graph&g,std::uint32_t version){w.str(p.name);w.u8(p.mono?1U:0U);w.u8(p.legato?1U:0U);w.f32(p.portamentoSec);w.u32(static_cast<std::uint32_t>(p.layers.size()));for(const auto&l:p.layers){w.str(l.name);const auto it=g.multisampleIds.find(l.multisample.get());w.u32(it==g.multisampleIds.end()?0xFFFFFFFFU:it->second);w.u8(l.enabled?1U:0U);w.u8(l.keyLow);w.u8(l.keyHigh);w.u8(l.velocityLow);w.u8(l.velocityHigh);w.i8(l.transposeSemitones);w.f32(l.tuneCents);w.f32(l.levelDb);w.f32(l.pan);w.u8(l.velocityFadeIn);w.u8(l.velocityFadeOut);w.f32(l.delaySec);w.u8(l.damperEnabled?1U:0U);writeEnvelope(w,l.ampEnvelope);writeEnvelope(w,l.filterEnvelope);writeEnvelope(w,l.pitchEnvelope);w.f32(l.pitchEnvelopeCents);writeFilter(w,l.filter);writeLfo(w,l.lfo1);writeLfo(w,l.lfo2);if(version>=kSampleDecayVersion)writeSampleDecay(w,l.sampleDecay);}}

ProgramPtr readProgramBody(Reader&r,const std::vector<MultisamplePtr>&ms,std::uint32_t version){auto p=std::make_shared<Program>();p->name=r.str();p->mono=r.u8()!=0U;p->legato=r.u8()!=0U;p->portamentoSec=r.f32();const auto n=r.u32();if(n>10000U){r.error="Program layer count too large";return nullptr;}p->layers.reserve(n);for(std::uint32_t i=0U;i<n;++i){ProgramLayer l;l.name=r.str();const auto id=r.u32();if(id<ms.size())l.multisample=ms[id];l.enabled=r.u8()!=0U;l.keyLow=r.u8();l.keyHigh=r.u8();l.velocityLow=r.u8();l.velocityHigh=r.u8();l.transposeSemitones=r.i8();l.tuneCents=r.f32();l.levelDb=r.f32();l.pan=r.f32();if(version>=7U){l.velocityFadeIn=r.u8();l.velocityFadeOut=r.u8();l.delaySec=r.f32();l.damperEnabled=r.u8()!=0U;}l.ampEnvelope=readEnvelope(r);l.filterEnvelope=readEnvelope(r);l.pitchEnvelope=readEnvelope(r);l.pitchEnvelopeCents=r.f32();l.filter=readFilter(r);l.lfo1=readLfo(r);l.lfo2=readLfo(r);if(version>=kSampleDecayVersion)readSampleDecay(r,l.sampleDecay);p->layers.push_back(l);}return p;}

void writeDrumKeyGroups(Writer& w,const DrumKeyGroups& groups){
    for(const auto& key:groups){
        w.u8(key.exclusiveGroup);w.u8(key.singleTrigger?1U:0U);
        w.f32(key.chokeFadeOutMs);w.u8(key.subgroupChokeOff?1U:0U);
    }
}
std::shared_ptr<const DrumKeyGroups> readDrumKeyGroups(Reader& r){
    auto groups=std::make_shared<DrumKeyGroups>();
    for(auto& key:*groups){
        key.exclusiveGroup=r.u8();const auto single=r.u8();
        // Unlike legacy tone fields, invalid group times must fail loading,
        // not silently turn a damaged value into an immediate choke.
        const auto bits=r.u32();std::memcpy(&key.chokeFadeOutMs,&bits,sizeof(bits));
        const auto subgroup=r.u8();key.singleTrigger=single!=0U;key.subgroupChokeOff=subgroup!=0U;
        if(!r.error.empty())return {};
        if(single>1U||subgroup>1U||!key.valid()){r.error="Invalid Drum Kit group settings";return {};}
    }
    return groups;
}

// SILVETON_SET_V17: the velocity shape of one sound (curve, the nine custom points, compress, velocity -> attack, crossfade)
void writeVelocityShape(Writer&w,const VelocityShape&s){w.u8(s.curve);for(const auto p:s.custom)w.u8(p);w.f32(s.compress);w.f32(s.toAttack);w.u8(s.crossfade?1U:0U);}
VelocityShape readVelocityShape(Reader&r){VelocityShape s;const auto c=r.u8();s.curve=c<kVelocityCurveTypes?c:0U;for(auto&p:s.custom)p=static_cast<std::uint8_t>(std::min<unsigned>(r.u8(),127U));
    const float comp=r.f32();s.compress=std::isfinite(comp)?std::clamp(comp,-1.0F,1.0F):0.0F;const float att=r.f32();s.toAttack=std::isfinite(att)?std::clamp(att,0.0F,1.0F):0.0F;s.crossfade=r.u8()!=0U;return s;}

void writeUpper(Writer&w,const UpperPart&u,const Graph&g){
    w.str(u.name);const auto it=g.programIds.find(u.program.get());w.u32(it==g.programIds.end()?0xFFFFFFFFU:it->second);w.u16(u.soundSlotId);
    w.u8(u.enabled?1U:0U);w.u8(u.mute?1U:0U);w.u8(u.solo?1U:0U);w.u8(u.keyLow);w.u8(u.keyHigh);w.u8(u.velocityLow);w.u8(u.velocityHigh);
    w.f32(u.levelDb);w.f32(u.pan);w.i8(u.transposeSemitones);w.f32(u.tuneCents);w.i8(u.octave);w.i8(u.pitchBendRange);
    w.u8(u.damperEnabled?1U:0U);w.u8(u.expressionEnabled?1U:0U);w.u8(u.breathEnabled?1U:0U);w.u8(u.aftertouchEnabled?1U:0U);w.u8(u.midiChannel);
    w.f32(u.eqLowDb);w.f32(u.eqMidDb);w.f32(u.eqHighDb);w.f32(u.fxSend1);w.f32(u.fxSend2);
    w.f32(u.ampAttackScale);w.f32(u.ampDecayScale);w.f32(u.ampReleaseScale);w.f32(u.filterCutoffOctaves);w.f32(u.filterResonanceOffset);w.f32(u.lfoRateScale);w.f32(u.lfoDepthScale);w.f32(u.portamentoSec);
    w.f32(u.ampSustainScale);w.u8(static_cast<std::uint8_t>(u.voiceMode));
    w.f32(u.toneAttackMs);w.f32(u.toneDecayMs);w.f32(u.toneSustain);w.f32(u.toneReleaseMs);w.f32(u.toneCutoffHz);w.f32(u.toneResonance);
    for(const auto&route:u.controllerRoutes){w.u8(static_cast<std::uint8_t>(route.source));w.u8(static_cast<std::uint8_t>(route.destination));w.u8(route.cc);w.f32(route.amount);w.u8(route.bipolar?1U:0U);}
    // SILVETON_SET_V12
    writeToneExtra(w,u.toneExtra);writeMod(w,u.toneMod);
    for(const auto&l:u.layers){w.u8(l.enabled?1U:0U);w.str(l.name);const auto lit=g.programIds.find(l.program.get());w.u32(lit==g.programIds.end()?0xFFFFFFFFU:lit->second);w.u16(l.soundSlotId);
        w.f32(l.levelDb);w.f32(l.pan);w.i8(l.transposeSemitones);w.i8(l.octave);w.f32(l.tuneCents);w.u8(l.keyLow);w.u8(l.keyHigh);w.u8(l.velocityLow);w.u8(l.velocityHigh);writeSoundTone(w,l.tone);
        w.u8(l.velocityFadeIn);w.u8(l.velocityFadeOut);w.f32(l.velocityResponse);}
    writeEq(w,u.eq);
    w.u8(static_cast<std::uint8_t>(u.portaMode));w.u8(u.portaFingered?1U:0U);w.u8(u.portaRateMode?1U:0U);w.u8(u.portaTime);w.f32(u.fxSend3);w.f32(u.fxSend4);
    w.u8(u.velocityFadeIn);w.u8(u.velocityFadeOut);w.f32(u.velocityResponse);
    w.u8(static_cast<std::uint8_t>(u.oscillatorMode));w.u8(u.independentLayerRanges?1U:0U);
    writeVelocityShape(w,u.velocityShape);for(const auto&l:u.layers)writeVelocityShape(w,l.velocityShape);   // SILVETON_SET_V17
}

UpperPart readUpper(Reader&r,const std::vector<ProgramPtr>&p,std::uint32_t version,bool strictProgramRefs=false){
    UpperPart u;u.sourceVoiceInherit=false;u.name=r.str();const auto id=r.u32();if(id<p.size())u.program=p[id];else if(strictProgramRefs&&id!=0xFFFFFFFFU&&r.error.empty())r.error="Invalid full engine-slot Program reference";if(version>=10U)u.soundSlotId=r.u16();
    u.enabled=r.u8()!=0U;u.mute=r.u8()!=0U;u.solo=r.u8()!=0U;u.keyLow=r.u8();u.keyHigh=r.u8();u.velocityLow=r.u8();u.velocityHigh=r.u8();
    u.levelDb=r.f32();u.pan=r.f32();u.transposeSemitones=r.i8();u.tuneCents=r.f32();u.octave=r.i8();u.pitchBendRange=r.i8();
    u.damperEnabled=r.u8()!=0U;u.expressionEnabled=r.u8()!=0U;u.breathEnabled=r.u8()!=0U;u.aftertouchEnabled=r.u8()!=0U;u.midiChannel=r.u8();
    u.eqLowDb=r.f32();u.eqMidDb=r.f32();u.eqHighDb=r.f32();u.fxSend1=r.f32();u.fxSend2=r.f32();
    if(version>=2U){u.ampAttackScale=r.f32();u.ampDecayScale=r.f32();u.ampReleaseScale=r.f32();u.filterCutoffOctaves=r.f32();u.filterResonanceOffset=r.f32();u.lfoRateScale=r.f32();u.lfoDepthScale=r.f32();u.portamentoSec=r.f32();}
    if(version>=9U){u.ampSustainScale=std::clamp(r.f32(),0.0F,2.0F);const auto vm=r.u8();u.voiceMode=vm<=static_cast<std::uint8_t>(UpperVoiceMode::Legato)?static_cast<UpperVoiceMode>(vm):UpperVoiceMode::Poly;}
    else if(u.program!=nullptr){u.voiceMode=u.program->legato?UpperVoiceMode::Legato:(u.program->mono?UpperVoiceMode::Mono:UpperVoiceMode::Poly);if(version<2U)u.portamentoSec=u.program->portamentoSec;}
    if(version>=11U){
        const auto tone=[&r](float hi){const float v=r.f32();return(std::isfinite(v)&&v>=0.0F)?std::min(v,hi):-1.0F;};
        u.toneAttackMs=tone(kToneMaxTimeMs);u.toneDecayMs=tone(kToneMaxTimeMs);u.toneSustain=tone(1.0F);u.toneReleaseMs=tone(kToneMaxTimeMs);
        u.toneCutoffHz=tone(kToneCutoffOpenHz);u.toneResonance=tone(1.0F);
    }
    if(version>=6U){for(auto&route:u.controllerRoutes){route.source=static_cast<ControllerSource>(r.u8());route.destination=static_cast<ModDestination>(r.u8());route.cc=static_cast<std::uint8_t>(r.u8()&0x7FU);route.amount=r.f32();route.bipolar=r.u8()!=0U;}}
    if(version>=12U){
        u.toneExtra=readToneExtra(r,version);if(version>=13U)u.toneMod=readMod(r);
        for(auto&l:u.layers){l.enabled=r.u8()!=0U;l.name=r.str();const auto lid=r.u32();if(lid<p.size())l.program=p[lid];else if(strictProgramRefs&&lid!=0xFFFFFFFFU&&r.error.empty())r.error="Invalid full engine-slot layer Program reference";l.soundSlotId=r.u16();
            l.levelDb=std::clamp(r.f32(),-60.0F,24.0F);l.pan=std::clamp(r.f32(),-1.0F,1.0F);l.transposeSemitones=r.i8();l.octave=r.i8();l.tuneCents=r.f32();l.keyLow=r.u8();l.keyHigh=r.u8();l.velocityLow=r.u8();l.velocityHigh=r.u8();l.tone=readSoundTone(r,version);
            if(version>=16U){l.velocityFadeIn=static_cast<std::uint8_t>(std::min<unsigned>(r.u8(),127U));l.velocityFadeOut=static_cast<std::uint8_t>(std::min<unsigned>(r.u8(),127U));l.velocityResponse=std::clamp(r.f32(),0.25F,4.0F);}}
        u.eq=readEq(r);
        const auto pm=r.u8();u.portaMode=pm==1U?PortamentoMode::Kronos:(pm==2U&&version>=16U?PortamentoMode::Instrument:(pm==3U&&version>=17U?PortamentoMode::Bass:PortamentoMode::Silveton));u.portaFingered=r.u8()!=0U;u.portaRateMode=r.u8()!=0U;u.portaTime=static_cast<std::uint8_t>(std::min<unsigned>(r.u8(),127U));
        u.fxSend3=std::clamp(r.f32(),0.0F,1.0F);u.fxSend4=std::clamp(r.f32(),0.0F,1.0F);
        if(version>=16U){u.velocityFadeIn=static_cast<std::uint8_t>(std::min<unsigned>(r.u8(),127U));u.velocityFadeOut=static_cast<std::uint8_t>(std::min<unsigned>(r.u8(),127U));u.velocityResponse=std::clamp(r.f32(),0.25F,4.0F);
            const auto category=r.u8();u.oscillatorMode=category<=6U?static_cast<OscillatorMode>(category):OscillatorMode::Neutral;
            u.independentLayerRanges=r.u8()!=0U;
            if(version>=17U){u.velocityShape=readVelocityShape(r);for(auto&l:u.layers)l.velocityShape=readVelocityShape(r);}}   // SILVETON_SET_V17
        else u.independentLayerRanges=false;
    } else {
        u.independentLayerRanges=false;
        // an old BLEND: its LOW / MID / HIGH become bands 1 / 3 / 5 of the new EQ
        u.eq.band[0].gainDb=std::clamp(u.eqLowDb,-18.0F,18.0F);u.eq.band[2].gainDb=std::clamp(u.eqMidDb,-18.0F,18.0F);u.eq.band[4].gainDb=std::clamp(u.eqHighDb,-18.0F,18.0F);
    }
    return u;
}

// SVEP completes stored engine-slot snapshots without changing SVES/SVEF or
// the legacy COMBI body. SVSM/SVSS/SVMX/SVGT still own their auxiliary fields.
constexpr std::uint32_t kEngineSnapshotMark=0x50455653U; // SVEP
constexpr std::uint32_t kEngineSnapshotVersion=1U;
constexpr std::uint32_t kEngineSnapshotUpperVersion=19U;
struct PendingEngineSnapshot {
    std::size_t owner{};
    std::size_t slot{};
    UpperPart upper;
    EffectSlot insert;
};

void writeEngineSnapshot(Writer& w,const UpperPart& upper,const EffectSlot& insert,const Graph& graph){
    writeUpper(w,upper,graph);
    w.f32(upper.evenDecayMs);
    w.u8(static_cast<std::uint8_t>(upper.engine.type));
    const int count=engineStoredCount(upper.engine);
    w.u16(static_cast<std::uint16_t>(count));
    for(int k=0;k<count;++k)w.f32(upper.engine.p[static_cast<std::size_t>(k)]);
    // Keep native parameter values even while this insert is Off. Numbered FX
    // remain in SVNF and are committed after this native snapshot is merged.
    writeFx(w,insert);
}

PendingEngineSnapshot readEngineSnapshot(Reader& r,const std::vector<ProgramPtr>& programs){
    PendingEngineSnapshot snapshot;
    snapshot.upper=readUpper(r,programs,kEngineSnapshotUpperVersion,true);
    if(!r.error.empty())return snapshot;
    const float decay=r.f32();
    snapshot.upper.evenDecayMs=decay>=30.0F?std::min(decay,10000.0F):0.0F;
    auto& engine=snapshot.upper.engine;
    engine=engineDefaults(keptEngineType(r.u8(),true));
    const auto count=r.u16();
    if(count>4096U){r.error="Invalid engine in full engine-slot snapshot";return snapshot;}
    for(std::uint16_t k=0;k<count&&r.error.empty();++k){
        const float value=r.f32();
        if(k<kEngineParamCount)engine.p[k]=engineClamp(engine.type,static_cast<int>(k),value);
    }
    engineSanitizeLoaded(engine);
    snapshot.insert=readFx(r,kEngineSnapshotUpperVersion);
    return snapshot;
}

void mergeEngineSnapshot(Combi& combi,PendingEngineSnapshot& snapshot){
    auto& previous=combi.engineSlots[snapshot.slot];
    auto& upper=snapshot.upper;
    upper.commonProcessing=previous.commonProcessing;
    upper.soloModel=previous.soloModel;
    upper.sourceVolumeRaw=previous.sourceVolumeRaw;
    upper.sourcePanRaw=previous.sourcePanRaw;
    upper.sourceExpressionRaw=previous.sourceExpressionRaw;
    upper.sourceCoarseTuneRaw=previous.sourceCoarseTuneRaw;
    upper.sourceFineTuneRaw=previous.sourceFineTuneRaw;
    upper.sourceSoundEdits=previous.sourceSoundEdits;
    upper.channelGate=previous.channelGate;
    for(std::size_t layer=0;layer<upper.layers.size();++layer){
        upper.layers[layer].engine=previous.layers[layer].engine;
        upper.layers[layer].soloModel=previous.layers[layer].soloModel;
        upper.layers[layer].commonProcessing=previous.layers[layer].commonProcessing;
    }
    auto& previousInsert=combi.engineInsert[snapshot.slot];
    snapshot.insert.numbered=previousInsert.numbered;
    snapshot.insert.numberedModulatingPart=previousInsert.numberedModulatingPart;
    const int part=kUpperCount+static_cast<int>(snapshot.slot);
    if(combi.sourceEffects&&std::find(combi.sourceEffects->logicalToSampler.begin(),
            combi.sourceEffects->logicalToSampler.end(),part)!=combi.sourceEffects->logicalToSampler.end()){
        // Preserve SVFX's established source-owner precedence. Original sends
        // and the retained original insert chain must not become manual FX.
        upper.fxSend1=previous.fxSend1;upper.fxSend2=previous.fxSend2;upper.fxSend3=previous.fxSend3;
        snapshot.insert=previousInsert;
    }
    previous=std::move(upper);
    previousInsert=std::move(snapshot.insert);
}

void writeCombi(Writer&w,const Combi&c,const Graph&g){w.str(c.name);for(const auto&u:c.uppers)writeUpper(w,u,g);writeFx(w,c.fx[0]);writeFx(w,c.fx[1]);w.u8(static_cast<std::uint8_t>(c.fxRouting));
    writeFx(w,c.fx[2]);writeFx(w,c.fx[3]);for(const auto&ins:c.insert)writeFx(w,ins);}   // SILVETON_SET_V12
Combi readCombi(Reader&r,const std::vector<ProgramPtr>&p,std::uint32_t version){Combi c;c.name=r.str();for(auto&u:c.uppers)u=readUpper(r,p,version);c.fx[0]=readFx(r,version);c.fx[1]=readFx(r,version);if(version>=6U)c.fxRouting=static_cast<EffectRouting>(r.u8());
    if(version>=12U){c.fx[2]=readFx(r,version);c.fx[3]=readFx(r,version);for(auto&ins:c.insert)ins=readFx(r,version);}return c;}

// SVSC is appended after SVPS: old readers retain their previous global
// tuning, while current readers preserve each blend and the open edit.
void writeBlendScale(Writer& w, const BlendScale& scale) {
    w.u8(scale.stored ? 1U : 0U);
    if (!scale.stored) return;
    w.u8(scale.enabled ? 1U : 0U);
    w.u16(scale.targets);
    w.u8(scale.tonic);
    for (float cents : scale.cents) w.f32(cents);
    w.str(scale.name);
}
BlendScale readBlendScale(Reader& r) {
    BlendScale scale;
    const auto stored = r.u8();
    if (stored > 1U) { r.error = "Invalid stored scale flag"; return scale; }
    scale.stored = stored != 0U;
    if (!scale.stored) return scale;
    const auto enabled = r.u8();
    scale.enabled = enabled != 0U;
    scale.targets = r.u16();
    scale.tonic = r.u8();
    if (enabled > 1U || scale.targets > 0x7FFFU || scale.tonic > 11U) r.error = "Invalid scale settings";
    for (float& cents : scale.cents) {
        // The legacy f32() reader sanitizes NaN to zero; a tuning snapshot
        // must instead reject corrupt cents rather than silently retune it.
        const auto bits = r.u32();
        std::memcpy(&cents, &bits, sizeof(cents));
        if (!std::isfinite(cents) || cents < -100.0F || cents > 100.0F) r.error = "Invalid scale cents";
    }
    scale.name = r.str();
    if (scale.name.size() > 256U) r.error = "Scale name is too long";
    return scale;
}

// SVMX v1 is a trailing extension: the v19 base COMBI/performance layouts
// remain readable by older versions. Values encode absent as 0 and MIDI 0..127
// as 1..128; neither a fixed sampler slot nor a physical input channel owns it.
bool validSourceMix(const Combi& combi) noexcept {
    const auto valid=[](int raw) noexcept {return raw>=-1&&raw<=127;};
    for(int pi=0;pi<kPartCount;++pi){const auto& u=combi.part(pi);
        if(!valid(u.sourceVolumeRaw)||!valid(u.sourcePanRaw)||!valid(u.sourceExpressionRaw))return false;}
    return true;
}
bool hasSourceMix(const Combi& combi) noexcept {
    for(int pi=0;pi<kPartCount;++pi){const auto& u=combi.part(pi);
        if(u.sourceVolumeRaw>=0||u.sourcePanRaw>=0||u.sourceExpressionRaw>=0)return true;}
    return false;
}
// SVTN keeps original channel tuning independent of the visible fine trim.
// The current base codecs stay unchanged. Zero encodes absent, positive
// values encode the original MIDI value plus one (not a default tuning).
constexpr std::uint32_t kSourceTuningMark=0x4E545653U; // SVTN
constexpr std::uint32_t kSourceTuningVersion=1U;
using SourceTuningSnapshot=std::array<std::pair<int,int>,kPartCount>;
bool validSourceTuning(const Combi& combi) noexcept {
    for(int part=0;part<kPartCount;++part){const auto& u=combi.part(part);
        if(u.sourceCoarseTuneRaw< -1||u.sourceCoarseTuneRaw>127||
           u.sourceFineTuneRaw< -1||u.sourceFineTuneRaw>16383)return false;}
    return true;
}
bool hasSourceTuning(const Combi& combi) noexcept {
    for(int part=0;part<kPartCount;++part){const auto& u=combi.part(part);
        if(u.sourceCoarseTuneRaw>=0||u.sourceFineTuneRaw>=0)return true;}
    return false;
}
void writeSourceTuning(Writer& w,const Combi& combi){
    for(int part=0;part<kPartCount;++part){const auto& u=combi.part(part);
        w.u8(static_cast<std::uint8_t>(u.sourceCoarseTuneRaw+1));
        w.u16(static_cast<std::uint16_t>(u.sourceFineTuneRaw+1));}
}
SourceTuningSnapshot readSourceTuning(Reader& r){
    SourceTuningSnapshot snapshot{};
    for(auto& part:snapshot){
        const auto coarse=r.u8();const auto fine=r.u16();
        if(!r.error.empty())return snapshot;
        if(coarse>128U||fine>16384U){r.error="Invalid original channel tuning value";return snapshot;}
        part={static_cast<int>(coarse)-1,static_cast<int>(fine)-1};
    }
    return snapshot;
}
void applySourceTuning(Combi& combi,const SourceTuningSnapshot& snapshot){
    for(int part=0;part<kPartCount;++part){auto& upper=combi.part(part);
        upper.sourceCoarseTuneRaw=snapshot[static_cast<std::size_t>(part)].first;
        upper.sourceFineTuneRaw=snapshot[static_cast<std::size_t>(part)].second;}
}
using SourceSoundEditSnapshot=std::array<SourceSoundEdits,kPartCount>;
bool validSourceSoundEdits(const Combi& combi) noexcept {
    for(int part=0;part<kPartCount;++part)if(!combi.part(part).sourceSoundEdits.valid())return false;
    return true;
}
bool hasSourceSoundEdits(const Combi& combi) noexcept {
    for(int part=0;part<kPartCount;++part)if(combi.part(part).sourceSoundEdits.present())return true;
    return false;
}
void writeSourceSoundEdits(Writer& writer,const Combi& combi){
    for(int part=0;part<kPartCount;++part){
        const auto& edits=combi.part(part).sourceSoundEdits;
        for(const auto value:edits.raw)writer.u8(static_cast<std::uint8_t>(value+1));
        writer.u8(static_cast<std::uint8_t>(edits.portamentoTimeRaw+1));
        writer.u8(static_cast<std::uint8_t>(edits.portamentoOnRaw+1));
    }
}
SourceSoundEditSnapshot readSourceSoundEdits(Reader& reader){
    SourceSoundEditSnapshot snapshot{};
    const auto value=[&]() -> std::int16_t {
        const auto raw=reader.u8();
        if(raw>128U&&reader.error.empty())reader.error="Invalid original Sound Edit MIDI value";
        return static_cast<std::int16_t>(static_cast<int>(raw)-1);
    };
    for(auto& edits:snapshot){
        for(auto& raw:edits.raw)raw=value();
        edits.portamentoTimeRaw=value();edits.portamentoOnRaw=value();
    }
    return snapshot;
}
void writeSourceMix(Writer& w,const Combi& combi) {
    for(int pi=0;pi<kPartCount;++pi){const auto& u=combi.part(pi);
        w.u8(static_cast<std::uint8_t>(u.sourceVolumeRaw+1));
        w.u8(static_cast<std::uint8_t>(u.sourcePanRaw+1));
        w.u8(static_cast<std::uint8_t>(u.sourceExpressionRaw+1));}
}
void readSourceMix(Reader& r,Combi& combi) {
    for(int pi=0;pi<kPartCount&&r.error.empty();++pi){
        const auto volume=r.u8(),pan=r.u8(),expression=r.u8();
        if(volume>128U||pan>128U||expression>128U){r.error="Invalid Keyboard Set source mix value";return;}
        auto& u=combi.part(pi);u.sourceVolumeRaw=static_cast<int>(volume)-1;
        u.sourcePanRaw=static_cast<int>(pan)-1;u.sourceExpressionRaw=static_cast<int>(expression)-1;
    }
}

// SVPS v1 follows the existing v19 blocks, so older SETs need no migration and
// older readers can still read their stored COMBIs. The live copy includes all
// 15 parts, their layers, engines and inserts rather than borrowing a WRITE slot.
bool hasChannelGates(const Combi& c){
    for(int i=0;i<kPartCount;++i)if(!(c.part(i).channelGate==ChannelGate{}))return true;
    return false;
}
void writeChannelGates(Writer& w,const Combi& c){
    for(int i=0;i<kPartCount;++i){
        const auto& g=c.part(i).channelGate;
        w.u8((g.enabled?1:0)|(g.fastAttack?2:0)|(g.expand?4:0));
        w.f32(g.thresholdDb);w.f32(g.rangeDb);w.f32(g.holdSec);w.f32(g.releaseSec);
    }
}
void readChannelGates(Reader& r,Combi& c){
    const auto bounded=[](float v,float lo,float hi){return std::isfinite(v)&&v>=lo&&v<=hi;};
    for(int i=0;i<kPartCount;++i){
        auto& g=c.part(i).channelGate;const auto flags=r.u8();
        g.enabled=flags&1;g.fastAttack=flags&2;g.expand=flags&4;
        g.thresholdDb=r.f32();g.rangeDb=r.f32();g.holdSec=r.f32();g.releaseSec=r.f32();
        if(flags>7||!bounded(g.thresholdDb,-30,10)||!bounded(g.rangeDb,0,40)||
           !bounded(g.holdSec,0,4)||!bounded(g.releaseSec,.1F,4)){
            r.error="Invalid channel gate settings";return;
        }
    }
}
void writePerformance(Writer& w, const PerformanceSnapshot& p, const Graph& g) {
    w.u8(p.edited ? 1U : 0U);
    const bool hasList = p.activeListAddress.has_value() && p.activeListEntry >= 0;
    w.u8(hasList ? 1U : 0U);
    if (hasList) { writeAddress(w, *p.activeListAddress); w.u32(static_cast<std::uint32_t>(p.activeListEntry)); }
    writeCombi(w, p.combi, g);
    for (const auto& u : p.combi.engineSlots) writeUpper(w, u, g);
    for (const auto& fx : p.combi.engineInsert) writeFx(w, fx);
    for (int i = 0; i < kPartCount; ++i) {
        const auto& u = p.combi.part(i);
        w.f32(u.evenDecayMs);
        w.u8(static_cast<std::uint8_t>(u.engine.type));
        const int count = engineStoredCount(u.engine);
        w.u16(static_cast<std::uint16_t>(count));
        for (int k = 0; k < count; ++k) w.f32(u.engine.p[static_cast<std::size_t>(k)]);
    }
}

PerformanceSnapshot readPerformance(Reader& r, const std::vector<ProgramPtr>& programs) {
    PerformanceSnapshot p;
    p.edited = r.u8() != 0U;
    if (r.u8() != 0U) {
        p.activeListAddress = readAddress(r);
        const auto index = r.u32();
        if (index >= 100000U) { r.error = "Invalid active LIST position in SET"; return p; }
        p.activeListEntry = static_cast<int>(index);
    }
    p.combi = readCombi(r, programs, 19U);
    for (auto& u : p.combi.engineSlots) u = readUpper(r, programs, 19U);
    for (auto& fx : p.combi.engineInsert) fx = readFx(r, 19U);
    for (int i = 0; i < kPartCount && r.error.empty(); ++i) {
        auto& u = p.combi.part(i);
        const float decay = r.f32();
        u.evenDecayMs = decay >= 30.0F ? std::min(decay, 10000.0F) : 0.0F;
        u.engine = engineDefaults(keptEngineType(r.u8(), true));
        const auto count = r.u16();
        if (count > 4096U) { r.error = "Invalid engine in SET performance"; break; }
        for (std::uint16_t k = 0U; k < count && r.error.empty(); ++k) {
            const float v = r.f32();
            if (k < kEngineParamCount) u.engine.p[k] = engineClamp(u.engine.type, static_cast<int>(k), v);
        }
        engineSanitizeLoaded(u.engine);
    }
    return p;
}

} // namespace

namespace {
SetPackageResult savePackageDirectory(const std::string& packageDirectory,const SetData& data){
    namespace fs=silveton::fsx;
    try{
        for(const auto& cs:data.combis)if(!validSourceMix(cs.combi))return{false,"Invalid stored Keyboard Set source mix"};
        if(data.performance&&!validSourceMix(data.performance->combi))return{false,"Invalid live Keyboard Set source mix"};
        for(const auto& cs:data.combis)if(!validSourceTuning(cs.combi))return{false,"Invalid stored Keyboard Set source tuning"};
        if(data.performance&&!validSourceTuning(data.performance->combi))return{false,"Invalid live Keyboard Set source tuning"};
        for(const auto& cs:data.combis)if(!validSourceSoundEdits(cs.combi))return{false,"Invalid stored Sound Edits"};
        if(data.performance&&!validSourceSoundEdits(data.performance->combi))return{false,"Invalid live Sound Edits"};
        // Validate and bound the new extension before touching staged files.
        std::vector<std::string> numberedCombis;numberedCombis.reserve(data.combis.size());
        std::size_t numberedBytes=0,numberedAssignments=0;bool numberedPresent=false;
        const auto numberedRecord=[&](const Combi& combi){
            auto bytes=encodeNumberedFxCombi(combi);
            if(!bytes.empty()){
                numberedPresent=true;numberedAssignments+=static_cast<unsigned char>(bytes.front());
                if(bytes.size()>kMaximumNumberedFxTotalBytes-numberedBytes||numberedAssignments>kMaximumNumberedFxAssignments)
                    throw std::runtime_error("SET numbered FX metadata is too large");
                numberedBytes+=bytes.size();
            }
            return bytes;
        };
        for(const auto& cs:data.combis)numberedCombis.push_back(numberedRecord(cs.combi));
        const auto numberedPerformance=data.performance?numberedRecord(data.performance->combi):std::string{};
        if(numberedPresent&&(data.combis.size()>(kMaximumNumberedFxTotalBytes-17U)/4U||
           17U+4U*data.combis.size()>kMaximumNumberedFxTotalBytes-numberedBytes))
            return {false,"SET numbered FX metadata is too large"};
        fs::path root(packageDirectory);fs::remove_all(root);
        Graph g;for(const auto&s:data.samples)g.addSample(s.sample);for(const auto&m:data.multisamples)g.addMs(m.multisample);for(const auto&s:data.programs)g.addProgram(s.program);
        const auto addCombi = [&g](const Combi& c) {
            for (int i = 0; i < kPartCount; ++i) {
                const auto& u = c.part(i);
                g.addProgram(u.program);
                for (const auto& l : u.layers) g.addProgram(l.program);
            }
        };
        for (const auto& cs : data.combis) {
            for (const auto& u : cs.combi.uppers) { g.addProgram(u.program); for (const auto& l : u.layers) g.addProgram(l.program); }
            for (const auto& u : cs.combi.engineSlots) g.addProgram(u.program);
        }
        if (data.performance) addCombi(data.performance->combi);
        // Append previously omitted layer Programs after the legacy traversal,
        // preserving every existing graph id and shared PCM/MS/Program object.
        for(const auto& cs:data.combis)for(const auto& upper:cs.combi.engineSlots)
            for(const auto& layer:upper.layers)g.addProgram(layer.program);
        for(const auto& program:g.programs)if(program->drumKeyGroups)
            for(const auto& key:*program->drumKeyGroups)if(!key.valid())return{false,"Invalid Drum Kit group settings"};
        std::uint32_t sourceAmpCount=0U;
        std::uint32_t sourceVoiceCount=0U,sourcePortamentoCount=0U,sourceOscillatorDspCount=0U;
        for(const auto& program:g.programs){
            if(!program->sourceVoiceAssignment.valid())return{false,"Invalid original Sound voice assignment"};
            if(program->sourceVoiceAssignment.present)++sourceVoiceCount;
            for(const auto& layer:program->layers){
                if(layer.sourceOscillatorDsp){
                    const auto bytes=encodeSourceOscillatorDsp(*layer.sourceOscillatorDsp);
                    if(bytes.empty()||bytes.size()>kMaximumSourceOscillatorDspBytes)
                        return{false,"Invalid original oscillator metadata"};
                    if(++sourceOscillatorDspCount>kMaximumSourceAmpRecords)
                        return{false,"Too many original oscillator metadata records"};
                }
                if(!layer.sourcePortamento.valid())return{false,"Invalid original Sound portamento"};
                if(layer.sourcePortamento.present&&++sourcePortamentoCount>kMaximumSourceAmpRecords)
                    return{false,"Too many original Sound portamento records"};
            }
        }
        for(const auto& program:g.programs)for(const auto& layer:program->layers){
            if(!layer.sourceAmpEnvelope.valid())return{false,"Invalid original Sound Amp EG"};
            if(layer.sourceAmpEnvelope.present&&++sourceAmpCount>kMaximumSourceAmpRecords)
                return{false,"Too many original Sound Amp EG records"};
        }
        // SILVETON_SET_FILE_V1: a SET without sample audio (BLENDS / LIST / SAVE AS sets) is ONE file
        // (the manifest itself); only a SET that embeds audio is a folder with manifest.svs + audio/.
        const bool hasDecay = std::any_of(g.programs.begin(), g.programs.end(), [](const auto& program) {
            return std::any_of(program->layers.begin(), program->layers.end(),
                [](const auto& layer) { return layer.sampleDecay.enabled(); });
        });
        const auto version = hasDecay ? kSampleDecayVersion : kVersion;
        const bool single=g.samples.empty();
        if(single){if(root.has_parent_path())fs::create_directories(root.parent_path());}else fs::create_directories(root/"audio");
        Writer w(single?root:root/"manifest.svs");if(!w.ok())return{false,"Cannot create SET manifest"};w.bytes(kMagic.data(),kMagic.size());w.u32(version);w.str(data.name);writeGlobal(w,data.global);
        w.u32(static_cast<std::uint32_t>(g.samples.size()));
        for(std::uint32_t i=0U;i<g.samples.size();++i){const auto&s=*g.samples[i];w.str(s.name);w.str(s.sourceIdentity);w.u8(s.rootKey);w.f32(s.fineTuneCents);w.u8(s.loop.enabled?1U:0U);w.u32(static_cast<std::uint32_t>(s.loop.startFrame));w.u32(static_cast<std::uint32_t>(s.loop.endFrame));w.u32(s.loop.crossfadeFrames);
            const fs::path src(s.sourcePath);const auto extension=src.extension().string();auto lower=extension;
            std::transform(lower.begin(),lower.end(),lower.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
            const bool standalone=lower==".wav"||lower==".wave"||lower==".aif"||lower==".aiff"||lower==".aifc"||lower==".ksf";
            bool copySource=false;
            if(standalone&&!s.sourcePath.empty()&&fs::is_regular_file(src)){
                std::string ignored;const auto original=loadAsset(src,ignored);
                copySource=original&&original->sampleRate==s.sampleRate&&original->channels==s.channels&&original->frameCount()==s.frameCount();
            }
            // A Pa .PCM path names a multi-resource container, not this UID's
            // waveform. Package its decoded recording rather than the bank.
            const fs::path rel=fs::path("audio")/("sample_"+std::to_string(i)+(copySource?extension:".wav"));
            const fs::path dst=root/rel;
            if(copySource)fs::copy_file(src,dst,fs::copy_options::overwrite_existing);
            else{std::string error;if(!writeFloatWav(dst,s,error))return{false,error};}
            w.str(rel.generic_string());}
        w.u32(static_cast<std::uint32_t>(g.multisamples.size()));for(const auto&msp:g.multisamples){w.str(msp->name);w.str(msp->sourceIdentity);w.u32(static_cast<std::uint32_t>(msp->zones.size()));for(const auto&z:msp->zones){const auto it=g.sampleIds.find(z.sample.get());w.u32(it==g.sampleIds.end()?0xFFFFFFFFU:it->second);w.u8(z.keyLow);w.u8(z.keyHigh);w.u8(z.velocityLow);w.u8(z.velocityHigh);w.u8(z.rootKey);w.i8(z.transposeSemitones);w.f32(z.tuneCents);w.f32(z.gainDb);w.f32(z.pan);w.u8(z.oneShot?1U:0U);w.u8(z.reverse?1U:0U);w.u8(z.nonTranspose?1U:0U);w.i8(z.sourceLevelRaw);w.i8(z.sourceFilterRaw);}}
        w.u32(static_cast<std::uint32_t>(g.programs.size()));for(const auto&p:g.programs)writeProgramBody(w,*p,g,version);
        w.u32(static_cast<std::uint32_t>(data.programs.size()));for(const auto&s:data.programs){writeAddress(w,s.address);const auto it=g.programIds.find(s.program.get());w.u32(it==g.programIds.end()?0xFFFFFFFFU:it->second);}
        w.u32(static_cast<std::uint32_t>(data.combis.size()));for(const auto&s:data.combis){writeAddress(w,s.address);writeCombi(w,s.combi,g);}
        w.u32(static_cast<std::uint32_t>(data.lists.size()));for(const auto&s:data.lists){writeAddress(w,s.address);w.str(s.list.name);w.u32(static_cast<std::uint32_t>(s.list.entries.size()));for(const auto&e:s.list.entries){w.u16(e.number);w.str(e.name);w.u16(e.combiBank);w.u16(e.combiPage);w.u16(e.combiSlot);}}
        w.u32(static_cast<std::uint32_t>(data.samples.size()));for(const auto&item:data.samples){w.u32(item.id);const auto it=g.sampleIds.find(item.sample.get());w.u32(it==g.sampleIds.end()?0xFFFFFFFFU:it->second);}
        w.u32(static_cast<std::uint32_t>(data.multisamples.size()));for(const auto&item:data.multisamples){w.u32(item.id);const auto it=g.multisampleIds.find(item.multisample.get());w.u32(it==g.multisampleIds.end()?0xFFFFFFFFU:it->second);}
        // SILVETON_EVEN_DECAY_LIVE_V1 (the Manager's copy): after everything an older reader reads (it stops before it, so the
        // tablet opens the file as before): "SVXD", 1, COMBI count, ЗАТИХВАНЕ ms of the 7 Uppers of every COMBI in the order above.
        // Written only when an Upper has it on (otherwise the file is exactly as before).
        bool anyDecay = false;
        for (const auto& cs : data.combis) for (const auto& u : cs.combi.uppers) if (u.evenDecayMs > 0.0F) anyDecay = true;
        if (anyDecay) {
            w.u32(0x44585653U); w.u32(1U); w.u32(static_cast<std::uint32_t>(data.combis.size()));
            for (const auto& cs : data.combis) for (const auto& u : cs.combi.uppers) w.f32(u.evenDecayMs);
        }
        // SILVETON_ENGINES_V1 / V2: the ENGINE of every Upper, the same way (a block after everything, only when one is on):
        // "SVEN", 3, COMBI count, per COMBI per Upper: type (u8) + value count (u16) + the values (V1 wrote version 1 with 48;
        // SILVETON_ENGINES_V3 writes 3: the same layout, the new knobs of V3 hold their values - a version 1 / 2 block gets their defaults).
        bool anyEngine = false;
        for (const auto& cs : data.combis) for (const auto& u : cs.combi.uppers) if (u.engine.chosen()) anyEngine = true;   // (a bypassed engine is kept too)
        if (anyEngine) {
            w.u32(0x4E455653U); w.u32(6U);   // SILVETON_MODEL_V1: block version 6 (type 11 was SILVETON MODEL - removed, opens empty; 12 = SILVETON SYNTH); V5 = the decay of GUITAR / HARP; V4 = ANALOG of the synth engines
            w.u32(static_cast<std::uint32_t>(data.combis.size()));
            for (const auto& cs : data.combis) for (const auto& u : cs.combi.uppers) {
                w.u8(static_cast<std::uint8_t>(u.engine.type));
                const int storedCount = engineStoredCount(u.engine);  // Write 64 current values; historical rows may contain 960.
                w.u16(static_cast<std::uint16_t>(storedCount));
                for (int k = 0; k < storedCount; ++k) w.f32(u.engine.p[static_cast<std::size_t>(k)]);
            }
        }
        // SILVETON_ENGINE_SLOTS_V1: the 8 engine slots of every COMBI (a block after everything, only when a slot is used):
        // "SVES", 1, COMBI count, per COMBI per slot: flags (1 on, 2 mute), level, pan, voice mode, octave, transpose, tune,
        // bend range, portamento (sec, mode, flags, time), then the engine: type (u8) + value count (u16) + the values.
        // SILVETON_MODEL_V1: version 2 adds, after the engine, the place's sound (program id, sound slot id, name) and its
        // envelope (attack, decay, sustain, release) - SILVETON SYNTH sounds through it.
        bool anySlot = false;
        for (const auto& cs : data.combis) for (const auto& u : cs.combi.engineSlots) if (u.engine.chosen() || u.enabled || u.program != nullptr) anySlot = true;
        if (anySlot) {
            w.u32(0x53455653U); w.u32(2U);
            w.u32(static_cast<std::uint32_t>(data.combis.size()));
            for (const auto& cs : data.combis) for (const auto& u : cs.combi.engineSlots) {
                w.u8(static_cast<std::uint8_t>((u.enabled ? 1U : 0U) | (u.mute ? 2U : 0U)));
                w.f32(u.levelDb); w.f32(u.pan);
                w.u8(static_cast<std::uint8_t>(u.voiceMode));
                w.u8(static_cast<std::uint8_t>(u.octave)); w.u8(static_cast<std::uint8_t>(u.transposeSemitones));
                w.f32(u.tuneCents); w.u8(static_cast<std::uint8_t>(u.pitchBendRange));
                w.f32(u.portamentoSec); w.u8(static_cast<std::uint8_t>(u.portaMode));
                w.u8(static_cast<std::uint8_t>((u.portaFingered ? 1U : 0U) | (u.portaRateMode ? 2U : 0U))); w.u8(u.portaTime);
                w.u8(static_cast<std::uint8_t>(u.engine.type));
                const int storedCount = engineStoredCount(u.engine);  
                w.u16(static_cast<std::uint16_t>(storedCount));
                for (int k = 0; k < storedCount; ++k) w.f32(u.engine.p[static_cast<std::size_t>(k)]);
                const auto it = g.programIds.find(u.program.get()); w.u32(it == g.programIds.end() ? 0xFFFFFFFFU : it->second);   // SILVETON_MODEL_V1
                w.u16(u.soundSlotId); w.str(u.name);
                w.f32(u.toneAttackMs); w.f32(u.toneDecayMs); w.f32(u.toneSustain); w.f32(u.toneReleaseMs);
            }
        }
        // SILVETON_PLACE_FX_V1: INSERT and the four sends of every SILVETON SYNTH place (a block after everything, only when used):
        // "SVEF", 1, COMBI count, per COMBI per place: INSERT (effect), send 1..4.
        bool anyPlaceFx = false;
        for (const auto& cs : data.combis) for (std::size_t k = 0U; k < cs.combi.engineSlots.size(); ++k) {
            const auto& u = cs.combi.engineSlots[k];
            if (cs.combi.engineInsert[k].type != EffectType::Off || u.fxSend1 > 0.0F || u.fxSend2 > 0.0F || u.fxSend3 > 0.0F || u.fxSend4 > 0.0F) anyPlaceFx = true;
        }
        if (anyPlaceFx) {
            w.u32(0x46455653U); w.u32(1U);
            w.u32(static_cast<std::uint32_t>(data.combis.size()));
            for (const auto& cs : data.combis) for (std::size_t k = 0U; k < cs.combi.engineSlots.size(); ++k) {
                const auto& u = cs.combi.engineSlots[k];
                writeFx(w, cs.combi.engineInsert[k]);
                w.f32(u.fxSend1); w.f32(u.fxSend2); w.f32(u.fxSend3); w.f32(u.fxSend4);
            }
        }
        // SILVETON_SET_ONE_FILE_V1: the T / Q text of the app (a block after everything, only when there is one): "SVTQ", 1, text
        if (!data.extra.empty()) { w.u32(0x51545653U); w.u32(1U); w.str(data.extra); }
        if (data.performance) { w.u32(0x53505653U); w.u32(1U); writePerformance(w, *data.performance, g); }
        const bool hasBlendScales = (data.performance && data.performance->combi.scale.stored) ||
            std::any_of(data.combis.begin(), data.combis.end(), [](const CombiSlot& cs) { return cs.combi.scale.stored; });
        if (hasBlendScales) {
            w.u32(0x43535653U); w.u32(1U); w.u32(static_cast<std::uint32_t>(data.combis.size()));
            for (const auto& cs : data.combis) writeBlendScale(w, cs.combi.scale);
            w.u8(data.performance ? 1U : 0U);
            if (data.performance) writeBlendScale(w, data.performance->combi.scale);
        }
        // SVSM: immutable trained models travel inside this one SET file.
        w.u32(0x4D535653U);w.u32(1U);w.u32(static_cast<std::uint32_t>(data.combis.size()));
        const auto writeModels=[&](const Combi&c){for(int i=0;i<kPartCount;++i){const auto&m=c.part(i).soloModel;const auto b=m?solo::encodeModel(*m):std::vector<std::uint8_t>{};w.u32(static_cast<std::uint32_t>(b.size()));if(!b.empty())w.bytes(b.data(),b.size());}};
        for(const auto&cs:data.combis){writeModels(cs.combi);}
        w.u8(data.performance?1:0);if(data.performance)writeModels(data.performance->combi);

        // SVSS v1: per-sound sources. MAIN retains SVSM compatibility; L1..L4
        // embed their existing SOLO data here, beside the ordinary sound settings.
        w.u32(0x53535653U);w.u32(1U);w.u32(static_cast<std::uint32_t>(data.combis.size()));
        const auto writeSources=[&](const Combi& c){
            for(int pi=0;pi<kPartCount;++pi){
                const auto& u=c.part(pi);w.u8(u.commonProcessing?1:0);
                for(const auto& l:u.layers){w.u8(l.commonProcessing?1:0);w.u8(static_cast<std::uint8_t>(l.engine.type));
                    for(float v:l.engine.p)w.f32(v);
                    const auto bytes=l.soloModel?solo::encodeModel(*l.soloModel):std::vector<std::uint8_t>{};
                    w.u32(static_cast<std::uint32_t>(bytes.size()));if(!bytes.empty())w.bytes(bytes.data(),bytes.size());
                }
            }
        };
        for(const auto& cs:data.combis)writeSources(cs.combi);
        w.u8(data.performance?1:0);if(data.performance)writeSources(data.performance->combi);
        const bool sourceMixPresent=(data.performance&&hasSourceMix(data.performance->combi))||
            std::any_of(data.combis.begin(),data.combis.end(),[](const CombiSlot& cs){return hasSourceMix(cs.combi);});
        if(sourceMixPresent){
            w.u32(0x584D5653U);w.u32(1U);w.u32(static_cast<std::uint32_t>(data.combis.size()));
            w.u32(static_cast<std::uint32_t>(kPartCount));
            for(const auto& cs:data.combis)writeSourceMix(w,cs.combi);
            w.u8(data.performance?1U:0U);if(data.performance)writeSourceMix(w,data.performance->combi);
        }
        if((data.performance&&hasChannelGates(data.performance->combi))||
            std::any_of(data.combis.begin(),data.combis.end(),[](const CombiSlot& cs){return hasChannelGates(cs.combi);})){
            w.u32(0x54475653U);w.u32(1);w.u32(static_cast<std::uint32_t>(data.combis.size()));
            for(const auto& cs:data.combis)writeChannelGates(w,cs.combi);
            w.u8(data.performance?1:0);
            if(data.performance)writeChannelGates(w,data.performance->combi);
        }
        // SVDG v1 adds per-key groups by existing Program graph id. The v19/v20
        // Program body and PCM assets stay unchanged; older SETs omit this block.
        const auto groupCount=static_cast<std::uint32_t>(std::count_if(g.programs.begin(),g.programs.end(),
            [](const auto& program){return program->drumKeyGroups!=nullptr;}));
        if(groupCount>0U){
            w.u32(0x47445653U);w.u32(1U);w.u32(static_cast<std::uint32_t>(g.programs.size()));
            w.u32(groupCount);w.u32(static_cast<std::uint32_t>(kMidiKeys));
            for(std::uint32_t i=0;i<g.programs.size();++i)if(g.programs[i]->drumKeyGroups){
                w.u32(i);writeDrumKeyGroups(w,*g.programs[i]->drumKeyGroups);
            }
        }
        const bool sourceFxPresent=(data.performance&&data.performance->combi.sourceEffects)||
            std::any_of(data.combis.begin(),data.combis.end(),[](const CombiSlot& cs){return bool(cs.combi.sourceEffects);});
        if(sourceFxPresent){
            // SVFX stores original owner metadata, independent of Program/PCM
            // assets. Old packages without the block remain explicit manual FX.
            w.u32(0x58465653U);w.u32(1U);w.u32(static_cast<std::uint32_t>(data.combis.size()));
            std::size_t total=0;
            const auto writeOriginal=[&](const Combi& c){
                const auto bytes=c.sourceEffects?encodeSourceEffects(*c.sourceEffects):std::vector<std::uint8_t>{};
                if((total+=bytes.size())>64U*1024U*1024U)throw std::runtime_error("SET original FX metadata is too large");
                w.u32(static_cast<std::uint32_t>(bytes.size()));if(!bytes.empty())w.bytes(bytes.data(),bytes.size());
            };
            for(const auto& cs:data.combis)writeOriginal(cs.combi);
            w.u8(data.performance?1U:0U);if(data.performance)writeOriginal(data.performance->combi);
        }
        if(numberedPresent){
            // Optional trailing extension: old native slots and original SVFX bytes
            // keep their existing layout. Native-only packages omit SVNF.
            w.u32(kNumberedFxMark);w.u32(kNumberedFxVersion);w.u32(static_cast<std::uint32_t>(data.combis.size()));
            const auto writeNumbered=[&](const std::string& bytes){
                w.u32(static_cast<std::uint32_t>(bytes.size()));if(!bytes.empty())w.bytes(bytes.data(),bytes.size());
            };
            for(const auto& bytes:numberedCombis)writeNumbered(bytes);
            w.u8(data.performance?1U:0U);if(data.performance)writeNumbered(numberedPerformance);
        }
        if(!data.combis.empty()){
            // Always retain all stored engine slots, including disabled parts
            // and Off inserts with edited controls. Older readers stop here,
            // after consuming the unchanged legacy and auxiliary extensions.
            w.u32(kEngineSnapshotMark);w.u32(kEngineSnapshotVersion);
            w.u32(kEngineSnapshotUpperVersion);
            w.u32(static_cast<std::uint32_t>(data.combis.size()));
            w.u32(static_cast<std::uint32_t>(kEngineSlotCount));
            for(std::size_t owner=0;owner<data.combis.size();++owner){
                w.u32(static_cast<std::uint32_t>(owner));
                const auto& combi=data.combis[owner].combi;
                for(std::size_t slot=0;slot<combi.engineSlots.size();++slot){
                    w.u32(static_cast<std::uint32_t>(slot));
                    writeEngineSnapshot(w,combi.engineSlots[slot],combi.engineInsert[slot],g);
                }
            }
        }
        const bool sourceTuningPresent=(data.performance&&hasSourceTuning(data.performance->combi))||
            std::any_of(data.combis.begin(),data.combis.end(),[](const CombiSlot& cs){return hasSourceTuning(cs.combi);});
        if(sourceTuningPresent){
            w.u32(kSourceTuningMark);w.u32(kSourceTuningVersion);
            w.u32(static_cast<std::uint32_t>(data.combis.size()));w.u32(static_cast<std::uint32_t>(kPartCount));
            for(const auto& cs:data.combis)writeSourceTuning(w,cs.combi);
            w.u8(data.performance?1U:0U);if(data.performance)writeSourceTuning(w,data.performance->combi);
        }
        if(sourceAmpCount>0U){
            // Optional original-parameter metadata: keep the v19/v20 Program
            // body, legacy SampleDecay bytes and every sample identity intact.
            w.u32(kSourceAmpMark);w.u32(kSourceAmpVersion);
            w.u32(static_cast<std::uint32_t>(g.programs.size()));w.u32(sourceAmpCount);
            for(std::uint32_t id=0;id<g.programs.size();++id){
                const auto& layers=g.programs[id]->layers;
                for(std::uint32_t layerId=0;layerId<layers.size();++layerId){
                    const auto& source=layers[layerId].sourceAmpEnvelope;if(!source.present)continue;
                    w.u32(id);w.u32(layerId);w.u8(source.enabled?1U:0U);
                    for(const auto value:source.levels)w.u8(value);
                    for(const auto value:source.times)w.u8(value);
                    w.u8(source.modulationEncodingSupported?1U:0U);
                    for(const auto value:source.amsSources)w.u8(value);
                    for(const auto value:source.amsIntensities)w.i8(value);
                    for(const auto value:source.amsDirections)w.u8(value);
                    for(const auto value:source.keyboardKeys)w.u8(value);
                    for(const auto value:source.keyboardRamps)w.i8(value);
                    w.u8(source.filterKeyboardTrackingPresent?1U:0U);
                    for(const auto value:source.filterKeyboardKeys)w.u8(value);
                    for(const auto value:source.filterKeyboardRamps)w.i8(value);
                }
            }
        }
        const auto sourceSoundFxCount=static_cast<std::uint32_t>(std::count_if(g.programs.begin(),g.programs.end(),
            [](const auto& program){return bool(program->sourceSoundEffects);}));
        if(sourceSoundFxCount>0U){
            w.u32(kSourceSoundFxMark);w.u32(kSourceProgramMetadataVersion);
            w.u32(static_cast<std::uint32_t>(g.programs.size()));w.u32(sourceSoundFxCount);
            for(std::uint32_t id=0;id<g.programs.size();++id){
                const auto& source=g.programs[id]->sourceSoundEffects;if(!source)continue;
                const auto bytes=arranger::encodePa5xSoundEffects(*source);
                if(bytes.empty()||bytes.size()>kMaximumSourceSoundFxBytes)return{false,"Invalid original Sound FX metadata"};
                w.u32(id);w.u32(static_cast<std::uint32_t>(bytes.size()));w.bytes(bytes.data(),bytes.size());
            }
        }
        const bool sourcePortamentoOverride=std::any_of(data.combis.begin(),data.combis.end(),
            [](const auto& slot){return hasSourcePortamentoOverride(slot.combi);})||
            (data.performance&&hasSourcePortamentoOverride(data.performance->combi));
        if(sourceVoiceCount>0U||sourcePortamentoCount>0U||sourcePortamentoOverride){
            w.u32(kSourcePortamentoMark);w.u32(kSourcePortamentoVersion);
            w.u32(static_cast<std::uint32_t>(g.programs.size()));w.u32(sourceVoiceCount);w.u32(sourcePortamentoCount);
            for(std::uint32_t id=0;id<g.programs.size();++id){
                const auto& source=g.programs[id]->sourceVoiceAssignment;if(!source.present)continue;
                w.u32(id);w.u8(source.resourceVersion);w.u8(source.flagsRaw);
                w.u8(source.legatoModePresent?1U:0U);w.u8(source.legatoModeRaw);w.u8(source.legatoExtensionRaw);
            }
            for(std::uint32_t id=0;id<g.programs.size();++id){
                const auto& layers=g.programs[id]->layers;
                for(std::uint32_t layerId=0;layerId<layers.size();++layerId){
                    const auto& source=layers[layerId].sourcePortamento;if(!source.present)continue;
                    w.u32(id);w.u32(layerId);w.u8(source.encodingSupported?1U:0U);
                    w.u8(source.resourceVersion);w.u8(source.flagsRaw);w.u8(source.timeRaw);
                    w.u8(source.extensionByteCount);for(auto byte:source.extensionRaw)w.u8(byte);
                }
            }
            w.u32(static_cast<std::uint32_t>(data.combis.size()));w.u32(static_cast<std::uint32_t>(kPartCount));
            for(const auto& slot:data.combis)writeSourcePortamentoInherit(w,slot.combi);
            w.u8(data.performance?1U:0U);
            if(data.performance)writeSourcePortamentoInherit(w,data.performance->combi);
        }
        if(sourceOscillatorDspCount>0U){
            w.u32(kSourceOscillatorDspMark);w.u32(1U);
            w.u32(static_cast<std::uint32_t>(g.programs.size()));w.u32(sourceOscillatorDspCount);
            for(std::uint32_t id=0;id<g.programs.size();++id){
                const auto& layers=g.programs[id]->layers;
                for(std::uint32_t layerId=0;layerId<layers.size();++layerId){
                    const auto& source=layers[layerId].sourceOscillatorDsp;if(!source)continue;
                    const auto bytes=encodeSourceOscillatorDsp(*source);
                    w.u32(id);w.u32(layerId);w.u32(static_cast<std::uint32_t>(bytes.size()));
                    w.bytes(bytes.data(),bytes.size());
                }
            }
        }
        const bool sourceSoundEditsPresent=(data.performance&&hasSourceSoundEdits(data.performance->combi))||
            std::any_of(data.combis.begin(),data.combis.end(),[](const auto& slot){return hasSourceSoundEdits(slot.combi);});
        if(sourceSoundEditsPresent){
            for(const auto& slot:data.combis)if(!validSourceSoundEdits(slot.combi))return{false,"Invalid original Sound Edits"};
            if(data.performance&&!validSourceSoundEdits(data.performance->combi))return{false,"Invalid live original Sound Edits"};
            w.u32(kSourceSoundEditsMark);w.u32(1U);
            w.u32(static_cast<std::uint32_t>(data.combis.size()));w.u32(static_cast<std::uint32_t>(kPartCount));
            for(const auto& slot:data.combis)writeSourceSoundEdits(w,slot.combi);
            w.u8(data.performance?1U:0U);
            if(data.performance)writeSourceSoundEdits(w,data.performance->combi);
        }
        if (!w.f) return {false, "Failed while writing SET manifest"};
        return {true, {}};
    }catch(const std::exception&e){return{false,e.what()};}
}


} // namespace

std::optional<std::string> SetPackage::combiMetadataBytes(const Combi& combi){
    try{
        if(!validSourceMix(combi)||!validSourceTuning(combi)||!validSourceSoundEdits(combi))return std::nullopt;
        // Existing native Keyboard Set auxiliary pointers bind this identity.
        // Off is the legacy meaning, so retain SVNF1 identity bytes unless an
        // explicit source needs the new field; SET storage itself uses SVNF2.
        std::uint32_t numberedVersion=1U;
        for(int slot=0;slot<kNumberedFxSlotCount;++slot)
            if(numberedFxSlot(combi,slot).numberedModulatingPart!=-1){numberedVersion=kNumberedFxVersion;break;}
        const auto numbered=encodeNumberedFxCombi(combi,numberedVersion);
        PerformanceSnapshot snapshot;snapshot.combi=combi;
        for(int part=0;part<kPartCount;++part)for(int source=0;source<=kUpperLayers;++source)
            soundSource(snapshot.combi.part(part),source).program.reset();
        std::string bytes;Writer writer(bytes);Graph references;
        writer.u32(0x49435653U);writer.u32(1U);writer.u32(kVersion);
        writePerformance(writer,snapshot,references);
        if(combi.sourceEffects){
            const auto original=encodeSourceEffects(*combi.sourceEffects);
            writer.u32(0x58465653U);writer.u32(static_cast<std::uint32_t>(original.size()));
            writer.bytes(original.data(),original.size());
        }
        writeBlendScale(writer,snapshot.combi.scale);
        writeSourceMix(writer,snapshot.combi);
        if(hasChannelGates(combi)){writer.u32(0x54475653U);writeChannelGates(writer,combi);}
        // Current trailing extensions are part of the identity too. The
        // runtime performance split caps intentionally have no serialized form.
        for(int part=0;part<kPartCount;++part){
            const auto& upper=snapshot.combi.part(part);
            writer.u8(upper.commonProcessing?1U:0U);
            for(int source=0;source<=kUpperLayers;++source){
                const auto& assignment=soundSource(upper,source);
                if(source>0){
                    writer.u8(assignment.commonProcessing?1U:0U);
                    writer.u8(static_cast<std::uint8_t>(assignment.engine.type));
                    for(float value:assignment.engine.p)writer.f32(value);
                }
                const auto model=assignment.soloModel?solo::encodeModel(*assignment.soloModel):std::vector<std::uint8_t>{};
                if(model.size()>16U*1024U*1024U)return std::nullopt;
                writer.u32(static_cast<std::uint32_t>(model.size()));
                if(!model.empty())writer.bytes(model.data(),model.size());
            }
        }
        if(!numbered.empty()){
            writer.u32(kNumberedFxMark);writer.u32(numberedVersion);writer.u32(static_cast<std::uint32_t>(numbered.size()));
            writer.bytes(numbered.data(),numbered.size());
        }
        // An absent original tuning declaration keeps all legacy identity bytes
        // unchanged; explicit RPN state belongs to the Keyboard Set identity.
        if(hasSourceTuning(combi)){
            writer.u32(kSourceTuningMark);writer.u32(kSourceTuningVersion);
            writeSourceTuning(writer,snapshot.combi);
        }
        if(hasSourcePortamentoOverride(combi)){
            writer.u32(kSourcePortamentoMark);writer.u32(kSourcePortamentoVersion);
            writeSourcePortamentoInherit(writer,combi);
        }
        if(hasSourceSoundEdits(combi)){
            writer.u32(kSourceSoundEditsMark);writer.u32(1U);
            writeSourceSoundEdits(writer,combi);
        }
        if(!writer.ok())return std::nullopt;
        return bytes;
    }catch(const std::exception&){return std::nullopt;}
}

SetPackageResult SetPackage::save(const std::string& packageDirectory,const SetData& data){
    namespace fs=silveton::fsx;
    try {
        const fs::path target(packageDirectory);
        if (target.empty()) return {false, "SET destination is empty"};
        const fs::path parent = target.has_parent_path() ? target.parent_path() : fs::current_path();
        fs::create_directories(parent);

        const std::string stem = target.filename().string();
        fs::path temp = parent / (stem + ".tmp-write");
        fs::path backup = parent / (stem + ".previous");
        fs::remove_all(temp);
        fs::remove_all(backup);

        const auto staged = savePackageDirectory(temp.string(), data);
        if (!staged.success) {
            fs::remove_all(temp);
            return staged;
        }

        // Verify the complete staged package before replacing the current SET.
        const auto verified = SetPackage::load(temp.string());
        if (!verified.ok()) {
            fs::remove_all(temp);
            return {false, "Staged SET verification failed: " + verified.error};
        }

        const bool hadTarget = fs::exists(target);
        if (hadTarget) fs::rename(target, backup);
        try {
            fs::rename(temp, target);
        } catch (...) {
            if (hadTarget && fs::exists(backup) && !fs::exists(target)) fs::rename(backup, target);
            fs::remove_all(temp);
            throw;
        }
        fs::remove_all(backup);
        return {true, {}};
    } catch (const std::exception& e) {
        return {false, e.what()};
    }
}

SetLoadResult SetPackage::load(const std::string& packageDirectory){
    namespace fs=silveton::fsx;SetLoadResult result;try{const fs::path root(packageDirectory);Reader r(fs::is_directory(root)?root/"manifest.svs":root);/* SILVETON_SET_FILE_V1: file or folder */if(!r.f){result.error="Cannot open SET manifest";return result;}std::array<char,8>magic{};r.bytes(magic.data(),magic.size());if(magic!=kMagic){result.error="Not a SILVETON SET manifest";return result;}const auto version=r.u32();if(version<1U||version>kSampleDecayVersion){result.error="Unsupported SILVETON SET version";return result;}result.data.name=r.str();result.data.global=readGlobal(r,version);
        const auto sampleCount=r.u32();if(sampleCount>10000000U){result.error="SET sample count too large";return result;}std::vector<SamplePtr>samples;samples.reserve(sampleCount);for(std::uint32_t i=0U;i<sampleCount;++i){const std::string name=r.str();const std::string sourceIdentity=version>=8U?r.str():std::string{};const auto rootKey=r.u8();const float fine=r.f32();const bool loopEnabled=r.u8()!=0U;const auto loopStart=r.u32();const auto loopEnd=r.u32();const auto cross=r.u32();const auto rel=r.str();std::string err;auto sp=loadAsset(root/rel,err);if(!sp){result.error="Sample load failed: "+err;return result;}auto m=std::make_shared<SampleData>(*sp);m->name=name;m->sourceIdentity=sourceIdentity;m->rootKey=rootKey;m->fineTuneCents=fine;m->loop.enabled=loopEnabled;m->loop.startFrame=loopStart;m->loop.endFrame=loopEnd;m->loop.crossfadeFrames=cross;samples.push_back(m);} 
        const auto msCount=r.u32();if(msCount>10000000U){result.error="SET multisample count too large";return result;}std::vector<MultisamplePtr>mss;mss.reserve(msCount);for(std::uint32_t i=0U;i<msCount;++i){auto ms=std::make_shared<Multisample>();ms->name=r.str();if(version>=8U)ms->sourceIdentity=r.str();const auto zn=r.u32();if(zn>1000000U){result.error="SET zone count too large";return result;}ms->zones.reserve(zn);for(std::uint32_t zidx=0U;zidx<zn;++zidx){SampleZone z;const auto sid=r.u32();if(sid<samples.size())z.sample=samples[sid];z.keyLow=r.u8();z.keyHigh=r.u8();z.velocityLow=r.u8();z.velocityHigh=r.u8();z.rootKey=r.u8();z.transposeSemitones=r.i8();z.tuneCents=r.f32();z.gainDb=r.f32();z.pan=r.f32();z.oneShot=r.u8()!=0U;z.reverse=r.u8()!=0U;z.nonTranspose=r.u8()!=0U;z.sourceLevelRaw=r.i8();z.sourceFilterRaw=r.i8();ms->zones.push_back(z);}mss.push_back(ms);} 
        const auto progCount=r.u32();if(progCount>100000U){result.error="SET program count too large";return result;}std::vector<ProgramPtr>programs;programs.reserve(progCount);for(std::uint32_t i=0U;i<progCount;++i)programs.push_back(readProgramBody(r,mss,version));
        const auto progSlots=r.u32();for(std::uint32_t i=0U;i<progSlots;++i){ProgramSlot s;s.address=readAddress(r);const auto id=r.u32();if(id<programs.size())s.program=programs[id];result.data.programs.push_back(s);} 
        const auto combiCount=r.u32();for(std::uint32_t i=0U;i<combiCount;++i){CombiSlot s;s.address=readAddress(r);s.combi=readCombi(r,programs,version);result.data.combis.push_back(s);} 
        const auto listCount=r.u32();for(std::uint32_t i=0U;i<listCount;++i){ListSlot s;s.address=readAddress(r);s.list.name=r.str();const auto n=r.u32();if(n>100000U){result.error="SET list entry count too large";return result;}for(std::uint32_t j=0U;j<n;++j){ListEntry e;e.number=r.u16();e.name=r.str();e.combiBank=r.u16();e.combiPage=r.u16();e.combiSlot=r.u16();s.list.entries.push_back(e);}result.data.lists.push_back(s);} 
        if(version>=4U){const auto sampleCatalogCount=r.u32();if(sampleCatalogCount>10000000U){result.error="SET sample catalog too large";return result;}for(std::uint32_t i=0U;i<sampleCatalogCount;++i){SampleCatalogEntry item;item.id=r.u32();const auto sid=r.u32();if(sid<samples.size())item.sample=samples[sid];result.data.samples.push_back(item);}const auto msCatalogCount=r.u32();if(msCatalogCount>10000000U){result.error="SET multisample catalog too large";return result;}for(std::uint32_t i=0U;i<msCatalogCount;++i){MultisampleCatalogEntry item;item.id=r.u32();const auto mid=r.u32();if(mid<mss.size())item.multisample=mss[mid];result.data.multisamples.push_back(item);}}
        if(!r.error.empty()){result.error=r.error;return result;}
        // SILVETON_EVEN_DECAY_LIVE_V1 / SILVETON_ENGINES_V1: the blocks written after everything (see save); a file without
        // them = all off. Unknown blocks stop the reader. Legacy optional blocks
        // retain their tolerance; a damaged live snapshot must not be reported as
        // a successful load of a different performance.
        bool sawBlendScales = false;
        bool sawChannelGates = false;
        bool sawSourceMix = false;
        bool sawDrumGroups = false;
        bool sawSourceEffects = false;
        bool sawNumberedEffects = false;
        bool sawEngineSnapshots = false;
        bool sawSourceTuning = false;
        bool sawSourceAmp = false;
        bool sawSourceSoundFx = false;
        bool sawSourcePortamento = false;
        bool sawSourceSoundEdits = false;
        bool sawSourceOscillatorDsp = false;
        std::vector<PendingNumberedFx> pendingNumberedEffects;
        std::vector<PendingEngineSnapshot> pendingEngineSnapshots;
        std::vector<SourceTuningSnapshot> pendingSourceTuning;
        std::vector<SourceSoundEditSnapshot> pendingSourceSoundEdits;
        std::vector<std::array<std::array<bool,2>,kPartCount>> pendingSourcePortamentoInherit;
        while (r.error.empty() && r.f.peek() != std::char_traits<char>::eof()) {
            const auto blockMark = r.u32();
            if (!r.error.empty()) { result.error=r.error; return result; }
            if (blockMark == 0x44585653U) {
                const auto blockVersion = r.u32();
                const auto n = r.u32();
                if (r.error.empty() && blockVersion == 1U && n == result.data.combis.size()) {
                    std::vector<float> values;
                    for (std::size_t i = 0U; i < static_cast<std::size_t>(n) * static_cast<std::size_t>(kUpperCount) && r.error.empty(); ++i) values.push_back(r.f32());
                    if (r.error.empty()) {
                        std::size_t k = 0U;
                        for (auto& cs : result.data.combis) for (auto& u : cs.combi.uppers) {
                            const float v = values[k++];
                            u.evenDecayMs = std::isfinite(v) && v >= 30.0F ? std::min(v, 10000.0F) : 0.0F;
                        }
                    }
                } else break;
            } else if (blockMark == 0x4E455653U) {
                const auto blockVersion = r.u32();
                const auto n = r.u32();
                if (r.error.empty() && (blockVersion >= 1U && blockVersion <= 6U) && n == result.data.combis.size()) {
                    std::vector<EngineParams> values;
                    values.reserve(static_cast<std::size_t>(n) * static_cast<std::size_t>(kUpperCount));
                    for (std::size_t i = 0U; i < static_cast<std::size_t>(n) * static_cast<std::size_t>(kUpperCount) && r.error.empty(); ++i) {
                        EngineParams e;
                        const auto t = r.u8();
                        e.type = keptEngineType(t, blockVersion >= 6U);
                        // SILVETON_ENGINES_V2: version 1 holds 48 values; version 2 says how many it holds (the rest take the defaults)
                        const int stored = blockVersion == 1U ? kEngineParamCountV1 : static_cast<int>(r.u16());
                        if (stored < 0 || stored > 4096) { r.error = "bad engine block"; break; }
                        e = engineDefaults(e.type);
                        for (int k = 0; k < stored && r.error.empty(); ++k) {
                            const float v = r.f32();
                            if (k < kEngineParamCount) e.p[static_cast<std::size_t>(k)] = engineClamp(e.type, k, v);
                        }
                        engineSanitizeLoaded(e);
                        values.push_back(e);
                    }
                    if (r.error.empty()) {
                        std::size_t k = 0U;
                        for (auto& cs : result.data.combis) for (auto& u : cs.combi.uppers) u.engine = values[k++];
                    }
                } else break;
            } else if (blockMark == 0x53455653U) {   // SILVETON_ENGINE_SLOTS_V1
                const auto blockVersion = r.u32();
                const auto n = r.u32();
                if (r.error.empty() && (blockVersion == 1U || blockVersion == 2U) && n == result.data.combis.size()) {
                    std::vector<UpperPart> values;
                    values.reserve(static_cast<std::size_t>(n) * static_cast<std::size_t>(kEngineSlotCount));
                    for (std::size_t i = 0U; i < static_cast<std::size_t>(n) * static_cast<std::size_t>(kEngineSlotCount) && r.error.empty(); ++i) {
                        UpperPart u;
                        const auto flags = r.u8();
                        u.enabled = (flags & 1U) != 0U; u.mute = (flags & 2U) != 0U;
                        u.levelDb = r.f32(); u.pan = r.f32();
                        const auto vm = r.u8();
                        u.voiceMode = vm <= 2U ? static_cast<UpperVoiceMode>(vm) : UpperVoiceMode::Poly;
                        u.octave = static_cast<std::int8_t>(r.u8()); u.transposeSemitones = static_cast<std::int8_t>(r.u8());
                        u.tuneCents = r.f32(); u.pitchBendRange = static_cast<std::int8_t>(r.u8());
                        u.portamentoSec = r.f32();
                        const auto pm = r.u8();
                        u.portaMode = pm <= 3U ? static_cast<PortamentoMode>(pm) : PortamentoMode::Silveton;
                        const auto pf = r.u8();
                        u.portaFingered = (pf & 1U) != 0U; u.portaRateMode = (pf & 2U) != 0U; u.portaTime = r.u8();
                        const auto t = r.u8();
                        u.engine = engineDefaults(keptEngineType(t, blockVersion >= 2U));
                        const int stored = static_cast<int>(r.u16());
                        if (stored < 0 || stored > 4096) { r.error = "bad engine slot block"; break; }
                        for (int k = 0; k < stored && r.error.empty(); ++k) {
                            const float v = r.f32();
                            if (k < kEngineParamCount) u.engine.p[static_cast<std::size_t>(k)] = engineClamp(u.engine.type, k, v);
                        }
        engineSanitizeLoaded(u.engine);
                        if (blockVersion >= 2U) {   // SILVETON_MODEL_V1: the sound and the envelope of the place
                            const auto id = r.u32(); if (id < programs.size()) u.program = programs[id];
                            u.soundSlotId = r.u16(); u.name = r.str();
                            const auto tone = [&r](float hi) { const float v = r.f32(); return (std::isfinite(v) && v >= 0.0F) ? std::min(v, hi) : -1.0F; };
                            u.toneAttackMs = tone(kToneMaxTimeMs); u.toneDecayMs = tone(kToneMaxTimeMs); u.toneSustain = tone(1.0F); u.toneReleaseMs = tone(kToneMaxTimeMs);
                        }
                        if (!std::isfinite(u.levelDb)) u.levelDb = 0.0F;
                        if (!std::isfinite(u.pan)) u.pan = 0.0F;
                        values.push_back(std::move(u));
                    }
                    if (r.error.empty()) {
                        std::size_t k = 0U;
                        for (auto& cs : result.data.combis) for (auto& u : cs.combi.engineSlots) u = values[k++];
                    }
                } else break;
            } else if (blockMark == 0x51545653U) {   // SILVETON_SET_ONE_FILE_V1
                const auto blockVersion = r.u32();
                if (r.error.empty() && blockVersion == 1U) result.data.extra = r.str(); else break;
            } else if (blockMark == 0x46455653U) {   // SILVETON_PLACE_FX_V1
                const auto blockVersion = r.u32();
                const auto n = r.u32();
                if (r.error.empty() && blockVersion == 1U && n == result.data.combis.size()) {
                    for (auto& cs : result.data.combis) for (std::size_t k = 0U; k < cs.combi.engineSlots.size() && r.error.empty(); ++k) {
                        cs.combi.engineInsert[k] = readFx(r, version);
                        auto& u = cs.combi.engineSlots[k];
                        u.fxSend1 = std::clamp(r.f32(), 0.0F, 1.0F); u.fxSend2 = std::clamp(r.f32(), 0.0F, 1.0F);
                        u.fxSend3 = std::clamp(r.f32(), 0.0F, 1.0F); u.fxSend4 = std::clamp(r.f32(), 0.0F, 1.0F);
                    }
                } else break;
            } else if (blockMark == 0x53505653U) {
                const auto blockVersion = r.u32();
                if (blockVersion != 1U) { result.error = "Unsupported SET performance version"; return result; }
                auto performance = readPerformance(r, programs);
                if (!r.error.empty()) { result.error = r.error; return result; }
                result.data.performance = std::move(performance);
            } else if(blockMark==0x4D535653U){
                if(r.u32()!=1U||r.u32()!=result.data.combis.size()){result.error="Invalid SOLO model extension";return result;}
                std::size_t total=0;
                const auto readModels=[&](Combi&c){for(int i=0;i<kPartCount;++i){auto n=r.u32();if(n>1500000U||(total+=n)>128000000U){r.error="SOLO model extension too large";return;}if(n){std::vector<std::uint8_t>b(n);if(!r.bytes(b.data(),b.size()))return;std::string error;auto m=solo::decodeModel(b,error);if(!m){r.error=error;return;}c.part(i).soloModel=m;}}};
                for(auto&cs:result.data.combis){readModels(cs.combi);if(!r.error.empty()){result.error=r.error;return result;}}
                const auto perf=r.u8();if(perf>1U||(perf!=0)!=result.data.performance.has_value()){result.error="Invalid SOLO performance models";return result;}
                if(perf){readModels(result.data.performance->combi);}
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if(blockMark==0x53535653U){
                if(r.u32()!=1U||r.u32()!=result.data.combis.size()){result.error="Invalid per-sound source extension";return result;}
                std::size_t total=0;
                const auto readSources=[&](Combi& c){
                    for(int pi=0;pi<kPartCount&&r.error.empty();++pi){auto& u=c.part(pi);u.commonProcessing=r.u8()!=0;
                        for(auto& l:u.layers){l.commonProcessing=r.u8()!=0;const auto type=r.u8();
                            if(type!=0&&type!=13){r.error="Invalid sound source";return;}l.engine.type=engineTypeOf(type);
                            for(float& v:l.engine.p){v=r.f32();if(!std::isfinite(v)){r.error="Invalid source control";return;}}
                            engineSanitizeLoaded(l.engine);
                            const auto n=r.u32();if(n>1500000U||(total+=n)>128000000U){r.error="Per-sound models too large";return;}
                            if(n){std::vector<std::uint8_t> bytes(n);if(!r.bytes(bytes.data(),n))return;std::string error;
                                l.soloModel=solo::decodeModel(bytes,error);if(!l.soloModel){r.error=error;return;}}
                        }
                    }
                };
                for(auto& cs:result.data.combis){readSources(cs.combi);if(!r.error.empty()){result.error=r.error;return result;}}
                const auto perf=r.u8();if(perf>1U||(perf!=0)!=result.data.performance.has_value()){result.error="Invalid per-sound performance";return result;}
                if(perf)readSources(result.data.performance->combi);
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if (blockMark == 0x584D5653U) {
                const auto blockVersion=r.u32(),count=r.u32(),parts=r.u32();
                if(sawSourceMix||blockVersion!=1U||count!=result.data.combis.size()||parts!=static_cast<std::uint32_t>(kPartCount)){
                    result.error="Invalid Keyboard Set source mix extension";return result;
                }
                sawSourceMix=true;
                for(auto& cs:result.data.combis){readSourceMix(r,cs.combi);if(!r.error.empty()){result.error=r.error;return result;}}
                const auto perf=r.u8();
                if(perf>1U||(perf!=0U)!=result.data.performance.has_value()){
                    result.error="Invalid live Keyboard Set source mix snapshot";return result;
                }
                if(perf!=0U)readSourceMix(r,result.data.performance->combi);
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if(blockMark==0x54475653U){
                if(sawChannelGates||r.u32()!=1||r.u32()!=result.data.combis.size()){result.error="Invalid channel gate block";return result;}
                sawChannelGates=true;
                for(auto& cs:result.data.combis){readChannelGates(r,cs.combi);if(!r.error.empty()){result.error=r.error;return result;}}
                const auto live=r.u8();
                if(live!=(result.data.performance?1:0)){result.error="Invalid performance gate block";return result;}
                if(live)readChannelGates(r,result.data.performance->combi);
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if(blockMark==0x47445653U){
                const auto blockVersion=r.u32(),totalPrograms=r.u32(),count=r.u32(),keys=r.u32();
                if(!r.error.empty()||sawDrumGroups||blockVersion!=1U||totalPrograms!=programs.size()||
                   count>programs.size()||keys!=static_cast<std::uint32_t>(kMidiKeys)){
                    result.error="Invalid Drum Kit groups block";return result;
                }
                sawDrumGroups=true;std::vector<bool> assigned(programs.size(),false);
                for(std::uint32_t i=0;i<count;++i){
                    const auto id=r.u32();
                    if(!r.error.empty()||id>=programs.size()||!programs[id]||assigned[id]){
                        result.error="Invalid Drum Kit group Program reference";return result;
                    }
                    auto groups=readDrumKeyGroups(r);
                    if(!groups||!r.error.empty()){result.error=r.error.empty()?"Invalid Drum Kit groups":r.error;return result;}
                    // These objects were freshly allocated by readProgramBody
                    // above; all COMBI references must keep the same shared id.
                    std::const_pointer_cast<Program>(programs[id])->drumKeyGroups=std::move(groups);
                    assigned[id]=true;
                }
            } else if (blockMark == 0x58465653U) {
                const auto blockVersion=r.u32(),count=r.u32();
                if(sawSourceEffects||blockVersion!=1U||count!=result.data.combis.size()){
                    result.error="Invalid original FX extension";return result;
                }
                sawSourceEffects=true;std::size_t total=0;
                const auto readOriginal=[&](Combi& c){
                    const auto n=r.u32();
                    if(n>16U*1024U*1024U||(total+=n)>64U*1024U*1024U){r.error="Original FX extension is too large";return;}
                    if(n==0){c.sourceEffects.reset();return;}
                    std::vector<std::uint8_t> bytes(n);if(!r.bytes(bytes.data(),n))return;
                    // This is a native snapshot. Its part send levels are
                    // already stored by writeUpper/SVEF, independently of SVFX.
                    // Rebuild the original rack without recalling its initial
                    // keyboard sends over later edits. Fresh original SET import
                    // still calls applySourceEffects directly and recalls them.
                    std::array<std::array<float,4>,kPartCount> storedSends{};
                    for(int part=0;part<kPartCount;++part){
                        const auto& u=c.part(part);
                        storedSends[static_cast<std::size_t>(part)]={{u.fxSend1,u.fxSend2,u.fxSend3,u.fxSend4}};
                    }
                    std::string error;
                    if(!decodeSourceEffects(bytes,c,error)){r.error=error;return;}
                    if(c.sourceEffects&&!c.sourceEffects->style){
                        for(int part=0;part<kPartCount;++part){
                            auto& u=c.part(part);const auto& sends=storedSends[static_cast<std::size_t>(part)];
                            u.fxSend1=sends[0];u.fxSend2=sends[1];u.fxSend3=sends[2];u.fxSend4=sends[3];
                        }
                    }
                };
                for(auto& cs:result.data.combis){readOriginal(cs.combi);if(!r.error.empty()){result.error=r.error;return result;}}
                const auto live=r.u8();
                if(live!=(result.data.performance?1U:0U)){result.error="Invalid original FX performance snapshot";return result;}
                if(live)readOriginal(result.data.performance->combi);
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if (blockMark == kSourceTuningMark) {
                const auto blockVersion=r.u32(),count=r.u32(),parts=r.u32();
                if(!r.error.empty()||sawSourceTuning||blockVersion!=kSourceTuningVersion||
                   count!=result.data.combis.size()||parts!=static_cast<std::uint32_t>(kPartCount)){
                    result.error="Invalid original channel tuning extension";return result;
                }
                sawSourceTuning=true;
                for(std::size_t owner=0;owner<count;++owner){
                    auto snapshot=readSourceTuning(r);
                    if(!r.error.empty()){result.error=r.error;return result;}
                    pendingSourceTuning.push_back(std::move(snapshot));
                }
                const auto live=r.u8();
                if(!r.error.empty()||live!=(result.data.performance?1U:0U)){
                    result.error="Invalid original channel tuning performance snapshot";return result;
                }
                if(live){
                    auto snapshot=readSourceTuning(r);
                    if(!r.error.empty()){result.error=r.error;return result;}
                    pendingSourceTuning.push_back(std::move(snapshot));
                }
            } else if (blockMark == kEngineSnapshotMark) {
                const auto blockVersion=r.u32(),upperVersion=r.u32(),count=r.u32(),parts=r.u32();
                if(!r.error.empty()||sawEngineSnapshots||blockVersion!=kEngineSnapshotVersion||
                   upperVersion!=kEngineSnapshotUpperVersion||count!=result.data.combis.size()||
                   parts!=static_cast<std::uint32_t>(kEngineSlotCount)){
                    result.error="Invalid full engine-slot snapshot extension";return result;
                }
                sawEngineSnapshots=true;
                for(std::uint32_t owner=0;owner<count;++owner){
                    if(r.u32()!=owner||!r.error.empty()){
                        result.error="Invalid full engine-slot owner index";return result;
                    }
                    for(std::uint32_t slot=0;slot<parts;++slot){
                        if(r.u32()!=slot||!r.error.empty()){
                            result.error="Invalid full engine-slot part index";return result;
                        }
                        auto snapshot=readEngineSnapshot(r,programs);
                        if(!r.error.empty()){result.error=r.error;return result;}
                        snapshot.owner=owner;snapshot.slot=slot;
                        pendingEngineSnapshots.push_back(std::move(snapshot));
                    }
                }
            } else if (blockMark == kNumberedFxMark) {
                const auto blockVersion=r.u32(),count=r.u32();
                if(!r.error.empty()||sawNumberedEffects||(blockVersion!=1U&&blockVersion!=kNumberedFxVersion)||count!=result.data.combis.size()||
                   count>(kMaximumNumberedFxTotalBytes-17U)/4U){
                    result.error="Invalid numbered FX extension";return result;
                }
                sawNumberedEffects=true;std::size_t total=17U+4U*count;
                const auto readNumbered=[&](std::size_t owner){
                    const auto n=r.u32();
                    if(!r.error.empty())return;
                    if(n>kMaximumNumberedFxCombiBytes||n>kMaximumNumberedFxTotalBytes-total){
                        r.error="Numbered FX extension is too large";return;
                    }
                    total+=n;
                    std::string bytes(n,'\0');if(n&&!r.bytes(bytes.data(),n))return;
                    (void)decodeNumberedFxCombi(bytes,owner,blockVersion,pendingNumberedEffects,r.error);
                };
                for(std::size_t owner=0;owner<count;++owner){readNumbered(owner);if(!r.error.empty()){result.error=r.error;return result;}}
                const auto live=r.u8();
                if(!r.error.empty()||live!=(result.data.performance?1U:0U)){
                    result.error="Invalid numbered FX performance snapshot";return result;
                }
                if(live)readNumbered(result.data.combis.size());
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if(blockMark==kSourceAmpMark){
                const auto blockVersion=r.u32(),totalPrograms=r.u32(),count=r.u32();
                if(!r.error.empty()||sawSourceAmp||(blockVersion<1U||blockVersion>kSourceAmpVersion)||
                   totalPrograms!=programs.size()||count>kMaximumSourceAmpRecords){
                    result.error="Invalid original Sound Amp EG block";return result;
                }
                sawSourceAmp=true;std::set<std::pair<std::uint32_t,std::uint32_t>> assigned;
                for(std::uint32_t i=0;i<count;++i){
                    const auto id=r.u32(),layerId=r.u32();const auto enabled=r.u8();
                    if(!r.error.empty()||id>=programs.size()||!programs[id]||layerId>=programs[id]->layers.size()||
                       enabled>1U||!assigned.emplace(id,layerId).second){
                        result.error="Invalid original Sound Amp EG reference";return result;
                    }
                    SourceAmpEnvelope source;source.present=true;source.enabled=enabled!=0U;
                    for(auto& value:source.levels)value=r.u8();
                    for(auto& value:source.times)value=r.u8();
                    if(blockVersion>=2U){
                        const auto modulation=r.u8();
                        if(modulation>1U){result.error="Invalid original Sound Amp EG modulation flag";return result;}
                        source.modulationEncodingSupported=modulation!=0U;
                        for(auto& value:source.amsSources)value=r.u8();
                        for(auto& value:source.amsIntensities)value=r.i8();
                        for(auto& value:source.amsDirections)value=r.u8();
                        for(auto& value:source.keyboardKeys)value=r.u8();
                        for(auto& value:source.keyboardRamps)value=r.i8();
                    }
                    if(blockVersion>=3U){
                        const auto filterTracking=r.u8();
                        if(filterTracking>1U){result.error="Invalid original Sound filter tracking flag";return result;}
                        source.filterKeyboardTrackingPresent=filterTracking!=0U;
                        for(auto& value:source.filterKeyboardKeys)value=r.u8();
                        for(auto& value:source.filterKeyboardRamps)value=r.i8();
                    }
                    if(!r.error.empty()||!source.valid()){
                        result.error="Invalid original Sound Amp EG values";return result;
                    }
                    // All COMBI references share these newly read Program ids.
                    std::const_pointer_cast<Program>(programs[id])->layers[layerId].sourceAmpEnvelope=source;
                }
            } else if(blockMark==kSourceSoundFxMark){
                const auto blockVersion=r.u32(),totalPrograms=r.u32(),count=r.u32();
                if(!r.error.empty()||sawSourceSoundFx||blockVersion!=kSourceProgramMetadataVersion||
                   totalPrograms!=programs.size()||count>programs.size()){
                    result.error="Invalid original Sound FX block";return result;
                }
                sawSourceSoundFx=true;std::vector<bool> assigned(programs.size(),false);
                for(std::uint32_t i=0;i<count;++i){
                    const auto id=r.u32(),size=r.u32();
                    if(!r.error.empty()||id>=programs.size()||!programs[id]||assigned[id]||size==0U||size>kMaximumSourceSoundFxBytes){
                        result.error="Invalid original Sound FX reference";return result;
                    }
                    std::vector<std::uint8_t> bytes(size);r.bytes(bytes.data(),bytes.size());
                    auto effects=std::make_shared<arranger::Pa5xSoundEffectsRaw>();
                    if(!r.error.empty()||!arranger::decodePa5xSoundEffects(bytes,*effects,r.error)){
                        result.error=r.error.empty()?"Invalid original Sound FX values":r.error;return result;
                    }
                    std::const_pointer_cast<Program>(programs[id])->sourceSoundEffects=std::move(effects);
                    assigned[id]=true;
                }
            } else if(blockMark==kSourcePortamentoMark){
                const auto blockVersion=r.u32(),totalPrograms=r.u32(),voiceCount=r.u32(),portamentoCount=r.u32();
                if(!r.error.empty()||sawSourcePortamento||(blockVersion<1U||blockVersion>kSourcePortamentoVersion)||
                   totalPrograms!=programs.size()||voiceCount>programs.size()||portamentoCount>kMaximumSourceAmpRecords){
                    result.error="Invalid original Sound portamento block";return result;
                }
                sawSourcePortamento=true;std::vector<bool> voicesAssigned(programs.size(),false);
                for(std::uint32_t i=0;i<voiceCount;++i){
                    const auto id=r.u32();SourceVoiceAssignment source;source.present=true;
                    source.resourceVersion=r.u8();source.flagsRaw=r.u8();
                    if(blockVersion>=2U){
                        const auto present=r.u8();source.legatoModePresent=present!=0U;
                        source.legatoModeRaw=r.u8();source.legatoExtensionRaw=r.u8();
                        if(present>1U){result.error="Invalid original Sound Legato presence";return result;}
                    }
                    if(!r.error.empty()||id>=programs.size()||!programs[id]||voicesAssigned[id]||!source.valid()){
                        result.error="Invalid original Sound voice assignment";return result;
                    }
                    std::const_pointer_cast<Program>(programs[id])->sourceVoiceAssignment=source;voicesAssigned[id]=true;
                }
                std::set<std::pair<std::uint32_t,std::uint32_t>> assigned;
                for(std::uint32_t i=0;i<portamentoCount;++i){
                    const auto id=r.u32(),layerId=r.u32();const auto supported=r.u8();
                    SourcePortamento source;source.present=true;source.encodingSupported=supported!=0U;
                    source.resourceVersion=r.u8();source.flagsRaw=r.u8();source.timeRaw=r.u8();source.extensionByteCount=r.u8();
                    for(auto& byte:source.extensionRaw)byte=r.u8();
                    if(!r.error.empty()||id>=programs.size()||!programs[id]||layerId>=programs[id]->layers.size()||
                       supported>1U||!source.valid()||!assigned.emplace(id,layerId).second){
                        result.error="Invalid original Sound portamento reference";return result;
                    }
                    std::const_pointer_cast<Program>(programs[id])->layers[layerId].sourcePortamento=source;
                }
                const auto sourceCombiCount=r.u32(),parts=r.u32();
                if(!r.error.empty()||sourceCombiCount!=result.data.combis.size()||parts!=static_cast<std::uint32_t>(kPartCount)){
                    result.error="Invalid source portamento performance count";return result;
                }
                const auto readInheritance=[&]{
                    std::array<std::array<bool,2>,kPartCount> values{};
                    for(auto& part:values)for(auto& value:part){const auto raw=r.u8();if(raw>1U)r.error="Invalid source Sound inheritance";value=raw!=0U;}
                    pendingSourcePortamentoInherit.push_back(values);
                };
                for(std::uint32_t owner=0;owner<sourceCombiCount;++owner)readInheritance();
                const auto live=r.u8();
                if(!r.error.empty()||live!=(result.data.performance?1U:0U)){
                    result.error="Invalid source portamento live performance";return result;
                }
                if(live)readInheritance();
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if(blockMark==kSourceOscillatorDspMark){
                const auto blockVersion=r.u32(),totalPrograms=r.u32(),count=r.u32();
                if(!r.error.empty()||sawSourceOscillatorDsp||blockVersion!=1U||
                   totalPrograms!=programs.size()||count>kMaximumSourceAmpRecords){
                    result.error="Invalid original oscillator metadata block";return result;
                }
                sawSourceOscillatorDsp=true;
                std::set<std::pair<std::uint32_t,std::uint32_t>> assigned;
                for(std::uint32_t i=0;i<count;++i){
                    const auto id=r.u32(),layerId=r.u32(),size=r.u32();
                    if(!r.error.empty()||id>=programs.size()||!programs[id]||layerId>=programs[id]->layers.size()||
                       size==0U||size>kMaximumSourceOscillatorDspBytes||!assigned.emplace(id,layerId).second){
                        result.error="Invalid original oscillator metadata reference";return result;
                    }
                    std::vector<std::uint8_t> bytes(size);r.bytes(bytes.data(),bytes.size());
                    auto source=std::make_shared<SourceOscillatorDsp>();
                    if(!r.error.empty()||!decodeSourceOscillatorDsp(bytes,*source,r.error)){
                        result.error=r.error.empty()?"Invalid original oscillator metadata values":r.error;return result;
                    }
                    std::const_pointer_cast<Program>(programs[id])->layers[layerId].sourceOscillatorDsp=std::move(source);
                }
            } else if(blockMark==kSourceSoundEditsMark){
                const auto blockVersion=r.u32(),owners=r.u32(),parts=r.u32();
                if(!r.error.empty()||sawSourceSoundEdits||blockVersion!=1U||owners!=result.data.combis.size()||
                   parts!=static_cast<std::uint32_t>(kPartCount)){
                    result.error="Invalid original performance Sound Edits block";return result;
                }
                sawSourceSoundEdits=true;
                for(std::uint32_t owner=0;owner<owners;++owner)pendingSourceSoundEdits.push_back(readSourceSoundEdits(r));
                const auto live=r.u8();
                if(!r.error.empty()||live!=(result.data.performance?1U:0U)){
                    result.error="Invalid original Sound Edits live owner";return result;
                }
                if(live)pendingSourceSoundEdits.push_back(readSourceSoundEdits(r));
                if(!r.error.empty()){result.error=r.error;return result;}
            } else if (blockMark == 0x43535653U) {
                const auto blockVersion = r.u32();
                const auto count = r.u32();
                if (sawBlendScales || blockVersion != 1U || count != result.data.combis.size()) {
                    result.error = "Invalid SET scale block"; return result;
                }
                sawBlendScales = true;
                for (auto& cs : result.data.combis) {
                    cs.combi.scale = readBlendScale(r);
                    if (!r.error.empty()) { result.error = r.error; return result; }
                }
                const auto hasPerformance = r.u8();
                if (hasPerformance > 1U || (hasPerformance != 0U) != result.data.performance.has_value()) {
                    result.error = "Invalid open scale snapshot"; return result;
                }
                if (hasPerformance != 0U) result.data.performance->combi.scale = readBlendScale(r);
                if (!r.error.empty()) { result.error = r.error; return result; }
            } else break;
        }
        // Apply only after every recognized extension has been read. A later
        // SVFX block must not erase or implicitly activate a manual assignment.
        for(const auto& entry:pendingNumberedEffects){
            auto& combi=entry.owner<result.data.combis.size()?result.data.combis[entry.owner].combi:
                result.data.performance->combi;
            if(combi.sourceEffects){result.error="Original SET FX and manual numbered FX cannot share an owner";return result;}
        }
        if((sawEngineSnapshots||sawSourceTuning)&&!r.error.empty()){result.error=r.error;return result;}
        // Commit only complete, validated snapshots. Auxiliary extensions are
        // already decoded; merge preserves their independent ownership and the
        // pending numbered assignments below remain authoritative for SVNF.
        for(auto& snapshot:pendingEngineSnapshots)
            mergeEngineSnapshot(result.data.combis[snapshot.owner].combi,snapshot);
        for(std::size_t owner=0;owner<pendingSourcePortamentoInherit.size();++owner){
            auto& combi=owner<result.data.combis.size()?result.data.combis[owner].combi:result.data.performance->combi;
            for(int part=0;part<kPartCount;++part){
                const auto& values=pendingSourcePortamentoInherit[owner][static_cast<std::size_t>(part)];
                combi.part(part).sourcePortamentoInherit=values[0];
                combi.part(part).sourceVoiceInherit=values[1];
            }
        }
        for(std::size_t owner=0;owner<pendingSourceTuning.size();++owner){
            auto& combi=owner<result.data.combis.size()?result.data.combis[owner].combi:result.data.performance->combi;
            applySourceTuning(combi,pendingSourceTuning[owner]);
        }
        for(std::size_t owner=0;owner<pendingSourceSoundEdits.size();++owner){
            auto& combi=owner<result.data.combis.size()?result.data.combis[owner].combi:result.data.performance->combi;
            for(int part=0;part<kPartCount;++part)
                combi.part(part).sourceSoundEdits=pendingSourceSoundEdits[owner][static_cast<std::size_t>(part)];
        }
        for(const auto& entry:pendingNumberedEffects){
            auto& combi=entry.owner<result.data.combis.size()?result.data.combis[entry.owner].combi:
                result.data.performance->combi;
            auto& effect=numberedFxSlot(combi,static_cast<int>(entry.slot));
            effect.numbered=entry.state;effect.numberedModulatingPart=entry.modulatingPart;
        }
        r.error.clear();
        return result;
    }catch(const std::exception&e){result.error=e.what();return result;}}

} // namespace silveton::sampler
