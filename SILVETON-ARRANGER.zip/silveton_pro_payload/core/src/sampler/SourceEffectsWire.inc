// Included by SourceEffectsDecode.inc inside SourceEffects.cpp's namespace.
// Only data declarations are generated. No manufacturer executable/DSP code
// is used. The source bibliography and reviewed Pa compatibility facts live
// in docs/SOURCE_FX_WIRE_LAYOUTS.json.
struct SourceFxValuePiece {
    int first, last;
    double scale, offset;
};
struct SourceFxWireField {
    unsigned first, width;
    bool signedValue;
    int minimum, maximum;
    const char* row;
    const SourceFxValuePiece* values;
    unsigned valueCount;
    // 0 = ordinary; 1 = fixed zero; 2 = unused fixed Input Trim;
    // 3 = a separately reviewed neutral field; 4 = unknown semantics.
    // Pa stores zero for rule2 although the shared M50 table says100.
    // It has no exposed Pa parameter and is not applied as an input gain.
    unsigned fixedRule;
};
struct SourceFxWireLayout {
    unsigned index, endBit;
    const SourceFxWireField* fields;
    unsigned fieldCount;
};

#include "SourceEffectsWireData.inc"

const SourceFxWireLayout* sourceFxWireLayout(unsigned index) noexcept {
    for(const auto& layout:kSourceFxWireLayouts)if(layout.index==index)return &layout;
    return nullptr;
}

void decodeSourceParameterBlock(std::uint16_t selector,const std::array<std::uint8_t,64>& parameters,
                                SourceFxSlotStatus& status) {
    status.decoded={};status.decoded.index=selector;
    status.parameterLayoutKnown=false;status.parameterBlockValid=false;
    status.parametersComplete=false;status.parameterDetail.clear();
    const auto* layout=sourceFxWireLayout(selector);
    const auto* descriptor=findNumberedFx(selector);
    if(!layout||!descriptor){
        status.parameterDetail="Original parameter layout is not established";return;
    }
    status.parameterLayoutKnown=true;
    NumberedFxState decoded;decoded.index=selector;decoded.origin=NumberedFxOrigin::Decoded;
    bool valid=true,unknownField=false;
    std::string problem;
    for(unsigned i=0;i<layout->fieldCount;++i){
        const auto& field=layout->fields[i];
        if(field.width==0||field.width>31||field.first+field.width>512){
            valid=false;problem="Invalid source layout bounds";break;
        }
        const int raw=field.signedValue?sourceFxSignedBits(parameters,field.first,field.width):
            static_cast<int>(sourceFxBits(parameters,field.first,field.width));
        if(field.fixedRule==1){
            if(raw!=0){valid=false;problem="Nonzero reserved/bypass source field";break;}
            continue;
        }
        if(field.fixedRule==2){
            if(raw!=0&&raw!=100){valid=false;problem="Unrecognized unused input-trim encoding";break;}
            continue;
        }
        if(raw<field.minimum||raw>field.maximum){
            valid=false;problem="Original value is outside the established field domain";break;
        }
        if(field.fixedRule==4)unknownField=true;
        if(!field.row||!*field.row)continue;
        const auto* parameter=findNumberedFxParam(selector,field.row);
        if(!parameter){valid=false;problem="Source field has no matching semantic parameter";break;}
        bool found=false;double value=0;
        for(unsigned n=0;n<field.valueCount;++n){
            const auto& piece=field.values[n];
            if(raw>=piece.first&&raw<=piece.last){
                value=static_cast<double>(raw)*piece.scale+piece.offset;found=true;break;
            }
        }
        if(!found)continue; // Unknown conversion remains unknown, including enum interiors.
        if(!numberedFxValueValid(*parameter,value)){
            valid=false;problem="Decoded value is outside its Pa semantic domain";break;
        }
        const auto mask=std::uint64_t{1}<<parameter->ordinal;
        if((decoded.knownMask&mask)!=0&&decoded.values[parameter->ordinal]!=value){
            valid=false;problem="Conflicting source fields address the same parameter";break;
        }
        decoded.values[parameter->ordinal]=value;decoded.knownMask|=mask;
    }
    if(valid&&!sourceFxTailIsZero(parameters,layout->endBit)){
        valid=false;problem="Additional source parameter fields are not decoded";
    }
    status.parameterBlockValid=valid;
    if(!valid){
        // A different field layout invalidates the whole interpretation. Do
        // not present a partially read prefix as trusted saved settings.
        status.parameterDetail=std::move(problem);return;
    }
    status.decoded=decoded;
    const std::uint64_t expected=descriptor->parameterCount==64?~std::uint64_t{0}:
        (std::uint64_t{1}<<descriptor->parameterCount)-1;
    status.parametersComplete=!unknownField&&decoded.knownMask==expected&&decoded.valid();
    unsigned count=0;for(auto mask=decoded.knownMask;mask;mask>>=1U)count+=static_cast<unsigned>(mask&1U);
    status.parameterDetail=std::to_string(count)+"/"+std::to_string(descriptor->parameterCount)+
        " saved parameters decoded";
    if(!status.parametersComplete)status.parameterDetail+="; unknown conversions remain unset";
}

void decodeSourceEffectParameters(const KorgSourceFxDefinition& source,
                                 SourceFxSlotStatus& status) {
    decodeSourceParameterBlock(source.selector,source.parameters,status);
}
