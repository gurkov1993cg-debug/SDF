#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SourceEffects.h"
#include "silveton/sampler/SourceAmpEnvelope.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"
#include "silveton/sampler/NumberedFxRuntime.h"
#include "silveton/sampler/NumberedFxControl.h"
#include "channelstrip/DynamicsCircuitFactory.h"
#include "silveton/sampler/EvenDecay.h"
#include "silveton/sampler/CpuWorkPolicy.h"
#include "silveton/sampler/SampleStream.h"
#include "silveton/sampler/PerformanceDiagnostics.h"
#include "silveton/sampler/UserWaves.h"   // SILVETON_USER_WAVES_V1: before EngineDsp.h (which is included inside a namespace)
#include "SoloVoice.h"
// SILVETON_CRACKLE_FIX_V1
// SILVETON_PRO_SOUND_V1

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <complex>   // SILVETON_ENGINES_V3: EngineDsp.h (the STR-1 body level), included below inside the namespace
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <cstdio>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#include <sys/resource.h>
#elif defined(__APPLE__)
#include <pthread.h>
#include <pthread/qos.h>
#if defined(__SSE__)
#include <xmmintrin.h>
#endif
#endif

namespace silveton::sampler {
namespace {

constexpr double kPi = 3.14159265358979323846264338327950288;
constexpr float kInv127 = 1.0F / 127.0F;

float dbToGain(float db) noexcept {
    return std::pow(10.0F, db / 20.0F);
}

float gainToDb(float gain) noexcept {
    const float g = std::max(gain, 1.0e-12F);
    return 20.0F * std::log10(g);
}

float clamp01(float v) noexcept { return std::clamp(v, 0.0F, 1.0F); }

bool decodedSourceFxActive(const SourceFxRenderParameters& source) noexcept {
    return source.active && source.numbered.index != 0;
}

// This is a semantic DSP graph, not a decoder for any original header byte.
// The adapter must supply verified normalized links and playable endpoints.
// Original MFX2/MFX3 can feed MFX1; the fourth native slot is independent.
struct SourceMasterGraph {
    std::array<float, kFxSendSlots> toFirst{};
    std::uint8_t componentMask{0U};
};

SourceMasterGraph sourceMasterGraph(
        const std::array<SourceFxRenderParameters, kFxSendSlots>& source) noexcept {
    static_assert(kFxSendSlots >= 3 && kFxSendSlots <= 8, "Source master graph uses an eight-bit slot mask");
    SourceMasterGraph graph;
    if (!decodedSourceFxActive(source[0])) return graph;
    for (std::size_t slot = 1U; slot <= 2U; ++slot) {
        const float gain = source[slot].masterToFirst;
        if (!decodedSourceFxActive(source[slot]) || !std::isfinite(gain) || gain <= 0.0F || gain > 1.0F)
            continue;
        graph.toFirst[slot] = gain;
        graph.componentMask |= static_cast<std::uint8_t>(1U | (1U << slot));
    }
    return graph;
}

std::size_t sourceMasterProcessSlot(std::size_t order) noexcept {
    return order == 0U ? 1U : order == 1U ? 2U : order == 2U ? 0U : order;
}

struct Envelope {
    enum class Stage : std::uint8_t { Idle, Attack, Decay, Sustain, Release };

    EnvelopeParams params{};
    Stage stage{Stage::Idle};
    float value{0.0F};
    float releaseStep{0.0F};

    void trigger() noexcept {
        stage = Stage::Attack;
        if (params.attackSec <= 0.0F) {
            value = 1.0F;
            stage = Stage::Decay;
        }
    }

    void release(double sr) noexcept {
        if (stage == Stage::Idle || stage == Stage::Release) return;
        stage = Stage::Release;
        const float frames = static_cast<float>(std::max(1.0, static_cast<double>(params.releaseSec) * sr));
        releaseStep = value / frames;
    }

    void forceOff() noexcept {
        value = 0.0F;
        stage = Stage::Idle;
        releaseStep = 0.0F;
    }

    [[nodiscard]] bool active() const noexcept { return stage != Stage::Idle; }

    float process(double sr) noexcept {
        const float srF = static_cast<float>(std::max(1.0, sr));
        switch (stage) {
            case Stage::Idle:
                value = 0.0F;
                break;
            case Stage::Attack: {
                if (params.attackSec <= 0.0F) {
                    value = 1.0F;
                    stage = Stage::Decay;
                } else {
                    value += 1.0F / (params.attackSec * srF);
                    if (value >= 1.0F) {
                        value = 1.0F;
                        stage = Stage::Decay;
                    }
                }
                break;
            }
            case Stage::Decay: {
                const float sus = clamp01(params.sustain);
                if (params.decaySec <= 0.0F) {
                    value = sus;
                    stage = Stage::Sustain;
                } else {
                    value -= (1.0F - sus) / (params.decaySec * srF);
                    if (value <= sus) {
                        value = sus;
                        stage = Stage::Sustain;
                    }
                }
                break;
            }
            case Stage::Sustain:
                value = clamp01(params.sustain);
                break;
            case Stage::Release:
                value -= releaseStep;
                if (value <= 0.0F || !std::isfinite(value)) {
                    value = 0.0F;
                    stage = Stage::Idle;
                }
                break;
        }
        return value;
    }
};

constexpr float kAttackRatio = 0.3F;   // overshoot ratio of the attack curve
constexpr float kTailRatio = 1.0e-4F;    // decay/release end 80 dB down
constexpr float kMinAttackMs = 0.3F;
constexpr float kMinTimeMs = 1.0F;
constexpr float kMaxFallbackMs = 60000.0F;

// Values of one sound's TONE page for one PROGRAM layer. Unset (negative)
// values fall back to the layer envelope times the Easy Edit scales of the Upper.
UpperToneValues effectiveToneFor(const SoundTone& s, const UpperPart& u, const EnvelopeParams& env) noexcept {
    UpperToneValues t;
    const auto ms = [](float sec, float scale) noexcept {
        const float v = sec * std::clamp(scale, 0.0F, 16.0F) * 1000.0F;
        return std::isfinite(v) ? std::clamp(v, 0.0F, kMaxFallbackMs) : 0.0F;
    };
    t.attackMs = s.attackMs >= 0.0F ? std::min(s.attackMs, kToneMaxTimeMs) : ms(env.attackSec, u.ampAttackScale);
    t.decayMs = s.decayMs >= 0.0F ? std::min(s.decayMs, kToneMaxTimeMs) : ms(env.decaySec, u.ampDecayScale);
    t.releaseMs = s.releaseMs >= 0.0F ? std::min(s.releaseMs, kToneMaxTimeMs) : ms(env.releaseSec, u.ampReleaseScale);
    t.sustain = s.sustain >= 0.0F ? std::min(s.sustain, 1.0F)
                                  : std::clamp(env.sustain * std::clamp(u.ampSustainScale, 0.0F, 2.0F), 0.0F, 1.0F);
    t.cutoffHz = s.cutoffHz >= 0.0F ? std::clamp(s.cutoffHz, 20.0F, kToneCutoffOpenHz) : kToneCutoffOpenHz;
    t.resonance = s.resonance >= 0.0F ? std::min(s.resonance, 1.0F) : 0.0F;
    return t;
}


SoundTone basicToneOf(const UpperPart& u) noexcept {
    SoundTone s;
    s.attackMs = u.toneAttackMs; s.decayMs = u.toneDecayMs; s.sustain = u.toneSustain;
    s.releaseMs = u.toneReleaseMs; s.cutoffHz = u.toneCutoffHz; s.resonance = u.toneResonance;
    s.x = u.toneExtra;
    s.mod = u.toneMod;
    return s;
}

// SILVETON_LAYERS_V1: sound 0 = the basic sound of the Upper, 1..4 = its layers.
constexpr int kSoundsPerUpper = 1 + kUpperLayers;

const UpperLayer* layerOf(const UpperPart& u, int soundIndex) noexcept {
    return (soundIndex >= 1 && soundIndex <= kUpperLayers) ? &u.layers[static_cast<std::size_t>(soundIndex - 1)] : nullptr;
}

// SILVETON_ENGINES_V1: when the Upper has an ENGINE, its filter / drive / unison / PWM / SUB settings replace the hidden
// SYNTH values of the sound, so every voice of the Upper plays through the same instrument. The TONE page keeps the
// envelope, start / end, HP, EQ and vibrato; its CUTOFF / RESON are taken over by the ENGINE while the ENGINE filter is on.
void applyEngineOverlay(SoundTone& t, const EngineParams& e) noexcept {
    if (!e.on()) return;
    t.x.synthBypass=false;t.x.filterType=0;t.x.filterKeyTrack=0;t.x.velToCutoff=0;t.x.drive=0;
    t.x.filter2Type=0;t.x.unisonVoices=1;t.x.analogFeel=false;t.x.pwmWidth=0;t.x.pwmDepth=0;t.x.subLevel=0;
}

SoundTone soundToneOf(const UpperPart& u, int soundIndex) noexcept {
    const UpperLayer* l = layerOf(u, soundIndex);
    SoundTone t = l != nullptr ? l->tone : basicToneOf(u);
    // SILVETON_SYNTH_BYPASS_V1: SYNTH ИЗКЛ = every Polysix function and the matrix read as "off";
    // the stored knob values stay untouched, so SYNTH ВКЛ brings them straight back.
    if (t.x.synthBypass) {
        t.x.pwmWidth = 0.0F; t.x.pwmDepth = 0.0F; t.x.subLevel = 0.0F; t.x.unisonVoices = 1; t.x.drive = 0.0F;
        t.x.filterType = 0; t.x.filterKeyTrack = 0.0F; t.x.filter2Type = 0; t.x.analogFeel = false;
        for (auto& r : t.mod.route) r.source = ModSource::Off;
    }
    if(!soundSource(u,soundIndex).commonProcessing) applyEngineOverlay(t, soundSource(u, soundIndex).engine);   // SILVETON_ENGINES_V1: the ENGINE of the Upper decides the synth block of every sound
    return t;
}

const Program* soundProgramOf(const UpperPart& u, int soundIndex) noexcept {
    if (soundIndex == 0) return u.program.get();
    const UpperLayer* l = layerOf(u, soundIndex);
    return (l != nullptr && l->enabled) ? l->program.get() : nullptr;
}

struct SampleDecayCursor {
    float value{};
    double step{}, position{};
    std::uint32_t remaining{};
    unsigned segment{};

    // Advance exactly to each endpoint; consecutive zero-time stages are legal.
    bool next(const SampleDecayEnvelope& eg, double rate) noexcept {
        while (remaining == 0U) {
            if (segment > 0) position = eg.targets[segment - 1];
            if (segment == eg.targets.size()) { value = 0.0F; return false; }
            const double target = eg.targets[segment];
            remaining = static_cast<std::uint32_t>(std::llround(eg.seconds[segment++] * rate));
            if (remaining != 0U) step = (target - position) / remaining;
        }
        value = static_cast<float>(position);
        position += step;
        --remaining;
        return true;
    }
};

// Professional exponential ADSR (one-pole segments). The release time is exact
// for the level at which the key was released; a SUSTAIN edit glides in ~10 ms.
struct AmpEnv {
    enum class Stage : std::uint8_t { Idle, Attack, Decay, Sustain, Release };
    Stage stage{Stage::Idle};
    float value{0.0F};
    float attackCoef{0.0F}, attackBase{0.0F};
    float decayCoef{0.0F}, decayBase{0.0F};
    float releaseCoef{0.0F}, releaseBase{0.0F};
    float sustainTarget{1.0F};
    float sustainSmooth{0.0F};
    float releaseMs{120.0F},releaseStartLevel{};
    bool sourceEnabled{false};
    SourceAmpCursor source{};

    void useSource(const SourceAmpEnvelope& original,std::uint8_t key,std::uint8_t velocity) noexcept {
        sourceEnabled = original.runtimeEnabled();
        if (sourceEnabled) source.prepare(original,key,velocity);
    }
    void syncSource() noexcept {
        value = source.value;
        switch (source.stage) {
            case SourceAmpCursor::Stage::Idle: stage = Stage::Idle; break;
            case SourceAmpCursor::Stage::Attack: stage = Stage::Attack; break;
            case SourceAmpCursor::Stage::Decay:
            case SourceAmpCursor::Stage::Slope: stage = Stage::Decay; break;
            case SourceAmpCursor::Stage::Sustain: stage = Stage::Sustain; break;
            case SourceAmpCursor::Stage::Release: stage = Stage::Release; break;
        }
    }
    void continueAt(float level) noexcept {
        if (sourceEnabled) { source.continueAt(level); syncSource(); }
        else { value = level; stage = Stage::Decay; }
    }
    void setReleaseRate(double rate) noexcept {
        const double n=std::max(1.0,static_cast<double>(releaseMs)*.001*std::max(1.0,rate));
        releaseCoef=static_cast<float>(std::exp(-std::log((static_cast<double>(releaseStartLevel)+kTailRatio)/kTailRatio)/n));
        releaseBase=-kTailRatio*(1.0F-releaseCoef);
    }

    void trigger() noexcept {
        if (sourceEnabled) { source.trigger(); syncSource(); }
        else stage = Stage::Attack;
    }

    void setBlock(const UpperToneValues& t, double sr) noexcept {
        if (sourceEnabled) {
            source.configure(t.attackMs, t.decayMs, t.sustain, t.releaseMs, sr);
            sustainTarget = t.sustain;
            syncSource();
            return;
        }
        const double rate = std::max(1.0, sr);
        sustainTarget = std::clamp(t.sustain, 0.0F, 1.0F);
        const float nextRelease=std::max(kMinTimeMs,t.releaseMs);
        if(nextRelease!=releaseMs){
            releaseMs=nextRelease;
            if(stage==Stage::Release){releaseStartLevel=value;setReleaseRate(sr);}
        }
        sustainSmooth = static_cast<float>(1.0 - std::exp(-1.0 / (0.010 * rate)));
        const double na = std::max(1.0, static_cast<double>(std::max(kMinAttackMs, t.attackMs)) * 0.001 * rate);
        attackCoef = static_cast<float>(std::exp(-std::log((1.0 + kAttackRatio) / kAttackRatio) / na));
        attackBase = (1.0F + kAttackRatio) * (1.0F - attackCoef);
        const double nd = std::max(1.0, static_cast<double>(std::max(kMinTimeMs, t.decayMs)) * 0.001 * rate);
        decayCoef = static_cast<float>(std::exp(-std::log((1.0 + kTailRatio) / kTailRatio) / nd));
        const float range = std::max(1.0F - sustainTarget, 1.0e-4F);
        decayBase = (sustainTarget - kTailRatio * range) * (1.0F - decayCoef);
    }

    void release(double sr) noexcept {
        if (sourceEnabled) { source.release(); syncSource(); return; }
        if (stage == Stage::Idle || stage == Stage::Release) return;
        if (value <= 1.0e-6F) { value = 0.0F; stage = Stage::Idle; return; }
        stage = Stage::Release;
        releaseStartLevel=value;setReleaseRate(sr);
    }

    void forceOff() noexcept { source.forceOff(); value = 0.0F; stage = Stage::Idle; }
    [[nodiscard]] bool active() const noexcept { return stage != Stage::Idle; }

    float process() noexcept {
        if (sourceEnabled) { source.process(); syncSource(); return value; }
        switch (stage) {
            case Stage::Idle: value = 0.0F; break;
            case Stage::Attack:
                value = attackBase + value * attackCoef;
                if (value >= 1.0F) { value = 1.0F; stage = Stage::Decay; }
                break;
            case Stage::Decay:
                value = decayBase + value * decayCoef;
                if (value <= sustainTarget) { value = sustainTarget; stage = Stage::Sustain; }
                break;
            case Stage::Sustain:
                value += (sustainTarget - value) * sustainSmooth;
                // Zero terminal amplitude is permanent silence, even under
                // CC64. Retire the voice as in the source EG and legacy decay.
                // Keep nonzero sustain targets and normal release tails.
                if (sustainTarget == 0.0F && value <= 1.0e-6F) forceOff();
                break;
            case Stage::Release:
                value = releaseBase + value * releaseCoef;
                if (value <= 0.0F || !std::isfinite(value)) { value = 0.0F; stage = Stage::Idle; }
                break;
        }
        return value;
    }
};

// 12 dB/oct low-pass (TPT state variable) for the Upper TONE CUTOFF.
struct ToneLowPass {
    float a1{0.0F}, a2{0.0F}, a3{0.0F};
    float ic1L{0.0F}, ic2L{0.0F}, ic1R{0.0F}, ic2R{0.0F};
    bool prime{true};

    void set(float cutoffHz, float resonance, double sr) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double q = 0.70710678 * std::pow(2.0, static_cast<double>(std::clamp(resonance, 0.0F, 1.0F)) * 3.8);
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        const double k = 1.0 / q;
        const double a1d = 1.0 / (1.0 + g * (g + k));
        a1 = static_cast<float>(a1d);
        a2 = static_cast<float>(g * a1d);
        a3 = static_cast<float>(g * g * a1d);
    }
    static float tick(float x, float a1, float a2, float a3, float& ic1, float& ic2) noexcept {
        const float v3 = x - ic2;
        const float v1 = a1 * ic1 + a2 * v3;
        const float v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0F * v1 - ic1;
        ic2 = 2.0F * v2 - ic2;
        return v2;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { ic1L = ic1R = 0.0F; ic2L = l; ic2R = r; prime = false; }
        l = tick(l, a1, a2, a3, ic1L, ic2L);
        r = tick(r, a1, a2, a3, ic1R, ic2R);
    }
};

// SILVETON_POLYSIX_V1: 4-pole ladder low-pass (the Polysix / SSM2044 family), zero-delay
// feedback (Zavalishin): four one-pole stages, resonance feeds the output back to the
// input, a soft saturation at the input keeps it musical when it screams.
struct LadderFilter {
    float G{0.0F}, k{0.0F}, comp{1.0F};
    std::array<float, 4> sL{}, sR{};
    bool prime{true};
    void set(float cutoffHz, float resonance, double sr) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        G = static_cast<float>(g / (1.0 + g));
        k = 4.0F * std::clamp(resonance, 0.0F, 1.0F) * 0.98F;
        comp = 1.0F + 0.5F * k;   // keep the bass when the resonance is up
    }
    float tick(float x, std::array<float, 4>& st) const noexcept {
        const float g1 = 1.0F - G;
        const float G2 = G * G, G3 = G2 * G, G4 = G3 * G;
        const float S = g1 * (G3 * st[0] + G2 * st[1] + G * st[2] + st[3]);   // state contribution to the output
        float u = (x * comp - k * S) / (1.0F + k * G4);
        u = std::tanh(u * 0.5F) * 2.0F;   // soft clip
        for (int i = 0; i < 4; ++i) { const float vI = (u - st[static_cast<std::size_t>(i)]) * G; const float y = vI + st[static_cast<std::size_t>(i)]; st[static_cast<std::size_t>(i)] = y + vI; u = y; }
        return u;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { sL.fill(0.0F); sR.fill(0.0F); prime = false; }
        l = tick(l, sL); r = tick(r, sR);
    }
};

// SILVETON_POLYSIX_V1: Korg35 low-pass (the MS-20 filter), after W. Pirkle's zero-delay
// model: LPF1 -> LPF2, a HPF in the feedback with gain K (0..2); K near 2 self-oscillates.
struct Korg35Filter {
    float G{0.0F}, K{0.0F};
    float s1L{0.0F}, s2L{0.0F}, s3L{0.0F}, s1R{0.0F}, s2R{0.0F}, s3R{0.0F};
    bool prime{true};
    void set(float cutoffHz, float resonance, double sr) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        G = static_cast<float>(g / (1.0 + g));
        K = 2.0F * std::clamp(resonance, 0.0F, 1.0F) * 0.985F;
    }
    float tick(float x, float& s1, float& s2, float& s3) const noexcept {
        // LPF1
        const float v1 = (x - s1) * G; const float u = v1 + s1; s1 = u + v1;
        // LPF2 with the HPF1 feedback solved instantly
        const float g1 = 1.0F - G;
        const float den = 1.0F - G * K * g1;
        float y = (G * u - G * K * g1 * s3 + g1 * s2) / std::max(den, 0.05F);
        y = std::tanh(y * 0.8F) * 1.25F;   // the nonlinearity that gives the MS-20 its growl
        const float in2 = u + K * g1 * (y - s3);
        const float v2 = (in2 - s2) * G; const float y2 = v2 + s2; s2 = y2 + v2;
        const float v3 = (y - s3) * G; const float lp3 = v3 + s3; s3 = lp3 + v3;
        return y2;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { s1L = s2L = s3L = s1R = s2R = s3R = 0.0F; prime = false; }
        l = tick(l, s1L, s2L, s3L); r = tick(r, s1R, s2R, s3R);
    }
};

struct LfoState {
    double phase{0.0};
    double ageSec{0.0};
    std::uint32_t randomState{0x12345678U};
    float heldRandom{0.0F};

    void reset(bool keySync) noexcept {
        ageSec = 0.0;
        if (keySync) phase = 0.0;
    }

    float process(const LfoParams& p, double sr) noexcept {
        const double safeSr = std::max(1.0, sr);
        ageSec += 1.0 / safeSr;
        const double oldPhase = phase;
        phase += std::max(0.0F, p.frequencyHz) / safeSr;
        phase -= std::floor(phase);

        float v = 0.0F;
        switch (p.wave) {
            case LfoWave::Sine: v = static_cast<float>(std::sin(2.0 * kPi * phase)); break;
            case LfoWave::Triangle: v = static_cast<float>(1.0 - 4.0 * std::abs(phase - 0.5)); break;
            case LfoWave::SawUp: v = static_cast<float>(2.0 * phase - 1.0); break;
            case LfoWave::SawDown: v = static_cast<float>(1.0 - 2.0 * phase); break;
            case LfoWave::Square: v = phase < 0.5 ? 1.0F : -1.0F; break;
            case LfoWave::RandomHold:
                if (phase < oldPhase) {
                    randomState = randomState * 1664525U + 1013904223U;
                    heldRandom = static_cast<float>((static_cast<double>(randomState) / 4294967295.0) * 2.0 - 1.0);
                }
                v = heldRandom;
                break;
        }

        if (ageSec < static_cast<double>(std::max(0.0F, p.delaySec))) return 0.0F;
        const float fade = p.fadeSec <= 0.0F
            ? 1.0F
            : clamp01(static_cast<float>((ageSec - static_cast<double>(p.delaySec)) / static_cast<double>(p.fadeSec)));
        return v * fade;
    }
};

struct StateVariableFilter {
    float ic1eqL{0.0F};
    float ic2eqL{0.0F};
    float ic1eqR{0.0F};
    float ic2eqR{0.0F};

    void reset() noexcept { ic1eqL = ic2eqL = ic1eqR = ic2eqR = 0.0F; }

    float processOne(float x, float& ic1eq, float& ic2eq, FilterMode mode,
                     float cutoffHz, float resonance, double sampleRate) noexcept {
        if (mode == FilterMode::Bypass) return x;
        const float nyquistSafe = static_cast<float>(std::max(100.0, sampleRate * 0.45));
        const float cutoff = std::clamp(cutoffHz, 20.0F, nyquistSafe);
        const float g = std::tan(static_cast<float>(kPi) * cutoff / static_cast<float>(sampleRate));
        const float q = 0.5F + std::clamp(resonance, 0.0F, 1.0F) * 11.5F;
        const float k = 1.0F / q;
        const float a1 = 1.0F / (1.0F + g * (g + k));
        const float a2 = g * a1;
        const float a3 = g * a2;
        const float v3 = x - ic2eq;
        const float v1 = a1 * ic1eq + a2 * v3;
        const float v2 = ic2eq + a2 * ic1eq + a3 * v3;
        ic1eq = 2.0F * v1 - ic1eq;
        ic2eq = 2.0F * v2 - ic2eq;
        const float low = v2;
        const float band = v1;
        const float high = x - k * band - low;
        switch (mode) {
            case FilterMode::LowPass: return low;
            case FilterMode::HighPass: return high;
            case FilterMode::BandPass: return band;
            case FilterMode::Bypass: return x;
        }
        return x;
    }

    // SILVETON_RENDER_SPEED_V1: the coefficients (two tan() per sample before)
    // are computed only when cutoff / resonance really change. Same formulas,
    // same result.
    float cCut{-1.0F}, cRes{-1.0F};
    double cSr{0.0};
    float cK{0.0F}, cA1{0.0F}, cA2{0.0F}, cA3{0.0F};

    float processCached(float x, float& ic1eq, float& ic2eq, FilterMode mode) const noexcept {
        const float v3 = x - ic2eq;
        const float v1 = cA1 * ic1eq + cA2 * v3;
        const float v2 = ic2eq + cA2 * ic1eq + cA3 * v3;
        ic1eq = 2.0F * v1 - ic1eq;
        ic2eq = 2.0F * v2 - ic2eq;
        switch (mode) {
            case FilterMode::LowPass: return v2;
            case FilterMode::HighPass: return x - cK * v1 - v2;
            case FilterMode::BandPass: return v1;
            case FilterMode::Bypass: return x;
        }
        return x;
    }

    void process(float& l, float& r, FilterMode mode, float cutoffHz, float resonance, double sr) noexcept {
        if (mode == FilterMode::Bypass) return;
        if (cutoffHz != cCut || resonance != cRes || sr != cSr) {
            cCut = cutoffHz; cRes = resonance; cSr = sr;
            const float nyquistSafe = static_cast<float>(std::max(100.0, sr * 0.45));
            const float cutoff = std::clamp(cutoffHz, 20.0F, nyquistSafe);
            const float g = std::tan(static_cast<float>(kPi) * cutoff / static_cast<float>(sr));
            const float q = 0.5F + std::clamp(resonance, 0.0F, 1.0F) * 11.5F;
            cK = 1.0F / q;
            cA1 = 1.0F / (1.0F + g * (g + cK));
            cA2 = g * cA1;
            cA3 = g * cA2;
        }
        l = processCached(l, ic1eqL, ic2eqL, mode);
        r = processCached(r, ic1eqR, ic2eqR, mode);
    }
};

struct Biquad {
    float b0{1.0F}, b1{0.0F}, b2{0.0F}, a1{0.0F}, a2{0.0F};
    float z1L{0.0F}, z2L{0.0F}, z1R{0.0F}, z2R{0.0F};

    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0F; }

    void setPeaking(double sr, float freq, float q, float gainDb) noexcept {
        const double A = std::pow(10.0, static_cast<double>(gainDb) / 40.0);
        const double w0 = 2.0 * kPi * static_cast<double>(freq) / sr;
        const double alpha = std::sin(w0) / (2.0 * std::max(0.1, static_cast<double>(q)));
        const double c = std::cos(w0);
        const double a0 = 1.0 + alpha / A;
        b0 = static_cast<float>((1.0 + alpha * A) / a0);
        b1 = static_cast<float>((-2.0 * c) / a0);
        b2 = static_cast<float>((1.0 - alpha * A) / a0);
        a1 = static_cast<float>((-2.0 * c) / a0);
        a2 = static_cast<float>((1.0 - alpha / A) / a0);
    }

    void setShelf(double sr, float freq, float gainDb, bool high) noexcept {
        const double A = std::pow(10.0, static_cast<double>(gainDb) / 40.0);
        const double w0 = 2.0 * kPi * static_cast<double>(freq) / sr;
        const double c = std::cos(w0);
        const double s = std::sin(w0);
        const double alpha = s / std::sqrt(2.0);
        const double beta = 2.0 * std::sqrt(A) * alpha;
        double B0, B1, B2, A0, A1, A2;
        if (high) {
            B0 = A * ((A + 1.0) + (A - 1.0) * c + beta);
            B1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * c);
            B2 = A * ((A + 1.0) + (A - 1.0) * c - beta);
            A0 = (A + 1.0) - (A - 1.0) * c + beta;
            A1 = 2.0 * ((A - 1.0) - (A + 1.0) * c);
            A2 = (A + 1.0) - (A - 1.0) * c - beta;
        } else {
            B0 = A * ((A + 1.0) - (A - 1.0) * c + beta);
            B1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * c);
            B2 = A * ((A + 1.0) - (A - 1.0) * c - beta);
            A0 = (A + 1.0) + (A - 1.0) * c + beta;
            A1 = -2.0 * ((A - 1.0) + (A + 1.0) * c);
            A2 = (A + 1.0) + (A - 1.0) * c - beta;
        }
        b0 = static_cast<float>(B0 / A0);
        b1 = static_cast<float>(B1 / A0);
        b2 = static_cast<float>(B2 / A0);
        a1 = static_cast<float>(A1 / A0);
        a2 = static_cast<float>(A2 / A0);
    }

    static float tick(float x, float& z1, float& z2, float b0, float b1, float b2, float a1, float a2) noexcept {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void process(float& l, float& r) noexcept {
        l = tick(l, z1L, z2L, b0, b1, b2, a1, a2);
        r = tick(r, z1R, z2R, b0, b1, b2, a1, a2);
    }
};

// SILVETON_EQ5_V1: double-precision biquad (TDF2) for the common Upper EQ.
// Peaks use the Orfanidis design ("Digital Parametric Equalizer Design With
// Prescribed Nyquist-Frequency Gain", 1997): the digital curve matches the analog
// one up to Nyquist instead of cramping towards 20 kHz. Shelves are RBJ (at
// 96 kHz their cramping is negligible); HP/LP are Butterworth sections.
struct DBiquad {
    double b0{1.0}, b1{0.0}, b2{0.0}, a1{0.0}, a2{0.0};
    double z1L{0.0}, z2L{0.0}, z1R{0.0}, z2R{0.0};

    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0; }
    void identity() noexcept { b0 = 1.0; b1 = b2 = a1 = a2 = 0.0; }

    void setPeakingMatched(double sr, double freq, double q, double gainDb) noexcept {
        const double G = std::pow(10.0, gainDb / 20.0);
        if (std::abs(gainDb) < 1.0e-6) { identity(); return; }
        const double w0 = 2.0 * kPi * std::clamp(freq, 10.0, 0.49 * sr) / sr;
        const double Dw = w0 / std::max(0.05, q);
        const double G0 = 1.0;                       // gain at DC
        const double GB = std::sqrt(G);              // bandwidth gain (geometric mean)
        const double G2 = G * G, GB2 = GB * GB, G02 = G0 * G0;
        const double F = std::abs(G2 - GB2);
        const double G00 = std::abs(G2 - G02);
        const double F00 = std::abs(GB2 - G02);
        // Gain of the analog prototype at the Nyquist frequency: that is what the
        // digital filter is made to reach there (instead of returning to 0 dB).
        const double num = G02 * (w0 * w0 - kPi * kPi) * (w0 * w0 - kPi * kPi) + G2 * F00 * kPi * kPi * Dw * Dw / F;
        const double den = (w0 * w0 - kPi * kPi) * (w0 * w0 - kPi * kPi) + F00 * kPi * kPi * Dw * Dw / F;
        const double G1u = std::sqrt(std::max(0.0, num / den));
        const double G12u = G1u * G1u;
        const double G01 = std::abs(G2 - G0 * G1u);
        const double G11 = std::abs(G2 - G12u);
        const double F01 = std::abs(GB2 - G0 * G1u);
        const double F11 = std::abs(GB2 - G12u);
        const double W2 = std::sqrt(G11 / G00) * std::tan(w0 / 2.0) * std::tan(w0 / 2.0);
        const double DW = (1.0 + std::sqrt(F00 / F11) * W2) * std::tan(Dw / 2.0);
        const double C = F11 * DW * DW - 2.0 * W2 * (F01 - std::sqrt(F00 * F11));
        const double D = 2.0 * W2 * (G01 - std::sqrt(G00 * G11));
        const double A = std::sqrt(std::max(0.0, (C + D) / F));
        const double B = std::sqrt(std::max(0.0, (G2 * C + GB2 * D) / F));
        const double a0 = 1.0 + W2 + A;
        b0 = (G1u + G0 * W2 + B) / a0;
        b1 = -2.0 * (G1u - G0 * W2) / a0;
        b2 = (G1u - B + G0 * W2) / a0;
        a1 = -2.0 * (1.0 - W2) / a0;
        a2 = (1.0 + W2 - A) / a0;
        if (!std::isfinite(b0) || !std::isfinite(b1) || !std::isfinite(b2) || !std::isfinite(a1) || !std::isfinite(a2)) {
            setPeakingRbj(sr, freq, q, gainDb);
        }
    }

    void setPeakingRbj(double sr, double freq, double q, double gainDb) noexcept {
        const double A = std::pow(10.0, gainDb / 40.0);
        const double w0 = 2.0 * kPi * std::clamp(freq, 10.0, 0.49 * sr) / sr;
        const double alpha = std::sin(w0) / (2.0 * std::max(0.05, q));
        const double c = std::cos(w0);
        const double a0 = 1.0 + alpha / A;
        b0 = (1.0 + alpha * A) / a0; b1 = (-2.0 * c) / a0; b2 = (1.0 - alpha * A) / a0;
        a1 = (-2.0 * c) / a0; a2 = (1.0 - alpha / A) / a0;
    }

    void setShelf(double sr, double freq, double gainDb, double q, bool high) noexcept {
        if (std::abs(gainDb) < 1.0e-6) { identity(); return; }
        const double A = std::pow(10.0, gainDb / 40.0);
        const double w0 = 2.0 * kPi * std::clamp(freq, 10.0, 0.49 * sr) / sr;
        const double c = std::cos(w0), s = std::sin(w0);
        const double S = std::clamp(q, 0.3, 1.5);   // shelf slope: 1 = steepest without ripple
        const double alpha = s / 2.0 * std::sqrt((A + 1.0 / A) * (1.0 / S - 1.0) + 2.0);
        const double beta = 2.0 * std::sqrt(A) * alpha;
        double B0, B1, B2, A0, A1, A2;
        if (high) {
            B0 = A * ((A + 1.0) + (A - 1.0) * c + beta); B1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * c); B2 = A * ((A + 1.0) + (A - 1.0) * c - beta);
            A0 = (A + 1.0) - (A - 1.0) * c + beta; A1 = 2.0 * ((A - 1.0) - (A + 1.0) * c); A2 = (A + 1.0) - (A - 1.0) * c - beta;
        } else {
            B0 = A * ((A + 1.0) - (A - 1.0) * c + beta); B1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * c); B2 = A * ((A + 1.0) - (A - 1.0) * c - beta);
            A0 = (A + 1.0) + (A - 1.0) * c + beta; A1 = -2.0 * ((A - 1.0) + (A + 1.0) * c); A2 = (A + 1.0) + (A - 1.0) * c - beta;
        }
        b0 = B0 / A0; b1 = B1 / A0; b2 = B2 / A0; a1 = A1 / A0; a2 = A2 / A0;
    }

    // One Butterworth section (q = 0.7071 for 12 dB; 0.5412 and 1.3066 for 24 dB).
    void setPass(double sr, double freq, double q, bool high) noexcept {
        const double w0 = 2.0 * kPi * std::clamp(freq, 10.0, 0.49 * sr) / sr;
        const double c = std::cos(w0);
        const double alpha = std::sin(w0) / (2.0 * q);
        const double a0 = 1.0 + alpha;
        if (high) { b0 = (1.0 + c) / 2.0 / a0; b1 = -(1.0 + c) / a0; b2 = b0; }
        else { b0 = (1.0 - c) / 2.0 / a0; b1 = (1.0 - c) / a0; b2 = b0; }
        a1 = -2.0 * c / a0; a2 = (1.0 - alpha) / a0;
    }

    static double tick(double x, double& z1, double& z2, double b0, double b1, double b2, double a1, double a2) noexcept {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void process(float& l, float& r) noexcept {
        l = static_cast<float>(tick(l, z1L, z2L, b0, b1, b2, a1, a2));
        r = static_cast<float>(tick(r, z1R, z2R, b0, b1, b2, a1, a2));
    }
};

// The running state of one Upper's common EQ: targets move smoothly (about
// 20 ms), coefficients are recomputed only while something moves.
// The strip detector is stereo linked. Its panel maps 0 dB to -18 dBFS.
struct StripGateState {
    SslDynamicsCircuit circuit;
    ChannelGate settings{};
    float wet{},ramp{};
    void prepare(double rate) noexcept {
        circuit.prepare(rate);settings={};wet=0;ramp=static_cast<float>(1.0/std::max(1.0,rate*.003));
    }
    bool active() const noexcept {return settings.enabled||wet>0;}
    void update(const ChannelGate& next) noexcept {
        if(settings==next)return;
        if(next.enabled){
            if(!active())circuit.reset();
            circuit.setCircuit(DynamicsCircuitFactory::fromPanel(0,1,.3F,false,false,false,
                next.thresholdDb,next.rangeDb,next.holdSec,next.releaseSec,next.fastAttack,next.expand,true));
        }
        settings=next;
    }
    void process(float& left,float& right) noexcept {
        const double l2=double(left)*left,r2=double(right)*right;
        const float gain=circuit.processPowers((l2+r2)*.5,std::max(l2,r2));
        wet=settings.enabled?std::min(1.0F,wet+ramp):std::max(0.0F,wet-ramp);
        const float linked=1.0F+wet*(gain-1.0F);left*=linked;right*=linked;
    }
};
struct UpperEqState {
    std::array<DBiquad, kUpperEqBands> band{};
    std::array<DBiquad, 2U> hp{}, lp{};
    std::array<float, kUpperEqBands> gainNow{}, freqNow{}, qNow{};
    float hpNow{40.0F}, lpNow{18000.0F};
    std::array<bool, kUpperEqBands> bandActive{};
    bool hpActive{false}, lpActive{false};
    std::uint8_t hpSlope{12U}, lpSlope{12U};
    bool primed{false};

    void reset() noexcept {
        for (auto& b : band) b.reset();
        for (auto& b : hp) b.reset();
        for (auto& b : lp) b.reset();
        bandActive.fill(false); hpActive = lpActive = false; primed = false;
    }

    static bool approach(float& now, float target, float alpha, float eps) noexcept {
        if (now == target) return false;
        now += (target - now) * alpha;
        if (std::abs(now - target) <= eps) now = target;
        return true;
    }

    // Once per block. alpha = smoothing fraction for this block length.
    void update(const UpperEq& eq, double sr, float alpha) noexcept {
        if (!primed) {
            for (std::size_t i = 0; i < band.size(); ++i) { gainNow[i] = eq.on && eq.band[i].on ? eq.band[i].gainDb : 0.0F; freqNow[i] = eq.band[i].freqHz; qNow[i] = eq.band[i].q; }
            hpNow = eq.hpHz; lpNow = eq.lpHz;
            primed = true;
            for (std::size_t i = 0; i < band.size(); ++i) coef(i, sr);
            hpSlope = eq.hpSlopeDb; lpSlope = eq.lpSlopeDb;
            coefPass(sr, true); coefPass(sr, false);
        }
        for (std::size_t i = 0; i < band.size(); ++i) {
            const auto& b = eq.band[i];
            const float gTarget = (eq.on && b.on) ? std::clamp(b.gainDb, -18.0F, 18.0F) : 0.0F;
            bool moved = approach(gainNow[i], gTarget, alpha, 0.005F);
            moved |= approach(freqNow[i], std::clamp(b.freqHz, 20.0F, 20000.0F), alpha, 0.05F);
            moved |= approach(qNow[i], std::clamp(b.q, 0.1F, 10.0F), alpha, 0.002F);
            if (moved) coef(i, sr);
        }
        const bool wantHp = eq.on && eq.hpOn;
        const bool wantLp = eq.on && eq.lpOn;
        if (wantHp != hpActive) { hpActive = wantHp; hp[0].reset(); hp[1].reset(); }
        if (wantLp != lpActive) { lpActive = wantLp; lp[0].reset(); lp[1].reset(); }
        bool hpMoved = approach(hpNow, std::clamp(eq.hpHz, 10.0F, 2000.0F), alpha, 0.05F);
        if (hpSlope != eq.hpSlopeDb) { hpSlope = eq.hpSlopeDb; hpMoved = true; }
        if (hpMoved) coefPass(sr, true);
        bool lpMoved = approach(lpNow, std::clamp(eq.lpHz, 1000.0F, 20000.0F), alpha, 0.5F);
        if (lpSlope != eq.lpSlopeDb) { lpSlope = eq.lpSlopeDb; lpMoved = true; }
        if (lpMoved) coefPass(sr, false);
    }

    void coef(std::size_t i, double sr) noexcept {
        const bool active = std::abs(gainNow[i]) >= 0.01F;
        if (active && !bandActive[i]) band[i].reset();
        bandActive[i] = active;
        if (!active) return;
        if (i == 0U) band[i].setShelf(sr, freqNow[i], gainNow[i], 1.0, false);
        else if (i == static_cast<std::size_t>(kUpperEqBands - 1)) band[i].setShelf(sr, freqNow[i], gainNow[i], 1.0, true);
        else band[i].setPeakingMatched(sr, freqNow[i], qNow[i], gainNow[i]);
    }

    void coefPass(double sr, bool high) noexcept {
        auto& sec = high ? hp : lp;
        const double f = high ? hpNow : lpNow;
        const bool steep = (high ? hpSlope : lpSlope) >= 24U;
        if (steep) { sec[0].setPass(sr, f, 0.54119610, high); sec[1].setPass(sr, f, 1.30656296, high); }
        else { sec[0].setPass(sr, f, 0.70710678, high); sec[1].identity(); }
    }

    void process(float& l, float& r) noexcept {
        if (hpActive) { hp[0].process(l, r); if (hpSlope >= 24U) hp[1].process(l, r); }
        for (std::size_t i = 0; i < band.size(); ++i) if (bandActive[i]) band[i].process(l, r);
        if (lpActive) { lp[0].process(l, r); if (lpSlope >= 24U) lp[1].process(l, r); }
    }

    [[nodiscard]] bool any() const noexcept {
        return hpActive || lpActive || std::any_of(bandActive.begin(), bandActive.end(), [](bool on) noexcept { return on; });
    }
};

// SILVETON_TONE_V2: per-sound bus filters (HIGH-PASS + 3-band EQ of the basic
// sound or a layer), set from the TONE values once per block when they change.
struct SoundBusState {
    Biquad hp{}, low{}, mid{}, high{};
    float hpHz{-1.0F}, lowDb{0.0F}, midDb{0.0F}, highDb{0.0F};
    bool hpOn{false}, lowOn{false}, midOn{false}, highOn{false};

    void reset() noexcept { hp.reset(); low.reset(); mid.reset(); high.reset(); hpHz = -1.0F; hpOn = lowOn = midOn = highOn = false; }

    void update(const ToneExtra& x, double sr) noexcept {
        const float hz = std::clamp(x.highPassHz, 0.0F, 4000.0F);
        if (hz != hpHz) {
            hpHz = hz;
            const bool on = hz >= 10.0F;
            if (on && !hpOn) hp.reset();
            hpOn = on;
            if (on) {
                DBiquad d; d.setPass(sr, hz, 0.70710678, true);
                hp.b0 = static_cast<float>(d.b0); hp.b1 = static_cast<float>(d.b1); hp.b2 = static_cast<float>(d.b2);
                hp.a1 = static_cast<float>(d.a1); hp.a2 = static_cast<float>(d.a2);
            }
        }
        const auto upd = [sr](Biquad& q, float& now, bool& on, float target, float freq, bool shelfHigh, bool peak) noexcept {
            const float t = std::clamp(target, -18.0F, 18.0F);
            if (t == now) return;
            now = t;
            const bool want = std::abs(t) >= 0.01F;
            if (want && !on) q.reset();
            on = want;
            if (!want) return;
            if (peak) q.setPeaking(sr, freq, 0.75F, t); else q.setShelf(sr, freq, t, shelfHigh);
        };
        upd(low, lowDb, lowOn, x.eqLowDb, 120.0F, false, false);
        upd(mid, midDb, midOn, x.eqMidDb, 1200.0F, false, true);
        upd(high, highDb, highOn, x.eqHighDb, 7000.0F, true, false);
    }

    [[nodiscard]] bool any() const noexcept { return hpOn || lowOn || midOn || highOn; }
    void process(float& l, float& r) noexcept {
        if (hpOn) hp.process(l, r);
        if (lowOn) low.process(l, r);
        if (midOn) mid.process(l, r);
        if (highOn) high.process(l, r);
    }
};

float reverbSecondsFor(float feedback) noexcept;

// SILVETON_FX_V3: a stereo delay line on the heap (sized once in prepare()).
struct HeapLine {
    std::vector<float> left, right;
    std::size_t size{0U}, write{0U};

    void allocate(std::size_t frames) { size = std::max<std::size_t>(frames, 16U); left.assign(size, 0.0F); right.assign(size, 0.0F); write = 0U; }
    void clear() noexcept { std::fill(left.begin(), left.end(), 0.0F); std::fill(right.begin(), right.end(), 0.0F); write = 0U; }
    [[nodiscard]] double maxDelay() const noexcept { return static_cast<double>(size - 3U); }

    static float tapOne(const std::vector<float>& b, std::size_t size, std::size_t write, double delayFrames) noexcept {
        double rp = static_cast<double>(write) - delayFrames;
        while (rp < 0.0) rp += static_cast<double>(size);
        const auto i0 = static_cast<std::size_t>(rp) % size;
        const auto i1 = (i0 + 1U) % size;
        const float frac = static_cast<float>(rp - std::floor(rp));
        return b[i0] + (b[i1] - b[i0]) * frac;
    }
    [[nodiscard]] float tapL(double d) const noexcept { return tapOne(left, size, write, d); }
    [[nodiscard]] float tapR(double d) const noexcept { return tapOne(right, size, write, d); }
    // Hermite (4-point) read: cleaner than linear for modulated (tape/chorus) taps.
    static float tapHermite(const std::vector<float>& b, std::size_t size, std::size_t write, double delayFrames) noexcept {
        double rp = static_cast<double>(write) - delayFrames;
        while (rp < 0.0) rp += static_cast<double>(size);
        const auto i1 = static_cast<std::size_t>(rp) % size;
        const float t = static_cast<float>(rp - std::floor(rp));
        const float y0 = b[(i1 + size - 1U) % size], y1 = b[i1], y2 = b[(i1 + 1U) % size], y3 = b[(i1 + 2U) % size];
        const float c0 = y1, c1 = 0.5F * (y2 - y0), c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3, c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
        return ((c3 * t + c2) * t + c1) * t + c0;
    }
    [[nodiscard]] float tapHL(double d) const noexcept { return tapHermite(left, size, write, d); }
    [[nodiscard]] float tapHR(double d) const noexcept { return tapHermite(right, size, write, d); }
    void push(float l, float r) noexcept { left[write] = l; right[write] = r; write = (write + 1U) % size; }
};

// One-pole low-pass used all over the effects (tone, damping).
struct OnePole {
    float z{0.0F};
    float process(float x, float a) noexcept { z += (x - z) * a; return z; }
};

// A 6 dB/oct one-pole coefficient for a cutoff.
float onePoleCoef(double hz, double sr) noexcept {
    return static_cast<float>(1.0 - std::exp(-2.0 * kPi * std::clamp(hz, 5.0, 0.45 * sr) / std::max(1.0, sr)));
}

// SILVETON_FX_V3: DELAYS. DIGITAL (clean, TIME glides), TAPE (wow/flutter,
// saturation and head loss in the loop), PING-PONG (repeats alternate L/R),
// MULTI-TAP (four taps at 1/4 .. 4/4 of TIME), DUCKING (the repeats step back
// while you play and come up when you stop).
struct DelayEngine {
    HeapLine line{};
    double sampleRate{48000.0};
    double currentDelay{-1.0};
    double timeSmooth{0.0};
    OnePole toneL{}, toneR{}, headL{}, headR{};
    double wowPhase{0.0}, flutterPhase{0.0};
    float duckEnv{0.0F}, duckGain{1.0F};

    void allocate(double sr, double maxSec) { sampleRate = sr; line.allocate(static_cast<std::size_t>(maxSec * sr) + 64U); reset(); }
    void reset() noexcept {
        line.clear(); currentDelay = -1.0;
        timeSmooth = 1.0 - std::exp(-1.0 / (0.060 * std::max(1.0, sampleRate)));
        toneL = toneR = headL = headR = OnePole{}; wowPhase = flutterPhase = 0.0; duckEnv = 0.0F; duckGain = 1.0F;
    }

    static double delayMs(const EffectSlot& p) noexcept {
        if (p.tempoSync) {
            const double bpm = std::clamp(static_cast<double>(p.tempoBpm), 30.0, 300.0);
            return std::clamp(60000.0 / bpm * 4.0 * std::clamp(static_cast<double>(p.division), 1.0 / 64.0, 1.0), 1.0, 2500.0);
        }
        return std::clamp(static_cast<double>(p.timeMs), 1.0, 2500.0);
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        const double ms = delayMs(p);
        const double target = std::clamp(sampleRate * ms / 1000.0, 1.0, line.maxDelay() - 8.0);
        if (currentDelay < 0.0) currentDelay = target;
        else currentDelay += (target - currentDelay) * timeSmooth;
        const float t = std::clamp(p.tone, 0.0F, 1.0F);
        const float toneA = 0.08F + 0.92F * t * t;
        const float fb = std::clamp(p.feedback, 0.0F, 0.95F);
        float dl = 0.0F, dr = 0.0F;
        switch (p.type) {
            case EffectType::TapeDelay: {
                // wow (slow) + flutter (fast) move the read head; HEAD LOSS darkens, tape saturates the loop
                const double m = std::clamp(static_cast<double>(p.mod), 0.0, 1.0);
                wowPhase += 2.0 * kPi * 0.6 / sampleRate; if (wowPhase > 2.0 * kPi) wowPhase -= 2.0 * kPi;
                flutterPhase += 2.0 * kPi * 7.3 / sampleRate; if (flutterPhase > 2.0 * kPi) flutterPhase -= 2.0 * kPi;
                const double dev = sampleRate * (0.0025 * std::sin(wowPhase) + 0.0004 * std::sin(flutterPhase)) * m;
                dl = line.tapHL(std::max(1.0, currentDelay + dev));
                dr = line.tapHR(std::max(1.0, currentDelay + dev * 0.9));
                break;
            }
            case EffectType::MultiTap: {
                const float spread = 0.3F + 0.7F * std::clamp(p.depth, 0.0F, 1.0F);
                const double d1 = std::max(1.0, currentDelay * 0.25), d2 = std::max(1.0, currentDelay * 0.5), d3 = std::max(1.0, currentDelay * 0.75);
                dl = line.tapL(currentDelay) + 0.7F * line.tapL(d3) * (1.0F - spread) + 0.5F * line.tapL(d2) + 0.35F * line.tapL(d1) * spread;
                dr = line.tapR(currentDelay) + 0.7F * line.tapR(d3) * spread + 0.5F * line.tapR(d2) + 0.35F * line.tapR(d1) * (1.0F - spread);
                break;
            }
            default:
                dl = line.tapL(currentDelay);
                dr = line.tapR(currentDelay);
                break;
        }
        float fl = toneL.process(dl, toneA);
        float fr = toneR.process(dr, toneA);
        if (p.type == EffectType::TapeDelay) {
            const float drive = 1.0F + 1.5F * std::clamp(p.depth, 0.0F, 1.0F);
            fl = std::tanh(fl * drive) / drive;
            fr = std::tanh(fr * drive) / drive;
            const float head = onePoleCoef(4500.0 + 8000.0 * (1.0 - static_cast<double>(std::clamp(p.mod, 0.0F, 1.0F))), sampleRate);
            fl = headL.process(fl, head);
            fr = headR.process(fr, head);
        }
        if (p.type == EffectType::PingPong) {
            // mono in, repeats cross: L feeds R, R feeds L
            const float mono = 0.5F * (inL + inR);
            line.push(mono + fr * fb, fl * fb);
        } else {
            line.push(inL + fl * fb, inR + fr * fb);
        }
        if (p.type == EffectType::DuckDelay) {
            const float level = std::max(std::abs(inL), std::abs(inR));
            const float aAtt = onePoleCoef(60.0, sampleRate), aRel = onePoleCoef(1.2, sampleRate);
            duckEnv += (level - duckEnv) * (level > duckEnv ? aAtt : aRel);
            const float amount = std::clamp(p.depth, 0.0F, 1.0F);
            const float duckTarget = 1.0F - amount * std::clamp(duckEnv * 6.0F, 0.0F, 1.0F);
            duckGain += (duckTarget - duckGain) * onePoleCoef(20.0, sampleRate);
            fl *= duckGain; fr *= duckGain;
        }
        wetL = fl; wetR = fr;
    }
};

// SILVETON_FX_V3: CHORUS (2..4 voices on one line, each with its own LFO phase),
// FLANGER (short delay + feedback, LFO), PHASER (4/6/8 all-pass stages), ROTARY
// (horn and drum: tremolo + Doppler through a modulated delay, slow/fast with inertia).
struct ModEngine {
    HeapLine line{};
    double sampleRate{48000.0};
    double phase{0.0};
    float fbL{0.0F}, fbR{0.0F};
    std::array<float, 8U> apL{}, apR{};
    double fastPhase{0.0};         // ensemble fast LFO
    double rotSpeed{0.0};          // current rotor speed (Hz) with inertia
    double hornPhase{0.0}, drumPhase{0.0};
    float splitL{0.0F}, splitR{0.0F};

    void allocate(double sr) { sampleRate = sr; line.allocate(static_cast<std::size_t>(0.06 * sr) + 64U); reset(); }
    void reset() noexcept { line.clear(); phase = 0.0; fastPhase = 0.0; fbL = fbR = 0.0F; apL.fill(0.0F); apR.fill(0.0F); rotSpeed = 0.0; hornPhase = drumPhase = 0.0; splitL = splitR = 0.0F; }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        const double rate = std::clamp(static_cast<double>(p.rateHz), 0.02, 12.0);
        const float depth = std::clamp(p.depth, 0.0F, 1.0F);
        switch (p.type) {
            case EffectType::Chorus: {
                line.push(inL, inR);
                const int voices = std::clamp(static_cast<int>(std::lround(p.param1)), 2, 4);
                const double base = sampleRate * 0.012;
                const double dep = sampleRate * 0.008 * static_cast<double>(depth);
                float l = 0.0F, r = 0.0F;
                for (int v = 0; v < voices; ++v) {
                    const double ph = phase + static_cast<double>(v) / static_cast<double>(voices);
                    const double lfo = 0.5 + 0.5 * std::sin(2.0 * kPi * ph);
                    const double d = base * (1.0 + 0.35 * v) + dep * lfo;
                    if ((v & 1) == 0) { l += line.tapHL(d); r += line.tapHR(d + 0.0007 * sampleRate); }
                    else { r += line.tapHR(d); l += line.tapHL(d + 0.0007 * sampleRate); }
                }
                const float norm = 1.0F / static_cast<float>(voices) * 1.4F;
                wetL = l * norm; wetR = r * norm;
                break;
            }
            case EffectType::Flanger: {
                const float fb = std::clamp(p.feedback, -0.95F, 0.95F);
                line.push(inL + fbL * fb, inR + fbR * fb);
                const double lfoL = 0.5 + 0.5 * std::sin(2.0 * kPi * phase);
                const double lfoR = 0.5 + 0.5 * std::sin(2.0 * kPi * (phase + 0.5 * (1.0 - depth)));
                const double minD = sampleRate * 0.0006, span = sampleRate * 0.0075 * depth;
                fbL = line.tapHL(minD + span * lfoL);
                fbR = line.tapHR(minD + span * lfoR);
                wetL = fbL; wetR = fbR;
                break;
            }
            case EffectType::Phaser: {
                const int stages = std::clamp(static_cast<int>(std::lround(p.param1)) & ~1, 4, 8);
                const double lfo = 0.5 + 0.5 * std::sin(2.0 * kPi * phase);
                const double fMin = 200.0, fMax = 200.0 + 2800.0 * depth;
                const double fc = fMin * std::pow(fMax / fMin, lfo);
                const float a = static_cast<float>((std::tan(kPi * fc / sampleRate) - 1.0) / (std::tan(kPi * fc / sampleRate) + 1.0));
                const float fb = std::clamp(p.feedback, 0.0F, 0.9F);
                float xl = inL + fbL * fb, xr = inR + fbR * fb;
                for (int s = 0; s < stages; ++s) {
                    const auto i = static_cast<std::size_t>(s);
                    const float yl = a * xl + apL[i]; apL[i] = xl - a * yl; xl = yl;
                    const float yr = a * xr + apR[i]; apR[i] = xr - a * yr; xr = yr;
                }
                fbL = xl; fbR = xr;
                wetL = xl; wetR = xr;
                break;
            }
            case EffectType::Rotary: {
                // SLOW = rateHz, FAST = param1 (Hz), param2 >= 0.5 = fast. The rotor speeds up / slows down (inertia).
                const double slow = std::clamp(static_cast<double>(p.rateHz), 0.1, 2.0);
                const double fast = std::clamp(static_cast<double>(p.param1) > 0.0 ? static_cast<double>(p.param1) : 6.5, 2.0, 10.0);
                const double want = p.param2 >= 0.5F ? fast : slow;
                rotSpeed += (want - rotSpeed) * (1.0 - std::exp(-1.0 / (1.2 * sampleRate)));
                hornPhase += 2.0 * kPi * rotSpeed / sampleRate; if (hornPhase > 2.0 * kPi) hornPhase -= 2.0 * kPi;
                drumPhase += 2.0 * kPi * rotSpeed * 0.85 / sampleRate; if (drumPhase > 2.0 * kPi) drumPhase -= 2.0 * kPi;
                // crossover 800 Hz: drum = low, horn = high
                const float xo = onePoleCoef(800.0, sampleRate);
                splitL += (inL - splitL) * xo; splitR += (inR - splitR) * xo;
                const float lowL = splitL, lowR = splitR, highL = inL - splitL, highR = inR - splitR;
                line.push(highL, highR);
                const double dop = sampleRate * 0.0009 * (0.3 + 0.7 * depth);
                const double sh = std::sin(hornPhase), ch = std::cos(hornPhase);
                const float hornL = line.tapHL(sampleRate * 0.0012 + dop * (1.0 + sh)) * static_cast<float>(0.55 + 0.45 * sh);
                const float hornR = line.tapHR(sampleRate * 0.0012 + dop * (1.0 - sh)) * static_cast<float>(0.55 - 0.45 * sh);
                const float drumL = lowL * static_cast<float>(0.7 + 0.3 * std::sin(drumPhase));
                const float drumR = lowR * static_cast<float>(0.7 - 0.3 * std::sin(drumPhase));
                (void)ch;
                wetL = hornL + drumL; wetR = hornR + drumR;
                break;
            }
            case EffectType::Ensemble: {
                // SILVETON_POLYSIX_V1: string-machine ensemble - three taps on one line, each moved
                // by a slow (0.6 Hz) and a fast (6 Hz) triangle 120 degrees apart; DEPTH = width.
                line.push(inL, inR);
                const double slowPh = phase;                       // 'rate' is used as the slow speed scale
                const double fastPh = fastPhase;
                const double base = sampleRate * 0.0045;
                const double dSlow = sampleRate * 0.0028 * static_cast<double>(depth);
                const double dFast = sampleRate * 0.00035 * static_cast<double>(depth);
                float l = 0.0F, r = 0.0F;
                for (int v = 0; v < 3; ++v) {
                    const double off = static_cast<double>(v) / 3.0;
                    const auto triAt = [](double ph) noexcept { ph -= std::floor(ph); return 1.0 - 4.0 * std::abs(ph - 0.5); };
                    const double d = base + dSlow * (0.5 + 0.5 * triAt(slowPh + off)) + dFast * (0.5 + 0.5 * triAt(fastPh + off));
                    const float tl = line.tapHL(d), tr = line.tapHR(d + 0.0003 * sampleRate);
                    if (v == 0) { l += tl; r += tr; } else if (v == 1) { l += tl * 0.8F; r += tr * 0.5F; } else { l += tl * 0.5F; r += tr * 0.8F; }
                }
                wetL = l * 0.55F; wetR = r * 0.55F;
                fastPhase += 6.0 * std::clamp(static_cast<double>(p.rateHz), 0.1, 2.0) / 0.6 / sampleRate; fastPhase -= std::floor(fastPhase);
                break;
            }
            default: wetL = inL; wetR = inR; break;
        }
        phase += rate / sampleRate; phase -= std::floor(phase);
    }
};

// SILVETON_FX_V3: HALL / ROOM / CHAMBER - an 8-line feedback delay network
// (Jot) with a Householder mix, input diffusion, early reflections, damping in
// every line and slow modulation of the line lengths (no metallic ringing).
// SIZE scales every length, DECAY = reverb time, DAMPING = high-frequency loss,
// TONE = output colour, MOD = modulation depth, PRE-DELAY.
struct FdnReverb {
    static constexpr std::size_t kLines = 8U;
    double sampleRate{48000.0};
    std::vector<float> pre;           // pre-delay + early reflections
    std::size_t preSize{0U}, preW{0U};
    std::array<std::vector<float>, kLines> line{};
    std::array<std::size_t, kLines> lineSize{}, lineW{};
    std::array<float, kLines> damp{}, fb{};
    std::array<std::vector<float>, 4U> diff{};
    std::array<std::size_t, 4U> diffSize{}, diffW{};
    std::array<double, kLines> modPhase{};
    OnePole outL{}, outR{};
    float bwState{0.0F};
    EffectType kind{EffectType::Hall};

    static constexpr std::array<double, kLines> kBaseMs{{29.7, 37.1, 41.1, 43.7, 53.3, 59.9, 67.3, 73.1}};   // hall, SIZE 0.5
    static constexpr std::array<double, 4U> kDiffMs{{4.3, 6.7, 9.1, 12.3}};

    void allocate(double sr) {
        sampleRate = sr;
        preSize = static_cast<std::size_t>(0.25 * sr) + 64U; pre.assign(preSize, 0.0F);
        for (std::size_t i = 0; i < kLines; ++i) { lineSize[i] = static_cast<std::size_t>(kBaseMs[i] * 2.2 * 0.001 * sr) + 64U; line[i].assign(lineSize[i], 0.0F); }
        for (std::size_t i = 0; i < 4U; ++i) { diffSize[i] = static_cast<std::size_t>(kDiffMs[i] * 1.6 * 0.001 * sr) + 16U; diff[i].assign(diffSize[i], 0.0F); }
        reset();
    }
    void reset() noexcept {
        std::fill(pre.begin(), pre.end(), 0.0F); preW = 0U;
        for (std::size_t i = 0; i < kLines; ++i) { std::fill(line[i].begin(), line[i].end(), 0.0F); lineW[i] = 0U; modPhase[i] = static_cast<double>(i) * 0.7; }
        for (std::size_t i = 0; i < 4U; ++i) { std::fill(diff[i].begin(), diff[i].end(), 0.0F); diffW[i] = 0U; }
        damp.fill(0.0F); fb.fill(0.0F); outL = outR = OnePole{}; bwState = 0.0F;
    }

    static float readLine(const std::vector<float>& b, std::size_t size, std::size_t w, double d) noexcept {
        return HeapLine::tapOne(b, size, w, d);
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR,
                 const SourceFxRenderParameters* source = nullptr) noexcept {
        const float seconds = source && source->active ? std::clamp(source->reverbSeconds, 0.1F, 10.0F) : reverbSecondsFor(p.feedback);
        const double size = 0.35 + 1.3 * std::clamp(static_cast<double>(p.size), 0.0, 1.0);   // 0.35 .. 1.65 x
        double sizeK = size, modDepthMs = 0.0, erGain = 0.0, diffG = 0.0;
        float bright = 1.0F;
        switch (p.type) {
            case EffectType::Room:    sizeK = size * 0.45; modDepthMs = 0.15; erGain = 0.55; diffG = 0.55; bright = 0.9F; break;
            case EffectType::Chamber: sizeK = size * 0.7;  modDepthMs = 0.25; erGain = 0.35; diffG = 0.7;  bright = 0.75F; break;
            default:                  sizeK = size;        modDepthMs = 0.45; erGain = 0.2;  diffG = 0.62; bright = 1.0F; break;   // hall
        }
        modDepthMs *= 0.3 + 1.4 * static_cast<double>(std::clamp(p.mod, 0.0F, 1.0F));
        const double dampHz = 1500.0 + 14000.0 * std::pow(1.0 - static_cast<double>(std::clamp(p.damping, 0.0F, 1.0F)), 1.6);
        const float dampA = onePoleCoef(dampHz, sampleRate);
        const float toneA = onePoleCoef(2500.0 + 15000.0 * static_cast<double>(std::clamp(p.tone, 0.0F, 1.0F)) * static_cast<double>(bright), sampleRate);

        // pre-delay + early reflections from the pre line
        const double preD = std::clamp(static_cast<double>(p.preDelayMs), 0.0, 200.0) * 0.001 * sampleRate;
        const float mono = 0.5F * (inL + inR);
        pre[preW] = mono; preW = (preW + 1U) % preSize;
        float x = HeapLine::tapOne(pre, preSize, preW, preD + 1.0);
        float erL = 0.0F, erR = 0.0F;
        if (erGain > 0.0) {
            static constexpr std::array<double, 6U> erMs{{7.3, 11.9, 17.1, 23.3, 29.7, 38.1}};
            static constexpr std::array<float, 6U> erG{{0.8F, 0.65F, 0.55F, 0.45F, 0.35F, 0.28F}};
            for (std::size_t i = 0; i < erMs.size(); ++i) {
                const float e = HeapLine::tapOne(pre, preSize, preW, preD + 1.0 + erMs[i] * sizeK * 0.001 * sampleRate) * erG[i];
                if ((i & 1U) == 0U) erL += e; else erR += e;
            }
        }
        // input bandwidth + diffusion (four nested all-passes)
        bwState += (x - bwState) * 0.9F;
        x = bwState;
        for (std::size_t i = 0; i < 4U; ++i) {
            const double d = std::max(1.0, kDiffMs[i] * (0.6 + 0.6 * sizeK) * 0.001 * sampleRate);
            const float dOut = HeapLine::tapOne(diff[i], diffSize[i], diffW[i], d);
            const float v = x - static_cast<float>(diffG) * dOut;
            diff[i][diffW[i]] = v; diffW[i] = (diffW[i] + 1U) % diffSize[i];
            x = dOut + static_cast<float>(diffG) * v;
        }
        // read the 8 lines (modulated), damp, mix with a Householder matrix, feed back
        std::array<float, kLines> out{};
        float sum = 0.0F;
        for (std::size_t i = 0; i < kLines; ++i) {
            modPhase[i] += 2.0 * kPi * (0.11 + 0.07 * static_cast<double>(i)) / sampleRate;
            if (modPhase[i] > 2.0 * kPi) modPhase[i] -= 2.0 * kPi;
            const double len = kBaseMs[i] * sizeK * 0.001 * sampleRate + modDepthMs * 0.001 * sampleRate * std::sin(modPhase[i]);
            const double lenC = std::clamp(len, 2.0, static_cast<double>(lineSize[i] - 4U));
            float v = readLine(line[i], lineSize[i], lineW[i], lenC);
            damp[i] += (v - damp[i]) * dampA;
            v = damp[i];
            // gain for this line length so that every line decays in the same reverb time
            const float g = std::pow(10.0F, -3.0F * static_cast<float>(lenC / sampleRate) / std::max(0.05F, seconds));
            out[i] = v * g;
            sum += out[i];
        }
        const float h = -2.0F / static_cast<float>(kLines) * sum;   // Householder: y = x - (2/N) * sum
        for (std::size_t i = 0; i < kLines; ++i) {
            const float in = ((i & 1U) == 0U ? x : -x) * 0.5F;
            line[i][lineW[i]] = out[i] + h + in;
            lineW[i] = (lineW[i] + 1U) % lineSize[i];
        }
        float l = out[0] - out[1] + out[2] - out[3] + out[4] - out[5] + out[6] - out[7];
        float r = out[0] + out[1] - out[2] - out[3] + out[4] + out[5] - out[6] - out[7];
        const float earlyLevel = source && source->active ? source->earlyLevel : 1.0F;
        const float reverbLevel = source && source->active ? source->reverbLevel : 1.0F;
        l = outL.process(l, toneA) * 0.6F * reverbLevel + erL * static_cast<float>(erGain) * earlyLevel;
        r = outR.process(r, toneA) * 0.6F * reverbLevel + erR * static_cast<float>(erGain) * earlyLevel;
        wetL = l; wetR = r;
    }
};

// SILVETON_FX_V3: SPRING reverb - two springs, each a feedback loop whose
// dispersion comes from a chain of 24 stretched all-pass sections (the "boing"
// chirp), with low-pass loss. DECAY = loop gain, TONE = brightness, SIZE = spring length.
struct SpringReverb {
    double sampleRate{48000.0};
    struct Spring {
        std::vector<float> loop; std::size_t size{0U}, w{0U};
        std::array<float, 24U> ap{};
        OnePole lp{};
        float fbState{0.0F};
    };
    std::array<Spring, 2U> s{};
    OnePole outL{}, outR{};
    std::vector<float> pre; std::size_t preSize{0U}, preW{0U};

    void allocate(double sr) {
        sampleRate = sr;
        for (auto& sp : s) { sp.size = static_cast<std::size_t>(0.12 * sr) + 64U; sp.loop.assign(sp.size, 0.0F); }
        preSize = static_cast<std::size_t>(0.2 * sr) + 64U; pre.assign(preSize, 0.0F);
        reset();
    }
    void reset() noexcept {
        for (auto& sp : s) { std::fill(sp.loop.begin(), sp.loop.end(), 0.0F); sp.w = 0U; sp.ap.fill(0.0F); sp.lp = OnePole{}; sp.fbState = 0.0F; }
        std::fill(pre.begin(), pre.end(), 0.0F); preW = 0U; outL = outR = OnePole{};
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        const float mono = 0.5F * (inL + inR);
        pre[preW] = mono; preW = (preW + 1U) % preSize;
        const double preD = std::clamp(static_cast<double>(p.preDelayMs), 0.0, 150.0) * 0.001 * sampleRate;
        const float x = HeapLine::tapOne(pre, preSize, preW, preD + 1.0);
        const float decay = 0.55F + 0.42F * std::clamp(p.feedback, 0.0F, 0.95F) / 0.95F;
        const float lossA = onePoleCoef(1800.0 + 5000.0 * static_cast<double>(std::clamp(p.tone, 0.0F, 1.0F)), sampleRate);
        const double sizeK = 0.5 + 1.0 * std::clamp(static_cast<double>(p.size), 0.0, 1.0);
        const float apCoef = -0.62F;
        float outA = 0.0F, outB = 0.0F;
        for (std::size_t k = 0; k < 2U; ++k) {
            auto& sp = s[k];
            const double len = std::clamp((k == 0U ? 41.0 : 53.0) * sizeK * 0.001 * sampleRate, 4.0, static_cast<double>(sp.size - 4U));
            float v = HeapLine::tapOne(sp.loop, sp.size, sp.w, len);
            v = sp.lp.process(v, lossA);
            // dispersion: 24 first-order all-passes with the same coefficient
            for (auto& z : sp.ap) { const float y = apCoef * v + z; z = v - apCoef * y; v = y; }
            v = std::tanh(v * 1.2F) / 1.2F;   // the spring does not grow
            sp.fbState = v;
            sp.loop[sp.w] = x * 0.5F + v * decay; sp.w = (sp.w + 1U) % sp.size;
            if (k == 0U) outA = v; else outB = v;
        }
        wetL = outL.process(outA * 0.8F + outB * 0.3F, 0.9F);
        wetR = outR.process(outB * 0.8F + outA * 0.3F, 0.9F);
    }
};

// SILVETON_FX_V3: COMPRESSOR (peak detector, soft knee) and DRIVE (tanh with tone).
struct DynamicsFx {
    double sampleRate{48000.0};
    float env{0.0F};
    float grDb{0.0F};
    OnePole toneL{}, toneR{};
    void allocate(double sr) { sampleRate = sr; reset(); }
    void reset() noexcept { env = 0.0F; grDb = 0.0F; toneL = toneR = OnePole{}; }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        if (p.type == EffectType::Drive) {
            const float drive = 1.0F + 24.0F * std::clamp(p.depth, 0.0F, 1.0F) * std::clamp(p.depth, 0.0F, 1.0F);
            const float toneA = onePoleCoef(1200.0 + 16000.0 * static_cast<double>(std::clamp(p.tone, 0.0F, 1.0F)), sampleRate);
            const float outG = dbToGain(std::clamp(p.param1, -24.0F, 12.0F)) / std::sqrt(drive);
            wetL = toneL.process(std::tanh(inL * drive), toneA) * outG;
            wetR = toneR.process(std::tanh(inR * drive), toneA) * outG;
            return;
        }
        const float thr = std::clamp(p.param1, -60.0F, 0.0F);
        const float ratio = std::clamp(p.param2 > 1.0F ? p.param2 : 4.0F, 1.0F, 20.0F);
        const float aAtt = onePoleCoef(1000.0 / std::clamp(static_cast<double>(p.timeMs), 0.1, 300.0), sampleRate);
        const float aRel = onePoleCoef(1000.0 / std::clamp(static_cast<double>(p.param3 > 0.0F ? p.param3 : 120.0F), 10.0, 3000.0), sampleRate);
        const float level = std::max(std::abs(inL), std::abs(inR));
        env += (level - env) * (level > env ? aAtt : aRel);
        const float lvlDb = gainToDb(env);
        const float knee = 6.0F;
        float over = lvlDb - thr;
        float gr = 0.0F;
        if (over > knee * 0.5F) gr = over - over / ratio;
        else if (over > -knee * 0.5F) { const float t = over + knee * 0.5F; gr = (1.0F - 1.0F / ratio) * t * t / (2.0F * knee); }
        grDb = gr;
        const float g = dbToGain(-gr + std::clamp(p.tone, 0.0F, 24.0F));   // tone = make-up dB here
        wetL = inL * g; wetR = inR * g;
    }
};

// SILVETON_FX_V2: studio plate REVERB (J. Dattorro, "Effect Design Part 1", 1997):
// four input diffusers and a modulated figure-eight tank, stereo output taps.
// DECAY (the FEEDBACK value 0..0.95) = reverb time 0.6..12 s, TONE = brightness.
// Fixed arrays sized for up to 192 kHz: no allocation in the audio thread.
float reverbSecondsFor(float feedback) noexcept {
    const float v = std::clamp(feedback, 0.0F, 0.95F) / 0.95F;
    return 0.6F * std::pow(20.0F, v);
}

template <std::size_t N>
struct FxLine {
    std::array<float, N> buf{};
    std::size_t w{0U};
    void clear() noexcept { buf.fill(0.0F); w = 0U; }
    // Sample pushed d samples ago (d = 1 is the newest), d < N.
    [[nodiscard]] float at(std::size_t d) const noexcept { return buf[(w + N - d) % N]; }
    [[nodiscard]] float atFrac(double d) const noexcept {
        const auto di = static_cast<std::size_t>(d);
        const float frac = static_cast<float>(d - static_cast<double>(di));
        const float a = at(di);
        const float b = at(di + 1U);
        return a + (b - a) * frac;
    }
    void push(float v) noexcept { buf[w] = v; w = (w + 1U) % N; }
};

struct ReverbFx {
    static constexpr double kBaseRate = 29761.0;
    FxLine<24576U> pre{};      // SILVETON_FX_V3: PRE-DELAY up to 200 ms at 96 kHz
    OnePole toneOutL{}, toneOutR{};
    FxLine<1024U> in1{}, in2{};
    FxLine<2560U> in3{};
    FxLine<2048U> in4{};
    FxLine<4608U> modL{};
    FxLine<28800U> delL1{};
    FxLine<11776U> apL{};
    FxLine<24064U> delL2{};
    FxLine<6016U> modR{};
    FxLine<27264U> delR1{};
    FxLine<17152U> apR{};
    FxLine<20480U> delR2{};
    std::size_t lPre{1U}, l1{1U}, l2{1U}, l3{1U}, l4{1U};
    std::size_t lDelL1{1U}, lApL{1U}, lDelL2{1U}, lDelR1{1U}, lApR{1U}, lDelR2{1U};
    double lModL{1.0}, lModR{1.0}, excursion{1.0};
    std::array<std::size_t, 14U> tapsAt{};
    double scale{1.0};
    double lfoPhase{0.0}, lfoStep{0.0};
    float bandwidthState{0.0F}, dampL{0.0F}, dampR{0.0F};
    float feedL{0.0F}, feedR{0.0F};

    std::size_t sc(double base, std::size_t cap) const noexcept {
        return std::clamp<std::size_t>(static_cast<std::size_t>(std::lround(base * scale)), 1U, cap - 3U);
    }

    void reset(double sr) noexcept {
        scale = std::clamp(std::max(1.0, sr) / kBaseRate, 0.5, 192000.0 / kBaseRate);
        pre.clear(); in1.clear(); in2.clear(); in3.clear(); in4.clear();
        modL.clear(); delL1.clear(); apL.clear(); delL2.clear();
        modR.clear(); delR1.clear(); apR.clear(); delR2.clear();
        lPre = sc(0.010 * kBaseRate, 24576U);
        toneOutL = toneOutR = OnePole{};
        l1 = sc(142.0, 1024U); l2 = sc(107.0, 1024U); l3 = sc(379.0, 2560U); l4 = sc(277.0, 2048U);
        excursion = 16.0 * scale;
        lModL = 672.0 * scale;
        lModR = 908.0 * scale;
        lDelL1 = sc(4453.0, 28800U); lApL = sc(1800.0, 11776U); lDelL2 = sc(3720.0, 24064U);
        lDelR1 = sc(4217.0, 27264U); lApR = sc(2656.0, 17152U); lDelR2 = sc(3163.0, 20480U);
        const std::array<double, 14U> taps{{266.0, 2974.0, 1913.0, 1996.0, 1990.0, 187.0, 1066.0,
                                            353.0, 3627.0, 1228.0, 2673.0, 2111.0, 335.0, 121.0}};
        for (std::size_t i = 0; i < taps.size(); ++i) {
            tapsAt[i] = std::max<std::size_t>(1U, static_cast<std::size_t>(std::lround(taps[i] * scale)));
        }
        lfoPhase = 0.0;
        lfoStep = 2.0 * kPi * 0.9 / std::max(1.0, sr);
        bandwidthState = dampL = dampR = feedL = feedR = 0.0F;
    }

    template <std::size_t N>
    static float allpass(FxLine<N>& line, std::size_t len, float x, float g) noexcept {
        const float d = line.at(len);
        const float v = x - g * d;
        line.push(v);
        return d + g * v;
    }

    template <std::size_t N>
    static float allpassMod(FxLine<N>& line, double len, float x, float g) noexcept {
        const float d = line.atFrac(len);
        const float v = x - g * d;
        line.push(v);
        return d + g * v;
    }

    template <std::size_t N>
    static float delay(FxLine<N>& line, std::size_t len, float x) noexcept {
        const float d = line.at(len);
        line.push(x);
        return d;
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR,
                 const SourceFxRenderParameters* source = nullptr) noexcept {
        const float seconds = source && source->active ? std::clamp(source->reverbSeconds, 0.1F, 10.0F) : reverbSecondsFor(p.feedback);
        // Tank gain per trip for this reverb time (measured T30, any sample rate).
        const float decay = std::clamp(std::pow(10.0F, -0.571F / seconds), 0.0F, 0.95F);
        // SILVETON_FX_V3: DAMPING = loss in the tank, TONE = colour of the output, PRE-DELAY in ms.
        const float dampK = std::clamp(p.damping, 0.0F, 1.0F);
        const float damping = 0.0005F + dampK * 0.70F;
        const float toneA = onePoleCoef(2000.0 + 16000.0 * static_cast<double>(std::clamp(p.tone, 0.0F, 1.0F)), kBaseRate * scale);
        const double sr = kBaseRate * scale;
        const auto preLen = std::clamp<std::size_t>(static_cast<std::size_t>(std::lround(std::clamp(static_cast<double>(p.preDelayMs), 0.0, 200.0) * 0.001 * sr)) + 1U, 1U, 24576U - 3U);

        float x = delay(pre, preLen, (inL + inR) * 0.5F);
        bandwidthState += (x - bandwidthState) * 0.9995F;
        x = allpass(in1, l1, bandwidthState, 0.75F);
        x = allpass(in2, l2, x, 0.75F);
        x = allpass(in3, l3, x, 0.625F);
        x = allpass(in4, l4, x, 0.625F);

        lfoPhase += lfoStep;
        if (lfoPhase > 2.0 * kPi) lfoPhase -= 2.0 * kPi;
        const double modA = excursion * (0.5 + 0.5 * std::sin(lfoPhase));
        const double modB = excursion * (0.5 + 0.5 * std::cos(lfoPhase));

        // left half of the tank (fed by the right half)
        float a = x + decay * feedR;
        a = allpassMod(modL, lModL + modA, a, -0.70F);
        a = delay(delL1, lDelL1, a);
        dampL = a * (1.0F - damping) + dampL * damping;
        a = allpass(apL, lApL, dampL * decay, 0.50F);
        const float outLeftHalf = delay(delL2, lDelL2, a);

        // right half of the tank (fed by the left half)
        float b = x + decay * feedL;
        b = allpassMod(modR, lModR + modB, b, -0.70F);
        b = delay(delR1, lDelR1, b);
        dampR = b * (1.0F - damping) + dampR * damping;
        b = allpass(apR, lApR, dampR * decay, 0.50F);
        const float outRightHalf = delay(delR2, lDelR2, b);

        feedL = outLeftHalf;
        feedR = outRightHalf;

        wetL = 1.2F * (delR1.at(tapsAt[0]) + delR1.at(tapsAt[1]) - apR.at(tapsAt[2]) + delR2.at(tapsAt[3])
                       - delL1.at(tapsAt[4]) - apL.at(tapsAt[5]) - delL2.at(tapsAt[6]));
        wetR = 1.2F * (delL1.at(tapsAt[7]) + delL1.at(tapsAt[8]) - apL.at(tapsAt[9]) + delL2.at(tapsAt[10])
                       - delR1.at(tapsAt[11]) - apR.at(tapsAt[12]) - delR2.at(tapsAt[13]));
        wetL = toneOutL.process(wetL, toneA);
        wetR = toneOutR.process(wetR, toneA);
    }
};

// SILVETON_FX_V3: one effect slot engine. Holds every effect type; the memory
// is allocated once (prepare), never in the audio thread. A type change clears
// only the engine that starts.
struct FxUnit {
    double sampleRate{48000.0};
    EffectType built{EffectType::Off};
    DelayEngine delay{};
    ModEngine mod{};
    FdnReverb fdn{};
    SpringReverb spring{};
    DynamicsFx dyn{};
    NumberedFxProcessor numbered{};
    NumberedFxControlFrame numberedControl{};
    bool numberedMode{false};
    bool sourceNumberedMode{false};
    SourceFxRenderParameters sourceRunning{};
    Biquad sourceLow{}, sourceHigh{};
    std::unique_ptr<ReverbFx> plate;   // 600 KB: on the heap

    void prepare(double sr, double maxDelaySec) {
        sampleRate = sr;
        delay.allocate(sr, maxDelaySec);
        mod.allocate(sr);
        fdn.allocate(sr);
        spring.allocate(sr);
        dyn.allocate(sr);
        numbered.prepare(sr);
        numberedControl = {};
        numberedMode = false;
        sourceNumberedMode = false;
        if (plate == nullptr) plate = std::make_unique<ReverbFx>();
        plate->reset(sr);
        built = EffectType::Off;
    }
    void reset() noexcept { built = EffectType::Off; sourceRunning = {}; sourceLow = {}; sourceHigh = {}; numbered.reset(); numberedControl = {}; numberedMode = sourceNumberedMode = false; }

    // Called after configureNumbered, once per block. Only the three explicit
    // control-driven algorithms consume this snapshot; unrelated FX are not
    // changed. The frame is stored so an outgoing A/B lane can keep its owner.
    void setNumberedControl(const EffectSlot& p, const NumberedFxControlFrame& frame,
                            bool frozen = false) noexcept {
        if (p.numbered.index != 34 && p.numbered.index != 37 && p.numbered.index != 42) return;
        numberedControl = frame;
        numberedControl.frozen = numberedControl.frozen || frozen;
        numbered.setControlFrame(numberedControl);
    }
    void freezeNumberedControl() noexcept { numberedControl.frozen = true; }
    void applyFrozenNumberedControl(const EffectSlot& p) noexcept {
        if (p.numbered.index != 34 && p.numbered.index != 37 && p.numbered.index != 42) return;
        numberedControl.frozen = true;
        numbered.setControlFrame(numberedControl);
    }

    // Semantic lookup/coefficient changes happen once per block, not per
    // sample. Verified source semantics stay separate from manual slot state;
    // no original Korg parameter block is interpreted by this audio path.
    bool configureNumbered(const EffectSlot& p,
                           const SourceFxRenderParameters* source = nullptr) noexcept {
        const bool sourceMode = source && source->active && source->numbered.index != 0;
        const auto& state = sourceMode ? source->numbered : p.numbered;
        const bool mode = state.index != 0;
        if (mode != numberedMode || sourceMode != sourceNumberedMode) {
            built = EffectType::Off;
            sourceRunning = {}; sourceLow = {}; sourceHigh = {};
        }
        // A source/manual ownership change is distinct even when its effect
        // identity matches. Do not reuse the other provenance's delay history.
        if (sourceMode != sourceNumberedMode) numbered.reset();
        numberedMode = mode;
        sourceNumberedMode = sourceMode;
        numbered.configure(state);
        return mode ? numbered.active() : p.type != EffectType::Off;
    }

    void clearFor(EffectType t) noexcept {
        if (effectIsDelay(t)) delay.reset();
        else if (t == EffectType::Chorus || t == EffectType::Flanger || t == EffectType::Phaser || t == EffectType::Rotary || t == EffectType::Ensemble) mod.reset();
        else if (t == EffectType::Reverb) { if (plate != nullptr) plate->reset(sampleRate); }
        else if (t == EffectType::Spring) spring.reset();
        else if (effectIsReverb(t)) fdn.reset();
        else dyn.reset();
        built = t;
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR,
                 const SourceFxRenderParameters* source = nullptr) noexcept {
        if (numberedMode) {
            if (numbered.active()) numbered.process(inL, inR, wetL, wetR);
            else wetL = wetR = 0.0F;
            return;
        }
        if (p.type == EffectType::Off) { wetL = wetR = 0.0F; return; }
        if (p.type != built) clearFor(p.type);
        static const SourceFxRenderParameters noSource{};
        const auto& sourceNow = source ? *source : noSource;
        if (!sameSourceFxRender(sourceRunning, sourceNow)) {
            sourceLow = {}; sourceHigh = {};
            if (sourceNow.active) {
                if (sourceNow.eqLowGainDb != 0.0F && sourceNow.eqLowHz > 0.0F)
                    sourceLow.setShelf(sampleRate, sourceNow.eqLowHz, sourceNow.eqLowGainDb, false);
                if (sourceNow.eqHighGainDb != 0.0F && sourceNow.eqHighHz > 0.0F)
                    sourceHigh.setShelf(sampleRate, sourceNow.eqHighHz, sourceNow.eqHighGainDb, true);
            }
            sourceRunning = sourceNow;
        }
        if (sourceNow.active) {
            inL *= sourceNow.inputTrim; inR *= sourceNow.inputTrim;
            if (sourceNow.eqLowGainDb != 0.0F) sourceLow.process(inL, inR);
            if (sourceNow.eqHighGainDb != 0.0F) sourceHigh.process(inL, inR);
        }
        switch (p.type) {
            case EffectType::Off: wetL = wetR = 0.0F; break;
            case EffectType::Delay: case EffectType::TapeDelay: case EffectType::PingPong:
            case EffectType::MultiTap: case EffectType::DuckDelay:
                delay.process(inL, inR, p, wetL, wetR); break;
            case EffectType::Chorus: case EffectType::Flanger: case EffectType::Phaser: case EffectType::Rotary: case EffectType::Ensemble:
                mod.process(inL, inR, p, wetL, wetR); break;
            case EffectType::Reverb:
                if (plate != nullptr) plate->process(inL, inR, p, wetL, wetR, source); else wetL = wetR = 0.0F;
                break;
            case EffectType::Hall: case EffectType::Room: case EffectType::Chamber:
                fdn.process(inL, inR, p, wetL, wetR, source); break;
            case EffectType::Spring:
                spring.process(inL, inR, p, wetL, wetR); break;
            case EffectType::Compressor: case EffectType::Drive:
                dyn.process(inL, inR, p, wetL, wetR); break;
        }
        if (sourceNow.active && effectIsReverb(p.type)) {
            // The source's Pre Delay Thru goes around both pre-delay and
            // reverb, after its input trim/EQ, as in the source signal diagram.
            const float through = (inL + inR) * 0.5F * sourceNow.preDelayThru;
            wetL += through; wetR += through;
        }
        if (!std::isfinite(wetL) || !std::isfinite(wetR)) { wetL = wetR = 0.0F; clearFor(p.type); }
    }
};

// Silent one-zone routing carrier; SOLO computes audio independently of sample data.
ProgramPtr makeSoloCarrier() {
    auto ms = std::make_shared<Multisample>();
    ms->name = "SILVETON SOLO";
    constexpr int root = 60;
    const double f = 440.0 * std::pow(2.0, (root - 69) / 12.0);
    const auto P = static_cast<std::size_t>(std::max(16L, std::lround(96000.0 / f)));
    auto smp = std::make_shared<SampleData>();
    smp->name = "SILVETON SOLO";
    smp->sampleRate = static_cast<std::uint32_t>(std::lround(static_cast<double>(P) * f));
    smp->channels = 1U;
    smp->rootKey = static_cast<std::uint8_t>(root);
    smp->interleaved.assign(P * 4U, 0.0F);
    smp->totalFrames = P * 4U;
    smp->loop.enabled = true; smp->loop.startFrame = 0U; smp->loop.endFrame = P * 4U; smp->loop.crossfadeFrames = 0U;
    SampleZone z{};
    z.sample = smp;
    z.rootKey = static_cast<std::uint8_t>(root);
    z.keyLow = 0U; z.keyHigh = 127U;
    z.velocityLow = 1U; z.velocityHigh = 127U;
    ms->zones.push_back(z);
    auto prog = std::make_shared<Program>();
    prog->name = "SILVETON SOLO";
    ProgramLayer layer{};
    layer.name = prog->name;
    layer.multisample = ms;
    layer.ampEnvelope = EnvelopeParams{};
    prog->layers.push_back(layer);
    return prog;
}
const Program* soloCarrier() noexcept {
    static const ProgramPtr carrier = makeSoloCarrier();
    return carrier.get();
}

bool proceduralMono(const UpperPart& u) noexcept { return u.engine.type==EngineType::Solo; }
bool engineCarries(const UpperPart& u) noexcept { return u.engine.on(); }
const Program* playProgramOf(const UpperPart& u,int soundIndex) noexcept {
    const auto& source = soundSource(u, soundIndex);
    if (source.engine.chosen()) return source.engine.on() && (soundIndex == 0 || u.layers[static_cast<std::size_t>(soundIndex - 1)].enabled) ? soloCarrier() : nullptr;
    return soundProgramOf(u,soundIndex);
}

bool upperPlays(const UpperPart& u, std::uint8_t key, std::uint8_t velocity,bool bypassSwitch) noexcept {
    if (u.matches(key,velocity,bypassSwitch)) return true;
    return (bypassSwitch||(u.enabled&&!u.mute)) && engineCarries(u) &&
           key >= u.performanceKeyLow && key <= u.performanceKeyHigh &&
           (u.independentLayerRanges || (key >= u.keyLow && key <= u.keyHigh && velocity >= u.velocityLow && velocity <= u.velocityHigh));
}

} // namespace

// SILVETON_MIDI_MPSC_V1 (see SamplerEngine.h). A slot is free for position p when seq == p, holds an event for the reader
// when seq == p + 1, and is free again for p + capacity after the reader set seq = p + capacity.
RealtimeEventQueue::RealtimeEventQueue() noexcept {
    for (std::size_t i = 0U; i < kCapacity; ++i) slots_[i].seq.store(i, std::memory_order_relaxed);
}

bool RealtimeEventQueue::critical(const RealtimeEvent& e) noexcept {
    switch (e.type) {
        case EventType::NoteOff:
        case EventType::Panic: return true;
        case EventType::ControlChange: return e.data1 == 64U || e.data1 == 120U || e.data1 == 121U || e.data1 == 123U;
        default: return false;
    }
}

bool RealtimeEventQueue::pushRing(const RealtimeEvent& e, bool mayUseReserve) noexcept {
    std::size_t pos = enqueue_.load(std::memory_order_relaxed);
    for (;;) {
        if (!mayUseReserve) {
            const std::size_t used = pos - dequeue_.load(std::memory_order_acquire);
            if (used >= kCapacity - kReserve) return false;   // only the reserve is left
        }
        Slot& slot = slots_[pos & (kCapacity - 1U)];
        const std::size_t seq = slot.seq.load(std::memory_order_acquire);
        const auto diff = static_cast<std::ptrdiff_t>(seq) - static_cast<std::ptrdiff_t>(pos);
        if (diff == 0) {
            if (enqueue_.compare_exchange_weak(pos, pos + 1U, std::memory_order_relaxed, std::memory_order_relaxed)) {
                slot.event = e;
                slot.seq.store(pos + 1U, std::memory_order_release);
                return true;
            }
        } else if (diff < 0) {
            return false;   // full
        } else {
            pos = enqueue_.load(std::memory_order_relaxed);
        }
    }
}

void RealtimeEventQueue::notePending(const RealtimeEvent& e) noexcept {
    const std::uint32_t ch = e.channel & 0x0FU;
    if (e.type == EventType::Panic) panicPending_.store(true, std::memory_order_release);
    else if (e.type == EventType::NoteOff) {
        const std::size_t bit = static_cast<std::size_t>(ch) * 128U + (e.data1 & 0x7FU);
        offBits_[bit >> 6U].fetch_or(1ULL << (bit & 63U), std::memory_order_acq_rel);
    } else if (e.data1 == 64U) sustainOffBits_.fetch_or(1U << ch, std::memory_order_acq_rel);
    else if (e.data1 == 121U) controllerResetBits_.fetch_or(1U << ch, std::memory_order_acq_rel);
    else allOffBits_.fetch_or(1U << ch, std::memory_order_acq_rel);
    deferred_.fetch_add(1U, std::memory_order_relaxed);
    pendingHint_.store(true, std::memory_order_release);
}

bool RealtimeEventQueue::resolvePending(const RealtimeEvent& e) noexcept {
    const std::uint32_t ch = e.channel & 0x0FU;
    // A deferred reset is not All Notes Off: it frees pedal-held notes
    // but preserves keys still physically held. Replay it before a later
    // attack or expressive controller on this channel. If the reserve is
    // still full, reject the later non-release event, never discard reset.
    const bool laterState = e.type == EventType::NoteOn || e.type == EventType::PitchBend ||
        e.type == EventType::ChannelPressure || e.type == EventType::PolyPressure ||
        (e.type == EventType::ControlChange && e.data1 < 120U && !(e.data1 == 64U && e.data2 < 64U));
    if (laterState) {
        const std::uint32_t mask = 1U << ch;
        if ((controllerResetBits_.fetch_and(~mask, std::memory_order_acq_rel) & mask) != 0U) {
            RealtimeEvent reset{}; reset.type = EventType::ControlChange; reset.channel = static_cast<std::uint8_t>(ch); reset.data1 = 121U;
            if (!pushRing(reset, true)) {
                controllerResetBits_.fetch_or(mask, std::memory_order_acq_rel);
                pendingHint_.store(true, std::memory_order_release);
                return false;
            }
        }
    }
    if (e.type == EventType::NoteOn) {
        const std::size_t bit = static_cast<std::size_t>(ch) * 128U + (e.data1 & 0x7FU);
        const std::uint64_t mask = 1ULL << (bit & 63U);
        if ((offBits_[bit >> 6U].fetch_and(~mask, std::memory_order_acq_rel) & mask) == 0U) return true;
        RealtimeEvent off{}; off.type = EventType::NoteOff; off.channel = static_cast<std::uint8_t>(ch); off.data1 = e.data1;
        if (pushRing(off, true)) return true;
        offBits_[bit >> 6U].fetch_or(mask, std::memory_order_acq_rel);   // still no room: the OFF stays noted, the ON is refused
        pendingHint_.store(true, std::memory_order_release);
        return false;
    }
    if (e.type == EventType::ControlChange && e.data1 == 64U && e.data2 >= 64U) {
        const std::uint32_t mask = 1U << ch;
        if ((sustainOffBits_.fetch_and(~mask, std::memory_order_acq_rel) & mask) == 0U) return true;
        RealtimeEvent off{}; off.type = EventType::ControlChange; off.channel = static_cast<std::uint8_t>(ch); off.data1 = 64U; off.data2 = 0U;
        if (pushRing(off, true)) return true;
        sustainOffBits_.fetch_or(mask, std::memory_order_acq_rel);
        pendingHint_.store(true, std::memory_order_release);
        return false;
    }
    return true;
}

bool RealtimeEventQueue::push(const RealtimeEvent& event) noexcept {
    if (!resolvePending(event)) { dropped_.fetch_add(1U, std::memory_order_relaxed); return false; }
    const bool crit = critical(event);
    if (pushRing(event, crit)) return true;
    if (crit) { notePending(event); return true; }   // not lost: the audio thread makes it from the bit
    dropped_.fetch_add(1U, std::memory_order_relaxed);
    return false;
}

bool RealtimeEventQueue::popPending(RealtimeEvent& event) noexcept {
    if (!pendingHint_.load(std::memory_order_acquire)) return false;
    if (panicPending_.exchange(false, std::memory_order_acq_rel)) { event = RealtimeEvent{}; event.type = EventType::Panic; return true; }
    if (const std::uint32_t all = allOffBits_.load(std::memory_order_acquire); all != 0U) {
        const std::uint32_t ch = static_cast<std::uint32_t>(__builtin_ctz(all));
        if ((allOffBits_.fetch_and(~(1U << ch), std::memory_order_acq_rel) & (1U << ch)) != 0U) {
            event = RealtimeEvent{}; event.type = EventType::ControlChange; event.channel = static_cast<std::uint8_t>(ch); event.data1 = 123U; return true;
        }
    }
    for (std::size_t w = 0U; w < offBits_.size(); ++w) {
        const std::uint64_t bits = offBits_[w].load(std::memory_order_acquire);
        if (bits == 0U) continue;
        const auto b = static_cast<std::size_t>(__builtin_ctzll(bits));
        if ((offBits_[w].fetch_and(~(1ULL << b), std::memory_order_acq_rel) & (1ULL << b)) == 0U) continue;   // a producer took it back
        const std::size_t bit = w * 64U + b;
        event = RealtimeEvent{}; event.type = EventType::NoteOff; event.channel = static_cast<std::uint8_t>(bit / 128U); event.data1 = static_cast<std::uint8_t>(bit % 128U);
        return true;
    }
    if (const std::uint32_t sus = sustainOffBits_.load(std::memory_order_acquire); sus != 0U) {
        const std::uint32_t ch = static_cast<std::uint32_t>(__builtin_ctz(sus));
        if ((sustainOffBits_.fetch_and(~(1U << ch), std::memory_order_acq_rel) & (1U << ch)) != 0U) {
            event = RealtimeEvent{}; event.type = EventType::ControlChange; event.channel = static_cast<std::uint8_t>(ch); event.data1 = 64U; event.data2 = 0U; return true;
        }
    }
    if (const std::uint32_t reset = controllerResetBits_.load(std::memory_order_acquire); reset != 0U) {
        const std::uint32_t ch = static_cast<std::uint32_t>(__builtin_ctz(reset));
        if ((controllerResetBits_.fetch_and(~(1U << ch), std::memory_order_acq_rel) & (1U << ch)) != 0U) {
            event = RealtimeEvent{}; event.type = EventType::ControlChange; event.channel = static_cast<std::uint8_t>(ch); event.data1 = 121U; return true;
        }
    }
    pendingHint_.store(false, std::memory_order_release);
    // a producer may have noted a bit between the scan and the store above: look once more next time
    for (const auto& w : offBits_) if (w.load(std::memory_order_acquire) != 0U) { pendingHint_.store(true, std::memory_order_release); break; }
    if (controllerResetBits_.load(std::memory_order_acquire) != 0U || sustainOffBits_.load(std::memory_order_acquire) != 0U || allOffBits_.load(std::memory_order_acquire) != 0U || panicPending_.load(std::memory_order_acquire))
        pendingHint_.store(true, std::memory_order_release);
    return false;
}

bool RealtimeEventQueue::pop(RealtimeEvent& event) noexcept {
    const std::size_t pos = dequeue_.load(std::memory_order_relaxed);
    Slot& slot = slots_[pos & (kCapacity - 1U)];
    const std::size_t seq = slot.seq.load(std::memory_order_acquire);
    if (static_cast<std::ptrdiff_t>(seq) - static_cast<std::ptrdiff_t>(pos + 1U) == 0) {
        event = slot.event;
        slot.seq.store(pos + kCapacity, std::memory_order_release);
        dequeue_.store(pos + 1U, std::memory_order_release);
        return true;
    }
    // the queue is empty (or its next slot is still being written): the noted OFFs come after everything queued before them
    return popPending(event);
}

void RealtimeEventQueue::clear() noexcept {
    RealtimeEvent e{};
    for (std::size_t n = 0U; n < kCapacity; ++n) {
        const std::size_t pos = dequeue_.load(std::memory_order_relaxed);
        Slot& slot = slots_[pos & (kCapacity - 1U)];
        if (static_cast<std::ptrdiff_t>(slot.seq.load(std::memory_order_acquire)) - static_cast<std::ptrdiff_t>(pos + 1U) != 0) break;
        e = slot.event;
        if(e.type==EventType::ActivatePreparedState&&e.preparedState)
            e.preparedState->queuedPosts_.fetch_sub(1U,std::memory_order_acq_rel);
        slot.seq.store(pos + kCapacity, std::memory_order_release);
        dequeue_.store(pos + 1U, std::memory_order_release);
    }
}

// SILVETON_MULTICORE_V1 ---------------------------------------------------------------
// The voices of one chunk are shared out over several cores. A unit of work is one sound
// bus (one Upper, one of its sounds): every voice writes only into the bus of its own
// sound, so two cores never touch the same buffer and the voices of a bus are still added
// in the very same order. The sound that comes out is the same to the last bit.
//
// Whoever is free takes the next bus (one atomic counter), and the audio thread
// works as well. Claimed buses must finish before mixing, so only helpers whose
// realtime scheduling and CPU affinity were verified may participate. Until then
// the audio thread runs the identical buses itself, with unchanged DSP quality.
struct SilvetonRenderPool {
    using Fn = void (*)(void*, int) noexcept;

    int threadsWanted{1}; // configured only while all sharing engines are stopped
    std::vector<std::thread> workers;
    std::mutex wake;
    std::condition_variable bell;
    std::atomic<unsigned> job{0U};         // even = closed, odd = published chunk
    std::atomic<int> next{0};              // the next bus nobody has taken
    std::atomic<int> left{0};              // buses not finished yet
    std::atomic<int> busy{0};              // cores inside the work right now
    std::atomic<unsigned> workedMask{0U};  // which helpers actually took a bus (bit per helper)
    // A helper may take deadline-bound work only after it has checked its actual
    // scheduler and affinity. Root promotion happens after these threads start.
    std::atomic<unsigned> realtimeReady{0U};
    unsigned requiredReady{0U};
    std::atomic<int> parked{0};
    std::atomic<bool> quit{false};
    std::atomic<Fn> fn{nullptr};
    std::atomic<void*> ctx{nullptr};
    std::atomic<int> units{0};

    static void pause() noexcept {
#if defined(__i386__) || defined(__x86_64__)
        __builtin_ia32_pause();
#elif defined(__aarch64__) || defined(__arm__)
        __asm__ __volatile__("yield" ::: "memory");
#else
        std::this_thread::yield();
#endif
    }

    // Takes buses until there are none left. A core that comes late finds the counter
    // already past the end and simply does nothing - it never works on a finished chunk.
    void drain(int me = -1) noexcept {
        for (;;) {
            const int unit = next.fetch_add(1, std::memory_order_acq_rel);
            if (unit >= units.load(std::memory_order_acquire)) break;
            const Fn body = fn.load(std::memory_order_acquire);
            void* const context = ctx.load(std::memory_order_acquire);
            if (body == nullptr) break;
            body(context, unit);
            if (me >= 0) workedMask.fetch_or(1U << static_cast<unsigned>(me), std::memory_order_release);
            left.fetch_sub(1, std::memory_order_release);
        }
    }

    void run(const int index) noexcept {
        placeThread(index);
        auto nextPolicyCheck = std::chrono::steady_clock::time_point{};
        const unsigned readyBit = 1U << static_cast<unsigned>(index);
        unsigned seen = job.load(std::memory_order_seq_cst);
        while (!quit.load(std::memory_order_relaxed)) {
            // Never run scheduler syscalls on the audio callback. This idle-side
            // check also notices a later successful root promotion or its loss.
            const auto policyNow = std::chrono::steady_clock::now();
            if (policyNow >= nextPolicyCheck) {
                if (verifyThread(index)) realtimeReady.fetch_or(readyBit, std::memory_order_release);
                else realtimeReady.fetch_and(~readyBit, std::memory_order_release);
                nextPolicyCheck = policyNow + std::chrono::milliseconds(100);
            }
            // Stay hot for a short while (a block comes every millisecond while music is
            // playing), then sleep, so a quiet sampler does not keep cores spinning.
            const auto until = std::chrono::steady_clock::now() + std::chrono::microseconds(250);
            while (job.load(std::memory_order_seq_cst) == seen && !quit.load(std::memory_order_relaxed)) {
                if (std::chrono::steady_clock::now() >= until) {
                    std::unique_lock<std::mutex> lock(wake);
                    parked.fetch_add(1, std::memory_order_release);
                    bell.wait_for(lock, std::chrono::milliseconds(50), [&] {
                        return job.load(std::memory_order_seq_cst) != seen || quit.load(std::memory_order_relaxed);
                    });
                    parked.fetch_sub(1, std::memory_order_release);
                    break;
                }
                pause();
            }
            if (quit.load(std::memory_order_relaxed)) break;
            const unsigned now = job.load(std::memory_order_seq_cst);
            if (now == seen) continue;
            if ((now & 1U) == 0U) { seen = now; continue; }
            // Say "I am in" before looking at the work, and check that the chunk is still
            // the same open generation. Seq-cst pairs this entry with close+busy
            // below: a late helper either belongs to that fence or fails validation.
            if ((realtimeReady.load(std::memory_order_acquire) & readyBit) == 0U) {
                seen = now;
                continue;
            }
            busy.fetch_add(1, std::memory_order_seq_cst);
            if (job.load(std::memory_order_seq_cst) != now) {
                busy.fetch_sub(1, std::memory_order_seq_cst);
                continue;
            }
            seen = now;
            drain(index);
            busy.fetch_sub(1, std::memory_order_seq_cst);
        }
        realtimeReady.fetch_and(~readyBit, std::memory_order_release);
    }

    bool ready() const noexcept {
        return requiredReady != 0U &&
            (realtimeReady.load(std::memory_order_acquire) & requiredReady) != 0U;
    }

    static bool verifyThread(int index) noexcept {
#if defined(__linux__)
        // Check the kernel: Android may have promoted this TID from another process.
        const int policy=sched_getscheduler(0);
        sched_param param{};
        if ((policy != SCHED_FIFO && policy != SCHED_RR) ||
            sched_getparam(0,&param) != 0 || param.sched_priority < 79) return false;
        const int cpu = deviceCpuWorkPolicy().renderCpu(index);
        if (cpu < 0 || cpu >= CPU_SETSIZE) return false;
        cpu_set_t set;
        CPU_ZERO(&set);
        if (sched_getaffinity(0, sizeof(set), &set) != 0 || !CPU_ISSET(cpu, &set)) return false;
        for (int other = 0; other < CPU_SETSIZE; ++other)
            if (other != cpu && CPU_ISSET(other, &set)) return false;
        return true;
#elif defined(__APPLE__)
        (void)index;
        qos_class_t qos = QOS_CLASS_UNSPECIFIED;
        // The return value is an error code; the QoS class is an output argument.
        return pthread_get_qos_class_np(pthread_self(), &qos, nullptr) == 0 &&
               qos == QOS_CLASS_USER_INTERACTIVE;
#else
        (void)index;
        return false;
#endif
    }

    // One worker per core, away from the core the audio thread sits on (the top core), and
    // with the same kind of priority as the audio thread - one step below it. Otherwise the
    // helpers are ordinary threads: the system pushes them aside and the help is worth little.
    static void placeThread(int index) noexcept {
#if defined(__linux__)
        const auto& placement = deviceCpuWorkPolicy();
        if (placement.cores >= 3U) {
            const int cpu = placement.renderCpu(index);
            if (cpu >= 0 && cpu < CPU_SETSIZE) {
                // sched_setaffinity(0, ...) means "this thread" and exists on every Linux and
                // on Android from the start; pthread_setaffinity_np only arrived in Android 16.
                cpu_set_t set;
                CPU_ZERO(&set);
                CPU_SET(static_cast<std::size_t>(cpu), &set);
                (void)sched_setaffinity(0, sizeof(set), &set);
            }
        }
        char name[16];
        std::snprintf(name, sizeof(name), "SilvRender%d", index);
        (void)pthread_setname_np(pthread_self(), name);

        // SILVETON_MULTICORE_V1: audio priority, one step under the audio thread (which runs
        // at 80). Without root this is refused, so fall back to the strongest ordinary boost.
        sched_param param{};
        param.sched_priority = 79;
        if (sched_setscheduler(0, SCHED_FIFO, &param) != 0) (void)setpriority(PRIO_PROCESS, 0, -16);
#if defined(__aarch64__)
        // Match Android's audio thread even when these workers were started
        // earlier by the lifecycle thread, before audio configured its FPCR.
        std::uint64_t fpcr = 0U;
        __asm__ __volatile__("mrs %0, fpcr" : "=r"(fpcr));
        fpcr |= (std::uint64_t{1} << 24);
        __asm__ __volatile__("msr fpcr, %0" : : "r"(fpcr));
#endif
#elif defined(__APPLE__)
        // macOS has no core pinning; the name helps the profiler, and the QoS class asks the system
        // for the same treatment as an interactive audio job (the core's own audio thread is set by the host).
        char name[16];
        std::snprintf(name, sizeof(name), "SilvRender%d", index);
        (void)pthread_setname_np(name);
        (void)pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
#if defined(__SSE__)
        // Tiny numbers in reverb/delay tails cost extra time and are inaudible: flush them to zero
        // (the tablet does the same on its audio thread).
        _mm_setcsr(_mm_getcsr() | 0x8040U);
#endif
#else
        (void)index;
#endif
    }

    void start(int workerCount) {
        stop();
        quit.store(false, std::memory_order_relaxed);
        realtimeReady.store(0U, std::memory_order_relaxed);
        requiredReady = workerCount > 0 ? (1U << static_cast<unsigned>(workerCount)) - 1U : 0U;
        workers.reserve(static_cast<std::size_t>(std::max(0, workerCount)));
        for (int i = 0; i < workerCount; ++i) workers.emplace_back([this, i]() noexcept { run(i); });
    }

    void stop() noexcept {
        if (workers.empty()) return;
        quit.store(true, std::memory_order_release);
        { std::lock_guard<std::mutex> lock(wake); }
        bell.notify_all();
        for (auto& t : workers) if (t.joinable()) t.join();
        workers.clear();
        realtimeReady.store(0U, std::memory_order_relaxed);
        requiredReady = 0U;
        quit.store(false, std::memory_order_relaxed);
    }

    // Hand the buses out and work along with them; returns once every bus is done.
    void share(int unitCount, Fn body, void* context) noexcept {
        // The previous generation is closed and fenced before these fields can
        // change. Helpers ignore closed generations, including when another
        // engine immediately reuses this pool on the same audio callback.
        fn.store(body, std::memory_order_release);
        ctx.store(context, std::memory_order_release);
        units.store(unitCount, std::memory_order_release);
        left.store(unitCount, std::memory_order_release);
        next.store(0, std::memory_order_release);
        job.fetch_add(1U, std::memory_order_seq_cst); // publish the odd/open generation
        if (parked.load(std::memory_order_acquire) > 0) bell.notify_all();
        busy.fetch_add(1, std::memory_order_seq_cst);
        drain();
        busy.fetch_sub(1, std::memory_order_seq_cst);
        while (left.load(std::memory_order_acquire) > 0) pause();
        job.fetch_add(1U, std::memory_order_seq_cst); // close before fencing late entrants
        while (busy.load(std::memory_order_seq_cst) > 0) pause();
    }

    ~SilvetonRenderPool() { stop(); }
};

// Control-owned immutable publication nodes. One hazard slot is enough because
// render() has one consumer. All pointer publication/protection/scans use seq_cst:
// a node removed before its hazard is visible must fail the second latest load.
// No dereference occurs before that validation, and adoption never retries.
// Each node pins its graph until no audio/voice/external shared owner remains;
// therefore dropping an audio reference can never run a graph destructor.
template<class T>
struct GraphPublication {
    struct Node {
        explicit Node(std::shared_ptr<const T> p) : value(std::move(p)) {}
        const std::shared_ptr<const T> value;
        std::atomic<std::uint64_t> revision{1U};
    };
    std::uint64_t appliedRevision{0U}; // audio consumer only
    std::vector<std::unique_ptr<Node>> nodes; // accessed only under Publications::mutex
    std::atomic<Node*> latest{nullptr};
    std::atomic<Node*> applied{nullptr};
    std::atomic<Node*> hazard{nullptr};

    // Retain an additional graph without making it the normal current state.
    // Prepared program routes need this owner pin too: the last voice can then
    // release its graph on audio without running its destructor there.
    Node* retain(std::shared_ptr<const T> value) {
        for (const auto& n : nodes)
            if (n->value.get() == value.get() && !n->value.owner_before(value) && !value.owner_before(n->value)) return n.get();
        nodes.push_back(std::make_unique<Node>(std::move(value)));
        return nodes.back().get();
    }
    void publish(std::shared_ptr<const T> value) {
        // Reusing the same shared graph must not create two permanent owner pins
        // (neither could ever reach use_count==1). A revision keeps republishing
        // observable even when the same immutable object is selected again.
        for (const auto& n : nodes) {
            if (n->value.get() == value.get() && !n->value.owner_before(value) && !value.owner_before(n->value)) {
                n->revision.fetch_add(1U, std::memory_order_release);
                latest.store(n.get(), std::memory_order_seq_cst);
                return;
            }
        }
        auto n = std::make_unique<Node>(std::move(value));
        Node* const raw = n.get();
        nodes.push_back(std::move(n));
        latest.store(raw, std::memory_order_seq_cst);
    }
    template<class Predicate>
    bool adoptIf(std::shared_ptr<const T>& target,Predicate allowed) noexcept {
        Node* const n = latest.load(std::memory_order_seq_cst);
        if (n == nullptr) return false;
        hazard.store(n, std::memory_order_seq_cst);
        if (latest.load(std::memory_order_seq_cst) != n) {
            hazard.store(nullptr, std::memory_order_seq_cst);
            return false; // a later block adopts the newest complete graph
        }
        const auto revision = n->revision.load(std::memory_order_acquire);
        if (n == applied.load(std::memory_order_seq_cst) && revision == appliedRevision) {
            hazard.store(nullptr, std::memory_order_seq_cst);
            return false;
        }
        if(!allowed(n->value)){
            hazard.store(nullptr,std::memory_order_seq_cst);
            return false;
        }
        target = n->value;
        appliedRevision = revision;
        applied.store(n, std::memory_order_seq_cst);
        hazard.store(nullptr, std::memory_order_seq_cst);
        return true;
    }
    bool adopt(std::shared_ptr<const T>& target) noexcept {
        return adoptIf(target,[](const auto&){return true;});
    }
    // A registered queued token already protects this node from reclamation.
    void adoptRegistered(Node* n,std::shared_ptr<const T>& target) noexcept {
        hazard.store(n,std::memory_order_seq_cst);
        target=n->value;
        appliedRevision=n->revision.load(std::memory_order_acquire);
        applied.store(n,std::memory_order_seq_cst);
        hazard.store(nullptr,std::memory_order_seq_cst);
    }
    // Control thread, under the mutex. Check the hazard BEFORE use_count:
    // a cleared hazard then guarantees its protected owner copy is visible.
    template<class Predicate>
    void collectExcept(Predicate keep) {
        nodes.erase(std::remove_if(nodes.begin(), nodes.end(), [&](const auto& n) {
            if (n.get() == latest.load(std::memory_order_seq_cst) ||
                n.get() == applied.load(std::memory_order_seq_cst) ||
                n.get() == hazard.load(std::memory_order_seq_cst)) return false;
            if(keep(n->value))return false;
            // Aliasing shared_ptrs can point at different graphs in one owner.
            // Count our pins, so such a group also retires once no external or
            // audio reference remains. A protected/published alias retains its
            // own pin even while another node of the group is removed.
            long pins = 0;
            for (const auto& other : nodes)
                if (other && !other->value.owner_before(n->value) && !n->value.owner_before(other->value)) ++pins;
            // A producer can enqueue its registered raw token and then drop
            // its external shared owner between the first keep check and this
            // count. Recheck the queued guard after establishing eligibility.
            return n->value.use_count() == pins && !keep(n->value);
        }), nodes.end());
    }
    void collect(){collectExcept([](const auto&){return false;});}
    std::shared_ptr<const T> current() const {
        const auto* const n = applied.load(std::memory_order_seq_cst);
        return n != nullptr ? n->value : std::shared_ptr<const T>{};
    }
    std::shared_ptr<const T> newest() const {
        const auto* const n = latest.load(std::memory_order_seq_cst);
        return n != nullptr ? n->value : std::shared_ptr<const T>{};
    }
};

struct SamplerEngine::Publications {
    std::mutex mutex;
    std::condition_variable wake;
    bool stopping{false};
    GraphPublication<EngineState> states;
    GraphPublication<WaveTableMap> waves;
    GraphPublication<model::LearnedModels> models;
    GraphPublication<RealtimeProgramBank> programBanks;
    GraphPublication<PreparedSamplerState> preparedStates;
    std::thread reclaimer;

    Publications() : reclaimer([this] {
        std::unique_lock<std::mutex> lock(mutex);
        while (!stopping) {
            wake.wait_for(lock, std::chrono::milliseconds(25), [&] { return stopping; });
            collect();
        }
    }) {}
    ~Publications() {
        { std::lock_guard<std::mutex> lock(mutex); stopping = true; }
        wake.notify_one();
        if (reclaimer.joinable()) reclaimer.join();
    }
    void collect() {
        preparedStates.collectExcept([](const auto& prepared){
            return prepared&&prepared->queuedPosts_.load(std::memory_order_acquire)!=0U;
        });
        programBanks.collect(); states.collect(); waves.collect(); models.collect();
    }
};

struct SamplerEngine::Impl {
    std::shared_ptr<const PreparedSamplerState> preparedState;
    std::shared_ptr<const RealtimeProgramBank> programBank;
    std::array<std::shared_ptr<const EngineState>,16> selectedProgramStates;
    std::array<bool,16> programSelectionEnabled{};
    std::array<std::uint32_t,16> selectedProgramAddresses{};
    std::array<std::uint64_t,16> selectedProgramRevisions{};
    struct ChannelState {
        float expression{1.0F};
        float midiVolume{1.0F}, midiPan{0.0F};
        float breath{1.0F};
        int breathMidi{100};
        int expressionMidi{127};
        float pressure{0.0F};
        std::array<float, 128U> cc{};
        std::array<bool,128U> ccSeen{};
        std::array<float,128U> polyPressure{};
        SourceSoundEdits sourceSoundEdits{};
        SourceSoundEditReader sourceSoundEditReader{};
        std::uint16_t sourceEditTouched{0U};
        bool sustain{false};
        std::int16_t pitchBend{0};
    };

    // Physical routed notes, independent of audible/sample voices. A sample
    // reaching EOF or a stolen voice must not turn a still-held MIDI gate off.
    // Each part owns one input channel; repeated NoteOn retriggers Gate2 but a
    // matching NoteOff releases that key once, as in the existing note path.
    struct FxControlPart {
        std::array<std::uint64_t, 2> held{};
        std::uint8_t channel{0xFFU};
        bool damperGate{false};
        NumberedFxControlFrame frame{};
        bool any() const noexcept { return (held[0] | held[1]) != 0; }
        void press(std::uint8_t key) noexcept { held[(key & 127U) >> 6U] |= std::uint64_t{1} << (key & 63U); }
        void release(std::uint8_t key) noexcept { held[(key & 127U) >> 6U] &= ~(std::uint64_t{1} << (key & 63U)); }
        void releaseAll() noexcept { held = {}; damperGate = false; }
    };
    std::array<FxControlPart, kPartCount> fxControlParts{};
    std::uint64_t fxControlBindingSerial{0};
    std::uint32_t fxControlPerformanceGeneration{0};
    bool fxControlOwnerValid{false};

    float listenBusGain{1.0F};
    int listenPart{-1},listenKey{-1}; // audio thread, stable for one block
    bool listensTo(int part,int key) const noexcept {
        return listenPart==-1||(listenPart==part&&(listenKey<0||listenKey==key));
    }
    struct Voice {
        bool active{false};
        bool keyHeld{false};
        bool sustained{false};
        std::uint64_t age{0U},attackGroup{};
        std::uint8_t channel{0U};
        std::uint8_t key{0U};
        std::uint8_t velocity{0U};
        std::uint8_t sourceKey{60U},sourceVelocity{0U},releaseVelocity{64U};
        std::uint32_t sourcePerformanceGeneration{0U};
        ChannelState sourceControls{};
        SourceSoundEdits sourceEdits{};
        float sourceTempoBpm{120.0F};
        float sourceVelocityPosition{1.0F};
        float sourceToneExtraOctaves{0.0F};
        SourceOscillatorRuntime sourceOscillator{};
        int sourceLfoSlot{-1};
        unsigned sourceAmpControlCountdown{0U};
        std::uint8_t drumKey{0U}; // mapped kit key, before any later octave edit
        const Program* drumProgram{nullptr}; // kept alive by ownerState
        int upperIndex{0};
        int soundIndex{0};            // SILVETON_LAYERS_V1: 0 = basic sound, 1..4 = layer
        std::uint16_t routeMask{0U};
        SamplePtr sample;
        std::shared_ptr<const EngineState> ownerState;
        const ProgramLayer* layer{nullptr};
        const SampleZone* zone{nullptr};
        const UpperPart* upper{nullptr};
        double position{0.0};
        bool loopWrapped{false}; // SILVETON_STUDIO_INTERP_V1: passed the loop end at least once
        bool subLoopWrapped{false};
        LoopCrossfade loopCrossfade{};
        double ratio{1.0};
        double targetRatio{1.0};
        double lastReadRatio{1.0}; // actual pitch-modulated rate used by the last sample
        double bendNow{0.0};bool bendReady{false};
        double glideLogStep{0.0};
        double glideMul{1.0};
        std::uint32_t glideFramesRemaining{0U};
        // SILVETON_SOFT_GLIDE_V1: glide as an offset (semitones) from targetRatio.
        std::uint32_t glideTotalFrames{0U};
        double glideStartSemis{0.0};   // offset when the glide started
        double glideRawSemis{0.0};     // S-curve offset now (before BALANCE rounding)
        double glideSmooth1{0.0};      // BALANCE rounding, stage 1
        double glideSmooth2{0.0};      // actual continuous pitch offset (semitones)
        // SILVETON_SILK_PORTA_V1: remember the audible slope on interrupted glides.
        // Offsets/velocity are in semitones, not Hertz: even musical motion.
        double glideStartVelocity{0.0}; // initial semitone movement over whole glide
        double glideLastStep{0.0};      // last audible semitone change per sample
        bool pitchGliding{false};
        bool glideKronos{false};       // SILVETON_KRONOS_MUSICAL_PORTA_V2: controlled smooth pitch shape
        // SILVETON_TONE_V2
        std::uint32_t soloGesture{0};
        float velNorm{1.0F};
        float midiVolumeNow{1.0F};
        float filterEnvValue{0.0F};    // 1 at note on, decays to 0 in FILTER ENV time
        float velCutoffOct{0.0F};
        double endFrame{0.0};          // SAMPLE END (frames), 0 = none
        bool loopOff{false};           // END is before the loop end: no loop
        double vibPhase{0.0};
        double vibAgeSec{0.0};
        double vibSemis{0.0};          // vibrato of this block (semitones)
        // Click-free 4 ms fade used when a voice is taken over (voice limit,
        // MONO/LEGATO note change) instead of a one-sample cut.
        float fadeGain{1.0F};
        float fadeStep{0.0F};
        bool fading{false};
        bool fadeBlend{false};         // SILVETON_XFADE_PORTA_V1: crossfade law between two recordings of one line
        // SILVETON_POLYSIX_V1
        int unisonIndex{0};
        float unisonCents{0.0F};
        float unisonPan{0.0F};
        float unisonGain{1.0F};
        double subPosition{0.0};
        double periodFrames{0.0};      // one period of the recording's own pitch, in its frames (PWM)
        double pwmPhase{0.0};
        float pwmWidthNow{0.0F};
        float dcXL{0.0F}, dcYL{0.0F}, dcXR{0.0F}, dcYR{0.0F};
        // SILVETON_SYNTH_LIGHT_V1: PWM = the read sound minus itself one WIDTH x period later,
        // taken from this short delay line instead of a second interpolated read of the recording.
        static constexpr int kPwmDelay = 2048;      // frames (one period down to 47 Hz at 96 kHz)
        std::array<float, static_cast<std::size_t>(kPwmDelay) * 2U> pwmBuf{};
        int pwmWrite{0};
        int pwmFilled{0};
        // SILVETON_TRANSWAVE_V1
        WaveTablePtr waveTable;        // null = the sound plays its recording as usual
        std::shared_ptr<const WaveTableMap> ownerWaveMap; // keeps its publication pin until this voice ends
        double wavePhase{0.0};         // 0..1 inside one cycle
        double waveAge{0.0};           // seconds since the note began
        double waveLfoPhase{0.0};
        float wavePosNow{0.0F}, wavePosPrev{0.0F};
        bool waveInit{false};
        float random{0.0F};            // -1..1, fixed for the note
        float modCutOct{0.0F}, modRes{0.0F}, modCut2Oct{0.0F}, modLevelDb{0.0F}, modPan{0.0F};
        float modPitch{0.0F}, modLfoCents{0.0F}, modLfoRateMul{1.0F}, modPwm{0.0F}, modDrive{0.0F}, modAttackMul{1.0F}, modReleaseMul{1.0F};
        std::int8_t filterTypeNow{0};
        LadderFilter ladder{};
        Korg35Filter korg35{};
        StateVariableFilter filter2{};
        float filter2Hz{1000.0F}, filter2Res{0.0F};
        std::uint32_t delayFramesRemaining{0U};
        // Zone/layer gain x velocity. The Upper's level, pan and ON/MUTE/SOLO are
        // the live mix gains below (SILVETON_LIVE_EDIT_V1).
        float baseGain{1.0F};
        float mixL{0.70710678F};
        float mixR{0.70710678F};
        float lastOutputL{0.0F}, lastOutputR{0.0F}; // pre-bus contribution, for bounded overflow de-clicking
        float mixTargetL{0.70710678F};
        float mixTargetR{0.70710678F};
        float mixPanIn{0.0F};
        float mixLevelIn{0.0F};
        float mixSourceGainIn{1.0F};
        bool mixAudibleIn{true};
        // Upper + GLOBAL tuning (semitones) this voice is playing with now.
        double tuneSemis{0.0};
        AmpEnv ampEnv{};
        SampleDecayCursor sampleDecay{};
        float curveBlend{},curvePeak{1};
        bool editCurve{},oneShot{};
        ToneLowPass toneLp{};
        bool toneOn{false};
        float toneLog{0.0F};
        bool legatoKeep{false};
        bool mono{false};
        Envelope filterEnv{};
        Envelope pitchEnv{};
        LfoState lfo1{};
        LfoState lfo2{};
        StateVariableFilter filter{};
        bool sampleEnded{false};
        double soloIncrement{0};
        StateVariableFilter toneSvf{};
        float toneFilterHz{1000},toneFilterRes{0};
        solo::Voice* so{nullptr};
    };

    double sampleRate{48000.0};
    std::uint32_t maxBlock{512U};
    std::shared_ptr<const WaveTableMap> waveMap;   // SILVETON_TRANSWAVE_V1 (audio thread)
    // 128 playable voices + spare tail slots for 4 ms takeover fades.
    std::array<Voice, static_cast<std::size_t>(kMaxVoices) + SamplerEngine::kTakeoverTailVoices> voices{};
    std::array<ChannelState, 16U> channels{};
    std::uint32_t sourcePerformanceGeneration{0U};
    bool sourcePerformanceOwnerValid{false};
    // Per-part keyboard edits take precedence over older incoming CC5/65.
    // A fresh MIDI event can take control again; shared MIDI channels do
    // not force a UI edit of Upper 1 onto Upper 2/3 or Lower.
    std::array<std::uint8_t,kPartCount> keyboardPortamentoOverride{};
    std::atomic<float> sourceTempoRequested{120.0F};
    float sourceTempoBpm{120.0F};
    // Audio-owned global input gate, shared by held voices and routed Sounds.
    // Voice owners retain their part switches, not an obsolete global enable.
    bool aftertouchInputEnabled{true};
    // MONO/LEGATO: keys currently held on each Upper, oldest first.
    struct MonoKeys {
        std::array<std::uint8_t, kMidiKeys> key{};
        std::array<std::uint8_t, kMidiKeys> vel{};
        std::uint8_t count{0U};
    };
    std::array<MonoKeys, kPartCount> mono{};
    std::array<bool, kPartCount> monoWas{};
    // Accepted physical keys, independent of voice EOF, release tails and the
    // damper. POLY fingered glide must not mistake any of those for a held key.
    struct PolyKeys {
        std::array<std::uint64_t, 2U> held{};
        std::uint64_t chordStart{0U};
        std::uint8_t channel{0xFFU};
        bool chordActive{false};
        bool any() const noexcept { return (held[0] | held[1]) != 0U; }
        void press(std::uint8_t key) noexcept {
            held[(key & 0x7FU) >> 6U] |= std::uint64_t{1U} << (key & 0x3FU);
        }
        void release(std::uint8_t key) noexcept {
            held[(key & 0x7FU) >> 6U] &= ~(std::uint64_t{1U} << (key & 0x3FU));
        }
    };
    std::array<PolyKeys, kPartCount> polyKeys{};
    // Only the keyboard sampler enables this. Style samplers keep the default
    // false; track 6 of a Style is ACC4, not the keyboard's Lower.
    std::atomic<bool> lowerMemoryRequested{false};
    bool lowerMemoryApplied{false};
    std::array<std::array<bool,128>,16> lowerPhysical{},lowerDeferred{};
    std::atomic<float> portaBalance{11.0F};
    // SILVETON_PORTA_NEAR_V1: glide time for neighbouring keys (1..3 semitones), ms.
    std::atomic<float> portaNearMs{90.0F};
    std::uint64_t frameClock{0U};                                   // frames rendered so far
    std::array<int, kPartCount> polyLastKey{};                     // POLY portamento: last key of each Upper
    std::array<int, kPartCount> polyAnchorKey{};                   // glide start shared by a chord
    // SILVETON_TERCA_V1 (written by the control thread, read by the audio thread)
    std::atomic<int> tercaConfig{-1};    // -1 off, else partMask (15 bits: 7 Uppers + 8 places) | root << 16 | cell << 20 (SILVETON_TQ_PLACES_V1)
    std::atomic<int> scaleUppers{0};     // parts (Uppers and SYNTH places) whose Q key is on
    int tercaApplied{-1};                // config the maps below belong to (audio thread)
    std::array<std::array<std::int8_t, 128>, 16> tercaKey{};       // physical key -> harmony (-1)
    std::array<std::array<std::uint8_t, 128>, 16> tercaRefs{};     // harmony refcount
    std::uint64_t voiceAge{0U};
    std::uint32_t noiseState{0x9E3779B9U};   // SILVETON_POLYSIX_V1: per-note random
    float peakL{0.0F};
    float peakR{0.0F};
    float limiterGrDb{0.0F};
    float limiterGain{1.0F};
    std::array<float, kPartCount> upperPeakL{};
    std::array<float, kPartCount> upperPeakR{};
    // UI readers never inspect mutable voices/DSP storage. Atomic fields also
    // make a bounded seqlock read safe when a new publication overtakes it.
    struct PublishedMeters {
        std::atomic<std::uint32_t> seq{0U};
        std::atomic<float> left{0.0F}, right{0.0F}, reduction{0.0F}, cpu{0.0F};
        std::atomic<std::uint32_t> voices{0U};
        std::atomic<int> cores{1};
        std::array<std::atomic<float>, kPartCount> upperLeft{}, upperRight{};
    } publishedMeters;
    static_assert(std::atomic<float>::is_always_lock_free, "Audio telemetry needs lock-free floats");
    enum class ActivityState : unsigned { Idle, Requested, Ready };
    std::atomic<ActivityState> activityState{ActivityState::Idle};
    VoiceActivity activity;
    void captureVoiceActivity() noexcept {
        if(activityState.load(std::memory_order_acquire)!=ActivityState::Requested)return;
        activity={};
        activity.capturedMs=std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        std::array<const Voice*,16> oldest{};
        for(const auto& v:voices){
            if(!v.active || v.fading)continue;
            const auto channel=v.channel & 15U;
            auto& entry=activity.channels[channel];
            ++entry.active;
            if(v.keyHeld)++entry.held;
            if(v.sustained)++entry.sustained;
            if(v.zone && v.oneShot)++entry.oneShots;
            if(!oldest[channel] || v.age<oldest[channel]->age)oldest[channel]=&v;
        }
        for(std::size_t ch=0;ch<oldest.size();++ch){
            if(!oldest[ch])continue;
            auto& entry=activity.channels[ch];
            entry.oldestKey=oldest[ch]->key;
            if(!oldest[ch]->sample)continue;
            const auto& name=oldest[ch]->sample->name;
            auto n=std::min(name.size(),entry.oldestSample.size()-1);
            while(n && n<name.size() && (static_cast<unsigned char>(name[n])&0xc0U)==0x80U)--n;
            for(std::size_t i=0;i<n;++i)
                entry.oldestSample[i]=static_cast<unsigned char>(name[i])<32U?' ':name[i];
        }
        activityState.store(ActivityState::Ready,std::memory_order_release);
    }
    void publishMeters() noexcept {
        auto& m = publishedMeters;
        m.seq.fetch_add(1U, std::memory_order_acq_rel);
        m.left.store(peakL, std::memory_order_relaxed);
        m.right.store(peakR, std::memory_order_relaxed);
        m.reduction.store(limiterGrDb, std::memory_order_relaxed);
        std::uint32_t count = 0U;
        for (const auto& v : voices) if (v.active && !v.fading) ++count;
        m.voices.store(count, std::memory_order_relaxed);
        for (std::size_t i = 0; i < upperPeakL.size(); ++i) {
            m.upperLeft[i].store(upperPeakL[i], std::memory_order_relaxed);
            m.upperRight[i].store(upperPeakR[i], std::memory_order_relaxed);
        }
        m.cpu.store(cpuLoad.load(std::memory_order_relaxed), std::memory_order_relaxed);
        m.cores.store(coresWorking.load(std::memory_order_relaxed), std::memory_order_relaxed);
        m.seq.fetch_add(1U, std::memory_order_release);
    }
    std::array<std::uint16_t, kPartCount> upperRouteMask{};
    Biquad lowEq{}, midEq{}, highEq{};
    // SILVETON_EQ5_V1: common EQ of every Upper; SILVETON_TONE_V2: bus of every sound.
    std::array<UpperEqState, kPartCount> upperEq{};
    std::array<StripGateState,kPartCount> channelGates{};
    std::array<std::atomic<float>,kPartCount> gateMeters{};
    std::array<EvenDecayLive, kPartCount> evenDecay{};   // SILVETON_EVEN_DECAY_LIVE_V1: ЗАТИХВАНЕ of every Upper
    std::array<float, kPartCount> evenDecayApplied{};
   // Allocate SOLO voices once, outside the audio callback.
    std::array<solo::Voice, kMaxVoices + 32> soloPool{};
    // Legacy file metadata publication; not used as an audio source.
    std::shared_ptr<const model::LearnedModels> models;
    std::array<std::array<SoundBusState, kSoundsPerUpper>, kPartCount> soundBus{};
    // Emergency continuity when all sixteen full-waveform takeover tails are
    // occupied. These residuals retain only the last audible sample and fade
    // it to zero; they are not extra playable/full-waveform voices. One fixed
    // accumulator per bus bounds both memory and work during a MIDI burst.
    struct TakeoverResidual {
        float left{0.0F}, right{0.0F}, stepL{0.0F}, stepR{0.0F};
        std::uint32_t remaining{0U};
        void add(float l, float r, std::uint32_t duration) noexcept {
            left += l; right += r;
            remaining = std::max(1U, duration);
            stepL = left / static_cast<float>(remaining);
            stepR = right / static_cast<float>(remaining);
        }
        void tick(float& l, float& r) noexcept {
            if (remaining == 0U) return;
            l += left; r += right;
            if (--remaining == 0U) { *this = TakeoverResidual{}; return; }
            left -= stepL; right -= stepR;
        }
    };
    std::array<std::array<TakeoverResidual, kSoundsPerUpper>, kPartCount> takeoverResidual{};
    // Per-Upper, per-sound mix of one chunk (voices are rendered voice by voice).
    static constexpr std::uint32_t kRenderChunk = 256U;
    struct SourceSharedLfo {
        const Program* program{nullptr};
        const SourceOscillatorDsp* profile{nullptr};
        std::uint32_t generation{0U};
        int upper{-1},sound{-1};
        std::uint8_t channel{0U},oscillator{0U},key{60U},velocity{127U};
        float velocityPosition{1.0F};
        std::array<SourceLfoCursor,2> lfo{};
        std::array<std::array<float,kRenderChunk>,2> output{};
        std::array<bool,2> shared{};
        std::uint32_t initialDelay{0U};
        unsigned controlCountdown{0U};
    };
    std::array<SourceSharedLfo,kMaxVoices+SamplerEngine::kTakeoverTailVoices> sourceLfoSlots{};
    std::array<std::array<std::array<float, kRenderChunk>, kSoundsPerUpper>, kPartCount> chunkL{};
    std::array<std::array<std::array<float, kRenderChunk>, kSoundsPerUpper>, kPartCount> chunkR{};
    // SILVETON_MULTICORE_V1: the voices of a chunk sorted into their sound bus (kept in the
    // same order as the voice list, so the adding order inside a bus never changes), plus the
    // cores that share the work. threadsWanted 1 = everything on one core, as before.
    static constexpr int kBusCount = kPartCount * kSoundsPerUpper;
    std::array<std::array<std::uint16_t, kMaxVoices + static_cast<int>(SamplerEngine::kTakeoverTailVoices)>, kBusCount> busVoices{};
    std::array<std::uint16_t, kBusCount> busVoiceCount{};
    static constexpr std::size_t kHalfBus = (kMaxVoices + SamplerEngine::kTakeoverTailVoices + 1U) / 2U;
    std::array<std::array<float, kRenderChunk>, kHalfBus> splitL{}, splitR{};
    std::array<std::uint8_t, kBusCount> busOrder{};        // only the buses that carry voices
    // Serial engines on the same audio callback can reuse one helper team.
    // No pool ownership changes or shared_ptr copies occur inside render().
    std::shared_ptr<SilvetonRenderPool> pool{std::make_shared<SilvetonRenderPool>()};
    // SILVETON_VOICE_CEILING_V1: how many notes may sound at once (8...128)
    std::atomic<int> voiceCeiling{kMaxVoices};
    std::atomic<bool> channelMixEnabled{false};
    std::atomic<int> coresWorking{1};      // how many cores really shared the last block
    // SILVETON_FX_V3: one effect unit per send slot (A and B for the tails) and
    // one per Upper INSERT. Their buffers are allocated once in prepare().
    std::array<std::array<FxUnit, 2U>, kFxSendSlots> sendFx{};
    std::array<FxUnit, kPartCount> insertFx{};
    std::array<std::uint8_t, kFxSendSlots> fxInst{};        // engine the slot plays now (0 = A, 1 = B)
    std::array<SourceFxRenderParameters, kFxSendSlots> fxSourceRunning{};
    std::array<EffectSlot, kFxSendSlots> fxRunning{};       // settings of the last block
    bool fxRunningValid{false};
    std::uint32_t fxGeneration{0U};
    std::array<SourceFxRenderParameters, kFxSendSlots> tailSourceCfg{};
    std::array<EffectSlot, kFxSendSlots> tailCfg{};
    std::array<std::uint8_t, kFxSendSlots> tailInst{};
    std::array<std::uint32_t, kFxSendSlots> tailLeft{};     // frames the tail may still ring (0 = no tail)
    std::array<std::uint32_t, kFxSendSlots> tailQuiet{};    // frames the tail has been silent
    // A linked outgoing source graph owns one immutable snapshot across its
    // participating A/B lanes. Independent/manual tails keep snapshot zero.
    std::uint64_t tailSnapshotSerial{0U};
    std::array<std::uint64_t, kFxSendSlots> tailSnapshot{};
    std::array<std::uint8_t, kFxSendSlots> tailComponent{};
    // SILVETON_ANALYZER_V1
    std::array<std::atomic<float>, SamplerEngine::kAnalyzerRing> tapRing{};
    std::atomic<std::uint32_t> tapWrite{0U};
    std::atomic<int> tapUpper{-1};
    std::atomic<bool> tapAfter{true};
    // SILVETON_CPU_METER_V1
    std::atomic<float> cpuLoad{0.0F};
    float cpuLoadHold{0.0F};

    // Read-ahead windows for SampleStreamPrefetcher (one seqlock per slot).
    struct WindowSlot {
        std::atomic<std::uint32_t> seq{0U};
        std::atomic<std::uintptr_t> begin{0U};
        std::atomic<std::size_t> bytes{0U};
    };
    std::array<WindowSlot, SamplerEngine::kMaxStreamWindows> windows{};
    std::atomic<double> lookaheadSec{0.75};

    void publishWindow(std::size_t slot, std::uintptr_t begin, std::size_t bytes) noexcept {
        auto& w = windows[slot];
        if (w.begin.load(std::memory_order_relaxed) == begin && w.bytes.load(std::memory_order_relaxed) == bytes) return;
        const std::uint32_t s0 = w.seq.load(std::memory_order_relaxed);
        w.seq.store(s0 + 1U, std::memory_order_relaxed);
        std::atomic_thread_fence(std::memory_order_release);
        w.begin.store(begin, std::memory_order_relaxed);
        w.bytes.store(bytes, std::memory_order_relaxed);
        w.seq.store(s0 + 2U, std::memory_order_release);
    }

    void clearWindows() noexcept {
        for (std::size_t i = 0; i < windows.size(); ++i) publishWindow(i, 0U, 0U);
    }

    void reset(double sr) noexcept {
        sampleRate = sr;
        selectedProgramStates.fill({});
        programSelectionEnabled.fill(false);
        selectedProgramAddresses.fill(0xFFFFFFFFU);
        selectedProgramRevisions.fill(0);
        voiceAge = 0U;
        peakL = peakR = limiterGrDb = 0.0F;
        limiterGain = 1.0F;
        for (auto& ch : tercaKey) ch.fill(-1);
        for (auto& ch : tercaRefs) ch.fill(0U);
        tercaApplied = -1;
        polyLastKey.fill(-1); polyAnchorKey.fill(-1); frameClock = 0U;
        for (auto& p : polyKeys) p = PolyKeys{};
        lowerPhysical={};lowerDeferred={};lowerMemoryApplied=false;
        upperPeakL.fill(0.0F);
        upperPeakR.fill(0.0F);
        upperRouteMask.fill(0U);
        for (auto& c : channels) c = ChannelState{};
        sourcePerformanceGeneration=0U;sourcePerformanceOwnerValid=false;keyboardPortamentoOverride.fill(0U);
        sourceTempoBpm=sourceTempoRequested.load(std::memory_order_relaxed);
        for(auto& lfo:sourceLfoSlots)lfo=SourceSharedLfo{};
        for (auto& p : fxControlParts) p = FxControlPart{};
        fxControlBindingSerial = 0;
        fxControlPerformanceGeneration = 0;
        fxControlOwnerValid = false;
        for (auto& m : mono) m = MonoKeys{};
        monoWas.fill(false);
        for (auto& v : voices) v = Voice{};
        for (auto& row : takeoverResidual) for (auto& residual : row) residual = TakeoverResidual{};
        lowEq.reset(); midEq.reset(); highEq.reset();
        for (auto& e : upperEq) e.reset();
        for(auto& gate:channelGates)gate.prepare(sr);
        for(auto& meter:gateMeters)meter.store(0,std::memory_order_relaxed);
        for (auto& d : evenDecay) d.prepare(sr);
        evenDecayApplied.fill(-1.0F);
        for (auto& row : soundBus) for (auto& b : row) b.reset();
        for (auto& pair : sendFx) for (auto& u : pair) u.reset();
        for (auto& u : insertFx) u.reset();
        fxInst.fill(0U); tailLeft.fill(0U); tailQuiet.fill(0U); fxRunningValid = false; fxGeneration = 0U;
        tailSnapshotSerial = 0U; tailSnapshot.fill(0U); tailComponent.fill(0U);
        cpuLoadHold = 0.0F; cpuLoad.store(0.0F, std::memory_order_relaxed);
        clearWindows();
        publishMeters();
    }

    // Control thread only (allocates): effect memory for this sample rate.
    void prepareFx(double sr) {
        for (auto& pair : sendFx) for (auto& u : pair) u.prepare(sr, 2.6);
        for (auto& u : insertFx) u.prepare(sr, 1.1);
    }
};

UpperToneValues effectiveUpperTone(const UpperPart& upper) noexcept {
    EnvelopeParams env{};
    if (upper.program != nullptr && !upper.program->layers.empty()) env = upper.program->layers.front().ampEnvelope;
    return effectiveToneFor(basicToneOf(upper), upper, env);
}

UpperToneValues effectiveLayerTone(const UpperLayer& layer) noexcept {
    EnvelopeParams env{};
    if (layer.program != nullptr && !layer.program->layers.empty()) env = layer.program->layers.front().ampEnvelope;
    UpperPart plain{};   // a layer never uses the Easy Edit scales of the Upper
    return effectiveToneFor(layer.tone, plain, env);
}

SoundTone basicSoundTone(const UpperPart& upper) noexcept { return basicToneOf(upper); }

// SILVETON_OFS_V1: a velocity layer = where a zone of a layer starts on the velocity scale (the higher of the two bottoms)
std::vector<int> velocityZoneBottoms(const Program& program) {
    std::vector<int> b;
    for (const auto& layer : program.layers) {
        if (!layer.enabled || layer.multisample == nullptr) continue;
        for (const auto& z : layer.multisample->zones) {
            if (z.sample == nullptr) continue;
            const int lo = std::max<int>(layer.velocityLow, z.velocityLow), hi = std::min<int>(layer.velocityHigh, z.velocityHigh);
            if (lo > hi) continue;
            if (std::find(b.begin(), b.end(), lo) == b.end()) b.push_back(lo);
        }
    }
    std::sort(b.begin(), b.end(), std::greater<int>());
    return b;
}
int velocityZoneIndex(const Program& program, const ProgramLayer& layer, const SampleZone& zone) noexcept {
    const int mine = std::max<int>(layer.velocityLow, zone.velocityLow);
    int higher = 0;   // how many layers start above this one
    std::array<int, kOfsZones> seen{};
    int nSeen = 0;
    for (const auto& l : program.layers) {
        if (!l.enabled || l.multisample == nullptr) continue;
        for (const auto& z : l.multisample->zones) {
            if (z.sample == nullptr) continue;
            const int lo = std::max<int>(l.velocityLow, z.velocityLow), hi = std::min<int>(l.velocityHigh, z.velocityHigh);
            if (lo > hi || lo <= mine) continue;
            bool dup = false;
            for (int k = 0; k < nSeen; ++k) if (seen[static_cast<std::size_t>(k)] == lo) { dup = true; break; }
            if (dup) continue;
            if (nSeen < kOfsZones) seen[static_cast<std::size_t>(nSeen++)] = lo;
            if (++higher >= kOfsZones - 1) return kOfsZones - 1;
        }
    }
    return std::min(higher, kOfsZones - 1);
}

// ---------------------------------------------------------------- SILVETON_POLYSIX_V1 built-in waves
namespace {
constexpr std::array<const char*, kBuiltinWaveCount> kBuiltinWaveNames{{"SAW", "SQUARE", "PULSE 25", "TRIANGLE", "SINE", "SAW WARM"}};

SamplePtr makeWaveTable(int wave, int rootKey) {
    const double f = 440.0 * std::pow(2.0, (rootKey - 69) / 12.0);
    const auto P = static_cast<std::size_t>(std::max(16L, std::lround(96000.0 / f)));   // one period in frames
    const std::size_t periods = 8U;
    auto s = std::make_shared<SampleData>();
    s->name = std::string(kBuiltinWaveNames[static_cast<std::size_t>(wave)]) + " " + std::to_string(rootKey);
    s->sampleRate = static_cast<std::uint32_t>(std::lround(static_cast<double>(P) * f));   // so that one period = exactly P frames
    s->channels = 1U;
    s->rootKey = static_cast<std::uint8_t>(rootKey);
    s->interleaved.assign(P * periods, 0.0F);
    s->totalFrames = P * periods;
    s->loop.enabled = true; s->loop.startFrame = 0U; s->loop.endFrame = P * periods; s->loop.crossfadeFrames = 0U;
    const int nMax = static_cast<int>(P / 2U) - 1;   // the table's own Nyquist
    std::vector<double> one(P, 0.0);
    for (int n = 1; n <= nMax; ++n) {
        double a = 0.0; bool cosTerm = false;
        switch (wave) {
            case 0: a = ((n % 2) ? 1.0 : -1.0) / n; break;                                        // saw
            case 1: a = (n % 2) ? 1.0 / n : 0.0; break;                                            // square
            case 2: a = 2.0 / (n * kPi) * std::sin(n * kPi * 0.25); cosTerm = true; break;         // pulse 25 %
            case 3: a = (n % 2) ? (((n / 2) % 2 == 0) ? 1.0 : -1.0) / (static_cast<double>(n) * n) : 0.0; break;   // triangle
            case 4: a = n == 1 ? 1.0 : 0.0; break;                                                  // sine
            default: a = ((n % 2) ? 1.0 : -1.0) / n / (1.0 + std::pow(n / 12.0, 2.0)); break;       // saw warm
        }
        if (a == 0.0) continue;
        const double sigma = std::sin(kPi * n / (nMax + 1.0)) / (kPi * n / (nMax + 1.0));   // Lanczos: no Gibbs ripple
        a *= sigma;
        for (std::size_t i = 0; i < P; ++i) {
            const double th = 2.0 * kPi * static_cast<double>(i) / static_cast<double>(P);
            one[i] += a * (cosTerm ? std::cos(n * th) : std::sin(n * th));
        }
    }
    double peak = 1.0e-9; double mean = 0.0;
    for (double v : one) mean += v;
    mean /= static_cast<double>(P);
    for (double& v : one) { v -= mean; peak = std::max(peak, std::abs(v)); }
    for (std::size_t k = 0; k < periods; ++k)
        for (std::size_t i = 0; i < P; ++i) s->interleaved[k * P + i] = static_cast<float>(one[i] / peak * 0.5);
    return s;
}
} // namespace

const char* builtinWaveName(int index) noexcept {
    return (index >= 0 && index < kBuiltinWaveCount) ? kBuiltinWaveNames[static_cast<std::size_t>(index)] : "";
}

ProgramPtr builtinWaveProgram(int index) {
    if (index < 0 || index >= kBuiltinWaveCount) return nullptr;
    static std::array<ProgramPtr, kBuiltinWaveCount> cache{};
    static std::mutex cacheMutex;
    std::lock_guard<std::mutex> lock(cacheMutex);
    auto& slot = cache[static_cast<std::size_t>(index)];
    if (slot != nullptr) return slot;
    auto ms = std::make_shared<Multisample>();
    ms->name = kBuiltinWaveNames[static_cast<std::size_t>(index)];
    for (int root = 12; root <= 120; root += 12) {
        SampleZone z{};
        z.sample = makeWaveTable(index, root);
        z.rootKey = static_cast<std::uint8_t>(root);
        z.keyLow = static_cast<std::uint8_t>(root == 12 ? 0 : root - 6);
        z.keyHigh = static_cast<std::uint8_t>(root == 120 ? 127 : root + 5);
        z.velocityLow = 1U; z.velocityHigh = 127U;
        ms->zones.push_back(z);
    }
    auto prog = std::make_shared<Program>();
    prog->name = kBuiltinWaveNames[static_cast<std::size_t>(index)];
    ProgramLayer layer{};
    layer.name = prog->name;
    layer.multisample = ms;
    layer.ampEnvelope = EnvelopeParams{0.003F, 0.05F, 1.0F, 0.08F};
    prog->layers.push_back(layer);
    slot = prog;
    return slot;
}


SamplerEngine::SamplerEngine()
    : impl_(std::make_unique<Impl>()), state_(std::make_shared<EngineState>()),
      publications_(std::make_unique<Publications>()), interpolator_(InterpolationQuality::Studio) { // SILVETON_STUDIO_INTERP_V1
    {
        std::lock_guard<std::mutex> lock(publications_->mutex);
        publications_->states.publish(state_);
        publications_->states.applied.store(publications_->states.latest.load(std::memory_order_seq_cst), std::memory_order_seq_cst);
    }
    (void)soloCarrier();
    prepare(48000.0, 512U);
}
SamplerEngine::~SamplerEngine() = default;

void SamplerEngine::prepare(double sampleRate, std::uint32_t maximumBlockFrames) {
    const double sr = std::clamp(sampleRate, 8000.0, 384000.0);
    impl_->maxBlock = std::max<std::uint32_t>(16U, maximumBlockFrames);
    impl_->prepareFx(sr);
    impl_->reset(sr);
}

// SILVETON_MULTICORE_V1: how many cores render the voices. 1 = everything on one core, as
// before. The sound does not change: every bus keeps its own voices in their own order.
void SamplerEngine::setRenderThreads(int threads) noexcept {
    const int wanted = std::clamp(threads, 1, 8);
    if (wanted == impl_->pool->threadsWanted) return;
    impl_->pool->start(wanted - 1);
    impl_->pool->threadsWanted = wanted;
}

int SamplerEngine::renderThreads() const noexcept { return impl_->pool->threadsWanted; }

void SamplerEngine::shareRenderWorkersFrom(SamplerEngine& owner) noexcept {
    // Control thread, with every involved callback stopped. Retaining the pool
    // keeps its workers alive even if the original owning engine is destroyed.
    impl_->pool = owner.impl_->pool;
}

// SILVETON_VOICE_CEILING_V1
void SamplerEngine::setVoiceCeiling(int voices) noexcept {
    impl_->voiceCeiling.store(std::clamp(voices, 8, kMaxVoices), std::memory_order_relaxed);
}

int SamplerEngine::voiceCeiling() const noexcept { return impl_->voiceCeiling.load(std::memory_order_relaxed); }

void SamplerEngine::setPortamentoBalance(float balance) noexcept {
    impl_->portaBalance.store(std::isfinite(balance) ? std::clamp(balance, 3.0F, 40.0F) : 11.0F, std::memory_order_relaxed);
}

namespace {
struct TercaCell { std::array<int, 7> scale; int direction; };
constexpr std::array<TercaCell, 6> kTercaCells{{
    {{{0, 2, 4, 5, 7, 9, 11}}, +1},   // major third up
    {{{0, 2, 4, 5, 7, 9, 11}}, -1},   // major third down
    {{{0, 2, 3, 5, 7, 8, 10}}, +1},   // minor third up
    {{{0, 2, 3, 5, 7, 8, 10}}, -1},   // minor third down
    {{{0, 1, 3, 5, 7, 8, 10}}, +1},   // phrygian third up
    {{{0, 1, 4, 5, 7, 8, 10}}, +1},   // hijaz third up
}};
int tercaDegree(const std::array<int, 7>& scale, int relativePc) noexcept {
    for (int i = 0; i < 7; ++i) if (scale[static_cast<std::size_t>(i)] == relativePc) return i;
    return -1;
}
} // namespace

int SamplerEngine::tercaHarmony(int root, int cell, int key) noexcept {
    if (cell < 0 || cell >= 6 || key < 0 || key > 127) return -1;
    const auto& c = kTercaCells[static_cast<std::size_t>(cell)];
    const int dir = c.direction;
    const int pc = key % 12;
    const int relative = (pc - (root % 12) + 12) % 12;
    const int degree = tercaDegree(c.scale, relative);
    if (degree < 0) {
        // Not in the scale: the minor third that lands in the scale, else the
        // major third that does, else a plain minor third (processor rule).
        int delta = 3 * dir;
        if (tercaDegree(c.scale, ((relative + 3 * dir) % 12 + 12) % 12) >= 0) delta = 3 * dir;
        else if (tercaDegree(c.scale, ((relative + 4 * dir) % 12 + 12) % 12) >= 0) delta = 4 * dir;
        const int r = key + delta;
        return (r < 0 || r > 127) ? -1 : r;
    }
    const int step = degree + 2 * dir;
    const int octave = step >= 7 ? 12 : (step < 0 ? -12 : 0);
    const int target = c.scale[static_cast<std::size_t>(((step % 7) + 7) % 7)] + octave;
    const int r = key + target - c.scale[static_cast<std::size_t>(degree)];
    return (r < 0 || r > 127) ? -1 : r;
}

// SILVETON_TQ_PLACES_V1: the T and Q keys exist for every part - the 7 Uppers (bits 0..6) and the 8 SILVETON SYNTH places (bits 7..14)
constexpr int kAllPartsMask = (1 << kPartCount) - 1;

void SamplerEngine::setTerca(int upperMask, int root, int cell) noexcept {
    const int mask = upperMask & kAllPartsMask;
    const int cfg = (mask == 0 || cell < 0 || cell >= 6) ? -1 : (mask | ((root % 12 + 12) % 12) << 16 | cell << 20);
    impl_->tercaConfig.store(cfg, std::memory_order_release);
}

void SamplerEngine::setScaleUppers(int upperMask) noexcept {
    impl_->scaleUppers.store(upperMask & kAllPartsMask, std::memory_order_release);
}

void SamplerEngine::setPortamentoNear(float ms) noexcept {
    impl_->portaNearMs.store(std::isfinite(ms) ? std::clamp(ms, 0.0F, 400.0F) : 90.0F, std::memory_order_relaxed);
}

float SamplerEngine::portamentoNear() const noexcept {
    return impl_->portaNearMs.load(std::memory_order_relaxed);
}

float SamplerEngine::portamentoBalance() const noexcept {
    return impl_->portaBalance.load(std::memory_order_relaxed);
}

void SamplerEngine::reset() noexcept {
    impl_->reset(impl_->sampleRate);
    events_.clear();
}

void SamplerEngine::setState(std::shared_ptr<const EngineState> state) noexcept {
    if (state == nullptr) return;
    // Control only: retain ownership before publishing the immutable node.
    std::lock_guard<std::mutex> lock(publications_->mutex);
    publications_->states.publish(std::move(state));
    publications_->collect();
}

std::shared_ptr<const EngineState> SamplerEngine::state() const noexcept {
    std::lock_guard<std::mutex> lock(publications_->mutex);
    const auto prepared=publications_->preparedStates.current();
    if(prepared)return prepared->state;
    return publications_->states.current();
}

void SamplerEngine::setWaveTables(std::shared_ptr<const WaveTableMap> tables) noexcept {
    if (tables == nullptr) tables = std::make_shared<const WaveTableMap>();
    std::lock_guard<std::mutex> lock(publications_->mutex);
    publications_->waves.publish(std::move(tables));
    publications_->collect();
}

// SILVETON_MODEL_V1
void SamplerEngine::setLearnedModels(std::shared_ptr<const model::LearnedModels> models) noexcept {
    if (models == nullptr) models = std::make_shared<const model::LearnedModels>();
    std::lock_guard<std::mutex> lock(publications_->mutex);
    publications_->models.publish(std::move(models));
    publications_->collect();
}
std::shared_ptr<const model::LearnedModels> SamplerEngine::learnedModels() const noexcept {
    std::lock_guard<std::mutex> lock(publications_->mutex);
    return publications_->models.newest();
}

bool SamplerEngine::readStreamWindow(std::size_t slot, StreamWindow& out) const noexcept {
    out = StreamWindow{};
    if (slot >= impl_->windows.size()) return false;
    const auto& w = impl_->windows[slot];
    const std::uint32_t s1 = w.seq.load(std::memory_order_acquire);
    if ((s1 & 1U) != 0U) return false;
    const std::uintptr_t begin = w.begin.load(std::memory_order_relaxed);
    const std::size_t bytes = w.bytes.load(std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_acquire);
    if (w.seq.load(std::memory_order_relaxed) != s1) return false;
    out.begin = begin;
    out.bytes = bytes;
    return true;
}

float SamplerEngine::channelGateReduction(int part) const noexcept {
    return part>=0&&part<kPartCount?impl_->gateMeters[part].load(std::memory_order_relaxed):0.0F;
}
void SamplerEngine::setAnalyzerTap(int upper, bool afterEq) noexcept {
    impl_->tapAfter.store(afterEq, std::memory_order_relaxed);
    impl_->tapUpper.store((upper >= 0 && upper < kPartCount) ? upper : -1, std::memory_order_release);
}

void SamplerEngine::readAnalyzer(float* out, std::size_t frames) const noexcept {
    if (out == nullptr || frames == 0U) return;
    const std::size_t n = std::min(frames, kAnalyzerRing);
    const std::uint32_t w = impl_->tapWrite.load(std::memory_order_acquire);
    for (std::size_t i = 0; i < n; ++i) {
        const std::size_t idx = (static_cast<std::size_t>(w) + kAnalyzerRing - n + i) % kAnalyzerRing;
        out[i] = impl_->tapRing[idx].load(std::memory_order_relaxed);
    }
    for (std::size_t i = n; i < frames; ++i) out[i] = 0.0F;
}

void SamplerEngine::setStreamLookaheadSeconds(double seconds) noexcept {
    impl_->lookaheadSec.store(std::clamp(seconds, 0.05, 4.0), std::memory_order_relaxed);
}

bool SamplerEngine::postNoteOn(std::uint8_t ch, std::uint8_t key, std::uint8_t vel) noexcept {
    // A velocity-zero NOTE ON is a release, including the queue's reserved OFF capacity.
    // MIDI 1 Note On with zero velocity carries the default release velocity 64.
    // An explicit Note Off with velocity zero remains distinct for release AMS.
    if ((vel & 0x7FU) == 0U) return postNoteOff(ch, key, 64U);
    return events_.push({EventType::NoteOn, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(key & 0x7FU), static_cast<std::uint8_t>(vel & 0x7FU), 0});
}
bool SamplerEngine::postNoteOff(std::uint8_t ch, std::uint8_t key, std::uint8_t vel) noexcept {
    return events_.push({EventType::NoteOff, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(key & 0x7FU), static_cast<std::uint8_t>(vel & 0x7FU), 0});
}
bool SamplerEngine::postControlChange(std::uint8_t ch, std::uint8_t cc, std::uint8_t value) noexcept {
    return events_.push({EventType::ControlChange, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(cc & 0x7FU), static_cast<std::uint8_t>(value & 0x7FU), 0});
}
bool SamplerEngine::postPitchBend(std::uint8_t ch, std::int16_t value) noexcept {
    RealtimeEvent e{}; e.type = EventType::PitchBend; e.channel = static_cast<std::uint8_t>(ch & 0x0FU); e.pitchBend = static_cast<std::int16_t>(std::clamp<int>(value, -8192, 8191));
    return events_.push(e);
}
bool SamplerEngine::postChannelPressure(std::uint8_t ch, std::uint8_t value) noexcept {
    return events_.push({EventType::ChannelPressure, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(value & 0x7FU), 0U, 0});
}
bool SamplerEngine::postPolyPressure(std::uint8_t ch,std::uint8_t key,std::uint8_t value) noexcept {
    return events_.push({EventType::PolyPressure,static_cast<std::uint8_t>(ch&15U),
        static_cast<std::uint8_t>(key&127U),static_cast<std::uint8_t>(value&127U),0});
}
void SamplerEngine::setSourceTempo(float bpm) noexcept {
    if(std::isfinite(bpm)&&bpm>0.0F)impl_->sourceTempoRequested.store(std::clamp(bpm,1.0F,999.0F),std::memory_order_release);
}
bool SamplerEngine::postPanic() noexcept { return events_.push({EventType::Panic,0U,0U,0U,0}); }
bool SamplerEngine::postSoftChannelRelease(std::uint8_t channel) noexcept {
    if(channel>15U)return false;
    RealtimeEvent event{};event.type=EventType::SoftChannelRelease;event.channel=channel;
    if(events_.push(event))return true;
    // A full queue must still release the channel. The existing critical CC
    // path reserves space and has a deferred safety bit when even that is full.
    return postControlChange(channel,123U,0U);
}

bool SamplerEngine::postResetSourceChannel(std::uint8_t channel) noexcept {
    if(channel>15U)return false;
    RealtimeEvent event{};event.type=EventType::ResetSourceChannel;event.channel=channel;
    return events_.push(event);
}

namespace {
bool validRealtimeProgramBank(const std::shared_ptr<const RealtimeProgramBank>& bank) noexcept {
    if (!bank || bank->revision == 0 || bank->routes.size() > 65535U) return false;
    std::uint32_t previous = 0; bool first = true;
    for (const auto& route : bank->routes) {
        if (route.channel > 15 || route.msb > 127 || route.lsb > 127 || route.program > 127 || !route.state) return false;
        const auto key = (static_cast<std::uint32_t>(route.channel) << 24) |
            (static_cast<std::uint32_t>(route.msb) << 16) |
            (static_cast<std::uint32_t>(route.lsb) << 8) | route.program;
        if (!first && key <= previous) return false;
        first = false; previous = key;
    }
    return true;
}
} // namespace

bool SamplerEngine::setRealtimeProgramBank(std::shared_ptr<const RealtimeProgramBank> bank) {
    if(!validRealtimeProgramBank(bank))return false;
    std::lock_guard<std::mutex> lock(publications_->mutex);
    for (const auto& route : bank->routes) publications_->states.retain(route.state);
    publications_->programBanks.publish(std::move(bank));
    publications_->collect();
    return true;
}

bool SamplerEngine::registerPreparedState(std::shared_ptr<const PreparedSamplerState> prepared) {
    if(!prepared||!prepared->state||!validRealtimeProgramBank(prepared->bank))return false;
    std::lock_guard<std::mutex> lock(publications_->mutex);
    const void* expected=nullptr;
    if(!prepared->owner_.compare_exchange_strong(expected,publications_.get(),std::memory_order_acq_rel)&&
       expected!=publications_.get())return false;
    publications_->states.retain(prepared->state);
    for(const auto& route:prepared->bank->routes)publications_->states.retain(route.state);
    publications_->programBanks.retain(prepared->bank);
    auto* node=publications_->preparedStates.retain(prepared);
    prepared->registration_.store(node,std::memory_order_release);
    publications_->collect();
    return true;
}

bool SamplerEngine::publishPreparedState(std::shared_ptr<const PreparedSamplerState> prepared) {
    if(!registerPreparedState(prepared))return false;
    std::lock_guard<std::mutex> lock(publications_->mutex);
    publications_->preparedStates.publish(std::move(prepared));
    publications_->collect();
    return true;
}

bool SamplerEngine::postPreparedState(const PreparedSamplerState* prepared) noexcept {
    if(!prepared||prepared->owner_.load(std::memory_order_acquire)!=publications_.get()||
       !prepared->registration_.load(std::memory_order_acquire))return false;
    prepared->queuedPosts_.fetch_add(1U,std::memory_order_acq_rel);
    RealtimeEvent event{};event.type=EventType::ActivatePreparedState;event.preparedState=prepared;
    if(events_.push(event))return true;
    prepared->queuedPosts_.fetch_sub(1U,std::memory_order_acq_rel);
    return false;
}

bool SamplerEngine::postProgramSelection(std::uint8_t channel, std::uint8_t msb,
        std::uint8_t lsb, std::uint8_t program, std::uint64_t revision, const void* sourceIdentity) noexcept {
    if (channel > 15 || msb > 127 || lsb > 127 || program > 127 || revision == 0) return false;
    RealtimeEvent event{}; event.type = EventType::SelectProgram; event.channel = channel;
    event.programAddress = (static_cast<std::uint32_t>(msb) << 16) |
        (static_cast<std::uint32_t>(lsb) << 8) | program;
    event.programRevision = revision;
    event.programSourceIdentity = sourceIdentity;
    return events_.push(event);
}
bool SamplerEngine::postClearProgramSelection(std::uint8_t channel) noexcept {
    if (channel > 15) return false;
    RealtimeEvent event{}; event.type = EventType::SelectProgram; event.channel = channel;
    return events_.push(event);
}

void SamplerEngine::setLowerMemoryEnabled(bool enabled) noexcept {
    impl_->lowerMemoryRequested.store(enabled,std::memory_order_release);
}
void SamplerEngine::setChannelMixEnabled(bool enabled) noexcept {
    impl_->channelMixEnabled.store(enabled,std::memory_order_release);
}

namespace {

constexpr float kTakeoverFadeSec = 0.004F; // 4 ms: click-free and inaudible as a fade

void softKill(SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& v, float fadeSec = kTakeoverFadeSec) noexcept {
    if (!v.active || v.fading) return;
    if (v.delayFramesRemaining > 0U) { v.active = false; return; } // has not sounded yet
    v.fading = true;
    v.keyHeld = false;
    v.sustained = false;
    v.fadeStep = -1.0F / static_cast<float>(std::max(1.0, static_cast<double>(fadeSec) * impl.sampleRate));
}

// Move a victim's last contribution to a bounded click-free tail before
// releasing its playable slot. No additional sample allocations or readers.
void retirePlayableVoice(SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& victim) noexcept {
    constexpr auto kPlayable = static_cast<std::size_t>(kMaxVoices);
    bool tailCaptured = false;
    for (std::size_t i = kPlayable; i < impl.voices.size(); ++i) {
        auto& tail = impl.voices[i];
        if (tail.active) continue;
        tail = victim;
        softKill(impl, tail);
        tailCaptured = true;
        break;
    }
    if (!tailCaptured) {
        const auto ui = static_cast<std::size_t>(std::clamp(victim.upperIndex, 0, kPartCount - 1));
        const auto si = static_cast<std::size_t>(std::clamp(victim.soundIndex, 0, kSoundsPerUpper - 1));
        const auto duration = static_cast<std::uint32_t>(std::max(1.0, static_cast<double>(kTakeoverFadeSec) * impl.sampleRate));
        impl.takeoverResidual[ui][si].add(victim.lastOutputL, victim.lastOutputR, duration);
    }
    diagnostics::recordVoiceSteal(!tailCaptured);
    victim.active = false;
}

SamplerEngine::Impl::Voice* chooseVoice(SamplerEngine::Impl& impl, bool audible,
        std::uint64_t firstNewAge, bool wholeAttack = false) noexcept {
    using Voice = SamplerEngine::Impl::Voice;
    constexpr auto kPlayable = static_cast<std::size_t>(kMaxVoices);
    const auto ceiling = static_cast<std::size_t>(std::clamp(impl.voiceCeiling.load(std::memory_order_relaxed),8,kMaxVoices));
    std::size_t sounding = 0U;
    Voice* freeSlot = nullptr;
    for (std::size_t i = 0; i < kPlayable; ++i) {
        auto& v=impl.voices[i];
        if(v.active)++sounding;
        else if(!freeSlot)freeSlot=&v;
    }
    if(sounding<ceiling&&freeSlot)return freeSlot;
    if(!audible)return nullptr; // an inaudible part never displaces a sounding one
    // A new oscillator has not rendered its attack envelope yet. Comparing
    // it to older oscillators as if it were quiet used to steal the siblings
    // of the SAME note. Protect the entire incoming attack and any retained
    // legato voices. POLY steals complete old attacks, not arbitrary partial
    // timbres. MONO/LEGATO retain their per-voice hand-off/crossfade path.
    const auto protectedVoice = [firstNewAge](const Voice& v) noexcept {
        return v.age>=firstNewAge||v.legatoKeep;
    };
    const auto priority=[](const Voice& v) noexcept {
        return v.fading?0:(v.keyHeld?3:(v.sustained?2:1));
    };
    const auto level=[](const Voice& v) noexcept {
        return std::abs(v.ampEnv.value*v.baseGain)*std::max(std::abs(v.mixL),std::abs(v.mixR));
    };
    if(!wholeAttack){
        Voice* victim=nullptr;
        for(std::size_t i=0;i<kPlayable;++i){
            auto& v=impl.voices[i];
            if(!v.active||protectedVoice(v))continue;
            if(!victim||priority(v)<priority(*victim)||
               (priority(v)==priority(*victim)&&(level(v)<level(*victim)||
                (level(v)==level(*victim)&&v.age<victim->age))))victim=&v;
        }
        if(!victim)return nullptr;
        retirePlayableVoice(impl,*victim);
        return victim;
    }
    // Fixed, low-load-factor table on the audio thread. At most kMaxVoices
    // distinct groups; no heap allocation, locks, sort or unbounded storage.
    struct Group {
        std::uint64_t id{0},oldest{0};
        float level{0};
        int priority{0};
        bool protectedGroup{false};
    };
    constexpr std::size_t capacity=kPlayable*2U+1U;
    std::array<Group,capacity> groups{};
    for(std::size_t i=0;i<kPlayable;++i){
        const auto& v=impl.voices[i];if(!v.active)continue;
        const auto id=v.attackGroup?v.attackGroup:v.age;
        auto slot=static_cast<std::size_t>(id%capacity);
        while(groups[slot].id!=0&&groups[slot].id!=id)slot=(slot+1U)%capacity;
        auto& g=groups[slot];
        if(!g.id){g.id=id;g.oldest=v.age;}
        g.oldest=std::min(g.oldest,v.age);
        g.priority=std::max(g.priority,priority(v));
        g.level=std::max(g.level,level(v));
        g.protectedGroup|=protectedVoice(v);
    }
    const Group* victimGroup=nullptr;
    for(const auto& g:groups){
        if(!g.id||g.protectedGroup)continue;
        if(!victimGroup||g.priority<victimGroup->priority||
           (g.priority==victimGroup->priority&&(g.level<victimGroup->level||
            (g.level==victimGroup->level&&g.oldest<victimGroup->oldest))))victimGroup=&g;
    }
    if(!victimGroup)return nullptr; // the attack itself exceeds the physical voice budget
    Voice* victim=nullptr;
    for(std::size_t i=0;i<kPlayable;++i){
        auto& v=impl.voices[i];
        if(!v.active||(v.attackGroup?v.attackGroup:v.age)!=victimGroup->id)continue;
        if(!victim)victim=&v;
        retirePlayableVoice(impl,v);
    }
    return victim;
}

// Playback ratio of a key for one layer/zone (also used by LEGATO pitch changes).
// ulayer = the layer of the Upper this sound belongs to (nullptr = basic sound).
std::uint8_t playKeyFor(const UpperPart& upper, const GlobalState& global, std::uint8_t key,
                        const UpperLayer* ulayer = nullptr) noexcept {
    // SILVETON_LAYER_OCTAVE_OWN_V1: every sound has its OWN octave - the OCTAVE of ОСНОВЕН moves only the basic sound,
    // the OCTAVE of a layer (L1..L4) moves only that layer. (TRANSPOSE of the Upper still applies to all, as before.)
    int k = static_cast<int>(key) + static_cast<int>(upper.transposeSemitones) + static_cast<int>(global.transposeSemitones);
    if (ulayer != nullptr) k += static_cast<int>(ulayer->transposeSemitones) + static_cast<int>(ulayer->octave) * 12;
    else k += static_cast<int>(upper.octave) * 12;
    return static_cast<std::uint8_t>(std::clamp(k, 0, 127));
}

double sourceTuneSemis(const UpperPart& upper) noexcept {
    // MIDI RPN2 is a semitone pitch offset; RPN1 has 1/8192-semitone
    // resolution around 8192. Neither changes the played key/sample zone.
    const double coarse=upper.sourceCoarseTuneRaw>=0&&upper.sourceCoarseTuneRaw<=127
        ?static_cast<double>(upper.sourceCoarseTuneRaw-64):0.0;
    const double fine=upper.sourceFineTuneRaw>=0&&upper.sourceFineTuneRaw<=16383
        ?static_cast<double>(upper.sourceFineTuneRaw-8192)/8192.0:0.0;
    return coarse+fine;
}

double noteRatio(const SamplerEngine::Impl& impl, const UpperPart& upper, const ProgramLayer& layer,
                 const SampleZone& zone, std::uint8_t key, const GlobalState& global, int ui,
                 const UpperLayer* ulayer = nullptr) noexcept {
    // SILVETON_OCTAVE_KEY_V1: OCTAVE / TRANSPOSE move the KEY (like Korg): the
    // sample recorded for the new key is chosen and played at its own pitch,
    // instead of stretching the sample of the pressed key.
    const std::uint8_t pk = playKeyFor(upper, global, key, ulayer);
    const int keyTracking = zone.nonTranspose ? 0 : (static_cast<int>(pk) - static_cast<int>(zone.rootKey));
    const int semitones = keyTracking +
                          static_cast<int>(zone.transposeSemitones) + static_cast<int>(layer.transposeSemitones);
    const int root = static_cast<int>(global.scaleRoot % 12U);
    // SILVETON_TQ_TRANSPOSE_V1: the scale follows the PLAYED key, so TRANSPOSE /
    // OCTAVE / TUNE never move it (same keys as SCAN saw).
    const int pc = (static_cast<int>(key) - root + 120) % 12;
    // SILVETON_SCALE_V1: only Uppers with their Q key on follow the scale.
    const bool scaleOn = ((impl.scaleUppers.load(std::memory_order_relaxed) >> ui) & 1) != 0;
    const float scaleCents = scaleOn ? std::clamp(global.scaleOffsetsCents[static_cast<std::size_t>(pc)], -100.0F, 100.0F) : 0.0F;
    const float cents = zone.tuneCents + layer.tuneCents + upper.tuneCents + zone.sample->fineTuneCents + scaleCents +
                        (ulayer != nullptr ? ulayer->tuneCents : 0.0F);
    const double tuneHz = std::clamp(static_cast<double>(global.masterTuneHz), 400.0, 480.0);
    const double masterTuneSemis = 12.0 * std::log2(tuneHz / 440.0);
    const double pitch = static_cast<double>(semitones) + static_cast<double>(cents) / 100.0 + masterTuneSemis + sourceTuneSemis(upper);
    return (static_cast<double>(zone.sample->sampleRate) / impl.sampleRate) * std::pow(2.0, pitch / 12.0);
}

// SILVETON_LIVE_EDIT_V1 - live settings of notes that already sound.
// While an Upper keeps the same Sound, its sounding notes follow live edits:
// level, pan, ON / MUTE / SOLO (smoothed, no clicks), fine/master tuning,
// TONE, LFO, controllers, EQ. SOLO also follows octave/transpose immediately;
// Arranger PCM follows held pitch changes and chooses the new zone at the next note.
// A note of a Sound that was replaced (or of another COMBI) keeps its own
// settings and ends naturally.
constexpr double kLiveMixSmoothSec = 0.005;

double liveTuneSemis(const UpperPart& upper, const GlobalState& global, std::uint8_t key, bool scaleOn,
                     const UpperLayer* ulayer,bool pitchedZone) noexcept {
    // A held arranger voice keeps its sample cursor. New notes choose the transposed zone.
    const int root = static_cast<int>(global.scaleRoot % 12U);
    const int pc = (static_cast<int>(key) - root + 120) % 12;   // SILVETON_TQ_TRANSPOSE_V1: played key
    const float scaleCents = scaleOn ? std::clamp(global.scaleOffsetsCents[static_cast<std::size_t>(pc)], -100.0F, 100.0F) : 0.0F;
    const double tuneHz = std::clamp(static_cast<double>(global.masterTuneHz), 400.0, 480.0);
    const double liveTranspose = (upper.livePartMix&&pitchedZone)||(ulayer ? ulayer->engine : upper.engine).type==EngineType::Solo
        ? static_cast<int>(playKeyFor(upper,global,key,ulayer))-static_cast<int>(key) : 0;
    return liveTranspose + sourceTuneSemis(upper) + static_cast<double>(upper.tuneCents + scaleCents + (ulayer != nullptr ? ulayer->tuneCents : 0.0F)) / 100.0 +
           12.0 * std::log2(tuneHz / 440.0);
}

bool upperAudible(const EngineState& state, const UpperPart& upper) noexcept {
    if (!upper.enabled || upper.mute) return false;
    for (int pi = 0; pi < kPartCount; ++pi) { const auto& u = state.combi.part(pi); if (u.enabled && u.solo) return upper.solo; }
    return true;
}

// The original Program and SampleZone remain pinned by the voice. Only its
// immutable parameters change, including a key edit in the middle of a note.
const LiveDrumKey& liveKeyOf(const UpperPart& upper,std::uint8_t key) noexcept {
    static constexpr LiveDrumKey neutral{};
    return upper.liveDrumKeys?(*upper.liveDrumKeys)[key]:neutral;
}
SourceSoundEdits sourceEditsFor(const UpperPart& upper,const SamplerEngine::Impl::ChannelState& channel,std::uint8_t portamentoOverride=0U) noexcept {
    auto result=upper.sourceSoundEdits;
    for(unsigned i=0U;i<8U;++i)if((channel.sourceEditTouched&(1U<<i))!=0U)result.raw[i]=channel.sourceSoundEdits.raw[i];
    if((channel.sourceEditTouched&256U)!=0U&&!(portamentoOverride&1U))result.portamentoTimeRaw=channel.sourceSoundEdits.portamentoTimeRaw;
    if((channel.sourceEditTouched&512U)!=0U&&!(portamentoOverride&2U))result.portamentoOnRaw=channel.sourceSoundEdits.portamentoOnRaw;
    return result;
}
void captureSourceControls(SamplerEngine::Impl& impl,SamplerEngine::Impl::Voice& voice) noexcept {
    if(voice.upper==nullptr)return;
    voice.sourceControls=impl.channels[voice.channel&15U];
    voice.sourceEdits=sourceEditsFor(*voice.upper,voice.sourceControls,impl.keyboardPortamentoOverride[static_cast<std::size_t>(std::clamp(voice.upperIndex,0,kPartCount-1))]);
    voice.sourceTempoBpm=impl.sourceTempoBpm;
}
SourceModulationContext sourceContext(const SamplerEngine::Impl& impl,const SamplerEngine::Impl::Voice& voice,
                                     const GlobalState& global) noexcept {
    SourceModulationContext context;
    const auto& controls=voice.sourceControls;
    context.controllers=&controls.cc;context.controllersSeen=&controls.ccSeen;
    context.key=voice.sourceKey;context.velocity=voice.sourceVelocity;context.releaseVelocity=voice.releaseVelocity;
    context.velocityPosition=voice.sourceVelocityPosition;
    context.portamentoSwitch=voice.sourceEdits.controller(65);
    if(voice.upper!=nullptr){
        const auto tone=soundToneOf(*voice.upper,voice.soundIndex);
        context.velocityLevelScale=tone.x.velToLevel;
        context.manualCutoffHz=tone.cutoffHz;
        context.manualResonance=tone.resonance;
        context.filterExtraOctaves=voice.sourceToneExtraOctaves+voice.upper->filterCutoffOctaves;
        context.resonanceExtra=voice.modRes+voice.upper->filterResonanceOffset;
        context.filterReplacedByTone=tone.x.filterType!=0;
    }
    context.released=!voice.keyHeld;context.damper=voice.sustained||(voice.keyHeld&&controls.sustain);
    const bool allowed=((global.midiInputChannelMask>>(voice.channel&15U))&1U)!=0U;
    context.controlEnabled=allowed&&!global.filterControlChange;
    context.pressureEnabled=allowed&&impl.aftertouchInputEnabled&&voice.upper!=nullptr&&voice.upper->aftertouchEnabled;
    context.bendEnabled=allowed&&global.pitchBendEnabled&&!global.filterPitchBend;
    context.pressure=controls.pressure;context.polyPressure=controls.polyPressure[voice.key&127U];
    context.pitchBend=static_cast<float>(controls.pitchBend)/(controls.pitchBend>=0?8191.0F:8192.0F);
    context.tempoBpm=voice.sourceTempoBpm;
    context.amplitudeEnvelope=voice.ampEnv.value;
    context.pitchEnvelope=voice.sourceOscillator.support.pitchEnvelope?voice.sourceOscillator.pitchEnvelope.value:voice.pitchEnv.value;
    context.filterEnvelope=voice.sourceOscillator.support.filterEnvelope?voice.sourceOscillator.filterEnvelope.value:voice.filterEnv.value;
    if(voice.layer!=nullptr){
        const auto& envelope=voice.layer->sourceAmpEnvelope;
        context.amplitudeKeys=envelope.keyboardKeys;context.amplitudeRamps=envelope.keyboardRamps;
        context.filterKeys=envelope.filterKeyboardKeys;context.filterRamps=envelope.filterKeyboardRamps;
        if(const auto* source=voice.sourceOscillator.source){
            const auto& d=source->dspRaw;const auto& a=source->amplitudeEnvelopeRaw;
            context.filterKeys={d[76],d[78]};context.filterRamps={static_cast<std::int8_t>(sourceSignedByte(d[77])),static_cast<std::int8_t>(sourceSignedByte(d[79]))};
            context.amplitudeKeys={a[18],a[20]};context.amplitudeRamps={static_cast<std::int8_t>(sourceSignedByte(a[19])),static_cast<std::int8_t>(sourceSignedByte(a[21]))};
            context.lfo={voice.sourceOscillator.inputs[4U],voice.sourceOscillator.inputs[5U]};
        }
    }
    return context;
}
void refreshSourceAmp(SamplerEngine::Impl& impl,SamplerEngine::Impl::Voice& voice,const GlobalState& global) noexcept {
    if(!voice.ampEnv.sourceEnabled||voice.layer==nullptr)return;
    auto modulation=sourceModulationValues(sourceContext(impl,voice,global));
    voice.ampEnv.source.rekey(voice.layer->sourceAmpEnvelope,voice.sourceKey,voice.sourceVelocity,&modulation);
}
UpperToneValues voiceTone(SamplerEngine::Impl::Voice& v,const SoundTone& tone,const UpperPart& u) noexcept {
    const auto& layer=*v.layer;
    const auto& key=liveKeyOf(u,v.key);
    const bool edited=u.livePartMix&&(tone.decayMs>=0||tone.sustain>=0||key.decay>=0||key.sustain>=0);
    v.editCurve=!v.ampEnv.sourceEnabled&&edited&&layer.sampleDecay.enabled();
    // Every original OSC keeps its own Start/Attack/Break/Sustain shape. Part
    // and per-key controls override individual parameters of that shape.
    auto env=v.ampEnv.sourceEnabled?v.ampEnv.source.defaults:
        (edited?editableAmpEnvelope(layer):layer.ampEnvelope);
    env.attackSec=sourceSoundEditTimeMs(env.attackSec*1000.0F,v.sourceEdits.controller(73))*.001F;
    env.decaySec=sourceSoundEditTimeMs(env.decaySec*1000.0F,v.sourceEdits.controller(75))*.001F;
    env.releaseSec=sourceSoundEditTimeMs(env.releaseSec*1000.0F,v.sourceEdits.controller(72))*.001F;
    auto t=effectiveToneFor(tone,u,env);
    if(!v.sourceOscillator.support.filter){
        if(tone.cutoffHz<0.0F)t.cutoffHz=std::clamp(t.cutoffHz*std::exp2(sourceSoundEditCutoffOctaves(v.sourceEdits.controller(74))),20.0F,kToneCutoffOpenHz);
        if(tone.resonance<0.0F)t.resonance=std::clamp(t.resonance+sourceSoundEditResonance(v.sourceEdits.controller(71)),0.0F,1.0F);
    }
    if(key.attack>=0)t.attackMs=static_cast<float>(key.attack);
    if(key.decay>=0)t.decayMs=static_cast<float>(key.decay);
    if(key.sustain>=0)t.sustain=static_cast<float>(key.sustain)*.01F;
    if(key.release>=0)t.releaseMs=static_cast<float>(key.release);
    const int gate=key.gate>=0?key.gate:u.liveGate;
    v.oneShot=gate<0?v.zone->oneShot:gate!=0;
    return t;
}

void prepareSourceRelease(SamplerEngine::Impl& impl,SamplerEngine::Impl::Voice& voice) noexcept {
    if(voice.upper==nullptr||voice.ownerState==nullptr)return;
    if(voice.sourcePerformanceGeneration==impl.sourcePerformanceGeneration)captureSourceControls(impl,voice);
    voice.sourceControls.sustain=false;
    refreshSourceAmp(impl,voice,voice.ownerState->global);
    if(voice.ampEnv.sourceEnabled){
        auto tone=voiceTone(voice,soundToneOf(*voice.upper,voice.soundIndex),*voice.upper);
        tone.releaseMs=std::clamp(tone.releaseMs*voice.modReleaseMul,0.0F,kToneMaxTimeMs);
        voice.ampEnv.setBlock(tone,impl.sampleRate);
    }
    voice.sourceOscillator.inputs=sourceModulationValues(sourceContext(impl,voice,voice.ownerState->global));
    voice.sourceOscillator.invalidateOutputCache();
    voice.sourceOscillator.configureEnvelopes(voice.sourceEdits,impl.sampleRate);
    voice.sourceOscillator.release();
}

// Mix gains of a voice: Upper level x equal-power pan x ON/MUTE/SOLO.
// Recomputed only when one of its inputs changes.
void updateMixTarget(SamplerEngine::Impl::Voice& v, const UpperPart& upper, bool audible, float extraPan,
                     float channelPan = 0.0F) noexcept {
    // SILVETON_LAYERS_V1: a layer adds its own level and pan to the Upper's.
    const UpperLayer* ul = layerOf(upper, v.soundIndex);
    const auto& drum=liveKeyOf(upper,v.key);
    const float zonePan=drum.pan?std::clamp(v.zone->pan+static_cast<float>(drum.pan)*.01F,-1.0F,1.0F):v.zone->pan;
    const float sourcePan=v.sourceOscillator.support.pan?v.sourceOscillator.pan:0.0F;
    const float intrinsicPan=zonePan+v.layer->pan+sourcePan+(ul!=nullptr?ul->pan:0.0F);
    const auto steerPan=[](float intrinsic,float offset) noexcept {
        const float source=std::clamp(intrinsic,-1.0F,1.0F);
        return source+offset*(offset>0.0F?1.0F-source:1.0F+source);
    };
    float savedPan=intrinsicPan;
    // Keep the legacy summation order when no saved source steering is active.
    float panIn=zonePan+v.layer->pan+sourcePan+upper.pan+extraPan+(ul!=nullptr?ul->pan:0.0F);
    if(upper.sourcePanRaw>=0){
        const int raw=std::clamp(upper.sourcePanRaw,0,127);
        const float offset=raw<=1?-1.0F:static_cast<float>(raw-64)/63.0F;
        if(offset!=0.0F){savedPan=steerPan(intrinsicPan,offset);panIn=savedPan+upper.pan+extraPan;}
    }
    if(channelPan!=0.0F){
        // Pa5X Amp Level/Pan: CC10=64 retains the oscillator's position;
        // CC10=0/1 and127 reach the respective stereo edge. Adding the CC
        // offset could leave an oppositely panned source at center instead.
        // Interpolate toward the requested edge; this does not calibrate the
        // original DSP's intermediate pan/gain transfer law.
        const float positioned=steerPan(savedPan,channelPan);
        // The host's white Pan Trim and live modulation are independent user
        // corrections, applied after the source channel's saved panorama.
        panIn=positioned+upper.pan+extraPan;
    }
    const float levelIn = upper.levelDb + (ul != nullptr ? ul->levelDb : 0.0F) + static_cast<float>(drum.gainDb);
    // Use the same normalized CC gain as live channel mixing. Exact Korg
    // intermediate fader/pan transfer curves remain uncalibrated.
    const auto savedLevel=[](int raw) noexcept {return raw<0?1.0F:static_cast<float>(std::clamp(raw,0,127))*kInv127;};
    const float sourceGain=savedLevel(upper.sourceVolumeRaw)*savedLevel(upper.sourceExpressionRaw);
    if (panIn == v.mixPanIn && levelIn == v.mixLevelIn && sourceGain == v.mixSourceGainIn && audible == v.mixAudibleIn) return;
    v.mixPanIn = panIn;
    v.mixLevelIn = levelIn;
    v.mixSourceGainIn = sourceGain;
    v.mixAudibleIn = audible;
    if (!audible) { v.mixTargetL = v.mixTargetR = 0.0F; return; }
    const float pan = std::clamp(panIn, -1.0F, 1.0F);
    const float angle = (pan + 1.0F) * static_cast<float>(kPi * 0.25);
    const float level = dbToGain(levelIn)*sourceGain;
    v.mixTargetL = level * std::cos(angle);
    v.mixTargetR = level * std::sin(angle);
}

// SILVETON_TONE_V2: SAMPLE START in frames of the sample, moved forward to the
// next zero crossing (within 4 ms) so the note never starts with a click.
// Frame at or after `start` where the recording crosses zero (within 4 ms).
double snapToZeroCrossing(const SampleData& s, double start) noexcept {
    const auto pre = s.preloadedFrameCount();
    const auto ch = static_cast<std::size_t>(std::max<std::uint16_t>(1U, s.channels));
    auto i = static_cast<std::uint64_t>(std::max(0.0, start));
    const std::uint64_t limit = std::min<std::uint64_t>(pre, i + static_cast<std::uint64_t>(0.004 * s.sampleRate) + 1U);
    if (i + 1U < limit) {
        float prev = s.interleaved[static_cast<std::size_t>(i) * ch];
        for (std::uint64_t k = i + 1U; k < limit; ++k) {
            const float cur = s.interleaved[static_cast<std::size_t>(k) * ch];
            if ((prev <= 0.0F && cur >= 0.0F) || (prev >= 0.0F && cur <= 0.0F)) { i = k; break; }
            prev = cur;
        }
    }
    return static_cast<double>(i);
}

// SILVETON_XFADE_PORTA_V1: where a recording starts when it takes over a held
// line (legato / portamento): past its attack - at the loop start if it has
// one, else 40 ms in - so the new note is not struck again.
double legatoStartFrame(const SampleData& s) noexcept {
    const double frames = static_cast<double>(s.frameCount());
    if (s.loop.enabled && s.loop.endFrame > s.loop.startFrame && s.loop.startFrame > 0U &&
        static_cast<double>(s.loop.startFrame) < frames - 8.0) {
        return snapToZeroCrossing(s, static_cast<double>(s.loop.startFrame));
    }
    const double skip = 0.040 * static_cast<double>(s.sampleRate);
    if (frames > skip * 3.0) return snapToZeroCrossing(s, skip);
    return 0.0;
}

double startFrameFor(const SampleData& s, float startMs) noexcept {
    if (startMs <= 0.0F) return 0.0;
    const double frames = static_cast<double>(s.frameCount());
    double start = std::clamp(static_cast<double>(startMs), 0.0, static_cast<double>(kToneMaxStartMs)) * 0.001 * static_cast<double>(s.sampleRate);
    if (start >= frames - 8.0) return 0.0;
    const auto pre = s.preloadedFrameCount();
    const auto ch = static_cast<std::size_t>(std::max<std::uint16_t>(1U, s.channels));
    auto i = static_cast<std::uint64_t>(start);
    const std::uint64_t limit = std::min<std::uint64_t>(pre, i + static_cast<std::uint64_t>(0.004 * s.sampleRate) + 1U);
    if (i + 1U < limit) {
        float prev = s.interleaved[static_cast<std::size_t>(i) * ch];
        for (std::uint64_t k = i + 1U; k < limit; ++k) {
            const float cur = s.interleaved[static_cast<std::size_t>(k) * ch];
            if ((prev <= 0.0F && cur >= 0.0F) || (prev >= 0.0F && cur <= 0.0F)) { i = k; break; }
            prev = cur;
        }
    }
    return static_cast<double>(i);
}

// MIDI controls for the single SOLO source.
solo::Inputs soloInputsOf(const SamplerEngine::Impl& impl, const SamplerEngine::Impl::Voice& v) noexcept {
    const auto& ch=impl.channels[v.channel & 0x0FU];
    solo::Inputs in;
    in.key=v.key; in.gate=v.keyHeld||v.sustained; in.velocity=v.velNorm;
    if(v.upper&&v.ownerState)in.registerKey=playKeyFor(*v.upper,v.ownerState->global,v.key,layerOf(*v.upper,v.soundIndex));
    in.wheel=ch.cc[1];
    in.pressure=impl.aftertouchInputEnabled&&v.upper&&v.upper->aftertouchEnabled?ch.pressure:0.0F;
    in.breath=ch.breath;in.expression=ch.expression;
    if(v.upper){const auto& src=soundSource(*v.upper,v.soundIndex);in.model=src.soloModel.get();in.commonProcessing=src.commonProcessing;}
    in.articulation=v.soloGesture;if(in.model)in.velocity=static_cast<float>(v.velocity)*kInv127;
    return in;
}

void startSoloVoice(SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& v, const UpperPart& upper) noexcept {
    v.sampleEnded=true;
    const auto& src=soundSource(upper,v.soundIndex);
    if (!src.engine.on()) return;
    for (auto& candidate: impl.soloPool) {
        bool used=false;
        for (const auto& o:impl.voices) if (o.active && o.so==&candidate) {used=true;break;}
        if (!used) {v.so=&candidate; break;}
    }
    if (v.so) v.so->noteOn(src.engine.p.data(),impl.sampleRate,soloInputsOf(impl,v),impl.noiseState ^ (v.key*7919U));
}

// The note starts: a voice from the pool (the place's limit of notes and the global limit are kept: the oldest note fades out).


// SILVETON_SYNTH_V1: what the player does to the note (velocity, key, gate, wheel, pressure) for the calculated note of SILVETON SYNTH.


// the zone of the chosen model that plays this key (nullptr = no model / no file / NONE); `key` is the key as played


// SILVETON_MODEL_NOTE_V1: the note the model works on is the one that SOUNDS - the pressed key moved by the place's OCTAVE and
// TRANSPOSE (and the global one) - not the pressed key itself; otherwise OCTAVE -1 took the zone and the levelling of an octave above


// SILVETON_SYNTH_V1: the calculated note (16 a place, 32 in all, the oldest gives way)


void bindSourceLfo(SamplerEngine::Impl& impl,SamplerEngine::Impl::Voice& voice) noexcept {
    voice.sourceLfoSlot=-1;
    const auto* profile=voice.sourceOscillator.source;
    if(profile==nullptr)return;
    std::array<bool,2> shared{};
    for(unsigned i=0U;i<2U;++i)shared[i]=voice.sourceOscillator.support.lfo[i]&&(profile->lfoRaw[10U*i]&128U)==0U;
    if(!shared[0]&&!shared[1])return;
    const auto* program=playProgramOf(*voice.upper,voice.soundIndex);
    std::array<bool,kMaxVoices+SamplerEngine::kTakeoverTailVoices> used{};
    for(const auto& other:impl.voices)if(&other!=&voice&&other.active&&other.sourceLfoSlot>=0){
        const auto slot=static_cast<std::size_t>(other.sourceLfoSlot);used[slot]=true;
        const auto& state=impl.sourceLfoSlots[slot];
        if(state.program==program&&state.generation==voice.sourcePerformanceGeneration&&state.upper==voice.upperIndex&&
            state.sound==voice.soundIndex&&state.channel==voice.channel&&state.oscillator==profile->oscillatorIndex&&
            state.profile!=nullptr&&state.profile->lfoRaw==profile->lfoRaw&&state.shared==shared){
            voice.sourceLfoSlot=other.sourceLfoSlot;return;
        }
    }
    for(std::size_t i=0U;i<used.size();++i)if(!used[i]){
        auto& slot=impl.sourceLfoSlots[i];slot=SamplerEngine::Impl::SourceSharedLfo{};
        slot.program=program;slot.profile=profile;slot.generation=voice.sourcePerformanceGeneration;
        slot.upper=voice.upperIndex;slot.sound=voice.soundIndex;slot.channel=voice.channel;
        slot.oscillator=profile->oscillatorIndex;slot.key=voice.sourceKey;slot.velocity=voice.sourceVelocity;
        slot.velocityPosition=voice.sourceVelocityPosition;
        slot.shared=shared;slot.lfo=voice.sourceOscillator.lfo;slot.initialDelay=voice.delayFramesRemaining;
        voice.sourceLfoSlot=static_cast<int>(i);return;
    }
}

void prepareSourceLfos(SamplerEngine::Impl& impl,const GlobalState& global,std::uint32_t frames) noexcept {
    // Shared oscillators are advanced on the audio coordinator before workers
    // start. Workers only read these fixed buffers: no shared mutable DSP.
    std::array<const SamplerEngine::Impl::Voice*,kMaxVoices+SamplerEngine::kTakeoverTailVoices> owners{};
    for(const auto& voice:impl.voices)if(voice.active&&voice.sourceLfoSlot>=0){
        auto& owner=owners[static_cast<std::size_t>(voice.sourceLfoSlot)];
        if(owner==nullptr||voice.age<owner->age)owner=&voice;
    }
    for(std::size_t si=0U;si<owners.size();++si){
        const auto* owner=owners[si];if(owner==nullptr)continue;
        auto& slot=impl.sourceLfoSlots[si];
        auto context=sourceContext(impl,*owner,global);context.key=slot.key;context.velocity=slot.velocity;
        context.velocityPosition=slot.velocityPosition;
        auto inputs=sourceModulationValues(context);
        for(std::uint32_t frame=0U;frame<frames;++frame){
            if(slot.initialDelay>0U){--slot.initialDelay;for(auto& output:slot.output)output[frame]=0.0F;continue;}
            if(slot.controlCountdown==0U){
                slot.controlCountdown=kSourceControlStride;
                for(unsigned l=0U;l<2U;++l)if(slot.shared[l])
                    slot.lfo[l].configure(slot.profile->lfoRaw.data()+10U*l,inputs,owner->sourceEdits,owner->sourceTempoBpm,impl.sampleRate);
            }
            --slot.controlCountdown;
            for(unsigned l=0U;l<2U;++l){
                slot.output[l][frame]=slot.shared[l]?slot.lfo[l].process(impl.sampleRate):0.0F;
                if(slot.shared[l])inputs.value[4U+l]=slot.output[l][frame];
            }
        }
    }
}

void startVoice(SamplerEngine::Impl& impl,
                 SamplerEngine::Impl::Voice& v,
                 const UpperPart& upper,
                 const ProgramLayer& layer,
                 const SampleZone& zone,
                 int upperIndex,
                 std::uint8_t channel,
                 std::uint8_t key,
                 std::uint8_t velocity,
                 const GlobalState& global,
                 const std::shared_ptr<const EngineState>& ownerState,
                 int soundIndex = 0,
                 bool legatoStart = false,
                 int unisonIndex = 0, std::uint64_t attackGroup = 0) noexcept {
    v = SamplerEngine::Impl::Voice{};
    v.active = true;
    v.keyHeld = true;
    v.sustained = false;
    v.age = ++impl.voiceAge;
    v.attackGroup = attackGroup ? attackGroup : v.age;
    v.channel = channel;
    v.midiVolumeNow = impl.channels[channel & 15U].midiVolume;
    v.key = key;
    v.velocity = velocity;
    v.upperIndex = upperIndex;
    v.soundIndex = soundIndex;
    v.routeMask = impl.upperRouteMask[static_cast<std::size_t>(std::clamp(upperIndex, 0, kPartCount - 1))];
    v.sample = zone.sample;
    v.ownerState = ownerState;
    v.layer = &layer;
    v.zone = &zone;
    v.upper = &upper;
    const UpperLayer* ul = layerOf(upper, soundIndex);
    v.sourceKey=playKeyFor(upper,global,key,ul);
    v.sourcePerformanceGeneration=impl.sourcePerformanceGeneration;
    captureSourceControls(impl,v);
    if(const auto* program=playProgramOf(upper,soundIndex);program&&program->drumKeyGroups){
        v.drumProgram=program;v.drumKey=playKeyFor(upper,global,key,ul);
    }
    const SoundTone tone = soundToneOf(upper, soundIndex);
    v.position = zone.reverse && zone.sample != nullptr ? static_cast<double>(zone.sample->frameCount() - 1U) : 0.0;
    v.loopWrapped = false;
    // SILVETON_TONE_V2: SAMPLE START / END
    if (!zone.reverse && zone.sample != nullptr) {
        const auto& s = *zone.sample;
        // SILVETON_OFS_V1: the OFS of this zone's velocity layer, else START
        float startMs = tone.x.startMs;
        bool anyZone = false;
        for (const float z : tone.x.zoneStartMs) anyZone = anyZone || z >= 0.0F;
        if (const Program* prog = anyZone ? soundProgramOf(upper, soundIndex) : nullptr; prog != nullptr) {
            const float z = tone.x.zoneStartMs[static_cast<std::size_t>(velocityZoneIndex(*prog, layer, zone))];
            if (z >= 0.0F) startMs = z;
        }
        v.position = startFrameFor(s, startMs);
        if (legatoStart && startMs <= 0.0F) v.position = legatoStartFrame(s);   // SILVETON_XFADE_PORTA_V1
        if (s.loop.enabled && v.position >= static_cast<double>(s.loop.endFrame) && s.loop.endFrame > s.loop.startFrame) {
            v.position = static_cast<double>(s.loop.startFrame);
        }
        if (tone.x.endMs > 0.0F) {
            const double end = static_cast<double>(tone.x.endMs) * 0.001 * static_cast<double>(s.sampleRate);
            if (end > v.position + 16.0 && end < static_cast<double>(s.frameCount())) {
                v.endFrame = end;
                if (s.loop.enabled && end < static_cast<double>(s.loop.endFrame)) v.loopOff = true;
            }
        }
    }

    v.ratio = noteRatio(impl, upper, layer, zone, key, global, upperIndex, ul);
    v.targetRatio = v.ratio;
    v.pitchGliding = false;
    v.glideFramesRemaining = 0U;
    v.glideRawSemis = v.glideSmooth1 = v.glideSmooth2 = 0.0;
    v.glideLastStep = v.glideStartVelocity = 0.0;

    // SILVETON_VELOCITY_V1: this sound's own curve / compress; the default shape returns the strength unchanged (the same bits)
    const VelocityShape& shape = ul != nullptr ? ul->velocityShape : upper.velocityShape;
    const float velocityNorm = std::max(0.0F, velocityShaped(shape, static_cast<float>(velocity) * kInv127));
    v.velNorm = velocityNorm;
    float velGain = velocityNorm;
    switch (global.velocityCurve) {
        case 1U: velGain = std::sqrt(velocityNorm); break;
        case 2U: velGain = velocityNorm * velocityNorm; break;
        case 3U: velGain = 1.0F; break;
        default: break;
    }
    // The original OSC range is retained before High/Low multisample splitting.
    // Map its received velocity for Sound DSP/AMS only. Zone selection, fades,
    // note identity and native manual modulation keep the received MIDI byte.
    const auto* velocitySource=(soundSource(upper,soundIndex).engine.type!=EngineType::Solo||
        soundSource(upper,soundIndex).commonProcessing)?layer.sourceOscillatorDsp.get():nullptr;
    const float sourceVelocity=sourceScaledVelocity(velocitySource,velocity);
    v.sourceVelocity=static_cast<std::uint8_t>(std::floor(sourceVelocity+.5F));
    v.sourceVelocityPosition=velGain;
    const bool scaledSource=velocitySource!=nullptr&&sourceScaledVelocitySupported(*velocitySource);
    if(scaledSource&&sourceVelocity!=static_cast<float>(velocity)){
        const float shaped=std::max(0.0F,velocityShaped(shape,sourceVelocity*kInv127));
        switch(global.velocityCurve){
            case 1U:v.sourceVelocityPosition=std::sqrt(shaped);break;
            case 2U:v.sourceVelocityPosition=shaped*shaped;break;
            case 3U:v.sourceVelocityPosition=1.0F;break;
            default:v.sourceVelocityPosition=shaped;break;
        }
    }
    float sourceFallbackVelocityGain=1.0F+(v.sourceVelocityPosition-1.0F)*std::clamp(tone.x.velToLevel,0.0F,1.0F);
    // SILVETON_TONE_V2: VEL->LEVEL (1 = as before, 0 = every velocity the same level)
    velGain = 1.0F + (velGain - 1.0F) * std::clamp(tone.x.velToLevel, 0.0F, 1.0F);
    v.velCutoffOct = -std::clamp(tone.x.velToCutoff, 0.0F, 8.0F) * (1.0F - velocityNorm);
    v.filterEnvValue = 1.0F;
    // SILVETON_POLYSIX_V1: unison copy, sub position, PWM period, per-note random
    {
        const int n = std::clamp<int>(tone.x.unisonVoices, 1, 4);
        v.unisonIndex = unisonIndex;
        if (n > 1) {
            const float t = (static_cast<float>(unisonIndex) - 0.5F * static_cast<float>(n - 1)) / (0.5F * static_cast<float>(n - 1));   // -1..1
            v.unisonCents = t * std::clamp(tone.x.unisonDetuneCents, 0.0F, 100.0F);
            v.unisonPan = t * std::clamp(tone.x.unisonSpread, 0.0F, 1.0F);
            v.unisonGain = 1.0F / std::sqrt(static_cast<float>(n));
        }
        v.subPosition = v.position;
        v.periodFrames = 0.0;
        if (zone.sample != nullptr) {
            const double rootHz = 440.0 * std::pow(2.0, (static_cast<double>(zone.rootKey) - 69.0) / 12.0) *
                                  std::pow(2.0, -static_cast<double>(zone.tuneCents + zone.sample->fineTuneCents) / 1200.0);
            v.periodFrames = static_cast<double>(zone.sample->sampleRate) / std::max(1.0, rootHz);
        }
        // SILVETON_TRANSWAVE_V1: a sound with a wave table plays that instead of its recording
        if (tone.x.waveMode != 0 && v.periodFrames > 0.0 && impl.waveMap != nullptr) {
            const std::uint64_t wk = waveKey(zone, tone.x);
            if (wk != 0U) {
                const auto it = impl.waveMap->find(wk);
                if (it != impl.waveMap->end()) {
                    v.waveTable = it->second;
                    v.ownerWaveMap = impl.waveMap;
                }
            }
        }
        impl.noiseState = impl.noiseState * 1664525U + 1013904223U;
        v.random = static_cast<float>(impl.noiseState >> 8) / 8388608.0F - 1.0F;
        if (tone.x.analogFeel) { v.unisonCents += v.random * 3.0F; }   // a few cents, like a real analog
    }
    if(soundSource(upper,soundIndex).engine.type!=EngineType::Solo||soundSource(upper,soundIndex).commonProcessing)
        v.sourceOscillator.prepare(layer.sourceOscillatorDsp.get(),impl.noiseState,v.random);
    // SILVETON_ENGINES_V1: the per-note part of the Upper's ENGINE starts with the note
    if (soundSource(upper,soundIndex).engine.type == EngineType::Solo) {
        v.soloIncrement=440.0*std::exp2((static_cast<double>(key)-69.0)/12.0)/impl.sampleRate;
        startSoloVoice(impl,v,upper);
    }
    float layerVelocityGain = 1.0F;
    if (layer.velocityFadeIn > 0U) {
        const int fadeEnd = static_cast<int>(layer.velocityLow) + static_cast<int>(layer.velocityFadeIn);
        if (static_cast<int>(velocity) < fadeEnd) {
            layerVelocityGain *= std::clamp(
                static_cast<float>(static_cast<int>(velocity) - static_cast<int>(layer.velocityLow)) / static_cast<float>(layer.velocityFadeIn),
                0.0F, 1.0F);
        }
    }
    if (layer.velocityFadeOut > 0U) {
        const int fadeStart = static_cast<int>(layer.velocityHigh) - static_cast<int>(layer.velocityFadeOut);
        if (static_cast<int>(velocity) > fadeStart) {
            layerVelocityGain *= std::clamp(
                static_cast<float>(static_cast<int>(layer.velocityHigh) - static_cast<int>(velocity)) / static_cast<float>(layer.velocityFadeOut),
                0.0F, 1.0F);
        }
    }
    // COMBI layer velocity response is independent from the samples' own
    // ProgramLayer crossfades. Default 0/0/1 is bit-identical to old playback.
    const auto* activeSound = ul;
    const auto lo = activeSound ? activeSound->velocityLow : upper.velocityLow;
    const auto hi = activeSound ? activeSound->velocityHigh : upper.velocityHigh;
    const auto fadeIn = activeSound ? activeSound->velocityFadeIn : upper.velocityFadeIn;
    const auto fadeOut = activeSound ? activeSound->velocityFadeOut : upper.velocityFadeOut;
    const float response = activeSound ? activeSound->velocityResponse : upper.velocityResponse;
    // SILVETON_VELOCITY_FADE_NO_HOLE_V1 (Цветомир, 27.10.2026, "на 90 няма звук"): FADE IN / FADE OUT are the crossfade with a
    // NEIGHBOUR sound of the Upper. Where no other sound of this Upper plays this key at this strength there is nothing to cross
    // into, so the fade is left out and the sound plays at full strength - before, L2 66–90 with FADE OUT 8 was nearly silent at 90
    // while L3 only started at 91 (a hole at the border of two ranges that do not overlap).
    if (fadeIn != 0U || fadeOut != 0U) {
        bool otherSoundPlays = false;
        for (int s = 0; s < kSoundsPerUpper && !otherSoundPlays; ++s) {
            const UpperLayer* sl = layerOf(upper, s);
            if (sl == ul) continue;   // this sound itself (ОСНОВЕН: both nullptr)
            if (playProgramOf(upper, s) == nullptr) continue;
            if (sl != nullptr) otherSoundPlays = sl->matches(key, velocity);
            else otherSoundPlays = !upper.independentLayerRanges ||
                                   (key >= upper.keyLow && key <= upper.keyHigh && velocity >= upper.velocityLow && velocity <= upper.velocityHigh);
        }
        if (otherSoundPlays) {
            if (fadeIn != 0U) layerVelocityGain *= std::clamp((static_cast<float>(velocity) - static_cast<float>(lo) + 1.0F) / static_cast<float>(fadeIn), 0.0F, 1.0F);
            if (fadeOut != 0U) layerVelocityGain *= std::clamp((static_cast<float>(hi) - static_cast<float>(velocity) + 1.0F) / static_cast<float>(fadeOut), 0.0F, 1.0F);
        }
    }
    if (std::abs(response - 1.0F) > 0.0001F) {
        velGain=std::pow(std::clamp(velGain,0.0F,1.0F),std::clamp(response,0.25F,4.0F));
        sourceFallbackVelocityGain=std::pow(std::clamp(sourceFallbackVelocityGain,0.0F,1.0F),std::clamp(response,0.25F,4.0F));
    }
    // SILVETON_VELOCITY_V1: CROSSFADE - the sounds of this Upper that have it on (and play this key at this strength) never add up above 1.
    // A sound that plays alone keeps its fade as set; only an overlap that would be louder than 1 together is brought back to 1.
    if (shape.crossfade) {
        float sum = 0.0F;
        for (int s = 0; s < kSoundsPerUpper; ++s) {
            const UpperLayer* sl = layerOf(upper, s);
            const VelocityShape& ss = sl != nullptr ? sl->velocityShape : upper.velocityShape;
            if (!ss.crossfade || playProgramOf(upper, s) == nullptr) continue;
            if (sl != nullptr && !sl->matches(key, velocity)) continue;
            if (sl == nullptr && upper.independentLayerRanges && (key < upper.keyLow || key > upper.keyHigh || velocity < upper.velocityLow || velocity > upper.velocityHigh)) continue;
            sum += sl != nullptr ? velocityFadeGain(sl->velocityLow, sl->velocityHigh, sl->velocityFadeIn, sl->velocityFadeOut, velocity)
                                 : velocityFadeGain(upper.velocityLow, upper.velocityHigh, upper.velocityFadeIn, upper.velocityFadeOut, velocity);
        }
        if (sum > 1.0F) layerVelocityGain /= sum;
    }
    if(std::abs(response-1.0F)>.0001F)v.sourceVelocityPosition=std::pow(std::clamp(v.sourceVelocityPosition,0.0F,1.0F),std::clamp(response,.25F,4.0F));
    v.baseGain = dbToGain(zone.gainDb + layer.levelDb) * ((soundSource(upper,soundIndex).soloModel && !soundSource(upper,soundIndex).commonProcessing)||v.sourceOscillator.support.amplitude ? 1.F : (scaledSource?sourceFallbackVelocityGain:velGain)) * layerVelocityGain;
    v.mixPanIn = std::numeric_limits<float>::quiet_NaN();
    const float initialChannelPan = impl.channelMixEnabled.load(std::memory_order_acquire)
        ? impl.channels[channel & 15U].midiPan : 0.0F;
    updateMixTarget(v, upper, impl.listensTo(upperIndex,key)&&(impl.listenPart==upperIndex||upperAudible(*ownerState,upper)), 0.0F, initialChannelPan);
    v.mixL = v.mixTargetL;
    v.mixR = v.mixTargetR;
    v.tuneSemis = liveTuneSemis(upper, global, key, ((impl.scaleUppers.load(std::memory_order_relaxed) >> upperIndex) & 1) != 0, ul,!zone.nonTranspose) + static_cast<double>(v.unisonCents) / 100.0;
    v.ratio *= std::exp2(static_cast<double>(v.unisonCents) / 1200.0);
    v.targetRatio = v.ratio;
    v.filterEnv.params = layer.filterEnvelope;
    v.pitchEnv.params = layer.pitchEnvelope;
    v.ampEnv = AmpEnv{};
    if(v.so==nullptr||soundSource(upper,soundIndex).commonProcessing)
        v.ampEnv.useSource(layer.sourceAmpEnvelope,playKeyFor(upper,global,key,ul),v.sourceVelocity);
    refreshSourceAmp(impl,v,global);
    v.sourceOscillator.start(sourceContext(impl,v,global),v.sourceEdits,impl.sampleRate);
    v.sampleDecay = {};
    v.sampleDecay.position = v.sampleDecay.value = layer.sampleDecay.start;
    UpperToneValues tv0 = voiceTone(v,tone,upper);
    v.curveBlend=v.editCurve?1.0F:0.0F;
    if(layer.sampleDecay.enabled())v.curvePeak=std::max({layer.sampleDecay.start,layer.sampleDecay.targets[0],layer.sampleDecay.targets[1]});
    if (shape.toAttack > 0.0F) tv0.attackMs = std::min(tv0.attackMs + velocityAttackExtraMs(shape, velocityNorm), kToneMaxTimeMs);   // SILVETON_VELOCITY_V1
    v.ampEnv.setBlock(tv0, impl.sampleRate);
    // SILVETON_TONE_V2: the note starts AT its CUTOFF (before, the filter opened
    // from 20 kHz for the first ~30 ms of every note); FILTER ENV / VEL->CUTOFF too.
    {
        const float envOct = std::clamp(tone.x.filterEnvOctaves, -8.0F, 8.0F) + v.velCutoffOct;
        const bool wantOn = tv0.cutoffHz < kToneCutoffOpenHz - 1.0F || envOct < -0.001F;
        if (wantOn) {
            v.toneOn = true;
            v.toneLog = std::log(tv0.cutoffHz);
            v.toneLp.prime = true;
            v.toneLp.set(std::clamp(std::exp(v.toneLog + envOct * 0.69314718F), 20.0F, kToneCutoffOpenHz), tv0.resonance, impl.sampleRate);
        }
    }
    v.ampEnv.trigger(); v.filterEnv.trigger(); v.pitchEnv.trigger();
    v.lfo1.reset(layer.lfo1.keySync); v.lfo2.reset(layer.lfo2.keySync);
    v.delayFramesRemaining = static_cast<std::uint32_t>(std::clamp(
        static_cast<double>(layer.delaySec) * impl.sampleRate, 0.0, static_cast<double>(std::numeric_limits<std::uint32_t>::max())));
    bindSourceLfo(impl,v);
    v.filter.reset();
}

float calibratedController(std::uint8_t value, float minValue, float maxValue, float curve) noexcept {
    const float x = static_cast<float>(value) * kInv127;
    const float lo = std::clamp(minValue, 0.0F, 1.0F);
    const float hi = std::clamp(maxValue, lo + 0.0001F, 1.0F);
    const float normalized = std::clamp((x - lo) / (hi - lo), 0.0F, 1.0F);
    return std::pow(normalized, std::clamp(curve, 0.1F, 8.0F));
}

float routeSourceValue(const UpperControllerRoute& route, const SamplerEngine::Impl::ChannelState& ch) noexcept {
    float value = 0.0F;
    bool inherentlyBipolar = false;
    switch (route.source) {
        case ControllerSource::Off: return 0.0F;
        case ControllerSource::Breath: value = ch.breath; break;
        case ControllerSource::Expression: value = ch.expression; break;
        case ControllerSource::Aftertouch: value = ch.pressure; break;
        case ControllerSource::JoystickX:
            value = std::clamp(static_cast<float>(ch.pitchBend) / 8192.0F, -1.0F, 1.0F);
            inherentlyBipolar = true;
            break;
        case ControllerSource::JoystickY:
        case ControllerSource::ControlChange:
            value = ch.cc[static_cast<std::size_t>(route.cc & 0x7FU)];
            break;
    }
    if (route.bipolar && !inherentlyBipolar) value = value * 2.0F - 1.0F;
    return std::clamp(value, -1.0F, 1.0F);
}

float controllerAmount(const UpperPart& upper, const SamplerEngine::Impl::ChannelState& ch,
                       ModDestination destination, bool aftertouchInputEnabled) noexcept {
    float sum = 0.0F;
    for (const auto& route : upper.controllerRoutes) {
        if (route.source == ControllerSource::Off || route.destination != destination || !std::isfinite(route.amount)) continue;
        // Global and part switches disable the assigned source, including bipolar
        // routes whose zero input would otherwise become a negative offset.
        if (route.source == ControllerSource::Aftertouch && (!upper.aftertouchEnabled || !aftertouchInputEnabled)) continue;
        sum += routeSourceValue(route, ch) * route.amount;
    }
    return sum;
}

void releaseOne(SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& v, bool sustainDown) noexcept {
    if (!v.keyHeld) return;
    v.keyHeld = false;
    if (v.zone != nullptr && v.oneShot) return;
    if (sustainDown && v.upper != nullptr && v.upper->damperEnabled && v.layer != nullptr && v.layer->damperEnabled) {
        v.sustained = true;
    } else {
        prepareSourceRelease(impl,v);
        v.ampEnv.release(impl.sampleRate);
        v.filterEnv.release(impl.sampleRate);
        v.pitchEnv.release(impl.sampleRate);
    }
}

bool samePerformance(const SamplerEngine::Impl::Voice& voice,const EngineState& state) noexcept {
    return voice.ownerState&&voice.ownerState->combiGeneration==state.combiGeneration;
}

// handledUppers covers only the current performance's mono stacks. Notes held
// across recall still receive their own physical NoteOff and sustain release.
void releaseMatching(SamplerEngine::Impl& impl, std::uint8_t channel, std::uint8_t key,
                     std::uint16_t handledUppers,const EngineState& state,unsigned parts=static_cast<unsigned>((1U<<kPartCount)-1U)) noexcept {
    const bool sustain = impl.channels[channel].sustain;
    for (auto& v : impl.voices) {
        if (!v.active || v.channel != channel) continue;
        if (v.key != key) continue;
        if(v.upperIndex<0||v.upperIndex>=kPartCount||!(parts&(1U<<v.upperIndex)))continue;
        if (samePerformance(v,state) && v.upperIndex >= 0 && v.upperIndex < kPartCount &&
            ((handledUppers >> static_cast<unsigned>(v.upperIndex)) & 1U) != 0U) continue;
        releaseOne(impl, v, sustain);
    }
}

void releaseUpperVoices(SamplerEngine::Impl& impl, int ui, std::uint8_t channel,const EngineState& state) noexcept {
    const bool sustain = impl.channels[channel].sustain;
    for (auto& v : impl.voices) {
        if (v.active && !v.fading && v.upperIndex == ui && v.keyHeld && samePerformance(v,state)) releaseOne(impl, v, sustain);
    }
}

void releasePedalVoice(SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& v) noexcept {
    v.sustained = false;
    prepareSourceRelease(impl,v);
    v.ampEnv.release(impl.sampleRate);
    v.filterEnv.release(impl.sampleRate);
    v.pitchEnv.release(impl.sampleRate);
}

void releaseSustained(SamplerEngine::Impl& impl, std::uint8_t channel) noexcept {
    for (auto& v : impl.voices) {
        if (v.active && v.channel == channel && v.sustained && !v.keyHeld) releasePedalVoice(impl,v);
    }
}

void clearPolyKeys(SamplerEngine::Impl& impl, std::size_t ui) noexcept {
    impl.polyKeys[ui] = SamplerEngine::Impl::PolyKeys{};
    impl.polyAnchorKey[ui] = -1;
    // Keep polyLastKey: KRONOS without FINGERED remembers its previous note.
}

void panic(SamplerEngine::Impl& impl) noexcept {
    impl.lowerPhysical={};impl.lowerDeferred={};
    for (auto& v : impl.voices) {
        v.ampEnv.forceOff(); v.filterEnv.forceOff(); v.pitchEnv.forceOff(); v.active = false;
    }
    for (auto& c : impl.channels) c = SamplerEngine::Impl::ChannelState{};
    for (auto& m : impl.mono) m = SamplerEngine::Impl::MonoKeys{};
    for (auto& row : impl.takeoverResidual) for (auto& residual : row) residual = SamplerEngine::Impl::TakeoverResidual{};
    for (std::size_t ui = 0U; ui < impl.polyKeys.size(); ++ui) clearPolyKeys(impl, ui);
}

constexpr float kLegatoCrossfadeSec = 0.030F; // equal-power, only between two different recordings

void monoRemoveAt(SamplerEngine::Impl::MonoKeys& m, std::size_t index) noexcept {
    for (std::size_t i = index + 1U; i < m.count; ++i) { m.key[i - 1U] = m.key[i]; m.vel[i - 1U] = m.vel[i]; }
    if (m.count > 0U) --m.count;
}

std::size_t monoSelected(const SamplerEngine::Impl::MonoKeys& m, const UpperPart& upper) noexcept {
    if (m.count == 0U) return 0U;
    std::size_t best = m.count - 1U;
    int priority = upper.engine.type == EngineType::Solo ? static_cast<int>(std::lround(upper.engine.p[solo::Priority])) : 0;
    if(upper.sourceVoiceInherit&&upper.engine.type!=EngineType::Solo&&upper.program){
        // SOLO's explicit priority keeps precedence. Original Sound priority
        // belongs to the base Program, never to one selected oscillator.
        const auto source=upper.program->sourceVoiceAssignment.priority();
        if(source==SourceNotePriority::Low)priority=2;
        else if(source==SourceNotePriority::High)priority=1;
    }
    for (std::size_t i = 0U; i < m.count; ++i) {
        if ((priority == 1 && m.key[i] > m.key[best]) || (priority == 2 && m.key[i] < m.key[best])) best = i;
    }
    return best;
}

void monoPush(SamplerEngine::Impl::MonoKeys& m, std::uint8_t key, std::uint8_t vel) noexcept {
    for (std::size_t i = 0; i < m.count; ++i) if (m.key[i] == key) { monoRemoveAt(m, i); break; }
    if (m.count >= m.key.size()) monoRemoveAt(m, 0U);
    m.key[m.count] = key; m.vel[m.count] = vel; ++m.count;
}

// SILVETON_PORTA_PAGE_V1 - PORTAMENTO exactly like the SILVETON portamento page
// (Silveton-Portamento-Keys): while portamento is ON an Upper plays one line
// (last key wins, letting it go returns to a key that is still held).
//  * While a key is held the line is ONE continuous sound: a new key, or going
//    back to a held key, is not struck again - the pitch glides from the pitch
//    sounding right now (also part-way through a glide) to the new key in
//    exactly TIME (1..100 ms), evenly in semitones, the same time for every interval.
//  * With no key held the next note is struck normally and does not glide.
//  * The note that already sounds, pressed again, changes nothing.
// (PORTA BALANCE now rounds every glide: see SILVETON_SOFT_GLIDE_V1.)
constexpr float kPortamentoMaxSec = 0.100F;

// SILVETON_BASS_PORTA_V1: INSTRUMENT and BASS glide with the same machinery (fresh recording crossfaded in for an unlooped sample,
// zone of the held line reused). Only these two modes use it - SILVETON and KRONOS are exactly as they were.
inline bool instrumentGlide(const UpperPart& upper) noexcept {
    return upper.portaMode == PortamentoMode::Instrument || upper.portaMode == PortamentoMode::Bass;
}

// SILVETON_PORTA_MODES_V1: KRONOS portamento TIME 0..127 -> seconds (0 = off,
// 127 = 5 s; the lower half of the range is fine, like the instrument).
float kronosPortaSec(std::uint8_t time) noexcept {
    const float t = std::clamp(static_cast<float>(time), 0.0F, 127.0F) / 127.0F;
    return 5.0F * std::pow(t, 2.2F);
}

// SILVETON_MODEL_V1: a SILVETON SYNTH place glides by the place's own portamento (SILVETON / KRONOS / BASS), as every Upper does

float portamentoSecFor(const UpperPart& upper) noexcept {
    if (upper.portaMode == PortamentoMode::Kronos || instrumentGlide(upper)) return kronosPortaSec(upper.portaTime);
    return std::clamp(upper.portamentoSec, 0.0F, kPortamentoMaxSec);
}

float sourceGlideSeconds(const SamplerEngine::Impl& impl,const UpperPart& upper,const ProgramLayer& layer,bool previousKeyHeld,int ui) noexcept {
    // An explicit performance setting wins, including an explicit Off. Saved
    // source flags remain intact so recalling the original setup can inherit.
    if(!upper.sourcePortamentoInherit||portamentoSecFor(upper)>0.0F)return 0.0F;
    const auto edits=sourceEditsFor(upper,impl.channels[upper.midiChannel&15U],impl.keyboardPortamentoOverride[static_cast<std::size_t>(ui)]);
    return sourcePortamentoPlaybackSeconds(layer.sourcePortamento,edits,previousKeyHeld);
}

bool hasSourceGlide(const SamplerEngine::Impl& impl,const UpperPart& upper,int ui) noexcept {
    if(!upper.sourcePortamentoInherit||portamentoSecFor(upper)>0.0F)return false;
    for(int sound=0;sound<kSoundsPerUpper;++sound){
        if(const auto* extra=layerOf(upper,sound);extra&&!extra->enabled)continue;
        const auto* program=playProgramOf(upper,sound);
        if(!program)continue;
        for(const auto& layer:program->layers)
            if(layer.enabled&&sourceGlideSeconds(impl,upper,layer,true,ui)>0.0F)return true;
    }
    return false;
}

// SILVETON_POLY_PORTA_V1: POLY stays POLY with portamento ON (chords keep sounding,
// every new key glides from the key played before it, like Korg Pa).
UpperVoiceMode effectiveVoiceMode(const UpperPart& upper) noexcept {
    if(upper.sourceVoiceInherit&&upper.program&&playProgramOf(upper,0)==upper.program.get()){
        const auto& source=upper.program->sourceVoiceAssignment;
        if(source.present&&source.valid())return source.mono()?
            (source.legato()?UpperVoiceMode::Legato:UpperVoiceMode::Mono):UpperVoiceMode::Poly;
    }
    if (proceduralMono(upper) && !upper.commonProcessing && upper.voiceMode == UpperVoiceMode::Poly) return UpperVoiceMode::Legato;
    return upper.voiceMode;
}

// SILVETON_PORTA_NEAR_V1: far intervals glide in TIME (as before); neighbouring
// keys take longer and softer: 1 semitone = NEAR, 2 = 2/3, 3 = 1/3 of the way.
float glideSecFor(const SamplerEngine::Impl& impl, const UpperPart& upper, double fromKey, double toKey, int ui = -1) noexcept {
    const float base = portamentoSecFor(upper);
    if (base <= 0.0F || fromKey < 0.0) return base;
    // SILVETON_PORTA_SAME_V1: the glide is the same at any playing speed - exactly what
    // the PORTA page says, slow or fast (the earlier tempo shortening is gone).
    (void)ui;
    const auto capped = [](float sec) noexcept { return sec; };
    const double d = std::abs(toKey - fromKey);
    if (instrumentGlide(upper)) {
        // Instrument-specific glide timings: independent from the legacy
        // SILVETON and KRONOS algorithms. No new voices or buffer allocations.
        const float steps=static_cast<float>(std::max(0.0,d));
        float scale=1.0F;
        // BASS portamento always glides like a bass; INSTRUMENT follows its oscillator mode.
        switch(upper.portaMode == PortamentoMode::Bass ? OscillatorMode::Bass : upper.oscillatorMode) {
            case OscillatorMode::Bass: scale=std::clamp(0.72F+steps*0.055F,0.75F,1.30F); break;
            case OscillatorMode::Bowed: scale=std::clamp(0.95F+steps*0.022F,0.85F,1.35F); break;
            case OscillatorMode::Woodwind: scale=std::clamp(0.80F+steps*0.020F,0.70F,1.20F); break;
            case OscillatorMode::Brass: scale=std::clamp(0.88F+steps*0.023F,0.75F,1.35F); break;
            case OscillatorMode::Plucked: scale=std::clamp(0.68F+steps*0.036F,0.70F,1.20F); break;
            case OscillatorMode::Synth: scale=1.0F; break;
            default: scale=1.0F; break;
        }
        if (upper.portaRateMode) scale *= std::max(steps, 1.0F) / 12.0F;
        return std::clamp(base*scale,0.001F,5.0F);
    }
    if (upper.portaMode == PortamentoMode::Kronos) {
        // TIME: one duration for every interval. RATE: duration per octave.
        // A small, bounded near-note floor avoids almost instantaneous jumps
        // when using RATE with one or two semitones. Never extend a very short
        // user TIME setting beyond that setting, and never affect TIME mode.
        if (!upper.portaRateMode) return capped(base);
        const float scaled = base * static_cast<float>(std::max(d, 0.05) / 12.0);
        return capped(std::max(scaled, std::min(base, 0.055F)));
    }
    // SILVETON_PROCESSOR_PORTA_V1: the glide of the SILVETON keyboard processor on the Korg.
    // The processor picks the Korg's rate (CC#5) for every interval so that it lasts TIME;
    // PORTA BALANCE (11 = the player's keyboard) decides how the real time grows with the
    // interval: t(I) = TIME x I^((11 - BALANCE) / 11), bounded. At 11 every interval takes
    // TIME; below 11 a big jump takes longer than a step, above 11 a big jump is quicker.
    const double bal = static_cast<double>(impl.portaBalance.load(std::memory_order_relaxed));
    const double expo = std::clamp((11.0 - bal) / 11.0, -1.0, 1.0);
    const float baseB = std::clamp(static_cast<float>(static_cast<double>(base) * std::pow(std::max(1.0, d), expo)), 0.001F, 10.0F);
    const double w = d <= 1.0 ? 1.0 : (d >= 4.0 ? 0.0 : (4.0 - d) / 3.0);
    const float nearSec = impl.portaNearMs.load(std::memory_order_relaxed) / 1000.0F;
    return capped(nearSec > baseB ? baseB + static_cast<float>(w) * (nearSec - baseB) : baseB);
}

// Mode at this event; a key memory never survives a switch between POLY and MONO.
UpperVoiceMode voiceModeNow(SamplerEngine::Impl& impl, int ui, const UpperPart& upper) noexcept {
    const UpperVoiceMode mode = effectiveVoiceMode(upper);
    const bool mono = mode != UpperVoiceMode::Poly;
    auto& was = impl.monoWas[static_cast<std::size_t>(ui)];
    if (mono != was) {
        impl.mono[static_cast<std::size_t>(ui)] = SamplerEngine::Impl::MonoKeys{};
        clearPolyKeys(impl, static_cast<std::size_t>(ui));
        was = mono;
    }
    return mode;
}

// A live Poly -> Mono edit takes effect before MIDI events in the next block.
// Keep all velocity layers/unison copies of the winning attack together.
void adoptMonoLine(SamplerEngine::Impl& impl, const EngineState& state, int part) noexcept {
    using Voice = SamplerEngine::Impl::Voice;
    const auto& upper = state.combi.part(part);
    const auto index = static_cast<std::size_t>(part);
    auto& keys = impl.mono[index];
    keys = {};
    clearPolyKeys(impl,index);
    impl.monoWas[index] = true;
    std::array<const Voice*,kMaxVoices + SamplerEngine::kTakeoverTailVoices> held;
    std::size_t count = 0;
    const Voice* winner = nullptr;
    for (const auto& voice : impl.voices) {
        if (!voice.active || voice.fading || voice.upperIndex != part || !samePerformance(voice,state)) continue;
        if (voice.keyHeld) held[count++] = &voice;
        else if (!winner || (voice.sustained && !winner->sustained) ||
                 (voice.sustained == winner->sustained && voice.age > winner->age)) winner = &voice;
    }
    if (count) {
        std::sort(held.begin(),held.begin()+count,[](const Voice* a,const Voice* b){return a->age < b->age;});
        for (std::size_t i=0;i<count;++i) monoPush(keys,held[i]->key,held[i]->velocity);
        const auto key = keys.key[monoSelected(keys,upper)];
        for (std::size_t i=count;i>0;--i) if (held[i-1]->key == key) { winner=held[i-1];break; }
    }
    if (!winner) return;
    const auto group = winner->attackGroup;
    for (auto& voice : impl.voices) {
        if (!voice.active || voice.fading || voice.upperIndex != part || !samePerformance(voice,state)) continue;
        if (voice.attackGroup == group) voice.mono = true;
        else softKill(impl,voice);
    }
}

// SILVETON_SOFT_GLIDE_V1 / SILVETON_SILK_PORTA_V1
// The pitch starts at exactly the audible previous pitch, then follows a C2
// eased semitone-space path and reaches its target ON TIME (no lagging low-pass
// tail). When a key interrupts a moving glide, carry its velocity into the new
// path, bounded to keep the result monotonic / free of pitch overshoot.
void beginGlide(SamplerEngine::Impl::Voice& v, double newTargetRatio, std::uint32_t frames) noexcept {
    if (!(newTargetRatio > 0.0) || !std::isfinite(newTargetRatio)) return;
    const double start = v.ratio > 0.0 && std::isfinite(v.ratio)
        ? 12.0 * std::log2(v.ratio / newTargetRatio) : 0.0;
    const auto total = std::max<std::uint32_t>(1U, frames);
    // A reversal of direction brakes at the actual sounding pitch. Otherwise
    // preserve a limited amount of momentum, avoiding the characteristic corner
    // during very fast legato runs.
    const double carried = v.pitchGliding ? v.glideLastStep * static_cast<double>(total) : 0.0;
    const double desiredDirection = -start;
    // KRONOS changes keep the audible slope but never let a fast interruption
    // overshoot the target. SILVETON retains its existing wider momentum bound.
    const double maxCarry = (v.glideKronos ? 0.45 : 2.0) * std::abs(start);
    const double velocity = (carried * desiredDirection > 0.0)
        ? std::copysign(std::min(std::abs(carried), maxCarry), desiredDirection) : 0.0;
    v.glideStartVelocity = velocity;
    v.glideStartSemis = start;
    v.glideRawSemis = v.glideSmooth1 = v.glideSmooth2 = start;
    v.glideTotalFrames = total;
    v.glideFramesRemaining = total;
    v.targetRatio = newTargetRatio;
    v.pitchGliding = true;
    // Do not recalculate ratio here: preserve exactly the currently audible
    // floating-point value until the next generated sample.
}

void startPortamentoGlide(const SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& v, double fromKey, float seconds) noexcept {
    if (seconds <= 0.0F || fromKey < 0.0 || v.ratio <= 0.0) return;
    if (v.zone != nullptr && v.zone->nonTranspose) return; // fixed-pitch sample: nothing to glide
    const double semitones = fromKey - static_cast<double>(v.key);
    if (std::abs(semitones) < 1.0e-6) return;
    v.targetRatio = v.ratio;
    v.glideRawSemis = v.glideSmooth1 = v.glideSmooth2 = semitones;   // starts on the old key
    v.glideLastStep = 0.0; // a newly struck voice has no inherited motion
    v.pitchGliding = true;
    v.ratio = v.targetRatio * std::exp2(semitones / 12.0);
    const auto frames = static_cast<std::uint32_t>(std::max(1.0, static_cast<double>(seconds) * impl.sampleRate));
    beginGlide(v, v.targetRatio, frames);
}

// SILVETON_PHASE_ALIGN_V1: one mono frame of a recording (RAM prefix or streamed part).
float monoFrameAt(const SampleData& s, std::uint64_t k) noexcept {
    const auto ch = static_cast<std::size_t>(std::max<std::uint16_t>(1U, s.channels));
    if (k < s.preloadedFrameCount()) {
        const float* p = &s.interleaved[static_cast<std::size_t>(k) * ch];
        return ch >= 2U ? 0.5F * (p[0] + p[1]) : p[0];
    }
    if (s.stream != nullptr && k < s.stream->frameCount()) {
        return ch >= 2U ? 0.5F * (s.stream->readFrame(k, 0U) + s.stream->readFrame(k, 1U)) : s.stream->readFrame(k, 0U);
    }
    return 0.0F;
}

// SILVETON_PHASE_ALIGN_V1: when another recording takes over a held line, its start is
// moved by up to one period so its waveform lines up with the recording still sounding
// (both play the same pitch during the blend). Without this the two can sit in opposite
// phase and eat each other for a moment - a hollow dip in the middle of every change of
// recording. ~150 sample reads and 2300 multiplies, once per takeover.
void alignLegatoPhase(SamplerEngine::Impl::Voice& v, const SamplerEngine::Impl::Voice& old, double sampleRate) noexcept {
    if (v.sample == nullptr || old.sample == nullptr || v.ratio <= 0.0 || old.ratio <= 0.0 || v.periodFrames <= 0.0) return;
    // period of the sounding pitch, in frames of each recording: both read their own
    // recording at `ratio` frames per output frame and the output period is the same
    const double outPeriod = v.periodFrames / v.ratio;                 // output frames per period (new voice at its current pitch)
    if (!(outPeriod > 8.0) || !(outPeriod < 0.1 * sampleRate)) return;  // 10 Hz .. ~12 kHz: outside = not a pitched line
    const double Pn = outPeriod * v.ratio;
    const double Po = outPeriod * old.ratio;
    constexpr int M = 48;
    const double limitNew = static_cast<double>((v.sample->loop.enabled && v.sample->loop.endFrame > 0U) ? std::min<std::uint64_t>(v.sample->loop.endFrame, v.sample->frameCount()) : v.sample->frameCount());
    const double limitOld = static_cast<double>(old.sample->frameCount());
    if (v.position + 2.0 * Pn + 2.0 >= limitNew || old.position + Po + 2.0 >= limitOld || old.position < 0.0) return;
    float o[M]; float n[2 * M];
    for (int k = 0; k < M; ++k) o[k] = monoFrameAt(*old.sample, static_cast<std::uint64_t>(old.position + static_cast<double>(k) * Po / M));
    for (int k = 0; k < 2 * M; ++k) n[k] = monoFrameAt(*v.sample, static_cast<std::uint64_t>(v.position + static_cast<double>(k) * Pn / M));
    double best = -1.0e30; int bestJ = 0;
    for (int j = 0; j < M; ++j) {
        double c = 0.0;
        for (int k = 0; k < M; ++k) c += static_cast<double>(o[k]) * static_cast<double>(n[j + k]);
        if (c > best) { best = c; bestJ = j; }
    }
    v.position += static_cast<double>(bestJ) * Pn / M;
    v.subPosition = v.position;
}

// SILVETON_LAYERS_V1: every recording this key plays on this Upper - the basic
// sound (soundIndex 0) and every layer that is on and covers the key.
template <typename Fn>
void forEachSoundZone(const UpperPart& upper, const GlobalState& global, std::uint8_t key, std::uint8_t velocity, Fn&& fn) noexcept {
    for (int s = 0; s < kSoundsPerUpper; ++s) {
        const UpperLayer* ul = layerOf(upper, s);
        const Program* prog = playProgramOf(upper, s);   // SILVETON_ENGINES_V2: the silent carrier when the ENGINE plays alone
        if (prog == nullptr) continue;
        if (ul != nullptr && !ul->matches(key, velocity)) continue;
        // In independent COMBI mode the ОСНОВЕН range gates only its sound.
        // The L1..L4 ranges remain independent, even beyond the main range.
        if (s == 0 && upper.independentLayerRanges &&
            (key < upper.keyLow || key > upper.keyHigh ||
             velocity < upper.velocityLow || velocity > upper.velocityHigh)) continue;
        const std::uint8_t pk = playKeyFor(upper, global, key, ul);
        for (const auto& layer : prog->layers) {
            if (!layer.matches(pk, velocity) || layer.multisample == nullptr) continue;
            for (const auto& zone : layer.multisample->zones) {
                if (!zone.matches(pk, velocity) || !zone.sample->valid()) continue;
                // SILVETON_POLYSIX_V1: UNISON = the same recording 1..4 times, detuned and spread
                const SoundTone st = soundToneOf(upper, s);
                const int n = std::clamp<int>(st.x.unisonVoices, 1, 4);
                for (int u = 0; u < n; ++u) fn(s, layer, zone, u);
            }
        }
    }
}

// Same sound keeps playing; only its pitch moves to the new key (true glissando).
void legatoTo(SamplerEngine::Impl& impl, SamplerEngine::Impl::Voice& v, const UpperPart& upper,
              const ProgramLayer& layer, const SampleZone& zone, std::uint8_t key, const GlobalState& global,
              float glideSec) noexcept {
    const UpperLayer* ul = layerOf(upper, v.soundIndex);
    const double target = noteRatio(impl, upper, layer, zone, key, global, v.upperIndex, ul);
    v.key = key;
    v.sourceKey=playKeyFor(upper,global,key,ul);
    v.sourceOscillator.controlCountdown=0U;
    v.sourceAmpControlCountdown=0U;
    if(v.ampEnv.sourceEnabled){
        refreshSourceAmp(impl,v,global);
        auto tone=voiceTone(v,soundToneOf(upper,v.soundIndex),upper);
        const auto& shape=ul?ul->velocityShape:upper.velocityShape;
        if(shape.toAttack>0.0F)tone.attackMs=std::min(tone.attackMs+velocityAttackExtraMs(shape,v.velNorm),kToneMaxTimeMs);
        if(v.modAttackMul!=1.0F)tone.attackMs=std::clamp(tone.attackMs*v.modAttackMul,0.0F,kToneMaxTimeMs);
        if(v.modReleaseMul!=1.0F)tone.releaseMs=std::clamp(tone.releaseMs*v.modReleaseMul,0.0F,kToneMaxTimeMs);
        v.ampEnv.setBlock(tone,impl.sampleRate);
    }
    if(soundSource(upper,v.soundIndex).soloModel)++v.soloGesture;
    v.tuneSemis = liveTuneSemis(upper, global, key, ((impl.scaleUppers.load(std::memory_order_relaxed) >> v.upperIndex) & 1) != 0, ul,!zone.nonTranspose);
    const float portamentoSec = glideSec;
    if (portamentoSec > 0.0F && v.ratio > 0.0 && target > 0.0) {
        const auto frames = static_cast<std::uint32_t>(std::max(1.0, static_cast<double>(portamentoSec) * impl.sampleRate));
        beginGlide(v, target, frames);
    } else {
        v.targetRatio = target;
        v.ratio = target;
        v.glideFramesRemaining = 0U;
        v.glideLastStep = v.glideStartVelocity = 0.0;
        v.pitchGliding = false;
    }
}

void chokeDrumKeys(SamplerEngine::Impl& impl,const EngineState& state,int ui,
                   const UpperPart& upper,std::uint8_t channel,std::uint8_t key,std::uint8_t velocity) noexcept {
    // This runs once for a complete accepted NoteOn, before its velocity
    // layers/unison voices are created. A closing key may be silent itself.
    for(int source=0;source<kSoundsPerUpper;++source){
        const auto* program=playProgramOf(upper,source);
        if(!program||!program->drumKeyGroups)continue;
        const auto* layer=layerOf(upper,source);
        if(layer&&!layer->matches(key,velocity))continue;
        if(source==0&&upper.independentLayerRanges&&
           (key<upper.keyLow||key>upper.keyHigh||velocity<upper.velocityLow||velocity>upper.velocityHigh))continue;
        const auto drumKey=playKeyFor(upper,state.global,key,layer);
        const auto& trigger=(*program->drumKeyGroups)[drumKey];
        if(!trigger.valid()||(!trigger.singleTrigger&&(trigger.exclusiveGroup==0||trigger.subgroupChokeOff)))continue;
        for(auto& voice:impl.voices){
            if(!voice.active||voice.fading||voice.upperIndex!=ui||voice.soundIndex!=source||
               voice.channel!=channel||voice.drumProgram!=program||!samePerformance(voice,state))continue;
            const auto& previous=(*program->drumKeyGroups)[voice.drumKey];
            // SILVETON's explicit interaction: Single Trigger alone governs
            // repetitions of one key. Exclusive Group chokes the other keys;
            // Subgroup Choke Off on the incoming key lets those tails continue.
            const bool sameKey=voice.drumKey==drumKey;
            const bool stop=sameKey?trigger.singleTrigger:
                !trigger.subgroupChokeOff&&trigger.exclusiveGroup!=0&&
                previous.exclusiveGroup==trigger.exclusiveGroup;
            if(!stop)continue;
            const float fade=previous.valid()?previous.chokeFadeOutMs:4.0F;
            if(fade==0.0F){voice.active=false;voice.keyHeld=false;voice.sustained=false;}
            else softKill(impl,voice,fade*0.001F);
        }
    }
}

void playUpperNote(SamplerEngine::Impl& impl, const std::shared_ptr<const EngineState>& stateOwner, int ui,
                   const UpperPart& upper, std::uint8_t channel, std::uint8_t key, std::uint8_t velocity,
                   double glideFromKey = -1.0, float glideSec = 0.0F,
                   double sourceFromKey = -1.0,bool sourcePreviousHeld = false) noexcept {
    const auto& global = stateOwner->global;
    const UpperVoiceMode mode = effectiveVoiceMode(upper);
    const bool upperMono = mode != UpperVoiceMode::Poly;
    const bool upperLegato = mode == UpperVoiceMode::Legato;
    bool hadHeldVoice = false;
    float previousAmp = 0.0F;
    // MONO / LEGATO portamento is played by playPortamentoNote(); POLY portamento
    // passes glideFromKey / glideSec (SILVETON_POLY_PORTA_V1).
    if (upperMono) {
        for (auto& existing : impl.voices) {
            if (!existing.active || existing.fading || existing.upperIndex != ui || !samePerformance(existing,*stateOwner)) continue;
            if (existing.keyHeld && existing.delayFramesRemaining == 0U) hadHeldVoice = true;
            previousAmp = std::max(previousAmp, existing.ampEnv.value);
            existing.legatoKeep = false;
        }
        if (upperLegato && hadHeldVoice) {
            // 1) a still-held voice on the same recording just changes pitch
            forEachSoundZone(upper, global, key, velocity, [&](int s, const ProgramLayer& layer, const SampleZone& zone, int un) noexcept {
                for (auto& existing : impl.voices) {
                    if (existing.active && !existing.fading && existing.upperIndex == ui && existing.keyHeld && samePerformance(existing,*stateOwner) &&
                        existing.delayFramesRemaining == 0U && !existing.legatoKeep && existing.soundIndex == s && existing.unisonIndex == un &&
                        existing.layer == &layer && existing.zone == &zone) {
                        legatoTo(impl, existing, upper, layer, zone, key, global,
                                 sourceGlideSeconds(impl,upper,layer,sourcePreviousHeld,ui));
                        if(soundSource(upper,existing.soundIndex).soloModel)existing.velocity=velocity;
                        existing.legatoKeep = true;
                        break;
                    }
                }
            });
        }
        // 2) every other sounding voice of this Upper leaves with a short fade.
        //    Automatic MONO of a POLY Upper (portamento ON) works like the
        //    processor: the new note first, then a normal Note Off for the old one,
        //    so the old note ends with its own release (the damper pedal holds it).
        const bool sourceMode=upper.sourceVoiceInherit&&upper.program&&
            upper.program->sourceVoiceAssignment.present&&playProgramOf(upper,0)==upper.program.get();
        const bool autoMono = upper.voiceMode == UpperVoiceMode::Poly&&!sourceMode;
        const bool sustainDown = impl.channels[channel & 0x0FU].sustain;
        for (auto& existing : impl.voices) {
            if (existing.active && !existing.fading && existing.upperIndex == ui && !existing.legatoKeep && samePerformance(existing,*stateOwner)) {
                if (autoMono) {
                    if (existing.ampEnv.stage != AmpEnv::Stage::Release && !existing.sustained) releaseOne(impl, existing, sustainDown);
                } else {
                    softKill(impl, existing, (upperLegato && hadHeldVoice) ? kLegatoCrossfadeSec : kTakeoverFadeSec);
                }
            }
        }
    }
    if (!upperMono && (impl.preparedState || upper.livePartMix ||
                       impl.channelMixEnabled.load(std::memory_order_relaxed)) &&
        impl.channels[channel].sustain) {
        // Rearticulating a sustained pitch in any Style Player path (including
        // a plain MIDI style without a prepared Korg program bank) replaces
        // its old pedal-held attack. Other pitches and legitimate new layers
        // remain intact. Do not change ordinary keyboard piano sustain.
        for (auto& voice : impl.voices) {
            if (voice.active && !voice.fading && voice.sustained && voice.upperIndex == ui &&
                voice.channel == channel && voice.key == key && samePerformance(voice,*stateOwner)) softKill(impl,voice);
        }
    }
    const auto attackGroup = impl.voiceAge + 1;
    const bool kronos = upper.portaMode == PortamentoMode::Kronos;
    forEachSoundZone(upper, global, key, velocity, [&](int s, const ProgramLayer& layer, const SampleZone& zone, int un) noexcept {
        if (upperLegato && hadHeldVoice) {
            for (const auto& existing : impl.voices) {
                if (existing.active && existing.legatoKeep && existing.upperIndex == ui && samePerformance(existing,*stateOwner) && existing.soundIndex == s && existing.unisonIndex == un &&
                    existing.layer == &layer && existing.zone == &zone) return;
            }
        }
        const float savedGlide=sourceFromKey>=0.0?sourceGlideSeconds(impl,upper,layer,sourcePreviousHeld,ui):0.0F;
        double savedFrom=sourceFromKey;
        if(savedGlide>0.0F&&upperMono&&sourcePreviousHeld){
            // When a new recording takes over an interrupted source glide,
            // use this oscillator's current pitch, not another oscillator's
            // duration/position. No history is shared between ProgramLayers.
            const SamplerEngine::Impl::Voice* previous=nullptr;
            for(const auto& old:impl.voices)
                if(old.active&&old.upperIndex==ui&&old.soundIndex==s&&old.layer==&layer&&
                   old.age<attackGroup&&samePerformance(old,*stateOwner)&&
                   old.ratio>0.0&&old.targetRatio>0.0&&(!previous||old.age>previous->age))previous=&old;
            if(previous)savedFrom=static_cast<double>(previous->key)+12.0*std::log2(previous->ratio/previous->targetRatio);
        }
        auto* v = chooseVoice(impl,impl.listensTo(ui,key)&&(impl.listenPart==ui||upperAudible(*stateOwner,upper)),attackGroup,!upperMono);
        if(!v)return;
        startVoice(impl, *v, upper, layer, zone, ui, channel, key, velocity, global, stateOwner, s, upperLegato && hadHeldVoice, un, attackGroup);
        v->mono = upperMono;
        v->glideKronos = kronos;
        startPortamentoGlide(impl, *v, savedGlide>0.0F?savedFrom:glideFromKey,
                             savedGlide>0.0F?savedGlide:glideSec);
        if (upperLegato && hadHeldVoice) {
            v->ampEnv.continueAt(previousAmp);
            v->fadeGain = 0.0F;
            v->fadeStep = 1.0F / static_cast<float>(std::max(1.0, static_cast<double>(kLegatoCrossfadeSec) * impl.sampleRate));
        }
    });
    if (upperMono) for (auto& existing : impl.voices) if (existing.upperIndex == ui && samePerformance(existing,*stateOwner)) existing.legatoKeep = false;
}

// SILVETON_PORTA_PAGE_V1: one note of an Upper whose portamento is ON.
// keyWasHeld = another key of this Upper was held before this note;
// previousKey = that key (used only if its recording already ended).
void playPortamentoNote(SamplerEngine::Impl& impl, const std::shared_ptr<const EngineState>& stateOwner, int ui,
                        const UpperPart& upper, std::uint8_t channel, std::uint8_t key, std::uint8_t velocity,
                        bool keyWasHeld, int previousKey) noexcept {
    if (!upper.hasAnySound() && !engineCarries(upper)) return;
    const auto& global = stateOwner->global;
    float glideSec = portamentoSecFor(upper);
    SamplerEngine::Impl::Voice* sounding = nullptr;   // the voice of the held line
    for (auto& v : impl.voices) {
        if (!v.active || v.fading || v.upperIndex != ui || !samePerformance(v,*stateOwner)) continue;
        if (effectiveVoiceMode(upper) != UpperVoiceMode::Poly && (!keyWasHeld || !v.keyHeld)) {
            softKill(impl,v);
            continue;
        }
        if (!v.keyHeld || v.delayFramesRemaining > 0U) continue;
        if (sounding == nullptr || v.age > sounding->age) sounding = &v;
    }
    const bool kronos = upper.portaMode == PortamentoMode::Kronos;
    const bool fullTime = upper.portaMode == PortamentoMode::Kronos && !upper.portaFingered;
    // SILVETON_BASS_SLIDE_ZONE_GUARD_V1:
    // Imported basses can have gaps or a shortened playable range in their
    // velocity/key zones.  A legato slide must not fade its old voice to silence
    // when the destination has no new zone.  Reuse the zones of the held line
    // (including all its layers/unison copies) for this slide ONLY.  This never
    // changes ordinary NoteOn zone mapping when portamento is disabled.
    const auto originalVoiceAge = impl.voiceAge;
    auto forEachPortamentoZone = [&](auto&& visitor) noexcept {
        bool found = false;
        forEachSoundZone(upper, global, key, velocity,
                         [&](int s, const ProgramLayer& layer, const SampleZone& zone, int un) noexcept {
                             found = true;
                             visitor(s, layer, zone, un);
                         });
        if (found || !instrumentGlide(upper)) return;
        if (keyWasHeld) {
            // The original voices keep their EngineState alive, but the fresh
            // voice is owned by stateOwner. Do not borrow a zone from a prior
            // bank after a live program replacement.
            for (const auto& old : impl.voices) {
                if (!old.active || old.fading || !old.keyHeld || old.upperIndex != ui ||
                    old.delayFramesRemaining != 0U || old.age > originalVoiceAge ||
                    old.ownerState.get() != stateOwner.get() || old.layer == nullptr ||
                    old.zone == nullptr || old.sample == nullptr) continue;
                visitor(old.soundIndex, *old.layer, *old.zone, old.unisonIndex);
                found = true;
            }
            if (found) return;
            // The last bass pluck may already have reached EOF while its key
            // was still held. Re-trigger its last mapped recording rather than
            // leaving a held legato line completely silent.
            if (previousKey >= 0) {
                forEachSoundZone(upper, global, static_cast<std::uint8_t>(previousKey), velocity, visitor);
            }
        }
    };
    if (!keyWasHeld || sounding == nullptr) {
        if (keyWasHeld && !sounding && effectiveVoiceMode(upper) != UpperVoiceMode::Poly) {
            for (auto& v : impl.voices)
                if (v.active && !v.fading && v.upperIndex == ui && v.delayFramesRemaining && samePerformance(v,*stateOwner))
                    softKill(impl,v);
        }
        // Nothing held: struck normally, no glide (a held line whose recording
        // already ended starts again and glides from the previous key).
        // KRONOS (not Fingered): glides from the last key even when nothing is held.
        double fromKey = (keyWasHeld && previousKey >= 0) ? static_cast<double>(previousKey) : -1.0;
        if (fullTime && fromKey < 0.0) fromKey = static_cast<double>(impl.polyLastKey[static_cast<std::size_t>(ui)]);   // (ВИНАГИ: from the last key)
        glideSec = glideSecFor(impl, upper, fromKey, static_cast<double>(key), ui);
        forEachPortamentoZone([&](int s, const ProgramLayer& layer, const SampleZone& zone, int un) noexcept {
            auto* v = chooseVoice(impl,impl.listensTo(ui,key)&&(impl.listenPart==ui||upperAudible(*stateOwner,upper)),originalVoiceAge+1U);
            if(!v)return;
            startVoice(impl, *v, upper, layer, zone, ui, channel, key, velocity, global, stateOwner, s, false, un, originalVoiceAge+1U);
            v->mono = true;
            v->glideKronos = kronos;
            startPortamentoGlide(impl, *v, fromKey, glideSec);
        });
        impl.polyLastKey[static_cast<std::size_t>(ui)] = key;
        return;
    }
    // A key is held: one continuous sound glides to the new key in exactly TIME.
    const double fromPitch = static_cast<double>(sounding->key) + 12.0 * std::log2(sounding->ratio / sounding->targetRatio);
    glideSec = glideSecFor(impl, upper, fromPitch, static_cast<double>(key), ui);
    if (upper.portaMode == PortamentoMode::Silveton) {
        // SILVETON_PROCESSOR_PORTA_V1: like the Korg under the processor - the rate is the one
        // for the interval between the two KEYS. A shorter remaining distance
        // may arrive sooner, but an interrupted upward/downward run must never
        // multiply TIME/NEAR when its audible pitch is behind the previous key.
        const double keyInterval = std::abs(static_cast<double>(key) - static_cast<double>(sounding->key));
        const double pitchInterval = std::abs(static_cast<double>(key) - fromPitch);
        if (keyInterval >= 0.5 && pitchInterval > 1.0e-6) {
            const float keyTime = glideSecFor(impl, upper, static_cast<double>(sounding->key), static_cast<double>(key), ui);
            const double remainingFraction = std::min(1.0, pitchInterval / keyInterval);
            glideSec = std::clamp(static_cast<float>(keyTime * remainingFraction), 0.001F, 10.0F);
        }
    }
    if (upper.portaMode == PortamentoMode::Bass) {
        // SILVETON_BASS_PORTA_V2: the line keeps the recording it STARTED with. No other articulation (velocity layer) for the new
        // key, no fresh recording blended in, and no kill when the new key has no zone of its own (a slide past the recorded range):
        // every held voice of the line only moves its pitch to the new key. (SILVETON, KRONOS and INSTRUMENT are not changed.)
        for (auto& v : impl.voices) {
            if (v.active && !v.fading && v.upperIndex == ui && v.keyHeld && samePerformance(v,*stateOwner) && v.layer != nullptr && v.zone != nullptr) {
                v.glideKronos = false;
                legatoTo(impl, v, upper, *v.layer, *v.zone, key, global, glideSec);
            }
        }
        impl.polyLastKey[static_cast<std::size_t>(ui)] = key;
        return;
    }
    const float previousAmp = sounding->ampEnv.value;
    // SILVETON_XFADE_PORTA_V1 - crossfade portamento: when the new key needs
    // another recording, both recordings play the SAME pitch glide - the old one
    // fading out, the new one (started past its attack) fading in - over the
    // whole glide. No stretched single sample, no re-struck attack, no jump of
    // timbre at the arrival.
    // SILVETON_PORTA_SOFT_FAST_V1: the blend between the two recordings lasts the whole
    // glide (up to 300 ms) at any playing speed, and every tail still fading from an
    // earlier note glides along to the newest key, so nothing lags behind in pitch.
    float xfadeSec = std::clamp(glideSec, kLegatoCrossfadeSec, 0.300F);
    // The crossfade cannot be longer than the remaining recording! A plucked
    // bass has no loop, so a 100-300 ms glide must NOT imply a 100-300 ms
    // *amplitude* fade: its old recording may expire in only a few ms.
    // Keep the full pitch glide on the new voice, but hand off amplitude soon
    // enough that its attack has become audible before the old sample ends.
    if (instrumentGlide(upper) && sounding->sample && (!sounding->sample->loop.enabled || sounding->loopOff)) {
        const double remaining = static_cast<double>(sounding->sample->frameCount()) - sounding->position;
        const double framesPerSec = static_cast<double>(sounding->sample->sampleRate);
        const double playbackRate = std::max(0.01, sounding->ratio);
        const double remainingSec = std::max(0.0, remaining) / (framesPerSec * playbackRate);
        xfadeSec = std::min(xfadeSec, static_cast<float>(std::clamp(remainingSec * 0.5, 0.003, 0.025)));
    }
    for (auto& v : impl.voices) if (v.upperIndex == ui && samePerformance(v,*stateOwner)) v.legatoKeep = false;
    // First every held voice of the line gets its new glide (same rate, same arrival), so a
    // recording that takes over below copies the glide as it is NOW - not the one it was
    // interrupting (that left the two recordings out of tune for a moment).
    for (auto& v : impl.voices) {
        if (v.active && !v.fading && v.upperIndex == ui && v.keyHeld && v.delayFramesRemaining == 0U && samePerformance(v,*stateOwner) && v.layer != nullptr && v.zone != nullptr) {
            v.glideKronos = kronos; legatoTo(impl, v, upper, *v.layer, *v.zone, key, global, glideSec);
        }
    }
    forEachPortamentoZone([&](int s, const ProgramLayer& layer, const SampleZone& zone, int un) noexcept {
        SamplerEngine::Impl::Voice* keep = nullptr;
        for (auto& v : impl.voices) {
            if (v.active && !v.fading && v.upperIndex == ui && v.keyHeld && v.delayFramesRemaining == 0U && samePerformance(v,*stateOwner) &&
                !v.legatoKeep && v.soundIndex == s && v.unisonIndex == un && v.layer == &layer && v.zone == &zone) { keep = &v; break; }
        }
        // A plucked bass / percussion recording without a sustain loop has
        // a finite decay. Reusing that voice at its old playback position for
        // each legato key eventually runs into EOF and produces silence.
        // Crossfade to a *fresh* recording on every new key in that case;
        // retain seamless same-voice pitch glide for looping instruments.
        if (instrumentGlide(upper) && keep != nullptr && keep->sample != nullptr &&
            (!keep->sample->loop.enabled || keep->loopOff) &&
            keep->waveTable == nullptr) {
            keep = nullptr;
        }
        if (keep != nullptr) {
            // the same looping recording keeps sounding and only moves its pitch
            keep->glideKronos = kronos;
            legatoTo(impl, *keep, upper, layer, zone, key, global, glideSec);
            if(soundSource(upper,keep->soundIndex).soloModel)keep->velocity=velocity;
            keep->legatoKeep = true;
            return;
        }
        // another recording takes over without a new strike and glides from the pitch that sounded
        auto* v = chooseVoice(impl,impl.listensTo(ui,key)&&(impl.listenPart==ui||upperAudible(*stateOwner,upper)),originalVoiceAge+1U);
        if(!v)return;
        startVoice(impl, *v, upper, layer, zone, ui, channel, key, velocity, global, stateOwner, s, true, un, originalVoiceAge+1U);
        v->mono = true;
        v->glideKronos = kronos;
        startPortamentoGlide(impl, *v, fromPitch, glideSec);
        if (v != sounding && v->pitchGliding && sounding->pitchGliding) {
            // SILVETON_PHASE_ALIGN_V1: the new recording takes over the exact glide of the old one
            // (same momentum, same curve position) so the two stay in tune - and in phase - all the way
            v->glideStartVelocity = sounding->glideStartVelocity; v->glideStartSemis = sounding->glideStartSemis;
            v->glideRawSemis = sounding->glideRawSemis; v->glideSmooth1 = sounding->glideSmooth1; v->glideSmooth2 = sounding->glideSmooth2;
            v->glideLastStep = sounding->glideLastStep; v->glideTotalFrames = sounding->glideTotalFrames; v->glideFramesRemaining = sounding->glideFramesRemaining;
            v->ratio = v->targetRatio * std::exp2(12.0 * std::log2(sounding->ratio / sounding->targetRatio) / 12.0);
        }
        if (v != sounding) alignLegatoPhase(*v, *sounding, impl.sampleRate);   // SILVETON_PHASE_ALIGN_V1
        v->ampEnv.continueAt(previousAmp);
        v->fadeGain = 0.0F;
        v->fadeStep = 1.0F / static_cast<float>(std::max(1.0, static_cast<double>(xfadeSec) * impl.sampleRate));
        v->fadeBlend = true;
        v->legatoKeep = true;
    });
    impl.polyLastKey[static_cast<std::size_t>(ui)] = key;
    for (auto& v : impl.voices) {
        if (v.active && !v.fading && v.upperIndex == ui && v.keyHeld && !v.legatoKeep && samePerformance(v,*stateOwner)) {
            // the old recording glides along to the new key while it fades out
            if (v.layer != nullptr && v.zone != nullptr) { v.glideKronos = kronos; legatoTo(impl, v, upper, *v.layer, *v.zone, key, global, glideSec); }
            softKill(impl, v, xfadeSec);
            v.fadeBlend = true;
        } else if (v.active && v.fading && v.fadeBlend && v.upperIndex == ui && !v.legatoKeep && samePerformance(v,*stateOwner) && v.layer != nullptr && v.zone != nullptr) {
            // SILVETON_PORTA_SOFT_FAST_V1: a tail from an earlier note of this line follows the newest key too
            v.glideKronos = kronos; legatoTo(impl, v, upper, *v.layer, *v.zone, key, global, glideSec);
        }
    }
    for (auto& v : impl.voices) if (v.upperIndex == ui && samePerformance(v,*stateOwner)) v.legatoKeep = false;
}

void handleNoteOff(SamplerEngine::Impl& impl, const std::shared_ptr<const EngineState>& stateOwner,
                   std::uint8_t channel, std::uint8_t key, bool allowRetrigger = true,std::uint8_t releaseVelocity=64U,
                   unsigned parts=(1U<<kPartCount)-1U,bool updateTerca=true) noexcept {
    std::uint16_t handled = 0U;
    // SILVETON_TERCA_V1: the TERCA Upper releases the third that this key made.
    const int tmask = updateTerca && impl.tercaApplied >= 0 ? (impl.tercaApplied & kAllPartsMask) : 0;
    int harmony = -1;
    bool harmonyEnds = false;
    if (tmask != 0) {
        auto& slot = impl.tercaKey[channel & 0x0FU][key & 0x7FU];
        harmony = slot;
        slot = -1;
        if (harmony >= 0) {
            auto& refs = impl.tercaRefs[channel & 0x0FU][static_cast<std::size_t>(harmony)];
            if (refs > 0U) --refs;
            harmonyEnds = refs == 0U;
        }
    }
    for(auto& voice:impl.voices)if(voice.active&&voice.channel==channel&&voice.upperIndex>=0&&voice.upperIndex<kPartCount&&(parts&(1U<<voice.upperIndex))&&
        (voice.key==key||(harmony>=0&&harmonyEnds&&voice.key==static_cast<std::uint8_t>(harmony))))
        voice.releaseVelocity=releaseVelocity;
    for (int ui = 0; ui < kPartCount; ++ui) {
        if(!(parts&(1U<<ui)))continue;
        const auto& upper = stateOwner->combi.part(static_cast<int>(static_cast<std::size_t>(ui)));
        std::uint8_t keyHere = key;
        if (((tmask >> ui) & 1) != 0) {
            if (harmony < 0 || !harmonyEnds) continue;
            keyHere = static_cast<std::uint8_t>(harmony);
        }
        // Release accepted keys even after filtering or an input-channel edit.
        // A reconfigured part resets this memory before accepting the new channel.
        const auto u = static_cast<std::size_t>(ui);
        auto& poly = impl.polyKeys[u];
        if (poly.channel == (channel & 0x0FU)) {
            poly.release(keyHere);
            if (!poly.any()) {
                poly.chordActive = false;
                impl.polyAnchorKey[u] = -1;
            }
        }
        if (upper.midiChannel != (channel & 0x0FU) || voiceModeNow(impl, ui, upper) == UpperVoiceMode::Poly) continue;
        auto& mk = impl.mono[static_cast<std::size_t>(ui)];
        std::size_t index = mk.count;
        for (std::size_t i = 0; i < mk.count; ++i) if (mk.key[i] == keyHere) { index = i; break; }
        if (index >= mk.count) continue;
        handled = static_cast<std::uint16_t>(handled | static_cast<std::uint16_t>(1U << static_cast<unsigned>(ui)));
        const bool wasTop = index == monoSelected(mk, upper);
        monoRemoveAt(mk, index);
        if (!wasTop) continue; // a lower held key was let go: the sound goes on
        if (allowRetrigger && mk.count > 0U && (upper.hasAnySound() || engineCarries(upper))) {
            // back to the selected held key (LAST / HIGH / LOW)
            const std::size_t selected = monoSelected(mk, upper);
            if (portamentoSecFor(upper) > 0.0F) {
                playPortamentoNote(impl, stateOwner, ui, upper, channel, mk.key[selected], mk.vel[selected], true, static_cast<int>(keyHere));
            } else {
                playUpperNote(impl, stateOwner, ui, upper, channel, mk.key[selected], mk.vel[selected],
                              -1.0,0.0F,static_cast<double>(keyHere),true);
                impl.polyLastKey[static_cast<std::size_t>(ui)]=mk.key[selected];
            }
        } else {
            releaseUpperVoices(impl, ui, channel,*stateOwner);
        }
    }
    if (tmask != 0) {
        const auto tBits = static_cast<std::uint16_t>(tmask);
        if (harmony >= 0 && harmonyEnds) {
            // only the TERCA Uppers not already handled as MONO above
            releaseMatching(impl, channel, static_cast<std::uint8_t>(harmony),
                            static_cast<std::uint16_t>((((1U << kPartCount) - 1U) & ~static_cast<unsigned>(tBits)) | handled),*stateOwner,parts);
        }
        handled = static_cast<std::uint16_t>(handled | tBits);
    }
    releaseMatching(impl, channel, key, handled,*stateOwner,parts);
}

constexpr int kKeyboardLower=6;
constexpr unsigned kKeyboardLowerMask=1U<<kKeyboardLower;
void flushLowerMemory(SamplerEngine::Impl& impl,const std::shared_ptr<const EngineState>& stateOwner,bool retrigger) noexcept {
    // Only deferred physical releases are replayed. Upper parts and actual
    // still-pressed Lower notes are never touched, even on the same channel.
    for(unsigned channel=0;channel<16;++channel)for(unsigned key=0;key<128;++key){
        if(!impl.lowerDeferred[channel][key])continue;
        impl.lowerDeferred[channel][key]=false;
        handleNoteOff(impl,stateOwner,static_cast<std::uint8_t>(channel),static_cast<std::uint8_t>(key),retrigger,64U,kKeyboardLowerMask,false);
    }
}
void keyboardNoteOff(SamplerEngine::Impl& impl,const std::shared_ptr<const EngineState>& stateOwner,
    std::uint8_t channel,std::uint8_t key,bool allowed,std::uint8_t velocity) noexcept {
    if(key>=128)return;
    auto& physical=impl.lowerPhysical[channel][key];
    const bool defer=impl.lowerMemoryApplied&&(physical||impl.lowerDeferred[channel][key]);
    physical=false;
    if(defer)impl.lowerDeferred[channel][key]=true;
    const unsigned mask=((1U<<kPartCount)-1U)&~(defer?kKeyboardLowerMask:0U);
    handleNoteOff(impl,stateOwner,channel,key,allowed,velocity,mask);
}
void syncLowerMemory(SamplerEngine::Impl& impl,const std::shared_ptr<const EngineState>& owner) noexcept {
    const bool requested=impl.lowerMemoryRequested.load(std::memory_order_acquire);
    // The optional third-harmony layer shares a per-channel note map, so do
    // not defer transformed Lower releases across a Terca configuration.
    const auto terca=impl.tercaConfig.load(std::memory_order_acquire);
    const bool transformed=terca>=0 && (static_cast<unsigned>(terca)&kKeyboardLowerMask)!=0;
    const bool enabled=requested&&!transformed;
    if(impl.lowerMemoryApplied&&!enabled){flushLowerMemory(impl,owner,true);impl.lowerPhysical={};}
    impl.lowerMemoryApplied=enabled;
}

void syncTerca(SamplerEngine::Impl& impl) noexcept {
    const int cfg = impl.tercaConfig.load(std::memory_order_acquire);
    if (cfg == impl.tercaApplied) return;
    // TERCA changed (on/off, other Upper or tonality): the old TERCA Upper lets
    // its thirds go, so no third can hang.
    const int oldMask = impl.tercaApplied >= 0 ? (impl.tercaApplied & kAllPartsMask) : 0;
    const int newMask = cfg >= 0 ? (cfg & kAllPartsMask) : 0;
    // SILVETON_TQ_TRANSPOSE_V1: also the Upper that just became T (its held keys
    // would otherwise never get their note-off).
    const int touched = oldMask | newMask;
    for (int ui = 0; ui < kPartCount; ++ui) {
        if (((touched >> ui) & 1) == 0) continue;
        for (auto& v : impl.voices) {
            if (v.active && v.upperIndex == ui) releaseOne(impl, v, false);
        }
        impl.mono[static_cast<std::size_t>(ui)] = SamplerEngine::Impl::MonoKeys{};
        clearPolyKeys(impl, static_cast<std::size_t>(ui));
    }
    for (auto& ch : impl.tercaKey) ch.fill(-1);
    for (auto& ch : impl.tercaRefs) ch.fill(0U);
    impl.tercaApplied = cfg;
}

// DMS input is owned by a performance part, not by one of its sample voices.
// The existing MIDI queue has no sample offsets: counters retain real input
// edges across its block-boundary drain, without inventing a clock or LFO.
void refreshNumberedFxControlPart(SamplerEngine::Impl& impl, const EngineState& state,
                                 std::size_t part, bool countEdges) noexcept {
    auto& track = impl.fxControlParts[part];
    auto& frame = track.frame;
    const auto& upper = state.combi.part(static_cast<int>(part));
    const auto channel = static_cast<std::uint8_t>(upper.midiChannel & 15U);
    const auto& ch = impl.channels[channel];
    const bool channelAllowed = (state.global.midiInputChannelMask & (1U << channel)) != 0;
    const bool ccAllowed = channelAllowed && !state.global.filterControlChange;
    const bool pressureAllowed = channelAllowed && upper.aftertouchEnabled &&
        state.global.aftertouchEnabled && !state.global.filterAftertouch;
    const bool bendAllowed = channelAllowed && state.global.pitchBendEnabled && !state.global.filterPitchBend;
    const bool held = track.any();
    if (!held && !(upper.damperEnabled && ch.sustain)) track.damperGate = false;
    const auto oldAvailable = frame.availableMask;
    const auto oldHigh = frame.highMask;
    frame.availableMask = 0;
    frame.highMask = 0;
    frame.frozen = false;
    for (int source = 0; source < static_cast<int>(kNumberedFxControlSourceCount); ++source) {
        const auto bit = std::uint64_t{1} << source;
        bool available = numberedFxControlSourceSupported(source);
        bool high = false;
        float position = 0.0F;
        if (available) {
            switch (source) {
                case 0: break;
                case 1: case 3: high = held; position = high ? 1.0F : 0.0F; break;
                case 2: case 4: high = held || track.damperGate; position = high ? 1.0F : 0.0F; break;
                case 8:
                    available = pressureAllowed;
                    position = std::clamp(ch.pressure, 0.0F, 1.0F);
                    high = position >= (64.0F / 127.0F);
                    break;
                case 9:
                    available = bendAllowed;
                    // Physical centre is position0.5 and nominal DMS value64.
                    position = 0.5F + 0.5F * (ch.pitchBend < 0 ?
                        static_cast<float>(ch.pitchBend) / 8192.0F :
                        static_cast<float>(ch.pitchBend) / 8191.0F);
                    high = ch.pitchBend >= 0;
                    break;
                default: {
                    const int cc = numberedFxControlSourceCc(source);
                    available = ccAllowed && cc >= 0;
                    if (cc >= 0) position = std::clamp(ch.cc[static_cast<std::size_t>(cc)], 0.0F, 1.0F);
                    high = position >= (64.0F / 127.0F);
                    break;
                }
            }
        }
        frame.values[static_cast<std::size_t>(source)] = available ? position : 0.0F;
        if (available) frame.availableMask |= bit;
        if (available && high) frame.highMask |= bit;
        // Gate2 has an independent NoteOn counter, including legato/repeated
        // notes while its level is already high. Do not also count its rise.
        if (countEdges && source != 3 && source != 4 && available && high &&
            (oldAvailable & bit) != 0 && (oldHigh & bit) == 0)
            ++frame.rises[static_cast<std::size_t>(source)];
    }
}

void syncNumberedFxControlOwner(SamplerEngine::Impl& impl, const EngineState& state,
                               bool forceNewOwner = false) noexcept {
    const bool changed = forceNewOwner || !impl.fxControlOwnerValid ||
        impl.fxControlPerformanceGeneration != state.combiGeneration;
    for (std::size_t part = 0; part < impl.fxControlParts.size(); ++part) {
        auto& track = impl.fxControlParts[part];
        const auto channel = static_cast<std::uint8_t>(state.combi.part(static_cast<int>(part)).midiChannel & 15U);
        const bool rebind = changed || track.channel != channel || track.frame.ownerGeneration == 0;
        if (rebind) {
            track = SamplerEngine::Impl::FxControlPart{};
            track.channel = channel;
            if (++impl.fxControlBindingSerial == 0) ++impl.fxControlBindingSerial;
            track.frame.ownerGeneration = impl.fxControlBindingSerial;
        }
        // A setting/owner change is not a MIDI edge. Controllers may already
        // be high when a new algorithm is assigned; no trigger is fabricated.
        refreshNumberedFxControlPart(impl, state, part, false);
        if (rebind) track.frame.blockStartRises = track.frame.rises;
    }
    impl.fxControlPerformanceGeneration = state.combiGeneration;
    impl.fxControlOwnerValid = true;
}

void beginNumberedFxControlBlock(SamplerEngine::Impl& impl) noexcept {
    for (auto& part : impl.fxControlParts) part.frame.blockStartRises = part.frame.rises;
}

void captureNumberedFxNoteOn(SamplerEngine::Impl& impl, const EngineState& state,
                            const RealtimeEvent& e) noexcept {
    const auto channel = static_cast<std::uint8_t>(e.channel & 15U);
    if (e.data1 > 127U || e.data2 == 0U || state.global.filterNotes ||
        (state.global.midiInputChannelMask & (1U << channel)) == 0) return;
    for (std::size_t part = 0; part < impl.fxControlParts.size(); ++part) {
        auto& track = impl.fxControlParts[part];
        const auto& upper = state.combi.part(static_cast<int>(part));
        if (track.channel != channel || e.data1 < upper.performanceKeyLow ||
            e.data1 > upper.performanceKeyHigh) continue;
        // Modulating-track MIDI remains meaningful when a sample is absent,
        // muted, already ended or stolen. Sound-zone/voice decisions are not
        // sources of invented NoteOff events. Performance SPLIT still applies.
        track.press(e.data1);
        track.damperGate = true;
        ++track.frame.rises[static_cast<std::size_t>(NumberedFxControlSource::Gate2)];
        ++track.frame.rises[static_cast<std::size_t>(NumberedFxControlSource::Gate2Damper)];
        refreshNumberedFxControlPart(impl, state, part, true);
    }
}

void captureNumberedFxOtherEvent(SamplerEngine::Impl& impl, const EngineState& state,
                                const RealtimeEvent& e) noexcept {
    if (e.type == EventType::Panic) {
        syncNumberedFxControlOwner(impl, state, true);
        return;
    }
    const auto channel = static_cast<std::uint8_t>(e.channel & 15U);
    const bool noteRelease = e.type == EventType::NoteOff || (e.type == EventType::NoteOn && e.data2 == 0U);
    const bool allRelease = e.type == EventType::SoftChannelRelease ||
        (e.type == EventType::ControlChange && (e.data1 == 120U || e.data1 == 123U));
    const bool controls = e.type == EventType::ResetSourceChannel || e.type == EventType::ControlChange ||
        e.type == EventType::PitchBend || e.type == EventType::ChannelPressure;
    if (!noteRelease && !allRelease && !controls) return;
    for (std::size_t part = 0; part < impl.fxControlParts.size(); ++part) {
        auto& track = impl.fxControlParts[part];
        if (track.channel != channel) continue;
        if (allRelease) track.releaseAll();
        else if (noteRelease && e.data1 <= 127U) track.release(e.data1);
        // This follows processEvent, so CC/pressure/bend are precisely the
        // accepted real channel inputs. Releases clean up previously accepted
        // keys even when a later filter or key-range edit rejects new input.
        refreshNumberedFxControlPart(impl, state, part, true);
    }
}

void processEvent(SamplerEngine::Impl& impl, const std::shared_ptr<const EngineState>& stateOwner, const RealtimeEvent& e) noexcept {
    if (stateOwner == nullptr) return;
    syncTerca(impl);
    const auto& state = *stateOwner;
    const std::uint8_t channel = static_cast<std::uint8_t>(e.channel & 0x0FU);
    // Filters govern new input, never the release of a note/pedal accepted earlier.
    // In particular a channel may be disabled while its key or damper is still held.
    const bool channelAllowed = (state.global.midiInputChannelMask & (1U << channel)) != 0U;
    const bool noteInputAllowed = channelAllowed && !state.global.filterNotes;
    const bool noteRelease = e.type == EventType::NoteOff || (e.type == EventType::NoteOn && e.data2 == 0U);
    const bool damperEvent = e.type == EventType::ControlChange && e.data1 == state.global.damperCc;
    const bool damperDown = state.global.damperPolarityReversed ? e.data2 < 64U : e.data2 >= 64U;
    const bool damperRelease = damperEvent && !damperDown;
    const bool resetControllers = e.type == EventType::ControlChange && e.data1 == 121U;
    const bool allOff = e.type == EventType::SoftChannelRelease ||
        (e.type == EventType::ControlChange && (e.data1 == 120U || e.data1 == 123U));
    if (!channelAllowed && e.type != EventType::Panic && !noteRelease && !damperRelease && !resetControllers && !allOff && e.type != EventType::PitchBend && e.type != EventType::ResetSourceChannel) return;
    auto& ch = impl.channels[channel];
    if(allOff){impl.lowerPhysical[channel].fill(false);impl.lowerDeferred[channel].fill(false);}
    switch (e.type) {
        case EventType::NoteOn: {
            if (e.data2 == 0U) { keyboardNoteOff(impl, stateOwner, channel, e.data1, noteInputAllowed,64U); break; }
            if (!noteInputAllowed) break;
            ch.polyPressure[e.data1&127U]=0.0F;
            bool anySolo = false;
            for (int pi = 0; pi < kPartCount; ++pi) { const auto& u = state.combi.part(pi); if (u.enabled && u.solo) anySolo = true; }
            const int tmask = impl.tercaApplied >= 0 ? (impl.tercaApplied & kAllPartsMask) : 0;
            int harmonyKey = -1;   // SILVETON_TERCA_V1: the third, sounded once for all T Uppers
            if (tmask != 0) {
                const int cfg = impl.tercaApplied;
                auto& slot = impl.tercaKey[e.channel & 0x0FU][e.data1 & 0x7FU];
                if (slot < 0) {
                    const int h = SamplerEngine::tercaHarmony((cfg >> 16) & 0x0F, (cfg >> 20) & 0x0F, e.data1);
                    if (h >= 0) {
                        slot = static_cast<std::int8_t>(h);
                        auto& refs = impl.tercaRefs[e.channel & 0x0FU][static_cast<std::size_t>(h)];
                        if (refs < 255U) ++refs;
                        if (refs == 1U) harmonyKey = h;   // otherwise another key already sounds it
                    }
                }
            }
            for (int ui = 0; ui < kPartCount; ++ui) {
                const auto& upper = state.combi.part(static_cast<int>(static_cast<std::size_t>(ui)));
                if (upper.midiChannel != (e.channel & 0x0FU)) continue;
                if (anySolo && !upper.solo && impl.listenPart!=ui) continue;
                if (!upperPlays(upper,e.data1,e.data2,upper.livePartMix&&(upper.enabled||impl.listenPart==ui))) continue;   // SILVETON_ENGINES_V2: an empty Upper whose ENGINE sounds plays too
                if(ui==kKeyboardLower&&impl.lowerMemoryApplied){
                    flushLowerMemory(impl,stateOwner,false);
                    impl.lowerPhysical[channel][e.data1]=true;
                }
                std::uint8_t key = e.data1;
                if (((tmask >> ui) & 1) != 0) {
                    // SILVETON_TERCA_V1: a T Upper plays the third of the key.
                    if (harmonyKey < 0) continue;
                    key = static_cast<std::uint8_t>(harmonyKey);
                }
                chokeDrumKeys(impl,state,ui,upper,channel,key,e.data2);
                const auto mode = voiceModeNow(impl, ui, upper);
                bool polyKeyWasHeld = false;
                bool sourceKeyWasHeld = false;
                double sourcePreviousKey = static_cast<double>(impl.polyLastKey[static_cast<std::size_t>(ui)]);
                if (mode != UpperVoiceMode::Poly) {
                    auto& mk = impl.mono[static_cast<std::size_t>(ui)];
                    const bool keyWasHeld = mk.count > 0U;
                    const int previousKey = keyWasHeld ? static_cast<int>(mk.key[monoSelected(mk, upper)]) : -1;
                    sourceKeyWasHeld=keyWasHeld;
                    if(previousKey>=0)sourcePreviousKey=static_cast<double>(previousKey);
                    monoPush(mk, key, e.data2);
                    if (mk.key[monoSelected(mk, upper)] != key) continue;
                    if (portamentoSecFor(upper) > 0.0F) {
                        // SILVETON_PORTA_PAGE_V1: the note that already sounds changes nothing
                        // An unlooped bass may have reached EOF while its
                        // physical key remained pressed. Pressing that key
                        // again must restart it, not silently ignore NoteOn.
                        bool audibleLine = false;
                        for (const auto& voice : impl.voices) {
                            if (voice.active && !voice.fading && voice.keyHeld &&
                                voice.upperIndex == ui && samePerformance(voice,*stateOwner)) { audibleLine = true; break; }
                        }
                        if (previousKey != static_cast<int>(key) ||
                            (instrumentGlide(upper) && !audibleLine)) {
                            playPortamentoNote(impl, stateOwner, ui, upper, e.channel, key, e.data2, keyWasHeld, previousKey);
                        }
                        continue;
                    }
                } else {
                    const auto u = static_cast<std::size_t>(ui);
                    if (impl.polyKeys[u].channel != channel) {
                        clearPolyKeys(impl, u);
                        impl.polyKeys[u].channel = channel;
                    }
                    polyKeyWasHeld = impl.polyKeys[u].any();
                    sourceKeyWasHeld=polyKeyWasHeld;
                    impl.polyKeys[u].press(key);
                }
                if (portamentoSecFor(upper) > 0.0F) {
                    // SILVETON_POLY_PORTA_V1: glide from the key played before, only while
                    // a key of this Upper is held; keys of one chord share the same start.
                    const auto u = static_cast<std::size_t>(ui);
                    auto& poly = impl.polyKeys[u];
                    // Bound a rolled chord from its FIRST note. Updating this on
                    // every NoteOn would turn an arbitrarily long fast run into
                    // one chord, often with no glide anchor at all.
                    const bool sameChord = polyKeyWasHeld && poly.chordActive &&
                        impl.frameClock - poly.chordStart < static_cast<std::uint64_t>(0.050 * impl.sampleRate);
                    // KRONOS (not Fingered): always from the last key, held or not.
                    const bool always = upper.portaMode == PortamentoMode::Kronos && !upper.portaFingered;
                    if (!sameChord) {
                        impl.polyAnchorKey[u] = (polyKeyWasHeld || always) ? impl.polyLastKey[u] : -1;
                        poly.chordStart = impl.frameClock;
                        poly.chordActive = true;
                    }
                    const double from = impl.polyAnchorKey[u];
                    impl.polyLastKey[u] = key;
                    playUpperNote(impl, stateOwner, ui, upper, e.channel, key, e.data2,
                                  from, glideSecFor(impl, upper, from, static_cast<double>(key), ui));
                    continue;
                }
                if(mode==UpperVoiceMode::Poly&&hasSourceGlide(impl,upper,ui)){
                    // Polyphonic notes retain all their voices; a rolled chord
                    // shares one previous-note anchor but each oscillator uses
                    // its own saved Enable/Fingered/Time controls.
                    const auto u=static_cast<std::size_t>(ui);
                    auto& poly=impl.polyKeys[u];
                    const bool sameChord=polyKeyWasHeld&&poly.chordActive&&
                        impl.frameClock-poly.chordStart<static_cast<std::uint64_t>(0.050*impl.sampleRate);
                    if(!sameChord){
                        impl.polyAnchorKey[u]=impl.polyLastKey[u];
                        poly.chordStart=impl.frameClock;poly.chordActive=true;
                    }
                    sourcePreviousKey=static_cast<double>(impl.polyAnchorKey[u]);
                }else impl.polyKeys[static_cast<std::size_t>(ui)].chordActive = false;
                impl.polyLastKey[static_cast<std::size_t>(ui)] = key;
                playUpperNote(impl, stateOwner, ui, upper, e.channel, key, e.data2,
                              -1.0,0.0F,sourcePreviousKey,sourceKeyWasHeld);
            }
            break;
        }
        case EventType::NoteOff:
            keyboardNoteOff(impl, stateOwner, channel, e.data1, noteInputAllowed,e.data2);
            break;
        case EventType::SoftChannelRelease:
            for(auto& voice:impl.voices)
                if(voice.active&&voice.channel==channel)softKill(impl,voice,kTakeoverFadeSec);
            ch.sustain=false;
            impl.tercaKey[channel].fill(-1);
            impl.tercaRefs[channel].fill(0U);
            for(int ui=0;ui<kPartCount;++ui){
                if(state.combi.part(ui).midiChannel==channel)
                    impl.mono[static_cast<std::size_t>(ui)]=SamplerEngine::Impl::MonoKeys{};
                if(impl.polyKeys[static_cast<std::size_t>(ui)].channel==channel)
                    clearPolyKeys(impl,static_cast<std::size_t>(ui));
            }
            break;
        case EventType::ResetSourceChannel:
            // Ordered internal pattern reset, separate from live CC121.
            ch.sustain=false;
            releaseSustained(impl,channel);
            ch=SamplerEngine::Impl::ChannelState{};
            for(const auto cc:{7U,10U,11U,91U,93U,94U}){
                const auto value=static_cast<std::uint8_t>(cc==7U||cc==11U?127U:cc==10U?64U:0U);
                ch.cc[cc]=static_cast<float>(value)*kInv127;ch.ccSeen[cc]=true;
                if(cc==state.global.expressionCc){
                    ch.expression=calibratedController(value,state.global.expressionMin,state.global.expressionMax,state.global.expressionCurve);
                    ch.expressionMidi=value;
                }
                if(cc==state.global.breathCc){
                    ch.breath=calibratedController(value,state.global.breathMin,state.global.breathMax,state.global.breathCurve);
                    ch.breathMidi=value;
                }
            }
            break;
        case EventType::ControlChange:
            // Safety CCs remain active even when ordinary CCs are filtered.
            if (e.data1 == 120U || e.data1 == 123U) {
                for (auto& v : impl.voices) if (v.active && v.channel == e.channel) { v.ampEnv.forceOff(); v.active = false; }
                ch.sustain = false;
                impl.tercaKey[channel].fill(-1);
                impl.tercaRefs[channel].fill(0U);
                for (int ui = 0; ui < kPartCount; ++ui) {
                    if (state.combi.part(static_cast<int>(static_cast<std::size_t>(ui))).midiChannel == (e.channel & 0x0FU)) {
                        impl.mono[static_cast<std::size_t>(ui)] = SamplerEngine::Impl::MonoKeys{};
                    }
                    if (impl.polyKeys[static_cast<std::size_t>(ui)].channel == channel) clearPolyKeys(impl, static_cast<std::size_t>(ui));
                }
                break;
            }
            if (resetControllers) {
                // CC121 must release the damper even after the channel or CC
                // input was filtered. Leave physically held notes sounding;
                // the other (ordinary) controller routes still obey filters.
                ch.sustain = false;
                releaseSustained(impl, channel);
            } else if (damperEvent && (damperRelease || !state.global.filterControlChange)) {
                const bool old = ch.sustain;
                ch.sustain = damperDown;
                if (old && !ch.sustain) releaseSustained(impl, channel);
            }
            // A release admitted for cleanup must not also change ordinary
            // controller routes, breath or expression while input is filtered.
            if (!channelAllowed || state.global.filterControlChange) break;
            ch.cc[static_cast<std::size_t>(e.data1 & 0x7FU)] = static_cast<float>(e.data2) * kInv127;
            ch.ccSeen[static_cast<std::size_t>(e.data1&127U)]=true;
            if(ch.sourceSoundEditReader.controller(ch.sourceSoundEdits,e.data1,e.data2)){
                int target=e.data1;
                if(target==121)target=65;
                else if(target==6||target==96||target==97){
                    switch(ch.sourceSoundEditReader.lsb){
                        case 9:target=77;break;case 32:target=74;break;case 33:target=71;break;
                        case 99:target=73;break;case 100:target=75;break;case 102:target=72;break;
                        default:target=-1;break;
                    }
                }
                const unsigned bit=target>=71&&target<=78?static_cast<unsigned>(target-71):target==5?8U:9U;
                if(target==5||target==65||(target>=71&&target<=78))
                    ch.sourceEditTouched=static_cast<std::uint16_t>(ch.sourceEditTouched|(1U<<bit));
                if((target==5||target==65)&&!impl.preparedState&&!impl.channelMixEnabled.load(std::memory_order_relaxed)){
                    const std::uint8_t mask=target==5?1U:2U;
                    for(int part=0;part<kPartCount;++part)
                        if((state.combi.part(part).midiChannel&15U)==channel)
                            impl.keyboardPortamentoOverride[part]&=static_cast<std::uint8_t>(~mask);
                }
            }
            if(e.data1==121U){
                // Sound controllers71..78 and their NRPN values are retained.
                // Reset the documented MIDI1 momentary/expressive controls;
                // selector reset is handled above. CC5,7,10 and other saved
                // or undocumented controller policies remain unchanged.
                ch.pitchBend=0;ch.pressure=0.0F;ch.polyPressure.fill(0.0F);
                for(const auto cc:{1U,11U,64U,65U,66U,67U}){
                    const auto value=static_cast<std::uint8_t>(cc==11U?127U:0U);
                    ch.cc[cc]=static_cast<float>(value)*kInv127;ch.ccSeen[cc]=true;
                    // These caches follow their configured physical CC using
                    // exactly the same calibration as an ordinary CC event.
                    if(cc==state.global.breathCc){
                        ch.breath=calibratedController(value,state.global.breathMin,state.global.breathMax,state.global.breathCurve);
                        ch.breathMidi=value;
                    }
                    if(cc==state.global.expressionCc){
                        ch.expression=calibratedController(value,state.global.expressionMin,state.global.expressionMax,state.global.expressionCurve);
                        ch.expressionMidi=value;
                    }
                }
            }
            // Conventional normalized MIDI mixing, not a claimed Pa5X fader
            // transfer law. CC11 expression remains an independent multiplier.
            if (e.data1 == 7U) ch.midiVolume = static_cast<float>(e.data2) * kInv127;
            else if (e.data1 == 10U) ch.midiPan = e.data2<=1U?-1.0F:(e.data2 >= 64U ?
                static_cast<float>(static_cast<int>(e.data2)-64) / 63.0F :
                static_cast<float>(static_cast<int>(e.data2)-64) / 63.0F);
            if (e.data1 != 121U && e.data1 == state.global.breathCc) {
                ch.breath = calibratedController(e.data2, state.global.breathMin, state.global.breathMax, state.global.breathCurve);
                ch.breathMidi = e.data2;
            }
            if (e.data1 != 121U && e.data1 == state.global.expressionCc) {
                ch.expression = calibratedController(e.data2, state.global.expressionMin, state.global.expressionMax, state.global.expressionCurve);
                ch.expressionMidi = e.data2;
            }
            break;
        case EventType::PitchBend:
            // Track physical position even while muted/filtered; applying it is governed by render flags.
            // Otherwise a wheel returning to centre during a patch/filter change leaves an old bend latched.
            ch.pitchBend = e.pitchBend;
            break;
        case EventType::ChannelPressure:
            ch.pressure = impl.aftertouchInputEnabled
                              ? static_cast<float>(e.data1) * kInv127
                              : 0.0F;
            break;
        case EventType::PolyPressure:
            ch.polyPressure[e.data1&127U]=impl.aftertouchInputEnabled&&channelAllowed?
                static_cast<float>(e.data2)*kInv127:0.0F;
            break;
        case EventType::Panic: panic(impl); break;
        case EventType::SelectProgram:
        case EventType::ActivatePreparedState: break; // handled by render before ordinary MIDI
    }
}

void readWithLoopCrossfade(const SincInterpolator& interp, const SampleData& sample, double position,
                           double ratio, bool looping, LoopCrossfade& crossfade, float& left, float& right) noexcept {
    if (!looping || !sample.loop.enabled || sample.loop.crossfadeFrames == 0U ||
        sample.loop.endFrame <= sample.loop.startFrame) {
        interp.readStereo(sample, position, ratio, looping, left, right);
        return;
    }
    // Cache the four endpoint reads when the interpolation window first reaches
    // the fade, rather than adding them to every read or every NOTE ON.
    if (!crossfade.ready) {
        const auto length = sample.loop.endFrame - sample.loop.startFrame;
        const auto width = std::min<std::uint64_t>(sample.loop.crossfadeFrames, length);
        if (position + 64.0 >= static_cast<double>(sample.loop.endFrame - width))
            crossfade = SincInterpolator::prepareLoopCrossfade(sample);
    }
    interp.readStereo(sample, position, ratio, looping, left, right, crossfade.ready ? &crossfade : nullptr);
}

// Publishes which part of the bank this voice will read during the next
// lookahead seconds (only the part that is not in the RAM attack prefix).
void publishVoiceWindows(SamplerEngine::Impl& impl, std::size_t vi) noexcept {
    const auto& v = impl.voices[vi];
    const std::size_t firstSlot = vi * SamplerEngine::kStreamWindowsPerVoice;
    const RawPcmView raw = (v.active && !v.sampleEnded && v.sample != nullptr &&
        v.sample->stream != nullptr && v.zone != nullptr && v.upper != nullptr)
        ? v.sample->stream->rawView() : RawPcmView{};
    if (raw.data == nullptr || raw.frames == 0U) {
        for (std::size_t offset = 0U; offset < SamplerEngine::kStreamWindowsPerVoice; ++offset)
            impl.publishWindow(firstSlot + offset, 0U, 0U);
        return;
    }
    const auto& sample = *v.sample;
    constexpr double kTapMargin = 64.0;
    const double lookaheadFrames = impl.lookaheadSec.load(std::memory_order_relaxed) * impl.sampleRate;
    // Include the last actual modulated read rate and the destination of an
    // active glide, rather than assuming the unbent base ratio is the reader.
    const double speed = std::max({0.05, std::abs(v.ratio), std::abs(v.targetRatio), std::abs(v.lastReadRatio)});
    const double frames = static_cast<double>(raw.frames);
    const double preloaded = static_cast<double>(sample.preloadedFrameCount());
    const std::size_t frameBytes = raw.frameBytes();
    const auto emit = [&](std::size_t slot, double lo, double hi) noexcept {
        lo = std::max(std::max(lo, preloaded), 0.0);
        hi = std::min(hi, frames);
        if (!(hi > lo)) { impl.publishWindow(slot, 0U, 0U); return; }
        const auto first = static_cast<std::uint64_t>(lo);
        const auto last = std::min(static_cast<std::uint64_t>(std::ceil(hi)), raw.frames);
        if (last <= first) { impl.publishWindow(slot, 0U, 0U); return; }
        impl.publishWindow(slot,
                           reinterpret_cast<std::uintptr_t>(raw.data + static_cast<std::size_t>(first) * frameBytes),
                           static_cast<std::size_t>(last - first) * frameBytes);
    };
    // Match the playback loop predicate, including SAMPLE END/loop-off and
    // reverse. The SUB reader moves independently, even on a reverse zone.
    const bool looping = sample.loop.enabled && !v.oneShot && !v.zone->reverse &&
        !v.loopOff && sample.loop.endFrame > sample.loop.startFrame;
    const double loopStart = static_cast<double>(sample.loop.startFrame);
    const double loopEnd = static_cast<double>(sample.loop.endFrame);
    const auto publishReader = [&](std::size_t slot, double position, double rate,
                                    bool reverse, bool wrapped) noexcept {
        const double look = lookaheadFrames * std::max(0.05, std::abs(rate)) + kTapMargin;
        if (reverse) {
            emit(slot, position - look, position + kTapMargin);
            impl.publishWindow(slot + 1U, 0U, 0U);
            return;
        }
        const double end = position + look;
        if (looping && end > loopEnd) {
            emit(slot, position - kTapMargin, loopEnd + kTapMargin);
            emit(slot + 1U, loopStart - kTapMargin,
                std::min(loopEnd, loopStart + (end - loopEnd)) + kTapMargin);
        } else {
            emit(slot, position - kTapMargin, end);
            // After wrapping, the interpolator's preceding taps are from the
            // loop END, not the attack immediately preceding loopStart.
            if (looping && wrapped && position < loopStart + kTapMargin)
                emit(slot + 1U, loopEnd - kTapMargin, loopEnd + kTapMargin);
            else impl.publishWindow(slot + 1U, 0U, 0U);
        }
    };
    publishReader(firstSlot, v.position, speed, v.zone->reverse, v.loopWrapped);
    const auto tone = soundToneOf(*v.upper, v.soundIndex);
    if (tone.x.subLevel > 0.0F) {
        const double divisor = tone.x.subOctave >= 2 ? 4.0 : 2.0;
        publishReader(firstSlot + 2U, v.subPosition, speed / divisor, false, v.subLoopWrapped);
    } else {
        impl.publishWindow(firstSlot + 2U, 0U, 0U);
        impl.publishWindow(firstSlot + 3U, 0U, 0U);
    }
    if (looping && sample.loop.crossfadeFrames >= 2U) {
        // The lazy crossfade descriptor reads both endpoints, possibly long
        // before the main cursor reaches the end of a wide crossfade. Hint
        // only this active sample's tiny endpoint regions, never all SET tails.
        emit(firstSlot + 4U, loopStart - kTapMargin, loopStart + kTapMargin);
        emit(firstSlot + 5U, loopEnd - kTapMargin, loopEnd + kTapMargin);
    } else {
        impl.publishWindow(firstSlot + 4U, 0U, 0U);
        impl.publishWindow(firstSlot + 5U, 0U, 0U);
    }
}

} // namespace

void SamplerEngine::render(float* out, std::uint32_t frames) noexcept {
    const int listen=listenTarget_.load(std::memory_order_relaxed);
    impl_->listenPart=(listen>>8)-2;impl_->listenKey=(listen&255)-1;
    if (out == nullptr || frames == 0U) return;
    std::memset(out, 0, static_cast<std::size_t>(frames) * 2U * sizeof(float));
    beginNumberedFxControlBlock(*impl_);

    // Adopt a complete control-thread graph only at a realtime block boundary.
    // Do not reset voices or FX: old voices own their immutable source graph and
    // continue naturally while new notes immediately use the new SOUND/COMBI.
    (void)publications_->waves.adopt(impl_->waveMap);
    (void)publications_->models.adopt(impl_->models);
    const auto refreshProgramSelections = [&](const std::shared_ptr<const RealtimeProgramBank>& previousBank,
                                               bool clearOnNewSource) noexcept {
        const bool sameSource = previousBank && impl_->programBank &&
            impl_->programBank->sourceIdentity && previousBank->sourceIdentity == impl_->programBank->sourceIdentity;
        for (std::size_t channel = 0; channel < 16; ++channel) {
            if (clearOnNewSource && !sameSource) {
                impl_->selectedProgramStates[channel].reset();
                impl_->programSelectionEnabled[channel] = false;
                impl_->selectedProgramAddresses[channel] = 0xFFFFFFFFU;
                impl_->selectedProgramRevisions[channel] = 0;
                continue;
            }
            if (!impl_->programSelectionEnabled[channel]) continue;
            std::shared_ptr<const EngineState> refreshed;
            if (sameSource) {
                const auto address = impl_->selectedProgramAddresses[channel];
                const auto key = (static_cast<std::uint32_t>(channel) << 24) | address;
                const auto& routes = impl_->programBank->routes;
                const auto found = std::lower_bound(routes.begin(),routes.end(),key,
                    [](const RealtimeProgramRoute& route,std::uint32_t wanted) {
                        return ((static_cast<std::uint32_t>(route.channel) << 24) |
                            (static_cast<std::uint32_t>(route.msb) << 16) |
                            (static_cast<std::uint32_t>(route.lsb) << 8) | route.program) < wanted;
                    });
                if (found != routes.end() && found->channel == channel &&
                    ((static_cast<std::uint32_t>(found->msb) << 16) |
                     (static_cast<std::uint32_t>(found->lsb) << 8) | found->program) == address) refreshed = found->state;
            }
            impl_->selectedProgramStates[channel] = std::move(refreshed);
            impl_->selectedProgramRevisions[channel] = sameSource ? impl_->programBank->revision : 0;
        }
    };
    const auto applyBaseState = [&](std::shared_ptr<const EngineState> next) noexcept {
        if(!next)return;
        const bool hadState = state_ != nullptr;
        const auto oldDamperCc = hadState ? state_->global.damperCc : 64U;
        const bool oldDamperReversed = hadState && state_->global.damperPolarityReversed;
        const bool recalledPerformance=hadState&&state_->combiGeneration!=next->combiGeneration;
        if(!impl_->sourcePerformanceOwnerValid||impl_->sourcePerformanceGeneration!=next->combiGeneration){
            // Capture the last ordered source controls before a new performance
            // owns the channel. Held old voices keep that snapshot, while their
            // physical NoteOff/damper cleanup remains active.
            for(auto& voice:impl_->voices)if(voice.active&&voice.sourcePerformanceGeneration==impl_->sourcePerformanceGeneration)
                captureSourceControls(*impl_,voice);
            for(auto& channel:impl_->channels){
                channel.sourceSoundEdits={};channel.sourceSoundEditReader={};channel.sourceEditTouched=0U;
            }
            impl_->sourcePerformanceGeneration=next->combiGeneration;impl_->sourcePerformanceOwnerValid=true;
            impl_->keyboardPortamentoOverride.fill(0U);
        }else if(hadState&&!impl_->preparedState&&!impl_->channelMixEnabled.load(std::memory_order_relaxed)){
            for(int part=0;part<kPartCount;++part){
                const auto& before=state_->combi.part(part);
                const auto& after=next->combi.part(part);
                if(!after.livePartMix)continue;
                bool changedSound=before.program!=after.program||before.midiChannel!=after.midiChannel;
                for(int layer=0;layer<kUpperLayers;++layer)
                    changedSound|=before.layers[layer].program!=after.layers[layer].program;
                if(changedSound||before.sourceSoundEdits.controller(5)!=after.sourceSoundEdits.controller(5))
                    impl_->keyboardPortamentoOverride[part]|=1U;
                if(changedSound||before.sourceSoundEdits.controller(65)!=after.sourceSoundEdits.controller(65))
                    impl_->keyboardPortamentoOverride[part]|=2U;
            }
        }
        if(hadState&&impl_->lowerMemoryApplied){
            const auto& before=state_->combi.part(kKeyboardLower);
            const auto& after=next->combi.part(kKeyboardLower);
            if(recalledPerformance||before.midiChannel!=after.midiChannel||before.performanceKeyLow!=after.performanceKeyLow||
                before.performanceKeyHigh!=after.performanceKeyHigh||before.keyLow!=after.keyLow||before.keyHigh!=after.keyHigh||
                before.mute!=after.mute||before.enabled!=after.enabled||
                state_->global.filterNotes!=next->global.filterNotes||
                state_->global.midiInputChannelMask!=next->global.midiInputChannelMask){
                flushLowerMemory(*impl_,state_,false);impl_->lowerPhysical={};
            }
        }
        if (hadState && !recalledPerformance) {
            for (int part=0;part<kPartCount;++part) {
                const auto& before=state_->combi.part(part);
                const auto& after=next->combi.part(part);
                if (effectiveVoiceMode(before)==UpperVoiceMode::Poly && effectiveVoiceMode(after)!=UpperVoiceMode::Poly)
                    adoptMonoLine(*impl_,*next,part);
            }
        }
        state_=std::move(next);
        const auto& g = state_->global;
        impl_->aftertouchInputEnabled=g.aftertouchEnabled&&!g.filterAftertouch;
        if(!impl_->aftertouchInputEnabled){
            // Clear latched pressure at the configuration boundary. Re-enabling
            // after filtering starts from zero until a fresh pressure event.
            for(auto& channel:impl_->channels){channel.pressure=0.0F;channel.polyPressure.fill(0.0F);}
        }
        if(recalledPerformance){
            // Held voices retain their owners and sustain state. Key stacks
            // belong to the newly recalled performance: releasing an old mono
            // key must not retrigger another old held key with the new Sound.
            for(auto& keys:impl_->mono)keys=Impl::MonoKeys{};
            impl_->monoWas.fill(false);
            for(std::size_t ui=0;ui<impl_->polyKeys.size();++ui)clearPolyKeys(*impl_,ui);
            impl_->polyLastKey.fill(-1);impl_->polyAnchorKey.fill(-1);
        }
        // Keep coefficient/controller preparation aligned with the exact paired
        // activation, including when the token occurs between queued MIDI events.
        if (hadState && (oldDamperCc != g.damperCc || oldDamperReversed != g.damperPolarityReversed)) {
            for (std::size_t channel = 0; channel < impl_->channels.size(); ++channel) {
                impl_->channels[channel].sustain = false;
                releaseSustained(*impl_, static_cast<std::uint8_t>(channel));
            }
        }
        impl_->lowEq.setShelf(impl_->sampleRate, 120.0F, g.eqLowDb, false);
        impl_->midEq.setPeaking(impl_->sampleRate, 1200.0F, 0.75F, g.eqMidDb);
        impl_->highEq.setShelf(impl_->sampleRate, 7000.0F, g.eqHighDb, true);
        for (int i = 0; i < kPartCount; ++i) {
            const auto index = static_cast<std::size_t>(i);
            const auto& u = state_->combi.part(static_cast<int>(index));
            std::uint16_t routeMask = 0U;
            for (const auto& route : u.controllerRoutes) {
                if (route.source == ControllerSource::Off || std::abs(route.amount) <= 1.0e-9F) continue;
                routeMask = static_cast<std::uint16_t>(routeMask | static_cast<std::uint16_t>(1U << static_cast<unsigned>(route.destination)));
            }
            impl_->upperRouteMask[index] = routeMask;
        }
        syncNumberedFxControlOwner(*impl_, *state_);
    };
    const auto applyPrepared = [&]() noexcept {
        const auto previous=impl_->programBank;
        impl_->programBank=impl_->preparedState->bank;
        refreshProgramSelections(previous,true);
        applyBaseState(impl_->preparedState->state);
    };
    // Live mixer edits may refresh the currently committed source only. A
    // prepared next Style is registered off audio and becomes current solely
    // through its queued activation token at the arranger's Style boundary.
    if(publications_->preparedStates.adoptIf(impl_->preparedState,[&](const auto& candidate) noexcept {
        return candidate && (!impl_->preparedState ||
            candidate->bank->sourceIdentity==impl_->preparedState->bank->sourceIdentity);
    }))applyPrepared();
    if(!impl_->preparedState){
        const auto previous=impl_->programBank;
        if(publications_->programBanks.adopt(impl_->programBank))refreshProgramSelections(previous,false);
        auto next=state_;
        if(publications_->states.adopt(next))applyBaseState(std::move(next));
    }

    auto current = state_; // audio-owned; registration keeps final destructors off this thread
    if (current == nullptr) return;
    syncLowerMemory(*impl_,current);
    // Also initializes bindings when a renderer starts with an already-owned
    // state rather than adopting a fresh publication in this block.
    syncNumberedFxControlOwner(*impl_, *current);
    if(!impl_->sourcePerformanceOwnerValid){
        impl_->sourcePerformanceGeneration=current->combiGeneration;impl_->sourcePerformanceOwnerValid=true;
    }
    impl_->sourceTempoBpm=impl_->sourceTempoRequested.load(std::memory_order_acquire);
    const auto renderStart = std::chrono::steady_clock::now();   // SILVETON_CPU_METER_V1

    RealtimeEvent ev{};
    while (events_.pop(ev)) {
        const auto channel = static_cast<std::size_t>(ev.channel & 15U);
        if(ev.type==EventType::ActivatePreparedState){
            const auto* prepared=ev.preparedState;
            if(prepared&&prepared->owner_.load(std::memory_order_acquire)==publications_.get()){
                using Node=GraphPublication<PreparedSamplerState>::Node;
                auto* node=static_cast<Node*>(prepared->registration_.load(std::memory_order_acquire));
                if(node){
                    publications_->preparedStates.adoptRegistered(node,impl_->preparedState);
                    applyPrepared();current=state_;
                }
                prepared->queuedPosts_.fetch_sub(1U,std::memory_order_acq_rel);
            }
            continue;
        }
        if (ev.type == EventType::SelectProgram) {
            auto& selected = impl_->selectedProgramStates[channel];
            const bool enabled = ev.programAddress != 0xFFFFFFFFU;
            std::shared_ptr<const EngineState> next;
            if (enabled && impl_->programBank && (impl_->programBank->revision == ev.programRevision ||
                (ev.programSourceIdentity && impl_->programBank->sourceIdentity == ev.programSourceIdentity))) {
                const auto key = (static_cast<std::uint32_t>(channel) << 24) | ev.programAddress;
                const auto& routes = impl_->programBank->routes;
                const auto found = std::lower_bound(routes.begin(), routes.end(), key,
                    [](const RealtimeProgramRoute& route, std::uint32_t wanted) {
                        return ((static_cast<std::uint32_t>(route.channel) << 24) |
                            (static_cast<std::uint32_t>(route.msb) << 16) |
                            (static_cast<std::uint32_t>(route.lsb) << 8) | route.program) < wanted;
                    });
                if (found != routes.end() && found->channel == channel &&
                    ((static_cast<std::uint32_t>(found->msb) << 16) |
                     (static_cast<std::uint32_t>(found->lsb) << 8) | found->program) == ev.programAddress) next = found->state;
            }
            // An absent/mismatched route is an explicit silent gate. Never keep
            // the preceding Sound alive as the instrument for new notes.
            if (impl_->programSelectionEnabled[channel] != enabled ||
                (enabled && impl_->selectedProgramAddresses[channel] != ev.programAddress)) {
                const RealtimeEvent release{EventType::SoftChannelRelease,static_cast<std::uint8_t>(channel),0U,0U,0};
                processEvent(*impl_, selected ? selected : current, release);
                captureNumberedFxOtherEvent(*impl_, *current, release);
            }
            selected = std::move(next);
            impl_->programSelectionEnabled[channel] = enabled;
            impl_->selectedProgramAddresses[channel] = ev.programAddress;
            impl_->selectedProgramRevisions[channel] = impl_->selectedProgramStates[channel] && impl_->programBank ? impl_->programBank->revision : ev.programRevision;
            continue;
        }
        const bool newNote = ev.type == EventType::NoteOn && ev.data2 > 0;
        const auto& selected = impl_->selectedProgramStates[channel];
        // A missing factory/sample Program silences its voice, not the real
        // MIDI stream of a selected modulating track.
        if (newNote) captureNumberedFxNoteOn(*impl_, *current, ev);
        if (newNote && impl_->programSelectionEnabled[channel] &&
            (!selected || !impl_->programBank || impl_->selectedProgramRevisions[channel] != impl_->programBank->revision)) continue;
        processEvent(*impl_, selected && impl_->programSelectionEnabled[channel] ? selected : current, ev);
        if (!newNote) captureNumberedFxOtherEvent(*impl_, *current, ev);
    }
    impl_->frameClock += frames;

    // SILVETON_EQ5_V1 / SILVETON_TONE_V2: the common EQ of every Upper and the
    // HP + 3-band EQ of every sound follow the state once per block (smoothed).
    {
        const float eqAlpha = static_cast<float>(1.0 - std::exp(-static_cast<double>(frames) / (0.020 * impl_->sampleRate)));
        for (std::size_t ui = 0; ui < static_cast<std::size_t>(kPartCount); ++ui) {
            const auto& u = current->combi.part(static_cast<int>(ui));
            impl_->upperEq[ui].update(u.eq, impl_->sampleRate, eqAlpha);
            impl_->channelGates[ui].update(u.channelGate);
            for (int s = 0; s < kSoundsPerUpper; ++s) {
                const UpperLayer* ul = layerOf(u, s);
                impl_->soundBus[ui][static_cast<std::size_t>(s)].update(ul != nullptr ? ul->tone.x : u.toneExtra, impl_->sampleRate);
            }
        }
    }

    // Live TONE values (ADSR times, SUSTAIN, CUTOFF, RESONANCE, FILTER ENV,
    // VEL->CUTOFF, vibrato) of the current Upper state, once per block per voice.
    {
        const double blockAlpha = 1.0 - std::exp(-static_cast<double>(frames) / (0.012 * impl_->sampleRate));
        const float openLog = std::log(kToneCutoffOpenHz);
        const double blockSec = static_cast<double>(frames) / impl_->sampleRate;
        for (auto& v : impl_->voices) {
            if (!v.active || v.layer == nullptr || v.upper == nullptr) continue;
            const auto uix = static_cast<std::size_t>(std::clamp(v.upperIndex, 0, kPartCount - 1));
            // SILVETON_LIVE_EDIT_V1: the note follows the newest settings of its Upper
            // while that Upper still plays the same Sound in the same open
            // performance. A recalled Keyboard Set can share the Program but
            // must not replace the saved mix/tuning of notes already sounding.
            if (v.ownerState.get() != current.get()) {
                const auto& routed = impl_->selectedProgramStates[v.channel & 15U];
                const auto& newestOwner = impl_->programSelectionEnabled[v.channel & 15U] && routed ? routed : current;
                const auto& now = newestOwner->combi.part(static_cast<int>(uix));
                if (v.ownerState->combiGeneration == newestOwner->combiGeneration &&
                    playProgramOf(now, v.soundIndex) != nullptr && playProgramOf(*v.upper, v.soundIndex) == playProgramOf(now, v.soundIndex) && soundSource(*v.upper,v.soundIndex).soloModel == soundSource(now,v.soundIndex).soloModel) {
                    v.ownerState = newestOwner;
                    v.upper = &now;
                    v.routeMask = impl_->upperRouteMask[uix];
                }
            }
            const UpperLayer* ul = layerOf(*v.upper, v.soundIndex);
            const double tune = liveTuneSemis(*v.upper, current->global, v.key,
                ((impl_->scaleUppers.load(std::memory_order_relaxed) >> v.upperIndex) & 1) != 0, ul,!v.zone->nonTranspose) + (static_cast<double>(v.unisonCents)+liveKeyOf(*v.upper,v.key).tune) / 100.0;
            if (tune != v.tuneSemis) {
                const double m = std::exp2((tune - v.tuneSemis) / 12.0);
                v.ratio *= m;
                v.targetRatio *= m;
                v.tuneSemis = tune;
            }
            const SoundTone st = soundToneOf(*v.upper, v.soundIndex);
            // SILVETON_SYNTH_BYPASS_V1: a unison copy still sounding after SYNTH ИЗКЛ fades out
            if (v.unisonIndex > 0 && st.x.unisonVoices <= 1 && !v.fading) softKill(*impl_, v, 0.004F);
            // A part can stop accepting CC64 while the pedal is still down.
            if (v.sustained && !v.keyHeld && !v.upper->damperEnabled) releasePedalVoice(*impl_,v);
            const bool wasOneShot=v.oneShot,wasEditedCurve=v.editCurve;
            if(v.sourcePerformanceGeneration==impl_->sourcePerformanceGeneration)captureSourceControls(*impl_,v);
            refreshSourceAmp(*impl_,v,current->global);
            v.sourceOscillator.controlCountdown=0U;
            v.sourceAmpControlCountdown=0U;
            UpperToneValues tv = voiceTone(v,st,*v.upper);
            if(!wasEditedCurve&&v.editCurve&&v.curvePeak>0){
                // Adopt the envelope at the sounding amplitude. The sample and
                // cursor keep their positions, including on repeated edits.
                const float currentCurve=v.sampleDecay.value+(v.curvePeak-v.sampleDecay.value)*v.curveBlend;
                v.ampEnv.value*=std::clamp(currentCurve/v.curvePeak,0.0F,1.0F);
                v.curveBlend=1;
                if(v.ampEnv.stage!=AmpEnv::Stage::Release){
                    if(v.sampleDecay.segment<=1&&v.layer->sampleDecay.targets[0]>v.sampleDecay.value)
                        v.ampEnv.stage=AmpEnv::Stage::Attack;
                    else v.ampEnv.stage=v.ampEnv.value>tv.sustain?AmpEnv::Stage::Decay:AmpEnv::Stage::Sustain;
                }
            }
            if(!v.ampEnv.sourceEnabled&&v.upper->livePartMix&&tv.sustain!=v.ampEnv.sustainTarget){
                if(v.ampEnv.stage==AmpEnv::Stage::Sustain&&tv.sustain<v.ampEnv.value)
                    v.ampEnv.stage=AmpEnv::Stage::Decay;
                else if(v.ampEnv.stage==AmpEnv::Stage::Decay&&tv.sustain>v.ampEnv.value)
                    v.ampEnv.stage=AmpEnv::Stage::Sustain;
            }
            {   // SILVETON_VELOCITY_V1: VELOCITY -> ATTACK (a soft key press has a longer attack; v.velNorm is the shaped strength)
                const VelocityShape& vShape = ul != nullptr ? ul->velocityShape : v.upper->velocityShape;
                if (vShape.toAttack > 0.0F) tv.attackMs = std::min(tv.attackMs + velocityAttackExtraMs(vShape, v.velNorm), kToneMaxTimeMs);
            }
            // FILTER ENV: 1 at the start of the note, down to 0 in FILTER ENV time (exponential).
            {
                const double ms = std::clamp(static_cast<double>(st.x.filterEnvMs), 1.0, 20000.0);
                v.filterEnvValue *= static_cast<float>(std::exp(-blockSec * 1000.0 / ms * 4.6));   // -40 dB at FILTER ENV time
            }
            // SILVETON_POLYSIX_V1: the modulation matrix of this sound, once per block
            {
                const auto& ch = impl_->channels[v.channel & 0x0FU];
                v.modCutOct = v.modRes = v.modCut2Oct = v.modLevelDb = v.modPan = v.modPitch = v.modLfoCents = v.modPwm = v.modDrive = 0.0F;
                v.modLfoRateMul = v.modAttackMul = v.modReleaseMul = 1.0F;
                for (const auto& r : st.mod.route) {
                    if (r.source == ModSource::Off || r.amount == 0.0F) continue;
                    if (r.source == ModSource::Aftertouch && (!v.upper->aftertouchEnabled || !impl_->aftertouchInputEnabled)) continue;
                    float x = 0.0F; bool bip = false;
                    switch (r.source) {
                        case ModSource::Off: break;
                        case ModSource::Velocity: x = v.velNorm; break;
                        case ModSource::Note: x = (static_cast<float>(v.key) - 60.0F) / 60.0F; bip = true; break;
                        case ModSource::Aftertouch: x = ch.pressure; break;
                        case ModSource::ModWheel: x = ch.cc[1]; break;
                        case ModSource::Breath: x = ch.breath; break;
                        case ModSource::Expression: x = ch.expression; break;
                        case ModSource::Pedal: x = ch.sustain ? 1.0F : 0.0F; break;
                        case ModSource::Bend: x = static_cast<float>(ch.pitchBend) / 8192.0F; bip = true; break;
                        case ModSource::Lfo: x = static_cast<float>(std::sin(v.vibPhase)); bip = true; break;
                        case ModSource::FilterEnv: x = v.filterEnvValue; break;
                        case ModSource::AmpEnv: x = v.ampEnv.value; break;
                        case ModSource::Random: x = v.random; bip = true; break;
                    }
                    if (r.bipolar && !bip) x = x * 2.0F - 1.0F;
                    const float a = std::clamp(r.amount, -1.0F, 1.0F) * x;
                    switch (r.target) {
                        case ModTarget::Cutoff: v.modCutOct += a * 4.0F; break;
                        case ModTarget::Resonance: v.modRes += a; break;
                        case ModTarget::Cutoff2: v.modCut2Oct += a * 4.0F; break;
                        case ModTarget::Level: v.modLevelDb += a * 24.0F; break;
                        case ModTarget::Pan: v.modPan += a; break;
                        case ModTarget::Pitch: v.modPitch += a * 12.0F; break;
                        case ModTarget::LfoDepth: v.modLfoCents += a * 100.0F; break;
                        case ModTarget::LfoRate: v.modLfoRateMul *= std::exp2(a * 2.0F); break;
                        case ModTarget::PwmWidth: v.modPwm += a * 0.45F; break;
                        case ModTarget::Drive: v.modDrive += a; break;
                        case ModTarget::Attack: v.modAttackMul *= std::exp2(a * 3.0F); break;
                        case ModTarget::Release: v.modReleaseMul *= std::exp2(a * 3.0F); break;
                    }
                }
                if (v.modAttackMul != 1.0F) tv.attackMs = std::clamp(tv.attackMs * v.modAttackMul, 0.0F, kToneMaxTimeMs);
                if (v.modReleaseMul != 1.0F) tv.releaseMs = std::clamp(tv.releaseMs * v.modReleaseMul, 0.0F, kToneMaxTimeMs);
                tv.resonance = std::clamp(tv.resonance + v.modRes, 0.0F, 1.0F);
            }
           // the envelopes of SILVETON SYNTH decide how long a note lasts: the amplifier of the sampler only keeps the voice
            // alive (it never cuts the sound) until SILVETON SYNTH says it is quiet
            if (v.so != nullptr && !soundSource(*v.upper,v.soundIndex).commonProcessing) { tv.sustain = 1.0F; tv.releaseMs = kMaxFallbackMs; }
            v.ampEnv.setBlock(tv, impl_->sampleRate);
            if(wasOneShot&&!v.oneShot&&!v.keyHeld&&!v.sustained&&!v.fading&&v.ampEnv.stage!=AmpEnv::Stage::Release){
                const bool pedal=impl_->channels[v.channel&15U].sustain&&v.upper->damperEnabled&&v.layer->damperEnabled;
                if(pedal)v.sustained=true;
                else{prepareSourceRelease(*impl_,v);v.ampEnv.release(impl_->sampleRate);v.filterEnv.release(impl_->sampleRate);v.pitchEnv.release(impl_->sampleRate);}
            }

            if (v.so != nullptr) {
                const auto& sp=soundSource(*v.upper,v.soundIndex).engine;
                if (sp.type!=EngineType::Solo || !sp.on()) {if (!v.fading) softKill(*impl_,v,0.01F);}
                else {v.so->setParams(sp.p.data());v.so->setInputs(soloInputsOf(*impl_,v),impl_->sampleRate);}
            }

            // SILVETON_ENGINES_V1: the per-note part of the ENGINE, once per block (filter envelope, LFO, EG1, FM depth ...)

            float envOct = 0.0F;
            if (st.x.filterEnvOctaves != 0.0F) envOct = std::clamp(st.x.filterEnvOctaves, -8.0F, 8.0F) * v.filterEnvValue;
            const float keyTrackOct = std::clamp(st.x.filterKeyTrack, -1.0F, 1.0F) * (static_cast<float>(v.key) - 60.0F) / 12.0F;
            const float extraOct = envOct + v.velCutoffOct + v.modCutOct + keyTrackOct + (st.x.analogFeel ? v.random * 0.08F : 0.0F);
            v.sourceToneExtraOctaves=extraOct;
            // filter type of CUTOFF (clean / POLYSIX ladder / KORG35 / HP / BP) - a change resets the new filter's state
            if (v.filterTypeNow != st.x.filterType) { v.filterTypeNow = st.x.filterType; v.ladder.prime = true; v.korg35.prime = true; v.toneLp.prime = true; v.toneSvf.reset(); }
            // second filter
            if (st.x.filter2Type != 0) {
                const float hz2 = std::clamp(st.x.filter2Hz * std::exp2(v.modCut2Oct), 20.0F, kToneCutoffOpenHz);
                v.filter2Hz = hz2; v.filter2Res = std::clamp(st.x.filter2Res, 0.0F, 1.0F);
            }
            // PWM width of this block
            if (st.x.pwmWidth > 0.0F && v.periodFrames > 0.0) {
                v.pwmPhase += 2.0 * kPi * std::clamp(static_cast<double>(st.x.pwmRateHz), 0.02, 20.0) * blockSec;
                if (v.pwmPhase > 2.0 * kPi) v.pwmPhase -= 2.0 * kPi;
                v.pwmWidthNow = std::clamp(st.x.pwmWidth + v.modPwm + st.x.pwmDepth * static_cast<float>(std::sin(v.pwmPhase)), 0.02F, 0.98F);
            } else {
                v.pwmWidthNow = 0.0F;
            }
            // SILVETON_TRANSWAVE_V1: where in the row of frames this note is now (once per block, smoothed per sample later)
            if (v.waveTable != nullptr) {
                const auto& chw = impl_->channels[v.channel & 0x0FU];
                float src = 0.0F;
                switch (st.x.waveSource) {
                    case 1: src = static_cast<float>(std::clamp(v.waveAge / (std::max(1.0, static_cast<double>(st.x.waveTimeMs)) * 0.001), 0.0, 1.0)); break;
                    case 2: v.waveLfoPhase += 2.0 * kPi * std::clamp(static_cast<double>(st.x.waveRateHz), 0.02, 30.0) * blockSec;
                            if (v.waveLfoPhase > 2.0 * kPi) v.waveLfoPhase -= 2.0 * kPi;
                            src = static_cast<float>(std::sin(v.waveLfoPhase)); break;
                    case 3: src = v.velNorm; break;
                    case 4: src = chw.cc[1]; break;
                    case 5: src = v.upper->aftertouchEnabled&&impl_->aftertouchInputEnabled ? chw.pressure : 0.0F; break;
                    case 6: src = std::clamp((static_cast<float>(v.key) - 36.0F) / 60.0F, 0.0F, 1.0F); break;
                    default: break;
                }
                const float pos = std::clamp(st.x.wavePos + (st.x.waveSource != 0 ? std::clamp(st.x.waveAmount, -1.0F, 1.0F) * src : 0.0F), 0.0F, 1.0F);
                v.wavePosPrev = v.waveInit ? v.wavePosNow : pos;
                v.wavePosNow = pos;
                v.waveInit = true;
                v.waveAge += blockSec;
            }
            const bool wantOn = tv.cutoffHz < kToneCutoffOpenHz - 1.0F || extraOct < -0.001F;
            if (wantOn && !v.toneOn) { v.toneOn = true; v.toneLog = openLog; v.toneLp.prime = true; }
            if (v.toneOn) {
                const float target = tv.cutoffHz < kToneCutoffOpenHz - 1.0F ? std::log(tv.cutoffHz) : openLog;
                v.toneLog += (target - v.toneLog) * static_cast<float>(blockAlpha);
                const float hz = std::clamp(std::exp(v.toneLog + extraOct * 0.69314718F), 20.0F, kToneCutoffOpenHz);
                if (!wantOn && v.toneLog >= openLog - 0.05F) v.toneOn = false;
                if (v.filterTypeNow == 1) v.ladder.set(hz, tv.resonance, impl_->sampleRate);
                else if (v.filterTypeNow == 2) v.korg35.set(hz, tv.resonance, impl_->sampleRate);
                else if (v.filterTypeNow >= 3) { v.toneFilterHz = hz; v.toneFilterRes = tv.resonance; }   // SILVETON_ENGINES_V1: HP12 / BP12
                else v.toneLp.set(hz, tv.resonance, impl_->sampleRate);
            }
            // Vibrato (TONE LFO): depth from the TONE page, scaled by the modulation wheel if chosen.
            v.vibSemis = static_cast<double>(v.modPitch);   // SILVETON_ENGINES_V1: + the ENGINE's LFO / EG1 / pitch EG
            {
                const auto& ch = impl_->channels[v.channel & 0x0FU];
                const float wheel = st.x.lfoModWheel ? ch.cc[1] : 1.0F;
                v.vibAgeSec += blockSec;
                v.vibPhase += 2.0 * kPi * std::clamp(static_cast<double>(st.x.lfoRateHz * v.modLfoRateMul), 0.05, 30.0) * blockSec;
                if (v.vibPhase > 2.0 * kPi) v.vibPhase -= 2.0 * kPi;
                const float depthCents = std::clamp(st.x.lfoDepthCents * wheel + v.modLfoCents, 0.0F, 1200.0F);
                const double delay = std::max(0.0, static_cast<double>(st.x.lfoDelayMs)) * 0.001;
                double fade = 1.0;
                if (v.vibAgeSec < delay) fade = 0.0;
                else if (st.x.lfoFadeMs > 0.0F) fade = std::clamp((v.vibAgeSec - delay) / (static_cast<double>(st.x.lfoFadeMs) * 0.001), 0.0, 1.0);
                if (depthCents > 0.0F && fade > 0.0) {
                    v.vibSemis += std::sin(v.vibPhase) * static_cast<double>(depthCents) * 0.01 * fade;
                }
            }
        }
    }

    float peakL = 0.0F, peakR = 0.0F;
    std::array<float, kPartCount> upperPeakL{};
    std::array<float, kPartCount> upperPeakR{};
    const float masterGain = dbToGain(current->global.masterGainDb);
    const bool limiterOn = current->global.limiterEnabled;
    const float ceilingDb = std::isfinite(current->global.limiterCeilingDb)
        ? std::clamp(current->global.limiterCeilingDb, -12.0F, 0.0F) : -6.0F;
    const float limiterCeiling = dbToGain(ceilingDb);
    const float limiterRelease = static_cast<float>(1.0 - std::exp(-1.0 / (0.080 * impl_->sampleRate)));
    float minimumLimiterGain = 1.0F;
    if (!limiterOn) impl_->limiterGain = 1.0F;
    const float mixSmooth = static_cast<float>(1.0 - std::exp(-1.0 / (kLiveMixSmoothSec * impl_->sampleRate)));
    const bool channelMixOn = impl_->channelMixEnabled.load(std::memory_order_acquire);
    // SILVETON_SILK_PORTA_V1: BALANCE 3..40 controls the softness / skew of
    // the time-normalized curve instead of delaying its arrival with filters.
    // Loaded once per block, no expensive filter or allocation on audio thread.

    const int tapUpperNow = impl_->tapUpper.load(std::memory_order_acquire);
    const bool tapAfterNow = impl_->tapAfter.load(std::memory_order_relaxed);
    std::uint32_t tapW = impl_->tapWrite.load(std::memory_order_relaxed);

    // SILVETON_FX_TAIL_V1: another BLEND was called up -> an effect that changes keeps
    // ringing out on its own engine; the new effect starts on the other one.
    const auto tailFadeFrames = static_cast<std::uint32_t>(0.25 * impl_->sampleRate);
    const auto tailQuietFrames = static_cast<std::uint32_t>(0.30 * impl_->sampleRate);
    {
        const auto nextSource = current->combi.sourceEffects ? current->combi.sourceEffects->masterRender :
            std::array<SourceFxRenderParameters, kFxSendSlots>{};
        if (impl_->fxRunningValid && current->combiGeneration != impl_->fxGeneration) {
            const auto oldGraph = sourceMasterGraph(impl_->fxSourceRunning);
            const auto newGraph = sourceMasterGraph(nextSource);
            const auto unionComponent = static_cast<std::uint8_t>(oldGraph.componentMask | newGraph.componentMask);
            std::uint8_t changedMask = 0U;
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                const EffectSlot& was = impl_->fxRunning[slot];
                const EffectSlot& now = current->combi.fx[slot];
                const auto& nowSource = nextSource[slot];
                const bool same = was.type == now.type && was.wet == now.wet && was.timeMs == now.timeMs &&
                                  was.feedback == now.feedback && was.rateHz == now.rateHz &&
                                  was.depth == now.depth && was.tone == now.tone && was.size == now.size &&
                                  was.preDelayMs == now.preDelayMs && was.damping == now.damping && was.mod == now.mod &&
                                  was.tempoSync == now.tempoSync && was.tempoBpm == now.tempoBpm &&
                                  was.division == now.division && was.param1 == now.param1 &&
                                  was.param2 == now.param2 && was.param3 == now.param3 &&
                                  was.numberedModulatingPart == now.numberedModulatingPart &&
                                  sameNumberedFx(was.numbered, now.numbered) &&
                                  sameSourceFxRender(impl_->fxSourceRunning[slot], nowSource);
                // A controlled FX belongs to its selected performance owner.
                // Even equal settings need a separate outgoing lane on recall:
                // binding the incoming owner clears its EG/Scratch history.
                const bool controlledOwnerTail = (was.numbered.index == 34 ||
                    was.numbered.index == 37 || was.numbered.index == 42) &&
                    was.numberedModulatingPart >= 0 && was.numberedModulatingPart <= 7;
                if (!same || controlledOwnerTail) changedMask |= static_cast<std::uint8_t>(1U << slot);
            }
            // All nontrivial source components contain MFX1. Their old/new
            // union is therefore one bounded star, including a destination
            // whose own parameters did not change during the recall.
            const std::uint8_t linkedChange = (changedMask & unionComponent) != 0U ? unionComponent : 0U;
            std::uint8_t captureMask = 0U;
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                const auto bit = static_cast<std::uint8_t>(1U << slot);
                if (((changedMask | linkedChange) & bit) == 0U) continue;
                const auto& was = impl_->fxRunning[slot];
                // Source DSP has its own complete Wet/Dry mixture and may
                // have native type Off, negative Wet/Dry, or a dry MFX1 that
                // must continue passing the upstream outgoing effect tail.
                if (!decodedSourceFxActive(impl_->fxSourceRunning[slot]) &&
                    ((was.type == EffectType::Off && was.numbered.index == 0) || was.wet <= 0.0F)) continue;
                captureMask |= bit;
            }
            // A slot has only two processor lanes and one outgoing record.
            // Before any reuse, retire the whole older linked snapshot if a
            // member's record is replaced or its lane becomes active again.
            std::uint8_t retireMask = 0U;
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                if (impl_->tailLeft[slot] == 0U) continue;
                const auto bit = static_cast<std::uint8_t>(1U << slot);
                const auto incoming = static_cast<std::uint8_t>(impl_->fxInst[slot] ^ ((captureMask & bit) != 0U ? 1U : 0U));
                const bool replacesRecord = (captureMask & bit) != 0U;
                const bool reusesLane = ((changedMask | linkedChange) & bit) != 0U &&
                    incoming == impl_->tailInst[slot];
                if (replacesRecord || reusesLane)
                    retireMask |= static_cast<std::uint8_t>(bit | impl_->tailComponent[slot]);
            }
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                if ((retireMask & (1U << slot)) == 0U) continue;
                impl_->tailLeft[slot] = impl_->tailQuiet[slot] = 0U;
                impl_->tailSnapshot[slot] = 0U; impl_->tailComponent[slot] = 0U;
            }
            std::uint64_t snapshot = 0U;
            if (oldGraph.componentMask != 0U &&
                (captureMask & oldGraph.componentMask) == oldGraph.componentMask) {
                snapshot = ++impl_->tailSnapshotSerial;
                if (snapshot == 0U) snapshot = ++impl_->tailSnapshotSerial;
            }
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                const auto bit = static_cast<std::uint8_t>(1U << slot);
                if ((captureMask & bit) == 0U) continue;
                const auto& now = current->combi.fx[slot];
                const auto& nowSource = nextSource[slot];
                impl_->tailCfg[slot] = impl_->fxRunning[slot];
                impl_->tailSourceCfg[slot] = impl_->fxSourceRunning[slot];
                impl_->tailInst[slot] = impl_->fxInst[slot];
                impl_->sendFx[slot][impl_->tailInst[slot] & 1U].freezeNumberedControl();
                impl_->tailLeft[slot] = static_cast<std::uint32_t>(20.0 * impl_->sampleRate);
                impl_->tailQuiet[slot] = 0U;
                const bool linkedTail = snapshot != 0U && (oldGraph.componentMask & bit) != 0U;
                impl_->tailSnapshot[slot] = linkedTail ? snapshot : 0U;
                impl_->tailComponent[slot] = linkedTail ? oldGraph.componentMask : 0U;
                impl_->fxInst[slot] = static_cast<std::uint8_t>(impl_->fxInst[slot] ^ 1U);
                // The incoming A/B lane may have been used by an older owner
                // with this same algorithm and values. Clear only that new
                // numbered lane; the outgoing tail keeps its own history.
                if (now.numbered.index != 0 || nowSource.numbered.index != 0)
                    impl_->sendFx[slot][impl_->fxInst[slot] & 1U].numbered.reset();
            }
            // Reset only incoming lanes in the changed connected graph.
            // Old histories remain on the captured lanes, while nodes that
            // were previously Off also start the incoming graph afresh.
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot)
                if ((linkedChange & (1U << slot)) != 0U)
                    impl_->sendFx[slot][impl_->fxInst[slot] & 1U].reset();
        }
        impl_->fxGeneration = current->combiGeneration;
        impl_->fxRunning = current->combi.fx;
        impl_->fxSourceRunning = nextSource;
        impl_->fxRunningValid = true;
    }

    std::array<bool, kFxSendSlots> sendFxActive{};
    std::array<bool, kPartCount> insertFxActive{};
    const NumberedFxControlFrame noNumberedControl{};
    for (std::size_t slot = 0; slot < sendFxActive.size(); ++slot) {
        const auto& fx = current->combi.fx[slot];
        auto& active = impl_->sendFx[slot][impl_->fxInst[slot] & 1U];
        sendFxActive[slot] = active.configureNumbered(fx, &impl_->fxSourceRunning[slot]);
        const int modulatingPart = fx.numberedModulatingPart;
        const bool hasModulatingPart = modulatingPart >= 0 && modulatingPart <= 7;
        const auto& control = hasModulatingPart ?
            impl_->fxControlParts[static_cast<std::size_t>(modulatingPart)].frame : noNumberedControl;
        // These controlled MFX need an explicit owner part. Their dry bypass
        // is suitable for IFX, but would otherwise add a dry send-return copy.
        // Off or an unavailable primary source also suspends Scratch Input
        // recording. An unavailable record-only source does not mute playback.
        if (sendFxActive[slot] && (fx.numbered.index == 34 ||
            fx.numbered.index == 37 || fx.numbered.index == 42)) {
            const auto* source = findNumberedFxParam(fx.numbered.index,
                fx.numbered.index == 42 ? "a_1" : "c_2");
            sendFxActive[slot] = hasModulatingPart && source &&
                fx.numbered.known(source->ordinal) &&
                control.available(static_cast<int>(fx.numbered.values[source->ordinal]));
        }
        // Pause recording even though an inactive MFX will not process samples.
        // Freeze only this slot's copy, never the shared part or its IFX frame.
        active.setNumberedControl(fx, control, !sendFxActive[slot]);
        if (impl_->tailLeft[slot] != 0U) {
            auto& tail = impl_->sendFx[slot][impl_->tailInst[slot] & 1U];
            tail.configureNumbered(impl_->tailCfg[slot], &impl_->tailSourceCfg[slot]);
            tail.applyFrozenNumberedControl(impl_->tailCfg[slot]);
        }
    }
    for (std::size_t part = 0; part < insertFxActive.size(); ++part) {
        const auto& fx = current->combi.insertOf(static_cast<int>(part));
        insertFxActive[part] = impl_->insertFx[part].configureNumbered(fx);
        impl_->insertFx[part].setNumberedControl(fx, impl_->fxControlParts[part].frame);
    }

    const auto activeSourceGraph = sourceMasterGraph(impl_->fxSourceRunning);
    auto outgoingSourceGraph = sourceMasterGraph(impl_->tailSourceCfg);
    outgoingSourceGraph.componentMask = 0U;
    for (std::size_t slot = 1U; slot <= 2U; ++slot) {
        if (outgoingSourceGraph.toFirst[slot] <= 0.0F) continue;
        const auto required = static_cast<std::uint8_t>(1U | (1U << slot));
        // Never feed an old source lane into an incoming destination or into
        // a different recall's tail, even if its algorithm happens to match.
        if (impl_->tailLeft[0] == 0U || impl_->tailLeft[slot] == 0U ||
            impl_->tailSnapshot[0] == 0U || impl_->tailSnapshot[slot] != impl_->tailSnapshot[0] ||
            impl_->tailComponent[slot] != impl_->tailComponent[0] ||
            (impl_->tailComponent[0] & required) != required) {
            outgoingSourceGraph.toFirst[slot] = 0.0F;
            continue;
        }
        outgoingSourceGraph.componentMask |= required;
    }

    // A stopped/unloaded arranger Player still has to adopt its queued state
    // and MIDI above. Once those are consumed, skip only a provably zero mix:
    // no voice, residual, running processor, FX tail or analyzer can contribute.
    // Keep the common footer below, including stream-window/owner cleanup and
    // the real CPU/meters. Enabled processors retain their ordinary zero-input
    // processing, so this never truncates their histories or release tails.
    bool skipSilentMix = tapUpperNow < 0 && !limiterOn &&
        current->global.eqLowDb == 0.0F && current->global.eqMidDb == 0.0F &&
        current->global.eqHighDb == 0.0F;
    if (skipSilentMix) for (const auto& voice : impl_->voices) {
        if (voice.active || voice.fading) { skipSilentMix = false; break; }
    }
    if (skipSilentMix) for (std::size_t slot = 0U; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
        if (sendFxActive[slot] || impl_->tailLeft[slot] != 0U) {
            skipSilentMix = false; break;
        }
    }
    if (skipSilentMix) for (std::size_t ui = 0U; ui < static_cast<std::size_t>(kPartCount); ++ui) {
        const auto& upper = current->combi.part(static_cast<int>(ui));
        // If Even Decay was just changed, run its existing reset/bookkeeping
        // once before becoming eligible. An enabled decay always keeps running.
        if (impl_->channelGates[ui].active() || impl_->upperEq[ui].any() || !(upper.evenDecayMs < 30.0F) ||
            impl_->evenDecayApplied[ui] != 0.0F ||
            insertFxActive[ui]) {
            skipSilentMix = false; break;
        }
        for (std::size_t si = 0U; si < static_cast<std::size_t>(kSoundsPerUpper); ++si) {
            if (impl_->soundBus[ui][si].any() || impl_->takeoverResidual[ui][si].remaining != 0U) {
                skipSilentMix = false; break;
            }
        }
        if (!skipSilentMix) break;
    }

    // SILVETON_RENDER_SPEED_V1: every voice renders its whole chunk at once and
    // everything that cannot change inside a block (controllers, pitch bend,
    // LFO scaling, filter base, pan, level) is computed once per voice per chunk
    // instead of once per sample. Per sample the work and its order are the same,
    // so the sound is the same.
    constexpr std::uint32_t kChunk = Impl::kRenderChunk;
    if (!skipSilentMix) for (std::uint32_t chunkStart = 0U; chunkStart < frames; chunkStart += kChunk) {
      const std::uint32_t n = std::min(kChunk, frames - chunkStart);
      prepareSourceLfos(*impl_,current->global,n);

      // SILVETON_MULTICORE_V1: this chunk's voices sorted into their sound bus, in the order
      // of the voice list. The dominant PCM bus may be divided below.
      impl_->busVoiceCount.fill(0U);
      int busUsed = 0;
      int voicesHere = 0;
      for (std::uint16_t vi = 0U; vi < static_cast<std::uint16_t>(impl_->voices.size()); ++vi) {
          const auto& vv = impl_->voices[vi];
          if (!vv.active || vv.sample == nullptr || vv.layer == nullptr || vv.zone == nullptr || vv.upper == nullptr) continue;
          const int bui = std::clamp(vv.upperIndex, 0, kPartCount - 1);
          const int bsi = std::clamp(vv.soundIndex, 0, kSoundsPerUpper - 1);
          const auto bus = static_cast<std::size_t>(bui * kSoundsPerUpper + bsi);
          if (impl_->busVoiceCount[bus] == 0U) {
              impl_->busOrder[static_cast<std::size_t>(busUsed++)] = static_cast<std::uint8_t>(bus);
              // Only a claimed bus will be written by renderBus. Unclaimed
              // filter tails receive explicit zero at the mix stage below.
              std::fill_n(impl_->chunkL[static_cast<std::size_t>(bui)][static_cast<std::size_t>(bsi)].begin(), n, 0.0F);
              std::fill_n(impl_->chunkR[static_cast<std::size_t>(bui)][static_cast<std::size_t>(bsi)].begin(), n, 0.0F);
          }
          impl_->busVoices[bus][impl_->busVoiceCount[bus]++] = vi;
          ++voicesHere;
      }

      const bool parallel = voicesHere >= 8 && impl_->pool->threadsWanted > 1 && impl_->pool->ready();
      unsigned splitAt = 0;
      if (parallel && impl_->pool->threadsWanted == 2 && voicesHere >= 16) {
          // A dominant sampled instrument can occupy both fast CPUs even if
          // every voice belongs to the same part and sound. Other buses keep
          // their ordinary parallel execution, including synth-specific state.
          for (std::size_t slot = 0; slot < static_cast<std::size_t>(busUsed); ++slot) {
              const auto bus = impl_->busOrder[slot];
              const auto count = impl_->busVoiceCount[bus];
              if (count < 16 || count * 2 <= voicesHere) continue;
              const auto& ids = impl_->busVoices[bus];
              const bool sampled = std::all_of(ids.begin(), ids.begin() + count,
                  [&](auto id) { return impl_->voices[id].so == nullptr; });
              if (sampled) {
                  std::swap(impl_->busOrder[slot], impl_->busOrder[0]);
                  splitAt = (count + 1U) / 2U;
              }
              break;
          }
      }
      const auto renderBus = [&](int task) noexcept {
       const bool separate = splitAt && task == 1;
       const auto slot = static_cast<std::size_t>(splitAt && task > 0 ? task - 1 : task);
       const auto bus = impl_->busOrder[slot];
       const unsigned end = splitAt && task == 0 ? splitAt : impl_->busVoiceCount[bus];
       for (unsigned bi = separate ? splitAt : 0U; bi < end; ++bi) {
        auto& outL = separate ? impl_->splitL[bi - splitAt] : impl_->chunkL[bus / kSoundsPerUpper][bus % kSoundsPerUpper];
        auto& outR = separate ? impl_->splitR[bi - splitAt] : impl_->chunkR[bus / kSoundsPerUpper][bus % kSoundsPerUpper];
        if (separate) {
            std::fill_n(outL.begin(), n, 0.0F);
            std::fill_n(outR.begin(), n, 0.0F);
        }
        auto& v = impl_->voices[impl_->busVoices[bus][bi]];
        if (!v.active || v.sample == nullptr || v.layer == nullptr || v.zone == nullptr || v.upper == nullptr) continue;
        const auto& sample = *v.sample;
        const bool looping = sample.loop.enabled && !v.oneShot && !v.zone->reverse && !v.loopOff;
        const auto& ch = impl_->channels[v.channel & 0x0FU];
        const std::uint16_t routeMask = v.routeMask;
        const auto routeActive = [routeMask](ModDestination d) noexcept {
            return (routeMask & static_cast<std::uint16_t>(1U << static_cast<unsigned>(d))) != 0U;
        };


        const bool filterActive = v.layer->filter.mode != FilterMode::Bypass;
        const bool lfoDepthRouted = routeActive(ModDestination::LfoDepth);
        const bool lfo1Needed = lfoDepthRouted || v.layer->lfo1.pitchCents != 0.0F ||
            v.layer->lfo1.filterOctaves != 0.0F || v.layer->lfo1.ampDepth != 0.0F ||
            (v.sourceEdits.controller(77)>64&&!v.sourceOscillator.support.lfo[0])||
            (filterActive && v.layer->filter.lfoAmount != 0.0F);
        const bool lfo2Needed = lfoDepthRouted || v.layer->lfo2.pitchCents != 0.0F ||
            v.layer->lfo2.filterOctaves != 0.0F || v.layer->lfo2.ampDepth != 0.0F;

        LfoParams lfo1Params = v.layer->lfo1;
        LfoParams lfo2Params = v.layer->lfo2;
        for(auto* params:{&lfo1Params,&lfo2Params}){
            params->frequencyHz*=sourceSoundEditRateScale(v.sourceEdits.controller(76));
            params->delaySec=sourceSoundEditTimeMs(params->delaySec*1000.0F,v.sourceEdits.controller(78))*.001F;
            if(params==&lfo1Params||params->pitchCents!=0.0F)
                params->pitchCents=std::copysign(sourceSoundEditDepthCents(std::abs(params->pitchCents),v.sourceEdits.controller(77)),params->pitchCents);
        }
        if (lfo1Needed || lfo2Needed) {
            const float lfoRateScale = std::clamp(v.upper->lfoRateScale, 0.0F, 16.0F);
            const float controllerLfoDepth = lfoDepthRouted
                ? controllerAmount(*v.upper, ch, ModDestination::LfoDepth, impl_->aftertouchInputEnabled) : 0.0F;
            const float lfoDepthScale = std::clamp(
                v.upper->lfoDepthScale * std::max(0.0F, 1.0F + controllerLfoDepth), 0.0F, 8.0F);
            if (lfo1Needed) {
                lfo1Params.frequencyHz *= lfoRateScale;
                lfo1Params.pitchCents *= lfoDepthScale;
                lfo1Params.filterOctaves *= lfoDepthScale;
                lfo1Params.ampDepth *= lfoDepthScale;
            }
            if (lfo2Needed) {
                lfo2Params.frequencyHz *= lfoRateScale;
                lfo2Params.pitchCents *= lfoDepthScale;
                lfo2Params.filterOctaves *= lfoDepthScale;
                lfo2Params.ampDepth *= lfoDepthScale;
            }
        }

        const bool pitchEnvNeeded = v.layer->pitchEnvelopeCents != 0.0F;
        const bool filterEnvNeeded = filterActive && v.layer->filter.envelopeAmount != 0.0F;
        const bool lfoPitch = (lfo1Needed && lfo1Params.pitchCents != 0.0F) || (lfo2Needed && lfo2Params.pitchCents != 0.0F);
        const bool bendPermitted=current->global.pitchBendEnabled && !current->global.filterPitchBend &&
            ((current->global.midiInputChannelMask >> (v.channel & 15U)) & 1U)!=0;
        const float bendNorm = bendPermitted?static_cast<float>(ch.pitchBend)/(ch.pitchBend>=0?8191.0F:8192.0F):0.0F;
        // MAIN/L1-L4 sources use the one visible UPPER range. Hidden source
        // defaults must not override it; retain overrides only for legacy SOLO.
        float bendRange = static_cast<float>(v.upper->pitchBendRange);
        if (v.so != nullptr && !soundSource(*v.upper,v.soundIndex).commonProcessing) {
            const int sel = static_cast<int>(std::lround(soundSource(*v.upper,v.soundIndex).engine.p[bendNorm >= 0.0F ? E_BEND_UP : E_BEND_DOWN]));
            if (sel < 0) bendRange = 0.0F; else if (sel > 0) bendRange = static_cast<float>(std::min(sel, 24));
        }
        const float bendSemis = bendNorm * bendRange;
        if(!v.bendReady){v.bendNow=bendSemis;v.bendReady=true;}
        const bool bendMoving=std::abs(v.bendNow-bendSemis)>1e-8;
        const double bendAlpha=1-std::exp(-1/(.0025*impl_->sampleRate));
        const bool dynamicPitchActive = bendSemis != 0 || std::abs(v.bendNow)>1e-8 || routeActive(ModDestination::PitchSemitones) ||
            pitchEnvNeeded || lfoPitch || v.vibSemis != 0.0;
        const float controllerPitchSemis = routeActive(ModDestination::PitchSemitones)
            ? controllerAmount(*v.upper, ch, ModDestination::PitchSemitones, impl_->aftertouchInputEnabled) : 0.0F;
        const bool pitchPerSample = pitchEnvNeeded || lfoPitch || bendMoving;
        // Bend / controller / vibrato: the same factor for the whole block.
        const double staticPitchMul = (dynamicPitchActive && !pitchPerSample)
            ? std::pow(2.0, (static_cast<double>(bendSemis + controllerPitchSemis) + v.vibSemis) / 12.0)
            : 1.0;

        float filterBaseCutoff = 0.0F, filterStaticOct = 0.0F, filterResonance = 0.0F;
        const bool filterOctPerSample = filterEnvNeeded || lfo1Needed || lfo2Needed;
        if (filterActive) {
            const float controllerCutoff = routeActive(ModDestination::FilterCutoffOctaves)
                ? controllerAmount(*v.upper, ch, ModDestination::FilterCutoffOctaves, impl_->aftertouchInputEnabled) : 0.0F;
            filterBaseCutoff = v.layer->filter.cutoffHz * std::pow(
                2.0F, std::clamp(v.upper->filterCutoffOctaves + controllerCutoff, -10.0F, 10.0F));
            const float keyDelta = (static_cast<float>(v.key) - 60.0F) / 12.0F;
            const float velocityNorm = static_cast<float>(v.velocity) * kInv127;
            filterStaticOct = keyDelta * v.layer->filter.keyTrack + velocityNorm * v.layer->filter.velocityAmount;
            const float controllerResonance = routeActive(ModDestination::FilterResonance)
                ? controllerAmount(*v.upper, ch, ModDestination::FilterResonance, impl_->aftertouchInputEnabled) : 0.0F;
            filterResonance = std::clamp(
                v.layer->filter.resonance + v.upper->filterResonanceOffset + controllerResonance, 0.0F, 1.0F);
        }
        const float staticFilterCutoff = (filterActive && !filterOctPerSample)
            ? (filterStaticOct != 0.0F ? filterBaseCutoff * std::pow(2.0F, filterStaticOct) : filterBaseCutoff)
            : 0.0F;

        const bool ampLfo = (lfo1Needed && lfo1Params.ampDepth != 0.0F) || (lfo2Needed && lfo2Params.ampDepth != 0.0F);
        const bool anyChannelGain = v.upper->expressionEnabled || v.upper->breathEnabled;
        const float controllerLevelDb = routeActive(ModDestination::LevelDb)
            ? controllerAmount(*v.upper, ch, ModDestination::LevelDb, impl_->aftertouchInputEnabled) : 0.0F;
        const float levelGain = controllerLevelDb != 0.0F ? dbToGain(std::clamp(controllerLevelDb, -96.0F, 24.0F)) : 1.0F;
        const float controllerPan = routeActive(ModDestination::Pan) ? controllerAmount(*v.upper, ch, ModDestination::Pan, impl_->aftertouchInputEnabled) : 0.0F;
        const bool monitored=impl_->listensTo(v.upperIndex,v.key);
        const bool isolated=impl_->listenPart==v.upperIndex;
        const auto& strip=current->combi.part(v.upperIndex);
        const bool audible=isolated||(upperAudible(*v.ownerState,*v.upper)&&(!strip.livePartMix||!strip.mute));
        updateMixTarget(v, *v.upper, monitored&&audible, controllerPan + v.unisonPan + v.modPan,
                        channelMixOn ? ch.midiPan : 0.0F);
        // SILVETON_POLYSIX_V1 per-chunk settings of this sound
        const SoundTone stC = soundToneOf(*v.upper, v.soundIndex);
        const float subLevel = std::clamp(stC.x.subLevel, 0.0F, 1.0F);
        const double subRatioDiv = stC.x.subOctave >= 2 ? 4.0 : 2.0;
        const bool subOn = subLevel > 0.0F;
        const bool pwmOn = v.pwmWidthNow > 0.0F && v.periodFrames > 0.0;
        const float pwmMix = std::clamp(stC.x.pwmMix, 0.0F, 1.0F);
        const double pwmDelta = pwmOn ? static_cast<double>(v.pwmWidthNow) * v.periodFrames : 0.0;   // in recording frames
        const float driveAmt = std::clamp(stC.x.drive + v.modDrive, 0.0F, 1.0F);
        const float driveK = 1.0F + 9.0F * driveAmt * driveAmt;
        const float driveNorm = 1.0F / std::sqrt(driveK);
        const int f2type = stC.x.filter2Type;
        const bool f2parallel = stC.x.filter2Parallel;
        const float modLevelGain = v.modLevelDb != 0.0F ? dbToGain(std::clamp(v.modLevelDb, -60.0F, 24.0F)) : 1.0F;
        const float dcCoef = 1.0F - static_cast<float>(2.0 * kPi * 20.0 / impl_->sampleRate);
        float mixTargetL = v.mixTargetL;
        float mixTargetR = v.mixTargetR;
        bool mixMoving = mixTargetL != v.mixL || mixTargetR != v.mixR;
        const bool reverse = v.zone->reverse;
        const double loopEnd = static_cast<double>(sample.loop.endFrame);
        const double loopStart = static_cast<double>(sample.loop.startFrame);
        const double loopLen = static_cast<double>(sample.loop.endFrame - sample.loop.startFrame);
        const double loopHistoryOffset = looping && loopLen > 0.0
            ? std::ceil(64.0 / loopLen) * loopLen : 0.0;
        const double sampleEnd = static_cast<double>(sample.frameCount());
        // SILVETON_TRANSWAVE_V1
        const WaveTable* const wt = v.waveTable.get();
        const bool waveOn = wt != nullptr && wt->frames >= 2 && wt->length >= 16;
        const bool taperAtEof = !looping && v.so == nullptr && !waveOn;
        const double eofFadeFrames = std::max(1.0, impl_->sampleRate * 0.001);
        const float waveSmooth = std::clamp(stC.x.waveSmooth, 0.0F, 1.0F);
        // SILVETON_ENGINES_V1: the per-note part of the ENGINE in this chunk
        const SincInterpolator& ipol=interpolator_;
        const bool sourceDspActive=v.sourceOscillator.source!=nullptr||v.ampEnv.sourceEnabled;
        SourceModulationContext sourceInputs{};
        if(sourceDspActive){
            sourceInputs=sourceContext(*impl_,v,current->global);
            if(routeActive(ModDestination::FilterCutoffOctaves))sourceInputs.filterExtraOctaves+=
                controllerAmount(*v.upper,ch,ModDestination::FilterCutoffOctaves,impl_->aftertouchInputEnabled);
            if(routeActive(ModDestination::FilterResonance))sourceInputs.resonanceExtra+=
                controllerAmount(*v.upper,ch,ModDestination::FilterResonance,impl_->aftertouchInputEnabled);
        }
        const auto* sharedLfo=sourceDspActive&&v.sourceLfoSlot>=0?&impl_->sourceLfoSlots[static_cast<std::size_t>(v.sourceLfoSlot)]:nullptr;
        const std::array<bool,2> sourceShared=sharedLfo!=nullptr?sharedLfo->shared:std::array<bool,2>{};

        for (std::uint32_t i = 0U; i < n; ++i) {
            if (v.delayFramesRemaining > 0U) {
                --v.delayFramesRemaining;
                continue;
            }
            float lfo1 = 0.0F, lfo2 = 0.0F;
            if (lfo1Needed) lfo1 = v.lfo1.process(lfo1Params, impl_->sampleRate);
            if (lfo2Needed) lfo2 = v.lfo2.process(lfo2Params, impl_->sampleRate);

            const float pitchEnv = pitchEnvNeeded ? v.pitchEnv.process(impl_->sampleRate) : 0.0F;
            const float filterEnv = filterEnvNeeded ? v.filterEnv.process(impl_->sampleRate) : 0.0F;
            if(sourceDspActive){
                sourceInputs.amplitudeEnvelope=v.ampEnv.value;
                sourceInputs.pitchEnvelope=pitchEnv;sourceInputs.filterEnvelope=filterEnv;
                sourceInputs.lfo={lfo1,lfo2};
                const std::array<float,2> sharedValues=sharedLfo!=nullptr?
                    std::array<float,2>{{sharedLfo->output[0][i],sharedLfo->output[1][i]}}:std::array<float,2>{};
                v.sourceOscillator.tick(sourceInputs,v.sourceEdits,impl_->sampleRate,sharedValues,sourceShared);
                const bool sourceControl=v.sourceAmpControlCountdown==0U;
                if(sourceControl){
                    v.sourceAmpControlCountdown=kSourceControlStride;
                    if(v.ampEnv.sourceEnabled){
                        const auto modulation=v.sourceOscillator.source!=nullptr?v.sourceOscillator.inputs:sourceModulationValues(sourceInputs);
                        v.ampEnv.source.rekey(v.layer->sourceAmpEnvelope,v.sourceKey,v.sourceVelocity,&modulation);
                        auto sourceTone=voiceTone(v,stC,*v.upper);
                        const auto* layer=layerOf(*v.upper,v.soundIndex);
                        const auto& shape=layer!=nullptr?layer->velocityShape:v.upper->velocityShape;
                        if(shape.toAttack>0.0F)sourceTone.attackMs=std::min(sourceTone.attackMs+velocityAttackExtraMs(shape,v.velNorm),kToneMaxTimeMs);
                        sourceTone.attackMs=std::clamp(sourceTone.attackMs*v.modAttackMul,0.0F,kToneMaxTimeMs);
                        sourceTone.releaseMs=std::clamp(sourceTone.releaseMs*v.modReleaseMul,0.0F,kToneMaxTimeMs);
                        v.ampEnv.setBlock(sourceTone,impl_->sampleRate);
                    }
                    if(v.sourceOscillator.support.pan){
                        updateMixTarget(v,*v.upper,monitored&&audible,controllerPan+v.unisonPan+v.modPan,channelMixOn?ch.midiPan:0.0F);
                        mixTargetL=v.mixTargetL;mixTargetR=v.mixTargetR;
                        mixMoving=mixTargetL!=v.mixL||mixTargetR!=v.mixR;
                    }
                }
                --v.sourceAmpControlCountdown;
            }
            const bool ownsEnvelope=v.so != nullptr && !soundSource(*v.upper,v.soundIndex).commonProcessing;
            float ampEnv = ownsEnvelope ? (v.ampEnv.process(), 1.0F) : v.ampEnv.process();   // SILVETON SYNTH (the old one) has its own envelopes (the calculated SYNTH uses the place's)
            if (!ownsEnvelope && !v.ampEnv.sourceEnabled && v.layer->sampleDecay.enabled()) {
                // Releasing the gate starts the ADSR release from the currently
                // sounding source level. CC64 defers release, not natural decay.
                const bool sourceAlive=v.ampEnv.stage==AmpEnv::Stage::Release||v.sampleDecay.next(v.layer->sampleDecay,impl_->sampleRate);
                const float target=v.editCurve?1.0F:0.0F;
                if(v.curveBlend!=target){
                    v.curveBlend+=(target-v.curveBlend)*mixSmooth;
                    if(std::abs(target-v.curveBlend)<.0001F)v.curveBlend=target;
                }
                if(!sourceAlive&&v.curveBlend==0.0F){v.ampEnv.forceOff();v.active=false;break;}
                ampEnv*=v.sampleDecay.value+(v.curvePeak-v.sampleDecay.value)*v.curveBlend;
            }
            if (!v.ampEnv.active() && !ownsEnvelope) { v.active = false; break; } // SOLO owns its learned/manual release.

            if (v.pitchGliding) {
                double raw = 0.0;
                const double previous = v.glideRawSemis;
                if (v.glideFramesRemaining > 0U) {
                    --v.glideFramesRemaining;
                    const double t = 1.0 - static_cast<double>(v.glideFramesRemaining) / static_cast<double>(v.glideTotalFrames);
                    if (v.glideKronos) {
                        // SILVETON_KRONOS_MUSICAL_PORTA_V2: a firmer, more natural
                        // ease than SILVETON's velvet S-shape, with especially
                        // gentle starts/arrivals on adjacent keys. Use semitones
                        // (not Hz), no low-pass delay and EXACT arrival in TIME.
                        const double near = std::clamp(
                            (5.0 - std::abs(v.glideStartSemis)) / 4.0, 0.0, 1.0);
                        const double ease = 0.66 + 0.22 * near;
                        const double smooth = t * t * (3.0 - 2.0 * t);
                        const double progress = t + ease * (smooth - t);
                        // C1 continuity during overlapping, rapid legato notes.
                        // End-slope is independent of inherited movement.
                        const double inv = 1.0 - t;
                        const double velocityBasis = t * inv * inv;
                        raw = v.glideStartSemis * (1.0 - progress)
                            + v.glideStartVelocity * velocityBasis;
                    } else {
                        // SILVETON_PROCESSOR_PORTA_V1: the glide of the SILVETON keyboard processor on
                        // the Korg - a straight line at constant rate, from the pitch that sounds to the
                        // new key, arriving exactly in time. No S-curve, no carried momentum
                        // (the SILVETON_SILK_PORTA_V1 shape is retired).
                        raw = v.glideStartSemis * (1.0 - t);
                    }
                }
                v.glideRawSemis = v.glideSmooth1 = v.glideSmooth2 = raw;
                v.glideLastStep = raw - previous;
                if (v.glideFramesRemaining == 0U) {
                    // No low-pass tail: destination is exact at TIME (including
                    // 1 ms changes). No lingering pitch drift after landing.
                    v.pitchGliding = false;
                    v.glideStartVelocity = v.glideLastStep = 0.0;
                    v.glideRawSemis = v.glideSmooth1 = v.glideSmooth2 = 0.0;
                    v.ratio = v.targetRatio;
                } else {
                    v.ratio = v.targetRatio * std::exp2(raw / 12.0);
                }
            }

            double ratio = v.ratio;
            if (dynamicPitchActive) {
                if (pitchPerSample) {
                    const float lfoPitchCents = lfo1 * lfo1Params.pitchCents + lfo2 * lfo2Params.pitchCents;
                    const float envPitchCents = pitchEnv * v.layer->pitchEnvelopeCents;
                    v.bendNow+=(bendSemis-v.bendNow)*bendAlpha;
                    if(std::abs(v.bendNow-bendSemis)<1e-8)v.bendNow=bendSemis;
                    const double dynamicPitch = v.bendNow + static_cast<double>(controllerPitchSemis) + v.vibSemis +
                        static_cast<double>(lfoPitchCents + envPitchCents) / 100.0;
                    ratio *= std::pow(2.0, dynamicPitch / 12.0);
                } else {
                    ratio *= staticPitchMul;
                }
            }
            if(v.sourceOscillator.pitchSemitones!=0.0F)
                ratio*=v.sourceOscillator.pitchMultiplier();

            float sL = 0.0F, sR = 0.0F;
            // SILVETON_ENGINES_V2: FM (AL-1 / MOD-7) moves the recording in phase - the read rate stays the clean one, the
            // recording is never read backwards; SYNC restarts the recording every period of the key
            const double engInc = v.periodFrames > 0.0 ? ratio / v.periodFrames : v.soloIncrement * (ratio / std::max(1.0e-9, v.targetRatio));
            const double ratioRead=ratio;
            v.lastReadRatio=ratioRead;
            // After the first pass through the loop, the frames just before the loop
            // start are the loop END (that is what was heard), not the attack.
            // Shift by whole cycles covering even the shortest loop's tap history.
            double readPos = v.position;
            if (v.loopWrapped && looping && loopLen > 0.0 && readPos < loopStart + 64.0) readPos += loopHistoryOffset;

            if (v.sampleEnded) {
                sL = sR = 0.0F;   // the recording ran out; the engine's own sound goes on below
            } else if (waveOn) {
                // TRANSWAVE: one cycle of the table, read at the pitch of the key, between two neighbouring frames
                const float posNow = v.wavePosPrev + (v.wavePosNow - v.wavePosPrev) * static_cast<float>(i + 1U) / static_cast<float>(n);
                const float fp = posNow * static_cast<float>(wt->frames - 1);
                int k0 = std::min(static_cast<int>(fp), wt->frames - 2);
                float tf = fp - static_cast<float>(k0);
                if (waveSmooth < 0.999F) {   // steps: stay on a frame and morph quickly near the middle between two
                    const float w = std::max(0.02F, waveSmooth);
                    tf = std::clamp((tf - (0.5F - 0.5F * w)) / w, 0.0F, 1.0F);
                }
                const int len = wt->length;
                const int nch = wt->channels;
                const double idx = v.wavePhase * static_cast<double>(len);
                const int i1 = static_cast<int>(idx);
                const float fr = static_cast<float>(idx - static_cast<double>(i1));
                const int m = len - 1;
                const auto herm = [fr](float y0, float y1, float y2, float y3) noexcept {
                    const float c1 = 0.5F * (y2 - y0), c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3, c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
                    return ((c3 * fr + c2) * fr + c1) * fr + y1;
                };
                float out2[2] = {0.0F, 0.0F};
                for (int c = 0; c < nch; ++c) {
                    const float* fa = wt->frame(k0);
                    const float* fb = wt->frame(k0 + 1);
                    const auto at = [&](const float* f, int ix) noexcept { return f[static_cast<std::size_t>(ix & m) * static_cast<std::size_t>(nch) + static_cast<std::size_t>(c)]; };
                    float a = herm(at(fa, i1 - 1), at(fa, i1), at(fa, i1 + 1), at(fa, i1 + 2));
                    if (tf > 0.0F) {
                        const float b = herm(at(fb, i1 - 1), at(fb, i1), at(fb, i1 + 1), at(fb, i1 + 2));
                        a += (b - a) * tf;
                    }
                    out2[c] = a;
                }
                sL = out2[0];
                sR = nch == 2 ? out2[1] : out2[0];
                v.wavePhase += std::abs(ratioRead) / v.periodFrames;
                if (v.wavePhase >= 1.0) v.wavePhase -= std::floor(v.wavePhase);
            } else {
                readWithLoopCrossfade(ipol, sample, readPos, ratioRead, looping, v.loopCrossfade, sL, sR);

            }
            if (v.so != nullptr) {
                v.so->tick(engInc,sL,sR);
                if (v.so->finished()) {v.ampEnv.forceOff();v.active=false;v.so=nullptr;break;}
            }
            if (pwmOn) {
                // SILVETON_SYNTH_LIGHT_V1 - PWM: the recording minus itself shifted by WIDTH x its own
                // period (saw -> pulse; any harmonic recording -> the comb PWM gives). The shifted copy
                // comes from a delay line fed with the sound just read (4-point interpolation) - the
                // same result as a second read of the recording at a tenth of the cost. 20 Hz DC blocker.
                constexpr int kD = SamplerEngine::Impl::Voice::kPwmDelay;
                const int w = v.pwmWrite;
                v.pwmBuf[static_cast<std::size_t>(w) * 2U] = sL; v.pwmBuf[static_cast<std::size_t>(w) * 2U + 1U] = sR;
                v.pwmWrite = (w + 1) & (kD - 1);
                if (v.pwmFilled < kD) ++v.pwmFilled;
                const double delay = std::clamp(pwmDelta / std::max(1.0e-6, ratio), 1.0, static_cast<double>(kD - 4));   // output frames
                if (static_cast<double>(v.pwmFilled) > delay + 2.0) {
                    const double rp = static_cast<double>(w) - delay;
                    const int i1 = static_cast<int>(std::floor(rp));
                    const float t = static_cast<float>(rp - static_cast<double>(i1));
                    const auto at = [&](int ix, int c) noexcept { return v.pwmBuf[static_cast<std::size_t>(ix & (kD - 1)) * 2U + static_cast<std::size_t>(c)]; };
                    const auto herm = [t](float y0, float y1, float y2, float y3) noexcept {
                        const float c1 = 0.5F * (y2 - y0), c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3, c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
                        return ((c3 * t + c2) * t + c1) * t + y1;
                    };
                    const float dL = herm(at(i1 - 1, 0), at(i1, 0), at(i1 + 1, 0), at(i1 + 2, 0));
                    const float dR = herm(at(i1 - 1, 1), at(i1, 1), at(i1 + 1, 1), at(i1 + 2, 1));
                    sL -= dL * pwmMix; sR -= dR * pwmMix;
                }
                const float yL = sL - v.dcXL + dcCoef * v.dcYL; v.dcXL = sL; v.dcYL = yL; sL = yL;
                const float yR = sR - v.dcXR + dcCoef * v.dcYR; v.dcXR = sR; v.dcYR = yR; sR = yR;
            }
            if (subOn && !v.sampleEnded) {
                // SUB: the same recording an octave (or two) lower, from its own position
                // (SILVETON_SYNTH_LIGHT_V1: read with the light 4-point interpolation - it runs at half
                // or quarter speed, where that is already clean - instead of the Studio kernel)
                float subL = 0.0F, subR = 0.0F;
                double subPos = v.subPosition;
                if (v.subLoopWrapped && looping && loopLen > 0.0 && subPos < loopStart + 64.0) subPos += loopHistoryOffset;
                readWithLoopCrossfade(subInterpolator_, sample, subPos, ratio / subRatioDiv, looping, v.loopCrossfade, subL, subR);
                sL += subL * subLevel; sR += subR * subLevel;
                v.subPosition += ratio / subRatioDiv;
                if (looping && v.subPosition >= loopEnd && loopLen > 0.0) {
                    v.subPosition = loopStart + std::fmod(v.subPosition - loopStart, loopLen);
                    v.subLoopWrapped = true;
                }
                else if (!looping && v.subPosition >= sampleEnd) v.subPosition = sampleEnd - 1.0;
            }
            // SILVETON_ENGINES_V1: ring / noise / shaper, the MOD-7 waveshaper, the STR-1 string, the CX-3 tonewheels,
            // the MS-20 HPF, the SGX / EP colours and noises - on the sound just read

   // SILVETON_SYNTH_V1: the carrier is silent - the calculated note is the sound


            if(sourceDspActive){
                v.sourceOscillator.processFilter(sL,sR);
                v.sourceOscillator.processEqualizer(sL,sR);
            }
            if (filterActive) {
                float cutoff = staticFilterCutoff;
                if (filterOctPerSample) {
                    cutoff = filterBaseCutoff;
                    const float filterOct = filterStaticOct +
                                            filterEnv * v.layer->filter.envelopeAmount +
                                            lfo1 * v.layer->filter.lfoAmount +
                                            lfo1 * lfo1Params.filterOctaves +
                                            lfo2 * lfo2Params.filterOctaves;
                    if (filterOct != 0.0F) cutoff *= std::pow(2.0F, filterOct);
                }
                v.filter.process(sL, sR, v.layer->filter.mode, cutoff, filterResonance, impl_->sampleRate);
            }

            if (driveAmt > 0.0F) { sL = std::tanh(sL * driveK) * driveNorm; sR = std::tanh(sR * driveK) * driveNorm; }
            if (v.toneOn&&(!v.sourceOscillator.support.filter||v.filterTypeNow!=0)) {
                if (v.filterTypeNow == 1) v.ladder.process(sL, sR);
                else if (v.filterTypeNow == 2) v.korg35.process(sL, sR);
                else if (v.filterTypeNow >= 3) v.toneSvf.process(sL, sR, v.filterTypeNow == 3 ? FilterMode::HighPass : FilterMode::BandPass, v.toneFilterHz, v.toneFilterRes, impl_->sampleRate);
                else v.toneLp.process(sL, sR);
            }
            if (f2type != 0) {
                float bL = sL, bR = sR;
                const FilterMode fm = f2type == 1 ? FilterMode::LowPass : (f2type == 2 ? FilterMode::HighPass : FilterMode::BandPass);
                v.filter2.process(bL, bR, fm, v.filter2Hz, v.filter2Res, impl_->sampleRate);
                if (f2type == 4) { bL = sL - bL; bR = sR - bR; }   // band reject = input minus band-pass
                if (f2parallel) { sL = 0.5F * (sL + bL); sR = 0.5F * (sR + bR); } else { sL = bL; sR = bR; }
            }

            float modGain = ampEnv;
            if(sourceDspActive)modGain*=v.sourceOscillator.amplitudeGain;
            if (ampLfo) modGain *= std::max(0.0F, 1.0F + lfo1 * lfo1Params.ampDepth + lfo2 * lfo2Params.ampDepth);
            if (anyChannelGain) {
                if (v.upper->expressionEnabled) modGain *= ch.expression;
                if (v.upper->breathEnabled) modGain *= ch.breath;
            }
            if (channelMixOn) {
                v.midiVolumeNow += (ch.midiVolume-v.midiVolumeNow) * mixSmooth;
                modGain *= v.midiVolumeNow;
            }
            float g = v.baseGain * modGain * v.unisonGain * modLevelGain;
            if (controllerLevelDb != 0.0F) g *= levelGain;
            if (v.fadeStep != 0.0F) {
                v.fadeGain += v.fadeStep;
                if (v.fadeGain <= 0.0F) { v.ampEnv.forceOff(); v.active = false; v.fading = false; break; }
                if (v.fadeGain >= 1.0F) { v.fadeGain = 1.0F; v.fadeStep = 0.0F; }
            }
            if (v.fadeStep != 0.0F || v.fadeGain < 1.0F) {
                // equal-power fade; a crossfade between two recordings of the same line uses a
                // middle law (x^0.75): no +3 dB bump when they are in phase, no -3 dB hole when not
                g *= v.fadeBlend ? std::pow(v.fadeGain, 0.75F) : std::sin(v.fadeGain * 1.57079632679F);
            }
            if (taperAtEof) {
                // A recording may end away from zero. Taper only its final
                // millisecond at the actual pitched read rate; keep its cursor,
                // duration, release envelope and explicit SAMPLE END fade intact.
                const double remaining = reverse ? v.position : sampleEnd - v.position;
                const double fadeWidth = eofFadeFrames * std::abs(ratioRead);
                if (fadeWidth > 0.0 && std::isfinite(fadeWidth) && remaining < fadeWidth) {
                    const double phase = std::clamp(remaining / fadeWidth, 0.0, 1.0);
                    g *= static_cast<float>(0.5 - 0.5 * std::cos(kPi * phase));
                }
            }
            if (mixMoving) {
                v.mixL += (mixTargetL - v.mixL) * mixSmooth;
                v.mixR += (mixTargetR - v.mixR) * mixSmooth;
            }
            v.lastOutputL = sL * g * v.mixL;
            v.lastOutputR = sR * g * v.mixR;
            outL[i] += v.lastOutputL;
            outR[i] += v.lastOutputR;

            if (waveOn) continue;   // SILVETON_TRANSWAVE_V1: the cycle never runs out; the note ends with its envelope
            if (v.sampleEnded) continue;   // SILVETON_ENGINES_V2: the recording is over; the engine plays on until the envelope ends
            if (reverse) v.position -= ratioRead; else v.position += ratioRead;
            if (!reverse && looping && v.position >= loopEnd) {
                if (loopLen > 0.0) { v.position = loopStart + std::fmod(v.position - loopStart, loopLen); v.loopWrapped = true; }
            }
            if (reverse && v.position < 0.0) { v.ampEnv.forceOff(); v.active = false; break; }
            else if (!looping && v.position >= sampleEnd) {
                // SILVETON_ENGINES_V2 / SILVETON_SUSE_SAMPLE_V1: the recording is over; the engine (or SILVETON SYNTH) plays on until its envelopes end
                if (v.so != nullptr) { v.sampleEnded = true; v.position = std::max(0.0, sampleEnd - 1.0); continue; }
                v.ampEnv.forceOff(); v.active = false; break;
            }
            else if (v.endFrame > 0.0 && !reverse && v.position >= v.endFrame && !v.fading) {
                // SILVETON_TONE_V2: SAMPLE END - the note stops here with a short click-free fade
                softKill(*impl_, v, 0.003F);
            }
        }
        if (mixMoving) {
            if (std::abs(mixTargetL - v.mixL) < 1.0e-6F) v.mixL = mixTargetL;
            if (std::abs(mixTargetR - v.mixR) < 1.0e-6F) v.mixR = mixTargetR;
        }
       }
      };

      // SILVETON_MULTICORE_V1: one core or several - the same buses, the same voices in the
      // same order, so the result is identical. The cores only help when there is enough to
      // do; with a couple of voices the audio thread is quicker on its own.
      if (parallel && (busUsed >= 2 || splitAt)) {
          impl_->pool->share(busUsed + (splitAt ? 1 : 0),
                            [](void* p, int slot) noexcept { (*static_cast<const decltype(renderBus)*>(p))(slot); },
                            const_cast<void*>(static_cast<const void*>(&renderBus)));
      } else {
          for (int slot = 0; slot < busUsed; ++slot) renderBus(slot);
      }

      if (splitAt) {
          const auto bus = impl_->busOrder[0];
          auto& outL = impl_->chunkL[bus / kSoundsPerUpper][bus % kSoundsPerUpper];
          auto& outR = impl_->chunkR[bus / kSoundsPerUpper][bus % kSoundsPerUpper];
          for (unsigned v = splitAt; v < impl_->busVoiceCount[bus]; ++v) {
              for (unsigned i = 0; i < n; ++i) {
                  outL[i] += impl_->splitL[v - splitAt][i];
                  outR[i] += impl_->splitR[v - splitAt][i];
              }
          }
      }

      // A voice may finish after writing its last samples into this chunk.
      // Keep every bus selected before rendering, including its completed tails.
      std::array<std::array<bool, kSoundsPerUpper>, kPartCount> busLive{};
      for (int slot = 0; slot < busUsed; ++slot) {
          const auto bus = static_cast<std::size_t>(impl_->busOrder[static_cast<std::size_t>(slot)]);
          busLive[bus / kSoundsPerUpper][bus % kSoundsPerUpper] = true;
      }
      // Residual-only buses still pass through their ordinary sound/Upper
      // processors and FX sends. Never reuse an unclaimed chunk's old samples.
      for (std::size_t ui = 0U; ui < impl_->takeoverResidual.size(); ++ui) {
          for (std::size_t si = 0U; si < impl_->takeoverResidual[ui].size(); ++si) {
              auto& residual = impl_->takeoverResidual[ui][si];
              if (residual.remaining == 0U) continue;
              auto& chunkL = impl_->chunkL[ui][si];
              auto& chunkR = impl_->chunkR[ui][si];
              if (!busLive[ui][si]) {
                  std::fill_n(chunkL.begin(), n, 0.0F);
                  std::fill_n(chunkR.begin(), n, 0.0F);
              }
              busLive[ui][si] = true;
              for (std::uint32_t ci = 0U; ci < n && residual.remaining > 0U; ++ci)
                  residual.tick(chunkL[ci], chunkR[ci]);
          }
      }
      // Send amounts of every Upper (once per chunk).
      std::array<std::array<float, kFxSendSlots>, kPartCount> sendAmt{};
      for (std::size_t index = 0; index < static_cast<std::size_t>(kPartCount); ++index) {
          const auto& u = current->combi.part(static_cast<int>(index));
          const auto& upperChannel = impl_->channels[static_cast<std::size_t>(u.midiChannel & 0x0FU)];
          const std::uint16_t upperMask = impl_->upperRouteMask[index];
          std::array<float, kFxSendSlots> base{{u.fxSend1, u.fxSend2, u.fxSend3, u.fxSend4}};
          // Original Style sends are channel events, including setup and CV
          // catch-up. Native/manual racks retain their explicit stored sends.
          if (current->combi.sourceEffects && current->combi.sourceEffects->followMidiSends) {
              base[0] = upperChannel.cc[91];
              base[1] = upperChannel.cc[93];
              base[2] = upperChannel.cc[94];
          }
          const std::array<ModDestination, kFxSendSlots> dest{{ModDestination::FxSend1, ModDestination::FxSend2, ModDestination::FxSend3, ModDestination::FxSend4}};
          for (std::size_t s = 0; s < static_cast<std::size_t>(kFxSendSlots); ++s) {
              const bool routed = (upperMask & static_cast<std::uint16_t>(1U << static_cast<unsigned>(dest[s]))) != 0U;
              sendAmt[index][s] = std::clamp(base[s] + (routed ? controllerAmount(u, upperChannel, dest[s], impl_->aftertouchInputEnabled) : 0.0F), 0.0F, 1.0F);
          }
      }

      // SILVETON_EVEN_DECAY_LIVE_V1: КОМБИ > EQ > ЗАТИХВАНЕ of every Upper (0 = off); a new time starts its bands afresh
      std::array<float, kPartCount> decayMs{};
      for (std::size_t index = 0; index < static_cast<std::size_t>(kPartCount); ++index) {
          const float ms = current->combi.part(static_cast<int>(index)).evenDecayMs;
          decayMs[index] = ms >= 30.0F ? ms : 0.0F;
          if (decayMs[index] != impl_->evenDecayApplied[index]) {
              impl_->evenDecay[index].setTimeMs(decayMs[index] > 0.0F ? decayMs[index] : 300.0F);
              impl_->evenDecay[index].reset();
              impl_->evenDecayApplied[index] = decayMs[index];
          }
      }
      std::array<bool, kPartCount> upperLive{};
      for (std::size_t index = 0; index < static_cast<std::size_t>(kPartCount); ++index) {
          for (std::size_t s = 0; s < static_cast<std::size_t>(kSoundsPerUpper); ++s) {
              if (busLive[index][s]) upperLive[index] = true;
          }
      }
      // Skip only provably neutral, silent Uppers. Enabled filters/EQ/inserts
      // still run on zero input, so delayed output and their tails are retained.
      std::array<std::uint8_t, kPartCount> upperOrder{};
      std::size_t upperCount = 0U;
      for (std::size_t index = 0; index < static_cast<std::size_t>(kPartCount); ++index) {
          bool needsMix = upperLive[index] || impl_->channelGates[index].active() || impl_->upperEq[index].any() ||
              insertFxActive[index] ||
              (decayMs[index] > 0.0F && !impl_->evenDecay[index].idle()) ||
              static_cast<int>(index) == tapUpperNow;
          for (const auto& bus : impl_->soundBus[index]) needsMix = needsMix || bus.any();
          if (needsMix) upperOrder[upperCount++] = static_cast<std::uint8_t>(index);
      }
      for (std::uint32_t ci = 0U; ci < n; ++ci) {
        const std::uint32_t i = chunkStart + ci;
        float dryL = 0.0F, dryR = 0.0F;
        std::array<float, kFxSendSlots> sendL{}, sendR{};
        for (std::size_t upperSlot = 0U; upperSlot < upperCount; ++upperSlot) {
            const auto index = static_cast<std::size_t>(upperOrder[upperSlot]);
            // SILVETON_TONE_V2: every sound (basic + layers) through its HP + 3-band EQ, then summed
            float l = 0.0F, r = 0.0F;
            for (std::size_t s = 0; s < static_cast<std::size_t>(kSoundsPerUpper); ++s) {
                auto& bus = impl_->soundBus[index][s];
                if (!busLive[index][s] && !bus.any()) continue;
                float sl = busLive[index][s] ? impl_->chunkL[index][s][ci] : 0.0F;
                float sr = busLive[index][s] ? impl_->chunkR[index][s][ci] : 0.0F;
                if (bus.any()) bus.process(sl, sr);
                l += sl; r += sr;
            }
            // SILVETON_ENGINES_V1: the Upper's ENGINE after the sum of its sounds (before EQ, insert and sends)

            // SILVETON_EVEN_DECAY_LIVE_V1: before the EQ, the insert and the sends (the reverb of the blend keeps its own tail)
            if (decayMs[index] > 0.0F && (upperLive[index] || !impl_->evenDecay[index].idle())) impl_->evenDecay[index].process(l, r);
            auto& gate=impl_->channelGates[index];
            if(gate.active())gate.process(l,r);
            // SILVETON_ANALYZER_V1: before the EQ
            const bool tapped = static_cast<int>(index) == tapUpperNow;
            if (tapped && !tapAfterNow) { impl_->tapRing[tapW].store(0.5F * (l + r), std::memory_order_relaxed); tapW = (tapW + 1U) % static_cast<std::uint32_t>(SamplerEngine::kAnalyzerRing); }
            // SILVETON_EQ5_V1: common EQ of the Upper
            impl_->upperEq[index].process(l, r);
            if (tapped && tapAfterNow) { impl_->tapRing[tapW].store(0.5F * (l + r), std::memory_order_relaxed); tapW = (tapW + 1U) % static_cast<std::uint32_t>(SamplerEngine::kAnalyzerRing); }
            // SILVETON_FX_V3: INSERT of the Upper (wet = mix)
            const EffectSlot& ins = current->combi.insertOf(static_cast<int>(index));   // SILVETON_PLACE_FX_V1: Uppers and SILVETON SYNTH places
            if (insertFxActive[index]) {
                float wl = 0.0F, wr = 0.0F;
                impl_->insertFx[index].process(l, r, ins, wl, wr);
                // Numbered processors already apply their documented internal
                // Wet/Dry parameter. Do not interpolate it for a second time.
                const float mix = ins.numbered.index != 0 ? 1.0F : clamp01(ins.wet);
                if (ins.type == EffectType::Compressor || ins.type == EffectType::Drive) {
                    // Dynamics also use the insert's Dry/Wet control. Keep the
                    // existing full-wet result bit-for-bit; at zero retain dry
                    // samples while the detector/tone state continues running.
                    if (mix >= 1.0F) { l = wl; r = wr; }
                    else if (mix > 0.0F) { l += (wl - l) * mix; r += (wr - r) * mix; }
                } else { l += (wl - l) * mix; r += (wr - r) * mix; }
            }
            upperPeakL[index] = std::max(upperPeakL[index], std::abs(l));
            upperPeakR[index] = std::max(upperPeakR[index], std::abs(r));
            if (!current->combi.sourceEffects || !current->combi.sourceEffects->dryOff[index]) {
                dryL += l;
                dryR += r;
            }
            for (std::size_t s = 0; s < static_cast<std::size_t>(kFxSendSlots); ++s) {
                const float a = sendAmt[index][s];
                if (a > 0.0F) { sendL[s] += l * a; sendR[s] += r * a; }
            }
        }

        const auto runFx = [&](std::size_t slot, std::uint8_t inst, const EffectSlot& fx, float inL, float inR, float& wetL, float& wetR, const SourceFxRenderParameters& source) noexcept {
            impl_->sendFx[slot][inst & 1U].process(inL, inR, fx, wetL, wetR, source.active ? &source : nullptr);
        };
        float l = dryL, r = dryR;
        if (activeSourceGraph.componentMask != 0U) {
            std::array<float, kFxSendSlots> returnedL{}, returnedR{};
            // Evaluate the two upstream processors first. Their complete
            // source Wet/Dry mixtures feed MFX1 once, before outer returns.
            for (std::size_t order = 0; order < static_cast<std::size_t>(kFxSendSlots); ++order) {
                const auto slot = sourceMasterProcessSlot(order);
                const auto& fx = current->combi.fx[slot];
                const auto& source = impl_->fxSourceRunning[slot];
                float inL = sendL[slot], inR = sendR[slot];
                if (slot == 0U) {
                    for (std::size_t upstream = 1U; upstream <= 2U; ++upstream) {
                        inL += returnedL[upstream] * activeSourceGraph.toFirst[upstream];
                        inR += returnedR[upstream] * activeSourceGraph.toFirst[upstream];
                    }
                }
                float wl = 0.0F, wr = 0.0F;
                if (sendFxActive[slot]) runFx(slot, impl_->fxInst[slot], fx, inL, inR, wl, wr, source);
                const bool decodedReturn = decodedSourceFxActive(source);
                const float w = decodedReturn ? 1.0F : clamp01(fx.wet);
                returnedL[slot] = wl * w; returnedR[slot] = wr * w;
                if (source.active && !decodedReturn) {
                    returnedL[slot] += inL * (1.0F - w);
                    returnedR[slot] += inR * (1.0F - w);
                }
            }
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                l += returnedL[slot]; r += returnedR[slot];
            }
        } else {
        float prevWetL = 0.0F, prevWetR = 0.0F;
        for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
            const EffectSlot& fx = current->combi.fx[slot];
            float inL = sendL[slot], inR = sendR[slot];
            if (slot == 1U && current->combi.fxRouting == EffectRouting::Fx1IntoFx2) {
                const float chainGain = clamp01(current->combi.fx[0].wet);
                inL += prevWetL * chainGain; inR += prevWetR * chainGain;
            }
            float wl = 0.0F, wr = 0.0F;
            if (sendFxActive[slot]) runFx(slot, impl_->fxInst[slot], fx, inL, inR, wl, wr, impl_->fxSourceRunning[slot]);
            // A decoded numbered source already returns the original Wet/Dry
            // mixture. Keep fx.wet as the native/editor summary, but do not
            // apply it a second time or add another dry send-return copy.
            const bool decodedReturn = impl_->fxSourceRunning[slot].active &&
                impl_->fxSourceRunning[slot].numbered.index != 0;
            const float w = decodedReturn ? 1.0F : clamp01(fx.wet);
            l += wl * w; r += wr * w;
            if (impl_->fxSourceRunning[slot].active && !decodedReturn) {
                // Source Wet/Dry is the balance inside this MFX return. The
                // independent part dry path is controlled by its XML dryOff.
                l += inL * (1.0F - w); r += inR * (1.0F - w);
            }
            prevWetL = wl; prevWetR = wr;
        }
        }
        // SILVETON_FX_TAIL_V1: the effect of the previous BLEND rings out by itself.
        if (outgoingSourceGraph.componentMask != 0U) {
            std::array<float, kFxSendSlots> outgoingL{}, outgoingR{};
            for (std::size_t order = 0; order < static_cast<std::size_t>(kFxSendSlots); ++order) {
                const auto slot = sourceMasterProcessSlot(order);
                if (impl_->tailLeft[slot] == 0U) continue;
                float inL = 0.0F, inR = 0.0F;
                if (slot == 0U) {
                    for (std::size_t upstream = 1U; upstream <= 2U; ++upstream) {
                        inL += outgoingL[upstream] * outgoingSourceGraph.toFirst[upstream];
                        inR += outgoingR[upstream] * outgoingSourceGraph.toFirst[upstream];
                    }
                }
                runFx(slot, impl_->tailInst[slot], impl_->tailCfg[slot], inL, inR,
                    outgoingL[slot], outgoingR[slot], impl_->tailSourceCfg[slot]);
            }
            // Fade each final return once. Fading before the edge would fade
            // an upstream tail twice and change the destination's excitation.
            for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
                if (impl_->tailLeft[slot] == 0U) continue;
                const float tl = outgoingL[slot], tr = outgoingR[slot];
                const float w = decodedSourceFxActive(impl_->tailSourceCfg[slot]) ?
                    1.0F : clamp01(impl_->tailCfg[slot].wet);
                float fade = 1.0F;
                if (impl_->tailLeft[slot] < tailFadeFrames)
                    fade = static_cast<float>(impl_->tailLeft[slot]) / static_cast<float>(tailFadeFrames);
                l += tl * w * fade; r += tr * w * fade;
                if (std::abs(tl) + std::abs(tr) < 2.0e-5F) ++impl_->tailQuiet[slot]; else impl_->tailQuiet[slot] = 0U;
                --impl_->tailLeft[slot];
                // A long upstream delay can be silent for more than 300 ms
                // and still excite its destination later. A linked snapshot
                // retains the existing bounded 20-second maximum lifetime.
                if (impl_->tailSnapshot[slot] == 0U && impl_->tailQuiet[slot] > tailQuietFrames)
                    impl_->tailLeft[slot] = 0U;
            }
        } else {
        for (std::size_t slot = 0; slot < static_cast<std::size_t>(kFxSendSlots); ++slot) {
            if (impl_->tailLeft[slot] == 0U) continue;
            float tl = 0.0F, tr = 0.0F;
            runFx(slot, impl_->tailInst[slot], impl_->tailCfg[slot], 0.0F, 0.0F, tl, tr, impl_->tailSourceCfg[slot]);
            const bool decodedReturn = impl_->tailSourceCfg[slot].active &&
                impl_->tailSourceCfg[slot].numbered.index != 0;
            const float w = decodedReturn ? 1.0F : clamp01(impl_->tailCfg[slot].wet);
            float fade = 1.0F;
            if (impl_->tailLeft[slot] < tailFadeFrames) fade = static_cast<float>(impl_->tailLeft[slot]) / static_cast<float>(tailFadeFrames);
            l += tl * w * fade;
            r += tr * w * fade;
            if (std::abs(tl) + std::abs(tr) < 2.0e-5F) ++impl_->tailQuiet[slot]; else impl_->tailQuiet[slot] = 0U;
            --impl_->tailLeft[slot];
            if (impl_->tailSnapshot[slot] == 0U && impl_->tailQuiet[slot] > tailQuietFrames) impl_->tailLeft[slot] = 0U;
        }
        }

        if (current->global.eqLowDb != 0.0F) impl_->lowEq.process(l, r);
        if (current->global.eqMidDb != 0.0F) impl_->midEq.process(l, r);
        if (current->global.eqHighDb != 0.0F) impl_->highEq.process(l, r);
        // MASTER keeps its existing scaling; the optional sample-peak limiter adds no lookahead.
        l *= masterGain; r *= masterGain;

        if (!std::isfinite(l)) l = 0.0F;
        if (!std::isfinite(r)) r = 0.0F;
        if (limiterOn) {
            const float peak = std::max(std::abs(l), std::abs(r));
            const float required = peak > limiterCeiling ? limiterCeiling / peak : 1.0F;
            // One gain for both channels preserves the stereo balance. Immediate attack
            // catches this sample; an 80 ms release avoids gain jumping between peaks.
            const float released = impl_->limiterGain + (1.0F - impl_->limiterGain) * limiterRelease;
            impl_->limiterGain = std::min(required, released);
            minimumLimiterGain = std::min(minimumLimiterGain, impl_->limiterGain);
            l *= impl_->limiterGain; r *= impl_->limiterGain;
        }
        // Include the shared reverb/delay return when a whole engine is excluded.
        if(impl_->listenPart==-2||impl_->listenBusGain<1.0F){
            const float target=impl_->listenPart==-2?0.0F:1.0F;
            impl_->listenBusGain+=(target-impl_->listenBusGain)*mixSmooth;
            if(std::abs(target-impl_->listenBusGain)<.0001F)impl_->listenBusGain=target;
            l*=impl_->listenBusGain;r*=impl_->listenBusGain;
        }
        out[static_cast<std::size_t>(i) * 2U] = l;
        out[static_cast<std::size_t>(i) * 2U + 1U] = r;
        peakL = std::max(peakL, std::abs(l));
        peakR = std::max(peakR, std::abs(r));
      }
    }

    // SILVETON_MULTICORE_V1: how many cores actually shared this block (1 = only the audio
    // thread). Read and cleared once per block, for the display.
    {
        const unsigned mask = impl_->pool->workedMask.exchange(0U, std::memory_order_acq_rel);
        int used = 1;
        for (unsigned bit = mask; bit != 0U; bit &= bit - 1U) ++used;
        impl_->coresWorking.store(used, std::memory_order_relaxed);
    }
    for (std::size_t vi = 0; vi < impl_->voices.size(); ++vi) {
        publishVoiceWindows(*impl_, vi);
        auto& v = impl_->voices[vi];
        if (!v.active) {
            // Node pins retain the final owners for off-audio reclamation.
            // Do not keep an old bank alive just because a dead voice slot has
            // not yet been reused by another note.
            v.sample.reset(); v.ownerState.reset();
            v.waveTable.reset(); v.ownerWaveMap.reset();
            v.layer = nullptr; v.zone = nullptr; v.upper = nullptr;
        }
    }

    for(std::size_t i=0;i<impl_->channelGates.size();++i){
        auto& gate=impl_->channelGates[i];
        const float gr=gate.active()?static_cast<float>(gate.circuit.consumeMaxGateReductionDb()):0;
        impl_->gateMeters[i].store(gr,std::memory_order_relaxed);
    }
    if (tapUpperNow >= 0) impl_->tapWrite.store(tapW, std::memory_order_release);
    impl_->peakL = peakL;
    impl_->peakR = peakR;
    impl_->limiterGrDb = limiterOn ? -gainToDb(minimumLimiterGain) : 0.0F;
    impl_->upperPeakL = upperPeakL;
    impl_->upperPeakR = upperPeakR;

    // SILVETON_CPU_METER_V1: DSP time of this block as a share of its length,
    // held at its peak and let down slowly so the display is readable.
    {
        const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - renderStart).count();
        const double blockSec = static_cast<double>(frames) / impl_->sampleRate;
        const float now = static_cast<float>(std::clamp(elapsed / std::max(1.0e-9, blockSec) * 100.0, 0.0, 999.0));
        impl_->cpuLoadHold = std::max(now, impl_->cpuLoadHold * (1.0F - static_cast<float>(blockSec) * 2.0F));
        impl_->cpuLoad.store(impl_->cpuLoadHold, std::memory_order_relaxed);
    }
    impl_->publishMeters();
    impl_->captureVoiceActivity();
}

bool SamplerEngine::pollVoiceActivity(VoiceActivity& out) noexcept {
    const auto state=impl_->activityState.load(std::memory_order_acquire);
    if(state==Impl::ActivityState::Requested)return false;
    if(state==Impl::ActivityState::Ready)out=impl_->activity;
    impl_->activityState.store(Impl::ActivityState::Requested,std::memory_order_release);
    return state==Impl::ActivityState::Ready;
}

MeterSnapshot SamplerEngine::meters() const noexcept {
    MeterSnapshot out{};
    const auto& m = impl_->publishedMeters;
    for (int attempt = 0; attempt < 3; ++attempt) {
        const auto seq = m.seq.load(std::memory_order_acquire);
        out.peakLeft = m.left.load(std::memory_order_relaxed);
        out.peakRight = m.right.load(std::memory_order_relaxed);
        out.limiterGainReductionDb = m.reduction.load(std::memory_order_relaxed);
        out.activeVoices = m.voices.load(std::memory_order_relaxed);
        for (std::size_t i = 0; i < out.upperPeakLeft.size(); ++i) {
            out.upperPeakLeft[i] = m.upperLeft[i].load(std::memory_order_relaxed);
            out.upperPeakRight[i] = m.upperRight[i].load(std::memory_order_relaxed);
        }
        out.cpuLoadPercent = m.cpu.load(std::memory_order_relaxed);
        out.coresWorking = static_cast<std::uint8_t>(std::clamp(m.cores.load(std::memory_order_relaxed), 1, 8));
        std::atomic_thread_fence(std::memory_order_acquire);
        if ((seq & 1U) == 0U && m.seq.load(std::memory_order_relaxed) == seq) break;
    }
    out.droppedEvents = events_.droppedCount();
    return out;
}

std::uint32_t SamplerEngine::activeVoiceCount() const noexcept {
    return impl_->publishedMeters.voices.load(std::memory_order_relaxed);
}

} // namespace silveton::sampler
