#include "silveton/sampler/NumberedTimeFx.h"
#include "silveton/sampler/NumberedFxKernel.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <limits>
#include <utility>

namespace silveton::sampler {
namespace {
using namespace numbered_fx;

constexpr const char* kOwn = "Собствен DSP SILVETON; не е звуково копие на Korg. DMS е Off. Кривите и началните стойности са наши.";
constexpr const char* kBpm = "Собствен DSP; Base Note е фиксирана документирана цяла нота. Работят ръчни BPM и Times; външен MIDI Clock и DMS не са свързани. Над допустимото време настройката се отказва.";
constexpr const char* kLfo = "Собствен DSP; LFO работи, външните D-mod/LFO trigger са изключени. При BPM Sync базата е фиксирана цяла нота и темпото е ръчно.";
constexpr const char* kHold = "Реален моно запис, повторение и overdub до 10.8 s. Manual REC/RST работят; DMS е Off. BPM режимът използва фиксирана цяла нота. Аудиото на цикъла не се записва в preset.";
constexpr const char* kSequence = "Собствен фиксиран ритъм: четири активни шестнадесетини в един удар. BPM, четирите Pan, Feedback и Damp работят. Оригиналното меню Rhythm Pattern не е декодирано; MIDI Clock и DMS са Off.";

bool owns(std::uint16_t i) noexcept {
    return (i >= 55 && i <= 76) || (i >= 165 && i <= 170) || i == 179 || i == 180 || i == 182 || i == 194;
}
bool bpmDelay(std::uint16_t i) noexcept { return (i >= 64 && i <= 69) || i == 168 || i == 169; }
bool modDelay(std::uint16_t i) noexcept { return i == 58 || i == 67; }
bool panDelay(std::uint16_t i) noexcept { return i == 60 || i == 68; }
bool isReverb(std::uint16_t i) noexcept { return (i >= 70 && i <= 76) || i == 170 || i == 180 || i == 182 || i == 194; }
bool amountOnly(const NumberedFxParamDescriptor& p) noexcept {
    return std::strstr(p.label, "Input Level Dmod") || std::strcmp(p.label, "Amt") == 0 ||
           std::strncmp(p.label, "Amt ", 4) == 0;
}
bool readonly(const NumberedFxParamDescriptor& p) noexcept {
    return std::strstr(p.label, "Time Over") ||
           (p.choiceCount == 2 && std::strcmp(p.choices[1].label, "OVER!") == 0);
}
double get(const NumberedFxState& s, const char* row) noexcept { return value(s, row); }
double percent(const NumberedFxState& s, const char* row) noexcept { return get(s, row) * .01; }
double feedback(double v) noexcept { return std::clamp(v * .01, -.9995, .9995); }
double noteMs(const NumberedFxState& s, const char* bpm, const char* times) noexcept {
    // The only fixed musical-note choice used here is the visible whole-note
    // endpoint. No undocumented intermediate menu or wire enum is invented.
    const double tempo = get(s, bpm);
    return tempo >= 40 ? 240000.0 * get(s, times) / tempo : std::numeric_limits<double>::infinity();
}

struct Times {
    double left{0}, right{0}, center{0}, limit{0};
};
Times times(const NumberedFxState& s) noexcept {
    switch (s.index) {
        case 55: case 165: return {get(s,"a_1"), get(s,"c_1"), get(s,"b_1"), s.index == 55 ? 2730.0 : 5460.0};
        case 56: case 166: return {get(s,"b_1"), get(s,"c_1"), 0, s.index == 56 ? 1360.0 : 2730.0};
        case 57: return {get(s,"b_1"), get(s,"c_1"), 0, 1360};
        case 58: return {get(s,"i_1"), get(s,"j_1"), 0, 1000};
        case 59: return {get(s,"e_1"), get(s,"f_1"), 0, 1360};
        case 60: return {get(s,"a_1"), get(s,"b_1"), 0, 1360};
        case 61: return {get(s,"a_1"), 0, 0, 2700};
        case 64: case 168: return {noteMs(s,"a_1","b_2"), noteMs(s,"a_1","d_2"), noteMs(s,"a_1","c_2"), s.index == 64 ? 5460.0 : 10920.0};
        case 65: case 169: return {noteMs(s,"a_1","b_2")*(1+percent(s,"b_3")), noteMs(s,"a_1","c_2")*(1+percent(s,"c_3")), 0, s.index == 65 ? 2730.0 : 5460.0};
        // The manual names an upper limit for 66/68 but does not state its
        // number. 5460 ms/channel is our declared full-rate operational bound.
        case 66: return {noteMs(s,"b_1","c_2"), noteMs(s,"b_1","d_2"), 0, 5460};
        case 67: return {noteMs(s,"i_1","j_2"), noteMs(s,"i_1","k_2"), 0, 2550};
        case 68: return {noteMs(s,"a_1","b_2"), noteMs(s,"a_1","c_2"), 0, 5460};
        case 69: return {noteMs(s,"a_1","b_2"), 0, 0, 5400};
        case 179: return {get(s,"a_1"), 0, 0, 2700};
        default: return {};
    }
}

bool lockedChoiceValid(const NumberedFxState& s) noexcept {
    if (modDelay(s.index) && (get(s,"a_1") != 0 || get(s,"b_1") != 0 ||
                            get(s,"b_3") != 0 || get(s,"d_1") != 0)) return false;
    if (s.index == 62 && get(s,"c_1") != 1) return false;
    if (s.index == 69 && get(s,"c_2") != 1) return false;
    if (s.index == 62 && get(s,"a_1") == 1 && get(s,"b_1") > 1320) return false;
    if (s.index == 167 && get(s,"b_1") != 0 && noteMs(s,"c_1","d_2") > 10800) return false;
    const auto t = times(s);
    return t.limit == 0 || (t.left >= 0 && t.right >= 0 && t.center >= 0 &&
                            t.left <= t.limit && t.right <= t.limit && t.center <= t.limit);
}

struct Pole {
    double z{0}, coefficient{0};
    void frequency(double sr, double hz) noexcept { coefficient = std::exp(-2*pi*std::clamp(hz, 5.0, sr*.475)/sr); }
    float low(float x) noexcept {
        z = x + coefficient*(z-x);
        if (!std::isfinite(z)) z = 0;
        if (std::abs(z) < 1.e-25) z = 0;
        return static_cast<float>(z);
    }
};
struct Damp {
    Pole high{}, low{};
    double highAmount{0}, lowAmount{0};
    void configure(double sr, double hi, double lo) noexcept {
        highAmount = std::clamp(hi*.01, 0.0, 1.0);
        lowAmount = std::clamp(lo*.01, 0.0, 1.0);
        high.frequency(sr, 20000*std::pow(.015, highAmount));
        low.frequency(sr, 30*std::pow(20.0, lowAmount));
    }
    void reset() noexcept { high.z = low.z = 0; }
    float process(float x) noexcept {
        const float lowPassed = high.low(x);
        x = static_cast<float>(x + highAmount*(lowPassed-x));
        return static_cast<float>(x-lowAmount*low.low(x));
    }
};

float safe(float x) noexcept { return std::clamp(finite(x), -64.0F, 64.0F); }
float saturate(float x, double drive) noexcept {
    if (drive <= 1.000001) return safe(x);
    return static_cast<float>(std::tanh(x*drive)/drive);
}
double threshold(double x) noexcept { return x <= 0 ? 1.e-8 : db(-80+.8*x); }
void spread(float& l, float& r, double width) noexcept {
    const float mid = (l+r)*.5F, side = static_cast<float>((l-r)*.5*width);
    l = mid+side; r = mid-side;
}
void pan(float x, double position, float& l, float& r) noexcept {
    // Constant-power panning in our semantic normalized 0..1 domain.
    position = std::clamp(position, 0.0, 1.0);
    l += static_cast<float>(x*std::sqrt(1-position));
    r += static_cast<float>(x*std::sqrt(position));
}
double wave(double phase, int waveform, double shape) noexcept {
    phase -= std::floor(phase);
    double x = waveform == 0 ? 1-4*std::abs(phase-.5) : std::sin(2*pi*phase);
    // An explicit own curvature law, not a reverse-engineered Korg curve.
    const double exponent = std::pow(4.0, -shape);
    return std::copysign(std::pow(std::abs(x), exponent), x);
}
} // namespace

NumberedFxSupport numberedTimeFxSupport(std::uint16_t index) noexcept {
    if (!owns(index)) return {};
    auto mask = editableMainMask(index);
    const auto* descriptor = findNumberedFx(index);
    if (!descriptor) return {};
    for (std::size_t n=0; n<descriptor->parameterCount; ++n) {
        const auto& p = descriptor->parameters[n];
        if (amountOnly(p) || readonly(p)) lockRow(mask,index,p.rowId);
    }
    if (modDelay(index)) for (const auto* row : {"a_1","b_1","b_3","d_1"}) lockRow(mask,index,row);
    if (index == 62) lockRow(mask,index,"c_1");
    if (index == 69) lockRow(mask,index,"c_2");
    return {true, mask, index == 63 ? kSequence : index == 167 ? kHold : bpmDelay(index) ? kBpm :
        (modDelay(index) || panDelay(index)) ? kLfo : kOwn};
}

bool numberedTimeFxCanRender(const NumberedFxState& s) noexcept {
    if(s.origin==NumberedFxOrigin::Decoded&&!decodedSourceStateComplete(s)){
        // Existing partial source-decoder contract: six static reverbs with
        // zero EQ gain. A complete source state instead goes through the same
        // algorithm/DMS/live-bus checks below as the other semantic states.
        // The decoder separately validates original owner/activation/routing,
        // the complete zero modulation region, and all remaining packed bits.
        // Do not relax the global manual/DMS contract or infer unknown rows.
        if(s.index<70||s.index>75||!s.valid())return false;
        const bool room=s.index>=74;
        std::uint64_t expected=0;
        const auto require=[&](const char* row){
            const auto* p=findNumberedFxParam(s.index,row);
            if(!p||p->role!=NumberedFxParamRole::Parameter||!s.known(p->ordinal))return false;
            expected|=std::uint64_t{1}<<p->ordinal;return true;
        };
        for(const auto* row:{"a_1","a_2","b_1","b_2"})if(!require(row))return false;
        for(const auto* row:{room?"e_1":"c_1",room?"g_1":"e_1",
                            room?"g_2":"e_2",room?"h_1":"f_1"})if(!require(row))return false;
        if(room&&(!require("c_1")||!require("d_1")))return false;
        return s.knownMask==expected&&get(s,room?"g_1":"e_1")==0&&get(s,room?"g_2":"e_2")==0;
    }
    if (!numberedTimeFxSupport(s.index).selectable || !baseStateValid(s)) return false;
    const auto* d = findNumberedFx(s.index);
    for (std::size_t n=0; n<d->parameterCount; ++n) {
        const auto& p = d->parameters[n];
        if (!s.known(p.ordinal)) continue;
        const double v = s.values[p.ordinal];
        if ((amountOnly(p) || readonly(p)) && v != 0 && !decodedModulationInactive(s, p)) return false;
        // External tempo and trigger buses are not part of this API.
        if (std::strstr(p.label,"BPM") && p.kind == NumberedFxValueKind::RangeWithChoices && v < 40) return false;
    }
    return lockedChoiceValid(s);
}

bool initializeNumberedTimeFx(std::uint16_t index, NumberedFxState& state) noexcept {
    if (!numberedTimeFxSupport(index).selectable) return false;
    NumberedFxState s;
    if (!initializeKnown(index,s)) return false;
    const auto* d = findNumberedFx(index);
    for (std::size_t n=0;n<d->parameterCount;++n) {
        const auto& p=d->parameters[n];
        if (!s.known(p.ordinal)) continue;
        if (std::strstr(p.label,"BPM") && p.kind==NumberedFxValueKind::RangeWithChoices) setInitial(s,p.rowId,120);
        if (std::strcmp(p.label,"EQ Trim")==0 || std::strcmp(p.label,"Trim")==0 || std::strcmp(p.label,"Input Trim")==0) setInitial(s,p.rowId,100);
        if (std::strstr(p.label,"High Damp") || std::strcmp(p.label,"Hi Damp")==0) setInitial(s,p.rowId,25);
    }
    auto put=[&](const char* row,double v){ return setInitial(s,row,v); };
    switch(index) {
        case 55: case 165:
            put("a_1",240);put("b_1",360);put("c_1",480);
            put("a_2",35);put("b_2",25);put("c_2",35);put("d_1",30);put("g_1",50);break;
        case 56: case 166:
            put("b_1",350);put("c_1",470);put("d_1",30);put("e_1",30);put("i_1",50);break;
        case 57: case 66:
            if(index==57){put("b_1",230);put("c_1",460);put("d_1",60);put("e_1",30);}
            else {put("d_2",2);put("e_1",60);put("f_1",30);}
            put("i_1",100);break;
        case 58: case 67:
            put("c_1",1);put("e_1",.4);put("g_2",25);put("h_1",90);put("h_2",25);
            if(index==58){put("i_1",280);put("j_1",390);put("i_2",30);put("j_2",30);}
            else {put("j_3",30);put("k_3",30);}break;
        case 59:
            put("a_1",1);put("a_2",1);put("b_1",55);put("b_2",20);put("c_1",20);put("d_1",50);
            put("e_1",320);put("f_1",440);put("g_1",35);put("i_1",100);break;
        case 60: case 68:
            if(index==60){put("a_1",320);put("a_2",30);put("b_1",440);put("b_2",30);put("d_1",1);put("e_1",180);}
            else {put("b_3",30);put("c_3",30);put("e_1",1);put("e_3",180);}
            put("f_1",.5);put("h_1",80);break;
        case 61:
            put("a_1",450);put("b_1",50);put("c_1",75);
            put("d_1",80);put("d_2",10);put("d_3",60);put("e_1",50);put("e_2",50);put("e_3",20);
            put("f_1",60);put("f_2",90);put("f_3",20);put("g_1",45);put("i_1",25);put("j_2",55);put("k_1",.3);put("k_2",15);break;
        case 62:put("b_1",900);put("c_1",1);put("d_1",35);put("e_1",25);break;
        case 63:put("c_1",0);put("c_2",65);put("c_3",35);put("c_4",100);put("d_1",30);break;
        case 64: case 168:
            put("b_3",35);put("c_3",25);put("d_3",35);put("e_1",30);put("h_1",50);break;
        case 65: case 169:put("d_1",30);put("e_1",30);put("c_3",1);break;
        case 69:
            put("d_1",50);put("e_1",75);put("f_1",80);put("f_2",10);put("f_3",60);
            put("g_1",50);put("g_2",50);put("g_3",20);put("h_1",60);put("h_2",90);put("h_3",20);
            put("i_1",45);put("k_1",25);put("l_2",55);put("m_1",.3);put("m_2",15);break;
        case 70: case 71: case 72: case 73:put("a_1",index==71?2.8:index==73?1.1:1.8);put("b_1",18);break;
        case 74: case 75:put("a_1",.8);put("b_1",12);put("c_1",80);put("d_1",70);break;
        case 76: case 170:put("b_1",index==170?500:240);put("c_1",10);break;
        case 167:put("a_1",kNumberedFxChoiceBase);break;
        case 179:put("a_1",420);put("b_1",40);put("c_1",60);put("d_1",15);break;
        case 180: case 182:put("a_1",index==180?45:25);put("a_2",10);put("a_3",30);put("a_4",8);break;
        case 194:
            put("b_2",400);put("b_3",1);put("c_2",4500);put("c_3",1);put("d_1",15);put("e_1",20);
            put("e_2",50);put("e_3",50);put("f_1",50);put("f_2",65);put("f_3",45);
            put("g_1",60);put("g_2",250);put("h_1",.4);put("h_2",20);break;
        default:return false;
    }
    if (!numberedTimeFxCanRender(s)) return false;
    state=s;
    return true;
}

struct NumberedTimeFx::Impl {
    double sr{48000}; float* workspace{nullptr};std::size_t samples{0},used{0};
    bool ready{false},active{false};std::uint16_t index{0};
    NumberedFxState state{};
    std::array<Ring,24> ring{};
    std::array<Damp,16> damping{};
    std::array<Biquad,4> eq{};
    std::array<Pole,16> bass{};
    Pole tone{},rollL{},rollR{};
    std::array<double,3> delay{},levels{{1,1,1}},fb{{0,0,0}},pans{{0,.5,1}};
    std::array<double,4> sequencePan{{0,.65,.35,1}};
    double sequenceBeat{0};
    double wetAmount{1},wetCurrent{0},wetCoefficient{0},width{1},preDelay{0},preThru{0},trim{1},drive{1};
    double phase{0},phaseStep{0},phaseR{0},shape{0},depthL{0},depthR{0},panDepth{0};
    int waveform{1},mode{0};
    double detector{0},detectorFall{0},envelope{0},attack{0},release{0},thresholdAmp{0},offset{0};
    int dynamicTarget{0};bool negative{false};
    // Reverb topology: borrowed rings0=pre,1=ER,2..13=feedback,
    // 14..21=input diffusers; the delay families reuse these same slices.
    int lines{0},diffusers{0},erCount{0};
    std::array<double,12> lineTime{},lineGain{},bassGain{},linePhase{};
    std::array<double,8> diffuserTime{},diffuserGain{};
    std::array<double,64> erDelay{},erL{},erR{};
    std::array<std::array<double,4>,12> springMemory{};
    double reverbLevel{1},earlyLevel{0},mixCos{1},mixSin{0},reverbMod{0};
    bool spring{false},overb{false};
    // Hold/reverse validity is logical and bounded: no full-buffer clear in RT.
    std::size_t holdLength{0},holdPos{0},holdValid{0},holdAutoFrames{0},holdMaximum{0};
    bool holdRec{false},holdReset{false},holdAuto{true},holdGrowing{false};
    std::array<float*,2> reverseData{{nullptr,nullptr}};
    std::size_t reverseCapacity{0},reverseLimit{0},reverseWritten{0},reverseRead{0};
    int recordBank{0},playBank{-1},directMix{0};bool recording{false},above{false};
    double reverseGain{0};

    void reset() noexcept;
    bool layout() noexcept;
    void configure(const NumberedFxState& s) noexcept;
    void configureReverb(const NumberedFxState& s) noexcept;
    void processDelay(float,float,float&,float&) noexcept;
    void processReverb(float,float,float&,float&) noexcept;
    void processReverse(float,float&,float&) noexcept;
    void processHold(float,float&,float&) noexcept;
    float allpass(std::size_t n,float x,double time,double gain) noexcept {
        const float y=static_cast<float>(ring[n].read(time)-gain*x);
        ring[n].push(safe(static_cast<float>(x+gain*y)));
        return y;
    }
    bool attach(std::size_t n,double seconds) noexcept {
        const auto count=static_cast<std::size_t>(std::ceil(seconds*sr))+4;
        if(n>=ring.size() || count>samples-used) return false;
        ring[n].attach(workspace+used,count); used+=count;return true;
    }
};

void NumberedTimeFx::Impl::reset() noexcept {
    for(auto& r:ring)r.reset();for(auto& d:damping)d.reset();for(auto& f:eq)f.reset();
    for(auto& b:bass)b.z=0;tone.z=rollL.z=rollR.z=0;
    for(auto& a:springMemory)a.fill(0);
    phase=detector=envelope=reverseGain=wetCurrent=0;
    holdLength=holdPos=holdValid=holdAutoFrames=0;holdGrowing=false;
    reverseWritten=reverseRead=0;recordBank=0;playBank=-1;recording=above=false;
}

bool NumberedTimeFx::Impl::layout() noexcept {
    used=0;for(auto& r:ring)r.attach(nullptr,0);
    if(index==62){
        reverseCapacity=static_cast<std::size_t>(std::ceil(sr*2.64))+2;
        if(reverseCapacity*2>samples)return false;
        reverseData={workspace,workspace+reverseCapacity};return true;
    }
    if(index==167){holdMaximum=static_cast<std::size_t>(std::floor(sr*10.8));return holdMaximum<samples;}
    if(isReverb(index)){
        if(!attach(0,index==194?1.361:.201)||!attach(1,1.802))return false;
        // Maximum line reservation covers all sizes/modulations; topology
        // changes select a new layout without allocation or history clearing.
        for(int n=0;n<12;++n)if(!attach(2+n,.153))return false;
        for(int n=0;n<8;++n)if(!attach(14+n,.037))return false;
        return true;
    }
    if(index==55||index==165||index==63||index==64||index==168||index==61||index==69||index==179){ring[0].attach(workspace,samples);return true;}
    const auto half=samples/2;
    ring[0].attach(workspace,half);ring[1].attach(workspace+half,half);return half>4;
}

void NumberedTimeFx::Impl::configure(const NumberedFxState& s) noexcept {
    if(!ready||!numberedTimeFxCanRender(s)){active=false;reset();return;}
    const bool changed=index!=s.index||!active;
    bool loopTimeChanged=false;
    if(!changed&&index==167){
        const bool oldSync=get(state,"b_1")!=0, newSync=get(s,"b_1")!=0;
        const auto effectiveLength=[&](const NumberedFxState& v) noexcept {
            const bool sync=get(v,"b_1")!=0;
            // Zero identifies Auto, while fixed/BPM loops have at least one
            // sample. Ignore controls belonging to the inactive timing mode.
            if(!sync&&get(v,"a_1")==kNumberedFxChoiceBase)return std::size_t{0};
            const double ms=sync?noteMs(v,"c_1","d_2"):get(v,"a_1");
            return static_cast<std::size_t>(std::clamp(ms*.001*sr,1.0,static_cast<double>(holdMaximum)));
        };
        loopTimeChanged=oldSync!=newSync||effectiveLength(state)!=effectiveLength(s);
    }
    if(changed){index=s.index;reset();if(!layout()){active=false;return;}}
    if(loopTimeChanged)reset();
    active=true;wetAmount=wet(s);trim=1;drive=1;mode=0;phaseR=0;shape=0;depthL=depthR=0;panDepth=0;
    width=1;levels={1,1,1};fb={0,0,0};
    const auto t=times(s);delay={t.left*sr*.001,t.right*sr*.001,t.center*sr*.001};
    auto damp=[&](const char* h,const char* l){for(int n=0;n<2;++n)damping[n].configure(sr,get(s,h),get(s,l));};
    if(isReverb(index))configureReverb(s);
    else switch(index){
        case 55:case 165:case 64:case 168:{
            const bool tempo=bpmDelay(index);
            levels={get(s,tempo?"b_3":"a_2")/50,get(s,tempo?"d_3":"c_2")/50,get(s,tempo?"c_3":"b_2")/50};
            fb[0]=feedback(get(s,tempo?"e_1":"d_1"));width=get(s,tempo?"h_1":"g_1")/50;
            damp(tempo?"f_1":"e_1",tempo?"f_2":"e_2");break;}
        case 56:case 166:case 65:case 169:
            mode=(index==56||index==166)?static_cast<int>(get(s,"a_1")):0;
            fb={feedback(get(s,"d_1")),feedback(get(s,"e_1")),0};damp("f_1","g_1");
            if(index==56||index==166)width=get(s,"i_1")/50;break;
        case 57:case 66:
            mode=static_cast<int>(get(s,"a_1"));levels[0]=percent(s,index==57?"d_1":"e_1");
            fb[0]=fb[1]=feedback(get(s,index==57?"e_1":"f_1"));width=percent(s,"i_1");
            damp(index==57?"f_1":"g_1",index==57?"g_1":"g_2");break;
        case 58:case 67:{
            waveform=static_cast<int>(get(s,"c_1"));shape=percent(s,"c_2");
            phaseStep=(get(s,"f_1")?1000/noteMs(s,"f_2","f_4"):get(s,"e_1"))/sr;
            phaseR=get(s,"h_1")/360;levels[2]=get(s,"g_1")/360;
            depthL=get(s,"g_2")*.025*sr*.001;depthR=get(s,"h_2")*.025*sr*.001;
            fb={feedback(get(s,index==58?"i_2":"j_3")),feedback(get(s,index==58?"j_2":"k_3")),0};
            for(int n=0;n<2;++n)damping[n].configure(sr,0,0);break;}
        case 59:
            fb[0]=fb[1]=feedback(get(s,"g_1"));damp("h_1","h_2");width=percent(s,"i_1");
            dynamicTarget=static_cast<int>(get(s,"a_1"));negative=get(s,"a_2")!=0;thresholdAmp=threshold(get(s,"b_1"));offset=percent(s,"b_2");
            attack=std::exp(-1/(sr*.001*.2*std::pow(500.0,(get(s,"c_1")-1)/99)));
            release=std::exp(-1/(sr*.001*5*std::pow(400.0,(get(s,"d_1")-1)/99)));
            detectorFall=std::exp(-1/(sr*.02));break;
        case 60:case 68:{
            const bool tempo=index==68;
            fb={feedback(get(s,tempo?"b_3":"a_2")),feedback(get(s,tempo?"c_3":"b_2")),0};
            damp(tempo?"d_1":"c_1",tempo?"d_2":"c_2");
            waveform=static_cast<int>(get(s,tempo?"e_1":"d_1"));shape=percent(s,tempo?"e_2":"d_2");
            phaseR=get(s,tempo?"e_3":"e_1")/360;
            phaseStep=(get(s,"g_1")?1000/noteMs(s,"g_2","g_4"):get(s,"f_1"))/sr;
            panDepth=percent(s,"h_1");break;}
        case 61:case 69:{
            const bool tempo=index==69;
            delay[1]=delay[0]*percent(s,tempo?"d_1":"b_1");delay[2]=delay[0]*percent(s,tempo?"e_1":"c_1");
            const std::array<const char*,3> lev=tempo?std::array<const char*,3>{"f_1","g_1","h_1"}:std::array<const char*,3>{"d_1","e_1","f_1"};
            const std::array<const char*,3> panRows=tempo?std::array<const char*,3>{"f_2","g_2","h_2"}:std::array<const char*,3>{"d_2","e_2","f_2"};
            const std::array<const char*,3> feed=tempo?std::array<const char*,3>{"f_3","g_3","h_3"}:std::array<const char*,3>{"d_3","e_3","f_3"};
            for(int n=0;n<3;++n){levels[n]=percent(s,lev[n]);pans[n]=percent(s,panRows[n]);fb[n]=percent(s,feed[n])*percent(s,tempo?"i_1":"g_1");}
            // Normalize the head feedback mixture if its absolute sum would
            // exceed unity; the three levels/pans remain independent. This
            // own safety law also permits Saturation=0 without a divergent
            // linear loop when all three FB Amt controls are at maximum.
            const double sum=std::abs(fb[0])+std::abs(fb[1])+std::abs(fb[2]);
            if(sum>.9995)for(auto& amount:fb)amount*=.9995/sum;
            damp(tempo?"j_1":"h_1",tempo?"j_2":"h_2");drive=1+9*percent(s,tempo?"k_1":"i_1");
            trim=percent(s,tempo?"l_1":"j_1");tone.frequency(sr,300*std::pow(60.0,percent(s,tempo?"l_2":"j_2")));
            phaseStep=get(s,tempo?"m_1":"k_1")/sr;depthL=percent(s,tempo?"m_2":"k_2")*.003*sr;break;}
        case 179:
            fb[0]=feedback(get(s,"b_1"));drive=2.5;tone.frequency(sr,250*std::pow(64.0,get(s,"c_1")/99));
            damping[0].configure(sr,0,get(s,"d_1"));break;
        case 63:
            sequenceBeat=60*sr/get(s,"a_1");fb[0]=feedback(get(s,"d_1"));damp("e_1","e_2");
            sequencePan={percent(s,"c_1"),percent(s,"c_2"),percent(s,"c_3"),percent(s,"c_4")};break;
        case 62:
            mode=static_cast<int>(get(s,"a_1"));reverseLimit=std::min(reverseCapacity,static_cast<std::size_t>(std::ceil(sr*.001*get(s,"b_1"))));
            thresholdAmp=threshold(get(s,"d_1"));detectorFall=std::exp(-1/(sr*.001*(1+499*percent(s,"e_1"))));
            directMix=static_cast<int>(get(s,"f_1"));break;
        case 167:{
            const bool rec=get(s,"g_1")!=0, rst=get(s,"h_1")!=0;
            holdAuto=get(s,"a_1")==kNumberedFxChoiceBase && get(s,"b_1")==0;
            const double length=get(s,"b_1")?noteMs(s,"c_1","d_2"):get(s,"a_1");
            delay[0]=holdAuto?0:std::clamp(length*.001*sr,1.0,static_cast<double>(holdMaximum));
            if(rst)reset();
            if(holdGrowing&&holdRec&&!rec){holdLength=holdAutoFrames;holdPos=0;holdGrowing=false;}
            holdRec=rec;holdReset=rst;pans[0]=.5+.5*percent(s,"i_1");break;}
        default:active=false;break;
    }
    state=s;
}

void NumberedTimeFx::Impl::configureReverb(const NumberedFxState& s) noexcept {
    const bool room=index==74||index==75;
    const bool erOnly=index==76||index==170;
    spring=index==180;overb=index==194;
    for(auto& e:eq)e.identity();
    trim=1;preThru=0;preDelay=0;earlyLevel=0;reverbLevel=1;
    reverbMod=0;lines=8;diffusers=4;erCount=0;
    double seconds=1,hi=25,lo=0,mainDiffusion=.65,size=1,bassRatio=1;
    phaseStep=.37/sr;
    static constexpr std::array<double,12> hallMs{{31.1,37.9,41.3,47.7,53.1,59.3,67.1,73.7,83.9,91.3,103.1,113.9}};
    static constexpr std::array<double,12> smoothMs{{43.7,51.1,59.3,64.9,73.1,79.9,89.3,97.1,103.3,109.7,117.1,127.7}};
    static constexpr std::array<double,12> plateMs{{29.7,37.1,41.9,53.9,0,0,0,0,0,0,0,0}};
    static constexpr std::array<double,12> lightPlateMs{{19.1,23.9,31.3,43.1,0,0,0,0,0,0,0,0}};
    static constexpr std::array<double,12> roomMs{{11.3,17.9,23.3,29.9,37.1,41.9,0,0,0,0,0,0}};
    static constexpr std::array<double,12> brightMs{{7.9,13.7,19.1,23.3,31.1,37.9,0,0,0,0,0,0}};
    static constexpr std::array<double,12> springMs{{28.9,37.1,46.7,0,0,0,0,0,0,0,0,0}};
    static constexpr std::array<double,12> smallRoomMs{{8.3,13.1,19.7,29.3,0,0,0,0,0,0,0,0}};
    const std::array<double,12>* spacings=&hallMs;
    if(index>=70&&index<=75){
        seconds=get(s,"a_1");hi=get(s,"a_2");preDelay=get(s,"b_1")*sr*.001;preThru=percent(s,"b_2");
        trim=percent(s,room?"e_1":"c_1");
        // The restricted partial decoder leaves both cutoff choices unknown
        // and requires neutral gains. Complete decoded source states contain
        // the saved choices and gains, so their EQ must actually be applied.
        if(s.origin!=NumberedFxOrigin::Decoded||decodedSourceStateComplete(s)){
            const double lf=get(s,room?"f_1":"d_1")==0?100:400;
            const double hf=get(s,room?"f_2":"d_2")==0?8000:3000;
            eq[0].configure(Biquad::Type::LowShelf,sr,lf,.7071067811865476,get(s,room?"g_1":"e_1"));
            eq[1].configure(Biquad::Type::HighShelf,sr,hf,.7071067811865476,get(s,room?"g_2":"e_2"));
        }
        if(room){lines=6;diffusers=2;erCount=index==75?18:12;earlyLevel=percent(s,"c_1");reverbLevel=percent(s,"d_1");spacings=index==75?&brightMs:&roomMs;mainDiffusion=index==75?.55:.7;}
        else if(index==71){lines=12;diffusers=8;spacings=&smoothMs;mainDiffusion=.9;reverbMod=.00015*sr;}
        else if(index==72){lines=4;diffusers=6;spacings=&plateMs;mainDiffusion=.9;}
        else if(index==73){lines=4;diffusers=2;spacings=&lightPlateMs;mainDiffusion=.35;}
    }else if(erOnly){
        lines=diffusers=0;mode=static_cast<int>(get(s,"a_1"));erCount=index==170?48:16;
        preDelay=get(s,"c_1")*sr*.001;trim=percent(s,"d_1");
        eq[0].configure(Biquad::Type::LowShelf,sr,get(s,"e_1")==0?100:400,.7071067811865476,get(s,"f_1"));
        eq[1].configure(Biquad::Type::HighShelf,sr,get(s,"e_2")==0?8000:3000,.7071067811865476,get(s,"f_2"));
        earlyLevel=1;reverbLevel=0;
    }else if(spring||index==182){
        seconds=spring?.18*std::pow(35.0,(get(s,"a_1")-1)/99):.1*std::pow(28.0,(get(s,"a_1")-1)/99);
        hi=get(s,"a_3");lo=get(s,"a_2");preDelay=get(s,"a_4")*sr*.001;
        lines=spring?3:4;diffusers=spring?0:3;spacings=spring?&springMs:&smallRoomMs;
        mainDiffusion=spring?0:.55;erCount=spring?0:8;earlyLevel=spring?0:.35;
    }else if(overb){
        trim=percent(s,"a_1");preDelay=get(s,"e_1")*sr*.001;lines=12;diffusers=6;spacings=&smoothMs;
        if(get(s,"b_1")==0)eq[0].configure(Biquad::Type::Peak,sr,get(s,"b_2"),get(s,"b_3"),get(s,"b_4"));else eq[0].reset();
        if(get(s,"c_1")==0)eq[1].configure(Biquad::Type::Peak,sr,get(s,"c_2"),get(s,"c_3"),get(s,"c_4"));else eq[1].reset();
        // Own physical laws: size scales path lengths; decay is 0.15..15 s;
        // +6 dB Bass Gain doubles low-band decay, -12 dB quarters it.
        size=.12+.88*percent(s,"f_1");seconds=.15*std::pow(100.0,percent(s,"f_3"));
        mainDiffusion=percent(s,"f_2");hi=100-get(s,"g_1");bassRatio=std::pow(2.0,get(s,"g_3")/6);
        reverbMod=.0015*sr*percent(s,"h_2");phaseStep=get(s,"h_1")/sr;
        rollL.frequency(sr,20000*std::pow(.02,percent(s,"d_1")));rollR.coefficient=rollL.coefficient;
        // At Rolloff=0 the lowpass is bypassed, not an inaudible fake control.
        levels[2]=percent(s,"d_1");
    }
    const double angle=std::clamp(mainDiffusion,0.0,1.0)*pi*.25;
    mixCos=std::cos(angle);mixSin=std::sin(angle);
    for(int n=0;n<lines;++n){
        lineTime[n]=(*spacings)[n]*size*sr*.001;
        lineGain[n]=std::pow(10.0,-3*lineTime[n]/(sr*seconds));
        bassGain[n]=std::pow(10.0,-3*lineTime[n]/(sr*seconds*bassRatio));
        linePhase[n]=static_cast<double>(n)/std::max(1,lines);
        damping[n].configure(sr,hi,lo);
        bass[n].frequency(sr,overb?get(s,"g_2"):250);
    }
    static constexpr std::array<double,8> diffusionMs{{3.7,8.3,13.1,5.9,17.9,23.3,29.3,31.7}};
    for(int n=0;n<diffusers;++n){
        diffuserTime[n]=diffusionMs[n]*sr*.001;
        diffuserGain[n]=overb?.75*percent(s,n<3?"e_2":"e_3"):
            index==73?.35:index==72?.72:index==71?.7:.55;
    }
    if(erCount){
        const double erMs=erOnly?get(s,"b_1"):index==75?48:index==182?38:72;
        double normalL=0,normalR=0;
        for(int n=0;n<erCount;++n){
            const double f=(n+.35)/erCount;
            const double fractional=std::fmod((n+1)*.6180339887498949,1.0);
            // Deterministic irregular tap spacing; separate density and decay
            // curves implement Sharp/Loose/Modulated/Reverse, not aliases.
            const double position=n==0?0:n==erCount-1?1:std::clamp(f+(fractional-.5)*.5/erCount,.003,1.0);
            erDelay[n]=erMs*sr*.001*position;
            double weight=std::exp(-3.5*position);
            if(erOnly){
                // The four shapes follow the *amplitude-envelope* diagram
                // on manual p1571. "Modulated" is its U-shaped envelope,
                // not undocumented pitch/LFO modulation of the tap times.
                if(mode==0)weight=position<.96?1:std::max(0.0,(1-position)/.04);
                else if(mode==1)weight=std::sin(pi*.5*std::min(1.0,position/.2))*
                    std::cos(pi*.5*std::max(0.0,(position-.55)/.45));
                else if(mode==2)weight=.25+.375*(1+std::cos(2*pi*position));
                else weight=position*position*(3-2*position);
            }
            erL[n]=weight*std::sqrt(1-fractional);erR[n]=weight*std::sqrt(fractional);
            normalL+=erL[n];normalR+=erR[n];
        }
        for(int n=0;n<erCount;++n){erL[n]/=normalL;erR[n]/=normalR;}
    }
}

void NumberedTimeFx::Impl::processDelay(float inL,float inR,float& outL,float& outR) noexcept {
    const float mono=(inL+inR)*.5F;
    if(index==63){
        // Manual p1350 establishes one-beat feedback and equal tap spacing.
        // All four sixteenth taps are our explicit fixed pattern; no value is
        // fabricated for the unknown original Rhythm Pattern Reference row.
        const float returned=damping[0].process(ring[0].read(sequenceBeat));
        const float x=safe(static_cast<float>(mono+returned*fb[0]));
        outL=outR=0;
        for(int n=0;n<4;++n)pan(ring[0].read(sequenceBeat*(n+1)*.25)*.25F,sequencePan[n],outL,outR);
        ring[0].push(x);return;
    }
    if(index==55||index==165||index==64||index==168){
        const float center=damping[0].process(ring[0].read(delay[2]));
        const float x=safe(static_cast<float>(mono+center*fb[0]));
        const float l=delay[0]<1?x:ring[0].read(delay[0]);
        const float r=delay[1]<1?x:ring[0].read(delay[1]);
        const float c=delay[2]<1?x:ring[0].read(delay[2]);
        ring[0].push(x);
        outL=static_cast<float>(l*levels[0]+c*levels[2]*.7071067811865476);
        outR=static_cast<float>(r*levels[1]+c*levels[2]*.7071067811865476);
        spread(outL,outR,width);return;
    }
    if(index==61||index==69||index==179){
        if(index==179){
            // Classic model: tone belongs inside the loop before the tape
            // delay; Low Damp follows the head and feeds both output and FB.
            const float returned=damping[0].process(ring[0].read(delay[0]));
            const float written=saturate(tone.low(static_cast<float>(mono+returned*fb[0])),drive);
            ring[0].push(safe(written));outL=outR=returned;return;
        }
        std::array<float,3> taps{};double returned=0;
        const int count=3;
        // Shared tape-speed perturbation keeps the three playback heads
        // physically related. Classic Tape Echo has a single fixed head.
        const double flutter=depthL*(.8*std::sin(2*pi*phase)+.2*std::sin(2*pi*phase*7));
        for(int n=0;n<count;++n){taps[n]=ring[0].read(std::max(1.0,delay[n]+flutter));returned+=taps[n]*fb[n];}
        float x=tone.low(static_cast<float>(mono*trim));
        x=saturate(static_cast<float>(x+returned),drive);
        x=damping[0].process(x);ring[0].push(safe(x));
        outL=outR=0;
        for(int n=0;n<3;++n)pan(static_cast<float>((delay[n]<1?x:taps[n])*levels[n]),pans[n],outL,outR);
        phase+=phaseStep;if(phase>=1)phase-=std::floor(phase);return;
    }
    double dL=delay[0],dR=delay[1];
    if(modDelay(index)){
        dL=std::max(1.0,dL+depthL*wave(phase+levels[2],waveform,shape));
        dR=std::max(1.0,dR+depthR*wave(phase+phaseR,waveform,shape));
    }
    float yL=ring[0].read(dL),yR=ring[1].read(dR);
    double control=1;
    if(index==59){
        const double peak=std::max(std::abs(inL),std::abs(inR));
        detector=std::max(peak,detector*detectorFall);
        double target=detector>=thresholdAmp?1:0;if(negative)target=1-target;
        const double a=target>envelope?attack:release;
        envelope=target+a*(envelope-target);control=offset+(1-offset)*envelope;
    }
    const bool multitap=index==57||index==66;
    if(multitap){
        const float aL=ring[0].read(delay[0]),aR=ring[1].read(delay[0]);
        yL=ring[0].read(delay[1]);yR=ring[1].read(delay[1]);
        const bool crossed=mode==1||mode==3;
        // Unlike Stereo/Cross Delay, Multitap's manual diagram places the
        // two dampers before the taps, after the input/feedback junction.
        const float xL=safe(damping[0].process(static_cast<float>(inL+(crossed?yR:yL)*fb[0])));
        const float xR=safe(damping[1].process(static_cast<float>(inR+(crossed?yL:yR)*fb[1])));
        ring[0].push(xL);ring[1].push(xR);
        const float firstL=delay[0]<1?xL:aL,firstR=delay[0]<1?xR:aR;
        outL=static_cast<float>((delay[1]<1?xL:yL)+(mode>=2?firstR:firstL)*levels[0]);
        outR=static_cast<float>((delay[1]<1?xR:yR)+(mode>=2?firstL:firstR)*levels[0]);
        spread(outL,outR,width);return;
    }
    yL=damping[0].process(yL);yR=damping[1].process(yR);
    const bool crossed=(index==56||index==166)&&mode==1;
    const double gain= index==59&&dynamicTarget==2?control:1;
    const float xL=safe(static_cast<float>(inL+(crossed?yR:yL)*fb[0]*gain));
    const float xR=safe(static_cast<float>(inR+(crossed?yL:yR)*fb[1]*gain));
    ring[0].push(xL);ring[1].push(xR);
    if(dL<1)yL=xL;if(dR<1)yR=xR;
    if(crossed)std::swap(yL,yR);
    if(panDelay(index)){
        outL=outR=0;
        const double lfoL=wave(phase,waveform,shape),lfoR=wave(phase+phaseR,waveform,shape);
        // At depth0 retain original stereo position; depth100 sweeps each
        // delayed channel across both outputs, with the stated phase offset.
        pan(yL,panDepth*(.5+.5*lfoL),outL,outR);
        pan(yR,1-panDepth+panDepth*(.5+.5*lfoR),outL,outR);
    }else{outL=yL;outR=yR;spread(outL,outR,width);}
    if(index==59&&dynamicTarget==1){outL=static_cast<float>(outL*control);outR=static_cast<float>(outR*control);}
    if(modDelay(index)||panDelay(index)){phase+=phaseStep;if(phase>=1)phase-=std::floor(phase);}
}

void NumberedTimeFx::Impl::processReverb(float inL,float inR,float& outL,float& outR) noexcept {
    const float mono=eq[1].process(eq[0].process(static_cast<float>((inL+inR)*.5*trim)));
    ring[0].push(mono);
    const float pre=ring[0].read(preDelay+1);
    const bool erOnly=index==76||index==170;
    ring[1].push(erOnly?pre:mono);
    float earlyL=0,earlyR=0;
    for(int n=0;n<erCount;++n){
        const float t=ring[1].read(1+erDelay[n]);
        earlyL+=static_cast<float>(t*erL[n]);earlyR+=static_cast<float>(t*erR[n]);
    }
    if(erOnly){outL=earlyL;outR=earlyR;phase+=phaseStep;if(phase>=1)phase-=1;return;}
    // Manual diagram: Thru bypasses only the pre-delay, joining before the
    // reverb core. It is not an extra dry path around the reverberation.
    float input=static_cast<float>(pre+mono*preThru);
    for(int n=0;n<diffusers;++n)input=allpass(14+n,input,diffuserTime[n],diffuserGain[n]);
    std::array<float,12> returned{};
    float lateL=0,lateR=0;
    const double norm=1/std::sqrt(static_cast<double>(lines));
    for(int n=0;n<lines;++n){
        const double movement=reverbMod==0?0:reverbMod*std::sin(2*pi*(phase+linePhase[n]));
        float y=ring[2+n].read(std::max(1.0,lineTime[n]+movement));
        if(spring||index==72||index==73){
            // Dispersive spring paths (four sections) and plate loop
            // diffusers (two/one sections) are distinct from the hall FDN.
            const int stages=spring?4:index==72?2:1;
            for(int j=0;j<stages;++j){
                const double a=spring?.38+.075*j+.025*n:index==72?.42+.09*j:.22;
                const double v=springMemory[n][j]-a*y;
                springMemory[n][j]=y+a*v;y=static_cast<float>(v);
                if(std::abs(springMemory[n][j])<1.e-25)springMemory[n][j]=0;
            }
        }
        lateL+=static_cast<float>(y*norm*(n%2?-.5:1));
        lateR+=static_cast<float>(y*norm*(n%3?1:-.5));
        y=damping[n].process(y);
        const float low=bass[n].low(y);
        returned[n]=static_cast<float>(y*lineGain[n]+low*(bassGain[n]-lineGain[n]));
    }
    // A permutation and cascaded Givens rotations are energy-preserving for
    // every Diffusion setting. Decay is governed by the per-line gains, not an
    // unstable unnormalized summing matrix.
    std::rotate(returned.begin(),returned.begin()+1,returned.begin()+lines);
    if(!spring)for(int pass=0;pass<2;++pass){
        for(int n=pass;n+1<lines;n+=2){
            const float a=returned[n],b=returned[n+1];
            returned[n]=static_cast<float>(mixCos*a+mixSin*b);
            returned[n+1]=static_cast<float>(mixCos*b-mixSin*a);
        }
    }
    for(int n=0;n<lines;++n)ring[2+n].push(safe(static_cast<float>(input*norm+returned[n])));
    if(overb&&levels[2]>0){lateL=rollL.low(lateL);lateR=rollR.low(lateR);}
    outL=static_cast<float>(lateL*reverbLevel+earlyL*earlyLevel);
    outR=static_cast<float>(lateR*reverbLevel+earlyR*earlyLevel);
    phase+=phaseStep;if(phase>=1)phase-=std::floor(phase);
}

void NumberedTimeFx::Impl::processReverse(float mono,float& outL,float& outR) noexcept {
    detector=std::max(static_cast<double>(std::abs(mono)),detector*detectorFall);
    const bool open=detector>=thresholdAmp;
    if(open&&!above){
        if(mode==0){playBank=-1;reverseRead=0;}
        recordBank=playBank==0?1:0;reverseWritten=0;recording=true;
    }
    if(recording&&open&&reverseWritten<reverseLimit)reverseData[recordBank][reverseWritten++]=mono;
    if(!open&&above&&recording){
        playBank=reverseWritten?recordBank:-1;reverseRead=reverseWritten;recording=false;reverseGain=0;
    }
    above=open;
    const bool playing=playBank>=0&&reverseRead>0;
    float reversed=playing?reverseData[playBank][--reverseRead]:0;
    if(!reverseRead)playBank=-1;
    // Five-ms edge ramps are an own anti-click treatment. Single/Multi
    // recording priority and the documented duration limits remain distinct.
    const double step=1/(sr*.005);
    reverseGain=playing?std::min(1.0,reverseGain+step):std::max(0.0,reverseGain-step);
    const double endFade=playing?std::min(1.0,(reverseRead+1)/(sr*.005)):0;
    reversed=static_cast<float>(reversed*reverseGain*endFade);
    float result=reversed;
    if(directMix==0)result+=mono;
    else if(directMix==2)result+=static_cast<float>(mono*(1-reverseGain));
    outL=outR=result;
}

void NumberedTimeFx::Impl::processHold(float mono,float& outL,float& outR) noexcept {
    outL=outR=0;
    if(holdReset)return;
    if(!holdLength&&!holdGrowing&&holdRec){
        holdPos=holdValid=holdAutoFrames=0;
        if(holdAuto)holdGrowing=true;
        else holdLength=static_cast<std::size_t>(delay[0]);
    }
    if(holdGrowing){
        if(holdRec&&holdAutoFrames<holdMaximum){workspace[holdAutoFrames++]=mono;holdValid=holdAutoFrames;}
        if(holdAutoFrames>=holdMaximum||!holdRec){holdLength=holdAutoFrames;holdPos=0;holdGrowing=false;}
        return;
    }
    if(!holdLength)return;
    const float previous=holdPos<holdValid?workspace[holdPos]:0;
    // Complete the first fixed-length cycle with explicit zeros even when
    // REC is released early. Thus later overdubs never read stale workspace.
    if(holdRec)workspace[holdPos]=safe(previous+mono);
    else if(holdPos>=holdValid)workspace[holdPos]=0;
    if(holdPos==holdValid)++holdValid;
    pan(previous,pans[0],outL,outR);
    if(++holdPos>=holdLength)holdPos=0;
}

NumberedTimeFx::NumberedTimeFx()=default;
NumberedTimeFx::~NumberedTimeFx()=default;
NumberedTimeFx::NumberedTimeFx(NumberedTimeFx&&) noexcept=default;
NumberedTimeFx& NumberedTimeFx::operator=(NumberedTimeFx&&) noexcept=default;

void NumberedTimeFx::prepare(double sampleRate,float* workspace,std::size_t samples){
    if(!impl_)impl_=std::make_unique<Impl>();
    impl_->sr=boundedRate(sampleRate);impl_->workspace=workspace;impl_->samples=samples;
    impl_->wetCoefficient=std::exp(-1/(impl_->sr*.008));
    impl_->ready=workspace&&samples>=static_cast<std::size_t>(std::ceil(impl_->sr*11.3))+64;
    impl_->active=false;impl_->index=0;impl_->reset();
}
void NumberedTimeFx::reset() noexcept {if(impl_)impl_->reset();}
void NumberedTimeFx::configure(const NumberedFxState& state) noexcept {if(impl_)impl_->configure(state);}
void NumberedTimeFx::process(float inL,float inR,float& outL,float& outR) noexcept {
    inL=finite(inL);inR=finite(inR);
    if(!impl_||!impl_->active){outL=inL;outR=inR;return;}
    float l=0,r=0;
    if(isReverb(impl_->index))impl_->processReverb(inL,inR,l,r);
    else if(impl_->index==62)impl_->processReverse((inL+inR)*.5F,l,r);
    else if(impl_->index==167)impl_->processHold((inL+inR)*.5F,l,r);
    else impl_->processDelay(inL,inR,l,r);
    impl_->wetCurrent=impl_->wetAmount+impl_->wetCoefficient*(impl_->wetCurrent-impl_->wetAmount);
    outL=finite(mix(inL,finite(l),impl_->wetCurrent));
    outR=finite(mix(inR,finite(r),impl_->wetCurrent));
}

} // namespace silveton::sampler
