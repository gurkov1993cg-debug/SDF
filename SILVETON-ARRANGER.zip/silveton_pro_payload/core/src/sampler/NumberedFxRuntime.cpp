#include "silveton/sampler/NumberedFxRuntime.h"
#include "silveton/sampler/NumberedDynamics.h"
#include "silveton/sampler/NumberedCombinedFx.h"
#include "silveton/sampler/NumberedModFx.h"
#include "silveton/sampler/NumberedTimeFx.h"
#include "silveton/sampler/NumberedToneFx.h"
#include "silveton/sampler/NumberedFxKernel.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <vector>

namespace silveton::sampler {
namespace {

bool dynamicsIndex(std::uint16_t index) noexcept {
    return (index >= 1 && index <= 5) || index == 154 || index == 171;
}

enum class Family { Dynamics, Combined, Time, Mod, Tone };
Family familyFor(std::uint16_t index) noexcept {
    if (dynamicsIndex(index)) return Family::Dynamics;
    if ((index >= 77 && index <= 108) || index == 209) return Family::Combined;
    if ((index >= 55 && index <= 76) || (index >= 165 && index <= 170) ||
        index == 179 || index == 180 || index == 182 || index == 194) return Family::Time;
    if ((index >= 26 && index <= 54 && index != 40) || (index >= 161 && index <= 164) ||
        (index >= 173 && index <= 178) || index == 189 || index == 207) return Family::Mod;
    return Family::Tone;
}

std::uint64_t allRows(const NumberedFxDescriptor& d) noexcept {
    return d.parameterCount == 64 ? ~std::uint64_t{0} :
        (std::uint64_t{1} << d.parameterCount) - 1;
}

bool isModulation(const NumberedFxParamDescriptor& p) noexcept {
    return p.role != NumberedFxParamRole::Parameter;
}

double value(const NumberedFxState& s, const char* row, double fallback = 0) noexcept {
    const auto* p = findNumberedFxParam(s.index, row);
    return p && s.known(p->ordinal) ? s.values[p->ordinal] : fallback;
}

bool setInitial(NumberedFxState& state, const char* row, double v) noexcept {
    const auto* p = findNumberedFxParam(state.index, row);
    if (!p || !numberedFxValueValid(*p, v)) return false;
    state.values[p->ordinal] = v;
    state.knownMask |= std::uint64_t{1} << p->ordinal;
    return true;
}

const char* wetRow(std::uint16_t index) noexcept {
    if (index == 1 || index == 2 || index == 5) return "h_1";
    if (index == 3 || index == 154) return "i_1";
    return "d_1";
}

// Scalar output-gain controls are intentionally separate from the dynamics
// detector and its intrinsic compression law. -Inf is a finite, labelled
// semantic choice, not a stored IEEE infinity and not a Korg enum value.
float outputGain(const NumberedFxState& s) noexcept {
    // Trigger Monitor is taken from the Side PEQ before the limiter's output
    // gain, as in the documented signal diagram. It must remain audible even
    // when Gain Adjust is -Inf.
    if (s.index == 2 && value(s, "f_2") != 0) return 1;
    if (s.index == 1) return static_cast<float>(value(s, "g_1", 100) * .01);
    if (s.index == 171) return static_cast<float>(value(s, "c_1", 100) * .01);
    if (s.index == 2 || s.index == 3 || s.index == 154) {
        const double gain = value(s, s.index == 2 ? "e_1" : "h_1");
        if (gain <= kNumberedFxChoiceBase) return 0;
        return static_cast<float>(std::pow(10.0, gain / 20.0));
    }
    return 1;
}

} // namespace

NumberedFxSupport numberedFxSupport(std::uint16_t index) noexcept {
    if (index == 0) return {true, 0, "Bypass"};
    switch (familyFor(index)) {
        case Family::Combined: return numberedCombinedFxSupport(index);
        case Family::Time: return numberedTimeFxSupport(index);
        case Family::Mod: return numberedModFxSupport(index);
        case Family::Tone: return numberedToneFxSupport(index);
        case Family::Dynamics: break;
    }
    const auto* d = findNumberedFx(index);
    if (!d || d->completeness != NumberedFxCompleteness::Table) return {};
    std::uint64_t editable = 0;
    for (std::size_t i = 0; i < d->parameterCount; ++i) {
        const auto& p = d->parameters[i];
        if (!isModulation(p) && p.domainComplete && p.kind != NumberedFxValueKind::Reference)
            editable |= std::uint64_t{1} << p.ordinal;
    }
    // The envelope's external DMS source is deliberately not connected to a
    // guessed MIDI track. The input detector is the sole current gate source.
    if (index == 5) {
        const auto* source = findNumberedFxParam(index, "a_1");
        if (source) editable &= ~(std::uint64_t{1} << source->ordinal);
    }
    return {true, editable,
        "Собствен SILVETON алгоритъм за основните настройки. DMS е изключен; "
        "оригиналният SET decode и звуковото съвпадение с Pa5X не са потвърдени."};
}

bool initializeNumberedFx(std::uint16_t index, NumberedFxState& state) noexcept {
    if (index == 0) { state = {}; return true; }
    switch (familyFor(index)) {
        case Family::Combined: return initializeNumberedCombinedFx(index, state);
        case Family::Time: return initializeNumberedTimeFx(index, state);
        case Family::Mod: return initializeNumberedModFx(index, state);
        case Family::Tone: return initializeNumberedToneFx(index, state);
        case Family::Dynamics: break;
    }
    if (!numberedFxSupport(index).selectable) return false;
    const auto* descriptor = findNumberedFx(index);
    if (!descriptor) return false;
    NumberedFxState next;
    next.index = index;
    next.origin = NumberedFxOrigin::Initial;
    bool ok = true;
    const auto set = [&](const char* row, double v) { ok = setInitial(next, row, v) && ok; };
    // Explicit author-selected starting settings. These are never used to fill
    // unknown original fields and are never described as Korg factory presets.
    for (std::size_t i = 0; i < descriptor->parameterCount; ++i) {
        const auto& p = descriptor->parameters[i];
        if (isModulation(p)) set(p.rowId, 0);
    }
    switch (index) {
        case 1:
            set("a_1", 0); set("b_1", 35); set("c_1", 20); set("d_1", 100);
            set("e_1", 0); set("e_2", 0); set("f_1", 0); set("f_2", 0); set("g_1", 100);
            break;
        case 2:
            set("a_1", 0); set("b_1", 4); set("c_1", -12);
            set("v_1", 10); set("v_2", 40); set("e_1", 0);
            set("f_1", 0); set("f_2", 0); set("g_1", 1000); set("g_2", 1); set("g_3", 0);
            break;
        case 3: case 154:
            set("a_1", 4); set("b_1", -12); set("c_1", 10); set("d_1", 40);
            set("e_1", 0); set("f_1", 0); set("g_1", 0); set("h_1", 0);
            break;
        case 4:
            set("a_1", -6); set("b_1", -.5); set("c_1", 100);
            break;
        case 5:
            set("a_1", 1); set("b_1", 0); set("c_1", 10); set("c_2", 0);
            set("d_1", 1); set("d_2", 25); set("e_1", 0);
            set("f_1", 0); set("f_2", 0); set("g_1", 1000); set("g_2", 1); set("g_3", 0);
            break;
        case 171:
            set("a_1", 35); set("b_1", 20); set("c_1", 100);
            break;
        default: return false;
    }
    set(wetRow(index), 100);
    if (!ok || !numberedFxCanRender(next)) return false;
    state = next;
    return true;
}

bool numberedFxCanRender(const NumberedFxState& s) noexcept {
    if (s.index == 0) return false;
    switch (familyFor(s.index)) {
        case Family::Combined: return numberedCombinedFxCanRender(s);
        case Family::Time: return numberedTimeFxCanRender(s);
        case Family::Mod: return numberedModFxCanRender(s);
        case Family::Tone: return numberedToneFxCanRender(s);
        case Family::Dynamics: break;
    }
    if (s.origin == NumberedFxOrigin::Decoded) {
        if (!numbered_fx::decodedSourceStateComplete(s)) return false;
    } else if (s.origin != NumberedFxOrigin::Initial && s.origin != NumberedFxOrigin::Manual) return false;
    const auto* d = findNumberedFx(s.index);
    if (!d || !s.valid() || s.knownMask != allRows(*d)) return false;
    for (std::size_t i = 0; i < d->parameterCount; ++i) {
        const auto& p = d->parameters[i];
        if (isModulation(p) && s.values[p.ordinal] != 0 &&
            !numbered_fx::decodedModulationInactive(s, p)) return false;
    }
    return s.index != 5 || value(s, "a_1") == 1;
}

bool setNumberedFxValue(NumberedFxState& state, std::size_t row, double v) noexcept {
    const auto* d = findNumberedFx(state.index);
    if (!d || row >= d->parameterCount || !numberedFxCanRender(state)) return false;
    const auto support = numberedFxSupport(state.index);
    const auto& p = d->parameters[row];
    if ((support.editableMask & (std::uint64_t{1} << p.ordinal)) == 0 || !numberedFxValueValid(p, v)) return false;
    NumberedFxState next = state;
    next.values[p.ordinal] = v;
    next.knownMask |= std::uint64_t{1} << p.ordinal;
    next.origin = NumberedFxOrigin::Manual;
    if (!numberedFxCanRender(next)) return false;
    state = next;
    return true;
}

int numberedFxPrimaryWetRow(std::uint16_t index) noexcept {
    const auto* d = findNumberedFx(index);
    if (!d) return -1;
    if (index == 207) {
        const auto* p = findNumberedFxParam(index, "d_1");
        if (p) return p->ordinal;
    }
    for (std::size_t i = d->parameterCount; i > 0; --i) {
        const auto& p = d->parameters[i - 1];
        if (p.kind == NumberedFxValueKind::WetDry || p.kind == NumberedFxValueKind::BipolarWetDry)
            return static_cast<int>(i - 1);
    }
    return -1;
}

float numberedFxWet(const NumberedFxState& s) noexcept {
    if (!dynamicsIndex(s.index)) {
        const int row = numberedFxPrimaryWetRow(s.index);
        return row >= 0 && s.known(static_cast<std::size_t>(row)) ? static_cast<float>(s.values[static_cast<std::size_t>(row)] * .01) : 1;
    }
    return static_cast<float>(std::clamp(value(s, wetRow(s.index), 100), 0.0, 100.0) * .01);
}

bool sameNumberedFx(const NumberedFxState& a, const NumberedFxState& b) noexcept {
    if (a.schema != b.schema || a.index != b.index || a.origin != b.origin || a.knownMask != b.knownMask) return false;
    // Native-only slots have a zero mask and return immediately. Do not scan
    // 64 absent values for every unchanged native lane at every audio block.
    auto mask = a.knownMask;
    for (std::size_t i = 0; mask != 0; ++i, mask >>= 1U)
        if ((mask & 1U) != 0 && a.values[i] != b.values[i]) return false;
    return true;
}

struct NumberedFxProcessor::Impl {
    // All families borrow this one full-rate slot arena. They are mutually
    // exclusive; resetting every family on an index switch invalidates old
    // views before any new processor can read the shared memory.
    std::vector<float> workspace;
    NumberedDynamics dynamics;
    NumberedCombinedFx combined;
    NumberedModFx mod;
    NumberedTimeFx time;
    NumberedToneFx tone;
    Family family{Family::Dynamics};
    NumberedFxState state;
    bool cached{false}, enabled{false};
    float wet{1}, targetWet{1}, gain{1}, targetGain{1};
    float smoothing{1};
    void resetKernels() noexcept {
        dynamics.reset(); combined.reset(); mod.reset(); time.reset(); tone.reset();
    }
};

NumberedFxProcessor::NumberedFxProcessor() = default;
NumberedFxProcessor::~NumberedFxProcessor() = default;
NumberedFxProcessor::NumberedFxProcessor(NumberedFxProcessor&&) noexcept = default;
NumberedFxProcessor& NumberedFxProcessor::operator=(NumberedFxProcessor&&) noexcept = default;

void NumberedFxProcessor::prepare(double sr) {
    if (!impl_) impl_ = std::make_unique<Impl>();
    const double rate = std::isfinite(sr) && sr > 0 ? sr : 48000.0;
    impl_->workspace.assign(static_cast<std::size_t>(std::ceil(rate * 11.3)) + 64, 0);
    auto* data = impl_->workspace.data();
    const auto count = impl_->workspace.size();
    impl_->dynamics.prepare(rate);
    impl_->combined.prepare(rate, data, count);
    impl_->mod.prepare(rate, data, count);
    impl_->time.prepare(rate, data, count);
    impl_->tone.prepare(rate, data, count);
    impl_->smoothing = static_cast<float>(1.0 - std::exp(-1.0 / (.008 * rate)));
    reset();
}

void NumberedFxProcessor::reset() noexcept {
    if (!impl_) return;
    impl_->resetKernels();
    impl_->cached = impl_->enabled = false;
    impl_->state = {};
    impl_->wet = impl_->targetWet = impl_->gain = impl_->targetGain = 1;
}

void NumberedFxProcessor::configure(const NumberedFxState& state) noexcept {
    if (!impl_ || (impl_->cached && sameNumberedFx(impl_->state, state))) return;
    const bool changedAlgorithm = !impl_->cached || impl_->state.index != state.index;
    const bool wasEnabled = impl_->enabled;
    impl_->cached = true;
    impl_->state = state;
    impl_->enabled = numberedFxCanRender(state);
    if (!impl_->enabled) {
        if (changedAlgorithm || wasEnabled) impl_->resetKernels();
        return;
    }
    if (changedAlgorithm || !wasEnabled) impl_->resetKernels();
    impl_->family = familyFor(state.index);
    switch (impl_->family) {
        case Family::Combined: impl_->combined.configure(state); return;
        case Family::Time: impl_->time.configure(state); return;
        case Family::Mod: impl_->mod.configure(state); return;
        case Family::Tone: impl_->tone.configure(state); return;
        case Family::Dynamics: break;
    }
    NumberedDynamics::Config config;
    config.index = state.index;
    const auto scalar = [&](const char* row, double fallback = 0) {
        return static_cast<float>(value(state, row, fallback));
    };
    const auto ratio = [&](const char* row) {
        const double r = value(state, row, 4);
        config.infiniteRatio = r <= kNumberedFxChoiceBase;
        config.ratio = config.infiniteRatio ? 50.0F : static_cast<float>(r);
    };
    const auto detector = [&](const char* row) {
        switch (static_cast<int>(value(state, row))) {
            case 1: return NumberedDynamics::Detector::Left;
            case 2: return NumberedDynamics::Detector::Right;
            case 3: return NumberedDynamics::Detector::Independent;
            default: return NumberedDynamics::Detector::Mix;
        }
    };
    const auto sidechain = [&] {
        config.sideEqEnabled = value(state, "f_1") != 0;
        config.triggerMonitor = value(state, "f_2") != 0;
        config.sideEqHz = scalar("g_1", 1000);
        config.sideEqQ = scalar("g_2", 1);
        config.sideEqGainDb = scalar("g_3");
    };
    switch (state.index) {
        case 1:
            config.detector = value(state, "a_1") == 1 ? NumberedDynamics::Detector::Independent : NumberedDynamics::Detector::Mix;
            config.sensitivity = scalar("b_1"); config.attack = scalar("c_1");
            config.eqTrim = scalar("d_1") * .01F;
            config.lowShelf = value(state, "e_1") == 1 ? NumberedDynamics::LowShelf::MidLow : NumberedDynamics::LowShelf::Low;
            config.highShelf = value(state, "e_2") == 1 ? NumberedDynamics::HighShelf::MidHigh : NumberedDynamics::HighShelf::High;
            config.lowShelfGainDb = scalar("f_1"); config.highShelfGainDb = scalar("f_2");
            break;
        case 2:
            config.detector = detector("a_1"); ratio("b_1");
            config.thresholdDb = scalar("c_1"); config.attack = scalar("v_1"); config.release = scalar("v_2");
            sidechain();
            break;
        case 3: case 154:
            ratio("a_1"); config.thresholdDb = scalar("b_1");
            config.attack = scalar("c_1"); config.release = scalar("d_1");
            config.bandOffsetDb = {{scalar("e_1"), scalar("f_1"), scalar("g_1")}};
            break;
        case 4:
            config.thresholdDb = scalar("a_1"); config.ceilingDb = scalar("b_1"); config.masteringReleaseMs = scalar("c_1");
            break;
        case 5:
            config.detector = detector("b_1");
            config.gateDmod = false; // External DMS ownership is not guessed.
            config.gateThreshold = scalar("c_1"); config.gateNegativePolarity = value(state, "c_2") == 1;
            config.attack = scalar("d_1"); config.release = scalar("d_2"); config.gateDelayMs = scalar("e_1");
            sidechain();
            break;
        case 171:
            config.sensitivity = scalar("a_1"); config.attack = scalar("b_1");
            break;
        default: impl_->enabled = false; return;
    }
    impl_->dynamics.configure(config);
    impl_->targetWet = numberedFxWet(state);
    impl_->targetGain = outputGain(state);
    if (changedAlgorithm || !wasEnabled) {
        impl_->wet = impl_->targetWet;
        impl_->gain = impl_->targetGain;
    }
}

bool NumberedFxProcessor::active() const noexcept { return impl_ && impl_->enabled; }

void NumberedFxProcessor::setControlFrame(const NumberedFxControlFrame& frame) noexcept {
    if (!impl_ || !impl_->enabled || impl_->family != Family::Mod) return;
    impl_->mod.setControlFrame(frame);
}

void NumberedFxProcessor::process(float inL, float inR, float& outL, float& outR) noexcept {
    if (!active()) { outL = inL; outR = inR; return; }
    if (!std::isfinite(inL)) inL = 0;
    if (!std::isfinite(inR)) inR = 0;
    if (impl_->family != Family::Dynamics) {
        switch (impl_->family) {
            case Family::Combined: impl_->combined.process(inL, inR, outL, outR); break;
            case Family::Time: impl_->time.process(inL, inR, outL, outR); break;
            case Family::Mod: impl_->mod.process(inL, inR, outL, outR); break;
            case Family::Tone: impl_->tone.process(inL, inR, outL, outR); break;
            case Family::Dynamics: break;
        }
        if (!std::isfinite(outL) || !std::isfinite(outR)) {
            outL = outR = 0;
            impl_->resetKernels();
            impl_->enabled = impl_->cached = false;
        }
        return;
    }
    float left = 0, right = 0;
    impl_->dynamics.process(inL, inR, left, right);
    impl_->wet += (impl_->targetWet - impl_->wet) * impl_->smoothing;
    impl_->gain += (impl_->targetGain - impl_->gain) * impl_->smoothing;
    outL = inL + (left * impl_->gain - inL) * impl_->wet;
    outR = inR + (right * impl_->gain - inR) * impl_->wet;
    if (!std::isfinite(outL) || !std::isfinite(outR)) {
        outL = outR = 0;
        impl_->resetKernels();
        impl_->enabled = impl_->cached = false;
    }
}

} // namespace silveton::sampler
