#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include <algorithm>
#include <set>
#include <tuple>

namespace silveton::arranger {
namespace {
bool midiValue(int value) { return value>=0&&value<=127; }
void issue(Pa5xKeyboardSetPartRead& part,const std::string& message) { part.issues.push_back(message); }
// Read only absolute, explicit RPN tuning declarations from a validated
// single-channel, note-free recall setup. No controller messages are replayed.
// MIDI Association Table 3a defines RPN0/1/2; Pa5X User Manual MIDI chart *3
// declares the same selectors. NRPN values are deliberately a different family.
struct RpnRecallReader {
    enum class Family {None,Rpn,Nrpn};
    Family family{Family::None};
    int msb{-1},lsb{-1},dataMsb{-1};
    std::array<std::string,3> unresolved{};
    bool incompleteSelection{false};
    Pa5xKeyboardSetPartRead& part;

    explicit RpnRecallReader(Pa5xKeyboardSetPartRead& destination):part(destination){}
    int& value(int parameter){
        if(parameter==0)return part.pitchBendRangeSemitones;
        if(parameter==1)return part.fineTuneRaw;
        return part.coarseTuneRaw;
    }
    int selected() const {return family==Family::Rpn&&msb==0&&lsb>=0&&lsb<=2?lsb:-1;}
    void unknown(int parameter,const char* reason){value(parameter)=-1;unresolved[static_cast<std::size_t>(parameter)]=reason;}
    void known(int parameter,int raw){value(parameter)=raw;unresolved[static_cast<std::size_t>(parameter)].clear();}
    void controller(int control,int raw){
        if(control==101||control==100||control==99||control==98){
            const auto next=(control==101||control==100)?Family::Rpn:Family::Nrpn;
            if(family!=next){msb=-1;lsb=-1;}
            family=next;
            if(control==101||control==99)msb=raw;else lsb=raw;
            // Each selection starts fresh data provenance, even if its number
            // is unchanged. A previous parameter's CC38 cannot supply cents.
            dataMsb=-1;
            return;
        }
        if(control==121){
            // RP-015 preserves registered parameter values, but cancels their
            // selection. Do not manufacture a default bend range or tuning.
            family=Family::None;msb=-1;lsb=-1;dataMsb=-1;return;
        }
        if(control!=6&&control!=38&&control!=96&&control!=97)return;
        if(family!=Family::Rpn||(msb==127&&lsb==127))return;
        if(msb<0||lsb<0){incompleteSelection=true;return;}
        const int parameter=selected();if(parameter<0)return;
        if(control==96||control==97){
            dataMsb=-1;
            unknown(parameter,"relative Data Increment/Decrement requires a new complete absolute declaration");
            return;
        }
        if(control==6){
            dataMsb=raw;
            if(parameter==2)known(parameter,raw); // RPN2 uses only Data Entry MSB.
            else unknown(parameter,"Data Entry MSB was not followed by an explicit LSB for this selection");
            return;
        }
        if(parameter==2)return; // The RPN2 LSB has no defined tuning contribution.
        if(dataMsb<0){unknown(parameter,"Data Entry LSB has no preceding explicit MSB for this selection");return;}
        if(parameter==0){
            if(dataMsb<=12&&raw==0)known(parameter,dataMsb);
            else unknown(parameter,"only an explicit integer bend range 0..12 with zero cents is supported");
        }else known(parameter,(dataMsb<<7)|raw);
    }
    void finish(){
        static constexpr const char* names[]{"pitch-bend range","channel fine tuning","channel coarse tuning"};
        for(std::size_t i=0;i<unresolved.size();++i)if(!unresolved[i].empty())
            issue(part,std::string("Original RPN ")+names[i]+" remains unknown: "+unresolved[i]);
        if(incompleteSelection)issue(part,"Original RPN Data Entry has an incomplete parameter selection; no target or value was guessed");
    }
};
void resolve(Pa5xKeyboardSetPartRead& part,const Pa5xSetBank* bank) {
    static const Pa5xSetBank emptyBank;
    const auto selected=(bank!=nullptr?*bank:emptyBank).resolveSoundAddress(part.msb,part.lsb,part.program);
    part.soundName=selected.name;part.soundPath=selected.path;part.soundMessage=selected.message;
    switch(selected.resolution) {
        case KstResolution::ExactUserSound:part.status=Pa5xKeyboardSetSoundStatus::ExactUserSound;break;
        case KstResolution::FactorySoundRequired:part.status=Pa5xKeyboardSetSoundStatus::FactorySoundRequired;break;
        case KstResolution::MissingUserSound:part.status=Pa5xKeyboardSetSoundStatus::MissingUserSound;break;
        case KstResolution::AmbiguousSound:part.status=Pa5xKeyboardSetSoundStatus::AmbiguousSound;break;
        default:
            if(!selected.addressComplete)part.status=Pa5xKeyboardSetSoundStatus::IncompleteAddress;
            else {
                const auto state=(bank!=nullptr?*bank:emptyBank).status();
                part.status=state.recognized&&!state.cancelled&&state.soundDirectoryComplete?
                    Pa5xKeyboardSetSoundStatus::UnsupportedSoundAddress:Pa5xKeyboardSetSoundStatus::BankUnavailable;
            }
            break;
    }
    if(part.sourceNativeTrack&&part.status==Pa5xKeyboardSetSoundStatus::FactorySoundRequired){
        // A shared PRF/STS record revision does not identify the source Pa
        // model. Its factory address must not acquire a Pa5X-only Sound name.
        part.soundName.clear();
        part.soundMessage="Original factory MIDI address retained; the source Pa model and its factory Sound name are unavailable";
    }
}
void readPart(const Pa5xPerformancePart& source,Pa5xKeyboardSetPartRead& part,const Pa5xSetBank* bank) {
    part.present=source.present;part.resourcePath=source.resourcePath;
    part.mute=source.mute;part.keyLow=source.keyLow;part.keyHigh=source.keyHigh;
    part.velocityLow=source.velocityLow;part.velocityHigh=source.velocityHigh;
    part.partTranspositionDeclared=source.transpositionDeclared;part.partTranspositionRaw=source.transpositionRaw;
    part.opaqueMidiEvents=source.opaqueMidiEvents;
    part.sourceEffects=source.sourceEffects;
    part.sourceNativeTrack=source.sourceNativeTrack;
    if(source.sourceNativeTrack) {
        const auto& native=*source.sourceNativeTrack;
        if(!native.structurallyValid||native.trackIndex+1U!=static_cast<unsigned>(source.track)) {
            part.status=Pa5xKeyboardSetSoundStatus::InvalidSetup;
            issue(part,"The original native Pa mixer-part record is invalid or has a conflicting part role");return;
        }
        part.pitchBendRangeSemitones=native.pitchBendRangeSemitones;
        std::copy(native.masterFxSendRaw.begin(),native.masterFxSendRaw.end(),part.masterFxSendRaw.begin());
    }
    if(!source.present) { part.status=Pa5xKeyboardSetSoundStatus::InvalidSetup;issue(part,"The declared part MIDI resource is absent");return; }
    if(source.mute<-1||source.mute>1||source.keyLow<-1||source.keyHigh<-1||source.velocityLow<-1||source.velocityHigh<-1||
       source.keyLow>127||source.keyHigh>127||source.velocityLow>127||source.velocityHigh>127||
       (source.keyLow>=0&&source.keyHigh>=0&&source.keyLow>source.keyHigh)||
       (source.velocityLow>=0&&source.velocityHigh>=0&&source.velocityLow>source.velocityHigh)) {
        part.status=Pa5xKeyboardSetSoundStatus::InvalidSetup;issue(part,"The part's mute/key/velocity settings are invalid");return;
    }
    auto events=source.channelEvents;
    std::stable_sort(events.begin(),events.end(),[](const auto& a,const auto& b){return a.tick<b.tick||(a.tick==b.tick&&a.order<b.order);});
    std::set<int> channels;
    bool notes=source.hasNoteEvents,invalidEvent=false;
    for(const auto& event:events) {
        const unsigned type=event.status&0xF0U;
        if(type<0x80U||type>0xE0U||event.data1>127||event.data2>127)invalidEvent=true;
        channels.insert(event.status&15U);
        if(type==0x80U||type==0x90U)notes=true;
        part.setupLastTick=std::max(part.setupLastTick,event.tick);
    }
    if(notes||invalidEvent||channels.size()>1) {
        part.status=Pa5xKeyboardSetSoundStatus::InvalidSetup;
        if(notes)issue(part,"The part contains note events; a note-free recall setup is required");
        if(invalidEvent)issue(part,"The setup contains an invalid MIDI channel event");
        if(channels.size()>1)issue(part,"The part setup uses multiple MIDI channels; no channel is guessed");
        return;
    }
    if(channels.empty()) {
        part.recallSetupValid=true;part.status=Pa5xKeyboardSetSoundStatus::IncompleteAddress;
        issue(part,"The part has no explicit MIDI channel or Sound selection");return;
    }
    part.channel=*channels.begin();
    int pendingMsb=-1,pendingLsb=-1;
    RpnRecallReader tuning(part);
    sampler::SourceSoundEditReader soundEdits;
    std::set<std::tuple<int,int,int>> selections;
    for(const auto& event:events) {
        const auto type=event.status&0xF0U;
        if(type==0xB0U) {
            tuning.controller(event.data1,event.data2);
            (void)soundEdits.controller(part.sourceSoundEdits,event.data1,event.data2);
            if(event.data1==0)pendingMsb=event.data2;
            else if(event.data1==32)pendingLsb=event.data2;
            else if(event.data1==7)part.volumeRaw=event.data2;
            else if(event.data1==10)part.panRaw=event.data2;
            else if(event.data1==11)part.expressionRaw=event.data2;
            else if(event.data1==91)part.masterFxSendRaw[0]=event.data2;
            else if(event.data1==93)part.masterFxSendRaw[1]=event.data2;
            else if(event.data1==94)part.masterFxSendRaw[2]=event.data2;
            else if(event.data1==121)part.expressionRaw=-1; // reset value is not an explicit CC11 declaration
        } else if(type==0xC0U) {
            // Bank Select only commits with Program Change; a later CC0/32
            // cannot retroactively change the original selected Sound.
            part.msb=pendingMsb;part.lsb=pendingLsb;part.program=event.data1;
            selections.emplace(part.msb,part.lsb,part.program);
        }
    }
    tuning.finish();
    if(soundEdits.incompleteSelection)
        issue(part,"Original Sound Edit NRPN has an incomplete parameter selection; no offset was guessed");
    if(soundEdits.relativeValueUnknown)
        issue(part,"Original Sound Edit used relative Data Increment/Decrement; only later absolute values can be restored");
    if(selections.size()>1) {
        part.status=Pa5xKeyboardSetSoundStatus::InvalidSetup;
        issue(part,"Multiple different committed Sound selections require an unverified recall sequencing rule");return;
    }
    part.recallSetupValid=true;
    part.addressKnown=midiValue(part.msb)&&midiValue(part.lsb)&&midiValue(part.program);
    if(!part.addressKnown) {
        part.status=Pa5xKeyboardSetSoundStatus::IncompleteAddress;
        issue(part,"CC0, CC32 and Program Change must all be explicitly supplied before selection");return;
    }
    resolve(part,bank);
}
}
const char* pa5xKeyboardSetSoundStatusName(Pa5xKeyboardSetSoundStatus status) noexcept {
    switch(status) {
        case Pa5xKeyboardSetSoundStatus::ExactUserSound:return "Exact User Sound";
        case Pa5xKeyboardSetSoundStatus::FactorySoundRequired:return "Factory Sound";
        case Pa5xKeyboardSetSoundStatus::MissingUserSound:return "Missing User Sound";
        case Pa5xKeyboardSetSoundStatus::AmbiguousSound:return "Ambiguous Sound address";
        case Pa5xKeyboardSetSoundStatus::IncompleteAddress:return "Incomplete Sound address";
        case Pa5xKeyboardSetSoundStatus::InvalidSetup:return "Conflicting or invalid recall setup";
        case Pa5xKeyboardSetSoundStatus::BankUnavailable:return "Sound catalogue unavailable";
        case Pa5xKeyboardSetSoundStatus::UnsupportedSoundAddress:return "Unsupported original Sound address";
        default:return "Sound not read";
    }
}
Pa5xKeyboardSetRead readPa5xKeyboardSet(const Pa5xPerformanceInspection& inspection,const Pa5xSetBank* bank) {
    Pa5xKeyboardSetRead out;out.recognized=inspection.recognized;out.sourcePath=inspection.sourcePath;out.name=inspection.displayName;
    static const char* names[]{"Lower","Upper1","Upper2","Upper3"};
    for(std::size_t i=0;i<out.parts.size();++i){out.parts[i].role=static_cast<int>(i+1);out.parts[i].name=names[i];}
    if(!inspection.valid||inspection.kind!=Pa5xPerformanceKind::KeyboardSet) {out.error=inspection.error.empty()?"The resource is not a validated Keyboard Set":inspection.error;return out;}
    if(inspection.parts.size()!=4){out.error="A Keyboard Set must have exactly four declared part roles";return out;}
    out.splitPoint=inspection.splitPoint;out.useGlobalSplit=inspection.useGlobalSplit;out.lowerUseRaw=inspection.lowerUseRaw;
    out.bassInversionRaw=inspection.bassInversionRaw;
    out.complement=inspection.complement;
    out.sourceEffects=inspection.sourceEffects;
    out.upperOctaveTransposeKnown=inspection.upperOctaveDeclared;out.upperOctaveTranspose=inspection.upperOctaveTransposeRaw;
    out.valid=true;out.readComplete=true;std::array<bool,4> seen{};
    for(const auto& source:inspection.parts) {
        if(source.track<1||source.track>4||seen[static_cast<std::size_t>(source.track-1)]) {out.valid=false;out.readComplete=false;out.error="Invalid or duplicate Keyboard Set part role";return out;}
        const auto index=static_cast<std::size_t>(source.track-1);seen[index]=true;auto& part=out.parts[index];
        // The saved Upper octave is explicitly Upper-only (User Manual111).
        part.octaveTransposeKnown=index==0||out.upperOctaveTransposeKnown;part.octaveTranspose=index==0?0:out.upperOctaveTranspose;
        readPart(source,part,bank);
        if(!part.recallSetupValid||!part.addressKnown||part.soundName.empty()||
           (part.status!=Pa5xKeyboardSetSoundStatus::ExactUserSound&&part.status!=Pa5xKeyboardSetSoundStatus::FactorySoundRequired))out.readComplete=false;
        for(const auto& message:part.issues)out.issues.push_back(part.name+": "+message);
    }
    for(const auto& warning:inspection.warnings)out.issues.push_back(warning);
    return out;
}
Pa5xKeyboardSetRead readPa5xKeyboardSet(const std::string& path,const Pa5xSetBank* bank) {
    if(paKeyboardLocation(path)){
        return readPa5xKeyboardSet(readPaKeyboardLocation(path),bank);
    }
    return readPa5xKeyboardSet(inspectPa5xPerformanceFile(path),bank);
}
Pa5xKeyboardSetRead readPa5xKeyboardSetBytes(const std::vector<std::uint8_t>& bytes,const std::string& path,const Pa5xSetBank* bank) {
    return readPa5xKeyboardSet(inspectPa5xPerformanceBytes(bytes,path),bank);
}
} // namespace silveton::arranger
