#include "silveton/arranger/Pa5xSampleDiskCache.h"
#include "silveton/sampler/SvBankFormat.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <sys/stat.h>
#include <unistd.h>

namespace silveton::arranger {
namespace {
constexpr std::size_t kHeaderBytes = 128U;
constexpr std::array<std::uint8_t,8> kMagic{{'S','V','P','5','P','C','M',0}};
using Digest = std::array<std::uint8_t,32>;
using Header = std::array<std::uint8_t,kHeaderBytes>;

bool cancelled(const std::atomic<bool>* cancel) noexcept {
    return cancel && cancel->load(std::memory_order_relaxed);
}
void put16(std::uint8_t* out,std::uint16_t value) noexcept {
    out[0]=static_cast<std::uint8_t>(value);out[1]=static_cast<std::uint8_t>(value>>8U);
}
void put32(std::uint8_t* out,std::uint32_t value) noexcept {
    for(unsigned i=0;i<4U;++i)out[i]=static_cast<std::uint8_t>(value>>(i*8U));
}
void put64(std::uint8_t* out,std::uint64_t value) noexcept {
    for(unsigned i=0;i<8U;++i)out[i]=static_cast<std::uint8_t>(value>>(i*8U));
}
std::uint16_t get16(const std::uint8_t* in) noexcept {
    return static_cast<std::uint16_t>(static_cast<unsigned>(in[0])|(static_cast<unsigned>(in[1])<<8U));
}
std::uint32_t get32(const std::uint8_t* in) noexcept {
    std::uint32_t value=0;for(unsigned i=0;i<4U;++i)value|=static_cast<std::uint32_t>(in[i])<<(i*8U);return value;
}
std::uint64_t get64(const std::uint8_t* in) noexcept {
    std::uint64_t value=0;for(unsigned i=0;i<8U;++i)value|=static_cast<std::uint64_t>(in[i])<<(i*8U);return value;
}
Digest digestOf(const Pa5xSampleDiskSpec& spec) noexcept {
    return silveton::sampler::sha256(reinterpret_cast<const std::uint8_t*>(spec.identity.data()),spec.identity.size());
}
std::string cachePath(const std::string& directory,const Digest& digest) {
    constexpr char digits[]="0123456789abcdef";
    std::string path=directory;
    if(path.back()!='/')path.push_back('/');
    for(const auto value:digest){path.push_back(digits[value>>4U]);path.push_back(digits[value&15U]);}
    path+=".svpcm";return path;
}
bool valid(const std::string& directory,const Pa5xSampleDiskSpec& spec,std::string& error) {
    if(directory.empty()||directory.front()!='/'||directory.find('\0')!=std::string::npos||directory.size()>4096U){
        error="Sample cache requires an absolute directory";return false;
    }
    if(spec.identity.empty()||spec.identity.size()>65536U||spec.resourceId==0||spec.sampleRate==0||spec.frameCount==0||
       spec.frameCount>(static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())-kHeaderBytes)/4U||
       spec.frameCount>(static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())-kHeaderBytes)/4U){
        error="Invalid decoded sample cache identity or audio extent";return false;
    }
    return true;
}
bool ensureDirectory(const std::string& directory,std::string& error) {
    std::string path;
    for(std::size_t pos=1U;pos<=directory.size();++pos){
        if(pos!=directory.size()&&directory[pos]!='/')continue;
        path=directory.substr(0,pos);
        if(path.empty()||path=="/")continue;
        if(::mkdir(path.c_str(),0700)!=0&&errno!=EEXIST){error="Cannot create sample cache directory: "+std::string(std::strerror(errno));return false;}
        struct stat st{};
        // Android's own /data/user/0 or macOS /var may be a system symlink.
        // The caller supplies its private cache root; follow those prefixes.
        if(::stat(path.c_str(),&st)!=0||!S_ISDIR(st.st_mode)){error="Sample cache path is not a directory";return false;}
    }
    return true;
}
bool readAll(int fd,std::uint8_t* data,std::size_t size) noexcept {
    while(size!=0U){const auto count=::read(fd,data,size);if(count<0&&errno==EINTR)continue;if(count<=0)return false;
        data+=static_cast<std::size_t>(count);size-=static_cast<std::size_t>(count);}
    return true;
}
bool writeAll(int fd,const std::uint8_t* data,std::size_t size) noexcept {
    while(size!=0U){const auto count=::write(fd,data,size);if(count<0&&errno==EINTR)continue;if(count<=0)return false;
        data+=static_cast<std::size_t>(count);size-=static_cast<std::size_t>(count);}
    return true;
}
Header makeHeader(const Pa5xSampleDiskSpec& spec,const Digest& digest) noexcept {
    Header header{};std::copy(kMagic.begin(),kMagic.end(),header.begin());
    put32(header.data()+8,1U);put32(header.data()+12,static_cast<std::uint32_t>(kHeaderBytes));
    put64(header.data()+16,spec.resourceId);put64(header.data()+24,spec.frameCount);
    put32(header.data()+32,spec.sampleRate);put16(header.data()+36,1U);
    put16(header.data()+38,3U);put16(header.data()+40,32U);
    std::copy(digest.begin(),digest.end(),header.begin()+48);return header;
}
bool matches(const Header& header,const Pa5xSampleDiskSpec& spec,const Digest& digest) noexcept {
    return std::equal(kMagic.begin(),kMagic.end(),header.begin())&&get32(header.data()+8)==1U&&
        get32(header.data()+12)==kHeaderBytes&&get64(header.data()+16)==spec.resourceId&&
        get64(header.data()+24)==spec.frameCount&&get32(header.data()+32)==spec.sampleRate&&
        get16(header.data()+36)==1U&&get16(header.data()+38)==3U&&get16(header.data()+40)==32U&&
        std::equal(digest.begin(),digest.end(),header.begin()+48);
}
} // namespace

std::string pa5xSampleContentHash(const std::uint8_t* data,std::size_t bytes) {
    if(!data&&bytes!=0U)return {};
    constexpr std::uint8_t empty=0U;
    const auto digest=silveton::sampler::sha256(data?data:&empty,bytes);
    constexpr char digits[]="0123456789abcdef";
    std::string out;out.reserve(digest.size()*2U);
    for(const auto value:digest){out.push_back(digits[value>>4U]);out.push_back(digits[value&15U]);}
    return out;
}

void warmPa5xReverseSampleEntry(const silveton::sampler::SampleStream& stream) noexcept {
    const auto raw=stream.rawView();
    const auto frameBytes=raw.frameBytes();
    if(!raw.data||raw.frames==0U||frameBytes==0U||
       raw.frames>std::numeric_limits<std::size_t>::max()/frameBytes)return;
    const auto bytes=static_cast<std::size_t>(raw.frames)*frameBytes;
    const auto wanted=std::min<std::size_t>(bytes,16384U);
    const auto* begin=raw.data+(bytes-wanted);
    const auto rawPage=::sysconf(_SC_PAGESIZE);
    const auto page=static_cast<std::size_t>(rawPage>0?rawPage:4096L);
    // Touch actual audio addresses only, never an aligned address before the
    // recording or beyond its final frame. These faults happen on the worker.
    (void)*reinterpret_cast<const volatile std::uint8_t*>(begin);
    const auto firstPageStep=page-(reinterpret_cast<std::uintptr_t>(begin)%page);
    for(std::size_t offset=firstPageStep;offset<wanted;offset+=page)
        (void)*reinterpret_cast<const volatile std::uint8_t*>(begin+offset);
    if(wanted>1U)(void)*reinterpret_cast<const volatile std::uint8_t*>(begin+wanted-1U);
}

Pa5xSampleDiskImport openPa5xSampleDiskCache(const std::string& directory,
    const Pa5xSampleDiskSpec& spec,std::size_t prefixFrames) {
    Pa5xSampleDiskImport result;
    if(!valid(directory,spec,result.error))return result;
    const auto digest=digestOf(spec);result.path=cachePath(directory,digest);
    const int fd=::open(result.path.c_str(),O_RDONLY|O_CLOEXEC);
    if(fd<0){result.error="Decoded sample cache is unavailable";return result;}
    Header header{};struct stat st{};
    const auto bytes=static_cast<std::uint64_t>(kHeaderBytes)+spec.frameCount*4U;
    const bool okay=::fstat(fd,&st)==0&&S_ISREG(st.st_mode)&&st.st_size>=0&&
        static_cast<std::uint64_t>(st.st_size)==bytes&&readAll(fd,header.data(),header.size())&&matches(header,spec,digest);
    if(!okay){::close(fd);result.error="Decoded sample cache metadata or length does not match this resource";return result;}
    // A warm SET open reads only this header and its bounded attack prefix.
    // Do not visit the tail of every recording: thousands of unconditional
    // 16KiB tail faults used to reread hundreds of MiB on every cache reopen.
    const auto preload=std::min<std::uint64_t>(spec.frameCount,static_cast<std::uint64_t>(prefixFrames));
    result.attackPrefix.resize(static_cast<std::size_t>(preload));
    const bool prefixRead=readAll(fd,reinterpret_cast<std::uint8_t*>(result.attackPrefix.data()),
        static_cast<std::size_t>(preload)*sizeof(float));
    ::close(fd);
    if(!prefixRead){result.attackPrefix.clear();result.error="Decoded sample cache prefix is incomplete";return result;}
    for(auto& frame:result.attackPrefix){
        const auto bits=get32(reinterpret_cast<const std::uint8_t*>(&frame));
        float value=0.0F;std::memcpy(&value,&bits,sizeof(value));
        if(!std::isfinite(value)){result.attackPrefix.clear();result.error="Decoded sample cache prefix is invalid";return result;}
        frame=std::clamp(value,-1.0F,1.0F);
    }
    silveton::sampler::MappedPcmSpec pcm;
    pcm.dataOffset=kHeaderBytes;pcm.frameCount=spec.frameCount;pcm.sampleRate=spec.sampleRate;
    pcm.channels=1U;pcm.bitDepth=32U;pcm.formatTag=3U;
    auto stream=silveton::sampler::MappedPcmStream::open(result.path,pcm,result.error);
    if(!stream)return result;
    // Remaining pages stay demand-mapped and are read ahead only for active
    // voice windows by SampleStreamPrefetcher, including reverse playback.
    result.stream=std::move(stream);result.cacheHit=true;return result;
}

Pa5xSampleDiskImport storePa5xSampleDiskCache(const std::string& directory,
    const Pa5xSampleDiskSpec& spec,const float* mono,std::size_t frameCount,
    const std::atomic<bool>* cancel,std::size_t prefixFrames) {
    Pa5xSampleDiskImport result;
    if(!valid(directory,spec,result.error))return result;
    if(!mono||static_cast<std::uint64_t>(frameCount)!=spec.frameCount){result.error="Decoded sample cache input extent does not match";return result;}
    if(cancelled(cancel)){result.error="Decoded sample cache preparation cancelled";return result;}
    result=openPa5xSampleDiskCache(directory,spec,prefixFrames);
    if(result)return result;
    result.error.clear();
    if(!ensureDirectory(directory,result.error))return result;
    const auto digest=digestOf(spec);result.path=cachePath(directory,digest);
    std::string temporary=result.path+".tmp-XXXXXX";
    std::vector<char> name(temporary.begin(),temporary.end());name.push_back(0);
    const int fd=::mkstemp(name.data());
    if(fd<0){result.error="Cannot create decoded sample cache file: "+std::string(std::strerror(errno));return result;}
    (void)::fcntl(fd,F_SETFD,FD_CLOEXEC);
    temporary=name.data();
    const auto fail=[&](const std::string& message){::close(fd);::unlink(temporary.c_str());result.error=message;return result;};
    const auto header=makeHeader(spec,digest);
    if(!writeAll(fd,header.data(),header.size()))return fail("Cannot write decoded sample cache header");
    constexpr std::size_t chunkFrames=16384U;
    std::array<std::uint8_t,chunkFrames*4U> encoded{};
    const std::uint16_t endianMarker=1U;
    const bool littleEndian=*reinterpret_cast<const std::uint8_t*>(&endianMarker)==1U;
    static_assert(sizeof(float)==4U&&std::numeric_limits<float>::is_iec559,"Float32 sample cache requires IEEE754");
    for(std::size_t begin=0;begin<frameCount;){
        if(cancelled(cancel))return fail("Decoded sample cache preparation cancelled");
        const auto count=std::min(chunkFrames,frameCount-begin);
        if(std::any_of(mono+begin,mono+begin+count,[](float value){return !std::isfinite(value);}))
            return fail("Decoded sample cache input contains invalid audio");
        const std::uint8_t* bytes=nullptr;
        if(littleEndian)bytes=reinterpret_cast<const std::uint8_t*>(mono+begin);
        else {
            for(std::size_t i=0;i<count;++i){std::uint32_t bits=0;std::memcpy(&bits,mono+begin+i,4U);put32(encoded.data()+i*4U,bits);}
            bytes=encoded.data();
        }
        if(!writeAll(fd,bytes,count*4U))return fail("Cannot write decoded sample cache audio (check free storage)");
        begin+=count;
    }
    if(cancelled(cancel))return fail("Decoded sample cache preparation cancelled");
    // This is a regenerable cache, not the only copy of user data. Closing then
    // atomically renaming avoids incomplete files without per-sample fsync cost.
    if(::close(fd)!=0){::unlink(temporary.c_str());result.error="Cannot close decoded sample cache file";return result;}
    if(::rename(temporary.c_str(),result.path.c_str())!=0){::unlink(temporary.c_str());result.error="Cannot publish decoded sample cache file";return result;}
    result=openPa5xSampleDiskCache(directory,spec,prefixFrames);result.cacheHit=false;return result;
}

} // namespace silveton::arranger
