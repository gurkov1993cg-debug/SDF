#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/arranger/KorgMidiInspection.h"
#include "silveton/arranger/KorgResourceContainer.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <fstream>
#include <limits>
#include <map>
#include <set>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumBytes = 64U * 1024U * 1024U;
struct XmlTag { std::string name; std::map<std::string,std::string> attributes; };
bool space(char c) { return c==' ' || c=='\t' || c=='\r' || c=='\n'; }
bool nameChar(char c) {
    const auto u=static_cast<unsigned char>(c);
    return std::isalnum(u)!=0 || c=='_' || c==':' || c=='-' || c=='.';
}
bool unescape(std::string& text) {
    std::string output;
    for(std::size_t p=0;p<text.size();) {
        if(text[p]!='&') { output+=text[p++];continue; }
        const auto end=text.find(';',p+1);if(end==std::string::npos)return false;
        const auto entity=text.substr(p,end-p+1);
        if(entity=="&amp;")output+='&';else if(entity=="&quot;")output+='"';
        else if(entity=="&apos;")output+='\'';else if(entity=="&lt;")output+='<';
        else if(entity=="&gt;")output+='>';else return false;
        p=end+1;
    }
    text=std::move(output);return true;
}
bool tagAt(const std::string& xml,std::size_t begin,XmlTag& tag,std::size_t& after) {
    const auto end=xml.find('>',begin);if(end==std::string::npos)return false;
    std::size_t p=begin+1,start=p;
    while(p<end&&nameChar(xml[p]))++p;
    if(p==start)return false;
    tag.name=xml.substr(start,p-start);
    while(p<end) {
        while(p<end&&space(xml[p]))++p;
        if(p==end)break;
        if(xml[p]=='/'&&p+1==end){++p;break;}
        start=p;while(p<end&&nameChar(xml[p]))++p;
        if(p==start)return false;
        const auto key=xml.substr(start,p-start);
        while(p<end&&space(xml[p]))++p;
        if(p>=end||xml[p++]!='=')return false;
        while(p<end&&space(xml[p]))++p;
        if(p>=end||(xml[p]!='"'&&xml[p]!='\''))return false;
        const auto quote=xml[p++];start=p;
        while(p<end&&xml[p]!=quote)++p;
        if(p==end)return false;
        std::string value=xml.substr(start,p-start);++p;
        if(!unescape(value)||!tag.attributes.emplace(key,std::move(value)).second)return false;
    }
    after=end+1;return true;
}
bool tags(const std::string& xml,const std::string& wanted,std::vector<XmlTag>& result) {
    const std::string needle="<"+wanted;std::size_t p=0;
    while((p=xml.find(needle,p))!=std::string::npos) {
        const auto next=p+needle.size();
        if(next==xml.size())return false;
        if(!space(xml[next])&&xml[next]!='/'&&xml[next]!='>'){p=next;continue;}
        XmlTag tag;std::size_t after=0;if(!tagAt(xml,p,tag,after)||tag.name!=wanted)return false;
        result.push_back(std::move(tag));p=after;
    }
    return true;
}
std::string attribute(const XmlTag& tag,const std::string& key) {
    const auto found=tag.attributes.find(key);return found==tag.attributes.end()?std::string():found->second;
}
bool numeric(const std::string& value,int& result) {
    if(value.empty())return false;
    std::size_t p=0;bool negative=false;
    if(value[0]=='-'){negative=true;++p;}else if(value[0]=='+')++p;
    if(p==value.size())return false;
    std::uint64_t total=0;
    const auto limit=static_cast<std::uint64_t>(std::numeric_limits<int>::max())+(negative?1U:0U);
    for(;p<value.size();++p) {
        if(value[p]<'0'||value[p]>'9')return false;
        const auto digit=static_cast<unsigned>(value[p]-'0');
        if(total>(limit-digit)/10U)return false;
        total=total*10U+digit;
    }
    if(negative&&total==limit)result=std::numeric_limits<int>::min();
    else result=negative?-static_cast<int>(total):static_cast<int>(total);
    return true;
}
std::string join(const std::string& parent,const std::string& child) {
    return parent.empty()?child:parent+'/'+child;
}
void fileIdentity(Pa5xPerformanceInspection& out) {
    const auto start=out.sourcePath.find_last_of("/\\");
    auto name=out.sourcePath.substr(start==std::string::npos?0:start+1);
    const auto dot=name.find_last_of('.');if(dot!=std::string::npos)name.resize(dot);
    std::size_t p=0;while(p<name.size()&&name[p]>='0'&&name[p]<='9')++p;
    if(p>0&&p<name.size()&&name[p]=='.') {
        int n=0;if(numeric(name.substr(0,p),n))out.filenameOrdinal=n;
        out.displayName=name.substr(p+1);
    }else out.displayName=name;
}

struct Parser {
    const std::vector<std::uint8_t>& bytes;
    Pa5xPerformanceInspection& out;
    std::map<std::string,const KorgResourceLeaf*> leaves;
    bool fail(const std::string& why){out.error=why;return false;}
    bool one(const std::string& xml,const std::string& name,XmlTag& result,bool required=true) {
        std::vector<XmlTag> found;
        if(!tags(xml,name,found)||found.size()>1)return fail("Invalid or duplicate XML element: "+name);
        if(found.empty()){if(required)return fail("Missing XML element: "+name);return true;}
        result=std::move(found[0]);return true;
    }
    bool number(const XmlTag& tag,const std::string& key,int& value,bool required=false) {
        const auto found=tag.attributes.find(key);
        if(found==tag.attributes.end())return !required||fail("Missing XML value: "+tag.name+'/'+key);
        return numeric(found->second,value)||fail("Invalid XML integer: "+tag.name+'/'+key);
    }
    bool midiRange(int value,const std::string& field) {
        return (value>=-1&&value<=127)||fail("MIDI range is outside 0..127: "+field);
    }
    bool xml(const std::string& path,std::string& text) {
        const auto found=leaves.find(path);
        if(found==leaves.end())return fail("Missing descriptor: "+path);
        text=korgResourceText(bytes,*found->second);
        if(text.empty()||text.find('\0')!=std::string::npos||text.find("<!")!=std::string::npos)
            return fail("Unsupported XML content in "+path);
        return true;
    }
    bool clipDescriptor(const std::string& path,const std::string& type,std::string& text) {
        if(!xml(path,text))return false;
        XmlTag root;
        if(!one(text,"CLIP",root))return false;
        int version=-1,release=-1;
        if(attribute(root,"type")!=type||!number(root,"version",version,true)||!number(root,"release",release,true))
            return fail("Wrong clip descriptor type/version: "+path);
        if(version!=0||(release!=3&&release!=4))return fail("Unsupported Plain/Pad clip revision: "+path);
        return text.find("</CLIP>")!=std::string::npos||fail("Unclosed clip descriptor: "+path);
    }
    bool readMidi(const std::string& path,Pa5xPerformancePart* part=nullptr,
                  KorgMidiPatchScope scope=KorgMidiPatchScope::CombinedChannels,
                  Pa5xPerformanceComplement* complement=nullptr) {
        const auto found=leaves.find(path);if(found==leaves.end())return fail("Missing MIDI resource: "+path);
        const auto& leaf=*found->second;
        std::vector<std::uint8_t> midi(bytes.begin()+static_cast<std::ptrdiff_t>(leaf.offset),
            bytes.begin()+static_cast<std::ptrdiff_t>(leaf.offset+leaf.length));
        auto inspected=inspectKorgMidiBytes(midi,scope);
        if(!inspected.valid)return fail("Invalid MIDI resource: "+path+": "+inspected.error);
        if(part==nullptr) {
            if(complement!=nullptr) {
                KorgSourceFxContext context;context.scope=KorgSourceFxScope::KeyboardMaster;
                context.resourcePath=path;context.ppq=inspected.ppq;
                out.sourceEffects=makeKorgSourceEffects(context,inspected.channelEvents,inspected.opaqueMidiEvents);
                if(!out.sourceEffects->complete)out.warnings.push_back(out.sourceEffects->error);
                Pa5xPerformanceComplement retained;
                retained.present=true;retained.resourcePath=path;
                retained.midiBytes=std::move(midi);retained.midi=std::move(inspected);
                *complement=std::move(retained);
            }
            return true;
        }
        part->present=true;part->resourcePath=path;part->ppq=inspected.ppq;
        if(out.kind==Pa5xPerformanceKind::KeyboardSet){
            KorgSourceFxContext context;context.scope=KorgSourceFxScope::KeyboardPart;
            context.resourcePath=path;context.ppq=inspected.ppq;context.logicalPart=part->track-1;
            context.rawFxGroup=part->rawFxGroup;context.rawDryOff=part->rawDryOff;
            part->sourceEffects=makeKorgSourceEffects(context,inspected.channelEvents,inspected.opaqueMidiEvents);
            if(!part->sourceEffects->complete)out.warnings.push_back(path+": "+part->sourceEffects->error);
        }
        part->midiSpanTicks=inspected.spanTicks;part->midiEventCount=inspected.eventCount;
        part->channelEvents=inspected.channelEvents;
        part->opaqueMidiEvents=std::move(inspected.opaqueMidiEvents);
        for(const auto& track:inspected.tracks)part->hasNoteEvents=part->hasNoteEvents||track.notes;
        for(const auto& patch:inspected.patches)part->patches.push_back({patch.tick,patch.channel,patch.msb,patch.lsb,patch.program,
            patch.msb>=0&&patch.lsb>=0&&patch.program>=0});
        std::array<Pa5xPerformanceChannel,16> channels{};
        std::array<bool,16> used{};
        for(std::size_t i=0;i<channels.size();++i)channels[i].channel=static_cast<int>(i);
        for(const auto& event:inspected.channelEvents) {
            const auto channel=static_cast<std::size_t>(event.status&15U);used[channel]=true;
            if((event.status&0xF0U)!=0xB0U)continue;
            auto& c=channels[channel];
            if(event.data1==7)c.volumeRaw=event.data2;
            else if(event.data1==10)c.panRaw=event.data2;
            else if(event.data1==11)c.expressionRaw=event.data2;
        }
        for(std::size_t i=0;i<channels.size();++i)if(used[i])part->channels.push_back(channels[i]);
        if(part->patches.empty())out.warnings.push_back("No explicit Sound selection in "+path);
        for(const auto& patch:part->patches)if(!patch.addressComplete) {
            out.warnings.push_back("Sound address is incomplete in "+path);break;
        }
        return true;
    }
    bool settings(const std::string& xml,int track,Pa5xPerformancePart& part) {
        XmlTag t;if(!one(xml,"Track"+std::to_string(track)+"Params",t))return false;
        if(!number(t,"mute",part.mute)||!number(t,"keyrangelow",part.keyLow)||!number(t,"keyrangehigh",part.keyHigh)||
           !number(t,"dynamicrangelow",part.velocityLow)||!number(t,"dynamicrangehigh",part.velocityHigh)||
           !number(t,"trackroute",part.trackRoute)||!number(t,"actuator",part.actuatorRaw)||!number(t,"controllers",part.controllersRaw))return false;
        if(!midiRange(part.keyLow,"key low")||!midiRange(part.keyHigh,"key high")||
           !midiRange(part.velocityLow,"velocity low")||!midiRange(part.velocityHigh,"velocity high"))return false;
        if(part.keyLow>=0&&part.keyHigh>=0&&part.keyLow>part.keyHigh)return fail("Reversed Keyboard Set key range");
        if(part.velocityLow>=0&&part.velocityHigh>=0&&part.velocityLow>part.velocityHigh)return fail("Reversed Keyboard Set velocity range");
        if(part.mute<-1||part.mute>1)return fail("Invalid Keyboard Set mute flag");
        const auto fxGroup=attribute(t,"fxGroup");
        if(!fxGroup.empty()&&!numeric(fxGroup,part.rawFxGroup))
            out.warnings.push_back("Unrecognized original Keyboard Set FX-group value");
        // Direct KSC revisions put each EQSetting inside its TrackNParams.
        // Nested revisions instead declare it in the corresponding PlainClip.
        const auto label="Track"+std::to_string(track)+"Params";
        const auto start=xml.find("<"+label),end=start==std::string::npos?std::string::npos:xml.find("</"+label+">",start);
        if(end!=std::string::npos)drySetting(xml.substr(start,end-start),part);
        return true;
    }
    void drySetting(const std::string& xml,Pa5xPerformancePart& part) {
        std::vector<XmlTag> values;
        if(!tags(xml,"EQSetting",values)||values.size()>1){
            out.warnings.push_back("Ambiguous original Keyboard Set dry-signal declaration");return;
        }
        if(values.empty())return;
        const auto raw=attribute(values.front(),"dryOff");
        if(!raw.empty()&&!numeric(raw,part.rawDryOff))
            out.warnings.push_back("Unrecognized original Keyboard Set dry-signal value");
    }
    bool pitch(const std::string& xml,Pa5xPerformancePart& part) {
        drySetting(xml,part);
        XmlTag t;if(!one(xml,"Pitch",t,false))return false;
        if(t.name.empty())return true;
        part.transpositionDeclared=t.attributes.find("transposition")!=t.attributes.end();
        return number(t,"transposition",part.transpositionRaw);
    }
    bool keyboard(const std::string& descriptor,const XmlTag& root) {
        const bool nested=out.version==0&&(out.release==3||out.release==4);
        const bool direct=out.version==1&&out.release==0&&out.subtype==4;
        if(!nested&&!direct)return fail("Unsupported KeyboardSetClip revision");
        XmlTag resource;if(!one(descriptor,"RESOURCE",resource))return false;
        XmlTag keyboard;
        if(!one(descriptor,"KeyboardProcessing",keyboard)||!number(keyboard,"splitpoint",out.splitPoint)||
           !number(keyboard,"globalsplit",out.useGlobalSplit)||!number(keyboard,"chordscanning",out.chordScanningRaw)||
           !number(keyboard,"keyboardmode",out.keyboardModeRaw)||
           !number(keyboard,"bassinversion",out.bassInversionRaw))return false;
        out.upperOctaveDeclared=keyboard.attributes.find("upperoctavetranspose")!=keyboard.attributes.end();
        if(!number(keyboard,"upperoctavetranspose",out.upperOctaveTransposeRaw)||!midiRange(out.splitPoint,"split point"))return false;
        if(out.useGlobalSplit<-1||out.useGlobalSplit>1)return fail("Invalid globalsplit flag");
        if(keyboard.attributes.count("bassinversion")!=0U&&(out.bassInversionRaw<0||out.bassInversionRaw>1))
            return fail("Invalid Keyboard Set bass inversion flag");
        XmlTag lower;if(!one(descriptor,"Lower",lower,false)||!number(lower,"use",out.lowerUseRaw))return false;
        std::array<std::string,4> paths;
        if(direct) {
            for(int track=1;track<=4;++track) {
                paths[static_cast<std::size_t>(track-1)]=attribute(resource,"track"+std::to_string(track));
                if(paths[static_cast<std::size_t>(track-1)].empty())return fail("Keyboard Set lacks a declared track resource");
            }
        }else {
            const auto session=attribute(resource,"name");if(session.empty())return fail("Keyboard Set session resource is missing");
            std::string sessionXml;
            if(!xml(join(session,"SessionDescription.xml"),sessionXml))return false;
            XmlTag sessionTag,sceneResource;
            if(!one(sessionXml,"SESSION",sessionTag)||!one(sessionXml,"RESOURCE",sceneResource))return false;
            int maxTracks=-1,maxScenes=-1,sceneNum=-1;
            if(!number(sessionTag,"maxtracks",maxTracks,true)||!number(sessionTag,"maxscenes",maxScenes,true)||
               !number(sceneResource,"scenenum",sceneNum,true))return false;
            if(maxTracks!=4||maxScenes!=1||sceneNum!=1)return fail("Unsupported Keyboard Set session topology");
            const auto scene=join(session,attribute(sceneResource,"name"));
            std::string sceneXml;if(!xml(join(scene,"SceneDescription.xml"),sceneXml))return false;
            std::vector<XmlTag> trackResources;if(!tags(sceneXml,"RESOURCE",trackResources))return fail("Invalid scene resource list");
            if(trackResources.size()!=4)return fail("Keyboard Set must declare exactly four tracks");
            for(const auto& tr:trackResources) {
                int track=-1;if(!number(tr,"track",track,true))return false;
                if(track<1||track>4||attribute(tr,"type")!="PlainClip")return fail("Unsupported Keyboard Set track role");
                auto& path=paths[static_cast<std::size_t>(track-1)];
                if(!path.empty())return fail("Duplicate Keyboard Set track role");
                const auto clip=join(scene,attribute(tr,"name"));
                std::string clipXml;if(!clipDescriptor(join(clip,"ClipDescription.xml"),"PlainClip",clipXml))return false;
                XmlTag midiResource;if(!one(clipXml,"RESOURCE",midiResource))return false;
                const auto midiName=attribute(midiResource,"name");if(midiName.empty())return fail("Keyboard Set clip MIDI reference is empty");
                path=join(clip,midiName);
                Pa5xPerformancePart part;part.track=track;
                if(!pitch(clipXml,part))return false;
                // Pitch is kept with the matching role after declaration ordering is normalized.
                if(out.parts.size()<4)out.parts.resize(4);
                out.parts[static_cast<std::size_t>(track-1)].transpositionRaw=part.transpositionRaw;
                out.parts[static_cast<std::size_t>(track-1)].transpositionDeclared=part.transpositionDeclared;
                out.parts[static_cast<std::size_t>(track-1)].rawDryOff=part.rawDryOff;
            }
        }
        if(out.parts.size()<4)out.parts.resize(4);
        static const char* names[]{"Lower","Upper1","Upper2","Upper3"};
        for(std::size_t i=0;i<4;++i) {
            auto& part=out.parts[i];part.track=static_cast<int>(i+1);part.name=names[i];
            if(paths[i].empty()||!settings(descriptor,part.track,part)||!readMidi(paths[i],&part))return false;
        }
        const auto effects=attribute(resource,"complement");
        if(!effects.empty()) {
            if(!readMidi(effects,nullptr,KorgMidiPatchScope::CombinedChannels,&out.complement))return false;
            out.warnings.push_back("Original Keyboard Set effect selectors and parameter blocks are retained; algorithm and routing support is reported separately from source decoding.");
        }
        if(out.lowerUseRaw<-1||out.lowerUseRaw>1)return fail("Invalid Keyboard Set Lower use flag");
        (void)root;
        out.playbackBlockers.push_back("Keyboard Set sound/DSP, controller and effect processing is not fully decoded");
        return true;
    }
    bool pad(const std::string& descriptor) {
        if(out.version!=0||(out.release!=3&&out.release!=4))return fail("Unsupported PadClip revision");
        XmlTag resource;if(!one(descriptor,"RESOURCE",resource))return false;
        const auto midi=attribute(resource,"name");if(midi.empty())return fail("Pad MIDI reference is missing");
        Pa5xPerformancePart part;part.track=1;part.name="Pad";
        if(!readMidi(midi,&part,KorgMidiPatchScope::SetupAndIndependentCvs)||!pitch(descriptor,part))return false;
        XmlTag pattern;if(!one(descriptor,"Pattern",pattern,false))return false;
        part.patternType=attribute(pattern,"type");
        const auto raw=[&](const char* name,const char* key,int& value) {
            XmlTag t;return one(descriptor,name,t,false)&&number(t,key,value);
        };
        if(!raw("NTT","value",part.ntt)||!raw("NTR","value",part.ntr)||!raw("ReTrigger","mode",part.retrigger)||
           !raw("WrapAroundDegree","value",part.wrapAroundDegree)||!raw("KeyLow","value",part.keyLow)||
           !raw("KeyHigh","value",part.keyHigh))return false;
        if(!midiRange(part.keyLow,"pad low key")||!midiRange(part.keyHigh,"pad high key"))return false;
        XmlTag loop;if(!one(descriptor,"Loop",loop,false))return false;
        part.loopDeclared=!loop.name.empty();
        if(!number(loop,"number",part.loopNumberRaw)||!number(loop,"length",part.loopLengthRaw))return false;
        for(int n=1;n<=6;++n) {
            XmlTag cv;if(!one(descriptor,"CV"+std::to_string(n),cv,false))return false;
            if(!cv.name.empty())part.cvSources.push_back({n,attribute(cv,"root"),attribute(cv,"chord")});
        }
        const auto tableStart=descriptor.find("<CHORD_TABLE>");
        if(tableStart!=std::string::npos) {
            const auto start=tableStart+13;const auto end=descriptor.find("</CHORD_TABLE>",start);
            if(end==std::string::npos)return fail("Pad chord table is not closed");
            std::size_t pos=start;std::set<std::string> seen;
            while((pos=descriptor.find('<',pos))<end) {
                XmlTag chord;std::size_t after=0;if(!tagAt(descriptor,pos,chord,after)||after>end)return fail("Invalid Pad chord-table entry");
                int cv=-1;if(!number(chord,"cv",cv,true)||cv<1||cv>6||!seen.insert(chord.name).second)return fail("Invalid Pad chord variation selection");
                part.chordSelections.push_back({chord.name,cv});pos=after;
            }
        }
        out.parts.push_back(std::move(part));
        out.playbackBlockers.push_back("Pad CV/NTT, loop and Korg sound processing is not implemented by this metadata reader");
        return true;
    }
};
} // namespace

Pa5xPerformanceInspection inspectPa5xPerformanceBytes(const std::vector<std::uint8_t>& bytes,const std::string& sourcePath) {
    Pa5xPerformanceInspection out;out.sourcePath=sourcePath;fileIdentity(out);
    const auto container=inspectKorgResourceContainer(bytes,kMaximumBytes);out.recognized=container.recognized;
    if(!container.valid){out.error=container.error;return out;}
    Parser parser{bytes,out,{}};
    for(const auto& leaf:container.leaves) {
        for(const auto& p:leaf.path)if(p.empty()||p=="."||p==".."||p.find_first_of("/\\")!=std::string::npos) {
            out.error="Ambiguous internal resource path";return out;
        }
        if(!parser.leaves.emplace(korgResourcePath(leaf.path),&leaf).second){out.error="Duplicate internal resource path";return out;}
    }
    std::string descriptor;if(!parser.xml("ClipDescription.xml",descriptor))return out;
    XmlTag clip;if(!parser.one(descriptor,"CLIP",clip))return out;
    if(descriptor.find("</CLIP>")==std::string::npos){out.error="Unclosed performance descriptor";return out;}
    if(!parser.number(clip,"version",out.version,true)||!parser.number(clip,"release",out.release,true)||!parser.number(clip,"subtype",out.subtype))return out;
    const auto type=attribute(clip,"type");
    if(type=="KeyboardSetClip") {out.kind=Pa5xPerformanceKind::KeyboardSet;out.valid=parser.keyboard(descriptor,clip);}
    else if(type=="PadClip") {out.kind=Pa5xPerformanceKind::Pad;out.valid=parser.pad(descriptor);}
    else out.error="This Root container is not a Keyboard Set or Pad";
    out.playable=false;return out;
}
Pa5xPerformanceInspection inspectPa5xPerformanceFile(const std::string& path) {
    Pa5xPerformanceInspection out;out.sourcePath=path;fileIdentity(out);
    std::ifstream file(path,std::ios::binary|std::ios::ate);
    if(!file){out.error="Cannot open Keyboard Set/Pad file";return out;}
    const auto size=file.tellg();
    if(size<11||size>static_cast<std::streamoff>(kMaximumBytes)){out.error="Performance file size is outside the supported inspection range";return out;}
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));file.seekg(0);
    file.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    if(!file){out.error="Performance resource read failed";return out;}
    return inspectPa5xPerformanceBytes(bytes,path);
}
} // namespace silveton::arranger
