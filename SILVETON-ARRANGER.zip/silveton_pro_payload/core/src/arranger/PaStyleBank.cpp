#include "silveton/arranger/PaStyleBank.h"
#include "PaCueGate.h"
#include "silveton/arranger/Pa5xOc31.h"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <fstream>
#include <map>
#include <stdexcept>

namespace silveton::arranger {
namespace {
using Byte = std::uint8_t;
using Bytes = std::vector<Byte>;
using Chord = ChordType;
constexpr std::size_t maxBytes = 64U << 20;
constexpr std::size_t maxEvents = 1000000;
struct FormatError : std::runtime_error { using runtime_error::runtime_error; };
void require(bool ok,const char* why) { if(!ok) throw FormatError(why); }
struct Slice {
    const Byte* data{}; std::size_t size{};
    Slice part(std::size_t at,std::size_t n) const {
        require(at<=size && n<=size-at,"Truncated Pa bank record");
        return {data+at,n};
    }
    Byte byte(std::size_t at) const { return *part(at,1).data; }
    unsigned word(std::size_t at) const { auto p=part(at,2).data;return unsigned(p[0])*256+p[1]; }
    std::uint32_t integer(std::size_t at) const { return (std::uint32_t(word(at))<<16)|word(at+2); }
};
struct Chunk {unsigned tag; Slice body;};
std::vector<Chunk> chunks(Slice data) {
    std::vector<Chunk> result;
    for(std::size_t at=0;at<data.size;){
        auto tag=data.integer(at),len=data.integer(at+4);
        require(result.size()<65536,"Too many Pa bank chunks");
        result.push_back({tag,data.part(at+8,len)});at+=8+len;
    }
    return result;
}
std::string label(Slice s) {
    std::string out;
    for(std::size_t i=0;i<s.size&&s.data[i];++i){
        auto c=s.data[i]; if(c>=32)out+=static_cast<char>(c);
    }
    return out;
}
struct Member {unsigned kind{},bank{};int slot{};std::string name;bool protectedData{};Chunk chunk{};};
struct Bank {
    Bytes file;
    std::map<int,Member> styles,settings,performances,pads;
    explicit Bank(const std::string& path){
        std::ifstream f(path,std::ios::binary|std::ios::ate);
        require(bool(f),"Cannot open Pa Style bank");auto n=f.tellg();
        require(n>=8&&n<=static_cast<std::streamoff>(maxBytes),"Invalid Pa bank size");
        file.resize(static_cast<std::size_t>(n));f.seekg(0);
        require(bool(f.read(reinterpret_cast<char*>(file.data()),n)),"Cannot read Pa Style bank");
        Slice data{file.data(),file.size()};auto root=chunks(data);
        require(root.size()==1&&root[0].tag==0x01000114,"Unrecognized Pa bank root");
        auto objects=chunks(root[0].body);
        require(objects.size()>=3 && objects[0].tag==0x02000018 && !std::memcmp(objects[0].body.part(7,4).data,"KORF",4)
              && objects.back().tag==0xfe000018,"Invalid KORF bank header");
        const auto xref=objects.back().body;const auto refs=objects.size()-2;
        require(xref.size==12+4*refs&&xref.integer(0)==0x4b424547&&xref.integer(4+4*refs)==0x4b454e44&&xref.integer(8+4*refs)==refs,
                "Invalid KORF cross-reference directory");
        for(std::size_t i=0;i<refs;++i){
            const auto offset=static_cast<std::size_t>(objects[i+1].body.data-file.data())-8;
            require(xref.integer(4+4*i)==offset,"KORF directory offset mismatch");
        }
        auto toc=objects[1];std::size_t index=2;
        for(std::size_t p=0;p<toc.body.size;){
            Member m;
            if(toc.tag==0x05000018){
                auto r=toc.body.part(p,24);m.name=label(r.part(0,18));m.kind=r.byte(18);m.bank=r.byte(19);m.slot=r.byte(20);p+=24;
            }else{
                // Pa3X directory 1.1 uses the same length-delimited properties and
                // four-byte row trailer as 1.0, including protected entries.
                require(toc.tag==0x05010018||toc.tag==0x05010118,"Unsupported Pa bank directory version");
                auto r=toc.body.part(p,toc.body.word(p)+2);require(r.size>=8,"Short bank directory row");
                std::size_t at=4;
                for(unsigned j=0;j<r.word(2);++j){
                    unsigned key=r.word(at),len=r.word(at+2);auto value=r.part(at+4,len);at+=4+len;
                    if(key==0){m.kind=value.byte(0);m.bank=value.byte(1);m.slot=value.byte(2);}
                    if(key==2)m.name=label(value);
                    if(key==3)m.protectedData=true;
                }
                require(at+4==r.size,"Invalid Pa bank property lengths");p+=r.size;
            }
            require(index+1<objects.size(),"Pa directory refers beyond bank");m.chunk=objects[index++];
            if(m.kind==2||m.kind==7||m.kind==1||m.kind==9){
                auto& entries=m.kind==2?styles:m.kind==1?performances:m.kind==9?pads:settings;
                require(m.slot<128 && !entries.count(static_cast<int>(m.slot)),"Duplicate or invalid Pa Style slot");
                entries.emplace(m.slot,m);
            }
        }
        require(index+1==objects.size(),"Unmatched Pa bank objects");
    }
};
Bytes unpack(const Member& obj,unsigned type){
    require(!obj.protectedData&&(obj.chunk.tag&0x40U)==0,"Protected Pa resource");
    require((obj.chunk.tag>>24)==type,"Pa bank object type mismatch");auto s=obj.chunk.body;
    if(s.size>=4 && !std::memcmp(s.data,"OC31",4)){
        auto decoded=decodePa5xOc31(s.data,s.size,16U<<20);
        if(!decoded)throw FormatError(decoded.error);
        return std::move(decoded.data);
    }
    require((obj.chunk.tag&0x20)==0,"Unknown compressed Pa resource");
    return Bytes(s.data,s.data+s.size);
}
int storedTempo(Slice data,int depth=0){
    require(depth<8,"Too many nested performance records");
    for(auto c:chunks(data)){
        auto s=c.body;
        if(c.tag==0x04000108 && s.integer(0)==15)return s.byte(7);
        if(c.tag==0x04020008 && s.integer(0)==15){
            std::size_t p=5;
            if(!s.byte(4)){
                p=8;for(int i=0;i<2;++i){while(s.byte(p++)){}}
                auto n=s.integer(p);p+=4;s.part(p,n);p+=n;
            }
            return s.byte(p+1);
        }
        if((c.tag&255)==0){int bpm=storedTempo(s,depth+1);if(bpm)return bpm;}
    }
    return 0;
}
using Performances=std::map<int,Pa5xPerformanceInspection>;
void keyboardBlock(Slice body,Performances& entries,const std::string& source){
    Pa5xPerformanceInspection k;k.recognized=true;k.kind=Pa5xPerformanceKind::KeyboardSet;
    int index=-1;std::uint64_t recordOrder=0;std::vector<KorgSourceFxRawRecord> effects;
    for(auto c:chunks(body)){
        auto s=c.body;const auto order=recordOrder++;
        if(c.tag==0x0f000008){
            index=static_cast<int>(s.integer(0));k.displayName=label(s.part(4,33));
        }else if(c.tag==0x22000008&&s.size==2){
            if(s.byte(0)<=1)k.useGlobalSplit=s.byte(0);
            if(s.byte(1)<=127)k.splitPoint=s.byte(1);
        }else if(c.tag==0x09000008||c.tag==0x09010008||c.tag==0x09010108){
            unsigned track=s.integer(0);require(track<4,"Unexpected Pa keyboard part");
            Pa5xPerformancePart p;p.track=static_cast<int>(track+1);p.present=true;
            static constexpr const char* names[]={"Lower","Upper1","Upper2","Upper3"};
            p.name=names[track];p.resourcePath=p.name;
            p.sourceNativeTrack=std::make_shared<PaSeriesTrackSettings>(readPaSeriesTrackSettings(c.tag,s.data,s.size));
            if(!p.sourceNativeTrack->structurallyValid)
                k.warnings.push_back(p.name+": "+p.sourceNativeTrack->error);
            p.mute=(s.byte(7)&4)!=0;
            p.velocityLow=s.byte(8);p.velocityHigh=s.byte(9);p.keyLow=s.byte(10);p.keyHigh=s.byte(11);
            p.transpositionRaw=static_cast<std::int8_t>(s.byte(19));p.transpositionDeclared=true;
            const Byte msb=s.byte(12),lsb=s.byte(13),program=s.byte(15);
            // A native part has an explicit role. The setup is presented to the existing
            // recall reader on its own logical channel, independently of external MIDI.
            auto add=[&](Byte status,Byte a,Byte b){p.channelEvents.push_back({0,0,static_cast<Byte>(status|track),a,b,p.channelEvents.size()});};
            if(msb<=127&&lsb<=127&&program<=127&&s.byte(14)==0){
                add(0xb0,0,msb);add(0xb0,32,lsb);add(0xc0,program,0);
                p.patches.push_back({0,static_cast<int>(track),msb,lsb,program,true});
            }
            if(s.byte(16)<128)add(0xb0,7,s.byte(16));
            if(s.byte(17)<128)add(0xb0,10,s.byte(17));
            p.midiEventCount=p.channelEvents.size();k.parts.push_back(std::move(p));
        }else if(c.tag==0x07000008U||c.tag==0x1D000008U){
            if(effects.size()<kMaximumKorgSourceFxDefinitions){
                KorgSourceFxRawRecord record;record.tag=c.tag;record.order=order;
                // Only the two proven fixed-size record layouts are copied.
                // An unexpected size is recorded as malformed without an
                // unbounded allocation or a fabricated MIDI representation.
                if(s.size<=78U)record.bytes.assign(s.data,s.data+s.size);
                effects.push_back(std::move(record));
            }else if(effects.size()==kMaximumKorgSourceFxDefinitions){
                // One bounded sentinel tells the reducer that source records
                // were omitted; the resulting profile must not claim complete.
                effects.push_back({});
            }
        }
    }
    if(index<0)return;
    if(!effects.empty()){
        KorgSourceFxContext context;context.scope=KorgSourceFxScope::KeyboardMaster;
        context.resourcePath=source+"!/KeyboardSetRecord/"+std::to_string(index)+"/effects";
        k.sourceEffects=makeKorgPrfSourceEffects(context,effects);
        if(!k.sourceEffects->complete)k.warnings.push_back(k.sourceEffects->error);
        if(k.sourceEffects->unrecognizedFxMessages)
            k.warnings.push_back("Original PRF insert records are retained; their part/routing bindings are not decoded");
    }
    unsigned roles=0;for(const auto& p:k.parts)roles|=1U<<(p.track-1);
    k.valid=k.parts.size()==4&&roles==15;
    if(!k.valid)k.error="Legacy Keyboard Set has incomplete part data";
    require(entries.emplace(index,std::move(k)).second,"Duplicate Pa keyboard setting");
}
void findKeyboards(Slice s,Performances& out,const std::string& source,int depth=0){
    require(depth<8,"Too many nested Pa keyboard records");
    for(auto c:chunks(s)){
        if(c.tag==0x0a010000||c.tag==0x0a000000)keyboardBlock(c.body,out,source);
        else if((c.tag&255)==0)findKeyboards(c.body,out,source,depth+1);
    }
}
constexpr Element elements[]={Element::Var1,Element::Var2,Element::Var3,Element::Var4,
    Element::Intro1,Element::Intro2,Element::Fill1,Element::Fill2,Element::Ending1,Element::Ending2,
    Element::Break,Element::Intro3,Element::Ending3,Element::Fill3,Element::Fill4};
constexpr Chord chords[]={Chord::Major,Chord::Major6,Chord::Major7,Chord::Major7Flat5,Chord::Sus4,Chord::Sus2,
    Chord::Major7Sus4,Chord::Minor,Chord::Minor6,Chord::Minor7,Chord::Minor7Flat5,Chord::MinorMajor7,
    Chord::Seventh,Chord::SeventhFlat5,Chord::SeventhSus4,Chord::Diminished,Chord::DiminishedMajor7,
    Chord::Augmented,Chord::Augmented7,Chord::AugmentedMajor7,Chord::RootFifth,Chord::RootOctave,Chord::MajorFlat5,Chord::Diminished7};
constexpr Byte channels[]={9,10,8,11,12,13,14,15};
struct Cue {unsigned tick;unsigned index;bool start;};
struct Phrase {std::vector<MidiEvent> notes;std::vector<Cue> cues;std::vector<StyleTempoEvent> tempos;
    unsigned length{},root{},chord{};
    // 0 ordinary, 1 explicitly identified Guitar, 2 unrecognized Guitar
    // revision. Do not infer this from an instrument name or MIDI note range.
    int guitarKind{0};
    bool legacyGuitarProgression{false};};
Phrase phrase(Slice bytes,bool master,bool pitched){
    Phrase out;unsigned tick=0;auto s=bytes.part(8,bytes.word(6));std::size_t at=0;
    if(pitched){out.chord=bytes.byte(8+s.size);out.root=bytes.byte(9+s.size);}
    while(at<s.size){
        unsigned delay=0,opcode=s.byte(at++);
        while(opcode&128){require(delay<=0xffffff/128,"Pa delta time exceeds bounds");delay=128*delay+(opcode&127);opcode=s.byte(at++);}
        require(tick<=0x1ffffff-delay,"Pa track duration exceeds bounds");tick+=delay;
        if(opcode&64){++at;opcode&=63;}
        if(opcode==9){
            auto type=s.byte(at++);const std::size_t size=unsigned(s.byte(at))*128U+(s.byte(at+1)&127U);at+=2;
            auto payload=s.part(at,size);at+=size;
            if(type==47){require(size==0 && at==s.size,"Invalid Pa end of track");out.length=tick;return out;}
            if(master&&type==126&&size>=2&&(payload.byte(0)==3||payload.byte(0)==4))
                out.cues.push_back({tick,payload.byte(1),payload.byte(0)==3});
            if(type==81&&size==3){auto usec=payload.byte(0)*65536+payload.word(1);if(usec)out.tempos.push_back({tick,60000000.0/usec});}
            continue;
        }
        static constexpr Byte statuses[]={0x80,0x90,0,0xb0,0,0xd0,0xe0};
        unsigned status=opcode<7?statuses[opcode]:opcode==12?0x80:opcode==13?0x90:0;
        require(status,"Unsupported Pa MIDI event");
        bool one=status==0xc0||status==0xd0;unsigned a=s.byte(at++),b=one?0:s.byte(at++);
        require(one?(a&128):((a<128)&&(b&128)),"Invalid Pa MIDI data byte");
        out.notes.push_back({tick,0,static_cast<Byte>(status),static_cast<Byte>(a&127),static_cast<Byte>(b&127)});
    }
    throw FormatError("Incomplete Pa MIDI sequence");
}
// A master cue can stop before its phrase reaches the recorded Note Off or
// pedal-up. Release what this cue still owns at its boundary. Another cue on
// the same track can already have retriggered the same pitch.
struct CueEvent {
    MidiEvent event;
    std::size_t cue;
    bool closing{false};
};
void mergePitchedCues(std::vector<CueEvent>& source,std::vector<MidiEvent>& out,
                      std::size_t cueCount,std::size_t& totalEvents) {
    std::stable_sort(source.begin(),source.end(),[](const auto& a,const auto& b){
        return a.event.tick<b.event.tick;
    });
    std::vector<detail::PaCueState> cues(cueCount);
    detail::PaCueGate gate;
    const auto append=[&](MidiEvent event){
        require(++totalEvents<=maxEvents,"Too many expanded Pa Style events");
        out.push_back(event);
    };
    for(const auto& item:source){
        const auto& e=item.event;
        const auto channel=channels[e.track];
        auto& cue=cues[item.cue];
        gate.sync(cue);
        if(item.closing){
            for(unsigned key=0;key<cue.held.size();++key)
                if(cue.held[key] && gate.note(cue,key,false))
                    append({e.tick,e.track,static_cast<Byte>(0x80|channel),static_cast<Byte>(key),0});
            if(cue.pedalDown && gate.pedal(cue,false))
                append({e.tick,e.track,static_cast<Byte>(0xb0|channel),64,0});
            continue;
        }
        const int kind=e.status&0xf0;
        if(kind==0x90 || kind==0x80){
            if(!gate.note(cue,e.data1,kind==0x90 && e.data2!=0))continue;
        }else if(kind==0xb0 && e.data1==64){
            if(!gate.pedal(cue,e.data2>=64))continue;
        }else if(kind==0xb0 && (e.data1==120 || e.data1==121 || e.data1==123))
            gate.reset(e.data1!=121);
        append(e);
    }
}
struct Reader {
    std::shared_ptr<Style> style=std::make_shared<Style>();
    Pa5xStyleRead read;
    const Pa5xSetBank* sounds;
    unsigned mask{},nextElement{};std::size_t nextMap{},totalEvents{};
    std::vector<unsigned> mapping;std::vector<Phrase> pool;
    std::vector<KorgSourceFxRawRecord> mixerEffects;
    std::uint64_t mixerRecordOrder{0};
    std::array<std::shared_ptr<const PaSeriesTrackSettings>,kTracks> mixerParts{};
    explicit Reader(const Pa5xSetBank* s):sounds(s){}
    void warning(const char* message){
        if(std::find(read.warnings.begin(),read.warnings.end(),message)==read.warnings.end())
            read.warnings.push_back(message);
        if(std::find(style->playbackWarnings.begin(),style->playbackWarnings.end(),message)==style->playbackWarnings.end())
            style->playbackWarnings.push_back(message);
    }
    void tracks(Slice data, Section& section,Pa5xStyleReadSection& meta) {
        data.part(0,48);
        for(unsigned t=0;t<8;++t){
            auto& p=section.patterns[t]; auto& tr=style->tracks[t];auto& mt=meta.tracks[t];auto chan=channels[t];
            auto at=6*t;Byte exp=data.byte(at),msb=data.byte(at+1),lsb=data.byte(at+2),pc=data.byte(at+3);
            tr.role=t<2?(t==0?TrackRole::Drums:TrackRole::Percussion):t==2?TrackRole::Bass:TrackRole::Accompaniment;
            tr.sourceChannel=chan;p.mode=t<2?NativePatternMode::Drum:NativePatternMode::RecordedSourceOnly;
            p.keyLow=data.byte(at+4);p.keyHigh=data.byte(at+5);p.keyRangeEnabled=t>=2&&p.keyLow<=p.keyHigh&&p.keyHigh<128;
            if(data.size>=80)p.rawNtt=data.byte(72+t);
            mt.track=static_cast<int>(t);mt.ppq=384;mt.setupTimingKnown=true;
            if(msb>127||lsb>127||pc>127)continue;
            if(!tr.addressKnown){tr.msb=msb;tr.lsb=lsb;tr.program=pc;tr.addressKnown=true;}
            else if(tr.msb!=msb||tr.lsb!=lsb||tr.program!=pc)tr.addressVaries=true;
            auto control=[&](Byte type,Byte a,Byte b){p.setupEvents.push_back({0,static_cast<Byte>(t),static_cast<Byte>(type|chan),a,b});};
            control(0xb0,0,msb);control(0xb0,32,lsb);control(0xc0,pc,0);if(exp<=127)control(0xb0,11,exp);
            Pa5xStyleSoundChange change;change.fromSetup=true;change.channel=chan;change.msb=msb;change.lsb=lsb;change.program=pc;
            static const Pa5xSetBank emptySoundDirectory;
            change.sound=(sounds?*sounds:emptySoundDirectory).resolveSoundAddress(msb,lsb,pc);
            if(change.sound.resolution==KstResolution::FactorySoundRequired){
                change.sound.name.clear();
                change.sound.message="Original factory MIDI address retained; the source Pa model and its factory Sound name are unavailable";
            }
            mt.setupSoundChanges.push_back(std::move(change));
        }
    }
    void variation(Slice data,unsigned number,Section& section,Pa5xStyleReadSection& meta,
                   std::array<int,kTracks>& phraseKinds,std::array<bool,kTracks>& progressionProtocols){
        auto master=phrase(data,true,false);
        auto tail=data.part(8+data.word(6),data.size-8-data.word(6));
        unsigned count=tail.byte(0);require(count*2+1==tail.size&&nextMap+count<=mapping.size(),"Invalid Pa CV track table");
        auto first=nextMap;nextMap+=count;
        std::array<std::vector<CueEvent>,8> pitchedEvents;
        std::array<int,kTracks> sourceRoots;sourceRoots.fill(-1);
        std::vector<unsigned> cueEnd(master.cues.size());
        std::array<unsigned,256> nextCueTick;
        nextCueTick.fill(master.length);
        for(std::size_t i=master.cues.size();i>0;--i){
            const auto& cue=master.cues[i-1];
            cueEnd[i-1]=nextCueTick[cue.index];
            nextCueTick[cue.index]=cue.tick;
        }
        std::size_t staged=0;
        for(std::size_t i=0;i<master.cues.size();++i){
            auto cue=master.cues[i];require(cue.index<count,"Pa master selects missing phrase");
            if(!cue.start)continue;
            auto ref=mapping[first+cue.index];require(ref>0&&ref<=pool.size(),"Invalid Pa phrase reference");
            const auto& seq=pool[ref-1];auto t=tail.byte(2+2*cue.index);require(t<8,"Invalid Pa accompaniment part");
            auto& pat=section.patterns[t];auto& cv=pat.cvs[number];auto& mt=meta.tracks[t];auto& info=mt.cvs[number];
            cv.lengthTicks=master.length;cv.available=master.length>0;mt.present=pat.present=cv.available;
            if(!cv.available)continue;
            if(seq.notes.empty())continue;
            auto& kind=phraseKinds[t];
            if(kind==-1)kind=seq.guitarKind;
            else if(kind!=seq.guitarKind)kind=3; // One runtime pattern cannot mix ordinary notes and Guitar commands.
            progressionProtocols[t]=progressionProtocols[t]&&seq.legacyGuitarProgression;
            if(t>=2){
                if(seq.guitarKind==0)require(seq.root<12&&seq.chord<24,"Unsupported Pa recorded chord");
                // Guitar phrases can omit the original source pair (FF 00).
                // Their string/strum commands still follow the live chord;
                // absence is not a made-up C-major source declaration.
                if(seq.root<12){
                    const int root=static_cast<int>(seq.root);cv.sourceRoot=root;
                    if(seq.chord<24){
                        if(sourceRoots[t]==-1)sourceRoots[t]=root;
                        else if(sourceRoots[t]!=root)sourceRoots[t]=-2;
                        cv.sourceChord=chords[seq.chord];
                    }else sourceRoots[t]=-2; // FF 00 may be an absent pair, not a proven C key.
                }else sourceRoots[t]=-2;
            }
            const unsigned span=cueEnd[i]-cue.tick;
            const unsigned duration=std::min(span,seq.length);
            for(auto e:seq.notes){
                if(e.tick>duration)break;
                const bool attack=(e.status&0xf0)==0x90 && e.data2;
                if(t>=2 && e.tick==duration && attack)continue;
                e.tick+=cue.tick;e.track=static_cast<Byte>(t);e.status|=channels[t];
                if(t>=2){
                    require(++staged<=maxEvents,"Too many Pa cue events");
                    pitchedEvents[t].push_back({e,i,false});
                }else{
                    require(++totalEvents<=maxEvents,"Too many expanded Pa Style events");
                    cv.events.push_back(e);
                }
                if(attack)info.hasNotes=true;
            }
            if(t>=2){
                require(++staged<=maxEvents,"Too many Pa cue events");
                pitchedEvents[t].push_back({{cue.tick+duration,static_cast<Byte>(t),0,0,0},i,true});
            }
            style->tracks[t].used|=info.hasNotes;
        }
        for(unsigned t=0;t<8;++t){
            auto& pat=section.patterns[t];auto& cv=pat.cvs[number];if(!cv.available)continue;
            // A root is usable for progression transposition only when every
            // used phrase declares the same root. Do not let a later phrase
            // hide an earlier missing or conflicting declaration.
            cv.sourceRootKnown=sourceRoots[t]>=0;
            if(t>=2)mergePitchedCues(pitchedEvents[t],cv.events,master.cues.size(),totalEvents);
            else std::stable_sort(cv.events.begin(),cv.events.end(),[](const MidiEvent& a,const MidiEvent& b){return a.tick<b.tick;});
            for(const auto& event:cv.events)cv.observeSourceNote(event);
            cv.tempoEvents=master.tempos;auto& mt=meta.tracks[t];auto& info=mt.cvs[number];
            info.available=info.timingKnown=true;info.number=static_cast<int>(number+1);info.lengthTicks=cv.lengthTicks;info.soundChanges=mt.setupSoundChanges;
        }
        section.lengthTicks=std::max(section.lengthTicks,master.length);
    }
    void section(Slice s){
        while(nextElement<15&&!(mask&(1U<<nextElement)))++nextElement;
        require(nextElement<15,"Too many Pa Style elements");auto e=static_cast<unsigned>(elements[nextElement++]);
        auto& sec=style->sections[e];auto& meta=read.sections[e];unsigned flags=0,cv=0;
        std::array<int,kTracks> phraseKinds;phraseKinds.fill(-1);
        std::array<bool,kTracks> progressionProtocols;progressionProtocols.fill(true);
        for(auto c:chunks(s)){
            auto v=c.body;
            if((c.tag>>24)==1){
                unsigned at=(c.tag&0xff0000)?1:2;
                flags=v.byte(0);unsigned meter=v.byte(at++);sec.numerator=static_cast<Byte>(meter>>3);sec.denominator=static_cast<Byte>(1U<<(meter&7));
                unsigned nc=v.byte(at++);require((nc==22||nc==24)&&sec.numerator,"Unsupported Pa Style meter or chord table");
                for(auto& p:sec.patterns){
                    for(unsigned i=0;i<24;++i){auto choice=v.byte(at+(i<nc?i:i==22?13:15));
                        require(choice<6,"Invalid Pa chord variation selector");p.chordCv[static_cast<unsigned>(chords[i])]=static_cast<Byte>(choice+1);}
                }
            }else if((c.tag>>24)==2)tracks(v,sec,meta);
            else if((c.tag>>24)==3){
                while(cv<6&&!(flags&(1U<<cv)))++cv;
                require(cv<6,"Extra Pa chord variation");variation(v,cv++,sec,meta,phraseKinds,progressionProtocols);
            }
        }
        for(std::size_t track=0;track<phraseKinds.size();++track){
            auto& pattern=sec.patterns[track];
            if(phraseKinds[track]==1&&track>=2){
                pattern.mode=NativePatternMode::Guitar;pattern.legacyGuitarProgression=progressionProtocols[track];
                meta.tracks[track].patternType="Guitar";
                warning("Legacy Guitar phrase types are recognized; original capo, string limits and humanize settings are not decoded. Initial settings are capo 0, strings 1..6 and humanize 0; they can be edited.");
                warning("Guitar gestures use SILVETON six-string voicings and timing; original Korg voicing, noise and humanize algorithms are not reproduced.");
                const bool progressionElement=e==static_cast<unsigned>(Element::Intro1)||e==static_cast<unsigned>(Element::Ending1);
                for(std::size_t cv=0;cv<pattern.cvs.size();++cv){
                    const auto& source=pattern.cvs[cv];
                    const bool progressionKnown=pattern.legacyGuitarProgression&&progressionElement&&cv<2&&source.sourceRootKnown;
                    if(std::any_of(source.events.begin(),source.events.end(),[&](const auto& event){
                        return (event.status&0xf0)==0x90&&event.data2>0&&event.data1<12&&
                            (!progressionKnown||event.data2>24);
                    }))warning("Some Guitar chord commands lie outside the documented legacy Intro1/Ending1 CV1/CV2 protocol or lack a known source root; those commands are retained without guessing a conversion.");
                    if(source.sourceChord==ChordType::None&&std::any_of(source.events.begin(),source.events.end(),[](const auto& event){
                        return (event.status&0xf0)==0x90&&event.data2>0&&event.data1>=48&&event.data1<=95;
                    }))warning("A Guitar CV contains melody notes C3..B6 without a proven source chord; those melody notes remain silent while string/strum commands and RX notes remain available.");
                }
            }else if(phraseKinds[track]==1){
                pattern.mode=NativePatternMode::Unsupported;
                meta.tracks[track].patternType="Unsupported Guitar/Drum part binding";
                warning("Guitar metadata on a Drum/Percussion part is inconsistent; that track remains blocked.");
            }else if(phraseKinds[track]>=2){
                pattern.mode=NativePatternMode::Unsupported;
                meta.tracks[track].patternType="Unsupported Guitar mixture or revision";
                warning("A legacy track mixes ordinary/Guitar phrase types or uses an unknown Guitar revision; that track remains blocked.");
            }
        }
        sec.nativePatterns=true;
        for(auto& p:sec.patterns)for(auto& v:p.cvs)if(!v.events.empty())sec.available=true;
        meta.available=sec.available;meta.meterKnown=true;meta.numerator=sec.numerator;meta.denominator=sec.denominator;
    }
    void mixer(Slice s,int depth=0){
        require(depth<8,"Too many accompaniment mixer records");
        for(const auto& c:chunks(s)){
            const auto v=c.body;
            if(c.tag==0x05000000||c.tag==0x05010000){
                for(auto part:chunks(v)){
                    const auto order=mixerRecordOrder++;
                    if(part.tag==0x07000008U||part.tag==0x1D000008U){
                        if(mixerEffects.size()<kMaximumKorgSourceFxDefinitions){
                            KorgSourceFxRawRecord record;record.tag=part.tag;record.order=order;
                            if(part.body.size<=78U)record.bytes.assign(part.body.data,part.body.data+part.body.size);
                            mixerEffects.push_back(std::move(record));
                        }else if(mixerEffects.size()==kMaximumKorgSourceFxDefinitions)mixerEffects.push_back({});
                        continue;
                    }
                    if(part.tag!=0x09000008&&part.tag!=0x09010008&&part.tag!=0x09010108)continue;
                    auto data=part.body;auto t=data.integer(0);if(t>=8)continue;
                    auto native=std::make_shared<PaSeriesTrackSettings>(readPaSeriesTrackSettings(part.tag,data.data,data.size));
                    const auto& previous=mixerParts[t];
                    require(!previous||(previous->tag==native->tag&&previous->originalRecord==native->originalRecord),
                            "Conflicting native Pa accompaniment mixer records");
                    mixerParts[t]=std::move(native);
                }
            }else if((c.tag&255)==0 && (c.tag>>24)<=2)mixer(v,depth+1);
        }
    }
    void applyMixer(){
        // Stage the entire original mixer before applying it. A later
        // conflicting part must not leave earlier partial settings installed.
        for(std::size_t t=0;t<mixerParts.size();++t){
            const auto& native=mixerParts[t];if(!native)continue;
            if(!native->structurallyValid)warning(native->error.c_str());
            if(native->structurallyValid){
                auto bit=static_cast<Byte>(1U<<t);style->initialMuteKnownMask|=bit;
                read.originalMuteRaw[t]=(native->originalRecord[7]&4)?1:0;
                if(read.originalMuteRaw[t])style->initialMuteMask|=bit;
            }
            for(std::size_t e=0;e<style->sections.size();++e){
                auto& pattern=style->sections[e].patterns[t];if(!pattern.present)continue;
                read.sections[e].tracks[t].sourceNativeTrack=native;
                if(!native->structurallyValid)continue;
                auto control=[&](Byte cc,Byte value){if(value<128)pattern.setupEvents.push_back({0,static_cast<Byte>(t),
                    static_cast<Byte>(0xb0|channels[t]),cc,value});};
                control(7,native->originalRecord[16]);control(10,native->originalRecord[17]);
                if(native->masterFxSendRaw[0]>=0)control(91,static_cast<Byte>(native->masterFxSendRaw[0]));
                if(native->masterFxSendRaw[1]>=0)control(93,static_cast<Byte>(native->masterFxSendRaw[1]));
                if(native->pitchBendRangeSemitones>=0){
                    // Native integer semitones -> the engine's existing exact
                    // RPN0 setup path. The native bytes remain authoritative.
                    control(101,0);control(100,0);
                    control(6,static_cast<Byte>(native->pitchBendRangeSemitones));control(38,0);
                    control(101,127);control(100,127);
                }
            }
        }
    }
    void parse(Slice bytes){
        auto root=chunks(bytes);require(root.size()==1&&(root[0].tag>>24)==1,"Invalid Pa Style object");
        for(auto c:chunks(root[0].body)){
            auto v=c.body;
            if((c.tag>>24)==1){
                auto n=v.byte(0);style->name=label(v.part(1,n));
                require(c.tag==0x01000308||c.tag==0x01000208||c.tag==0x01000008,"Unsupported Pa Style header");
                mask=c.tag==0x01000308?v.word(1+n+16):v.word(1+n+3);
            }else if((c.tag>>24)==2)for(auto p:chunks(v)){
                if((p.tag>>24)==1){
                    auto n=p.body.word(2);require(p.body.size==4+n*2,"Invalid Pa phrase map");
                    for(unsigned i=0;i<n;++i)mapping.push_back(p.body.word(4+2*i));
                }else{
                    auto type=p.tag>>24;require(type>=2&&type<=5,"Unsupported Pa phrase type");
                    auto sequence=phrase(p.body,false,type>=3);
                    // Exact legacy type/version identification is documented
                    // by KORG-Tools' MIDITrackListReader::ReadGuitarTrackChunk.
                    // The remaining type-5 revisions have no guessed layout.
                    if(type==5)sequence.guitarKind=(p.tag==0x05000108||p.tag==0x05010008)?1:2;
                    // The original Pa4X corpus calibrates these outer/inner
                    // revision pairs against its manual's 24-chord velocity
                    // table. Other Style revisions may keep Guitar gestures,
                    // but do not silently inherit that progression protocol.
                    sequence.legacyGuitarProgression=
                        (root[0].tag==0x01050000&&p.tag==0x05010008)||
                        (root[0].tag==0x01040000&&p.tag==0x05000108);
                    pool.push_back(std::move(sequence));
                }
            }else if((c.tag>>24)==3)section(v);
        }
        require(nextMap==mapping.size(),"Unused Pa phrase mappings");
    }
};
Pa5xStyleRead load(const Bank& bank,const Member& obj,const std::string& source,const Pa5xSetBank* sounds){
    Reader r(sounds);r.read.sourcePath=source;r.read.recognized=true;r.read.name=obj.name;
    try{
        auto b=unpack(obj,6);r.parse({b.data(),b.size()});
        int tempo=0;auto setting=bank.settings.find(obj.slot);
        if(setting!=bank.settings.end()&&setting->second.bank==obj.bank)try{
            auto sts=unpack(setting->second,9);Slice data{sts.data(),sts.size()};tempo=storedTempo(data);r.mixer(data);r.applyMixer();
            if(!r.mixerEffects.empty()){
                KorgSourceFxContext context;context.scope=KorgSourceFxScope::StyleMaster;
                context.resourcePath=source+"!/StyleSettings/effects";
                r.read.sourceEffects=makeKorgPrfSourceEffects(context,r.mixerEffects);
                if(!r.read.sourceEffects->complete)r.warning(r.read.sourceEffects->error.c_str());
                if(r.read.sourceEffects->unrecognizedFxMessages)
                    r.warning("Original Style insert records are retained; their part/routing bindings are not decoded");
            }
            Performances keys;findKeyboards(data,keys,source);
            for(auto& pair:keys)if(pair.first>=0&&pair.first<4){
                auto& slot=r.read.keyboardSets[static_cast<std::size_t>(pair.first)];
                slot.position=pair.first+1;slot.declared=true;slot.available=pair.second.valid;slot.name=pair.second.displayName;
                slot.resourcePath="STS"+std::to_string(slot.position);pair.second.sourcePath=source+"!/"+slot.resourcePath;
                slot.error=pair.second.error;
                slot.keyboardSet=std::make_shared<Pa5xKeyboardSetRead>(readPa5xKeyboardSet(pair.second,sounds));
                r.read.keyboardSetMappingKnown=true;
            }
        }
        catch(const FormatError& problem){r.read.warnings.push_back(std::string("Style performance settings: ")+problem.what());}
        if(tempo>=20&&tempo<=255){r.style->tempoBpm=tempo;r.read.originalBpm=tempo;}
        else r.read.warnings.push_back("Original Style tempo unavailable; initial playback tempo is 120 BPM");
        r.style->ppq=r.read.ppq=384;r.style->nativeKorg=true;r.style->name=r.read.name;
        r.read.nativeStyle=r.style;r.read.valid=true;
    }catch(const FormatError& e){r.read.error=e.what();}
    return std::move(r.read);
}
}
bool paStyleBankPath(const std::string& path){
    if(path.size()<4)return false;
    auto ext=path.substr(path.size()-4);for(char& c:ext)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return ext==".sty";
}
namespace {
bool numberedSlot(const std::string& path,bool keyboard,std::string* bank,int* slot){
    const auto p=path.rfind("!/");
    if(p==std::string::npos||!(keyboard?paPerformanceBankPath(path.substr(0,p)):paStyleBankPath(path.substr(0,p)))||path.size()<=p+2||path.size()>p+5)return false;
    int n=0;for(auto i=p+2;i<path.size();++i){if(path[i]<'0'||path[i]>'9')return false;n=10*n+path[i]-'0';}
    if(n>127)return false;
    if(bank)*bank=path.substr(0,p);
    if(slot)*slot=n;
    return true;
}
bool keyboardSlot(const std::string& path,std::string& bank,int& slot,int& index){
    auto split=path.rfind("!/STS");
    if(split!=std::string::npos&&split+6==path.size()&&path.back()>='1'&&path.back()<='4'){
        index=path.back()-'1';return numberedSlot(path.substr(0,split),false,&bank,&slot);
    }
    index=4;return numberedSlot(path,true,&bank,&slot);
}
}
bool paPerformanceBankPath(const std::string& path){
    if(path.size()<4)return false;
    auto ext=path.substr(path.size()-4);for(auto& c:ext)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return ext==".prf";
}
bool paStyleSlot(const std::string& path,std::string* bank,int* slot){return numberedSlot(path,false,bank,slot);}
bool paKeyboardLocation(const std::string& path,std::string* physical){
    std::string bank;int slot,index;
    if(!keyboardSlot(path,bank,slot,index))return false;
    if(physical)*physical=bank;
    return true;
}
Pa5xPerformanceInspection readPaKeyboardLocation(const std::string& path){
    Pa5xPerformanceInspection failed;failed.sourcePath=path;
    try{
        std::string source;int slot,index;require(keyboardSlot(path,source,slot,index),"Invalid keyboard location");
        Bank bank(source);const auto& entries=index==4?bank.performances:bank.settings;
        auto entry=entries.find(slot);require(entry!=entries.end(),"Missing Pa keyboard slot");
        auto bytes=unpack(entry->second,9);Performances keys;findKeyboards({bytes.data(),bytes.size()},keys,path);
        auto found=keys.find(index);require(found!=keys.end(),"Unsupported Pa keyboard settings layout");
        found->second.sourcePath=path;found->second.filenameOrdinal=slot+1;
        if(index==4)found->second.displayName=entry->second.name;
        return std::move(found->second);
    }catch(const std::exception& e){failed.error=e.what();return failed;}
}
bool inspectPaPadBank(const std::string& path,const std::function<bool(const std::string&,bool)>& visit,std::string& error){
    try{
        Bank bank(path);
        for(const auto& pair:bank.pads){
            bool decoded=false;
            try{Reader reader(nullptr);auto b=unpack(pair.second,12);reader.parse({b.data(),b.size()});decoded=true;}
            catch(const FormatError&){}
            if(!visit(pair.second.name,decoded))return false;
        }
        return true;
    }catch(const std::exception& failure){error=failure.what();return false;}
}
bool inspectPaPerformanceBank(const std::string& path,const PaKeyboardVisitor& visit,std::string& error){
    try{
        Bank bank(path);
        for(const auto& pair:bank.performances){
            Pa5xPerformanceInspection item;
            try{
                auto b=unpack(pair.second,9);Performances keys;findKeyboards({b.data(),b.size()},keys,path+"!/"+std::to_string(pair.first));
                auto found=keys.find(4);require(found!=keys.end(),"Unsupported Pa performance layout");
                item=std::move(found->second);
            }catch(const FormatError& e){item.error=e.what();}
            item.displayName=pair.second.name;item.filenameOrdinal=pair.first+1;item.sourcePath=path+"!/"+std::to_string(pair.first);
            if(!visit(pair.first,item))return false;
        }
        return true;
    }catch(const std::exception& e){error=e.what();return false;}
}
bool inspectPaStyleBank(const std::string& path,const PaStyleVisitor& visit,std::string& error){
    try{Bank bank(path);for(const auto& item:bank.styles){
        auto read=load(bank,item.second,path+"!/"+std::to_string(item.first),nullptr);
        if(!visit(item.first,item.second.name,read))return false;
    }return true;}catch(const std::exception& e){error=e.what();return false;}
}
Pa5xStyleRead readPaStyleSlot(const std::string& path,const Pa5xSetBank* sounds){
    Pa5xStyleRead out;out.sourcePath=path;
    try{std::string source;int slot;
        require(paStyleSlot(path,&source,&slot),"Invalid Pa Style location");Bank bank(source);
        auto found=bank.styles.find(slot);require(found!=bank.styles.end(),"Missing original Pa Style slot");
        return load(bank,found->second,path,sounds);
    }catch(const std::exception& e){out.error=e.what();return out;}
}
}
