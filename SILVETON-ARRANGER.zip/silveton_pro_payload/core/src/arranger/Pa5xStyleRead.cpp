#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/Pa5xStyleRead.h"
#include "silveton/arranger/KorgResourceContainer.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <map>
#include <set>
#include <utility>

namespace silveton::arranger {
namespace {
constexpr std::size_t maximumStyleBytes = 64U * 1024U * 1024U;

struct ResourceTag { std::string name; std::map<std::string,std::string> attributes; };
bool xmlSpace(char c) { return c==' '||c=='\t'||c=='\r'||c=='\n'; }
bool xmlName(char c) {
    return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c==':'||c=='-'||c=='.';
}
bool xmlUnescape(std::string& value) {
    std::string decoded;
    for(std::size_t p=0;p<value.size();) {
        if(value[p]!='&'){decoded+=value[p++];continue;}
        const auto end=value.find(';',p+1);if(end==std::string::npos)return false;
        const auto entity=value.substr(p,end-p+1);
        if(entity=="&amp;")decoded+='&';else if(entity=="&quot;")decoded+='"';
        else if(entity=="&apos;")decoded+='\'';else if(entity=="&lt;")decoded+='<';
        else if(entity=="&gt;")decoded+='>';else return false;
        p=end+1;
    }
    value=std::move(decoded);return true;
}
bool resourceTags(const std::string& xml,const std::string& wanted,std::vector<ResourceTag>& tags) {
    const auto needle='<'+wanted;std::size_t cursor=0;
    while((cursor=xml.find(needle,cursor))!=std::string::npos) {
        std::size_t p=cursor+needle.size();
        if(p>=xml.size())return false;
        if(!xmlSpace(xml[p])&&xml[p]!='/'&&xml[p]!='>'){cursor=p;continue;}
        ResourceTag tag;tag.name=wanted;bool closed=false;
        while(p<xml.size()) {
            while(p<xml.size()&&xmlSpace(xml[p]))++p;
            if(p==xml.size())return false;
            if(xml[p]=='>'){++p;closed=true;break;}
            if(xml[p]=='/') {if(p+1>=xml.size()||xml[p+1]!='>')return false;p+=2;closed=true;break;}
            const auto keyStart=p;while(p<xml.size()&&xmlName(xml[p]))++p;
            if(p==keyStart)return false;
            const auto key=xml.substr(keyStart,p-keyStart);
            while(p<xml.size()&&xmlSpace(xml[p]))++p;
            if(p==xml.size()||xml[p++]!='=')return false;
            while(p<xml.size()&&xmlSpace(xml[p]))++p;
            if(p==xml.size()||(xml[p]!='"'&&xml[p]!='\''))return false;
            const auto quote=xml[p++];const auto start=p;
            while(p<xml.size()&&xml[p]!=quote)++p;
            if(p==xml.size())return false;
            auto value=xml.substr(start,p-start);++p;
            if(!xmlUnescape(value)||!tag.attributes.emplace(key,std::move(value)).second)return false;
        }
        if(!closed)return false;
        tags.push_back(std::move(tag));cursor=p;
    }
    return true;
}
std::string resourceAttribute(const ResourceTag& tag,const std::string& name) {
    const auto found=tag.attributes.find(name);return found==tag.attributes.end()?std::string{}:found->second;
}
int resourceNumber(const ResourceTag& tag,const std::string& name,int fallback=-1) {
    const auto value=resourceAttribute(tag,name);if(value.empty())return fallback;
    int number=0;
    for(const auto c:value) {
        if(c<'0'||c>'9'||number>(std::numeric_limits<int>::max()-(c-'0'))/10)return fallback;
        number=number*10+c-'0';
    }
    return number;
}
bool resourceComponent(const std::string& name) {
    return !name.empty()&&name!="."&&name!=".."&&name.find_first_of("/\\\0",0,3)==std::string::npos;
}

struct EmbeddedKeyboardReader {
    const std::vector<std::uint8_t>& bytes;
    Pa5xStyleRead& out;
    const Pa5xSetBank* bank;
    std::map<std::string,const KorgResourceLeaf*> leaves;
    std::string error;
    bool fail(const std::string& message) { error=message;return false; }
    bool xml(const std::string& path,std::string& text) {
        const auto found=leaves.find(path);
        if(found==leaves.end())return fail("Missing original Keyboard Set descriptor: "+path);
        text=korgResourceText(bytes,*found->second);
        return (!text.empty()&&text.find('\0')==std::string::npos&&text.find("<!")==std::string::npos)||
            fail("Unsupported original Keyboard Set XML: "+path);
    }
    bool one(const std::string& text,const std::string& name,ResourceTag& tag) {
        std::vector<ResourceTag> tags;
        if(!resourceTags(text,name,tags)||tags.size()!=1)return fail("Missing or ambiguous original XML element: "+name);
        tag=std::move(tags.front());return true;
    }
    // The validated container guarantees boundaries here. Copy only the named
    // Branch body, preserving every original XML/MIDI leaf and its ordering.
    bool branch(std::size_t begin,std::size_t end,const std::vector<std::string>& path,
                std::size_t depth,std::vector<std::uint8_t>& standalone) {
        for(std::size_t p=begin;p<end;) {
            const auto kindStart=p;while(p<end&&bytes[p])++p;
            const std::string kind(reinterpret_cast<const char*>(bytes.data()+kindStart),p-kindStart);++p;
            const auto nameStart=p;while(p<end&&bytes[p])++p;
            const std::string name(reinterpret_cast<const char*>(bytes.data()+nameStart),p-nameStart);++p;
            std::uint32_t length=0;for(unsigned n=0;n<4;++n)length=(length<<8U)|bytes[p++];
            if(kind=="Branch"&&name==path[depth]) {
                if(depth+1<path.size())return branch(p,p+length,path,depth+1,standalone);
                standalone={'R','o','o','t',0,1,0,
                    static_cast<std::uint8_t>(length>>24U),static_cast<std::uint8_t>(length>>16U),
                    static_cast<std::uint8_t>(length>>8U),static_cast<std::uint8_t>(length)};
                standalone.insert(standalone.end(),bytes.begin()+static_cast<std::ptrdiff_t>(p),
                    bytes.begin()+static_cast<std::ptrdiff_t>(p+length));return true;
            }
            p+=length;
        }
        return false;
    }
    void read(Pa5xStyleKeyboardSetRead& slot) {
        std::vector<std::string> path;std::size_t p=0;
        while(p<slot.resourcePath.size()) {
            const auto end=slot.resourcePath.find('/',p);
            path.push_back(slot.resourcePath.substr(p,end==std::string::npos?end:end-p));
            if(end==std::string::npos)break;
            p=end+1;
        }
        auto resource=std::make_shared<std::vector<std::uint8_t>>();
        if(path.empty()||!branch(11,bytes.size(),path,0,*resource)) {
            slot.error="The declared original Keyboard Set branch is absent: "+slot.resourcePath;return;
        }
        slot.resourceBytes=resource;
        const auto identity=out.sourcePath+"!/"+slot.resourcePath;
        auto keyboard=std::make_shared<Pa5xKeyboardSetRead>(readPa5xKeyboardSetBytes(*resource,identity,bank));
        slot.name=keyboard->name;slot.available=keyboard->valid;slot.error=keyboard->error;
        slot.keyboardSet=std::move(keyboard);
    }
    bool inspect(const KorgResourceContainer& tree) {
        for(const auto& leaf:tree.leaves) {
            for(const auto& component:leaf.path)if(!resourceComponent(component))return fail("Ambiguous original internal resource path");
            if(!leaves.emplace(korgResourcePath(leaf.path),&leaf).second)return fail("Duplicate original internal resource path");
        }
        std::string stageXml;ResourceTag stage,stageResource;
        if(!xml("StageDescription.xml",stageXml)||!one(stageXml,"STAGE",stage)||!one(stageXml,"RESOURCE",stageResource))return false;
        const auto main=resourceAttribute(stageResource,"mainsessionname");
        if(!resourceComponent(main))return fail("Invalid original main-session reference");
        std::string sessionXml;ResourceTag session;
        if(!xml(main+"/SessionDescription.xml",sessionXml)||!one(sessionXml,"SESSION",session))return false;
        std::vector<ResourceTag> scenes;
        if(!resourceTags(sessionXml,"RESOURCE",scenes))return fail("Invalid original main-session scenes");
        std::map<int,std::string> scenePaths;std::string styleScene;
        for(const auto& scene:scenes) {
            const auto name=resourceAttribute(scene,"name");const auto number=resourceNumber(scene,"scenenum");
            if(number<1||!resourceComponent(name)||!scenePaths.emplace(number,main+'/'+name).second)
                return fail("Ambiguous original main-session scene reference");
            std::string sceneXml;if(!xml(main+'/'+name+"/SceneDescription.xml",sceneXml))return false;
            std::vector<ResourceTag> resources;
            if(!resourceTags(sceneXml,"RESOURCE",resources))return fail("Invalid original scene resource list");
            for(const auto& resource:resources)if(resourceAttribute(resource,"type")=="StyleClip") {
                if(!styleScene.empty())return fail("Multiple original Style scene bindings");
                styleScene=main+'/'+name;
            }
        }
        if(styleScene.empty())return fail("The original Style scene binding is missing");
        const auto stageVersion=resourceNumber(stage,"version"),stageRelease=resourceNumber(stage,"release");
        if(resourceNumber(stage,"type")!=1)return fail("Unsupported original Stage type for Keyboard Set mapping");
        if(stageVersion==1&&stageRelease==2&&resourceNumber(session,"maxscenes")==71&&resourceNumber(session,"maxtracks")==28) {
            // This is the original v1r2 topology observed in the user's STGs.
            // Custom scene labels are allowed; numbers25..28 bind the slots.
            out.keyboardSetMappingKnown=true;
            for(std::size_t i=0;i<out.keyboardSets.size();++i) {
                auto& slot=out.keyboardSets[i];slot.originalSceneNumber=static_cast<int>(25+i);slot.originalTrack=21;
                const auto scene=scenePaths.find(slot.originalSceneNumber);
                if(scene==scenePaths.end()){slot.error="Original Keyboard Set scene is not declared";continue;}
                std::string sceneXml;if(!xml(scene->second+"/SceneDescription.xml",sceneXml))return false;
                std::vector<ResourceTag> resources;if(!resourceTags(sceneXml,"RESOURCE",resources))return fail("Invalid original Keyboard Set scene");
                std::vector<ResourceTag> keyboards;
                for(const auto& resource:resources)if(resourceAttribute(resource,"type")=="KeyboardSetClip")keyboards.push_back(resource);
                if(keyboards.size()!=1||resourceNumber(keyboards.front(),"track")!=21)
                    return fail("Ambiguous original Keyboard Set scene/track binding");
                const auto name=resourceAttribute(keyboards.front(),"name");
                if(!resourceComponent(name))return fail("Invalid original Keyboard Set resource name");
                slot.declared=true;slot.resourcePath=scene->second+'/'+name;
            }
        } else if(stageVersion==2&&stageRelease==0&&resourceNumber(session,"version")==1&&
                  resourceNumber(session,"release")==0&&resourceNumber(session,"maxtracks")==28) {
            std::string sceneXml;if(!xml(styleScene+"/SceneDescription.xml",sceneXml))return false;
            std::vector<ResourceTag> resources;if(!resourceTags(sceneXml,"RESOURCE",resources))return fail("Invalid original Style scene");
            std::vector<ResourceTag> arrays;
            for(const auto& resource:resources)if(resourceAttribute(resource,"type")=="KeybSetArray")arrays.push_back(resource);
            if(arrays.size()!=1||resourceNumber(arrays.front(),"track")!=21)return fail("Missing or ambiguous original Keyboard Set array binding");
            const auto name=resourceAttribute(arrays.front(),"name");
            if(!resourceComponent(name))return fail("Invalid original Keyboard Set array name");
            const auto arrayPath=styleScene+'/'+name;std::string arrayXml;ResourceTag clip,arrayResource;
            if(!xml(arrayPath+"/ClipDescription.xml",arrayXml)||!one(arrayXml,"CLIP",clip)||!one(arrayXml,"RESOURCE",arrayResource))return false;
            if(resourceAttribute(clip,"type")!="KeybSetArray"||resourceNumber(clip,"subtype")!=4||
               resourceNumber(clip,"version")!=0||resourceNumber(clip,"release")!=1)
                return fail("Unsupported original Keyboard Set array revision");
            out.keyboardSetMappingKnown=true;
            for(std::size_t i=0;i<out.keyboardSets.size();++i) {
                auto& slot=out.keyboardSets[i];const auto suffix=std::to_string(i+1);
                const auto keyboardName=resourceAttribute(arrayResource,"c"+suffix);
                if(!resourceComponent(keyboardName))return fail("Missing or invalid original Keyboard Set array position"+suffix);
                slot.declared=true;slot.originalTrack=21;
                for(const auto& scene:scenePaths)if(scene.second==styleScene)slot.originalSceneNumber=scene.first;
                slot.resourcePath=arrayPath+"/ks"+suffix+'/'+keyboardName;
            }
        } else return fail("Original Keyboard Set positions use an unsupported Stage/session revision");
        for(auto& slot:out.keyboardSets)if(slot.declared)read(slot);
        return true;
    }
};

struct ChannelState {
    int pendingMsb{-1}, pendingLsb{-1};
    int msb{-1}, lsb{-1}, program{-1};
    std::uint32_t programTick{0};
    bool programDeclared{false};
};

bool bankProgramEvent(const KorgMidiChannelEvent& event) noexcept {
    const auto kind = event.status & 0xF0U;
    return kind == 0xC0U || (kind == 0xB0U && (event.data1 == 0 || event.data1 == 32));
}

bool apply(ChannelState& state, const KorgMidiChannelEvent& event) noexcept {
    const auto kind = event.status & 0xF0U;
    if (kind == 0xB0U && event.data1 == 0) state.pendingMsb = event.data2;
    else if (kind == 0xB0U && event.data1 == 32) state.pendingLsb = event.data2;
    else if (kind == 0xC0U) {
        state.msb = state.pendingMsb; state.lsb = state.pendingLsb;
        state.program = event.data1; state.programTick = event.tick;
        state.programDeclared = true;
        return true;
    }
    return false;
}

Pa5xStyleSoundChange selection(const ChannelState& state, std::uint8_t channel,
    std::uint32_t tick, std::uint32_t originalTick, std::uint64_t order,
    bool setup, const Pa5xSetBank& bank) {
    Pa5xStyleSoundChange result;
    result.tick = tick; result.originalTick = originalTick; result.order = order;
    result.channel = channel; result.fromSetup = setup;
    result.msb = state.programDeclared ? state.msb : state.pendingMsb;
    result.lsb = state.programDeclared ? state.lsb : state.pendingLsb;
    result.program = state.program;
    result.sound = bank.resolveSoundAddress(result.msb, result.lsb, result.program);
    return result;
}

void warn(Pa5xStyleRead& result, const std::string& message) {
    if (std::find(result.warnings.begin(), result.warnings.end(), message) == result.warnings.end())
        result.warnings.push_back(message);
}

bool setupBoundary(const KorgStyleClip& source, std::uint32_t& tick) noexcept {
    if (source.midiTracks.size() < 2 || source.midiTracks.size() > 7 || source.ppq == 0) return false;
    const auto& setup = source.midiTracks[0];
    const std::uint64_t measure = static_cast<std::uint64_t>(source.ppq) * 4U * setup.numerator;
    if (!setup.hasEnd || setup.notes || !setup.meterKnown || setup.meterChanged ||
        setup.denominator == 0 || measure % setup.denominator != 0 || setup.endTick == 0 ||
        setup.endTick != measure / setup.denominator) return false;
    for (std::size_t i = 1; i < source.midiTracks.size(); ++i) {
        const auto& cv = source.midiTracks[i];
        const bool absent = cv.endTick == 0 && !cv.notes &&
            cv.firstChannelTick == std::numeric_limits<std::uint32_t>::max();
        if (!cv.hasEnd || (!absent && (cv.endTick < setup.endTick || cv.firstChannelTick < setup.endTick))) return false;
    }
    // A CV may declare a later FF58 meter change. Its physical track identity
    // and absolute start boundary are still readable, even when the constant-
    // meter native playback adapter cannot publish that CV.
    tick = setup.endTick; return true;
}

void readTrack(Pa5xStyleRead& result, Pa5xStyleReadTrack& track,
               const KorgStyleClip& source, const Pa5xSetBank& bank) {
    track.present = true; track.track = source.track;
    track.path = source.path; track.patternType = source.patternType;
    track.sourceEffects = source.sourceEffects;
    track.ppq = source.ppq;
    track.setupTimingKnown = setupBoundary(source, track.setupTicks);
    for (std::size_t i = 0; i < track.cvs.size(); ++i) track.cvs[i].number = static_cast<int>(i + 1U);
    for (const auto& chord : source.cvSources) if (chord.number >= 1 && chord.number <= 6) {
        auto& cv = track.cvs[static_cast<std::size_t>(chord.number - 1)];
        cv.sourceRoot = chord.root; cv.sourceChord = chord.chord;
    }
    if (!track.setupTimingKnown) {
        for (const auto& event : source.channelEvents)
            if (bankProgramEvent(event)) track.unscopedBankProgramEvents.push_back(event);
        track.unscopedTempoChanges = source.tempos;
        track.unscopedTimeSignatureChanges = source.timeSignatures;
        warn(result, "A clip's physical setup/CV mapping is unproven; its original Sound declarations remain unscoped: " + source.path);
        return;
    }

    std::array<ChannelState, 16> setup{};
    for (const auto& event : source.channelEvents) if (event.track == 0) {
        const auto channel = static_cast<std::uint8_t>(event.status & 15U);
        if (bankProgramEvent(event)) track.setupBankProgramEvents.push_back(event);
        auto& state = setup[channel];
        if (apply(state, event)) track.setupSoundChanges.push_back(selection(
            state, channel, event.tick, event.tick, event.order, true, bank));
    }
    for (const auto& tempo : source.tempos) if (tempo.track == 0)
        track.setupTempoChanges.push_back({tempo.tick, tempo.tick, tempo.microsecondsPerQuarter,
                                          60000000.0 / tempo.microsecondsPerQuarter});
    for (const auto& meter : source.timeSignatures) if (meter.track == 0)
        track.setupTimeSignatureChanges.push_back({meter.tick, meter.tick, meter.numerator, meter.denominator});

    for (std::size_t number = 1; number <= track.cvs.size(); ++number) {
        auto& cv = track.cvs[number - 1U];
        if (number >= source.midiTracks.size() || source.midiTracks[number].endTick == 0) continue;
        const auto& physical = source.midiTracks[number];
        cv.available = true; cv.hasNotes = physical.notes;
        if (physical.endTick <= track.setupTicks) {
            warn(result, "A CV has no positive proven duration: " + source.path);
            continue;
        }
        cv.timingKnown = true; cv.lengthTicks = physical.endTick - track.setupTicks;
        // Physical tracks are alternative CVs, not simultaneous MIDI lanes.
        // Never let a Program Change in CV1 become CV2's initial Sound.
        auto channels = setup;
        std::array<bool, 16> used{};
        for (std::size_t channel = 0; channel < used.size(); ++channel)
            used[channel] = setup[channel].programDeclared;
        for (const auto& event : source.channelEvents) if (event.track == number)
            used[event.status & 15U] = true;
        for (std::size_t channel = 0; channel < used.size(); ++channel) if (used[channel])
            cv.soundChanges.push_back(selection(channels[channel], static_cast<std::uint8_t>(channel),
                0, channels[channel].programTick, 0, true, bank));

        for (const auto& event : source.channelEvents) if (event.track == number) {
            if (event.tick < track.setupTicks || event.tick > physical.endTick) {
                warn(result, "A CV event is outside its proven performance interval: " + source.path);
                continue;
            }
            const auto channel = static_cast<std::uint8_t>(event.status & 15U);
            auto& state = channels[channel];
            if (bankProgramEvent(event)) cv.bankProgramEvents.push_back(event);
            if (apply(state, event)) {
                cv.soundChanges.push_back(selection(state, channel, event.tick - track.setupTicks,
                    event.tick, event.order, false, bank));
            } else if ((event.status & 0xF0U) == 0x90U && event.data2 > 0 && !state.programDeclared) {
                // Retain partial bank declarations for notes whose Program was
                // never specified; an absent Program does not become GM zero.
                const auto* prior = cv.soundAt(channel, event.tick - track.setupTicks, event.order);
                if (prior == nullptr || prior->msb != state.pendingMsb || prior->lsb != state.pendingLsb)
                    cv.soundChanges.push_back(selection(state, channel, event.tick - track.setupTicks,
                        event.tick, event.order, false, bank));
            }
        }
        for (const auto& tempo : source.tempos) if (tempo.track == number &&
            tempo.tick >= track.setupTicks && tempo.tick <= physical.endTick)
            cv.tempoChanges.push_back({tempo.tick - track.setupTicks, tempo.tick,
                                      tempo.microsecondsPerQuarter, 60000000.0 / tempo.microsecondsPerQuarter});
        for (const auto& meter : source.timeSignatures) if (meter.track == number &&
            meter.tick >= track.setupTicks && meter.tick <= physical.endTick)
            cv.timeSignatureChanges.push_back({meter.tick - track.setupTicks, meter.tick,
                                              meter.numerator, meter.denominator});
        std::stable_sort(cv.soundChanges.begin(), cv.soundChanges.end(), [](const auto& a, const auto& b) {
            return a.tick < b.tick || (a.tick == b.tick && a.order < b.order);
        });
    }
}
} // namespace

const Pa5xStyleSoundChange* Pa5xStyleReadCv::soundAt(std::uint8_t channel,
    std::uint32_t tick, std::uint64_t order) const noexcept {
    const Pa5xStyleSoundChange* found = nullptr;
    for (const auto& change : soundChanges) {
        if (change.channel != channel || change.tick > tick || (change.tick == tick && change.order > order)) continue;
        if (found == nullptr || change.tick > found->tick ||
            (change.tick == found->tick && change.order >= found->order)) found = &change;
    }
    return found;
}

Pa5xStyleRead readPa5xStyleBytes(const std::vector<std::uint8_t>& bytes,
    const std::string& path, const Pa5xSetBank* bank) {
    Pa5xStyleRead result; result.sourcePath = path;
    for(std::size_t i=0;i<result.keyboardSets.size();++i)result.keyboardSets[i].position=static_cast<int>(i+1);
    auto source = std::make_shared<KorgStyleInspection>(inspectKorgStyleBytes(bytes));
    result.recognized = source->recognized; result.name = source->name;
    result.originalMuteRaw = source->originalMuteRaw;
    result.originalBpm = source->tempoBpm; result.inspection = source;
    result.sourceEffects = source->sourceEffects;
    for(const auto& warning:source->warnings)warn(result,warning);
    if (!source->valid) { result.error = source->error; return result; }
    if (!std::isfinite(result.originalBpm) || result.originalBpm <= 0) {
        result.error = "Original Style tempo is missing or invalid"; return result;
    }
    Pa5xSetBank emptyBank; const auto& resolver = bank != nullptr ? *bank : emptyBank;
    std::uint16_t commonPpq = 0; bool mixedPpq = false;
    for (const auto& element : source->elements) {
        const auto index = static_cast<std::size_t>(element.element);
        if (index >= result.sections.size()) { result.error = "An original Style Element has no known identity"; return result; }
        auto& section = result.sections[index]; section.available = true;
        section.numerator = element.numerator; section.denominator = element.denominator;
        section.meterKnown = element.numerator > 0 && element.denominator > 0;
        for (const auto& clip : element.clips) {
            if (clip.track < 0 || clip.track >= kTracks) { result.error = "An original Style clip has no known logical track"; return result; }
            auto& track = section.tracks[static_cast<std::size_t>(clip.track)];
            if (track.present) { result.error = "Multiple original clips claim the same Style Element/track"; return result; }
            readTrack(result, track, clip, resolver);
            if (commonPpq == 0) commonPpq = clip.ppq;
            else mixedPpq = mixedPpq || commonPpq != clip.ppq;
        }
    }
    result.ppq = mixedPpq ? 0 : commonPpq;
    if (mixedPpq) warn(result, "Original clip PPQs differ; each track retains its own original tick timebase");
    const auto native = importKorgStyleInspection(*source); result.nativeStyle = native.style;
    if (!native) warn(result, "Native playback graph unavailable; original reading remains separate: " + native.error);
    const auto tree=inspectKorgResourceContainer(bytes,maximumStyleBytes);
    if(tree.valid) {
        EmbeddedKeyboardReader keyboard{bytes,result,bank,{},{}};
        if(!keyboard.inspect(tree)) {
            result.keyboardSetMappingKnown=false;
            for(auto& slot:result.keyboardSets) {
                slot.available=false;slot.keyboardSet.reset();slot.resourceBytes.reset();
                if(slot.error.empty())slot.error=keyboard.error;
            }
            warn(result,"Original Style Keyboard Sets unavailable: "+keyboard.error);
        } else for(const auto& slot:result.keyboardSets)if(!slot.available)
            warn(result,"Original Style Keyboard Set "+std::to_string(slot.position)+": "+slot.error);
    }
    result.valid = true;
    return result;
}

Pa5xStyleRead readPa5xStyleFile(const std::string& path, const Pa5xSetBank* bank) {
    if(paStyleSlot(path))return readPaStyleSlot(path,bank);
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    Pa5xStyleRead failed; failed.sourcePath = path;
    if (!file) { failed.error = "Cannot open the original Style file"; return failed; }
    const auto size = file.tellg();
    if (size <= 0 || size > static_cast<std::streamoff>(maximumStyleBytes)) {
        failed.error = "Original Style file is empty or exceeds the 64 MiB reading limit"; return failed;
    }
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size)); file.seekg(0);
    if (!file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()))) {
        failed.error = "Cannot read the original Style file"; return failed;
    }
    return readPa5xStyleBytes(bytes, path, bank);
}
} // namespace silveton::arranger
