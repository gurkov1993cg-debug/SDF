#include "silveton/arranger/KorgSourceEffects.h"

#include <algorithm>

namespace silveton::arranger {
namespace {
bool contextValid(const KorgSourceFxContext& value) noexcept {
    if(value.resourcePath.size()>4096U||value.resourcePath.find('\0')!=std::string::npos)return false;
    switch(value.scope){
        case KorgSourceFxScope::KeyboardMaster:
        case KorgSourceFxScope::StyleMaster:return value.logicalPart==-1&&value.element==-1;
        case KorgSourceFxScope::KeyboardPart:return value.logicalPart>=0&&value.logicalPart<4&&value.element==-1;
        case KorgSourceFxScope::StyleTrack:return value.logicalPart>=0&&value.logicalPart<8&&value.element>=0&&value.element<15;
    }
    return false;
}
bool fxFamily(const std::vector<std::uint8_t>& p) noexcept {
    return p.size()>=5&&p[0]==0x42U&&p[1]==0x7FU&&p[2]==0x78U&&p[3]==0x02U;
}
bool decode(const std::uint8_t* p,std::size_t length,KorgSourceFxDefinition& out) noexcept {
    if(length!=87U||p[0]!=0x42U||p[1]!=0x7FU||p[2]!=0x78U||p[3]!=0x02U||
       (p[4]!=0x10U&&p[4]!=0x20U)||p[6]>2U||p[86]!=0xF7U)return false;
    for(std::size_t i=0;i<86;++i)if(p[i]>127U)return false;
    // The last pack group has only one data byte: all unused mask bits must
    // be clear. Treat noncanonical future layouts as opaque, not as this one.
    if((p[84]&0x3FU)!=0)return false;
    out.kind=p[4]==0x10U?KorgSourceFxKind::Master:KorgSourceFxKind::Insert;
    out.ownerRaw=p[5];out.slotRaw=p[6];out.selector=static_cast<std::uint16_t>(p[10]*128U+p[11]);
    std::copy_n(p+7,3,out.controlsRaw.begin());std::copy_n(p,87,out.payload.begin());
    std::size_t output=0;
    for(std::size_t at=12;at<86;at+=8){
        const auto count=std::min<std::size_t>(7,85-at);
        for(std::size_t i=0;i<count;++i)
            out.parameters[output++]=static_cast<std::uint8_t>(p[at+1+i]|(((p[at]>>(6U-i))&1U)<<7U));
    }
    return output==out.parameters.size();
}
bool decodePrf(KorgSourceFxEncoding encoding,const std::vector<std::uint8_t>& raw,KorgSourceFxDefinition& out) noexcept {
    const bool older=encoding==KorgSourceFxEncoding::LegacyPrf78;
    if((!older&&encoding!=KorgSourceFxEncoding::Prf73)||raw.size()!=(older?78U:73U)||
       raw[0]!=0||raw[1]!=0||raw[2]!=0||raw[3]>3)return false;
    out.encoding=encoding;out.slotRaw=raw[3];
    // Only master slots0/1 have an established owner/slot correspondence.
    // Legacy slots2/3 may contain inserts; their destination is still opaque.
    out.kind=out.slotRaw<2?KorgSourceFxKind::Master:KorgSourceFxKind::Unscoped;
    out.ownerRaw=out.slotRaw<2?1U:255U;out.controlsKnownMask=out.slotRaw<2?3U:0U;
    if(out.slotRaw<2){out.controlsRaw[0]=raw[older?6U:4U];out.controlsRaw[1]=raw[older?11U:72U];}
    const std::size_t selector=older?12U:5U,parameters=older?14U:7U;
    out.selector=static_cast<std::uint16_t>(static_cast<unsigned>(raw[selector])*256U+raw[selector+1]);
    std::copy_n(raw.begin()+static_cast<std::ptrdiff_t>(parameters),64,out.parameters.begin());
    return true;
}
template<class Event> bool ordered(const std::vector<Event>& events) noexcept {
    for(std::size_t i=1;i<events.size();++i)
        if(events[i].tick<events[i-1].tick||(events[i].tick==events[i-1].tick&&events[i].order<events[i-1].order))return false;
    return true;
}
template<class Event> void sortEvents(std::vector<Event>& events) {
    std::stable_sort(events.begin(),events.end(),[](const auto& a,const auto& b){
        return a.tick<b.tick||(a.tick==b.tick&&a.order<b.order);
    });
}
void fail(KorgSourceEffects& out,const std::string& why) {
    out.complete=false;if(out.error.empty())out.error=why.substr(0,4096U);
    std::replace(out.error.begin(),out.error.end(),'\0',' ');
}
} // namespace

bool KorgSourceEffects::valid() const noexcept {
    if(!contextValid(*this)||error.size()>4096U||error.find('\0')!=std::string::npos||
       (complete&&(malformedFxMessages!=0||!error.empty()))||
       definitions.size()>kMaximumKorgSourceFxDefinitions||sends.size()>kMaximumKorgSourceFxSends||
       unknownMessages.size()>kMaximumKorgSourceFxOpaqueEvents||
       !ordered(definitions)||!ordered(sends)||!ordered(unknownMessages))return false;
    for(const auto& value:definitions){
        if(value.physicalTrack>255)return false;
        KorgSourceFxDefinition decoded;
        const bool midi=value.encoding==KorgSourceFxEncoding::Pa5xSysEx87;
        if(midi?!value.originalRecord.empty():std::any_of(value.payload.begin(),value.payload.end(),[](auto b){return b!=0;}))return false;
        if(!(midi?decode(value.payload.data(),value.payload.size(),decoded):decodePrf(value.encoding,value.originalRecord,decoded))||decoded.kind!=value.kind||
           decoded.ownerRaw!=value.ownerRaw||decoded.slotRaw!=value.slotRaw||decoded.selector!=value.selector||
           decoded.controlsKnownMask!=value.controlsKnownMask||decoded.controlsRaw!=value.controlsRaw||decoded.parameters!=value.parameters)return false;
    }
    for(const auto& send:sends)if(send.physicalTrack>255||send.channel>15||send.slot>2||send.value>127)return false;
    std::size_t bytes=0;
    for(const auto& message:unknownMessages){
        if(message.track>255||(message.status!=0xF0U&&message.status!=0xF7U&&
           !(message.status==0xFFU&&message.metaType==0x7FU)))return false;
        if(message.payload.size()>kMaximumKorgSourceFxOpaqueBytes-bytes)return false;
        bytes+=message.payload.size();
    }
    return true;
}

std::shared_ptr<const KorgSourceEffects> unavailableKorgSourceEffects(
        const KorgSourceFxContext& context,const std::string& error) {
    auto out=std::make_shared<KorgSourceEffects>();static_cast<KorgSourceFxContext&>(*out)=context;
    fail(*out,error.empty()?"Original effect resource is unavailable":error);return out;
}

std::shared_ptr<const KorgSourceEffects> makeKorgSourceEffects(
        const KorgSourceFxContext& context,const std::vector<KorgMidiChannelEvent>& channels,
        const std::vector<KorgMidiOpaqueEvent>& opaque) {
    auto out=std::make_shared<KorgSourceEffects>();static_cast<KorgSourceFxContext&>(*out)=context;
    if(!contextValid(context)){fail(*out,"Invalid original effect resource context");return out;}
    for(const auto& event:channels){
        if((event.status&0xF0U)!=0xB0U)continue;
        const int slot=event.data1==91?0:event.data1==93?1:event.data1==94?2:-1;
        if(slot<0)continue;
        if(out->sends.size()>=kMaximumKorgSourceFxSends){fail(*out,"Original effect sends exceed the bounded event limit");break;}
        if(event.data2>127){fail(*out,"Invalid original effect-send value");continue;}
        out->sends.push_back({event.tick,event.track,event.order,static_cast<std::uint8_t>(event.status&15U),
            static_cast<std::uint8_t>(slot),event.data2});
    }
    std::size_t opaqueBytes=0;
    for(const auto& event:opaque){
        const bool family=fxFamily(event.payload);
        const bool effect=family&&(event.payload[4]==0x10U||event.payload[4]==0x20U);
        KorgSourceFxDefinition definition;
        if(effect&&event.status==0xF0U&&decode(event.payload.data(),event.payload.size(),definition)){
            if(out->definitions.size()>=kMaximumKorgSourceFxDefinitions){fail(*out,"Original effects exceed the bounded definition limit");break;}
            definition.tick=event.tick;definition.physicalTrack=event.track;definition.order=event.order;
            out->definitions.push_back(std::move(definition));continue;
        }
        if(effect){++out->malformedFxMessages;fail(*out,"An original effect message has an unsupported or malformed layout");}
        else if(family)++out->unrecognizedFxMessages;
        if(out->unknownMessages.size()>=kMaximumKorgSourceFxOpaqueEvents||
           event.payload.size()>kMaximumKorgSourceFxOpaqueBytes-opaqueBytes){
            fail(*out,"Original opaque effect data exceeds its bounded retention limit");break;
        }
        out->unknownMessages.push_back(event);opaqueBytes+=event.payload.size();
    }
    sortEvents(out->definitions);sortEvents(out->sends);sortEvents(out->unknownMessages);
    return out;
}

std::shared_ptr<const KorgSourceEffects> makeKorgPrfSourceEffects(
        const KorgSourceFxContext& context,const std::vector<KorgSourceFxRawRecord>& records) {
    auto out=std::make_shared<KorgSourceEffects>();static_cast<KorgSourceFxContext&>(*out)=context;
    if(!contextValid(context)){fail(*out,"Invalid original PRF effect context");return out;}
    if(records.size()>kMaximumKorgSourceFxDefinitions)fail(*out,"Original PRF effects exceed the bounded definition limit");
    for(const auto& record:records){
        if(out->definitions.size()>=kMaximumKorgSourceFxDefinitions){fail(*out,"Original PRF effects exceed the bounded definition limit");break;}
        KorgSourceFxDefinition definition;
        const auto encoding=record.tag==0x07000008U?KorgSourceFxEncoding::LegacyPrf78:KorgSourceFxEncoding::Prf73;
        if((record.tag!=0x07000008U&&record.tag!=0x1D000008U)||!decodePrf(encoding,record.bytes,definition)){
            ++out->malformedFxMessages;fail(*out,"An original PRF effect record has an unsupported layout");continue;
        }
        definition.originalRecord=record.bytes;definition.order=record.order;
        if(definition.kind==KorgSourceFxKind::Unscoped)++out->unrecognizedFxMessages;
        out->definitions.push_back(std::move(definition));
    }
    sortEvents(out->definitions);return out;
}
} // namespace silveton::arranger
