#include "silveton/arranger/Pa5xStyleSourceSettings.h"
#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xStyleRead.h"

#include <algorithm>
#include <array>

namespace silveton::arranger {
namespace {
bool addressField(int value) noexcept {return value>=-1&&value<=127;}
bool sameAddress(const Pa5xStyleSourceSound& a,int msb,int lsb,int program) noexcept {
    return a.msb==msb&&a.lsb==lsb&&a.program==program;
}
struct SoundSlot {Pa5xStyleSourceSound value;bool seen{false};};
using SoundScopes=std::array<std::array<SoundSlot,16>,7>;
void selection(SoundSlot& slot,int msb,int lsb,int program,bool initial) {
    if(initial){slot.value.msb=msb;slot.value.lsb=lsb;slot.value.program=program;}
    else if(!sameAddress(slot.value,msb,lsb,program))slot.value.varies=true;
    slot.seen=true;
}
void collectSounds(Pa5xStyleSourceTrack& target,const SoundScopes& scopes) {
    for(std::size_t cv=0;cv<scopes.size();++cv)for(std::size_t channel=0;channel<scopes[cv].size();++channel){
        if(!scopes[cv][channel].seen)continue;
        auto value=scopes[cv][channel].value;value.cv=static_cast<int>(cv);value.channel=static_cast<int>(channel);
        target.sounds.push_back(value);
    }
}
void soundsFromClip(Pa5xStyleSourceTrack& target,const KorgStyleClip& clip) {
    if(!clip.setupTimingKnown)return;
    SoundScopes scopes{};
    // Setup is a pre-roll: its final committed Program is the initial Sound.
    for(const auto& patch:clip.patchSelections)if(patch.track==0&&patch.channel<16)
        selection(scopes[0][patch.channel],patch.msb,patch.lsb,patch.program,true);
    for(std::size_t cv=1;cv<scopes.size()&&cv<clip.midiTracks.size();++cv){
        if(clip.midiTracks[cv].endTick<=clip.setupTicks)continue;
        scopes[cv]=scopes[0];
        for(const auto& patch:clip.patchSelections)if(patch.track==cv&&patch.channel<16)
            selection(scopes[cv][patch.channel],patch.msb,patch.lsb,patch.program,patch.tick<=clip.setupTicks);
    }
    collectSounds(target,scopes);
}
void soundsFromPattern(Pa5xStyleSourceTrack& target,const TrackPattern& pattern) {
    struct PendingBank {int msb{-1},lsb{-1};};
    using Banks=std::array<PendingBank,16>;
    Banks setupBanks{};SoundScopes scopes{};
    const auto observe=[](const MidiEvent& event,Banks& banks,std::array<SoundSlot,16>& selections,bool setup){
        const auto channel=static_cast<std::size_t>(event.status&15U);auto& bank=banks[channel];
        const auto type=event.status&0xF0U;
        if(type==0xB0U&&event.data1==0)bank.msb=event.data2;
        else if(type==0xB0U&&event.data1==32)bank.lsb=event.data2;
        else if(type==0xC0U)selection(selections[channel],bank.msb,bank.lsb,event.data1,setup||event.tick==0);
    };
    for(const auto& event:pattern.setupEvents)observe(event,setupBanks,scopes[0],true);
    for(std::size_t cv=0;cv<pattern.cvs.size();++cv){
        if(!pattern.cvs[cv].available)continue;
        auto banks=setupBanks;scopes[cv+1]=scopes[0];
        for(const auto& event:pattern.cvs[cv].events)observe(event,banks,scopes[cv+1],false);
    }
    collectSounds(target,scopes);
}
void nativeFields(Pa5xStyleSourceTrack& target,const Style* native) {
    if(!native||target.element<0||target.element>=static_cast<int>(kElementCount)||target.track<0||target.track>=kTracks)return;
    const auto& section=native->sections[static_cast<std::size_t>(target.element)];
    const auto& pattern=section.patterns[static_cast<std::size_t>(target.track)];
    target.nativeMode=pattern.mode;
    target.available=section.available&&section.nativePatterns&&pattern.present&&
        pattern.mode!=NativePatternMode::Unsupported&&
        std::any_of(pattern.cvs.begin(),pattern.cvs.end(),[](const auto& cv){return cv.available;});
}
void sourceMutes(Pa5xStyleSourceSettings& target,const std::array<int,kTracks>& raw) {
    for(std::size_t track=0;track<raw.size();++track)if(raw[track]==0||raw[track]==1){
        const auto bit=static_cast<std::uint8_t>(1U<<track);
        target.muteKnownMask=static_cast<std::uint8_t>(target.muteKnownMask|bit);
        if(raw[track]==1)target.muteMask=static_cast<std::uint8_t>(target.muteMask|bit);
    }
}
Pa5xStyleSourceSettings finish(Pa5xStyleSourceSettings value) {
    if(value.valid())return value;
    return unavailablePa5xStyleSourceSettings("Original Style settings exceed their bounded metadata contract");
}
} // namespace

bool Pa5xStyleSourceSettings::valid() const noexcept {
    if(error.size()>kPa5xStyleSourceMaximumErrorBytes||error.find('\0')!=std::string::npos||
       tracks.size()>kPa5xStyleSourceMaximumTracks||(muteMask&~muteKnownMask)!=0)return false;
    if(!indexed)return !readable&&tracks.empty()&&error.empty()&&muteKnownMask==0&&muteMask==0;
    if(!readable)return tracks.empty()&&muteKnownMask==0&&muteMask==0;
    std::array<bool,kPa5xStyleSourceMaximumTracks> present{};
    for(const auto& item:tracks){
        if(item.element<0||item.element>=static_cast<int>(kElementCount)||item.track<0||item.track>=kTracks||
           item.declaredType.size()>kPa5xStyleSourceMaximumTypeBytes||item.declaredType.find('\0')!=std::string::npos||
           static_cast<unsigned>(item.nativeMode)>static_cast<unsigned>(NativePatternMode::Guitar)||
           (item.available&&item.nativeMode==NativePatternMode::Unsupported)||
           (item.capoKnown?(item.capo<0||item.capo>12):item.capo!=-1)||
           (item.humanizeKnown?(item.humanize<0||item.humanize>127):item.humanize!=-1)||
           item.tensionRaw<-1||item.tensionRaw>1||item.sounds.size()>kPa5xStyleSourceMaximumSounds)return false;
        const auto slot=static_cast<std::size_t>(item.element)*kTracks+static_cast<std::size_t>(item.track);
        if(present[slot])return false;present[slot]=true;
        std::array<bool,kPa5xStyleSourceMaximumSounds> scopes{};
        for(const auto& sound:item.sounds){
            if(sound.cv<0||sound.cv>6||sound.channel<0||sound.channel>15||
               !addressField(sound.msb)||!addressField(sound.lsb)||!addressField(sound.program))return false;
            const auto scope=static_cast<std::size_t>(sound.cv)*16U+static_cast<std::size_t>(sound.channel);
            if(scopes[scope])return false;scopes[scope]=true;
        }
    }
    return true;
}

Pa5xStyleSourceSettings unavailablePa5xStyleSourceSettings(const std::string& error) {
    Pa5xStyleSourceSettings out;out.indexed=true;
    out.error=error.empty()?"Original Style metadata is unavailable":error.substr(0,kPa5xStyleSourceMaximumErrorBytes);
    std::replace(out.error.begin(),out.error.end(),'\0',' ');return out;
}

Pa5xStyleSourceSettings summarizePa5xStyleSourceSettings(const KorgStyleInspection& source,const Style* native) {
    if(!source.valid)return unavailablePa5xStyleSourceSettings(source.error);
    Pa5xStyleSourceSettings out;out.indexed=true;out.readable=true;sourceMutes(out,source.originalMuteRaw);
    if(!native)out.error="Original settings are readable; native pattern conversion is unavailable";
    for(const auto& section:source.elements)for(const auto& clip:section.clips){
        if(out.tracks.size()>=kPa5xStyleSourceMaximumTracks)
            return unavailablePa5xStyleSourceSettings("Too many original Style element/track records");
        Pa5xStyleSourceTrack row;row.element=static_cast<int>(section.element);row.track=clip.track;row.declaredType=clip.patternType;
        nativeFields(row,native);
        row.capoKnown=clip.guitarCapo>=0&&clip.guitarCapo<=12;if(row.capoKnown)row.capo=clip.guitarCapo;
        row.humanizeKnown=clip.guitarHumanize>=0&&clip.guitarHumanize<=127;if(row.humanizeKnown)row.humanize=clip.guitarHumanize;
        row.stringHighRaw=clip.guitarStringHigh;row.stringLowRaw=clip.guitarStringLow;
        row.nttRaw=clip.ntt;row.ntrRaw=clip.ntr;row.retriggerRaw=clip.retriggerMode;
        row.keyRangeKnown=clip.keyRangeDeclared;row.keyRangeEnabled=clip.keyRangeEnabled;
        row.keyLow=clip.keyLow;row.keyHigh=clip.keyHigh;row.wrapRaw=clip.wrapAroundDegree;
        row.noiseOffsetRaw=clip.guitarNoiseOffset;row.tensionRaw=clip.guitarTension;
        soundsFromClip(row,clip);out.tracks.push_back(std::move(row));
    }
    return finish(std::move(out));
}

Pa5xStyleSourceSettings summarizePa5xStyleSourceSettings(const Style& source) {
    Pa5xStyleSourceSettings out;out.indexed=true;out.readable=true;
    out.muteKnownMask=source.initialMuteKnownMask;out.muteMask=static_cast<std::uint8_t>(source.initialMuteMask&source.initialMuteKnownMask);
    for(std::size_t element=0;element<source.sections.size();++element){
        const auto& section=source.sections[element];if(!section.nativePatterns)continue;
        for(std::size_t track=0;track<section.patterns.size();++track){
            const auto& pattern=section.patterns[track];if(!pattern.present)continue;
            Pa5xStyleSourceTrack row;row.element=static_cast<int>(element);row.track=static_cast<int>(track);
            nativeFields(row,&source);
            // Only the established legacy Guitar phrase tag proves this type.
            // Ordinary MIDI/legacy lane labels do not fabricate named XML data.
            if(pattern.mode==NativePatternMode::Guitar)row.declaredType="Guitar";
            row.nttRaw=pattern.rawNtt;row.ntrRaw=pattern.rawNtr;row.retriggerRaw=pattern.rawRetrigger;
            row.keyRangeEnabled=pattern.keyRangeEnabled;row.keyLow=pattern.keyLow;row.keyHigh=pattern.keyHigh;row.wrapRaw=pattern.wrapAroundDegree;
            soundsFromPattern(row,pattern);out.tracks.push_back(std::move(row));
        }
    }
    return finish(std::move(out));
}

Pa5xStyleSourceSettings summarizePa5xStyleSourceSettings(const Pa5xStyleRead& source) {
    if(source.inspection)return summarizePa5xStyleSourceSettings(*source.inspection,source.nativeStyle.get());
    if(!source.valid||!source.nativeStyle)return unavailablePa5xStyleSourceSettings(source.error);
    auto out=summarizePa5xStyleSourceSettings(*source.nativeStyle);
    if(!out.readable)return out;
    for(auto& row:out.tracks){
        const auto& original=source.sections[static_cast<std::size_t>(row.element)].tracks[static_cast<std::size_t>(row.track)];
        if(!original.patternType.empty())row.declaredType=original.patternType;
        // Legacy per-track data contains the actual key-range endpoints. Its
        // setupTimingKnown marker is set only when that record was decoded.
        row.keyRangeKnown=original.setupTimingKnown;
    }
    return finish(std::move(out));
}
} // namespace silveton::arranger
