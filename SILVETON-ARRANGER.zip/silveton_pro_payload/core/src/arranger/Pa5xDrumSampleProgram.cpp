#include "silveton/arranger/Pa5xDrumSampleProgram.h"
#include "silveton/arranger/Pa5xSampleDiskCache.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <map>
#include <memory>
#include <set>
#include <utility>

namespace silveton::arranger {
namespace {
void warn(Pa5xSampleProgramImport& result, const std::string& message) {
    if (std::find(result.warnings.begin(), result.warnings.end(), message) == result.warnings.end())
        result.warnings.push_back(message);
}
bool cancelled(const Pa5xMultisampleBuildOptions& options) {
    return options.cancel != nullptr && options.cancel->load(std::memory_order_relaxed);
}
} // namespace

std::shared_ptr<const silveton::sampler::DrumKeyGroups> buildPa5xDrumKeyGroups(
    const Pa5xDrumKitInspection& kit) {
    std::array<std::uint8_t,128> assignments{};
    if (!decodePa5xDrumExclusiveGroups(kit, assignments)) return nullptr;
    auto groups = std::make_shared<silveton::sampler::DrumKeyGroups>();
    for (std::size_t key = 0U; key < assignments.size(); ++key)
        (*groups)[key].exclusiveGroup = assignments[key];
    return groups;
}

bool pa5xDrumHasVerifiedStereoPair(const Pa5xDrumLayerSampleLink& link) noexcept {
    return link.resolved && link.ram && link.stereoPairingKnown &&
        link.sampleIds.size() == 2U && link.sampleIds[0] != 0U &&
        link.sampleIds[1] != 0U && link.sampleIds[0] != link.sampleIds[1];
}

Pa5xSampleProgramImport buildPa5xDrumSampleProgram(
    const Pa5xSetBank& bank, int msb, int lsb, int programNumber,
    const Pa5xMultisampleBuildOptions& options, Pa5xMultisampleCache* cache) {
    Pa5xSampleProgramImport result;
    result.msb = msb; result.lsb = lsb; result.programNumber = programNumber;
    const auto* source = bank.findSampleSound(msb, lsb, programNumber);
    if (source == nullptr || source->descriptor.kind != Pa5xPcgSoundKind::DrumKit) {
        warn(result, "No User Drum Kit exists at this exact original address");
        return result;
    }
    result.found = true; result.name = source->descriptor.name; result.partial = true;
    warn(result, "Temporary User sample playback: original Korg envelopes, filters and effects are not recreated");
    warn(result, "Drum samples play as fixed-pitch one-shots; unknown per-key and layer processing is bypassed");
    warn(result, "Verified legacy KMP L/R drum pairs use separate hard-panned voices; KMP v8 unknown reference roles, round-robin and ambience remain unsupported");
    const auto& kit = source->drumKit;
    if (!kit.referenceGraphDecoded) {
        warn(result, kit.error.empty() ? "The Drum Kit key/layer reference graph is unavailable" : kit.error);
        return result;
    }
    const auto drumKeyGroups = buildPa5xDrumKeyGroups(kit);
    if (!drumKeyGroups)
        warn(result, "Original Drum Kit group numbers unavailable for " + result.name);
    const auto links = bank.sampleDrumKitLinks(msb, lsb, programNumber);
    std::map<std::size_t, const Pa5xDrumLayerSampleLink*> layerLinks;
    for (const auto& link : links.layers) layerLinks.emplace(link.layer, &link);
    Pa5xMultisampleCache localCache;
    auto* sampleCache = cache == nullptr ? &localCache : cache;
    std::map<std::uint64_t, Pa5xSampleImport> samples;
    std::set<std::uint64_t> usedSamples;
    std::set<const silveton::sampler::SampleData*> warmedReverseSamples;
    std::array<std::shared_ptr<silveton::sampler::Multisample>, 6> multisamples{};

    for (std::size_t keyNumber = 0; keyNumber < kit.keys.size(); ++keyNumber) {
        if (cancelled(options)) {
            warn(result, "User Drum Kit sample loading was cancelled");
            return result;
        }
        const auto& key = kit.keys[keyNumber];
        if (key.layerCount == 0U) continue;
        if (key.layerCount > multisamples.size() ||
            static_cast<std::size_t>(key.firstLayer) + key.layerCount > kit.layers.size()) {
            result.sourceCount += key.layerCount;
            result.missingSources += key.layerCount;
            warn(result, "A Drum Kit key references an unsupported layer span; that key stays silent");
            continue;
        }
        bool velocityRangesValid = true;
        unsigned previousSwitch = 0U;
        for (std::size_t i = 0; i + 1U < key.layerCount; ++i) {
            const auto threshold = static_cast<unsigned>(key.velocitySwitchesRaw[i]);
            if (threshold > 127U || threshold < previousSwitch) velocityRangesValid = false;
            previousSwitch = threshold;
        }
        if (!velocityRangesValid) {
            result.sourceCount += key.layerCount;
            result.missingSources += key.layerCount;
            warn(result, "A Drum Kit key has invalid velocity switches; that key stays silent");
            continue;
        }
        for (std::size_t layerNumber = 0; layerNumber < key.layerCount; ++layerNumber) {
            const unsigned low = layerNumber == 0U ? 1U
                : static_cast<unsigned>(key.velocitySwitchesRaw[layerNumber - 1U]) + 1U;
            const unsigned high = layerNumber + 1U == key.layerCount ? 127U
                : static_cast<unsigned>(key.velocitySwitchesRaw[layerNumber]);
            // Repeated switches can describe a velocity layer with no playable
            // notes. It must not acquire a substitute range or allocate audio.
            if (low > high || low > 127U) continue;
            ++result.sourceCount;
            const auto layerIndex = static_cast<std::size_t>(key.firstLayer) + layerNumber;
            const auto& layer = kit.layers[layerIndex];
            if (layer.sampleBankRaw == 0U) { ++result.skippedRomSources; continue; }
            const auto linked = layerLinks.find(layerIndex);
            if (layer.sampleBankRaw != 1U || linked == layerLinks.end() ||
                !linked->second->ram || !linked->second->resolved) {
                ++result.missingSources;
                continue;
            }
            // Fetch by exact typed KMP UID; this is a preparation-thread
            // lookup and shares decoded waveforms with every other Sound.
            const auto fetch = [&](std::uint64_t uid) -> const Pa5xSampleImport* {
                if (uid == 0U) return nullptr;
                auto found = samples.find(uid);
                if (found == samples.end())
                    found = samples.emplace(uid, bank.buildSample(uid, options, sampleCache)).first;
                if (!found->second) {
                    if (!found->second.error.empty()) warn(result, found->second.error);
                    return nullptr;
                }
                return &found->second;
            };
            std::array<const Pa5xSampleImport*, 2> selected{};
            std::array<std::uint64_t, 2> selectedUids{};
            std::size_t selectedCount = 0U;
            const auto& link = *linked->second;
            if (pa5xDrumHasVerifiedStereoPair(link)) {
                const auto* left = fetch(link.sampleIds[0]);
                const auto* right = fetch(link.sampleIds[1]);
                // Only pair compatible channels: mismatched rates/frame lengths
                // can drift or stop at different times and are not valid stereo.
                if (left && right && left->sample->sampleRate == right->sample->sampleRate &&
                    left->sample->frameCount() == right->sample->frameCount() &&
                    left->sample->loop.enabled == right->sample->loop.enabled &&
                    (!left->sample->loop.enabled ||
                     (left->sample->loop.startFrame == right->sample->loop.startFrame &&
                      left->sample->loop.endFrame == right->sample->loop.endFrame))) {
                    selected = {left, right};
                    selectedUids = {link.sampleIds[0], link.sampleIds[1]};
                    selectedCount = 2U;
                } else {
                    warn(result, "Legacy L/R Drum Kit pair is missing or has incompatible waveforms; playing only the first available channel centered");
                }
            }
            if (selectedCount == 0U) {
                for (const auto uid : link.sampleIds) {
                    if (cancelled(options)) {
                        warn(result, "User Drum Kit sample loading was cancelled");
                        return result;
                    }
                    if (const auto* first = fetch(uid)) {
                        selected[0] = first; selectedUids[0] = uid;
                        selectedCount = 1U; break;
                    }
                }
            }
            if (selectedCount == 0U) { ++result.missingSources; continue; }
            if (multisamples[layerNumber] == nullptr) {
                auto multi = std::make_shared<silveton::sampler::Multisample>();
                multi->name = result.name + " User drum layer " + std::to_string(layerNumber + 1U);
                multi->sourceIdentity = "Pa5X sample playback:" + source->path + ":" +
                    std::to_string(msb) + "/" + std::to_string(lsb) + "/" +
                    std::to_string(programNumber) + ":" + std::to_string(layerNumber);
                multisamples[layerNumber] = std::move(multi);
            }
            for (std::size_t channel = 0U; channel < selectedCount; ++channel) {
                const auto& sample = *selected[channel];
                for (const auto& message : sample.warnings) warn(result, message);
                silveton::sampler::SampleZone zone;
                zone.sample = sample.sample;
                zone.keyLow = zone.keyHigh = zone.rootKey = static_cast<std::uint8_t>(keyNumber);
                zone.velocityLow = static_cast<std::uint8_t>(low);
                zone.velocityHigh = static_cast<std::uint8_t>(high);
                zone.nonTranspose = true;
                zone.oneShot = true;
                zone.reverse = sample.reverse || (layer.reverseRaw & 2U) != 0U;
                zone.gainDb = sample.gainDb;
                // Hard L/R only when the KMP revision actually identifies both
                // channels. Unknown v8 positions and incomplete pairs are mono.
                zone.pan = selectedCount == 2U ? (channel == 0U ? -1.0F : 1.0F) : 0.0F;
                if (zone.reverse && zone.sample->stream && warmedReverseSamples.insert(zone.sample.get()).second)
                    warmPa5xReverseSampleEntry(*zone.sample->stream);
                if (layer.layerParametersIdentified && layer.transposeRaw >= -64 && layer.transposeRaw <= 63)
                    zone.transposeSemitones = layer.transposeRaw;
                multisamples[layerNumber]->zones.push_back(std::move(zone));
                usedSamples.insert(selectedUids[channel]);
            }
            ++result.loadedSources;
        }
    }
    if (cancelled(options)) {
        warn(result, "User Drum Kit sample loading was cancelled");
        return result;
    }
    auto native = std::make_shared<silveton::sampler::Program>();
    native->name = result.name + " [samples]";
    native->drumKeyGroups = drumKeyGroups;
    for (std::size_t i = 0; i < multisamples.size(); ++i) {
        if (multisamples[i] == nullptr || multisamples[i]->zones.empty()) continue;
        silveton::sampler::ProgramLayer layer;
        layer.name = "User drum layer " + std::to_string(i + 1U);
        layer.multisample = multisamples[i];
        layer.ampEnvelope = {0.001F, 0.0F, 1.0F, 0.015F};
        layer.damperEnabled = false;
        native->layers.push_back(std::move(layer));
    }
    result.decodedSampleCount = usedSamples.size();
    if (result.skippedRomSources != 0U) warn(result, "Factory drum samples are missing and remain silent");
    if (result.missingSources != 0U) warn(result, "Unavailable User drum key/velocity regions remain silent");
    if (!native->layers.empty()) {
        result.program = std::move(native);
        result.ready = true;
    } else warn(result, "No linked User drum recording could be loaded for this kit");
    return result;
}
} // namespace silveton::arranger
