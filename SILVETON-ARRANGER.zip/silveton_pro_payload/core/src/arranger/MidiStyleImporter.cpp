#include "silveton/arranger/ArrangerEngine.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <fstream>
#include <iterator>
#include <limits>
#include <map>
#include <utility>

namespace silveton::arranger {
namespace {
struct Reader {
    const std::vector<std::uint8_t>& data;
    std::size_t pos{0}, end{0};
    bool ok{true};
    std::uint8_t byte(){if(pos>=end){ok=false;return 0;}return data[pos++];}
    std::uint16_t u16(){const auto a=byte();const auto b=byte();return static_cast<std::uint16_t>((a<<8U)|b);}
    std::uint32_t u32(){std::uint32_t n=0;for(int i=0;i<4;++i)n=(n<<8U)|byte();return n;}
    std::uint32_t variable(){std::uint32_t n=0;for(int i=0;i<4;++i){const auto b=byte();n=(n<<7U)|(b&127U);if(!ok||(b&128U)==0)return n;}ok=false;return 0;}
    bool skip(std::uint32_t n){if(static_cast<std::size_t>(n)>end-pos){ok=false;return false;}pos+=n;return true;}
    std::string text(std::uint32_t n){if(static_cast<std::size_t>(n)>end-pos){ok=false;return{};}std::string s(reinterpret_cast<const char*>(data.data()+pos),n);pos+=n;return s;}
};
struct Raw { std::uint32_t tick; std::uint8_t status,data1,data2; std::uint64_t order; };
struct Marker {std::uint32_t tick;Element element;};
struct Meter {std::uint32_t tick;std::uint8_t n,d;};
struct Tempo {std::uint32_t tick;std::uint32_t us;};
Element parseMarker(const std::string& text,bool& extraChordVariations) {
    std::string clean;for(unsigned char ch:text)if(std::isalnum(ch))clean+=static_cast<char>(std::toupper(ch));
    if(clean=="BR")return Element::Break;
    const auto cv=clean.find("CV");
    if(cv!=std::string::npos&&cv+3==clean.size()&&clean[cv+2]>='1'&&clean[cv+2]<='6'){
        auto tag=clean.substr(0,cv);
        if(tag.size()==2&&tag[1]>='1'&&tag[1]<='4'){
            const auto number=tag.substr(1);
            switch(tag[0]){
                case 'V': tag="VAR"+number;break;
                case 'I': tag="INTRO"+number;break;
                case 'F': tag="FILL"+number;break;
                case 'E': tag="ENDING"+number;break;
            }
        }else if(tag=="B"||tag=="BR"||tag=="BRK")tag="BREAK";
        if(clean[cv+2]!='1')extraChordVariations=true;
        clean=std::move(tag);
    }
    for(int i=0;i<static_cast<int>(Element::Count);++i){std::string name;for(const char* p=elementName(static_cast<Element>(i));*p;++p)if(std::isalnum(static_cast<unsigned char>(*p)))name+=*p;if(clean==name)return static_cast<Element>(i);}
    if(clean.size()==4&&clean.rfind("END",0)==0&&clean[3]>='1'&&clean[3]<='3')return static_cast<Element>(static_cast<int>(Element::Ending1)+clean[3]-'1');
    return Element::Count;
}
std::string baseName(const std::string& path){auto n=path.find_last_of("/\\");std::string out=n==std::string::npos?path:path.substr(n+1);n=out.find_last_of('.');if(n!=std::string::npos)out.resize(n);return out.empty()?"Imported MIDI":out;}
} // namespace

ImportResult importMidiFile(const std::string& path) {
    ImportResult result;
    std::ifstream input(path,std::ios::binary|std::ios::ate);
    if(!input){result.error="Cannot open MIDI file";return result;}
    const auto size=input.tellg();
    if(size<14||size>64*1024*1024){result.error="MIDI file must be between 14 bytes and 64 MiB";return result;}
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));input.seekg(0);input.read(reinterpret_cast<char*>(bytes.data()),size);
    if(!input){result.error="MIDI file read failed";return result;}
    return importMidiBytes(bytes,baseName(path));
}
ImportResult importMidiBytes(const std::vector<std::uint8_t>& bytes,const std::string& name) {
    ImportResult result;
    auto fail=[&](const char* message){result.error=message;return result;};
    if(bytes.size()<14||bytes.size()>64U*1024U*1024U)return fail("Invalid MIDI file size");
    Reader r{bytes,0,bytes.size()};
    if(r.u32()!=0x4D546864U)return fail("Not a standard MIDI file (MThd missing). Korg STG/STY/KST needs a separate decoder.");
    const auto headerLength=r.u32();
    if(headerLength<6||headerLength>bytes.size()-8)return fail("Invalid MIDI header length");
    const auto format=r.u16(),trackCount=r.u16(),division=r.u16();
    if(format>1||trackCount==0||trackCount>256||(format==0&&trackCount!=1))return fail("Only standard MIDI format 0 or 1 is supported");
    if((division&0x8000U)!=0||division==0)return fail("SMPTE MIDI timing is not supported for styles");
    r.pos=8U+headerLength;
    std::vector<Raw> events;std::vector<Marker> markers;std::vector<Meter> meters;std::vector<Tempo> tempos;
    std::array<bool,16> channels{};std::array<std::string,16> channelNames{};
    std::uint32_t lastTick=0;std::uint64_t order=0;
    for(unsigned ti=0;ti<trackCount;++ti){
        if(r.end-r.pos<8||r.u32()!=0x4D54726BU)return fail("MIDI track chunk is missing");
        const auto length=r.u32();if(length>r.end-r.pos)return fail("Truncated MIDI track");
        const std::size_t trackEnd=r.pos+length;Reader tr{bytes,r.pos,trackEnd};std::uint32_t tick=0;std::uint8_t running=0;bool sawEnd=false;std::string trackName;std::array<bool,16> trackChannels{};
        while(tr.pos<tr.end&&tr.ok){
            const auto delta=tr.variable();if(!tr.ok||delta>std::numeric_limits<std::uint32_t>::max()-tick)return fail("Invalid MIDI delta time");tick+=delta;lastTick=std::max(lastTick,tick);
            auto status=tr.byte();bool hasFirst=false;std::uint8_t first=0;
            if(status<0x80){if(running==0)return fail("MIDI running status without a channel status");first=status;hasFirst=true;status=running;}
            if(status==0xFF){
                running=0;const auto type=tr.byte();const auto metaLength=tr.variable();if(!tr.ok||metaLength>tr.end-tr.pos)return fail("Truncated MIDI meta event");
                if(type==0x2F){if(metaLength!=0)return fail("Invalid MIDI End-of-Track");sawEnd=true;tr.pos=tr.end;break;}
                if(type==0x06){bool extraCv=false;const auto marker=parseMarker(tr.text(metaLength),extraCv);if(extraCv&&marker!=Element::Count)return fail("This MIDI Style includes multiple chord variations. Load the converted KST, or export one CV per section.");if(marker!=Element::Count)markers.push_back({tick,marker});}
                else if(type==0x03)trackName=tr.text(metaLength);
                else if(type==0x51){if(metaLength!=3)return fail("Invalid MIDI tempo event");const auto t0=tr.byte(),t1=tr.byte(),t2=tr.byte();const auto us=(static_cast<std::uint32_t>(t0)<<16U)|(static_cast<std::uint32_t>(t1)<<8U)|t2;if(us==0)return fail("MIDI tempo cannot be zero");tempos.push_back({tick,us});}
                else if(type==0x58){if(metaLength!=4)return fail("Invalid MIDI time signature");const auto n=tr.byte(),power=tr.byte();tr.skip(2);if(n==0||power>6)return fail("Unsupported MIDI time signature");meters.push_back({tick,n,static_cast<std::uint8_t>(1U<<power)});}
                else tr.skip(metaLength);
                continue;
            }
            if(status==0xF0||status==0xF7){running=0;const auto size=tr.variable();if(!tr.ok||!tr.skip(size))return fail("Truncated MIDI SysEx event");continue;}
            if(status<0x80||status>=0xF0)return fail("Unsupported MIDI system event in track");
            running=status;const auto type=static_cast<std::uint8_t>(status&0xF0U);const auto ch=static_cast<std::uint8_t>(status&15U);
            const auto d1=hasFirst?first:tr.byte();const auto d2=(type==0xC0||type==0xD0)?0:tr.byte();
            if(!tr.ok||d1>127||d2>127)return fail("Truncated or invalid MIDI channel event");
            channels[ch]=true;trackChannels[ch]=true;events.push_back({tick,status,d1,static_cast<std::uint8_t>(d2),order++});
            if(events.size()>2000000)return fail("MIDI style has too many events");
        }
        if(!tr.ok||!sawEnd)return fail("MIDI track does not end with a valid End-of-Track event");
        for(std::size_t ch=0;ch<16;++ch)if(trackChannels[ch]&&!trackName.empty()&&channelNames[ch].empty())channelNames[ch]=trackName;
        r.pos=trackEnd;
    }
    if(events.empty())return fail("MIDI contains no channel events");
    std::stable_sort(events.begin(),events.end(),[](const Raw& a,const Raw& b){return a.tick<b.tick||(a.tick==b.tick&&a.order<b.order);});
    std::sort(markers.begin(),markers.end(),[](const Marker& a,const Marker& b){return a.tick<b.tick;});
    std::sort(meters.begin(),meters.end(),[](const Meter& a,const Meter& b){return a.tick<b.tick;});
    std::sort(tempos.begin(),tempos.end(),[](const Tempo& a,const Tempo& b){return a.tick<b.tick;});
    auto style=std::make_shared<Style>();style->name=name;style->ppq=division;
    if(!tempos.empty()){
        const auto initial=tempos.front();style->tempoBpm=60000000.0/initial.us;
        for(const auto& t:tempos)if(t.us!=initial.us)return fail("Tempo changes inside the MIDI are not supported by this style importer");
    }
    if(style->tempoBpm<20||style->tempoBpm>400)return fail("MIDI tempo is outside the supported 20..400 BPM range");
    std::array<int,16> channelMap;channelMap.fill(-1);int mapped=0;
    auto addChannel=[&](int ch,TrackRole role){if(!channels[static_cast<std::size_t>(ch)])return true;if(mapped>=kTracks)return false;channelMap[static_cast<std::size_t>(ch)]=mapped;auto& track=style->tracks[static_cast<std::size_t>(mapped++)];track.used=true;track.sourceChannel=static_cast<std::uint8_t>(ch);track.role=role;track.name=channelNames[static_cast<std::size_t>(ch)];if(track.name.empty())track.name="MIDI "+std::to_string(ch+1);return true;};
    addChannel(9,TrackRole::Drums);addChannel(10,TrackRole::Percussion);addChannel(8,TrackRole::Bass);
    for(int ch=0;ch<16;++ch)if(ch!=9&&ch!=10&&ch!=8&&!addChannel(ch,TrackRole::Accompaniment))return fail("A style can contain at most eight MIDI channels");
    if(mapped==0)return fail("MIDI contains no usable channels");
    std::array<std::uint8_t,16> msb{},lsb{},program{};std::array<bool,16> notesStarted{};
    for(const auto& event:events){
        const int ch=event.status&15;const int type=event.status&0xF0;const int index=channelMap[static_cast<std::size_t>(ch)];if(index<0)continue;
        if(type==0x90&&event.data2>0)notesStarted[static_cast<std::size_t>(ch)]=true;
        if(type==0xB0&&(event.data1==0||event.data1==32)){
            auto& value=event.data1==0?msb[static_cast<std::size_t>(ch)]:lsb[static_cast<std::size_t>(ch)];
            if(notesStarted[static_cast<std::size_t>(ch)]&&value!=event.data2)return fail("Bank changes after notes begin require section-specific sound resolution and are not supported yet");
            value=event.data2;
        }else if(type==0xC0){auto& value=program[static_cast<std::size_t>(ch)];if(notesStarted[static_cast<std::size_t>(ch)]&&value!=event.data1)return fail("Program changes after notes begin require section-specific sound resolution and are not supported yet");value=event.data1;}
    }
    for(int ch=0;ch<16;++ch)if(channelMap[static_cast<std::size_t>(ch)]>=0){auto& track=style->tracks[static_cast<std::size_t>(channelMap[static_cast<std::size_t>(ch)])];track.msb=msb[static_cast<std::size_t>(ch)];track.lsb=lsb[static_cast<std::size_t>(ch)];track.program=program[static_cast<std::size_t>(ch)];}
    if(markers.empty()){
        markers.push_back({0,Element::Var1});
        result.warnings.push_back("No recognized section markers: the whole MIDI file is imported as VAR 1.");
    }
    std::array<bool,kElementCount> seen{};
    for(std::size_t mi=0;mi<markers.size();++mi){
        const auto& marker=markers[mi];const auto index=static_cast<std::size_t>(marker.element);
        if(seen[index])return fail("A section marker occurs more than once");
        seen[index]=true;
        if(mi>0&&marker.tick==markers[mi-1].tick)return fail("Two section markers have the same tick position");
        const std::uint32_t end=mi+1<markers.size()?markers[mi+1].tick:lastTick;
        Meter meter{0,4,4};for(const auto& m:meters)if(m.tick<=marker.tick)meter=m;
        for(const auto& m:meters)if(m.tick>marker.tick&&m.tick<end)return fail("Time signature changes within one style section are not supported");
        const double bar=static_cast<double>(division)*4.0*meter.n/meter.d;
        if(bar<1.0||bar>static_cast<double>(std::numeric_limits<std::uint32_t>::max()))return fail("Invalid style measure length");
        if(end<=marker.tick)return fail("An imported style section is empty");
        auto& sec=style->sections[index];sec.available=true;sec.numerator=meter.n;sec.denominator=meter.d;
        const double length=std::ceil(static_cast<double>(end-marker.tick)/bar-1e-9)*bar;
        if(length>static_cast<double>(std::numeric_limits<std::uint32_t>::max()))return fail("Style section is too long");
        sec.lengthTicks=static_cast<std::uint32_t>(std::max(1.0,length));
        for(const auto& event:events){if(event.tick<marker.tick||event.tick>end||(event.tick==end&&mi+1<markers.size()))continue;const auto type=static_cast<std::uint8_t>(event.status&0xF0U);if(type==0xC0||(type==0xB0&&(event.data1==0||event.data1==32)))continue;const int track=channelMap[static_cast<std::size_t>(event.status&15U)];if(track<0)continue;sec.events.push_back({event.tick-marker.tick,static_cast<std::uint8_t>(track),type,event.data1,event.data2});}
    }
    bool hasVariation=false;for(int i=static_cast<int>(Element::Var1);i<=static_cast<int>(Element::Var4);++i)hasVariation=hasVariation||style->sections[static_cast<std::size_t>(i)].available;
    if(!hasVariation)return fail("Style must have at least one VAR 1..4 section");
    result.warnings.push_back("Source phrases are interpreted as C major. This is a generic MIDI style import, not Korg CV/NTT decoding.");
    result.style=std::move(style);return result;
}
} // namespace silveton::arranger
