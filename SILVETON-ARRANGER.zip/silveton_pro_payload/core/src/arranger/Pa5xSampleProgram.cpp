#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/arranger/Pa5xDrumSampleProgram.h"
#include "silveton/arranger/Pa5xSampleDiskCache.h"
#include "silveton/sampler/SampleStream.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <tuple>
#include <unistd.h>
#include <utility>

namespace silveton::arranger {
namespace {
struct SampleWarmCounters {
    std::atomic<std::uint64_t> batches{0},entries{0},warmedEntries{0},warmedBytes{0},touchedPages{0};
    std::atomic<std::uint64_t> failedEntries{0},budgetSkippedEntries{0},cancelledBatches{0};
};
SampleWarmCounters sampleWarmCounters;

void warn(Pa5xSampleProgramImport& result,const std::string& message) {
    if(std::find(result.warnings.begin(),result.warnings.end(),message)==result.warnings.end())
        result.warnings.push_back(message);
}
bool cancelled(const Pa5xMultisampleBuildOptions& options) noexcept {
    return options.cancel!=nullptr&&options.cancel->load(std::memory_order_relaxed);
}
void nativePitch(silveton::sampler::ProgramLayer& layer,const Pa5xOscillatorReferences& oscillator) noexcept {
    if(!oscillator.staticPitchDecoded)return;
    const int cents=oscillator.staticPitchOffsetCents;
    const int semitones=std::clamp(cents/100,-127,127);
    layer.transposeSemitones=static_cast<std::int8_t>(semitones);
    layer.tuneCents=static_cast<float>(cents-semitones*100);
}
void importSourcePortamento(sampler::ProgramLayer& layer,const Pa5xOscillatorReferences& oscillator,
                            std::uint8_t resourceVersion) noexcept {
    auto& control=layer.sourcePortamento;
    control.present=oscillator.dsp.fieldLayoutDecoded;
    control.resourceVersion=resourceVersion;
    control.flagsRaw=oscillator.dsp.portamentoFlags;
    control.timeRaw=oscillator.dsp.portamentoTime;
    if(resourceVersion>=6U&&oscillator.additionalDspBytes>=2U){
        control.extensionByteCount=2U;
        control.extensionRaw={oscillator.additionalDspRaw[0],oscillator.additionalDspRaw[1]};
    }
    control.encodingSupported=control.present&&resourceVersion<=3U&&
        oscillator.dsp.legacyTritonLayoutCorroborated&&oscillator.dsp.portamentoEncodingDecoded&&
        control.flagsRaw<=3U&&control.timeRaw<=127U;
}
void retainLegacySampleDecay(sampler::ProgramLayer& layer,const Pa5xOscillatorDspParametersRaw& dsp) {
    const auto& eg=dsp.amplitudeEnvelope;const auto& mod=dsp.amplitudeEnvelopeModulation;
    if(!dsp.fieldLayoutDecoded||!dsp.nominalRangesValid||eg.sustainLevel!=0||
       mod.level.intensity!=0||mod.time[0].intensity!=0||mod.time[1].intensity!=0)return;
    // Exact 0.1.69 metadata projection for existing native/Style identities.
    // A full source EG supersedes this cursor in the audio path.
    layer.sampleDecay.start=sampler::SourceAmpEnvelope::levelGain(static_cast<float>(eg.startLevel));
    layer.sampleDecay.targets={sampler::SourceAmpEnvelope::levelGain(static_cast<float>(eg.attackLevel)),
        sampler::SourceAmpEnvelope::levelGain(static_cast<float>(eg.breakLevel)),0.0F};
    layer.sampleDecay.seconds={sampler::SourceAmpEnvelope::timeSeconds(eg.attackTime),
        sampler::SourceAmpEnvelope::timeSeconds(eg.decayTime),sampler::SourceAmpEnvelope::timeSeconds(eg.slopeTime)};
    layer.ampEnvelope.releaseSec=std::max(.001F,sampler::SourceAmpEnvelope::timeSeconds(eg.releaseTime));
}
bool applySourceAmpEnvelope(sampler::ProgramLayer& layer, const Pa5xOscillatorDspParametersRaw& dsp) {
    const auto& eg = dsp.amplitudeEnvelope;
    const auto& mod = dsp.amplitudeEnvelopeModulation;
    if (!dsp.fieldLayoutDecoded || eg.hasReleaseLevel) return false;
    for (const auto level : {eg.startLevel,eg.attackLevel,eg.breakLevel,eg.sustainLevel})
        if (level < 0 || level > 99) return false;
    sampler::SourceAmpEnvelope source;
    source.present = true;
    source.levels = {static_cast<std::uint8_t>(eg.startLevel),static_cast<std::uint8_t>(eg.attackLevel),
        static_cast<std::uint8_t>(eg.breakLevel),static_cast<std::uint8_t>(eg.sustainLevel)};
    source.times = {eg.attackTime,eg.decayTime,eg.slopeTime,eg.releaseTime};
    source.amsSources={mod.time[0].source,mod.time[1].source,mod.level.source};
    source.amsIntensities={mod.time[0].intensity,mod.time[1].intensity,mod.level.intensity};
    source.amsDirections={mod.timeDirections[0],mod.timeDirections[1],mod.levelDirections};
    source.keyboardKeys={dsp.amplitudeKeyboardTracking.lowKey,dsp.amplitudeKeyboardTracking.highKey};
    source.keyboardRamps={dsp.amplitudeKeyboardTracking.lowRamp,dsp.amplitudeKeyboardTracking.highRamp};
    source.filterKeyboardTrackingPresent=true;
    source.filterKeyboardKeys={dsp.filterKeyboardTracking.lowKey,dsp.filterKeyboardTracking.highKey};
    source.filterKeyboardRamps={dsp.filterKeyboardTracking.lowRamp,dsp.filterKeyboardTracking.highRamp};
    source.modulationEncodingSupported=dsp.legacyTritonLayoutCorroborated||dsp.newerPaLayoutCorroborated;
    if (!source.valid()) return false;
    // Unsupported modulation does not erase the decoded base values. The
    // read-only source page and SVAE round-trip retain them as unapplied.
    layer.sourceAmpEnvelope = source;
    // Normal Triton table1-4, retained paired records and the official Pa5X
    // GUI's complete AMS table corroborate0..45. Voice/controller binding is
    // explicit; our response/time/gain laws are not claimed Korg DSP.
    if(!source.playbackSupported())return false;
    source.enabled = true;
    layer.sourceAmpEnvelope = source;
    // The full raw multistage EG is authoritative. A native ADSR projection
    // remains a useful fallback for older readers that do not know SVAE.
    if(!layer.sampleDecay.enabled())layer.ampEnvelope = sampler::sourceAmpEnvelopeParams(source);
    return true;
}

void importSourceOscillator(sampler::ProgramLayer& layer,const Pa5xSoundReferenceGraph& graph,
                            const Pa5xOscillatorReferences& oscillator,std::size_t index,bool high) {
    if(!oscillator.dsp.fieldLayoutDecoded||index>255U)return;
    auto source=std::make_shared<sampler::SourceOscillatorDsp>();
    source->resourceVersion=graph.resourceVersion[0];source->oscillatorIndex=static_cast<std::uint8_t>(index);
    source->highSource=high;
    source->layoutCorroborated=oscillator.dsp.legacyTritonLayoutCorroborated||oscillator.dsp.newerPaLayoutCorroborated;
    source->dspRaw=oscillator.opaqueDsp;source->lfoRaw=oscillator.lfoRaw;
    source->amplitudeEnvelopeRaw=oscillator.amplitudeEnvelopeRaw;
    source->additionalDspRaw=oscillator.additionalDspRaw;source->additionalDspBytes=oscillator.additionalDspBytes;
    source->pitchEnvelopeRaw=graph.pitchEnvelopeRaw;source->pitchEnvelopePresent=graph.pitchEnvelopePresent;
    source->outputRaw=oscillator.outputRaw;source->outputRawPresent=oscillator.outputRawPresent;
    const auto& eq=oscillator.equalizer;
    source->equalizerPresent=eq.present;
    source->equalizerRaw={eq.enabledRaw,eq.trimRaw,eq.lowGainTimes2Raw,eq.frequencyRaw,eq.midGainTimes2Raw,eq.highGainTimes2Raw};
    const auto& selected=high?oscillator.high:oscillator.low;
    source->multisampleLevelRaw=selected.levelRaw;source->multisampleLevelDecoded=selected.levelDecoded;
    source->delayRaw=oscillator.delayRaw;
    source->scaledVelocityRaw={oscillator.scaledVelocityLow,oscillator.scaledVelocityHigh};
    source->scaledVelocityDecoded=oscillator.scaledVelocityDecoded;
    source->velocityZoneRaw={{oscillator.velocityLow,oscillator.velocityHigh}};
    source->velocityZonePresent=true;
    if(!source->framingValid())return;
    // Delay is a native editable value after import. Runtime never reapplies
    // the retained byte over a later user's layer delay edit.
    if(source->delayRaw<=96U)layer.delaySec=sampler::sourceDelaySeconds(source->delayRaw);
    layer.sourceOscillatorDsp=std::move(source);
}

struct ReversedSourceGraph {
    silveton::sampler::MultisamplePtr original;
    silveton::sampler::Multisample reversed;
    explicit ReversedSourceGraph(const silveton::sampler::MultisamplePtr& source)
        :original(source),reversed(*source) {
        for(auto& zone:reversed.zones)zone.reverse=true;
    }
};
silveton::sampler::MultisamplePtr sourceDirection(
    const silveton::sampler::MultisamplePtr& source,const Pa5xOscillatorSource& oscillatorSource,
    Pa5xMultisampleCache* cache) {
    if(!source||!oscillatorSource.reverseDecoded||!oscillatorSource.reversed)return source;
    // One reversed zone graph is shared by every referencing OSC and Sound;
    // no waveform data is copied. Its owner also keeps the original graph
    // alive, so the raw-pointer cache key cannot be recycled after a caller
    // drops a temporary base graph or clears the separate multisample map.
    if(cache!=nullptr) {
        const auto found=cache->reverseMultisamples.find(source.get());
        if(found!=cache->reverseMultisamples.end()&&found->second)return found->second;
    }
    // A reversed PCG source can start at the end even when the PCM recording
    // itself is forward. Prepare only those used reverse entries off audio.
    std::set<const silveton::sampler::SampleData*> warmed;
    for(const auto& zone:source->zones)if(zone.sample&&zone.sample->stream&&warmed.insert(zone.sample.get()).second)
        warmPa5xReverseSampleEntry(*zone.sample->stream);
    auto owner=std::make_shared<ReversedSourceGraph>(source);
    silveton::sampler::MultisamplePtr reversed(owner,&owner->reversed);
    if(cache!=nullptr)cache->reverseMultisamples.emplace(source.get(),reversed);
    return reversed;
}
}

Pa5xSampleWarmTotals pa5xSampleWarmTotals() noexcept {
    Pa5xSampleWarmTotals totals;
    totals.batches=sampleWarmCounters.batches.load(std::memory_order_relaxed);
    totals.entries=sampleWarmCounters.entries.load(std::memory_order_relaxed);
    totals.warmedEntries=sampleWarmCounters.warmedEntries.load(std::memory_order_relaxed);
    totals.warmedBytes=sampleWarmCounters.warmedBytes.load(std::memory_order_relaxed);
    totals.touchedPages=sampleWarmCounters.touchedPages.load(std::memory_order_relaxed);
    totals.failedEntries=sampleWarmCounters.failedEntries.load(std::memory_order_relaxed);
    totals.budgetSkippedEntries=sampleWarmCounters.budgetSkippedEntries.load(std::memory_order_relaxed);
    totals.cancelledBatches=sampleWarmCounters.cancelledBatches.load(std::memory_order_relaxed);
    return totals;
}

Pa5xSampleWarmStatus warmPa5xSamplePrograms(
    const std::vector<silveton::sampler::ProgramPtr>& programs,
    std::size_t maximumBytes,const std::atomic<bool>* cancel) {
    struct Entry {
        silveton::sampler::SamplePtr sample;
        silveton::sampler::RawPcmView raw;
        bool reverse{false};
        std::uint64_t firstFrame{0};
        std::size_t availableBytes{0};
    };
    constexpr std::size_t maximumEntryBytes=64U*1024U;
    constexpr std::uint64_t interpolationGuardFrames=64U;
    const long systemPage=::sysconf(_SC_PAGESIZE);
    const auto pageBytes=static_cast<std::size_t>(systemPage>0?systemPage:4096L);
    std::vector<Entry> entries;
    std::set<std::tuple<std::uintptr_t,std::uint64_t,bool>> seen;
    const auto stopped=[cancel]{return cancel&&cancel->load(std::memory_order_relaxed);};
    Pa5xSampleWarmStatus status;
    const auto finish=[&]{
        status.entries=entries.size();
        sampleWarmCounters.batches.fetch_add(1U,std::memory_order_relaxed);
        sampleWarmCounters.entries.fetch_add(static_cast<std::uint64_t>(status.entries),std::memory_order_relaxed);
        sampleWarmCounters.warmedEntries.fetch_add(static_cast<std::uint64_t>(status.warmedEntries),std::memory_order_relaxed);
        sampleWarmCounters.warmedBytes.fetch_add(static_cast<std::uint64_t>(status.warmedBytes),std::memory_order_relaxed);
        sampleWarmCounters.touchedPages.fetch_add(static_cast<std::uint64_t>(status.touchedPages),std::memory_order_relaxed);
        sampleWarmCounters.failedEntries.fetch_add(static_cast<std::uint64_t>(status.failedEntries),std::memory_order_relaxed);
        sampleWarmCounters.budgetSkippedEntries.fetch_add(static_cast<std::uint64_t>(status.budgetSkippedEntries),std::memory_order_relaxed);
        if(stopped())sampleWarmCounters.cancelledBatches.fetch_add(1U,std::memory_order_relaxed);
        return status;
    };
    for(const auto& program:programs) {
        if(stopped())return finish();
        if(!program)continue;
        for(const auto& layer:program->layers) {
            if(!layer.enabled||!layer.multisample)continue;
            for(const auto& zone:layer.multisample->zones) {
                if(stopped()){status.entries=entries.size();return finish();}
                if(layer.keyLow>zone.keyHigh||layer.keyHigh<zone.keyLow||
                   layer.velocityLow>zone.velocityHigh||layer.velocityHigh<zone.velocityLow)continue;
                const auto& sample=zone.sample;
                if(!sample||!sample->stream)continue;
                const auto raw=sample->stream->rawView();
                const auto frameBytes=raw.frameBytes();
                const auto preloaded=sample->preloadedFrameCount();
                if(!raw.data||frameBytes==0U||raw.frames<=preloaded||
                   raw.frames>std::numeric_limits<std::size_t>::max()/frameBytes)continue;
                if(static_cast<std::size_t>(raw.frames)*frameBytes>
                   std::numeric_limits<std::uintptr_t>::max()-reinterpret_cast<std::uintptr_t>(raw.data))continue;
                if(!seen.emplace(reinterpret_cast<std::uintptr_t>(raw.data),raw.frames,zone.reverse).second)continue;
                // The copied attack prefix needs no disk access. A small
                // lookbehind also covers the interpolator's boundary taps.
                const auto first=zone.reverse?std::min<std::uint64_t>(preloaded,raw.frames):
                    preloaded>interpolationGuardFrames?preloaded-interpolationGuardFrames:0U;
                const auto available=static_cast<std::size_t>(raw.frames-first)*frameBytes;
                entries.push_back({sample,raw,zone.reverse,first,std::min(available,maximumEntryBytes)});
            }
        }
    }
    status.entries=entries.size();
    std::size_t remaining=std::min(maximumBytes,std::size_t{16U*1024U*1024U});
    for(std::size_t index=0;index<entries.size();++index) {
        if(stopped())break;
        const auto& entry=entries[index];
        const auto frameBytes=entry.raw.frameBytes();
        const auto fairShare=std::min(maximumEntryBytes,remaining/(entries.size()-index));
        const auto pageBudget=(fairShare/pageBytes)*pageBytes;
        auto bytes=(std::min(entry.availableBytes,pageBudget)/frameBytes)*frameBytes;
        if(bytes==0U){++status.budgetSkippedEntries;continue;}
        const auto address=[&entry,frameBytes](std::size_t count){
            const auto first=entry.reverse?entry.raw.frames-static_cast<std::uint64_t>(count/frameBytes):entry.firstFrame;
            return reinterpret_cast<std::uintptr_t>(entry.raw.data+static_cast<std::size_t>(first)*frameBytes);
        };
        const auto pageSpan=[pageBytes](std::uintptr_t begin,std::size_t count){
            return ((static_cast<std::size_t>(begin%pageBytes)+count+pageBytes-1U)/pageBytes)*pageBytes;
        };
        auto begin=address(bytes);auto charged=pageSpan(begin,bytes);
        if(charged>pageBudget){
            const auto reduction=charged-pageBudget;
            bytes=bytes>reduction?((bytes-reduction)/frameBytes)*frameBytes:0U;
            if(bytes==0U){++status.budgetSkippedEntries;continue;}
            begin=address(bytes);charged=pageSpan(begin,bytes);
        }
        if(charged>pageBudget||charged>remaining){++status.budgetSkippedEntries;continue;}
        // Charge actual OS page spans, including unaligned edge pages. Failed
        // attempts consume the same budget, so neither small disjoint entries
        // nor unsupported mappings can expand this bounded preparation.
        remaining-=charged;
        std::size_t touchedPages=0U;
        if(silveton::sampler::MappedSampleRegion::prefault(begin,bytes,&touchedPages)) {
            ++status.warmedEntries;status.warmedBytes+=bytes;status.touchedPages+=touchedPages;
        }else ++status.failedEntries;
    }
    return finish();
}

Pa5xSampleProgramImport buildPa5xSampleProgram(
    const Pa5xSetBank& bank,int msb,int lsb,int programNumber,
    const Pa5xMultisampleBuildOptions& options,Pa5xMultisampleCache* cache) {
    Pa5xSampleProgramImport result;
    result.msb=msb;result.lsb=lsb;result.programNumber=programNumber;
    const auto* sound=bank.findSampleSound(msb,lsb,programNumber);
    if(sound==nullptr){
        warn(result,"The original address has no User Sound in this bank; no replacement instrument was selected");
        return result;
    }
    if(sound->descriptor.kind==Pa5xPcgSoundKind::DrumKit)
        return buildPa5xDrumSampleProgram(bank,msb,lsb,programNumber,options,cache);
    result.found=true;result.partial=true;result.name=sound->descriptor.name;
    if(!sound->graph.referenceGraphDecoded){
        warn(result,"This Sound's original oscillator/source graph is unavailable");return result;
    }
    auto native=std::make_shared<silveton::sampler::Program>();
    native->name=result.name+" [samples]";
    if(sound->graph.effects.framingDecoded)
        native->sourceSoundEffects=std::make_shared<const Pa5xSoundEffectsRaw>(sound->graph.effects);
    // Common voice assignment and per-oscillator glide remain separate.
    // Corroborated Mono applies to every supported revision. Revision 8 stores
    // its three-way Legato choice independently of the older compatibility bit.
    native->sourceVoiceAssignment={true,sound->graph.resourceVersion[0],sound->graph.voiceFlagsRaw};
    if(sound->graph.resourceVersion[0]==8U&&sound->graph.resourceVersion[1]==0U&&
       sound->graph.commonRaw.size()==450U){
        native->sourceVoiceAssignment.legatoModePresent=true;
        native->sourceVoiceAssignment.legatoModeRaw=sound->graph.commonRaw[431U];
        native->sourceVoiceAssignment.legatoExtensionRaw=sound->graph.commonRaw[432U];
    }
    native->mono=native->sourceVoiceAssignment.mono();
    native->legato=native->sourceVoiceAssignment.legato();
    native->portamentoSec=0.0F;
    Pa5xMultisampleCache localCache;
    auto* sampleCache=cache==nullptr?&localCache:cache;
    std::map<std::uint64_t,Pa5xMultisampleImport> multisamples;
    std::set<const silveton::sampler::SampleData*> loadedSamples;
    for(std::size_t oscillatorIndex=0;oscillatorIndex<sound->graph.oscillators.size();++oscillatorIndex) {
        if(cancelled(options)){warn(result,"Sample preparation was cancelled");return result;}
        const auto& oscillator=sound->graph.oscillators[oscillatorIndex];
        for(int sourceIndex=0;sourceIndex<2;++sourceIndex) {
            const bool high=sourceIndex==0;
            const auto& source=high?oscillator.high:oscillator.low;
            const auto use=pa5xSourceVelocityUse(oscillator,high);
            if(use.known&&!use.possible)continue;
            int low=std::max(1,static_cast<int>(oscillator.velocityLow));
            int upper=std::min(127,static_cast<int>(oscillator.velocityHigh));
            if(oscillator.velocitySwitch>=1&&oscillator.velocitySwitch<=127) {
                if(high)low=std::max(low,static_cast<int>(oscillator.velocitySwitch));
                else upper=std::min(upper,static_cast<int>(oscillator.velocitySwitch)-1);
            } else {
                // An unknown switch does not justify simultaneously playing
                // two recordings. Prefer the declared High source only.
                if(!high)continue;
                warn(result,"An unsupported velocity switch uses only its exact High recording in sample playback");
            }
            if(low>upper||oscillator.keyLow>oscillator.keyHigh)continue;
            if(source.levelDecoded&&source.levelRaw==0)continue;
            ++result.sourceCount;
            if(source.source==Pa5xMultisampleSource::Rom){++result.skippedRomSources;continue;}
            if(source.source!=Pa5xMultisampleSource::Ram||source.multisampleId==0){++result.missingSources;continue;}
            auto found=multisamples.find(source.multisampleId);
            if(found==multisamples.end()) {
                auto imported=bank.buildSampleMultisample(source.multisampleId,options,sampleCache);
                found=multisamples.emplace(source.multisampleId,std::move(imported)).first;
            }
            const auto& imported=found->second;
            for(const auto& warning:imported.warnings)warn(result,warning);
            if(!imported.multisample||imported.multisample->zones.empty()){++result.missingSources;continue;}
            silveton::sampler::ProgramLayer layer;
            layer.name="OSC "+std::to_string(oscillatorIndex+1)+(high?" High":" Low");
            layer.multisample=sourceDirection(imported.multisample,source,sampleCache);
            layer.keyLow=oscillator.keyLow;layer.keyHigh=oscillator.keyHigh;
            layer.velocityLow=static_cast<std::uint8_t>(low);layer.velocityHigh=static_cast<std::uint8_t>(upper);
            nativePitch(layer,oscillator);
            importSourcePortamento(layer,oscillator,sound->graph.resourceVersion[0]);
            // Unsupported envelope modulation retains an explicit neutral
            // fallback; eligible original EG bytes drive the full source EG.
            layer.ampEnvelope={0.001F,0.0F,1.0F,0.015F};
            retainLegacySampleDecay(layer,oscillator.dsp);
            const bool sourceEnvelope=applySourceAmpEnvelope(layer,oscillator.dsp);
            importSourceOscillator(layer,sound->graph,oscillator,oscillatorIndex,high);
            layer.filter.mode=silveton::sampler::FilterMode::Bypass;
            layer.pitchEnvelopeCents=0.0F;layer.lfo1.pitchCents=0.0F;layer.lfo1.ampDepth=0.0F;
            layer.lfo2.pitchCents=0.0F;layer.lfo2.ampDepth=0.0F;
            bool playable=false;
            for(const auto& zone:layer.multisample->zones) {
                if(!zone.sample||!zone.sample->valid()||zone.keyHigh<layer.keyLow||zone.keyLow>layer.keyHigh)continue;
                playable=true;loadedSamples.insert(zone.sample.get());
            }
            if(!playable){++result.missingSources;continue;}
            if(layer.sourcePortamento.basicPlaybackSupported()&&!layer.sourcePortamento.encodingSupported)
                warn(result,"Newer original OSC Portamento uses SILVETON base Enable/Fingered/Time; added mode/AMS fields remain raw");
            if(!sourceEnvelope)warn(result,"Original Amp EG not fully supported: valid base envelope and supported AMS routes are applied; unknown routes remain raw; invalid base fields use fallback");
            if(layer.sourceOscillatorDsp){
                const auto supported=sampler::sourceOscillatorSupport(*layer.sourceOscillatorDsp);
                if(!supported.pitch)warn(result,"Original pitch controls contain an unsupported mode, AMS or value; raw controls are retained");
                if(!supported.filter||!supported.filterEnvelope)warn(result,"Original filter controls contain unsupported fields; supported modules remain independent");
                if(!supported.lfo[0]||!supported.lfo[1])warn(result,"An original LFO contains unsupported fields and is retained without applying that oscillator");
                if(!supported.level)warn(result,"An original Amp level encoding remains unsupported; that gain stays neutral while other source controls apply");
                if(!supported.multisampleLevel)warn(result,"An original multisample level encoding remains unsupported; its raw value is retained without inventing a gain");
                if(supported.amplitudeSecondUnknown)warn(result,"The additional original Amp modulation pair is retained; its exact wire mapping is not yet corroborated");
                if(supported.equalizerUnknown)warn(result,"Original oscillator EQ applies known trim/shelf gains with SILVETON response; an active middle band with unknown frequency remains unapplied");
                if(supported.delayUnknown)warn(result,"Original oscillator KeyOff/unknown delay trigger is not implemented");
            }
            if(!oscillator.staticPitchDecoded)warn(result,"Unknown oscillator pitch was left neutral for sample playback");
            if(!source.offsetDecoded||source.offsetRaw!=0)
                warn(result,"Unsupported oscillator Start Offset was omitted from sample playback");
            if(!source.reverseDecoded)warn(result,"Unknown source direction was left at the PCM recording's direction");
            if(!imported.missingSampleIds.empty()||!imported.blockers.empty())
                warn(result,"Unavailable zones remain silent; other exact User recordings are enabled");
            native->layers.push_back(std::move(layer));++result.loadedSources;
        }
    }
    if(cancelled(options)){warn(result,"Sample preparation was cancelled");return result;}
    if(!native->layers.empty()) {
        // Keep SILVETON's existing RMS headroom for simultaneous recordings,
        // independently of the now-active original oscillator DSP. This is our
        // audition trim, never a claimed original Sound/master gain setting.
        // Every KMP source map has exactly one selected zone at a key, so its
        // native key spans are disjoint. Add their key/velocity rectangles to
        // a difference grid, then evaluate the whole note domain once. SET
        // preparation consequently does not scan 16,384 cells for each layer.
        constexpr std::size_t stride=129U;
        std::array<int,stride*stride> noteOverlap{};
        std::size_t overlap=1;
        for(const auto& layer:native->layers) {
            if(cancelled(options)){warn(result,"Sample preparation was cancelled");return result;}
            for(const auto& zone:layer.multisample->zones) {
                if(!zone.sample||!zone.sample->valid())continue;
                const int keyLow=std::max<int>(layer.keyLow,zone.keyLow);
                const int keyHigh=std::min<int>(layer.keyHigh,zone.keyHigh);
                const int velocityLow=std::max<int>(layer.velocityLow,zone.velocityLow);
                const int velocityHigh=std::min<int>(layer.velocityHigh,zone.velocityHigh);
                if(keyLow>keyHigh||velocityLow>velocityHigh)continue;
                const auto firstKey=static_cast<std::size_t>(keyLow),lastKey=static_cast<std::size_t>(keyHigh)+1U;
                const auto firstVelocity=static_cast<std::size_t>(velocityLow),lastVelocity=static_cast<std::size_t>(velocityHigh)+1U;
                ++noteOverlap[firstKey*stride+firstVelocity];
                --noteOverlap[lastKey*stride+firstVelocity];
                --noteOverlap[firstKey*stride+lastVelocity];
                ++noteOverlap[lastKey*stride+lastVelocity];
            }
        }
        for(std::size_t key=0;key<128U;++key) {
            if(cancelled(options)){warn(result,"Sample preparation was cancelled");return result;}
            for(std::size_t velocity=0;velocity<128U;++velocity) {
                const auto cell=key*stride+velocity;
                auto& count=noteOverlap[cell];
                if(key!=0U)count+=noteOverlap[cell-stride];
                if(velocity!=0U)count+=noteOverlap[cell-1U];
                if(key!=0U&&velocity!=0U)count-=noteOverlap[cell-stride-1U];
                if(count>0)overlap=std::max(overlap,static_cast<std::size_t>(count));
            }
        }
        const float headroom=-10.0F*std::log10(static_cast<float>(overlap));
        // Copies of the same waveform at the same pitch and starting phase add
        // as amplitudes. The RMS allowance above already accounts for one
        // square-root factor. Account for the other inside each identical group.
        for (auto& layer : native->layers) {
            const auto copies = std::count_if(native->layers.begin(), native->layers.end(), [&](const auto& other) {
                return other.multisample == layer.multisample && other.transposeSemitones == layer.transposeSemitones &&
                    other.tuneCents == layer.tuneCents && other.keyLow == layer.keyLow && other.keyHigh == layer.keyHigh &&
                    other.velocityLow == layer.velocityLow && other.velocityHigh == layer.velocityHigh &&
                    other.sampleDecay.start == layer.sampleDecay.start && other.sampleDecay.targets == layer.sampleDecay.targets &&
                    other.sampleDecay.seconds == layer.sampleDecay.seconds && other.ampEnvelope.releaseSec == layer.ampEnvelope.releaseSec &&
                    other.sourceAmpEnvelope.enabled == layer.sourceAmpEnvelope.enabled &&
                    (!layer.sourceAmpEnvelope.enabled || other.sourceAmpEnvelope.sameAs(layer.sourceAmpEnvelope)) &&
                    other.sourcePortamento == layer.sourcePortamento&&
                    (other.sourceOscillatorDsp==layer.sourceOscillatorDsp||
                     (other.sourceOscillatorDsp&&layer.sourceOscillatorDsp&&
                      other.sourceOscillatorDsp->samePlaybackSettings(*layer.sourceOscillatorDsp)));
            });
            layer.levelDb = headroom - 10.0F * std::log10(static_cast<float>(copies));
        }
        result.program=std::move(native);result.ready=true;
    }
    result.decodedSampleCount=loadedSamples.size();
    warn(result,"User sample playback uses original source UIDs, key/velocity map and known pitch with partial oscillator playback; full eligible Amp EG levels/times and Velocity/Note Number/Amp-Flt KTrk modulation use explicitly SILVETON index/gain/time laws");
    if(result.skippedRomSources!=0)warn(result,"Factory/ROM sources remain silent; no GM replacement was used");
    return result;
}

silveton::sampler::ProgramPtr projectPa5xSampleProgramLegacy69(
        const silveton::sampler::ProgramPtr& source){
    if(!source||!source->sourceVoiceAssignment.present||!source->sourceVoiceAssignment.valid()||
       source->layers.empty()||!paSampleProgramLayerCountSupported(*source)||
       source->drumKeyGroups||source->mono!=source->sourceVoiceAssignment.mono()||
       source->legato!=source->sourceVoiceAssignment.legato()||source->portamentoSec!=0.0F)return {};
    for(const auto& layer:source->layers){
        if(!layer.multisample||layer.multisample->zones.size()>static_cast<std::size_t>(sampler::kMaxZonesPerMultisample)||
           !layer.sourcePortamento.present||!layer.sourcePortamento.valid()||
           layer.sourcePortamento.resourceVersion!=source->sourceVoiceAssignment.resourceVersion||
           !layer.sourceAmpEnvelope.present||!layer.sourceAmpEnvelope.valid()||!layer.sampleDecay.valid()||
           layer.keyLow>layer.keyHigh||layer.keyHigh>127U||layer.velocityLow>layer.velocityHigh||layer.velocityHigh>127U)return {};
        if(layer.sourceOscillatorDsp){
            const auto& original=*layer.sourceOscillatorDsp;
            if(original.manualOverrideMask!=0U)return {};
            const float expectedDelay=original.delayRaw<=96U?
                sampler::sourceDelaySeconds(original.delayRaw):0.0F;
            if(layer.delaySec!=expectedDelay)return {};
        }
        sampler::EnvelopeParams expected{0.001F,0.0F,1.0F,0.015F};
        if(layer.sampleDecay.enabled()){
            const auto index=layer.sourceAmpEnvelope.times[3];
            expected.releaseSec=std::max(0.001F,static_cast<float>(0.001*std::expm1(index*std::log(2.0)/7.5)));
        }else if(layer.sourceAmpEnvelope.enabled)expected=sampler::sourceAmpEnvelopeParams(layer.sourceAmpEnvelope);
        if(layer.ampEnvelope.attackSec!=expected.attackSec||layer.ampEnvelope.decaySec!=expected.decaySec||
           layer.ampEnvelope.sustain!=expected.sustain||layer.ampEnvelope.releaseSec!=expected.releaseSec)return {};
        for(const auto& zone:layer.multisample->zones)
            if(zone.keyLow>zone.keyHigh||zone.keyHigh>127U||zone.velocityLow>zone.velocityHigh||zone.velocityHigh>127U||
               (zone.sample&&zone.sample->sourceIdentity.empty()))return {};
    }
    auto result=std::make_shared<sampler::Program>(*source);
    result->mono=false;result->legato=false;result->portamentoSec=0.0F;
    result->sourceVoiceAssignment={};result->sourceSoundEffects.reset();
    for(auto& layer:result->layers){
        layer.ampEnvelope={0.001F,0.0F,1.0F,0.015F};
        // The importer deliberately retained the exact old SampleDecay gate
        // and three stages. Do not reconstruct its eligibility from incomplete
        // filter/AMS metadata or from the broader new full-EG support gate.
        if(layer.sampleDecay.enabled()){
            const auto index=layer.sourceAmpEnvelope.times[3];
            const auto seconds=static_cast<float>(0.001*std::expm1(index*std::log(2.0)/7.5));
            layer.ampEnvelope.releaseSec=std::max(0.001F,seconds);
        }
        // Delay was not imported in 0.1.69. Only undo the exact, unedited
        // source-owned value validated above; never erase a manual override.
        if(layer.sourceOscillatorDsp)layer.delaySec=0.0F;
        layer.sourceAmpEnvelope={};layer.sourcePortamento={};layer.sourceOscillatorDsp.reset();
    }
    // Exact numerical ordering from the 0.1.69 importer. Undoing the new dB
    // compensation by addition/subtraction would lose float bits and is not an
    // acceptable identity projection. No sample, zone, loop or UID is changed.
    constexpr std::size_t stride=129U;
    std::array<int,stride*stride> noteOverlap{};
    std::size_t overlap=1;
    for(const auto& layer:result->layers){
        for(const auto& zone:layer.multisample->zones){
            if(!zone.sample||!zone.sample->valid())continue;
            const int keyLow=std::max<int>(layer.keyLow,zone.keyLow);
            const int keyHigh=std::min<int>(layer.keyHigh,zone.keyHigh);
            const int velocityLow=std::max<int>(layer.velocityLow,zone.velocityLow);
            const int velocityHigh=std::min<int>(layer.velocityHigh,zone.velocityHigh);
            if(keyLow>keyHigh||velocityLow>velocityHigh)continue;
            const auto firstKey=static_cast<std::size_t>(keyLow),lastKey=static_cast<std::size_t>(keyHigh)+1U;
            const auto firstVelocity=static_cast<std::size_t>(velocityLow),lastVelocity=static_cast<std::size_t>(velocityHigh)+1U;
            ++noteOverlap[firstKey*stride+firstVelocity];
            --noteOverlap[lastKey*stride+firstVelocity];
            --noteOverlap[firstKey*stride+lastVelocity];
            ++noteOverlap[lastKey*stride+lastVelocity];
        }
    }
    for(std::size_t key=0;key<128U;++key){
        for(std::size_t velocity=0;velocity<128U;++velocity){
            const auto cell=key*stride+velocity;
            auto& count=noteOverlap[cell];
            if(key!=0U)count+=noteOverlap[cell-stride];
            if(velocity!=0U)count+=noteOverlap[cell-1U];
            if(key!=0U&&velocity!=0U)count-=noteOverlap[cell-stride-1U];
            if(count>0)overlap=std::max(overlap,static_cast<std::size_t>(count));
        }
    }
    const float headroom=-10.0F*std::log10(static_cast<float>(overlap));
    // Reject an explicitly edited gain instead of silently projecting it away.
    // Only an exact current import compensation has a proven former value.
    for(const auto& layer:source->layers){
        const auto copies=std::count_if(source->layers.begin(),source->layers.end(),[&](const auto& other){
            return other.multisample==layer.multisample&&other.transposeSemitones==layer.transposeSemitones&&
                other.tuneCents==layer.tuneCents&&other.keyLow==layer.keyLow&&other.keyHigh==layer.keyHigh&&
                other.velocityLow==layer.velocityLow&&other.velocityHigh==layer.velocityHigh&&
                other.sampleDecay.start==layer.sampleDecay.start&&other.sampleDecay.targets==layer.sampleDecay.targets&&
                other.sampleDecay.seconds==layer.sampleDecay.seconds&&other.ampEnvelope.releaseSec==layer.ampEnvelope.releaseSec&&
                other.sourceAmpEnvelope.enabled==layer.sourceAmpEnvelope.enabled&&
                (!layer.sourceAmpEnvelope.enabled||other.sourceAmpEnvelope.sameAs(layer.sourceAmpEnvelope))&&
                other.sourcePortamento==layer.sourcePortamento&&
                (other.sourceOscillatorDsp==layer.sourceOscillatorDsp||
                 (other.sourceOscillatorDsp&&layer.sourceOscillatorDsp&&
                  other.sourceOscillatorDsp->samePlaybackSettings(*layer.sourceOscillatorDsp)));
        });
        if(layer.levelDb!=headroom-10.0F*std::log10(static_cast<float>(copies)))return {};
    }
    for(auto& layer:result->layers){
        const auto copies=std::count_if(result->layers.begin(),result->layers.end(),[&](const auto& other){
            return other.multisample==layer.multisample&&other.transposeSemitones==layer.transposeSemitones&&
                other.tuneCents==layer.tuneCents&&other.keyLow==layer.keyLow&&other.keyHigh==layer.keyHigh&&
                other.velocityLow==layer.velocityLow&&other.velocityHigh==layer.velocityHigh&&
                other.sampleDecay.start==layer.sampleDecay.start&&other.sampleDecay.targets==layer.sampleDecay.targets&&
                other.sampleDecay.seconds==layer.sampleDecay.seconds&&other.ampEnvelope.releaseSec==layer.ampEnvelope.releaseSec;
        });
        layer.levelDb=headroom-10.0F*std::log10(static_cast<float>(copies));
    }
    return result;
}

silveton::sampler::ProgramPtr projectPa5xSampleProgramLegacyOscillator1(
        const silveton::sampler::ProgramPtr& source){
    // Reuse the exact import-provenance checks, including unchanged current
    // gains, envelopes, delay, Sound flags and waveform UIDs. Never project a
    // manually edited Program merely because it shares a name or address.
    if(!projectPa5xSampleProgramLegacy69(source))return {};
    auto result=std::make_shared<sampler::Program>(*source);bool changed=false;
    for(auto& layer:result->layers){
        if(!layer.sourceOscillatorDsp||!layer.sourceOscillatorDsp->velocityZonePresent)continue;
        auto profile=std::make_shared<sampler::SourceOscillatorDsp>(*layer.sourceOscillatorDsp);
        profile->velocityZonePresent=false;profile->velocityZoneRaw={{0U,127U}};
        layer.sourceOscillatorDsp=std::move(profile);changed=true;
    }
    if(!changed)return {};
    // Recompute in the original operation order: removing the newly retained
    // input zone can merge formerly identical playback groups. Do not undo dB
    // values by subtraction, which would lose fingerprint float bits.
    constexpr std::size_t stride=129U;
    std::array<int,stride*stride> noteOverlap{};std::size_t overlap=1U;
    for(const auto& layer:result->layers)for(const auto& zone:layer.multisample->zones){
        if(!zone.sample||!zone.sample->valid())continue;
        const int kl=std::max<int>(layer.keyLow,zone.keyLow),kh=std::min<int>(layer.keyHigh,zone.keyHigh);
        const int vl=std::max<int>(layer.velocityLow,zone.velocityLow),vh=std::min<int>(layer.velocityHigh,zone.velocityHigh);
        if(kl>kh||vl>vh)continue;
        const auto k0=static_cast<std::size_t>(kl),k1=static_cast<std::size_t>(kh)+1U;
        const auto v0=static_cast<std::size_t>(vl),v1=static_cast<std::size_t>(vh)+1U;
        ++noteOverlap[k0*stride+v0];--noteOverlap[k1*stride+v0];
        --noteOverlap[k0*stride+v1];++noteOverlap[k1*stride+v1];
    }
    for(std::size_t key=0;key<128U;++key)for(std::size_t velocity=0;velocity<128U;++velocity){
        const auto cell=key*stride+velocity;auto& count=noteOverlap[cell];
        if(key!=0U)count+=noteOverlap[cell-stride];
        if(velocity!=0U)count+=noteOverlap[cell-1U];
        if(key!=0U&&velocity!=0U)count-=noteOverlap[cell-stride-1U];
        if(count>0)overlap=std::max(overlap,static_cast<std::size_t>(count));
    }
    const float headroom=-10.0F*std::log10(static_cast<float>(overlap));
    for(auto& layer:result->layers){
        const auto copies=std::count_if(result->layers.begin(),result->layers.end(),[&](const auto& other){
            return other.multisample==layer.multisample&&other.transposeSemitones==layer.transposeSemitones&&
                other.tuneCents==layer.tuneCents&&other.keyLow==layer.keyLow&&other.keyHigh==layer.keyHigh&&
                other.velocityLow==layer.velocityLow&&other.velocityHigh==layer.velocityHigh&&
                other.sampleDecay.start==layer.sampleDecay.start&&other.sampleDecay.targets==layer.sampleDecay.targets&&
                other.sampleDecay.seconds==layer.sampleDecay.seconds&&other.ampEnvelope.releaseSec==layer.ampEnvelope.releaseSec&&
                other.sourceAmpEnvelope.enabled==layer.sourceAmpEnvelope.enabled&&
                (!layer.sourceAmpEnvelope.enabled||other.sourceAmpEnvelope.sameAs(layer.sourceAmpEnvelope))&&
                other.sourcePortamento==layer.sourcePortamento&&
                (other.sourceOscillatorDsp==layer.sourceOscillatorDsp||
                 (other.sourceOscillatorDsp&&layer.sourceOscillatorDsp&&
                  other.sourceOscillatorDsp->samePlaybackSettings(*layer.sourceOscillatorDsp)));
        });
        layer.levelDb=headroom-10.0F*std::log10(static_cast<float>(copies));
    }
    return result;
}

} // namespace silveton::arranger
