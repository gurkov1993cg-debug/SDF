#include "silveton/arranger/PaSampleIdentity.h"
#include "silveton/arranger/Pa5xProgramSnapshot.h"
#include "silveton/arranger/Pa5xSampleDiskCache.h"
#include "silveton/arranger/Pa5xSoundGraph.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "Pa5xSnapshotArchive.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <stdexcept>
#include <tuple>
#include <utility>

namespace silveton::arranger {
namespace prepared_snapshot {
using snapshot::Archive;
constexpr const char* magic="SILVPROGRAM2";
constexpr std::uint64_t noReference=~std::uint64_t{0};
constexpr std::uint32_t sourceAmpMark=0x45415653U; // SVAE
constexpr std::uint32_t sourceSoundFxMark=0x46535653U; // SVSF
constexpr std::uint32_t sourcePortamentoMark=0x50535653U; // SVSP
constexpr std::uint32_t sourceOscillatorMark=0x444F5653U; // SVOD
constexpr std::uint64_t maximumSourceAmpRecords=1000000U;
constexpr std::uint32_t maximumSourceSoundFxBytes=412U;
constexpr bool sourceOscillatorPayloadSize(std::size_t bytes) noexcept {
    return bytes==178U||bytes==181U; // exact SVOD schema1/schema2 envelopes
}

struct Sample {
    sampler::SampleData value;
    bool streamed{false};
    std::uint64_t resourceId{0};
};
struct Zone {
    sampler::SampleZone value;
    std::uint64_t sample{noReference};
};
struct Multisample {
    std::string name, sourceIdentity;
    std::vector<Zone> zones;
};
struct Layer {
    sampler::ProgramLayer value;
    std::uint64_t multisample{noReference};
};
struct Program {
    std::string name;
    bool mono{false},legato{false};
    float portamentoSec{0};
    std::vector<Layer> layers;
    // Written in an optional trailer, never in the existing base graph.
    std::shared_ptr<const sampler::DrumKeyGroups> drumKeyGroups;
    sampler::SourceVoiceAssignment sourceVoiceAssignment{};
    std::shared_ptr<const Pa5xSoundEffectsRaw> sourceSoundEffects;
};
struct Assignment {
    int msb{-1},lsb{-1},program{-1};
    std::uint64_t sound{noReference};
};
struct Graph {
    std::vector<Sample> samples;
    std::vector<Multisample> multisamples;
    std::vector<Program> programs;
    std::vector<Assignment> assignments;
    std::vector<std::string> warnings;
};
void archiveFields(Archive& a,Sample& entry){
    auto& s=entry.value;
    a(s.name,s.sourcePath,s.sourceIdentity,s.sampleRate,s.channels,s.rootKey,
      s.fineTuneCents,s.interleaved,s.totalFrames,s.loop,entry.streamed,entry.resourceId);
}
void archiveFields(Archive& a,Zone& entry){
    auto& z=entry.value;
    a(entry.sample,z.keyLow,z.keyHigh,z.velocityLow,z.velocityHigh,z.rootKey,
      z.transposeSemitones,z.tuneCents,z.gainDb,z.pan,z.oneShot,z.reverse,
      z.nonTranspose,z.sourceLevelRaw,z.sourceFilterRaw);
}
void archiveFields(Archive& a,Multisample& m){a(m.name,m.sourceIdentity,m.zones);}
void archiveFields(Archive& a,Layer& entry){
    auto& l=entry.value;
    a(l.name,entry.multisample,l.enabled,l.keyLow,l.keyHigh,l.velocityLow,
      l.velocityHigh,l.transposeSemitones,l.tuneCents,l.levelDb,l.pan,
      l.velocityFadeIn,l.velocityFadeOut,l.delaySec,l.damperEnabled,
      l.ampEnvelope,l.filterEnvelope,l.pitchEnvelope,l.pitchEnvelopeCents,
      l.filter,l.lfo1,l.lfo2,l.sampleDecay.start,l.sampleDecay.targets,l.sampleDecay.seconds);
}
void archiveFields(Archive& a,Program& p){a(p.name,p.mono,p.legato,p.portamentoSec,p.layers);}
void archiveFields(Archive& a,Assignment& p){a(p.msb,p.lsb,p.program,p.sound);}
void archiveFields(Archive& a,Graph& g){a(g.samples,g.multisamples,g.programs,g.assignments,g.warnings);}

bool cancelled(const std::atomic<bool>* cancel){return cancel&&cancel->load(std::memory_order_relaxed);}
void require(bool value){if(!value)throw std::runtime_error("Invalid prepared SET graph");}
std::uint64_t sampleUid(const std::string& identity){
    const auto uid=paSampleUid(identity);require(uid!=0);return uid;
}
struct Builder {
    Graph graph;
    std::map<const sampler::SampleData*,std::uint64_t> samples;
    std::map<const sampler::Multisample*,std::uint64_t> multisamples;
    std::map<const sampler::Program*,std::uint64_t> programs;
    std::uint64_t sample(const sampler::SamplePtr& source){
        if(!source)return noReference;
        const auto found=samples.find(source.get());if(found!=samples.end())return found->second;
        require(source->valid());
        const auto id=static_cast<std::uint64_t>(graph.samples.size());samples.emplace(source.get(),id);
        Sample entry;entry.value=*source;entry.streamed=static_cast<bool>(source->stream);
        if(entry.streamed){
            require(source->channels==1U&&source->stream->channels()==source->channels&&
                source->stream->frameCount()==source->frameCount()&&source->stream->sampleRate()==source->sampleRate);
            entry.resourceId=sampleUid(source->sourceIdentity);
        }
        entry.value.stream.reset();graph.samples.push_back(std::move(entry));return id;
    }
    std::uint64_t multisample(const sampler::MultisamplePtr& source){
        if(!source)return noReference;
        const auto found=multisamples.find(source.get());if(found!=multisamples.end())return found->second;
        const auto id=static_cast<std::uint64_t>(graph.multisamples.size());multisamples.emplace(source.get(),id);
        Multisample entry;entry.name=source->name;entry.sourceIdentity=source->sourceIdentity;
        entry.zones.reserve(source->zones.size());
        for(const auto& original:source->zones){Zone zone;zone.value=original;zone.sample=sample(original.sample);zone.value.sample.reset();entry.zones.push_back(std::move(zone));}
        graph.multisamples.push_back(std::move(entry));return id;
    }
    std::uint64_t program(const sampler::ProgramPtr& source){
        if(!source)return noReference;
        const auto found=programs.find(source.get());if(found!=programs.end())return found->second;
        const auto id=static_cast<std::uint64_t>(graph.programs.size());programs.emplace(source.get(),id);
        Program entry;entry.name=source->name;entry.mono=source->mono;entry.legato=source->legato;entry.portamentoSec=source->portamentoSec;entry.drumKeyGroups=source->drumKeyGroups;entry.sourceSoundEffects=source->sourceSoundEffects;entry.sourceVoiceAssignment=source->sourceVoiceAssignment;
        entry.layers.reserve(source->layers.size());
        for(const auto& original:source->layers){Layer layer;layer.value=original;layer.multisample=multisample(original.multisample);layer.value.multisample.reset();entry.layers.push_back(std::move(layer));}
        graph.programs.push_back(std::move(entry));return id;
    }
};
template<class T> T reference(const std::vector<T>& objects,std::uint64_t id){
    if(id==noReference)return {};
    require(id<objects.size());return objects[static_cast<std::size_t>(id)];
}
void validateSample(const Sample& entry){
    const auto& s=entry.value;
    require(s.valid()&&s.rootKey<=127U&&std::isfinite(s.fineTuneCents)&&
        s.interleaved.size()%s.channels==0U&&s.preloadedFrameCount()<=s.frameCount());
    require(std::all_of(s.interleaved.begin(),s.interleaved.end(),[](float v){return std::isfinite(v);}));
    if(s.loop.enabled)require(s.loop.startFrame<s.loop.endFrame&&s.loop.endFrame<=s.frameCount());
    if(entry.streamed)require(s.channels==1U&&entry.resourceId!=0U&&entry.resourceId==sampleUid(s.sourceIdentity));
    else require(s.preloadedFrameCount()==s.frameCount());
}
} // namespace prepared_snapshot

bool savePa5xProgramSnapshot(const std::string& path,
        const std::vector<Pa5xPreparedProgram>& programs,
        const std::vector<std::string>& warnings){
    try{
        prepared_snapshot::Builder builder;builder.graph.warnings=warnings;
        for(const auto& source:programs){
            prepared_snapshot::require(source.msb>=0&&source.msb<=127&&source.lsb>=0&&source.lsb<=127&&source.program>=0&&source.program<=127&&source.sound);
            builder.graph.assignments.push_back({source.msb,source.lsb,source.program,builder.program(source.sound)});
        }
        snapshot::Archive archive;archive(builder.graph);
        std::uint64_t count=static_cast<std::uint64_t>(std::count_if(builder.graph.programs.begin(),builder.graph.programs.end(),
            [](const auto& sound){return sound.drumKeyGroups!=nullptr;}));
        if(count>0U){
            // Keep SILVPROGRAM2 and its old graph intact. Unedited prepared
            // banks remain byte-identical and existing PCM caches stay usable.
            std::uint32_t marker=0x47445653U,version=1U;archive(marker,version,count);
            for(std::uint64_t id=0;id<builder.graph.programs.size();++id){
                const auto& groups=builder.graph.programs[id].drumKeyGroups;if(!groups)continue;
                archive(id);
                for(const auto& key:*groups){
                    prepared_snapshot::require(key.valid());
                    auto group=key.exclusiveGroup;std::uint8_t single=key.singleTrigger?1U:0U,subgroup=key.subgroupChokeOff?1U:0U;
                    auto fade=key.chokeFadeOutMs;archive(group,single,fade,subgroup);
                }
            }
        }
        count=0U;
        for(const auto& sound:builder.graph.programs)for(const auto& layer:sound.layers){
            prepared_snapshot::require(layer.value.sourceAmpEnvelope.valid());
            if(layer.value.sourceAmpEnvelope.present)++count;
        }
        prepared_snapshot::require(count<=prepared_snapshot::maximumSourceAmpRecords);
        if(count>0U){
            // Raw source indices live outside the existing graph ABI. Older
            // snapshots with no SVAE still retain their original behavior.
            std::uint32_t marker=prepared_snapshot::sourceAmpMark,version=3U;
            auto totalPrograms=static_cast<std::uint64_t>(builder.graph.programs.size());
            archive(marker,version,totalPrograms,count);
            for(std::uint64_t id=0;id<builder.graph.programs.size();++id){
                const auto& layers=builder.graph.programs[id].layers;
                for(std::uint64_t layerId=0;layerId<layers.size();++layerId){
                    auto source=layers[layerId].value.sourceAmpEnvelope;if(!source.present)continue;
                    std::uint8_t enabled=source.enabled?1U:0U;
                    archive(id,layerId,enabled,source.levels,source.times);
                    std::uint8_t modulation=source.modulationEncodingSupported?1U:0U;
                    archive(modulation,source.amsSources,source.amsIntensities,source.amsDirections,
                        source.keyboardKeys,source.keyboardRamps);
                    std::uint8_t filterTracking=source.filterKeyboardTrackingPresent?1U:0U;
                    archive(filterTracking,source.filterKeyboardKeys,source.filterKeyboardRamps);
                }
            }
        }
        count=static_cast<std::uint64_t>(std::count_if(builder.graph.programs.begin(),builder.graph.programs.end(),
            [](const auto& sound){return bool(sound.sourceSoundEffects);}));
        if(count>0U){
            std::uint32_t marker=prepared_snapshot::sourceSoundFxMark,version=1U;
            auto totalPrograms=static_cast<std::uint64_t>(builder.graph.programs.size());
            archive(marker,version,totalPrograms,count);
            for(std::uint64_t id=0;id<builder.graph.programs.size();++id){
                const auto& source=builder.graph.programs[id].sourceSoundEffects;if(!source)continue;
                auto bytes=encodePa5xSoundEffects(*source);
                prepared_snapshot::require(!bytes.empty()&&bytes.size()<=prepared_snapshot::maximumSourceSoundFxBytes);
                auto size=static_cast<std::uint32_t>(bytes.size());archive(id,size);
                for(auto& byte:bytes)archive(byte);
            }
        }
        std::uint64_t voiceCount=0U,portamentoCount=0U;
        for(const auto& sound:builder.graph.programs){
            prepared_snapshot::require(sound.sourceVoiceAssignment.valid());
            if(sound.sourceVoiceAssignment.present)++voiceCount;
            for(const auto& layer:sound.layers){
                prepared_snapshot::require(layer.value.sourcePortamento.valid());
                if(layer.value.sourcePortamento.present)++portamentoCount;
            }
        }
        prepared_snapshot::require(portamentoCount<=prepared_snapshot::maximumSourceAmpRecords);
        if(voiceCount>0U||portamentoCount>0U){
            std::uint32_t marker=prepared_snapshot::sourcePortamentoMark,version=2U;
            auto totalPrograms=static_cast<std::uint64_t>(builder.graph.programs.size());
            archive(marker,version,totalPrograms,voiceCount,portamentoCount);
            for(std::uint64_t id=0;id<builder.graph.programs.size();++id){
                auto source=builder.graph.programs[id].sourceVoiceAssignment;
                if(source.present){
                    std::uint8_t modePresent=source.legatoModePresent?1U:0U;
                    archive(id,source.resourceVersion,source.flagsRaw,modePresent,
                        source.legatoModeRaw,source.legatoExtensionRaw);
                }
            }
            for(std::uint64_t id=0;id<builder.graph.programs.size();++id){
                const auto& layers=builder.graph.programs[id].layers;
                for(std::uint64_t layerId=0;layerId<layers.size();++layerId){
                    auto source=layers[layerId].value.sourcePortamento;if(!source.present)continue;
                    std::uint8_t supported=source.encodingSupported?1U:0U;
                    archive(id,layerId,supported,source.resourceVersion,source.flagsRaw,
                            source.timeRaw,source.extensionByteCount,source.extensionRaw);
                }
            }
        }
        count=0U;
        for(const auto& sound:builder.graph.programs)for(const auto& layer:sound.layers){
            const auto& source=layer.value.sourceOscillatorDsp;if(!source)continue;
            prepared_snapshot::require(source->framingValid());++count;
        }
        prepared_snapshot::require(count<=prepared_snapshot::maximumSourceAmpRecords);
        if(count>0U){
            std::uint32_t marker=prepared_snapshot::sourceOscillatorMark,version=1U;
            auto totalPrograms=static_cast<std::uint64_t>(builder.graph.programs.size());
            archive(marker,version,totalPrograms,count);
            for(std::uint64_t id=0;id<builder.graph.programs.size();++id){
                const auto& layers=builder.graph.programs[id].layers;
                for(std::uint64_t layerId=0;layerId<layers.size();++layerId){
                    const auto& source=layers[layerId].value.sourceOscillatorDsp;if(!source)continue;
                    auto bytes=sampler::encodeSourceOscillatorDsp(*source);
                    prepared_snapshot::require(prepared_snapshot::sourceOscillatorPayloadSize(bytes.size()));
                    auto size=static_cast<std::uint32_t>(bytes.size());archive(id,layerId,size);
                    for(auto& byte:bytes)archive(byte);
                }
            }
        }
        return archive.writeFile(path,prepared_snapshot::magic);
    }catch(...){return false;}
}
bool loadPa5xProgramSnapshot(const std::string& path,const std::string& cacheDirectory,
        std::vector<Pa5xPreparedProgram>& programs,std::vector<std::string>& warnings,
        const std::atomic<bool>* cancel){
    using namespace prepared_snapshot;
    try{
        if(cancelled(cancel))return false;
        auto archive=snapshot::Archive::readFile(path,magic);Graph graph;archive(graph);
        bool sawGroups=false,sawSourceAmp=false,sawSourceSoundFx=false,sawSourcePortamento=false,
            sawSourceOscillator=false;
        while(archive.remaining()>0U){
            std::uint32_t marker=0,version=0;archive(marker,version);
            require(version==1U||(marker==sourceAmpMark&&version>=2U&&version<=3U)||
                (marker==sourcePortamentoMark&&version==2U));
            if(marker==0x47445653U){
                std::uint64_t count=0;archive(count);require(!sawGroups&&count<=graph.programs.size());
                sawGroups=true;std::vector<bool> assigned(graph.programs.size(),false);
                for(std::uint64_t i=0;i<count;++i){
                    std::uint64_t id=0;archive(id);require(id<graph.programs.size()&&!assigned[id]);
                    auto groups=std::make_shared<sampler::DrumKeyGroups>();
                    for(auto& key:*groups){
                        std::uint8_t single=0,subgroup=0;archive(key.exclusiveGroup,single,key.chokeFadeOutMs,subgroup);
                        key.singleTrigger=single!=0U;key.subgroupChokeOff=subgroup!=0U;
                        require(single<=1U&&subgroup<=1U&&key.valid());
                    }
                    graph.programs[id].drumKeyGroups=std::move(groups);assigned[id]=true;
                }
            }else if(marker==sourceAmpMark){
                std::uint64_t totalPrograms=0,count=0;archive(totalPrograms,count);
                require(!sawSourceAmp&&totalPrograms==graph.programs.size()&&count<=maximumSourceAmpRecords);
                sawSourceAmp=true;std::set<std::pair<std::uint64_t,std::uint64_t>> assigned;
                for(std::uint64_t i=0;i<count;++i){
                    std::uint64_t id=0,layerId=0;std::uint8_t enabled=0;archive(id,layerId,enabled);
                    require(id<graph.programs.size()&&layerId<graph.programs[id].layers.size()&&enabled<=1U&&
                        assigned.emplace(id,layerId).second);
                    sampler::SourceAmpEnvelope source;source.present=true;source.enabled=enabled!=0U;
                    archive(source.levels,source.times);
                    if(version>=2U){
                        std::uint8_t modulation=0;
                        archive(modulation,source.amsSources,source.amsIntensities,source.amsDirections,
                            source.keyboardKeys,source.keyboardRamps);
                        require(modulation<=1U);source.modulationEncodingSupported=modulation!=0U;
                    }
                    if(version>=3U){
                        std::uint8_t filterTracking=0;
                        archive(filterTracking,source.filterKeyboardKeys,source.filterKeyboardRamps);
                        require(filterTracking<=1U);source.filterKeyboardTrackingPresent=filterTracking!=0U;
                    }
                    require(source.valid());
                    graph.programs[id].layers[layerId].value.sourceAmpEnvelope=source;
                }
            }else if(marker==sourceSoundFxMark){
                std::uint64_t totalPrograms=0,count=0;archive(totalPrograms,count);
                require(!sawSourceSoundFx&&totalPrograms==graph.programs.size()&&count<=graph.programs.size());
                sawSourceSoundFx=true;std::vector<bool> assigned(graph.programs.size(),false);
                for(std::uint64_t i=0;i<count;++i){
                    std::uint64_t id=0;std::uint32_t size=0;archive(id,size);
                    require(id<graph.programs.size()&&!assigned[id]&&size>0U&&size<=maximumSourceSoundFxBytes);
                    std::vector<std::uint8_t> bytes(size);for(auto& byte:bytes)archive(byte);
                    auto effects=std::make_shared<Pa5xSoundEffectsRaw>();std::string error;
                    require(decodePa5xSoundEffects(bytes,*effects,error));
                    graph.programs[id].sourceSoundEffects=std::move(effects);assigned[id]=true;
                }
            }else if(marker==sourcePortamentoMark){
                std::uint64_t totalPrograms=0,voiceCount=0,portamentoCount=0;
                archive(totalPrograms,voiceCount,portamentoCount);
                require(!sawSourcePortamento&&totalPrograms==graph.programs.size()&&
                    voiceCount<=graph.programs.size()&&portamentoCount<=maximumSourceAmpRecords);
                sawSourcePortamento=true;std::vector<bool> voicesAssigned(graph.programs.size(),false);
                for(std::uint64_t i=0;i<voiceCount;++i){
                    std::uint64_t id=0;sampler::SourceVoiceAssignment source;source.present=true;
                    archive(id,source.resourceVersion,source.flagsRaw);
                    if(version>=2U){
                        std::uint8_t modePresent=0U;
                        archive(modePresent,source.legatoModeRaw,source.legatoExtensionRaw);
                        require(modePresent<=1U);source.legatoModePresent=modePresent!=0U;
                    }
                    require(id<graph.programs.size()&&!voicesAssigned[id]&&source.valid());
                    graph.programs[id].sourceVoiceAssignment=source;voicesAssigned[id]=true;
                }
                std::set<std::pair<std::uint64_t,std::uint64_t>> assigned;
                for(std::uint64_t i=0;i<portamentoCount;++i){
                    std::uint64_t id=0,layerId=0;std::uint8_t supported=0;
                    sampler::SourcePortamento source;source.present=true;
                    archive(id,layerId,supported,source.resourceVersion,source.flagsRaw,
                            source.timeRaw,source.extensionByteCount,source.extensionRaw);
                    source.encodingSupported=supported!=0U;
                    require(id<graph.programs.size()&&layerId<graph.programs[id].layers.size()&&
                        supported<=1U&&source.valid()&&assigned.emplace(id,layerId).second);
                    graph.programs[id].layers[layerId].value.sourcePortamento=source;
                }
            }else if(marker==sourceOscillatorMark){
                std::uint64_t totalPrograms=0,count=0;archive(totalPrograms,count);
                require(!sawSourceOscillator&&totalPrograms==graph.programs.size()&&count<=maximumSourceAmpRecords);
                sawSourceOscillator=true;std::set<std::pair<std::uint64_t,std::uint64_t>> assigned;
                for(std::uint64_t i=0;i<count;++i){
                    std::uint64_t id=0,layerId=0;std::uint32_t size=0;archive(id,layerId,size);
                    require(id<graph.programs.size()&&layerId<graph.programs[id].layers.size()&&
                        sourceOscillatorPayloadSize(size)&&assigned.emplace(id,layerId).second);
                    std::vector<std::uint8_t> bytes(size);for(auto& byte:bytes)archive(byte);
                    auto source=std::make_shared<sampler::SourceOscillatorDsp>();std::string error;
                    require(sampler::decodeSourceOscillatorDsp(bytes,*source,error));
                    graph.programs[id].layers[layerId].value.sourceOscillatorDsp=std::move(source);
                }
            }else require(false);
        }
        archive.finish();
        std::vector<sampler::SamplePtr> samples;samples.reserve(graph.samples.size());
        for(auto& entry:graph.samples){
            if(cancelled(cancel))return false;
            validateSample(entry);
            auto sample=std::make_shared<sampler::SampleData>(std::move(entry.value));
            if(entry.streamed){
                Pa5xSampleDiskSpec spec{sample->sourceIdentity,entry.resourceId,sample->frameCount(),sample->sampleRate};
                auto cached=openPa5xSampleDiskCache(cacheDirectory,spec,0U);require(static_cast<bool>(cached));
                sample->stream=std::move(cached.stream);
            }
            samples.push_back(std::move(sample));
        }
        std::vector<sampler::MultisamplePtr> multisamples;multisamples.reserve(graph.multisamples.size());
        std::set<const sampler::SampleData*> reversed;
        for(auto& entry:graph.multisamples){
            if(cancelled(cancel))return false;
            auto multisample=std::make_shared<sampler::Multisample>();
            multisample->name=std::move(entry.name);multisample->sourceIdentity=std::move(entry.sourceIdentity);
            multisample->zones.reserve(entry.zones.size());
            for(auto& zone:entry.zones){
                auto& z=zone.value;z.sample=reference(samples,zone.sample);
                require(z.keyLow<=z.keyHigh&&z.keyHigh<=127U&&z.velocityLow<=z.velocityHigh&&z.velocityHigh<=127U&&
                    z.rootKey<=127U&&std::isfinite(z.tuneCents)&&std::isfinite(z.gainDb)&&std::isfinite(z.pan));
                if(z.reverse&&z.sample&&z.sample->stream&&reversed.insert(z.sample.get()).second)
                    warmPa5xReverseSampleEntry(*z.sample->stream);
                multisample->zones.push_back(std::move(z));
            }
            multisamples.push_back(std::move(multisample));
        }
        std::vector<sampler::ProgramPtr> sounds;sounds.reserve(graph.programs.size());
        for(auto& entry:graph.programs){
            if(cancelled(cancel))return false;
            require(std::isfinite(entry.portamentoSec)&&entry.portamentoSec>=0);
            auto sound=std::make_shared<sampler::Program>();sound->name=std::move(entry.name);
            sound->mono=entry.mono;sound->legato=entry.legato;sound->portamentoSec=entry.portamentoSec;sound->layers.reserve(entry.layers.size());sound->drumKeyGroups=std::move(entry.drumKeyGroups);sound->sourceSoundEffects=std::move(entry.sourceSoundEffects);sound->sourceVoiceAssignment=entry.sourceVoiceAssignment;
            for(auto& layer:entry.layers){auto& l=layer.value;l.multisample=reference(multisamples,layer.multisample);
                require(l.keyLow<=l.keyHigh&&l.keyHigh<=127U&&l.velocityLow<=l.velocityHigh&&l.velocityHigh<=127U&&
                    l.sampleDecay.valid()&&l.sourceAmpEnvelope.valid()&&l.sourcePortamento.valid()&&std::isfinite(l.tuneCents)&&std::isfinite(l.levelDb)&&std::isfinite(l.pan)&&std::isfinite(l.delaySec));
                sound->layers.push_back(std::move(l));}
            sounds.push_back(std::move(sound));
        }
        std::vector<Pa5xPreparedProgram> restored;restored.reserve(graph.assignments.size());
        std::set<std::tuple<int,int,int>> addresses;
        for(const auto& entry:graph.assignments){
            require(entry.msb>=0&&entry.msb<=127&&entry.lsb>=0&&entry.lsb<=127&&entry.program>=0&&entry.program<=127&&
                addresses.emplace(entry.msb,entry.lsb,entry.program).second);
            auto sound=reference(sounds,entry.sound);require(static_cast<bool>(sound));
            restored.push_back({entry.msb,entry.lsb,entry.program,std::move(sound)});
        }
        if(cancelled(cancel))return false;
        programs=std::move(restored);warnings=std::move(graph.warnings);return true;
    }catch(...){return false;}
}
} // namespace silveton::arranger
