#include "silveton/arranger/Pa5xMultisampleImport.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <limits>
#include <set>
#include <sstream>
#include <utility>

namespace silveton::arranger {
namespace {
using Bytes=std::vector<std::uint8_t>;

std::uint16_t be16(const std::uint8_t* p) {
    return static_cast<std::uint16_t>((static_cast<unsigned>(p[0])<<8U)|p[1]);
}
std::int16_t signed16(const std::uint8_t* p) {
    const auto value=be16(p);
    return static_cast<std::int16_t>(value<32768U?static_cast<int>(value):static_cast<int>(value)-65536);
}
std::string uidText(std::uint64_t uid) {
    std::ostringstream out;out<<std::hex<<std::uppercase<<std::setfill('0')<<std::setw(16)<<uid;return out.str();
}
void block(Pa5xMultisampleImport& result,const char* code,std::uint64_t uid,
           std::size_t zone,const std::string& message) {
    const auto duplicate=std::find_if(result.blockers.begin(),result.blockers.end(),[&](const Pa5xMultisampleBlocker& item){
        return item.code==code&&item.resourceId==uid&&item.zoneIndex==zone&&item.message==message;
    });
    if(duplicate==result.blockers.end())result.blockers.push_back({code,uid,zone,message});
}

struct ZoneParameters {
    std::size_t sourceZone{0}, sampleIndex{0};
    std::uint8_t root{0};
    float pitch{0.0F};
    bool derived{false};
};
bool zoneParameters(const Pa5xKmpKeyZone& zone,std::size_t index,std::uint64_t uid,
                    Pa5xMultisampleImport& result,ZoneParameters& parameters) {
    parameters.sourceZone=index;parameters.root=zone.originalNote;
    if(zone.originalNote>127){block(result,"ZONE_ROOT_UNKNOWN",uid,index,"The zone Original Note is not a MIDI key; no replacement root is inferred");return false;}
    if(zone.pitchLevelDecoded){
        const auto& raw=zone.version5Record;
        // The published v1/3/5 reader retains byte2 without naming its function;
        // both supplied v5 banks use 1 here. Other unknown fields must be neutral.
        if(raw[2]!=1U||raw[5]!=0U||raw[9]!=0U||
           std::any_of(raw.begin()+10,raw.end(),[](std::uint8_t value){return value!=0U;})) {
            block(result,"ZONE_PARAMETERS_UNSUPPORTED",uid,index,"The legacy zone contains unsupported flags or non-neutral opaque parameters");return false;
        }
        if(zone.level!=0){block(result,"ZONE_LEVEL_TRANSFER_UNKNOWN",uid,index,"A nonzero Korg zone Level has no verified native gain transfer law");return false;}
        parameters.pitch=static_cast<float>(zone.pitch);return true;
    }
    const auto& raw=zone.version8Record;
    // V8 moves the signed cents value to +4 and duplicates the level words.
    // Only their observed neutral encoding is currently converted; no gain law
    // is invented for the other values 32768+330*n found in the source corpus.
    if(std::any_of(raw.begin()+12,raw.end(),[](std::uint8_t value){return value!=0U;})) {
        block(result,"ZONE_PARAMETERS_UNSUPPORTED",uid,index,"The v8 zone contains unsupported nonzero trailing parameters");return false;
    }
    if(be16(raw.data()+6)!=32768U||be16(raw.data()+8)!=32768U) {
        block(result,"ZONE_LEVEL_TRANSFER_UNKNOWN",uid,index,"The v8 zone Level is not the proven neutral encoding; its gain transfer remains unknown");return false;
    }
    parameters.pitch=static_cast<float>(signed16(raw.data()+4));parameters.derived=true;return true;
}

struct Resource {
    const Pa5xPcmInventory* source{nullptr};
    std::size_t objectIndex{0}, sampleIndex{0};
    Pa5xSamplePlaybackMetadata playback;
    silveton::sampler::SamplePtr native;
    std::string cacheKey;
};

std::string cacheKey(const Pa5xPcmInventory& source,const Pa5xSampleObject& object,
                     const Pa5xKmpSample& sample,const Pa5xSamplePlaybackMetadata& playback) {
    std::ostringstream out;
    out<<source.sourcePath<<'\n'<<uidText(object.resourceId)<<':'<<object.payloadOffset<<':'
       <<object.sampleRate<<':'<<object.encodedSampleCount<<':'<<sample.packedData<<':'
       <<sample.predictor1<<':'<<sample.predictor2<<':'<<static_cast<int>(sample.originalNote)<<':'
       <<static_cast<int>(playback.endConvention)<<':'<<playback.sampleStartFrame<<':'
       <<playback.sampleEndFrame<<':'<<playback.loopEnabled<<':'<<playback.loopStartFrame<<':'<<playback.loopEndFrame;
    return out.str();
}

// Keeps only one encoded PCM file in memory. Calls are grouped by source path.
struct DefaultAudioLoader {
    std::string path;
    Bytes bytes;
    Pa5xSampleIndex index;
    std::size_t maximumSamples{16U*1024U*1024U};
    Pa5xSampleAudio load(const Pa5xPcmInventory& source,std::size_t objectIndex,const Pa5xKmpSample& sample) {
        Pa5xSampleAudio failed;
        if(source.sourcePath!=path){
            path.clear();bytes.clear();index={};
            std::ifstream file(source.sourcePath,std::ios::binary|std::ios::ate);
            if(!file){failed.error="Cannot read the PCM source file";return failed;}
            const auto length=file.tellg();
            if(length<=0||static_cast<std::uint64_t>(length)>256ULL*1024ULL*1024ULL){failed.error="PCM source size exceeds the bounded file decoder limit";return failed;}
            bytes.resize(static_cast<std::size_t>(length));file.seekg(0);
            file.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
            if(!file){bytes.clear();failed.error="PCM source could not be read completely";return failed;}
            index=inspectPa5xSampleBytes(bytes);
            if(!index.valid||index.kind!=Pa5xSampleContainerKind::PcmSamples){bytes.clear();failed.error="PCM source failed revalidation: "+index.error;return failed;}
            path=source.sourcePath;
        }
        if(source.index==nullptr||objectIndex>=source.index->objects.size()||objectIndex>=index.objects.size()){
            failed.error="PCM source directory changed after inspection";return failed;
        }
        const auto& expected=source.index->objects[objectIndex];const auto& fresh=index.objects[objectIndex];
        const auto matches=std::count_if(index.objects.begin(),index.objects.end(),[&](const Pa5xSampleObject& object){
            return object.hasId&&object.resourceId==sample.resourceId;
        });
        if(matches!=1||!expected.hasId||!fresh.hasId||expected.resourceId!=sample.resourceId||
           expected.resourceId!=fresh.resourceId||expected.sampleRate!=fresh.sampleRate||
           expected.sampleFormat!=fresh.sampleFormat||expected.encodedSampleCount!=fresh.encodedSampleCount||
           expected.payloadFlags!=fresh.payloadFlags||expected.rawAudioHeaderWords!=fresh.rawAudioHeaderWords||
           expected.channelTag!=fresh.channelTag||expected.pcmByteOrder!=fresh.pcmByteOrder||
           expected.audioDataBytes!=fresh.audioDataBytes||expected.versionMajor!=fresh.versionMajor||
           expected.versionMinor!=fresh.versionMinor){
            failed.error="PCM resource metadata changed after inspection";return failed;
        }
        return decodePa5xSampleAudio(bytes,fresh,sample,maximumSamples);
    }
};
}

Pa5xMultisampleImport buildPa5xMultisample(
    const Pa5xSampleIndex& kmp,std::size_t multisampleIndex,const std::vector<Pa5xPcmInventory>& pcm,
    const Pa5xSampleAudioLoader& loader,Pa5xMultisampleCache* cache,const Pa5xMultisampleBuildOptions& options) {
    Pa5xMultisampleImport result;
    if(!kmp.valid||!kmp.multisampleMappingDecoded||kmp.kind!=Pa5xSampleContainerKind::Multisamples){
        block(result,"KMP_INVALID",0,0,"A validated KMP table and exact key map are required");return result;
    }
    if(multisampleIndex>=kmp.multisamples.size()){
        block(result,"MULTISAMPLE_MISSING",0,0,"The requested KMP multisample index does not exist");return result;
    }
    const auto& source=kmp.multisamples[multisampleIndex];result.found=true;result.resourceId=source.resourceId;result.name=source.name;
    if(static_cast<std::uint64_t>(source.firstZone)+source.zoneCount>kmp.keyZones.size()){
        block(result,"ZONE_MAP_INVALID",source.resourceId,0,"The multisample zone span exceeds its KMP table");return result;
    }
    std::array<int,128> keyZones{};keyZones.fill(-1);
    std::map<std::size_t,ZoneParameters> zones;
    std::map<std::size_t,Resource> resources;
    std::map<std::uint64_t,std::size_t> usedUids;
    for(std::size_t keyIndex=0;keyIndex<128;++keyIndex){
        const auto local=source.zoneIndices[keyIndex];
        if(local==255U){++result.silentKeys;continue;}
        if(local>=source.zoneCount){block(result,"ZONE_MAP_INVALID",source.resourceId,local,"A keyboard key references a zone outside its multisample");continue;}
        const auto zoneIndex=static_cast<std::size_t>(source.firstZone)+local;const auto& zone=kmp.keyZones[zoneIndex];
        if(zone.sampleIndex==-1){++result.silentKeys;continue;}
        if(zone.sampleIndex<0||static_cast<std::uint64_t>(zone.sampleIndex)>=kmp.samples.size()){
            block(result,"SAMPLE_REFERENCE_INVALID",source.resourceId,zoneIndex,"The zone does not reference an existing KMP sample");continue;
        }
        const auto sampleIndex=static_cast<std::size_t>(zone.sampleIndex);const auto& sample=kmp.samples[sampleIndex];
        if(keyIndex>zone.highNote){block(result,"ZONE_MAP_INVALID",sample.resourceId,zoneIndex,"The key map extends above the zone's declared upper key");continue;}
        ++result.mappedKeys;keyZones[keyIndex]=static_cast<int>(zoneIndex);
        if(zones.find(zoneIndex)==zones.end()){
            ZoneParameters parameters;parameters.sampleIndex=sampleIndex;
            if(zoneParameters(zone,zoneIndex,sample.resourceId,result,parameters)){
                if(parameters.derived&&!result.usesDerivedMetadata)result.warnings.push_back("KMP v8 zone cents and neutral levels were converted from empirically identified fields");
                result.usesDerivedMetadata=result.usesDerivedMetadata||parameters.derived;zones.emplace(zoneIndex,parameters);
            }
        }
        const auto existing=usedUids.emplace(sample.resourceId,sampleIndex);
        if(!existing.second&&existing.first->second!=sampleIndex)block(result,"KMP_SAMPLE_UID_AMBIGUOUS",sample.resourceId,zoneIndex,"Different used KMP sample records share the same resource identifier");
        resources.emplace(sampleIndex,Resource{nullptr,0,sampleIndex,{},{},{}});
    }
    std::size_t totalFrames=0;
    for(auto& entry:resources){
        auto& resource=entry.second;const auto& sample=kmp.samples[resource.sampleIndex];
        std::size_t matches=0;
        for(const auto& inventory:pcm){
            if(inventory.index==nullptr||!inventory.index->valid||inventory.index->kind!=Pa5xSampleContainerKind::PcmSamples){
                block(result,"PCM_INVENTORY_INVALID",sample.resourceId,0,"A supplied PCM inventory is invalid or has another resource type");continue;
            }
            for(std::size_t index=0;index<inventory.index->objects.size();++index){
                const auto& object=inventory.index->objects[index];
                if(object.hasId&&object.resourceId==sample.resourceId){++matches;resource.source=&inventory;resource.objectIndex=index;}
            }
        }
        if(matches==0){result.missingSampleIds.push_back(sample.resourceId);block(result,"PCM_SAMPLE_MISSING",sample.resourceId,0,"No PCM resource has the sample's exact KMP identifier");continue;}
        if(matches!=1){block(result,"PCM_SAMPLE_AMBIGUOUS",sample.resourceId,0,"More than one PCM resource has the same sample identifier");continue;}
        const auto& object=resource.source->index->objects[resource.objectIndex];
        resource.playback=inspectPa5xSamplePlayback(object,sample,options.endConvention);
        if(!resource.playback){block(result,"SAMPLE_PLAYBACK_UNSUPPORTED",sample.resourceId,0,resource.playback.error);continue;}
        for(const auto& uncertainty:resource.playback.uncertainties)result.warnings.push_back(uidText(sample.resourceId)+": "+uncertainty);
        if(object.endPositionRaw!=object.secondaryEndPositionRaw){block(result,"SAMPLE_END_ROLE_UNKNOWN",sample.resourceId,0,"The two PCM end-like fields differ; their separate playback roles are not verified");continue;}
        if(resource.playback.useLoopPitch){block(result,"SAMPLE_LOOP_PITCH_UNSUPPORTED",sample.resourceId,0,"Use Loop Pitch has no verified native tuning conversion");continue;}
        if(object.encodedSampleCount==0||object.encodedSampleCount>options.maximumSamplesPerWaveform||
           object.encodedSampleCount>options.maximumTotalFrames-totalFrames){
            block(result,"DECODE_BUDGET_EXCEEDED",sample.resourceId,0,"The multisample exceeds the caller's decoded waveform budget");continue;
        }
        totalFrames+=object.encodedSampleCount;
        result.usesDerivedMetadata=result.usesDerivedMetadata||sample.predictorsDerived||
            object.versionMajor==2||options.endConvention!=Pa5xSampleEndConvention::InclusiveIndex;
        resource.cacheKey=cacheKey(*resource.source,object,sample,resource.playback);
    }
    if(!result.blockers.empty())return result;
    result.parametersDecoded=true;
    std::vector<Resource*> ordered;for(auto& entry:resources)ordered.push_back(&entry.second);
    std::sort(ordered.begin(),ordered.end(),[](const Resource* first,const Resource* second){
        if(first->source->sourcePath!=second->source->sourcePath)return first->source->sourcePath<second->source->sourcePath;
        return first->objectIndex<second->objectIndex;
    });
    DefaultAudioLoader defaultLoader;defaultLoader.maximumSamples=options.maximumSamplesPerWaveform;
    std::map<std::string,silveton::sampler::SamplePtr> additions;
    for(auto* resource:ordered){
        const auto& sample=kmp.samples[resource->sampleIndex];const auto& object=resource->source->index->objects[resource->objectIndex];
        const auto expectedFrames=resource->playback.sampleEndFrame-resource->playback.sampleStartFrame;
        if(cache!=nullptr){const auto found=cache->samples.find(resource->cacheKey);if(found!=cache->samples.end()){
            const auto& cached=found->second;
            const auto loopStart=resource->playback.loopStartFrame-resource->playback.sampleStartFrame;
            const auto loopEnd=resource->playback.loopEndFrame-resource->playback.sampleStartFrame;
            if(cached==nullptr||cached->channels!=1||cached->sampleRate!=object.sampleRate||cached->frameCount()!=expectedFrames||
               cached->sourceIdentity!=resource->cacheKey||cached->sourcePath!=resource->source->sourcePath||
               cached->rootKey!=sample.originalNote||cached->fineTuneCents!=0.0F||
               cached->loop.enabled!=resource->playback.loopEnabled||
               (cached->loop.enabled&&(cached->loop.startFrame!=loopStart||cached->loop.endFrame!=loopEnd||cached->loop.crossfadeFrames!=0))){
                block(result,"SAMPLE_CACHE_INVALID",sample.resourceId,0,"The scoped sample cache contains inconsistent waveform metadata");continue;
            }
            resource->native=found->second;continue;
        }}
        auto audio=loader?loader(*resource->source,resource->objectIndex,sample):defaultLoader.load(*resource->source,resource->objectIndex,sample);
        if(!audio){block(result,"SAMPLE_DECODE_FAILED",sample.resourceId,0,audio.error.empty()?"The exact PCM waveform could not be decoded":audio.error);continue;}
        if(audio.sampleRate!=object.sampleRate||audio.mono.size()!=object.encodedSampleCount||
           std::any_of(audio.mono.begin(),audio.mono.end(),[](float value){return !std::isfinite(value)||value < -1.0F||value > 1.0F;})){
            block(result,"SAMPLE_DECODE_MISMATCH",sample.resourceId,0,"The decoded waveform does not match its validated PCM metadata");continue;
        }
        auto native=std::make_shared<silveton::sampler::SampleData>();
        native->name=sample.name;native->sourcePath=resource->source->sourcePath;native->sourceIdentity=resource->cacheKey;
        native->sampleRate=audio.sampleRate;native->channels=1;native->rootKey=sample.originalNote;
        const auto first=static_cast<std::size_t>(resource->playback.sampleStartFrame),last=static_cast<std::size_t>(resource->playback.sampleEndFrame);
        if(first==0&&last==audio.mono.size())native->interleaved=std::move(audio.mono);
        else native->interleaved.assign(audio.mono.begin()+static_cast<std::ptrdiff_t>(first),audio.mono.begin()+static_cast<std::ptrdiff_t>(last));
        native->totalFrames=native->interleaved.size();native->loop.enabled=resource->playback.loopEnabled;
        if(native->loop.enabled){native->loop.startFrame=resource->playback.loopStartFrame-resource->playback.sampleStartFrame;native->loop.endFrame=resource->playback.loopEndFrame-resource->playback.sampleStartFrame;}
        resource->native=native;additions.emplace(resource->cacheKey,native);
    }
    if(!result.blockers.empty())return result;
    auto native=std::make_shared<silveton::sampler::Multisample>();native->name=source.name;native->sourceIdentity="KORG-KMP:"+uidText(source.resourceId);
    for(std::size_t first=0;first<128;){
        const int sourceZone=keyZones[first];std::size_t last=first;
        while(last+1U<128U&&keyZones[last+1U]==sourceZone)++last;
        if(sourceZone>=0){
            const auto& parameters=zones.at(static_cast<std::size_t>(sourceZone));const auto& resource=resources.at(parameters.sampleIndex);
            silveton::sampler::SampleZone zone;zone.sample=resource.native;
            zone.keyLow=static_cast<std::uint8_t>(first);zone.keyHigh=static_cast<std::uint8_t>(last);zone.rootKey=parameters.root;
            zone.tuneCents=parameters.pitch;zone.gainDb=resource.playback.gainDb;zone.reverse=resource.playback.reverse;
            // Loop-off is not a PCG gate/ignore-note-off instruction.
            zone.oneShot=false;native->zones.push_back(std::move(zone));
        }
        first=last+1U;
    }
    if(cache!=nullptr)cache->samples.insert(additions.begin(),additions.end());
    result.decodedSampleCount=resources.size();result.samplesDecoded=true;result.ready=true;result.multisample=std::move(native);return result;
}
}
