#pragma once

// Private, versioned native cache. Never used for imported Korg files.
#include "silveton/sampler/SvBankFormat.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>
#include <unistd.h>

namespace silveton::arranger::snapshot {
class Archive {
public:
    // The existing SET preload budget can hold 256 MiB of prefixes. Leave
    // room for graph metadata instead of rejecting a valid full-budget SET.
    static constexpr std::size_t maximumBytes=384U*1024U*1024U;
    bool reading() const noexcept {return reading_;}
    std::size_t remaining() const noexcept {return reading_?data_.size()-offset_:0U;}
    const std::vector<std::uint8_t>& data() const noexcept {return data_;}
    template<class... T> void operator()(T&... value){(one(value),...);}
    void finish() const {if(reading_&&offset_!=data_.size())throw std::runtime_error("Trailing SET snapshot bytes");}
    static Archive readFile(const std::string& path,const std::string& magic){
        std::ifstream input(path,std::ios::binary|std::ios::ate);
        const auto size=input.tellg();
        if(!input||size<static_cast<std::streamoff>(64)||size>static_cast<std::streamoff>(maximumBytes+64U))
            throw std::runtime_error("SET snapshot unavailable");
        input.seekg(0);std::array<std::uint8_t,64> header{};
        input.read(reinterpret_cast<char*>(header.data()),header.size());
        if(magic.empty()||magic.size()>24U||std::memcmp(header.data(),magic.data(),magic.size())!=0||
           header[24]!=1U||header[25]!=sizeof(std::size_t)||header[26]!=sizeof(bool)||header[27]!=sizeof(float))
            throw std::runtime_error("SET snapshot version mismatch");
        const std::uint32_t endian=0x01020304U;
        if(std::memcmp(header.data()+28,&endian,sizeof(endian))!=0)throw std::runtime_error("SET snapshot ABI mismatch");
        Archive result;result.reading_=true;result.data_.resize(static_cast<std::size_t>(size)-header.size());
        input.read(reinterpret_cast<char*>(result.data_.data()),static_cast<std::streamsize>(result.data_.size()));
        if(!input)throw std::runtime_error("Incomplete SET snapshot");
        const auto digest=sampler::sha256(result.data_.data(),result.data_.size());
        if(std::memcmp(digest.data(),header.data()+32,digest.size())!=0)throw std::runtime_error("Damaged SET snapshot");
        return result;
    }
    bool writeFile(const std::string& path,const std::string& magic) const {
        if(reading_||magic.empty()||magic.size()>24U||data_.size()>maximumBytes)return false;
        static std::atomic<unsigned> serial{0};
        const auto pending=path+".pending-"+std::to_string(::getpid())+"-"+std::to_string(serial.fetch_add(1));
        std::array<std::uint8_t,64> header{};std::memcpy(header.data(),magic.data(),magic.size());
        header[24]=1;header[25]=sizeof(std::size_t);header[26]=sizeof(bool);header[27]=sizeof(float);
        const std::uint32_t endian=0x01020304U;std::memcpy(header.data()+28,&endian,sizeof(endian));
        const auto digest=sampler::sha256(data_.data(),data_.size());std::memcpy(header.data()+32,digest.data(),digest.size());
        std::ofstream output(pending,std::ios::binary|std::ios::trunc);
        output.write(reinterpret_cast<const char*>(header.data()),header.size());
        output.write(reinterpret_cast<const char*>(data_.data()),static_cast<std::streamsize>(data_.size()));
        output.flush();const bool okay=static_cast<bool>(output);output.close();
        if(!okay||std::rename(pending.c_str(),path.c_str())!=0){std::remove(pending.c_str());return false;}
        return true;
    }
private:
    bool reading_{false};std::size_t offset_{0},allocated_{0};std::vector<std::uint8_t> data_;
    void bytes(void* value,std::size_t size){
        if(reading_){
            if(size>data_.size()-offset_)throw std::runtime_error("Incomplete SET snapshot field");
            if(size)std::memcpy(value,data_.data()+offset_,size);
            offset_+=size;
        }else{
            if(size>maximumBytes-data_.size())throw std::runtime_error("SET snapshot too large");
            const auto* begin=static_cast<const std::uint8_t*>(value);if(size)data_.insert(data_.end(),begin,begin+size);
        }
    }
    void allocation(std::uint64_t count,std::size_t elementBytes){
        if(count>maximumBytes/std::max<std::size_t>(1U,elementBytes)||
           count*elementBytes>maximumBytes-allocated_)throw std::runtime_error("SET snapshot allocation limit");
        allocated_+=static_cast<std::size_t>(count)*elementBytes;
    }
    template<class T> void one(T& value){
        if constexpr(std::is_trivially_copyable_v<T>)bytes(&value,sizeof(value));
        else archiveFields(*this,value);
    }
    void one(std::string& value){
        std::uint64_t size=value.size();one(size);
        if(reading_){allocation(size,1);if(size>data_.size()-offset_)throw std::runtime_error("Invalid SET string");value.resize(static_cast<std::size_t>(size));}
        bytes(value.data(),value.size());
    }
    template<class T> void one(std::vector<T>& value){
        std::uint64_t size=value.size();one(size);
        if(reading_){allocation(size,sizeof(T));value.resize(static_cast<std::size_t>(size));}
        if constexpr(std::is_trivially_copyable_v<T> && !std::is_same_v<T,bool>)bytes(value.data(),value.size()*sizeof(T));
        else for(auto& entry:value)one(entry);
    }
    template<class T,std::size_t N> void one(std::array<T,N>& value){for(auto& entry:value)one(entry);}
    template<class A,class B> void one(std::pair<A,B>& value){one(value.first);one(value.second);}
    template<class K,class V> void one(std::map<K,V>& value){
        std::uint64_t size=value.size();one(size);
        if(reading_){allocation(size,sizeof(std::pair<const K,V>));value.clear();
            for(std::uint64_t i=0;i<size;++i){K key{};V item{};one(key);one(item);if(!value.emplace(std::move(key),std::move(item)).second)throw std::runtime_error("Duplicate SET snapshot key");}
        }else for(const auto& entry:value){auto key=entry.first;one(key);one(const_cast<V&>(entry.second));}
    }
};
} // namespace silveton::arranger::snapshot
