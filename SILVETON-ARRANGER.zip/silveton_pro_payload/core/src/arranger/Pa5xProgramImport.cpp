#include "silveton/arranger/Pa5xProgramImport.h"
#include <map>
#include <set>

namespace silveton::arranger {
namespace {
void block(Pa5xProgramCandidate& out, const std::string& reason) {
    for (const auto& existing : out.blockers) if (existing == reason) return;
    out.blockers.push_back(reason);
}
struct Location { std::size_t bank{0}, object{0}; };
}
Pa5xProgramCandidate inspectPa5xProgramCandidate(
    const Pa5xPcgSound& sound, const Pa5xSoundReferenceGraph& graph,
    const Pa5xSampleIndex& kmp, const std::vector<Pa5xPcmInventory>& pcm) {
    Pa5xProgramCandidate out;
    out.name = sound.name;
    out.graph = graph;
    out.found = sound.addressKnown;
    if (sound.addressKnown) { out.msb = sound.msb; out.lsb = sound.lsb; out.program = sound.rawProgram; }
    block(out, "Full Sound activation is blocked: original envelope time/gain laws, filter/AMS behavior, effects and articulations are not implemented; extracted raw parameters are not a playable Sound.");
    block(out, "Sample availability is a dependency inventory, not proof of a playable or faithful Korg Sound.");
    if (!sound.addressKnown || sound.resourceClass != 4 || sound.kind != Pa5xPcgSoundKind::Sound) {
        block(out, "A known original normal-Sound address is required."); return out;
    }
    if (!graph.referenceGraphDecoded || graph.resourceVersion != sound.resourceVersion) {
        block(out, graph.error.empty() ? "The versioned Sound reference graph is unavailable or mismatched." : graph.error);
        return out;
    }
    out.referenceGraphDecoded = true;
    if (!kmp.valid || kmp.kind != Pa5xSampleContainerKind::Multisamples || !kmp.multisampleMappingDecoded) {
        block(out, "A validated KMP key-zone mapping is required."); return out;
    }
    std::map<std::uint64_t, std::vector<std::size_t>> multisamples, samples;
    for (std::size_t i = 0; i < kmp.multisamples.size(); ++i) multisamples[kmp.multisamples[i].resourceId].push_back(i);
    for (std::size_t i = 0; i < kmp.samples.size(); ++i) samples[kmp.samples[i].resourceId].push_back(i);
    std::map<std::uint64_t, std::vector<Location>> available;
    bool complete = true, headers = true;
    for (std::size_t bank = 0; bank < pcm.size(); ++bank) {
        const auto* index = pcm[bank].index;
        if (index == nullptr || !index->valid || index->kind != Pa5xSampleContainerKind::PcmSamples) {
            complete = false; block(out, "A supplied PCM inventory is invalid; it cannot establish dependency completeness."); continue;
        }
        for (std::size_t object = 0; object < index->objects.size(); ++object)
            if (index->objects[object].hasId) available[index->objects[object].resourceId].push_back({bank, object});
    }
    std::set<std::uint64_t> selectedSamples;
    for (std::size_t oscillator = 0; oscillator < graph.oscillators.size(); ++oscillator) {
        const auto& osc = graph.oscillators[oscillator];
        for (int layer = 0; layer < 2; ++layer) {
            const auto& source = layer == 0 ? osc.high : osc.low;
            const auto use = pa5xSourceVelocityUse(osc, layer == 0);
            if(use.known&&!use.possible){++out.velocityDisabledSources;continue;}
            if (source.source == Pa5xMultisampleSource::Rom) { out.hasRomDependencies = true; continue; }
            if (source.source != Pa5xMultisampleSource::Ram) {
                complete = false; block(out, "An oscillator source kind is unsupported."); continue;
            }
            Pa5xProgramMultisampleDependency dependency;
            dependency.oscillatorIndex = oscillator; dependency.high = layer == 0; dependency.resourceId = source.multisampleId;
            const auto found = multisamples.find(source.multisampleId);
            if (source.multisampleId == 0 || found == multisamples.end() || found->second.size() != 1) {
                complete = false; block(out, "A RAM multisample UID is missing or ambiguous in KMP.");
                out.multisamples.push_back(dependency); continue;
            }
            dependency.kmpMultisampleIndex = found->second.front();
            const auto& multi = kmp.multisamples[dependency.kmpMultisampleIndex];
            dependency.name = multi.name; dependency.resolved = true;
            std::set<std::uint64_t> ids;
            for (const auto zone : multi.zoneIndices) {
                if (zone == 255U) { ++dependency.emptyKeys; continue; }
                const auto zoneIndex = static_cast<std::uint64_t>(multi.firstZone) + zone;
                if (zone >= multi.zoneCount || zoneIndex >= kmp.keyZones.size()) {
                    complete = false; dependency.resolved = false; block(out, "A KMP key-map index exceeds its multisample zone span."); continue;
                }
                const auto sampleIndex = kmp.keyZones[static_cast<std::size_t>(zoneIndex)].sampleIndex;
                if (sampleIndex == -1) { ++dependency.emptyKeys; continue; }
                if (sampleIndex < 0 || static_cast<std::size_t>(sampleIndex) >= kmp.samples.size()) {
                    complete = false; dependency.resolved = false; block(out, "A KMP key zone references an invalid sample index."); continue;
                }
                ++dependency.mappedKeys;
                const auto uid = kmp.samples[static_cast<std::size_t>(sampleIndex)].resourceId;
                ids.insert(uid); selectedSamples.insert(uid);
            }
            dependency.sampleIds.assign(ids.begin(), ids.end());
            out.multisamples.push_back(dependency);
        }
    }
    if (out.hasRomDependencies) block(out, "Declared ROM multisample sources are not supplied by user PCM files.");
    for (const auto uid : selectedSamples) {
        Pa5xProgramSampleDependency dependency;
        dependency.resourceId = uid;
        const auto mapped = samples.find(uid);
        if (uid == 0 || mapped == samples.end() || mapped->second.size() != 1) {
            complete = false; headers = false; dependency.ambiguous = true;
            block(out, "A sample UID is missing or ambiguous in KMP."); out.samples.push_back(dependency); continue;
        }
        dependency.kmpSampleIndex = mapped->second.front(); dependency.name = kmp.samples[dependency.kmpSampleIndex].name;
        const auto found = available.find(uid);
        if (found == available.end()) {
            complete = false; headers = false; block(out, "A required sample UID is absent from the supplied PCM inventories.");
        } else if (found->second.size() != 1) {
            complete = false; headers = false; dependency.ambiguous = true; block(out, "A required sample UID appears in multiple PCM objects.");
        } else {
            const auto location = found->second.front();
            const auto& object = pcm[location.bank].index->objects[location.object];
            dependency.pcmPresent = true; dependency.pcmSourcePath = pcm[location.bank].sourcePath;
            dependency.pcmObjectIndex = location.object; dependency.audioMetadataDecoded = object.audioMetadataDecoded;
            dependency.encrypted = object.encrypted; dependency.sampleFormat = object.sampleFormat;
            if (!object.audioMetadataDecoded || object.encrypted) { headers = false; block(out, "A present sample has encrypted or unsupported audio metadata."); }
            const auto expectedRate = kmp.samples[dependency.kmpSampleIndex].sampleRate;
            if (object.audioMetadataDecoded && expectedRate != 0 && object.sampleRate != expectedRate) {
                complete = false; headers = false; block(out, "A PCM sample rate contradicts its exact-UID KMP entry.");
            }
        }
        out.samples.push_back(dependency);
    }
    out.ramDependenciesComplete = complete && !out.multisamples.empty() && !out.samples.empty();
    out.allSampleHeadersDecoded = out.ramDependenciesComplete && headers;
    return out;
}
Pa5xProgramCandidate inspectPa5xProgramCandidate(
    const std::vector<std::uint8_t>& bytes, const Pa5xPcgInspection& pcg,
    int msb, int lsb, int program, const Pa5xSampleIndex& kmp,
    const std::vector<Pa5xPcmInventory>& pcm) {
    if (pcg.valid) if (const auto* sound = findPa5xPcgSound(pcg, msb, lsb, program))
        return inspectPa5xProgramCandidate(*sound, inspectPa5xSoundGraph(bytes, *sound), kmp, pcm);
    Pa5xProgramCandidate out;
    out.msb = msb; out.lsb = lsb; out.program = program;
    out.blockers.push_back("The original Korg address is not present in a validated PCG index.");
    return out;
}
} // namespace silveton::arranger
