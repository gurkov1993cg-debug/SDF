#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/KorgResourceContainer.h"
#include "silveton/arranger/KorgMidiInspection.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <limits>
#include <map>
#include <set>
#include <sstream>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumBytes = 64U * 1024U * 1024U;
std::string pathName(const std::vector<std::string>& p) {
    std::string out; for(const auto& n:p){if(!out.empty())out+='/';out+=n;}return out;
}
std::string tag(const std::string& xml, const std::string& label) {
    const std::string needle="<"+label;
    std::size_t pos=0;
    while((pos=xml.find(needle,pos))!=std::string::npos) {
        const auto next=pos+needle.size();
        if(next<xml.size()&&(xml[next]==' '||xml[next]=='\t'||xml[next]=='\r'||xml[next]=='\n'||xml[next]=='/'||xml[next]=='>')) {
            const auto end=xml.find('>',next); if(end!=std::string::npos)return xml.substr(pos,end-pos+1);
        }
        pos=next;
    }
    return {};
}
std::string attr(const std::string& text, const std::string& key) {
    std::size_t pos=0;
    while((pos=text.find(key,pos))!=std::string::npos) {
        if(pos>0 && text[pos-1]!=' '&&text[pos-1]!='\t'&&text[pos-1]!='\r'&&text[pos-1]!='\n'){pos+=key.size();continue;}
        std::size_t n=pos+key.size();while(n<text.size()&&(text[n]==' '||text[n]=='\t'))++n;
        if(n>=text.size()||text[n++]!='='){pos+=key.size();continue;}
        while(n<text.size()&&(text[n]==' '||text[n]=='\t'))++n;
        if(n>=text.size()||(text[n]!='"'&&text[n]!='\''))return {};
        const char quote=text[n++];const auto end=text.find(quote,n);
        return end==std::string::npos?std::string{}:text.substr(n,end-n);
    }
    return {};
}
int integer(const std::string& text, const std::string& key, int fallback=-1) {
    const auto value=attr(text,key);if(value.empty())return fallback;
    std::size_t p=0;int sign=1;if(value[0]=='-'){sign=-1;p=1;}if(p==value.size())return fallback;
    int out=0;for(;p<value.size();++p){if(value[p]<'0'||value[p]>'9'||out>100000000)return fallback;out=out*10+value[p]-'0';}return out*sign;
}
std::string elementBody(const std::string& xml, const std::string& name) {
    const auto opening=tag(xml,name);
    if(opening.empty()||opening.size()<2||opening[opening.size()-2]=='/')return {};
    const auto begin=xml.find(opening);if(begin==std::string::npos)return {};
    const auto content=begin+opening.size();const auto end=xml.find("</"+name+">",content);
    return end==std::string::npos?std::string{}:xml.substr(content,end-content);
}
KorgMidiInspection inspectMidi(const std::vector<std::uint8_t>& bytes,
    KorgMidiPatchScope scope=KorgMidiPatchScope::CombinedChannels) {
    KorgMidiInspection out;
    const auto fail=[&](const char* error) {out.error=error;return out;};
    if(bytes.size()<14||bytes.size()>kMaximumBytes||bytes[0]!='M'||bytes[1]!='T'||bytes[2]!='h'||bytes[3]!='d')
        return fail("Korg embedded MIDI header is missing or oversized");
    const auto be16=[&](std::size_t p){return static_cast<std::uint16_t>((static_cast<unsigned>(bytes[p])<<8U)|bytes[p+1]);};
    const auto be32=[&](std::size_t p){std::uint32_t n=0;for(unsigned i=0;i<4;++i)n=(n<<8U)|bytes[p+i];return n;};
    const auto header=be32(4);if(header<6||header>bytes.size()-8)return fail("Invalid Korg embedded MIDI header length");
    out.format=be16(8);out.ppq=be16(12);const auto count=be16(10);
    if(out.format>1||count==0||count>256||(out.format==0&&count!=1)||out.ppq==0||(out.ppq&0x8000U)!=0)
        return fail("Unsupported Korg embedded MIDI format or timing");
    std::size_t cursor=8+header;
    std::uint64_t order=0;
    for(unsigned index=0;index<count;++index) {
        if(bytes.size()-cursor<8||be32(cursor)!=0x4D54726BU)return fail("Korg embedded MIDI track is missing");
        const auto length=be32(cursor+4);cursor+=8;if(length>bytes.size()-cursor)return fail("Korg embedded MIDI track is truncated");
        const std::size_t trackEnd=cursor+length;KorgMidiTrackInspection track;std::uint32_t tick=0;std::uint8_t running=0;
        const auto variable=[&](std::uint32_t& value) {
            value=0;for(unsigned i=0;i<4;++i){if(cursor>=trackEnd)return false;const auto b=bytes[cursor++];value=(value<<7U)|(b&127U);if((b&128U)==0)return true;}return false;
        };
        while(cursor<trackEnd) {
            if(++out.eventCount>2000000U)return fail("Korg embedded MIDI has too many events");
            const auto eventOrder=order++;
            std::uint32_t delta=0;
            if(!variable(delta)||delta>std::numeric_limits<std::uint32_t>::max()-tick)return fail("Invalid Korg embedded MIDI delta time");
            tick+=delta;
            if(cursor>=trackEnd)return fail("Truncated Korg embedded MIDI event");
            auto status=bytes[cursor];if(status>=0x80U)++cursor;else if(running!=0)status=running;else return fail("Korg embedded MIDI running status has no prior status");
            if(status==0xFFU) {
                running=0;if(cursor>=trackEnd)return fail("Truncated Korg embedded MIDI meta event");
                const auto type=bytes[cursor++];std::uint32_t size=0;
                if(!variable(size)||size>trackEnd-cursor)return fail("Korg embedded MIDI meta event exceeds its track");
                if(type==0x58U) {
                    if(size!=4)return fail("Invalid Korg embedded MIDI time signature");
                    const unsigned numerator=bytes[cursor],power=bytes[cursor+1];
                    if(numerator==0||power>6)return fail("Unsupported Korg embedded MIDI time signature");
                    const unsigned denominator=1U<<power;
                    out.timeSignatures.push_back({tick,static_cast<std::uint16_t>(index),numerator,denominator});
                    if(tick!=0||(track.meterKnown&&(track.numerator!=numerator||track.denominator!=denominator)))track.meterChanged=true;
                    if(!track.meterKnown){track.meterKnown=true;track.numerator=numerator;track.denominator=denominator;}
                } else if(type==0x51U) {
                    if(size!=3)return fail("Invalid Korg embedded MIDI tempo event");
                    const auto us=(static_cast<std::uint32_t>(bytes[cursor])<<16U)|(static_cast<std::uint32_t>(bytes[cursor+1])<<8U)|bytes[cursor+2];
                    if(us==0)return fail("Korg embedded MIDI tempo cannot be zero");
                    out.tempos.push_back({tick,us,static_cast<std::uint16_t>(index)});
                } else if(type==0x03U) {
                    track.name.assign(reinterpret_cast<const char*>(bytes.data()+cursor),size);
                }
                if(type==0x7FU) out.opaqueMidiEvents.push_back({tick,static_cast<std::uint16_t>(index),0xFF,type,
                    std::vector<std::uint8_t>(bytes.begin()+static_cast<std::ptrdiff_t>(cursor),bytes.begin()+static_cast<std::ptrdiff_t>(cursor+size)),eventOrder});
                cursor+=size;
                if(type==0x2FU) {
                    if(size!=0||cursor!=trackEnd)return fail("Invalid Korg embedded MIDI End-of-Track");
                    track.endTick=tick;track.hasEnd=true;break;
                }
            } else if(status==0xF0U||status==0xF7U) {
                running=0;std::uint32_t size=0;
                if(!variable(size)||size>trackEnd-cursor)return fail("Korg embedded MIDI SysEx exceeds its track");
                out.opaqueMidiEvents.push_back({tick,static_cast<std::uint16_t>(index),status,0,
                    std::vector<std::uint8_t>(bytes.begin()+static_cast<std::ptrdiff_t>(cursor),bytes.begin()+static_cast<std::ptrdiff_t>(cursor+size)),eventOrder});
                cursor+=size;
            } else {
                if(status<0x80U||status>=0xF0U)return fail("Unsupported Korg embedded MIDI system event");
                running=status;
                const auto kind=static_cast<std::uint8_t>(status&0xF0U);
                const std::size_t size=(kind==0xC0U||kind==0xD0U)?1U:2U;
                if(size>trackEnd-cursor)return fail("Truncated Korg embedded MIDI channel event");
                for(std::size_t n=0;n<size;++n)if(bytes[cursor+n]>127)return fail("Invalid Korg embedded MIDI data byte");
                track.firstChannelTick=std::min(track.firstChannelTick,tick);
                track.notes=track.notes||kind==0x80U||kind==0x90U;
                out.channelEvents.push_back({tick,static_cast<std::uint16_t>(index),status,bytes[cursor],
                    static_cast<std::uint8_t>(size==2?bytes[cursor+1]:0),eventOrder});
                cursor+=size;
            }
        }
        if(!track.hasEnd)return fail("Korg embedded MIDI track has no End-of-Track");
        out.spanTicks=std::max(out.spanTicks,track.endTick);out.tracks.push_back(std::move(track));cursor=trackEnd;
    }
    if(cursor!=bytes.size())return fail("Trailing bytes after Korg embedded MIDI tracks");
    std::sort(out.channelEvents.begin(),out.channelEvents.end(),[](const auto& a,const auto& b){return a.tick<b.tick||(a.tick==b.tick&&a.order<b.order);});
    std::sort(out.opaqueMidiEvents.begin(),out.opaqueMidiEvents.end(),[](const auto& a,const auto& b){return a.tick<b.tick||(a.tick==b.tick&&a.order<b.order);});
    struct ChannelState {int pendingMsb{-1},pendingLsb{-1};std::size_t patch{std::numeric_limits<std::size_t>::max()};};
    using ChannelStates=std::array<ChannelState,16>;
    const auto observe=[&](const KorgMidiChannelEvent& event,ChannelStates& channels) {
        const auto channel=static_cast<std::size_t>(event.status&15U);auto& state=channels[channel];const auto kind=event.status&0xF0U;
        if(kind==0xB0U&&event.data1==0)state.pendingMsb=event.data2;
        else if(kind==0xB0U&&event.data1==32)state.pendingLsb=event.data2;
        else if(kind==0xC0U) {
            // Bank-select becomes effective with Program Change, not when CC0
            // and CC32 are partially updated. Preserve every timed selection.
            out.patches.push_back({event.tick,static_cast<std::uint8_t>(channel),state.pendingMsb,state.pendingLsb,event.data1,false,event.track,event.order});
            state.patch=out.patches.size()-1;
        } else if(kind==0x90U&&event.data2>0) {
            if(state.patch==std::numeric_limits<std::size_t>::max()) {
                out.patches.push_back({event.tick,static_cast<std::uint8_t>(channel),state.pendingMsb,state.pendingLsb,-1,true,event.track,event.order});
                state.patch=out.patches.size()-1;
            } else out.patches[state.patch].usedByNotes=true;
        }
    };
    ChannelStates channels{};
    if(scope==KorgMidiPatchScope::SetupAndIndependentCvs&&out.format==1&&out.tracks.size()>1) {
        for(const auto& event:out.channelEvents)if(event.track==0)observe(event,channels);
        for(std::size_t track=1;track<out.tracks.size();++track) {
            auto cvChannels=channels;
            for(const auto& event:out.channelEvents)if(event.track==track)observe(event,cvChannels);
        }
    }else for(const auto& event:out.channelEvents)observe(event,channels);
    out.valid=true;return out;
}
Element elementOf(const std::string& name) {
    if(name=="CountIn.scn"||name=="Intro3.scn")return Element::Intro3;
    if(name=="Break.scn")return Element::Break;
    struct Group {const char* prefix;int count;Element first;};
    constexpr Group groups[]{{"Intro",3,Element::Intro1},{"Var",4,Element::Var1},{"Fill",4,Element::Fill1},{"End",3,Element::Ending1}};
    for(const auto& g:groups)for(int n=1;n<=g.count;++n)if(name==std::string(g.prefix)+std::to_string(n)+".scn")return static_cast<Element>(static_cast<int>(g.first)+n-1);
    return Element::Count;
}
int trackOf(const std::string& name) {
    if(name=="Drum.pdc")return 0;
    if(name=="Perc.pdc")return 1;
    if(name=="Bass.pdc")return 2;
    for(int n=1;n<=5;++n)if(name=="Acc"+std::to_string(n)+".pdc")return n+2;
    return -1;
}
void blocker(KorgStyleInspection& out,const std::string& value) {
    if(std::find(out.playbackBlockers.begin(),out.playbackBlockers.end(),value)==out.playbackBlockers.end())out.playbackBlockers.push_back(value);
}
std::vector<std::string> matchingTags(const std::string& xml,const std::string& label) {
    std::vector<std::string> result;
    const auto needle="<"+label;
    std::size_t position=0;
    while((position=xml.find(needle,position))!=std::string::npos){
        const auto next=position+needle.size();
        if(next<xml.size()&&(xml[next]==' '||xml[next]=='\t'||xml[next]=='\r'||xml[next]=='\n'||xml[next]=='/'||xml[next]=='>')){
            const auto end=xml.find('>',next);if(end==std::string::npos)return {};
            result.push_back(xml.substr(position,end-position+1));position=end+1;
        }else position=next;
    }
    return result;
}
std::string xmlResourceName(const std::string& value) {
    std::string result;
    for(std::size_t position=0;position<value.size();++position){
        if(value[position]!='&'){result.push_back(value[position]);continue;}
        const auto end=value.find(';',position+1U);if(end==std::string::npos)return {};
        const auto entity=value.substr(position,end-position+1U);
        if(entity=="&amp;")result.push_back('&');
        else if(entity=="&lt;")result.push_back('<');
        else if(entity=="&gt;")result.push_back('>');
        else if(entity=="&quot;")result.push_back('"');
        else if(entity=="&apos;")result.push_back('\'');
        else return {}; // No custom entity expansion or guessed resource name.
        position=end;
    }
    return result;
}
void readOriginalMutes(KorgStyleInspection& out,const KorgResourceContainer& tree,
                       const std::vector<std::uint8_t>& bytes,const std::vector<std::string>& stylePrefix) {
    const auto xmlAt=[&](const std::vector<std::string>& path){
        const KorgResourceLeaf* found=nullptr;
        for(const auto& leaf:tree.leaves)if(leaf.path==path){if(found)return std::string{};found=&leaf;}
        return found?korgResourceText(bytes,*found):std::string{};
    };
    auto parentScene=stylePrefix;parentScene.back()="SceneDescription.xml";
    const auto outerXml=xmlAt(parentScene),stageXml=xmlAt({"StageDescription.xml"});
    std::string binding;
    bool bindingAmbiguous=false;
    for(const auto& resource:matchingTags(outerXml,"RESOURCE"))
        if(xmlResourceName(attr(resource,"name"))==stylePrefix.back()&&attr(resource,"type")=="StyleClip"){
            if(!binding.empty())bindingAmbiguous=true;
            binding=resource;
        }
    std::array<int,kTracks> internalTracks{{-1,-1,-1,-1,-1,-1,-1,-1}};
    std::array<bool,kTracks> conflicts{};
    // A logical part must retain the same explicit internal track binding in
    // every element that declares it. Filenames identify the same supported
    // logical roles as the MIDI reader, never a guessed Stage-track offset.
    for(const auto& leaf:tree.leaves){
        const auto elementIndex=stylePrefix.size()+1U;
        if(leaf.path.size()!=stylePrefix.size()+3U||!std::equal(stylePrefix.begin(),stylePrefix.end(),leaf.path.begin())||
           leaf.path.back()!="SceneDescription.xml"||elementOf(leaf.path[elementIndex])==Element::Count)continue;
        const auto sceneXml=korgResourceText(bytes,leaf);
        if(sceneXml.find("<!")!=std::string::npos){conflicts.fill(true);continue;}
        std::array<int,kTracks> declared{{-1,-1,-1,-1,-1,-1,-1,-1}};
        std::array<bool,kTracks> seen{};
        for(const auto& resource:matchingTags(sceneXml,"RESOURCE")){
            const int logical=trackOf(attr(resource,"name"));if(logical<0)continue;
            const auto track=static_cast<std::size_t>(logical);
            const int internal=integer(resource,"track");
            if(seen[track]||attr(resource,"type")!="PadClip"||internal<1||internal>256)conflicts[track]=true;
            seen[track]=true;declared[track]=internal;
        }
        for(const auto& element:out.elements)if(element.element==elementOf(leaf.path[elementIndex]))
            for(const auto& clip:element.clips)if(clip.track>=0&&clip.track<kTracks&&!seen[static_cast<std::size_t>(clip.track)])
                conflicts[static_cast<std::size_t>(clip.track)]=true;
        for(std::size_t track=0;track<declared.size();++track)if(seen[track]){
            for(std::size_t other=0;other<declared.size();++other)
                if(track!=other&&seen[other]&&declared[other]==declared[track])conflicts[track]=true;
            if(internalTracks[track]!=-1&&internalTracks[track]!=declared[track])conflicts[track]=true;
            internalTracks[track]=declared[track];
        }
    }
    bool unknown=false;
    const bool xmlSupported=outerXml.find("<!")==std::string::npos&&stageXml.find("<!")==std::string::npos;
    for(std::size_t track=0;track<internalTracks.size();++track){
        const int internal=internalTracks[track];
        if(binding.empty()||bindingAmbiguous||!xmlSupported||conflicts[track]||internal<1||internal>256){unknown=true;continue;}
        const int stageTrack=integer(binding,"t"+std::to_string(internal));
        if(stageTrack<1||stageTrack>256){unknown=true;continue;}
        const auto params=matchingTags(stageXml,"Track"+std::to_string(stageTrack)+"Params");
        if(params.size()!=1U){unknown=true;continue;}
        out.originalFxGroupRaw[track]=integer(params.front(),"fxGroup");
        const int mute=integer(params.front(),"mute");
        if(mute!=0&&mute!=1){unknown=true;continue;}
        out.originalMuteRaw[track]=mute;
    }
    if(unknown)out.warnings.push_back("Some saved Style track mute bindings are absent or ambiguous; unknown tracks start unmuted.");
}
void readOriginalEffects(KorgStyleInspection& out,const KorgResourceContainer& tree,
        const std::vector<std::uint8_t>& bytes,const std::vector<std::string>& stylePrefix) {
    KorgSourceFxContext master;master.scope=KorgSourceFxScope::StyleMaster;
    auto descriptor=stylePrefix;descriptor.push_back("ClipDescription.xml");
    const KorgResourceLeaf* description=nullptr;
    for(const auto& leaf:tree.leaves)if(leaf.path==descriptor){
        if(description){description=nullptr;break;}
        description=&leaf;
    }
    master.resourcePath=pathName(descriptor);
    const auto failMaster=[&](const std::string& why){
        out.sourceEffects=unavailableKorgSourceEffects(master,why);out.warnings.push_back(why);
    };
    if(!description)failMaster("Original Style effect descriptor is missing or ambiguous");
    else {
        const auto xml=korgResourceText(bytes,*description);
        std::string complement;bool ambiguous=false;
        for(const auto& resource:matchingTags(xml,"RESOURCE")){
            const auto value=attr(resource,"complement");if(value.empty())continue;
            if(!complement.empty())ambiguous=true;
            complement=xmlResourceName(value);
            if(complement.empty())ambiguous=true;
        }
        if(ambiguous||xml.find("<!")!=std::string::npos)
            failMaster("Original Style effect complement declaration is ambiguous or unsupported");
        else if(!complement.empty()){
            auto path=stylePrefix;std::size_t start=0;bool validPath=true;
            for(;;){
                const auto end=complement.find('/',start);const auto part=complement.substr(start,end==std::string::npos?end:end-start);
                if(part.empty()||part=="."||part==".."||part.find('\\')!=std::string::npos||part.find('\0')!=std::string::npos){validPath=false;break;}
                path.push_back(part);if(end==std::string::npos)break;start=end+1;
            }
            master.resourcePath=pathName(path);const KorgResourceLeaf* midi=nullptr;
            if(validPath)for(const auto& leaf:tree.leaves)if(leaf.path==path){
                if(midi){validPath=false;break;}midi=&leaf;
            }
            if(!validPath||!midi)failMaster("Original Style effect complement resource is missing or ambiguous");
            else {
                std::vector<std::uint8_t> data(bytes.begin()+static_cast<std::ptrdiff_t>(midi->offset),
                    bytes.begin()+static_cast<std::ptrdiff_t>(midi->offset+midi->length));
                const auto inspected=inspectMidi(data);
                master.ppq=inspected.ppq;
                if(!inspected.valid)failMaster("Original Style effect MIDI is unreadable: "+inspected.error);
                else {
                    out.sourceEffects=makeKorgSourceEffects(master,inspected.channelEvents,inspected.opaqueMidiEvents);
                    if(!out.sourceEffects->complete)out.warnings.push_back(out.sourceEffects->error);
                }
            }
        }
    }
    for(auto& element:out.elements)for(auto& clip:element.clips){
        KorgSourceFxContext context;context.scope=KorgSourceFxScope::StyleTrack;
        context.resourcePath=clip.path;context.logicalPart=clip.track;context.element=static_cast<int>(clip.element);
        context.ppq=clip.ppq;context.setupBoundaryKnown=clip.setupTimingKnown;context.setupTicks=clip.setupTicks;
        context.rawDryOff=clip.rawDryOff;
        if(clip.track>=0&&clip.track<kTracks)context.rawFxGroup=out.originalFxGroupRaw[static_cast<std::size_t>(clip.track)];
        clip.sourceEffects=makeKorgSourceEffects(context,clip.channelEvents,clip.opaqueMidiEvents);
        if(!clip.sourceEffects->complete)out.warnings.push_back(clip.path+": "+clip.sourceEffects->error);
    }
}
} // namespace

KorgMidiInspection inspectKorgMidiBytes(const std::vector<std::uint8_t>& bytes,KorgMidiPatchScope scope) { return inspectMidi(bytes,scope); }

KorgStyleInspection inspectKorgStyleBytes(const std::vector<std::uint8_t>& bytes) {
    KorgStyleInspection out;
    const auto tree=inspectKorgResourceContainer(bytes,kMaximumBytes);
    out.recognized=tree.recognized;
    if(!tree.valid){out.error=tree.error;return out;}
    std::vector<std::string> stylePrefix;
    for(const auto& leaf:tree.leaves)for(std::size_t i=0;i<leaf.path.size();++i) {
        const auto& n=leaf.path[i];
        if(n.size()>4&&n.compare(n.size()-4,4,".stc")==0) {
            std::vector<std::string> prefix(leaf.path.begin(),leaf.path.begin()+static_cast<std::ptrdiff_t>(i+1));
            if(!stylePrefix.empty()&&prefix!=stylePrefix){out.error="Multiple StyleClip resources cannot be flattened into one style";return out;}
            stylePrefix=std::move(prefix);out.name=n.substr(0,n.size()-4);
        }
    }
    if(stylePrefix.empty()){out.error="Korg file has no StyleClip (.stc) resource";return out;}
    for(const auto& leaf:tree.leaves)if(leaf.path.size()==1&&leaf.path[0]=="StageDescription.xml") {
        const auto us=integer(tag(korgResourceText(bytes,leaf),"Tempo"),"value");if(us>0)out.tempoBpm=60000000.0/us;
    }
    if(!std::isfinite(out.tempoBpm)||out.tempoBpm<20||out.tempoBpm>400){out.error="STG global tempo is missing or unsupported";return out;}
    std::map<Element,std::size_t> elementIndices;
    std::map<std::string,std::string> descriptions;
    for(const auto& leaf:tree.leaves)if(leaf.path.back()=="ClipDescription.xml")descriptions[pathName(leaf.path)]=korgResourceText(bytes,leaf);
    for(const auto& leaf:tree.leaves) {
        if(leaf.path.size()<stylePrefix.size()+3||!std::equal(stylePrefix.begin(),stylePrefix.end(),leaf.path.begin()))continue;
        const std::size_t ei=stylePrefix.size()+1;
        if(ei>=leaf.path.size())continue;
        const Element element=elementOf(leaf.path[ei]);if(element==Element::Count)continue;
        auto found=elementIndices.find(element);
        if(found==elementIndices.end()){elementIndices[element]=out.elements.size();out.elements.push_back({element,0,0,{}});found=elementIndices.find(element);}
        auto& sec=out.elements[found->second];
        if(leaf.path.back()=="SceneDescription.xml") {
            const auto ts=tag(korgResourceText(bytes,leaf),"TimeSignature");sec.numerator=integer(ts,"numerator",0);const int power=integer(ts,"denominator",-1);
            if(sec.numerator<=0||power<0||power>6){out.error="Unsupported STG element time signature";return out;}sec.denominator=1<<power;
        }
        if(leaf.path.back()!="Main.mid"||ei+1>=leaf.path.size())continue;
        const int logicalTrack=trackOf(leaf.path[ei+1]);if(logicalTrack<0)continue;
        const auto key=pathName(std::vector<std::string>(leaf.path.begin(),leaf.path.end()-1))+"/ClipDescription.xml";
        const auto desc=descriptions.find(key);if(desc==descriptions.end()){out.error="A style MIDI clip has no ClipDescription.xml";return out;}
        const auto& xml=desc->second;
        if(xml.find("<!")!=std::string::npos){out.error="Unsupported XML declaration/entity content";return out;}
        KorgStyleClip clip;clip.version=integer(tag(xml,"CLIP"),"version");clip.release=integer(tag(xml,"CLIP"),"release");clip.element=element;clip.track=logicalTrack;clip.path=pathName(leaf.path);clip.patternType=attr(tag(xml,"Pattern"),"type");clip.ntt=integer(tag(xml,"NTT"),"value");clip.ntr=integer(tag(xml,"NTR"),"value");
        clip.rawDryOff=integer(tag(xml,"EQSetting"),"dryOff");
        clip.retriggerMode=integer(tag(xml,"ReTrigger"),"mode");
        clip.keyLow=integer(tag(xml,"KeyLow"),"value");clip.keyHigh=integer(tag(xml,"KeyHigh"),"value");clip.wrapAroundDegree=integer(tag(xml,"WrapAroundDegree"),"value");
        const auto range=attr(tag(xml,"KeyRange"),"enabled");clip.keyRangeDeclared=!range.empty();clip.keyRangeEnabled=range=="true"||range=="1"||range=="yes";
        if(clip.keyRangeDeclared&&range!="true"&&range!="false"&&range!="1"&&range!="0"&&range!="yes"&&range!="no"){out.error="Unknown STG KeyRange enabled value";return out;}
        clip.declaredLoopLength=integer(tag(xml,"Loop"),"length");clip.declaredLoopNumber=integer(tag(xml,"Loop"),"number");
        clip.timeStretchingNumerator=integer(tag(xml,"TimeStretching"),"numerator");
        clip.timeStretchingDenominator=integer(tag(xml,"TimeStretching"),"denominator");
        clip.startFineSlide=integer(tag(xml,"Start"),"fineSlide");
        const auto appearing=tag(xml,"AppearingTimeSignature");clip.appearingNumerator=integer(appearing,"numerator",0);const int appearingPower=integer(appearing,"denominator",-1);
        if(clip.appearingNumerator>0&&appearingPower>=0&&appearingPower<=6)clip.appearingDenominator=1<<appearingPower;
        const auto capo=tag(xml,"Capo"),humanize=tag(xml,"HumanizeGuitar");
        clip.guitarCapo=integer(capo,"value");clip.guitarHumanize=integer(humanize,"value");
        clip.guitarStringHigh=integer(tag(xml,"StringHigh"),"value");
        clip.guitarStringLow=integer(tag(xml,"StringLow"),"value");
        clip.guitarNoiseOffset=integer(tag(xml,"NoiseOffset"),"value");
        const auto tension=attr(tag(xml,"Tension"),"enabled");
        if(tension=="true"||tension=="1"||tension=="yes")clip.guitarTension=1;
        else if(tension=="false"||tension=="0"||tension=="no")clip.guitarTension=0;
        // Missing settings in an older inspection use explicit neutral
        // defaults. A present, malformed or out-of-range control must not be
        // clamped into a different original capo/amount.
        clip.guitarParametersValid=(capo.empty()||(clip.guitarCapo>=0&&clip.guitarCapo<=12))&&
            (humanize.empty()||(clip.guitarHumanize>=0&&clip.guitarHumanize<=127));
        const auto originals=elementBody(xml,"ORIGINAL_CHORD");
        for(int cvNumber=1;cvNumber<=6;++cvNumber) {
            const auto cv=tag(originals,"CV"+std::to_string(cvNumber));if(cv.empty())continue;
            KorgStyleCvSource source;source.number=cvNumber;source.root=attr(cv,"root");source.chord=attr(cv,"chord");source.declaredLengthRaw=integer(cv,"length");source.numerator=integer(cv,"numerator",0);source.denominatorExponent=integer(cv,"denominator");
            if(cvNumber==1){clip.originalRoot=source.root;clip.originalChord=source.chord;}
            clip.cvSources.push_back(std::move(source));
        }
        const auto chordTable=elementBody(xml,"CHORD_TABLE");
        std::size_t pos=0;
        while((pos=chordTable.find('<',pos))!=std::string::npos) {
            const auto end=chordTable.find('>',pos);
            if(end==std::string::npos){out.error="Unterminated chord variation table entry";return out;}
            const auto entry=chordTable.substr(pos,end-pos+1);
            const auto nameEnd=entry.find_first_of(" \t\r\n/>",1);
            const auto symbol=entry.substr(1,nameEnd==std::string::npos?std::string::npos:nameEnd-1);
            const int v=integer(entry,"cv");
            if(symbol.empty()||symbol[0]=='/'||v<1||v>6){out.error="Unsupported chord variation reference";return out;}
            if(std::find_if(clip.chordSelections.begin(),clip.chordSelections.end(),[&](const auto& selection){return selection.chord==symbol;})!=clip.chordSelections.end()) {
                out.error="Duplicate chord variation table symbol";return out;
            }
            clip.chordSelections.push_back({symbol,v});
            if(std::find(clip.chordVariations.begin(),clip.chordVariations.end(),v)==clip.chordVariations.end())clip.chordVariations.push_back(v);
            pos=end+1;
        }
        if(clip.ntt>=0||clip.ntr>=0)blocker(out,"SILVETON adapts harmony independently; original Korg NTT/NTR/retrigger codes are not mapped.");
        if(clip.ntt>=0||clip.ntr>=0||clip.retriggerMode>=0)blocker(out,"Raw NTT/NTR/retrigger numeric values are preserved; SILVETON uses its own harmonic and common-tone retrigger policy.");
        if(!clip.originalRoot.empty())blocker(out,"Original chord/key is stored per track and CV; it cannot be replaced by one global C-major assumption.");
        std::vector<std::uint8_t> midi(bytes.begin()+static_cast<std::ptrdiff_t>(leaf.offset),bytes.begin()+static_cast<std::ptrdiff_t>(leaf.offset+leaf.length));
        auto timing=inspectMidi(midi,KorgMidiPatchScope::SetupAndIndependentCvs);
        if(!timing.valid){out.error="Embedded MIDI cannot be indexed safely: "+clip.path+": "+timing.error;return out;}
        clip.opaqueMidiEvents=std::move(timing.opaqueMidiEvents);
        clip.ppq=timing.ppq;clip.eventCount=timing.eventCount;clip.patchSelections=timing.patches;
        clip.channelEvents=timing.channelEvents;clip.midiTracks=timing.tracks;clip.tempos=timing.tempos;clip.timeSignatures=timing.timeSignatures;
        for(const auto& patch:timing.patches) {
            if(patch.msb<0||patch.lsb<0||patch.program<0) {
                blocker(out,"A MIDI patch selection has undeclared bank/program fields; the original state is retained without inventing zero addresses.");
                continue;
            }
            const auto duplicate=std::find_if(clip.patches.begin(),clip.patches.end(),[&](const auto& p) {
                return p.sourceChannel==patch.channel&&p.msb==patch.msb&&p.lsb==patch.lsb&&p.program==patch.program;
            });
            if(duplicate==clip.patches.end()) {
                TrackInfo info;info.used=true;info.addressKnown=true;info.sourceChannel=patch.channel;
                info.msb=static_cast<std::uint8_t>(patch.msb);info.lsb=static_cast<std::uint8_t>(patch.lsb);info.program=static_cast<std::uint8_t>(patch.program);
                clip.patches.push_back(std::move(info));
            }
        }
        if(timing.valid) {
            clip.midiSpanTicks=timing.spanTicks;
            if(timing.format==1&&timing.tracks.size()>=2&&timing.tracks.size()<=7) {
                const auto& setup=timing.tracks[0];
                const std::uint64_t measureNumerator=static_cast<std::uint64_t>(timing.ppq)*4U*setup.numerator;
                bool cvTracksValid=true;
                for(std::size_t cv=1;cv<timing.tracks.size();++cv) {
                    const auto& performance=timing.tracks[cv];
                    const bool absent=performance.endTick==0&&!performance.notes&&
                        performance.firstChannelTick==std::numeric_limits<std::uint32_t>::max();
                    if(!absent&&(performance.endTick<setup.endTick||performance.firstChannelTick<setup.endTick||
                        performance.meterChanged||(performance.meterKnown&&(performance.numerator!=setup.numerator||performance.denominator!=setup.denominator))))cvTracksValid=false;
                }
                if(setup.meterKnown&&!setup.meterChanged&&!setup.notes&&setup.denominator>0&&measureNumerator%setup.denominator==0&&setup.endTick>0&&setup.endTick==measureNumerator/setup.denominator&&cvTracksValid) {
                    clip.setupTimingKnown=true;clip.setupTicks=setup.endTick;clip.performanceTicks=timing.spanTicks-setup.endTick;
                }
            }
        }
        if(!clip.setupTimingKnown)blocker(out,"A MIDI clip's setup/performance boundary is not proven; first-note trimming is not used.");
        sec.clips.push_back(std::move(clip));
    }
    if(out.elements.empty()){out.error="No recognizable style sections were found";return out;}
    for(const auto& e:out.elements)if(e.numerator<=0||e.denominator<=0){out.error="Missing per-element time signature";return out;}
    readOriginalMutes(out,tree,bytes,stylePrefix);
    readOriginalEffects(out,tree,bytes,stylePrefix);
    blocker(out,"Per-element original MSB/LSB/Program addresses require exact PCG and sample-resource resolution; no GM or SILVETON slot substitution is performed.");
    blocker(out,"Embedded MIDI includes Korg setup/pre-roll; its raw SMF span must not be used as the CV loop length.");
    blocker(out,"Full Korg Sound/DNC processing is not implemented by the generic MIDI style engine; original FX profiles are retained and their runtime support is reported separately.");
    out.valid=true;return out;
}
KorgStyleInspection inspectKorgStyleFile(const std::string& path) {
    std::ifstream in(path,std::ios::binary|std::ios::ate);KorgStyleInspection out;
    if(!in){out.error="Cannot open STG file";return out;}const auto size=in.tellg();
    if(size<11||size>static_cast<std::streamoff>(kMaximumBytes)){out.error="STG file size is outside the supported inspection range";return out;}
    std::vector<std::uint8_t> data(static_cast<std::size_t>(size));in.seekg(0);in.read(reinterpret_cast<char*>(data.data()),size);
    if(!in){out.error="STG file read failed";return out;}return inspectKorgStyleBytes(data);
}
std::string korgStyleDiagnostic(const KorgStyleInspection& out) {
    if(!out.valid)return out.error;
    std::ostringstream text;text<<"Korg STG recognized: "<<out.name<<", "<<out.tempoBpm<<" BPM, "<<out.elements.size()<<" sections. Exact playback is not available.";
    for(const auto& why:out.playbackBlockers)text<<"\n"<<why;
    return text.str();
}
namespace {
ChordType chordTypeOf(const std::string& symbol) {
    struct Entry {const char* symbol;ChordType type;};
    static const Entry entries[]{
        {"Maj",ChordType::Major},{"Min",ChordType::Minor},{"Dom7",ChordType::Seventh},
        {"Maj7",ChordType::Major7},{"Min7",ChordType::Minor7},{"Dim",ChordType::Diminished},
        {"Aug",ChordType::Augmented},{"Sus2",ChordType::Sus2},{"Sus4",ChordType::Sus4},
        {"Maj6",ChordType::Major6},{"Min6",ChordType::Minor6},{"Dom7sus4",ChordType::SeventhSus4},
        {"Majb5",ChordType::MajorFlat5},{"Dom7b5",ChordType::SeventhFlat5},
        {"Maj7b5",ChordType::Major7Flat5},{"Maj7sus4",ChordType::Major7Sus4},
        {"Minmaj7",ChordType::MinorMajor7},{"Dim7",ChordType::Diminished7},
        {"Dimmaj7",ChordType::DiminishedMajor7},{"Min7b5",ChordType::Minor7Flat5},
        {"Aug7",ChordType::Augmented7},{"Augmaj7",ChordType::AugmentedMajor7},
        {"MajNo3No5",ChordType::RootOctave},{"MajNo3",ChordType::RootFifth}
    };
    for(const auto& entry:entries)if(symbol==entry.symbol)return entry.type;
    return ChordType::None;
}
int rootOf(const std::string& symbol) {
    static const char* roots[]{"C","Cs","D","Eb","E","F","Fs","G","Ab","A","Bb","B"};
    for(int n=0;n<12;++n)if(symbol==roots[n])return n;
    // Alternate written accidentals are accepted as exact enharmonic notation.
    if(symbol=="C#"||symbol=="Db")return 1;
    if(symbol=="D#"||symbol=="Ds")return 3;
    if(symbol=="F#"||symbol=="Gb")return 6;
    if(symbol=="G#"||symbol=="Gs")return 8;
    if(symbol=="A#"||symbol=="As")return 10;
    return -1;
}
std::uint32_t divisor(std::uint32_t a,std::uint32_t b) {
    while(b!=0){const auto next=a%b;a=b;b=next;}return a;
}
ImportResult nativeStyle(const KorgStyleInspection& inspected) {
    ImportResult out;
    if(!inspected.valid){out.error=inspected.error;return out;}
    std::uint32_t ppq=1;
    for(const auto& element:inspected.elements)for(const auto& clip:element.clips) {
        if(clip.ppq==0){out.error="A Korg clip has no valid PPQ";return out;}
        const auto common=static_cast<std::uint64_t>(ppq/divisor(ppq,clip.ppq))*clip.ppq;
        if(common>65535U){out.error="Korg clip PPQs have no exact common runtime resolution within 65535";return out;}
        ppq=static_cast<std::uint32_t>(common);
    }
    auto style=std::make_shared<Style>();style->name=inspected.name;
    style->nativeKorg=true;style->tempoBpm=inspected.tempoBpm;style->ppq=static_cast<std::uint16_t>(ppq);
    for(std::size_t track=0;track<inspected.originalMuteRaw.size();++track){
        const auto bit=static_cast<std::uint8_t>(1U<<track);
        if(inspected.originalMuteRaw[track]==0||inspected.originalMuteRaw[track]==1){
            style->initialMuteKnownMask=static_cast<std::uint8_t>(style->initialMuteKnownMask|bit);
            if(inspected.originalMuteRaw[track]==1)style->initialMuteMask=static_cast<std::uint8_t>(style->initialMuteMask|bit);
        }
    }
    std::set<std::string> warnings;
    warnings.insert(inspected.warnings.begin(),inspected.warnings.end());
    warnings.insert("Native Korg track/CV timing is loaded; Sound/sample playback and original FX support are assessed by the host. Full Korg Sound/DNC synthesis is not claimed.");
    std::array<std::set<std::uint32_t>,kTracks> addresses;
    std::array<bool,kTracks> unknownAddress{},drumRole{},pitchedRole{};
    bool available=false;
    for(const auto& element:inspected.elements) {
        const auto sectionIndex=static_cast<std::size_t>(element.element);
        if(sectionIndex>=style->sections.size()||element.numerator<=0||element.numerator>255||element.denominator<=0||element.denominator>255) {
            out.error="Korg element or meter is outside runtime bounds";return out;
        }
        auto& section=style->sections[sectionIndex];section.nativePatterns=true;
        section.numerator=static_cast<std::uint8_t>(element.numerator);section.denominator=static_cast<std::uint8_t>(element.denominator);
        for(const auto& clip:element.clips) {
            if(clip.track<0||clip.track>=kTracks){out.error="Korg logical track is outside runtime bounds";return out;}
            const auto track=static_cast<std::size_t>(clip.track);auto& pattern=section.patterns[track];
            if(pattern.present){out.error="Duplicate Korg element/track resources cannot be merged";return out;}
            pattern.present=true;pattern.rawNtt=clip.ntt;pattern.rawNtr=clip.ntr;pattern.rawRetrigger=clip.retriggerMode;
            pattern.keyRangeEnabled=clip.keyRangeDeclared&&clip.keyRangeEnabled;
            pattern.keyLow=clip.keyLow>=0?clip.keyLow:0;pattern.keyHigh=clip.keyHigh>=0?clip.keyHigh:127;
            pattern.wrapAroundDegree=clip.wrapAroundDegree;
            auto& info=style->tracks[track];info.used=true;
            info.role=track==0?TrackRole::Drums:(track==1?TrackRole::Percussion:(track==2?TrackRole::Bass:TrackRole::Accompaniment));
            if(info.name.empty()){static const char* names[]{"Drum","Perc","Bass","ACC1","ACC2","ACC3","ACC4","ACC5"};info.name=names[track];}
            for(const auto& patch:clip.patchSelections) {
                if(patch.msb<0||patch.lsb<0||patch.program<0){unknownAddress[track]=true;continue;}
                const auto address=(static_cast<std::uint32_t>(patch.msb)<<16U)|(static_cast<std::uint32_t>(patch.lsb)<<8U)|static_cast<std::uint32_t>(patch.program);
                if(addresses[track].empty()){info.msb=static_cast<std::uint8_t>(patch.msb);info.lsb=static_cast<std::uint8_t>(patch.lsb);info.program=static_cast<std::uint8_t>(patch.program);info.sourceChannel=patch.channel;}
                addresses[track].insert(address);
            }
            if(clip.patchSelections.empty())unknownAddress[track]=true;
            if(clip.patternType=="Drum"){pattern.mode=NativePatternMode::Drum;drumRole[track]=true;}
            else if(clip.patternType=="Bass"||clip.patternType=="Accompaniment") {
                pitchedRole[track]=true;
                pattern.mode=NativePatternMode::RecordedSourceOnly;
                warnings.insert("ACC/Bass use SILVETON harmonic adaptation; original raw NTT/NTR/retrigger enums are preserved, not interpreted as SILVETON controls.");
            } else if(clip.patternType=="Guitar") {
                pitchedRole[track]=true;pattern.mode=NativePatternMode::Guitar;
                pattern.pa5xGuitarProgression=clip.version==0&&(clip.release==3||clip.release==4);
                if(clip.guitarCapo>=0&&clip.guitarCapo<=12)pattern.guitar.capo=clip.guitarCapo;
                if(clip.guitarHumanize>=0&&clip.guitarHumanize<=127)pattern.guitar.humanize=clip.guitarHumanize;
                if(!clip.guitarParametersValid||clip.guitarCapo<-1||clip.guitarCapo>12||
                   clip.guitarHumanize<-1||clip.guitarHumanize>127||!pattern.guitar.valid()) {
                    pattern.mode=NativePatternMode::Unsupported;
                    warnings.insert("A Guitar capo or humanize setting is malformed or outside its supported range; that track is blocked.");
                } else {
                    warnings.insert("Guitar gestures use SILVETON six-string voicings and timing; original Korg voicing, noise and humanize algorithms are not reproduced.");
                    // The corpus stores High=0/2 and Low=4, while the manual
                    // describes physical strings 1..6. Keep these raw selector
                    // values in the inspection until their mapping is proven.
                    // Explicit editor overrides can choose the physical range.
                    warnings.insert("Original Guitar StringHigh/StringLow selector codes are uncalibrated; the initial range is strings 1..6 and can be edited.");
                    if(clip.guitarCapo<0||clip.guitarHumanize<0)
                        warnings.insert("A Guitar capo or humanize setting is absent; its initial value is zero.");
                    if(clip.guitarNoiseOffset>0||clip.guitarTension>=0)
                        warnings.insert("Original Guitar NoiseOffset and Tension controls are preserved but their Korg processing is not reproduced.");
                }
            } else {
                pitchedRole[track]=true;
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("An unknown Korg pattern type is preserved but blocked.");
            }
            if(clip.patternType=="Guitar"&&track<2){
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("Guitar metadata on a Drum/Percussion part is inconsistent; that track remains blocked.");
            }
            if(!clip.opaqueMidiEvents.empty())warnings.insert("Korg SysEx and sequencer-specific MIDI events are retained by inspection but not applied by native playback; proprietary tempo/articulation processing may be unavailable.");
            if(clip.patternType=="Guitar"&&std::any_of(clip.channelEvents.begin(),clip.channelEvents.end(),[](const auto& event){
                return (event.status&0xF0U)==0x90U&&event.data2>24&&event.data1<12;
            }))warnings.insert("Extended Pa5X Guitar chord commands (velocity above 24) exceed the current SILVETON chord types; retained but not rendered as ordinary notes.");
            if(!clip.setupTimingKnown||clip.midiTracks.size()<2||clip.midiTracks.size()>7) {
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("A Korg setup/CV boundary is unproven; that track is blocked without trimming to its first note.");continue;
            }
            if(clip.version!=0||(clip.release!=3&&clip.release!=4)) {
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("A Korg clip revision is uncalibrated; its events are preserved but that track is blocked.");
            }
            const auto& setup=clip.midiTracks[0];
            if(setup.numerator!=static_cast<unsigned>(element.numerator)||setup.denominator!=static_cast<unsigned>(element.denominator)) {
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("A Korg clip setup meter differs from its element; that track is blocked.");
            }
            if((clip.timeStretchingNumerator>=0||clip.timeStretchingDenominator>=0)&&
                (clip.timeStretchingNumerator!=1||clip.timeStretchingDenominator!=1)) {
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("A Korg time-stretch ratio is unsupported; that track is blocked.");
            }
            if(clip.startFineSlide>0||clip.startFineSlide<-1) {
                pattern.mode=NativePatternMode::Unsupported;
                warnings.insert("A Korg start offset is unsupported; that track is blocked.");
            }
            const auto scale=ppq/clip.ppq;
            const auto scaled=[&](std::uint32_t tick,std::uint32_t& result) {
                const auto value=static_cast<std::uint64_t>(tick)*scale;
                if(value>std::numeric_limits<std::uint32_t>::max())return false;
                result=static_cast<std::uint32_t>(value);return true;
            };
            for(const auto& selection:clip.chordSelections) {
                const auto type=chordTypeOf(selection.chord);const auto index=static_cast<std::size_t>(type);
                if(type==ChordType::None||index>=pattern.chordCv.size()) {warnings.insert("An unknown Korg chord-table symbol has no guessed CV fallback.");continue;}
                pattern.chordCv[index]=static_cast<std::uint8_t>(selection.cv);
            }
            for(const auto& event:clip.channelEvents)if(event.track==0) {
                std::uint32_t tick=0;if(!scaled(event.tick,tick)){out.error="Korg setup event time overflows runtime bounds";return out;}
                pattern.setupEvents.push_back({tick,static_cast<std::uint8_t>(track),event.status,event.data1,event.data2});
            }
            for(std::size_t cv=1;cv<clip.midiTracks.size();++cv) {
                const auto& midiTrack=clip.midiTracks[cv];auto& variation=pattern.cvs[cv-1];
                if(midiTrack.endTick==0)continue; // Explicit empty slot, not CV1.
                if(midiTrack.endTick<=clip.setupTicks){out.error="Korg CV has a nonpositive proven duration";return out;}
                if(!scaled(midiTrack.endTick-clip.setupTicks,variation.lengthTicks)){out.error="Korg CV duration overflows runtime bounds";return out;}
                variation.available=true;section.available=true;available=true;
                section.lengthTicks=std::max(section.lengthTicks,variation.lengthTicks);
                for(const auto& source:clip.cvSources)if(source.number==static_cast<int>(cv)) {
                    const int root=rootOf(source.root);const auto chord=chordTypeOf(source.chord);
                    if(root>=0){variation.sourceRoot=root;variation.sourceRootKnown=true;}
                    if(root>=0&&chord!=ChordType::None)variation.sourceChord=chord;
                }
                if(pattern.mode==NativePatternMode::RecordedSourceOnly&&midiTrack.notes&&variation.sourceChord==ChordType::None)
                    warnings.insert("A pitched Korg CV has no proven source chord for ACC interpretation.");
                for(const auto& event:clip.channelEvents)if(event.track==cv) {
                    if(event.tick<clip.setupTicks||event.tick>midiTrack.endTick){out.error="Korg CV event is outside its proven bounds";return out;}
                    std::uint32_t tick=0;if(!scaled(event.tick-clip.setupTicks,tick)){out.error="Korg CV event time overflows runtime bounds";return out;}
                    variation.events.push_back({tick,static_cast<std::uint8_t>(track),event.status,event.data1,event.data2});
                }
                if(pattern.mode==NativePatternMode::Guitar&&std::any_of(variation.events.begin(),variation.events.end(),[](const auto& event){
                    return (event.status&0xf0)==0x90&&event.data2>0&&event.data1<12;
                })){
                    const bool introOrEnding=sectionIndex<=static_cast<std::size_t>(Element::Intro3)||sectionIndex>=static_cast<std::size_t>(Element::Ending1);
                    if(!introOrEnding||cv>2||!variation.sourceRootKnown)
                        warnings.insert("A Pa5X Guitar progression command is outside Intro/Ending CV1/CV2 or lacks a reference root; retained without playing a false note.");
                }
                if(pattern.mode==NativePatternMode::Guitar&&variation.sourceChord==ChordType::None&&
                   std::any_of(variation.events.begin(),variation.events.end(),[](const auto& event){
                       return (event.status&0xf0)==0x90&&event.data2>0&&event.data1>=48&&event.data1<=95;
                   }))warnings.insert("A Guitar CV contains melody notes C3..B6 without a proven source chord; those melody notes remain silent while string/strum commands and RX notes remain available.");
                if(clip.patternType=="Drum")for(const auto& tempo:clip.tempos)if(tempo.track==cv&&tempo.tick>=clip.setupTicks&&tempo.tick<=midiTrack.endTick) {
                    std::uint32_t tick=0;if(!scaled(tempo.tick-clip.setupTicks,tick)){out.error="Korg CV tempo time overflows runtime bounds";return out;}
                    variation.tempoEvents.push_back({tick,60000000.0/tempo.microsecondsPerQuarter});
                }
            }
        }
    }
    if(!available){out.error="Korg style contains no CV with a proven positive duration";return out;}
    for(std::size_t track=0;track<style->tracks.size();++track) {
        // The sampler's scale/transpose policy is currently assigned per lane.
        // Pattern type, rather than an ACC/Bass/Drum lane name, establishes
        // whether the original MIDI pitches must bypass that policy.
        if(drumRole[track]&&!pitchedRole[track])style->tracks[track].role=TrackRole::Drums;
        if(drumRole[track]&&pitchedRole[track]) {
            for(auto& section:style->sections)if(section.patterns[track].present)
                section.patterns[track].mode=NativePatternMode::Unsupported;
            warnings.insert(style->tracks[track].name+": mixed Drum/pitched pattern role requires per-section pitch policy; lane not sounding.");
        }
        style->tracks[track].addressKnown=!addresses[track].empty()&&!unknownAddress[track];
        style->tracks[track].addressVaries=addresses[track].size()>1;
        if(unknownAddress[track])warnings.insert("Some Korg sound addresses are undeclared; bank/program zero is not substituted.");
    }
    style->playbackWarnings.assign(warnings.begin(),warnings.end());out.warnings=style->playbackWarnings;
    out.style=std::move(style);return out;
}
} // namespace
ImportResult importKorgStyleBytes(const std::vector<std::uint8_t>& bytes) {
    return importKorgStyleInspection(inspectKorgStyleBytes(bytes));
}
ImportResult importKorgStyleInspection(const KorgStyleInspection& inspection) {
    return nativeStyle(inspection);
}
ImportResult importKorgStyleFile(const std::string& path) {
    std::ifstream in(path,std::ios::binary|std::ios::ate);ImportResult out;
    if(!in){out.error="Cannot open STG file";return out;}const auto size=in.tellg();
    if(size<11||size>static_cast<std::streamoff>(kMaximumBytes)){out.error="STG file size is outside the supported import range";return out;}
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));in.seekg(0);in.read(reinterpret_cast<char*>(bytes.data()),size);
    if(!in){out.error="STG file read failed";return out;}return importKorgStyleBytes(bytes);
}
} // namespace silveton::arranger
