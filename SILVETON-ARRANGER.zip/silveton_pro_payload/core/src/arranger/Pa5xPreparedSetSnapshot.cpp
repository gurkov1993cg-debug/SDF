#include "silveton/arranger/Pa5xPreparedSetSnapshot.h"
#include "silveton/arranger/Pa5xCatalogSnapshot.h"
#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/Pa5xSampleDiskCache.h"
#include "Pa5xSnapshotArchive.h"

#include <chrono>
#include <cerrno>
#include <dirent.h>
#include <mutex>
#include <set>
#include <sys/stat.h>

namespace silveton::arranger {
namespace {
std::mutex snapshotMutex;
// Revision 8 retains the original OSC input velocity zone and native Pa
// mixer-part records. Earlier prepared graphs lack these source fields;
// re-import their metadata once, while retaining the separate PCM cache.
// Revision 9 invalidates old artificial OSC attenuation; PCM cache unchanged.
// Revision 10 rebuilds the Program graph for single-sample playback.
constexpr const char* manifestMagic="SVP5SET10";
constexpr const char* previousManifestMagic="SVP5SET1";
bool cancelled(const std::atomic<bool>* cancel){return cancel&&cancel->load(std::memory_order_acquire);}
struct Stamp {
    std::string path;
    bool exists{false};
    std::uint64_t device{0},inode{0},size{0};
    std::int64_t modified{0},modifiedNs{0},changed{0},changedNs{0};
    std::uint32_t mode{0};
    friend void archiveFields(snapshot::Archive& a,Stamp& v){a(v.path,v.exists,v.device,v.inode,v.size,v.modified,v.modifiedNs,v.changed,v.changedNs,v.mode);}
    bool same(const Stamp& v) const {
        return path==v.path&&exists==v.exists&&device==v.device&&inode==v.inode&&size==v.size&&
            modified==v.modified&&modifiedNs==v.modifiedNs&&changed==v.changed&&changedNs==v.changedNs&&mode==v.mode;
    }
};
struct Manifest {
    std::string root,generation;
    std::vector<Stamp> sources;
    friend void archiveFields(snapshot::Archive& a,Manifest& v){a(v.root,v.generation,v.sources);}
};
Stamp inspect(const std::string& path){
    Stamp result;result.path=path;struct stat st{};
    if(::lstat(path.c_str(),&st)!=0)return result;
    result.exists=true;result.device=static_cast<std::uint64_t>(st.st_dev);result.inode=static_cast<std::uint64_t>(st.st_ino);
    result.size=static_cast<std::uint64_t>(st.st_size);result.mode=static_cast<std::uint32_t>(st.st_mode);
#if defined(__APPLE__)
    result.modified=st.st_mtimespec.tv_sec;result.modifiedNs=st.st_mtimespec.tv_nsec;
    result.changed=st.st_ctimespec.tv_sec;result.changedNs=st.st_ctimespec.tv_nsec;
#else
    result.modified=st.st_mtim.tv_sec;result.modifiedNs=st.st_mtim.tv_nsec;
    result.changed=st.st_ctim.tv_sec;result.changedNs=st.st_ctim.tv_nsec;
#endif
    return result;
}
std::string prefix(const std::string& root,const std::string& cache){
    return cache+"/set-"+pa5xSampleContentHash(reinterpret_cast<const std::uint8_t*>(root.data()),root.size());
}
bool validGeneration(const std::string& value){return !value.empty()&&value.size()<100U&&value.find_first_not_of("0123456789-")==std::string::npos;}
bool readManifest(const std::string& path,Manifest& v,const char* magic=manifestMagic){
    try{auto a=snapshot::Archive::readFile(path,magic);a(v);a.finish();return validGeneration(v.generation)&&!v.sources.empty();}catch(...){return false;}
}
void captureDirectory(const std::string& path,unsigned depth,std::vector<Stamp>& stamps,const std::atomic<bool>* cancel){
    if(cancelled(cancel)||depth>32U||stamps.size()>=100000U)throw std::runtime_error("SET source inventory limit");
    auto stamp=inspect(path);if(!stamp.exists)throw std::runtime_error("SET source unavailable");
    const bool directory=S_ISDIR(stamp.mode);stamps.push_back(std::move(stamp));
    if(!directory)return;
    std::unique_ptr<DIR,int(*)(DIR*)> dir(::opendir(path.c_str()),&::closedir);
    if(!dir)throw std::runtime_error("SET directory unavailable");
    std::vector<std::string> names;errno=0;
    while(const auto* entry=::readdir(dir.get())){
        const std::string name=entry->d_name;
        if(name!="."&&name!="..")names.push_back(name);
        if(cancelled(cancel)||names.size()>50000U)throw std::runtime_error("SET source inventory limit");
    }
    if(errno!=0)throw std::runtime_error("Incomplete SET directory");
    std::sort(names.begin(),names.end());
    for(const auto& name:names)captureDirectory(path+"/"+name,depth+1U,stamps,cancel);
}

bool unchanged(const Manifest& manifest,const std::atomic<bool>* cancel){
    for(const auto& stamp:manifest.sources){
        if(cancelled(cancel)||stamp.path.compare(0,manifest.root.size(),manifest.root)!=0||
            (stamp.path.size()!=manifest.root.size()&&stamp.path[manifest.root.size()]!='/')||
            !stamp.same(inspect(stamp.path)))return false;
    }
    return true;
}
bool catalogStyleSourcesKnown(const Manifest& manifest,const Pa5xKstCatalog& catalog){
    std::set<std::string> remaining;
    for(const auto& style:catalog.styles){
        if(style.originalSettings.indexed&&style.originalSettings.valid())continue;
        std::string physical=style.path;(void)paStyleSlot(style.path,&physical);
        remaining.insert(std::move(physical));
    }
    for(const auto& source:manifest.sources)
        if(source.exists&&S_ISREG(source.mode))remaining.erase(source.path);
    return remaining.empty();
}
void removeParts(const std::string& base){for(const auto* suffix:{".catalog",".bank",".programs"})std::remove((base+suffix).c_str());}
}

class Pa5xSnapshotSourceState {
public:
    Manifest manifest;
};
std::shared_ptr<const Pa5xSnapshotSourceState> capturePa5xPreparedSetSources(
        const std::string& root,const std::atomic<bool>* cancel){
    try{
        if(root.empty())return {};
        auto result=std::make_shared<Pa5xSnapshotSourceState>();result->manifest.root=root;
        captureDirectory(root,0,result->manifest.sources,cancel);
        if(!unchanged(result->manifest,cancel))return {};
        return result;
    }catch(...){return {};}
}

bool loadPa5xPreparedSetSnapshot(const std::string& root,const std::string& cache,
        Pa5xPreparedSetSnapshot& result,const std::atomic<bool>* cancel,
        const std::function<void(const KstProgress&)>& progress){
    std::lock_guard<std::mutex> lock(snapshotMutex);
    try{
        Manifest saved;const auto base=prefix(root,cache);
        if(!readManifest(base+".snapshot",saved))return false;
        if(saved.root!=root||!unchanged(saved,cancel))return false;
        const auto parts=base+"-"+saved.generation;
        Pa5xPreparedSetSnapshot restored;restored.bank=std::make_shared<Pa5xSetBank>();
        bool needsStyleMetadataUpgrade=false,needsNativeTrackUpgrade=false;
        if(!loadPa5xCatalogSnapshot(parts+".catalog",restored.index,restored.catalog,&needsStyleMetadataUpgrade,&needsNativeTrackUpgrade)||needsNativeTrackUpgrade||restored.index.rootPath!=root||
            cancelled(cancel)||!restored.bank->loadSnapshot(parts+".bank",root)||cancelled(cancel)||
            !loadPa5xProgramSnapshot(parts+".programs",cache,restored.programs,restored.warnings,cancel)||
            !unchanged(saved,cancel))return false;
        if(needsStyleMetadataUpgrade){
            // Older/missing source summaries need only a metadata upgrade.
            // The loaded bank, prepared Programs and decoded PCM remain
            // exactly as restored above.
            if(cancelled(cancel)||!catalogStyleSourcesKnown(saved,restored.catalog)||
                !refreshPa5xKstStyleMetadata(restored.catalog,progress,cancel)||
                !unchanged(saved,cancel))return false;
            for(const auto& style:restored.catalog.styles)
                if(!style.originalSettings.indexed||!style.originalSettings.valid())return false;
            const bool stored=savePa5xCatalogSnapshot(parts+".catalog",restored.index,restored.catalog);
            // A cancellation or source edit during the atomic catalog write
            // must not publish this restore. The unchanged manifest continues
            // to reject a newly stale catalog on the next attempt as well.
            if(!unchanged(saved,cancel))return false;
            if(stored){
                restored.index.diagnostics.push_back({KstSeverity::Info,"STYLE_SETTINGS_UPGRADED",{},
                    "Original Style track settings loaded; existing sample cache and instruments retained"});
            }else{
                const std::string message="Original Style settings loaded, but their updated catalog could not be saved for the next startup";
                restored.warnings.push_back(message);
                restored.index.diagnostics.push_back({KstSeverity::Warning,"STYLE_SETTINGS_CACHE_WRITE_FAILED",{},message});
            }
        }
        // Import activity belongs to the earlier LOAD, not this restoration.
        auto& diagnostics=restored.index.diagnostics;
        diagnostics.erase(std::remove_if(diagnostics.begin(),diagnostics.end(),[](const auto& d){return d.code=="PCM_CACHE_ACTIVITY"||d.code=="SET_SNAPSHOT_RESTORED";}),diagnostics.end());
        diagnostics.push_back({KstSeverity::Info,"SET_SNAPSHOT_RESTORED",{},"Saved SET restored: no source PCM reads, no sample decoding, no instrument rebuild"});
        result=std::move(restored);return true;
    }catch(...){return false;}
}
bool savePa5xPreparedSetSnapshot(const std::string& cache,const Pa5xKstIndex& index,
        const Pa5xKstCatalog& catalog,const Pa5xSetBank& bank,
        const std::vector<Pa5xPreparedProgram>& programs,const std::vector<std::string>& warnings,
        const std::shared_ptr<const Pa5xSnapshotSourceState>& sourceState,
        const std::atomic<bool>* cancel){
    std::lock_guard<std::mutex> lock(snapshotMutex);
    std::string parts;
    try{
        if(cancelled(cancel)||index.rootPath.empty()||!index.recognized||index.cancelled||
            !sourceState||sourceState->manifest.root!=index.rootPath||!unchanged(sourceState->manifest,cancel))return false;
        const auto base=prefix(index.rootPath,cache);Manifest previous;
        if(!readManifest(base+".snapshot",previous)&&!readManifest(base+".snapshot",previous,"SVP5SET9")&&!readManifest(base+".snapshot",previous,"SVP5SET8")&&!readManifest(base+".snapshot",previous,"SVP5SET7")&&
            !readManifest(base+".snapshot",previous,"SVP5SET6")&&!readManifest(base+".snapshot",previous,"SVP5SET5")&&!readManifest(base+".snapshot",previous,"SVP5SET4")&&!readManifest(base+".snapshot",previous,"SVP5SET3")&&!readManifest(base+".snapshot",previous,"SVP5SET2"))(void)readManifest(base+".snapshot",previous,previousManifestMagic);
        static std::atomic<unsigned> sequence{0};
        Manifest saved=sourceState->manifest;
        saved.generation=std::to_string(std::chrono::system_clock::now().time_since_epoch().count())+"-"+std::to_string(::getpid())+"-"+std::to_string(sequence.fetch_add(1));
        parts=base+"-"+saved.generation;
        if(!savePa5xCatalogSnapshot(parts+".catalog",index,catalog)||cancelled(cancel)||
            !bank.saveSnapshot(parts+".bank")||cancelled(cancel)||
            !savePa5xProgramSnapshot(parts+".programs",programs,warnings)||!unchanged(saved,cancel)){
            removeParts(parts);return false;
        }
        snapshot::Archive a;a(saved);
        if(!a.writeFile(base+".snapshot",manifestMagic)){removeParts(parts);return false;}
        if(validGeneration(previous.generation)&&previous.generation!=saved.generation)removeParts(base+"-"+previous.generation);
        return true;
    }catch(...){if(!parts.empty())removeParts(parts);return false;}
}
} // namespace silveton::arranger
