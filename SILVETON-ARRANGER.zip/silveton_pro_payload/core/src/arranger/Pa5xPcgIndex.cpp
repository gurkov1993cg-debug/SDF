#include "silveton/arranger/Pa5xPcgIndex.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <limits>
#include <set>
#include <utility>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumFile = 64U * 1024U * 1024U;
constexpr std::uint32_t kRoot = 0x01000114U;
constexpr std::uint32_t kMetadata = 0x02000018U;
constexpr std::uint32_t kDirectory = 0x05010018U;
constexpr std::uint32_t kCrossReference = 0xFE000018U;

std::uint16_t be16(const std::vector<std::uint8_t>& b, std::size_t p) noexcept {
    return static_cast<std::uint16_t>((static_cast<unsigned>(b[p]) << 8U) | b[p + 1]);
}
std::uint32_t be32(const std::vector<std::uint8_t>& b, std::size_t p) noexcept {
    std::uint32_t value = 0;
    for (int i = 0; i < 4; ++i) value = (value << 8U) | b[p + static_cast<std::size_t>(i)];
    return value;
}
std::uint64_t be64(const std::vector<std::uint8_t>& b, std::size_t p) noexcept {
    std::uint64_t value = 0;
    for (int i = 0; i < 8; ++i) value = (value << 8U) | b[p + static_cast<std::size_t>(i)];
    return value;
}
bool magic(const std::vector<std::uint8_t>& b, std::size_t p, const char* value) noexcept {
    return p <= b.size() && b.size() - p >= 4 && b[p] == static_cast<std::uint8_t>(value[0]) &&
        b[p + 1] == static_cast<std::uint8_t>(value[1]) &&
        b[p + 2] == static_cast<std::uint8_t>(value[2]) &&
        b[p + 3] == static_cast<std::uint8_t>(value[3]);
}
struct Chunk { std::uint32_t tag; std::size_t offset, payload, length; };

void knownAddress(Pa5xPcgSound& sound, const std::string& sourcePath) {
    // Format facts: KORG-Tools SoundBankNumber.hpp documents the older raw
    // codes 09/0A/0B/0C/0D; Set.hpp documents MSB 121 (normal), 120 (drum)
    // and LSB 64 + zero-based User ordinal. The additional Pa5X raw codes are
    // observed in the canonical USER05..08/USERDK02..03 files in the uploaded
    // corpus. The same corpus's independent MIDI selectors corroborate the
    // 64..71 normal User bank range. No implementation text is copied.
    // Requiring the complete bank context avoids extending a raw-code guess
    // to another model, a renamed bank or an unknown resource revision.
    if (sound.resourceClass != 4 || sound.resourceVersion[1] != 0) return;
    switch (sound.resourceVersion[0]) {
        case 0: case 1: case 2: case 3: case 5: case 6: case 7: case 8: break;
        default: return;
    }
    const auto slash = sourcePath.find_last_of("/\\");
    std::string name = slash == std::string::npos ? sourcePath : sourcePath.substr(slash + 1);
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    struct Bank {
        const char* name;
        std::uint8_t raw, msb, lsb;
        Pa5xPcgSoundKind kind;
        Pa5xPcgAddressEvidence evidence;
    };
    using Kind = Pa5xPcgSoundKind;
    using Evidence = Pa5xPcgAddressEvidence;
    constexpr Bank banks[] = {
        {"user01.pcg",0x09,121,64,Kind::Sound,Evidence::LegacyBankTableAndCorpus},
        {"user02.pcg",0x0A,121,65,Kind::Sound,Evidence::LegacyBankTableAndCorpus},
        {"user03.pcg",0x0C,121,66,Kind::Sound,Evidence::LegacyBankTableAndCorpus},
        {"user04.pcg",0x0D,121,67,Kind::Sound,Evidence::LegacyBankTableAndCorpus},
        {"user05.pcg",0x18,121,68,Kind::Sound,Evidence::CanonicalPa5xBankContext},
        {"user06.pcg",0x19,121,69,Kind::Sound,Evidence::CanonicalPa5xBankContext},
        {"user07.pcg",0x1B,121,70,Kind::Sound,Evidence::CanonicalPa5xBankContext},
        {"user08.pcg",0x1C,121,71,Kind::Sound,Evidence::CanonicalPa5xBankContext},
        {"userdk01.pcg",0x0B,120,64,Kind::DrumKit,Evidence::LegacyBankTableAndCorpus},
        {"userdk02.pcg",0x14,120,65,Kind::DrumKit,Evidence::CanonicalPa5xBankContext},
        {"userdk03.pcg",0x1A,120,66,Kind::DrumKit,Evidence::CanonicalPa5xBankContext}
    };
    for (const auto& bank : banks) if (name == bank.name && sound.internalBank == bank.raw) {
        sound.kind = bank.kind; sound.addressKnown = true;
        sound.addressEvidence = bank.evidence; sound.msb = bank.msb; sound.lsb = bank.lsb;
        return;
    }
}
} // namespace

Pa5xPcgInspection inspectPa5xPcgBytes(const std::vector<std::uint8_t>& bytes,
                                    const std::string& sourcePath) {
    Pa5xPcgInspection out;
    out.sourcePath = sourcePath;
    out.fileSize = bytes.size();
    const auto fail = [&](const char* error) {
        out.error = error;
        out.valid = false;
        return out;
    };
    if (bytes.size() < 8 || bytes.size() > kMaximumFile)
        return fail("PCG file size is outside the supported 8-byte to 64-MiB bounds");
    std::copy_n(bytes.begin(), 4, out.fileTag.begin());
    if (be32(bytes, 0) != kRoot) return fail("Unrecognized Pa5X bank root/version");
    out.recognized = true;
    if (be32(bytes, 4) != bytes.size() - 8)
        return fail("PCG root length does not match the complete file");

    std::vector<Chunk> chunks;
    std::size_t position = 8;
    while (position < bytes.size()) {
        if (bytes.size() - position < 8) return fail("Truncated PCG object header");
        const auto length = be32(bytes, position + 4);
        if (length > bytes.size() - position - 8) return fail("PCG object exceeds its file boundary");
        chunks.push_back({be32(bytes, position), position, position + 8, length});
        if (chunks.size() > 100000) return fail("PCG object count exceeds the supported bound");
        position += 8 + length;
    }
    if (chunks.size() < 4 || chunks.front().tag != kMetadata || chunks.front().length != 12 ||
        !magic(bytes, chunks.front().payload + 7, "KORF") ||
        (chunks[1].tag != kDirectory && chunks[1].tag != 0x05000018U) || chunks.back().tag != kCrossReference)
        return fail("Unsupported PCG KORF metadata, directory or cross-reference layout");

    const auto& directory = chunks[1];
    const std::size_t directoryEnd = directory.payload + directory.length;
    position = directory.payload;
    std::set<std::pair<unsigned, unsigned>> rawAddresses;
    bool unknownBank = false;
    // Older Pa banks store one fixed 24-byte directory record per object.
    // The xref and each typed payload below must still agree with the directory.
    if (directory.tag == 0x05000018U) {
        if (directory.length % 24 != 0) return fail("Truncated legacy PCG directory");
        for (; position < directoryEnd; position += 24) {
            Pa5xPcgSound sound;
            sound.indexOrdinal = out.sounds.size();
            sound.recordOffset = position;
            sound.recordLength = 24;
            std::copy_n(bytes.data() + position, 18, sound.rawName.begin());
            sound.name.assign(sound.rawName.begin(), std::find(sound.rawName.begin(), sound.rawName.end(), 0));
            while (!sound.name.empty() && sound.name.back() == ' ') sound.name.pop_back();
            sound.resourceClass = bytes[position + 18];
            sound.internalBank = bytes[position + 19];
            sound.rawProgram = bytes[position + 20];
            sound.resourceVersion = {bytes[position + 21], bytes[position + 22]};
            if (sound.resourceClass != 4 || sound.rawProgram > 127 ||
                !rawAddresses.emplace(sound.internalBank, sound.rawProgram).second)
                return fail("Invalid or duplicate legacy PCG address");
            knownAddress(sound, sourcePath);
            unknownBank = unknownBank || !sound.addressKnown;
            out.sounds.push_back(std::move(sound));
        }
    }
    while (position < directoryEnd) {
        if (directoryEnd - position < 2) return fail("Truncated PCG directory record size");
        const auto length = be16(bytes, position);
        if (length < 6 || length > directoryEnd - position - 2)
            return fail("PCG directory record exceeds its table boundary");
        const std::size_t recordEnd = position + 2 + length;
        const std::size_t fieldsEnd = recordEnd - 4;
        std::size_t field = position + 2;
        if (fieldsEnd - field < 2) return fail("Truncated PCG property count");
        const auto count = be16(bytes, field); field += 2;
        if (count == 0 || count > 64) return fail("Unsupported PCG property count");
        Pa5xPcgSound sound;
        sound.indexOrdinal = out.sounds.size();
        sound.recordOffset = position;
        sound.recordLength = static_cast<std::size_t>(length) + 2;
        bool address = false, name = false, version = false;
        std::set<std::uint16_t> seen;
        for (unsigned i = 0; i < count; ++i) {
            if (fieldsEnd - field < 4) return fail("Truncated PCG property header");
            const auto type = be16(bytes, field);
            const auto size = be16(bytes, field + 2); field += 4;
            if (size > fieldsEnd - field) return fail("PCG property exceeds its record boundary");
            if (!seen.insert(type).second) return fail("Duplicate PCG property in one record");
            if (type == 0) {
                if (size != 3) return fail("Unsupported PCG resource address property");
                sound.resourceClass = bytes[field]; sound.internalBank = bytes[field + 1];
                sound.rawProgram = bytes[field + 2]; address = true;
            } else if (type == 1) {
                if (size != 2) return fail("Unsupported PCG resource version property");
                std::copy_n(bytes.begin() + static_cast<std::ptrdiff_t>(field), 2, sound.resourceVersion.begin());
                version = true;
            } else if (type == 2) {
                if (size != sound.rawName.size()) return fail("Unsupported PCG fixed-name field length");
                std::copy_n(bytes.begin() + static_cast<std::ptrdiff_t>(field), size, sound.rawName.begin());
                const auto nul = std::find(sound.rawName.begin(), sound.rawName.end(), 0);
                sound.name.assign(sound.rawName.begin(), nul);
                while (!sound.name.empty() && sound.name.back() == ' ') sound.name.pop_back();
                name = true;
            } else if (type == 4) {
                if (size != 8) return fail("Unsupported PCG object ID property length");
                sound.rawObjectId = be64(bytes, field); sound.objectIdPresent = true;
            } else if (type == 5 && size != 7) {
                return fail("Unsupported PCG timestamp property length");
            }
            field += size;
        }
        if (field != fieldsEnd || !address || !name || !version)
            return fail("PCG record has missing fields or unaccounted property bytes");
        if (sound.resourceClass != 4 || sound.rawProgram > 127)
            return fail("PCG record is not a supported MIDI-addressable Sound resource");
        if (!rawAddresses.insert({sound.internalBank, sound.rawProgram}).second)
            return fail("Duplicate raw PCG bank/program address");
        sound.rawChecksum = be32(bytes, fieldsEnd);
        knownAddress(sound, sourcePath);
        unknownBank = unknownBank || !sound.addressKnown;
        out.sounds.push_back(std::move(sound));
        position = recordEnd;
    }
    if (out.sounds.empty() || out.sounds.size() > 16384)
        return fail("PCG directory contains no supported Sounds or too many records");
    if (chunks.size() != out.sounds.size() + 3)
        return fail("PCG record count does not match the object payload count");

    const auto& reference = chunks.back();
    const std::size_t references = out.sounds.size() + 1;
    const std::size_t expectedLength = 12 + references * 4;
    if (reference.length != expectedLength || !magic(bytes, reference.payload, "KBEG") ||
        !magic(bytes, reference.payload + 4 + references * 4, "KEND") ||
        be32(bytes, reference.payload + 8 + references * 4) != references)
        return fail("PCG cross-reference count or KBEG/KEND structure is invalid");
    for (std::size_t index = 0; index < references; ++index) {
        if (be32(bytes, reference.payload + 4 + index * 4) != chunks[index + 1].offset)
            return fail("PCG cross-reference does not point to its exact indexed object");
    }
    for (std::size_t index = 0; index < out.sounds.size(); ++index) {
        const auto& chunk = chunks[index + 2];
        auto& sound = out.sounds[index];
        if ((chunk.tag & 0xFF0000FFU) != 0x10000038U || chunk.length < 4)
            return fail("Unsupported PCG Sound object chunk tag or empty payload");
        for (unsigned i = 0; i < 4; ++i)
            sound.payloadChunkTag[i] = static_cast<std::uint8_t>(chunk.tag >> ((3U - i) * 8U));
        if (sound.resourceVersion[0] != sound.payloadChunkTag[1] ||
            sound.resourceVersion[1] != sound.payloadChunkTag[2])
            return fail("PCG directory and Sound object resource versions differ");
        sound.payloadOffset = chunk.payload;
        sound.payloadLength = chunk.length;
        sound.oc31Encoded = magic(bytes, chunk.payload, "OC31");
    }
    if (unknownBank) out.warnings.push_back("Some PCG bank contexts or resource revisions have no supported external MSB/LSB mapping");
    out.warnings.push_back("PCG directory and exact object boundaries indexed; OSC/DrumKit/DNC/effects parameters and sample references are not decoded");
    out.valid = true;
    return out;
}

Pa5xPcgInspection inspectPa5xPcgFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) { Pa5xPcgInspection out; out.sourcePath = path; out.error = "Cannot open PCG file"; return out; }
    const auto length = file.tellg();
    if (length < 8 || length > static_cast<std::streamoff>(kMaximumFile)) {
        Pa5xPcgInspection out; out.sourcePath = path; out.error = "PCG file is outside supported size bounds"; return out;
    }
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length));
    file.seekg(0);
    file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!file) { Pa5xPcgInspection out; out.sourcePath = path; out.error = "PCG file read failed"; return out; }
    return inspectPa5xPcgBytes(bytes, path);
}

const Pa5xPcgSound* findPa5xPcgSound(const Pa5xPcgInspection& index,
                                  int msb, int lsb, int rawProgram) noexcept {
    if (!index.valid || msb < 0 || msb > 127 || lsb < 0 || lsb > 127 || rawProgram < 0 || rawProgram > 127)
        return nullptr;
    for (const auto& sound : index.sounds)
        if (sound.addressKnown && sound.msb == msb && sound.lsb == lsb && sound.rawProgram == rawProgram)
            return &sound;
    return nullptr;
}
} // namespace silveton::arranger
