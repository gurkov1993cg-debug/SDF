// Included by ArrangerEngine.cpp, shares the existing musical clock and chord path.
namespace {
bool sameSequenceChord(Chord a,Chord b) noexcept {return a.root==b.root&&a.type==b.type&&a.bass==b.bass;}
std::uint64_t packSequence(ChordSequenceEvent e) noexcept {return (std::uint64_t(e.tick)<<16U)|(std::uint64_t(e.chord.root)<<9U)|(std::uint64_t(e.chord.bass)<<5U)|std::uint64_t(e.chord.type);}
ChordSequenceEvent unpackSequence(std::uint64_t v) noexcept {return {std::uint32_t(v>>16U),{int((v>>9U)&15U),static_cast<ChordType>(v&31U),int((v>>5U)&15U)}};}
}
bool validChordSequence(const ChordSequenceData& d) noexcept {
    if(!d.count||d.count>d.events.size()||!d.lengthTicks||d.lengthTicks>kChordSequenceMaxTicks||d.events[0].tick!=0)return false;
    for(std::uint32_t i=0;i<d.count;++i){const auto& e=d.events[i];
        if(e.tick>=d.lengthTicks||(i&&e.tick<=d.events[i-1].tick)||e.chord.root<0||e.chord.root>11||e.chord.bass<0||e.chord.bass>11||
           static_cast<unsigned>(e.chord.type)>static_cast<unsigned>(ChordType::RootFifth))return false;
    }return true;
}
std::string encodeChordSequence(const ChordSequenceData& d){
    if(!validChordSequence(d))return {};std::ostringstream out;
    out<<"SILVETON_CHORD_SEQUENCE 1 "<<d.lengthTicks<<' '<<d.count<<'\n';
    for(std::uint32_t i=0;i<d.count;++i){const auto& e=d.events[i];out<<e.tick<<' '<<e.chord.root<<' '<<static_cast<int>(e.chord.type)<<' '<<e.chord.bass<<'\n';}
    return out.str();
}
bool decodeChordSequence(const std::string& text,ChordSequenceData& result){
    if(text.size()>16384U)return false;std::istringstream in(text);std::string magic;int version=0;ChordSequenceData d;
    if(!(in>>magic>>version>>d.lengthTicks>>d.count)||magic!="SILVETON_CHORD_SEQUENCE"||version!=1||d.count>d.events.size())return false;
    for(std::uint32_t i=0;i<d.count;++i){auto& e=d.events[i];int type=-1;if(!(in>>e.tick>>e.chord.root>>type>>e.chord.bass)||type<0||type>static_cast<int>(ChordType::RootFifth))return false;e.chord.type=static_cast<ChordType>(type);}
    in>>std::ws;if(!in.eof()||!validChordSequence(d))return false;result=d;return true;
}
bool ArrangerEngine::loadChordSequence(const ChordSequenceData& d,int player) noexcept {
    if(player<0||player>=kPlayers||!validChordSequence(d))return false;
    int expected=0;if(!sequenceMailboxState_.compare_exchange_strong(expected,1,std::memory_order_acq_rel))return false;
    sequenceMailbox_=d;sequenceMailboxPlayer_=player;sequenceMailboxState_.store(2,std::memory_order_release);return true;
}
void ArrangerEngine::adoptSequence(RenderCallbacks& cb) noexcept {
    if(sequenceMailboxState_.load(std::memory_order_acquire)!=2)return;
    const bool release=sequenceMode_==ChordSequenceMode::Playing;
    sequence_=sequenceMailbox_;sequencePlayer_=sequenceMailboxPlayer_;sequenceMailboxState_.store(0,std::memory_order_release);
    sequenceMode_=ChordSequenceMode::Idle;sequenceCurrent_=-1;sequenceTick_=0;sequenceDirty_=true;
    if(release)releaseSequenceHarmony(cb);
}
ChordSequenceSnapshot ArrangerEngine::chordSequence() const noexcept {
    ChordSequenceSnapshot s;for(;;){const auto rev=sequenceRevision_.load(std::memory_order_acquire);if(rev&1U)continue;
        s.revision=rev;s.data.count=sequenceCount_.load(std::memory_order_relaxed);s.data.lengthTicks=sequenceLength_.load(std::memory_order_relaxed);
        s.mode=static_cast<ChordSequenceMode>(sequenceState_.load(std::memory_order_relaxed));s.player=sequenceOwner_.load(std::memory_order_relaxed);
        s.current=sequenceIndex_.load(std::memory_order_relaxed);s.locked=sequenceLock_.load(std::memory_order_relaxed)!=0;
        for(std::uint32_t i=0;i<s.data.count;++i)s.data.events[i]=unpackSequence(sequenceEvents_[i].load(std::memory_order_relaxed));
        if(rev==sequenceRevision_.load(std::memory_order_acquire))return s;
    }
}
void ArrangerEngine::publishSequence() noexcept {
    if(!sequenceDirty_)return;sequenceDirty_=false;sequenceRevision_.fetch_add(1,std::memory_order_acq_rel);
    sequenceCount_.store(sequence_.count,std::memory_order_relaxed);sequenceLength_.store(sequence_.lengthTicks,std::memory_order_relaxed);
    for(std::uint32_t i=0;i<sequence_.count;++i)sequenceEvents_[i].store(packSequence(sequence_.events[i]),std::memory_order_relaxed);
    sequenceState_.store(static_cast<int>(sequenceMode_),std::memory_order_relaxed);sequenceOwner_.store(sequencePlayer_,std::memory_order_relaxed);
    sequenceIndex_.store(sequenceCurrent_,std::memory_order_relaxed);sequenceLock_.store(sequenceLocked_?1:0,std::memory_order_relaxed);sequenceRevision_.fetch_add(1,std::memory_order_release);
}
void ArrangerEngine::releaseSequenceHarmony(RenderCallbacks& cb) noexcept {
    // Re-evaluate the actual held keys. With chord memory enabled the last
    // played harmony is deliberately retained until the next physical chord.
    refreshChord(cb,ScanReason::Control);
}
double ArrangerEngine::sequenceNextBar() const noexcept {
    const auto& p=players_[static_cast<std::size_t>(sequencePlayer_)];const auto* sec=section(p);
    if(!p.playing||!p.style||!sec)return 0;
    const double bar=measureTicks(*p.style,*sec);
    return ((std::floor((p.tick+1e-7)/bar)+1.0)*bar-p.tick)*480.0/p.style->ppq;
}
void ArrangerEngine::finishSequenceRecording() noexcept {
    if(sequenceMode_!=ChordSequenceMode::Recording)return;
    const auto last=sequence_.count?sequence_.events[sequence_.count-1].tick:0U;
    const double needed=std::max(sequenceTick_,double(last)+1.0);
    const auto bar=std::max(1U,sequenceBarTicks_);
    const auto length=std::min<double>(kChordSequenceMaxTicks,std::max<double>(bar,std::ceil((needed-1e-7)/bar)*bar));
    sequence_.lengthTicks=static_cast<std::uint32_t>(length);
    if(!validChordSequence(sequence_))sequence_={};
    sequenceMode_=ChordSequenceMode::Idle;sequenceCurrent_=-1;sequenceDirty_=true;
}
void ArrangerEngine::recordSequenceChord(Chord chord) noexcept {
    if(!chord.valid())return;
    const auto tick=static_cast<std::uint32_t>(std::clamp(std::floor(sequenceTick_+0.5),0.0,double(kChordSequenceMaxTicks-1)));
    if(sequence_.count){auto& last=sequence_.events[sequence_.count-1];if(sameSequenceChord(last.chord,chord))return;
        if(tick<=last.tick){last.chord=chord;sequenceDirty_=true;return;}
    }
    if(sequence_.count==sequence_.events.size()){finishSequenceRecording();return;}
    const auto position=sequence_.count;sequence_.events[position]={position==0?0U:tick,chord};++sequence_.count;sequenceDirty_=true;
}
void ArrangerEngine::sequenceCommand(const Command& c,RenderCallbacks& cb) noexcept {
    if(c.player<0||c.player>=kPlayers)return;
    if(c.type==CommandType::ToggleSequenceLock){sequenceLocked_=!sequenceLocked_;sequenceDirty_=true;return;}
    const auto before=sequenceMode_;
    if(c.type==CommandType::ClearSequence){sequence_={};sequenceMode_=ChordSequenceMode::Idle;sequenceCurrent_=-1;sequenceDirty_=true;
        if(before==ChordSequenceMode::Playing)releaseSequenceHarmony(cb);return;}
    if(c.type==CommandType::ToggleSequenceRecord){
        if(before==ChordSequenceMode::Recording){finishSequenceRecording();
            if(sequence_.count&&players_[static_cast<std::size_t>(sequencePlayer_)].playing){sequenceMode_=ChordSequenceMode::PlayArmed;sequenceWait_=sequenceNextBar();}
            return;}
        if(before==ChordSequenceMode::RecordArmed){sequenceMode_=ChordSequenceMode::Idle;sequenceDirty_=true;return;}
        if(!players_[static_cast<std::size_t>(c.player)].style)return;
        sequencePlayer_=c.player;sequenceMode_=ChordSequenceMode::RecordArmed;sequenceWait_=sequenceNextBar();sequenceCurrent_=-1;sequenceDirty_=true;
        if(before==ChordSequenceMode::Playing)releaseSequenceHarmony(cb);return;
    }
    if(c.type==CommandType::ToggleSequencePlay){
        if(before==ChordSequenceMode::Playing||before==ChordSequenceMode::PlayArmed){sequenceMode_=ChordSequenceMode::Idle;sequenceCurrent_=-1;sequenceDirty_=true;
            if(before==ChordSequenceMode::Playing)releaseSequenceHarmony(cb);return;}
        if(before==ChordSequenceMode::Recording)finishSequenceRecording();
        if(!validChordSequence(sequence_)||!players_[static_cast<std::size_t>(c.player)].style)return;
        sequencePlayer_=c.player;sequenceMode_=ChordSequenceMode::PlayArmed;sequenceWait_=sequenceNextBar();sequenceCurrent_=-1;sequenceDirty_=true;
    }
}
void ArrangerEngine::serviceSequence(RenderCallbacks& cb) noexcept {
    const auto& p=players_[static_cast<std::size_t>(sequencePlayer_)];
    if(!p.playing||!p.style){
        if(sequenceMode_==ChordSequenceMode::Recording)finishSequenceRecording();
        if(sequenceMode_==ChordSequenceMode::Playing){sequenceMode_=ChordSequenceMode::PlayArmed;sequenceCurrent_=-1;sequenceDirty_=true;releaseSequenceHarmony(cb);}
        sequenceWait_=0;return;
    }
    if((sequenceMode_==ChordSequenceMode::RecordArmed||sequenceMode_==ChordSequenceMode::PlayArmed)&&sequenceWait_<=1e-7){
        sequenceTick_=0;sequenceCurrent_=-1;sequenceDirty_=true;
        if(sequenceMode_==ChordSequenceMode::RecordArmed){
            sequence_={};sequenceMode_=ChordSequenceMode::Recording;const auto* sec=section(p);
            sequenceBarTicks_=sec?static_cast<std::uint32_t>(std::max(1.0,std::round(measureTicks(*p.style,*sec)*480.0/p.style->ppq))):1920U;
            if(chord_.valid())recordSequenceChord(chord_);
        }else sequenceMode_=ChordSequenceMode::Playing;
    }
    if(sequenceMode_==ChordSequenceMode::Recording&&sequenceTick_>=kChordSequenceMaxTicks){finishSequenceRecording();return;}
    if(sequenceMode_!=ChordSequenceMode::Playing)return;
    if(sequenceTick_+1e-7>=sequence_.lengthTicks){sequenceTick_=std::max(0.0,sequenceTick_-sequence_.lengthTicks);sequenceCurrent_=-1;}
    while(sequenceCurrent_+1<static_cast<int>(sequence_.count)&&sequence_.events[static_cast<std::size_t>(sequenceCurrent_+1)].tick<=sequenceTick_+1e-7){
        ++sequenceCurrent_;sequenceDirty_=true;applyChord(sequence_.events[static_cast<std::size_t>(sequenceCurrent_)].chord,cb);
    }
}
double ArrangerEngine::nextSequenceFrames(double rate) const noexcept {
    const auto& p=players_[static_cast<std::size_t>(sequencePlayer_)];if(!p.playing||!p.style)return std::numeric_limits<double>::infinity();
    const double perFrame=p.tempo*480.0/(60.0*rate);
    if(sequenceMode_==ChordSequenceMode::RecordArmed||sequenceMode_==ChordSequenceMode::PlayArmed)return sequenceWait_/perFrame;
    if(sequenceMode_==ChordSequenceMode::Recording)return (kChordSequenceMaxTicks-sequenceTick_)/perFrame;
    if(sequenceMode_!=ChordSequenceMode::Playing)return std::numeric_limits<double>::infinity();
    const auto next=sequenceCurrent_+1<static_cast<int>(sequence_.count)?sequence_.events[static_cast<std::size_t>(sequenceCurrent_+1)].tick:sequence_.lengthTicks;
    return (next-sequenceTick_)/perFrame;
}
void ArrangerEngine::advanceSequence(std::uint32_t frames,double rate) noexcept {
    const auto& p=players_[static_cast<std::size_t>(sequencePlayer_)];if(!p.playing||!p.style)return;
    const double ticks=frames*p.tempo*480.0/(60.0*rate);
    if(sequenceMode_==ChordSequenceMode::RecordArmed||sequenceMode_==ChordSequenceMode::PlayArmed)sequenceWait_-=ticks;
    else if(sequenceMode_==ChordSequenceMode::Recording||sequenceMode_==ChordSequenceMode::Playing)sequenceTick_+=ticks;
}
