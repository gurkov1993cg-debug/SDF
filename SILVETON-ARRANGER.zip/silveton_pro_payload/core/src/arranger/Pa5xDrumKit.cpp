#include "silveton/arranger/Pa5xDrumKit.h"
#include "silveton/arranger/Pa5xOc31.h"

#include <algorithm>
#include <fstream>
#include <map>
#include <utility>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumPcgBytes = 64U * 1024U * 1024U;
constexpr std::size_t kMaximumBodyBytes = 2U * 1024U * 1024U;
// Independent field-layout implementation. Provenance: original KORG-Tools
// SoundFormat0..3 and legacy0.2 readers, plus exact full-body corpus checks.
// Opaque fields remain raw; this does not embed its source or DSP algorithms.
class Reader {
public:
    explicit Reader(const std::vector<std::uint8_t>& bytes) : bytes_(bytes) {}
    bool good() const noexcept { return good_; }
    std::size_t position() const noexcept { return position_; }
    std::size_t remaining() const noexcept { return bytes_.size() - position_; }
    std::uint8_t byte() noexcept {
        if (position_ >= bytes_.size()) { good_ = false; return 0; }
        return bytes_[position_++];
    }
    std::int8_t signedByte() noexcept {
        const int n = byte(); return static_cast<std::int8_t>(n < 128 ? n : n - 256);
    }
    std::uint16_t word() noexcept {
        const auto hi = byte(); const auto lo = byte();
        return static_cast<std::uint16_t>((static_cast<unsigned>(hi) << 8U) | lo);
    }
    std::uint64_t id() noexcept {
        std::uint64_t n = 0; for (int i = 0; i < 8; ++i) n = (n << 8U) | byte(); return n;
    }
    void skip(std::size_t n) noexcept {
        if (n > remaining()) { good_ = false; return; } position_ += n;
    }
    template <std::size_t N> void raw(std::array<std::uint8_t,N>& out) noexcept {
        for (auto& b : out) b = byte();
    }
    std::string name() {
        std::string out;
        for (int i = 0; i < 16; ++i) {
            const auto c = byte(); if (c == 0) { skip(static_cast<std::size_t>(15-i)); break; }
            out.push_back(static_cast<char>(c));
        }
        return out;
    }
private:
    const std::vector<std::uint8_t>& bytes_;
    std::size_t position_{0}; bool good_{true};
};
void commonOscillator(Reader& r, unsigned version) noexcept {
    // Two versioned multisample source records; drum key/layer references
    // follow later and are never inferred by searching these bytes for IDs.
    for (int source = 0; source < 2; ++source) {
        (void)r.id(); (void)r.word(); (void)r.byte(); (void)r.byte();
        if (version >= 2) { (void)r.byte(); (void)r.byte(); }
    }
    r.skip(1); // delay
    r.skip(1); // velocity switch
    r.skip(2); // velocity zone
    r.skip(2); // key zone
    r.skip(1); // opaque oscillator field
    if (version >= 1) r.skip(2); // trigger/controller exception
    if (version >= 2) r.skip(2); // newer opaque fields
    r.skip(4); r.skip(20);
    r.skip(1); r.skip(1); r.skip(2); // octave, transpose, tune
    r.skip(90); // opaque synthesis/DNC fields
    r.skip(2); // scaled velocity
    r.skip(22);
    if (version >= 2) r.skip(6); // oscillator EQ
    r.skip(4);
}
std::vector<std::int32_t> references(const Pa5xKmpDrumSample& sample) {
    if (sample.version8ReferencesPresent)
        return {sample.version8References.begin(), sample.version8References.end()};
    return {sample.leftSample,sample.rightSample};
}
struct NewLayout { std::size_t countOffset, commonBytes, oscillatorBytes, keyBytes, layerBytes; };
NewLayout layout(unsigned version) noexcept {
    // Newer framing was derived independently from decoded resource bounds:
    // 450 normal resources and 138 Drum Kits (17 v5, 7 v6, 8 v7, 106 v8).
    // Each kit has 128 bounded key rows, a packed count and fixed-width layer
    // rows, consuming its entire body. Full UID joins to typed RAM.KMP provide
    // independent reference corroboration, not the means of locating fields.
    switch (version) {
        case 5: return {288,313,198,20,32};
        case 6: return {288,313,200,20,32};
        case 7: return {423,448,202,22,33};
        case 8: return {423,450,202,29,33};
        default: return {};
    }
}
} // namespace

bool decodePa5xDrumExclusiveGroups(const Pa5xDrumKitInspection& kit,
                                  std::array<std::uint8_t,128>& groups) noexcept {
    groups = {};
    if (!kit.referenceGraphDecoded || kit.resourceVersion[1] != 0U) return false;
    std::size_t recordBytes = 0U, layerCountOffset = 0U, groupOffset = 0U;
    // Calibrated against the Pa1X Factory Data's explicit Excl. columns:
    // eleven non-hi-hat assignments agree in 36 original kits at these bytes;
    // every alternative byte agrees at most twice. Exact RAM UID/header joins
    // corroborate the newer versions. v7 adds two opaque bytes AFTER the group
    // (before the key flags), and v8 extends the velocity-switch tail.
    // No undocumented flag or choke-time value is interpreted here.
    switch (kit.resourceVersion[0]) {
        case 0: case 1: recordBytes = 18U; layerCountOffset = 2U; groupOffset = 7U; break;
        case 2: case 3: recordBytes = 18U; layerCountOffset = 2U; groupOffset = 8U; break;
        case 5: case 6: recordBytes = 20U; layerCountOffset = 4U; groupOffset = 10U; break;
        case 7: recordBytes = 22U; layerCountOffset = 4U; groupOffset = 10U; break;
        case 8: recordBytes = 29U; layerCountOffset = 4U; groupOffset = 10U; break;
        default: return false;
    }
    std::array<std::uint8_t,128> decoded{};
    for (std::size_t note = 0U; note < kit.keys.size(); ++note) {
        const auto& key = kit.keys[note];
        const auto& raw = key.rawRecord;
        if (raw.size() != recordBytes || raw[layerCountOffset] != key.layerCount ||
            key.layerCount > 6U ||
            ((static_cast<unsigned>(raw[0]) << 8U) | raw[1]) != key.firstLayer ||
            static_cast<std::size_t>(key.firstLayer) + key.layerCount > kit.layers.size() ||
            raw[groupOffset] > 127U) return false;
        const auto sentinel = kit.resourceVersion[0] < 2U ? 14U : recordBytes - 3U;
        if (raw[sentinel] != 127U || raw[sentinel + 1U] != 127U ||
            raw[sentinel + 2U] != 127U) return false;
        decoded[note] = raw[groupOffset];
    }
    groups = decoded;
    return true;
}

Pa5xDrumKitInspection inspectPa5xDrumKitBytes(const std::vector<std::uint8_t>& bytes,
                                            const Pa5xPcgSound& descriptor) {
    Pa5xDrumKitInspection out; out.name = descriptor.name; out.resourceVersion = descriptor.resourceVersion;
    const auto fail = [&](const std::string& error) {
        out.error = error; out.layers.clear(); out.keys = {};
        out.referenceGraphDecoded = false; out.blockers.push_back(error); return out;
    };
    const unsigned version = descriptor.resourceVersion[0];
    const bool newer = version >= 5 && version <= 8;
    if (descriptor.resourceClass != 4 || descriptor.resourceVersion[1] != 0 || (version > 3 && !newer))
        return fail("Drum Kit reference layout is unsupported for this Sound resource version");
    out.recognized = true;
    if (descriptor.kind == Pa5xPcgSoundKind::Sound)
        return fail("A normal Sound descriptor is not a Drum Kit");
    if (bytes.size() > kMaximumPcgBytes || descriptor.payloadOffset > bytes.size() ||
        descriptor.payloadLength > bytes.size() - descriptor.payloadOffset || descriptor.payloadLength < 9)
        return fail("Drum Kit payload exceeds its PCG boundary");
    const auto decoded = decodePa5xOc31(bytes.data()+descriptor.payloadOffset,descriptor.payloadLength,kMaximumBodyBytes);
    if (!decoded) return fail("Drum Kit resource decompression failed: " + decoded.error);
    out.decodedBodyBytes = decoded.data.size(); Reader r(decoded.data);
    out.multisampleMapRaw = r.word();
    if (version < 3) (void)r.name();
    out.voiceFlagsRaw = r.byte();
    if ((out.voiceFlagsRaw & 2U) == 0) return fail("Sound body does not declare the Drum Kit voice kind");
    const auto format = layout(version);
    if (newer) {
        // Cross-version framing is independently evidenced by all450 newer
        // normal Sounds and all138 newer Drum Kits. Common synthesis spans
        // are explicitly opaque; key/layer boundaries below are verified again.
        r.skip(format.countOffset-r.position()); out.oscillatorFlagsRaw = r.byte();
        r.skip(format.commonBytes-r.position());
        if (!r.good()) return fail("Newer Drum Kit common frame is truncated");
        out.commonRaw.assign(decoded.data.begin(),decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
        const unsigned oscillators = out.oscillatorFlagsRaw & 63U;
        for (unsigned i = 0; i < oscillators && r.good(); ++i) {
            const auto start = r.position(); r.skip(format.oscillatorBytes);
            if (r.good()) out.commonOscillatorsRaw.emplace_back(decoded.data.begin()+static_cast<std::ptrdiff_t>(start),
                decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
        }
    } else {
        r.skip(5); r.skip(2); // common fields and transpose range
        for (unsigned fx = 0; fx < (version >= 2 ? 4U : 2U); ++fx) {
            r.skip(1); r.skip(64); r.skip(1); if (version >= 2) r.skip(1);
        }
        r.skip(3); if (version >= 2) r.skip(3);
        out.oscillatorFlagsRaw = r.byte();
        const unsigned oscillators = out.oscillatorFlagsRaw & 63U;
        r.skip(1); r.skip(6); r.skip(14); if (version >= 1) r.skip(3);
        if (!r.good()) return fail("Drum Kit common frame is truncated");
        out.commonRaw.assign(decoded.data.begin(),decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
        for (unsigned i = 0; i < oscillators && r.good(); ++i) {
            const auto start = r.position(); commonOscillator(r,version);
            if (r.good()) out.commonOscillatorsRaw.emplace_back(decoded.data.begin()+static_cast<std::ptrdiff_t>(start),
                decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
        }
    }
    if (!r.good()) return fail("Drum Kit common oscillator fields are truncated");
    out.drumTableOffset = r.position();
    if (newer) {
        out.drumTableFlagsRaw = r.byte();
        if (out.drumTableFlagsRaw != 0) return fail("Newer Drum Kit table flags are uncalibrated");
    }
    for (auto& key : out.keys) {
        const auto start = r.position();
        if (newer) {
            key.firstLayer = r.word(); key.opaqueIndexRaw = r.word(); key.layerCount = r.byte();
            if (key.layerCount > 6) return fail("Newer Drum Kit key layer count is uncalibrated");
            // Known v5/6/7 has five switch bytes. v8 preserves twelve bytes
            // at the same end-relative span; only the first five are observed
            // to vary in this corpus. Their selection law remains unverified.
            const std::size_t switches = version == 8 ? 12U : 5U;
            r.skip(format.keyBytes-5U-switches-3U);
            for (std::size_t i = 0; i < switches; ++i) key.velocitySwitchesExtendedRaw.push_back(r.byte());
            std::copy_n(key.velocitySwitchesExtendedRaw.begin(),5,key.velocitySwitchesRaw.begin());
            const auto a = r.byte(), b = r.byte(), c = r.byte();
            if (a != 127 || b != 127 || c != 127) return fail("Newer Drum Kit key sentinel is unsupported");
            if (!r.good()) return fail("Newer Drum Kit key record is truncated");
            key.rawRecord.assign(decoded.data.begin()+static_cast<std::ptrdiff_t>(start),decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
            continue;
        }
        key.firstLayer = r.word(); key.layerCount = r.byte(); r.raw(key.opaqueA);
        if (version >= 2) key.opaqueB = r.byte();
        r.raw(key.opaqueC); r.raw(key.velocitySwitchesRaw);
        // These three fixed bytes are part of the primary versioned grammar.
        const auto a = r.byte(), b = r.byte(), c = r.byte();
        if (a != 127 || b != 127 || c != 127 || key.layerCount > 6)
            return fail("Drum Kit key table contains an unsupported layer layout");
        if (version < 2) key.legacyOpaque = r.byte();
        key.velocitySwitchesExtendedRaw.assign(key.velocitySwitchesRaw.begin(),key.velocitySwitchesRaw.end());
        if (r.good()) key.rawRecord.assign(decoded.data.begin()+static_cast<std::ptrdiff_t>(start),decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
    }
    if (!r.good()) return fail("Drum Kit key table is truncated");
    const auto packed = r.word(); out.layerIdsPresent = (packed & 0x8000U) != 0;
    const std::size_t count = packed & 0x7FFFU;
    const std::size_t detailBytes = newer ? format.layerBytes-8U-11U : (version >= 2 ? 11U : 1U);
    const std::size_t layerBytes = 11U + detailBytes + (out.layerIdsPresent ? 8U : 0U);
    if (!r.good() || count > r.remaining()/layerBytes || count*layerBytes != r.remaining())
        return fail("Drum Kit layer count does not consume its exact resource boundary");
    out.layers.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        const auto start = r.position();
        Pa5xDrumKitLayer layer;
        layer.sampleBankRaw = r.byte(); layer.reverseRaw = r.byte(); layer.drumSampleNumber = r.word();
        if (layer.reverseRaw > 3) return fail("Drum Kit reverse flags are unsupported");
        layer.layerParametersIdentified = !newer;
        if (newer) r.skip(7); // New layer parameter encoding is not the old signed-byte layout.
        else {
            layer.levelRaw = r.signedByte(); layer.transposeRaw = r.signedByte(); layer.tuneRaw = r.byte();
            layer.attackRaw = r.signedByte(); layer.decayRaw = r.byte();
            layer.cutoffRaw = r.signedByte(); layer.resonanceRaw = r.byte();
        }
        layer.detailBytes = static_cast<std::uint8_t>(detailBytes);
        for (std::size_t d = 0; d < detailBytes; ++d) layer.detailRaw[d] = r.byte();
        layer.hasDrumSampleId = out.layerIdsPresent;
        if (out.layerIdsPresent) layer.drumSampleId = r.id();
        if (r.good()) layer.rawRecord.assign(decoded.data.begin()+static_cast<std::ptrdiff_t>(start),decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
        out.layers.push_back(layer);
    }
    if (!r.good() || r.position() != decoded.data.size()) return fail("Drum Kit body is truncated or has trailing bytes");
    for (const auto& key : out.keys)
        if (static_cast<std::size_t>(key.firstLayer)+key.layerCount > out.layers.size())
            return fail("Drum Kit key references layers outside its layer table");
    out.referenceGraphDecoded = true;
    out.blockers.push_back("Drum references are decoded; common Sound DSP, effects and DNC remain opaque");
    out.blockers.push_back("Key flags, velocity selection and raw layer gain/tune/envelope/filter laws are not fully calibrated");
    return out;
}

Pa5xDrumKitInspection inspectPa5xDrumKitFile(const std::string& path, int bank, int program) {
    const auto index = inspectPa5xPcgFile(path); Pa5xDrumKitInspection out;
    if (!index.valid) { out.error = index.error; return out; }
    const Pa5xPcgSound* selected = nullptr;
    for (const auto& sound : index.sounds) if (sound.internalBank == bank && sound.rawProgram == program) { selected = &sound; break; }
    if (selected == nullptr) { out.error = "Drum Kit raw bank/program is not present"; return out; }
    std::ifstream file(path,std::ios::binary | std::ios::ate);
    if (!file) { out.error = "Cannot open Drum Kit PCG"; return out; }
    const auto length = file.tellg();
    if (length < 0 || length > static_cast<std::streamoff>(kMaximumPcgBytes)) { out.error = "Drum Kit PCG exceeds its size limit"; return out; }
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length)); file.seekg(0);
    if (!bytes.empty()) file.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    if (!file) { out.error = "Cannot read Drum Kit PCG"; return out; }
    return inspectPa5xDrumKitBytes(bytes,*selected);
}

Pa5xDrumKitSampleLinks linkPa5xDrumKitSamples(const Pa5xDrumKitInspection& kit, const Pa5xSampleIndex& kmp) {
    Pa5xDrumKitSampleLinks out;
    if (!kit.referenceGraphDecoded || !kmp.valid || !kmp.multisampleMappingDecoded) {
        out.blockers.push_back("Typed Drum Kit and KMP graphs are required before linking"); return out;
    }
    std::map<std::uint64_t,std::vector<std::size_t>> ids;
    for (std::size_t i = 0; i < kmp.drumSamples.size(); ++i) ids[kmp.drumSamples[i].resourceId].push_back(i);
    out.completeRamReferences = true;
    for (std::size_t i = 0; i < kit.layers.size(); ++i) {
        const auto& layer = kit.layers[i]; Pa5xDrumLayerSampleLink link; link.layer = i;
        link.ram = layer.sampleBankRaw == 1; link.drumSampleId = layer.drumSampleId;
        if (layer.sampleBankRaw == 0) link.blocker = "Factory ROM drum content is required";
        else if (!link.ram) link.blocker = "Drum sample bank code is unsupported";
        else if (!layer.hasDrumSampleId || layer.drumSampleId == 0) link.blocker = "RAM drum reference has no exact UID";
        else {
            const auto found = ids.find(layer.drumSampleId);
            if (found == ids.end()) link.blocker = "Exact drum UID is absent from this KMP";
            else {
                link.kmpDrumIndices = found->second;
                auto selected = found->second.front();
                const auto& first = kmp.drumSamples[selected];
                link.sampleIndices = references(first); link.stereoPairingKnown = !first.version8ReferencesPresent;
                bool same = true;
                for (const auto n : found->second) if (references(kmp.drumSamples[n]) != link.sampleIndices) same = false;
                if (!same && std::find(found->second.begin(),found->second.end(),layer.drumSampleNumber) != found->second.end()) {
                    // UID remains mandatory. The original drum number is only
                    // a tie-breaker among records already proven to share it.
                    selected = layer.drumSampleNumber; link.kmpDrumIndices = {selected};
                    const auto& exact = kmp.drumSamples[selected]; link.sampleIndices = references(exact);
                    link.stereoPairingKnown = !exact.version8ReferencesPresent;
                    link.duplicateResolvedByNumber = true; same = true;
                }
                if (!same) link.blocker = "Duplicate drum UIDs have conflicting sample-reference graphs";
                else {
                    link.resolved = true;
                    for (const auto n : link.sampleIndices) {
                        if (n == -1) continue;
                        if (n < 0 || static_cast<std::size_t>(n) >= kmp.samples.size()) {
                            link.resolved = false; link.blocker = "Drum sample index exceeds the typed KMP sample table"; break;
                        }
                        link.sampleIds.push_back(kmp.samples[static_cast<std::size_t>(n)].resourceId);
                    }
                    if (link.sampleIds.empty() && link.resolved) { link.resolved = false; link.blocker = "Drum reference has no ordinary sample payload"; }
                }
            }
        }
        if (layer.sampleBankRaw != 0 && !link.resolved) out.completeRamReferences = false;
        out.layers.push_back(std::move(link));
    }
    out.blockers.push_back("Exact KMP joins do not establish waveform availability or decoded drum synthesis");
    out.blockers.push_back("KMP v8 reference positions are retained; full stereo/layer roles remain unverified");
    return out;
}
} // namespace silveton::arranger
