#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/Pa5xKstCatalog.h"
#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xPcgIndex.h"
#include "silveton/arranger/Pa5xPredictiveDecoder.h"
#include "silveton/arranger/Pa5xSampleIndex.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xSoundGraph.h"
#include "Pa5xStyleDirectory.h"
#include "Pa5xKstMetadataReuse.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <fstream>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <utility>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumResourceBytes = 64U * 1024U * 1024U;
constexpr std::uint32_t kMaximumPreviewFrames = 16U * 1024U * 1024U;
bool stopped(const std::atomic<bool>* cancel) noexcept {
    return cancel != nullptr && cancel->load(std::memory_order_relaxed);
}
std::string baseName(const std::string& path) {
    const auto slash = path.find_last_of('/');
    const auto begin = slash == std::string::npos ? 0 : slash + 1;
    const auto dot = path.find_last_of('.');
    return path.substr(begin, dot != std::string::npos && dot > begin ? dot - begin : std::string::npos);
}
std::string parentPath(const std::string& path) {
    const auto slash=path.find_last_of('/');
    return slash==std::string::npos?std::string():path.substr(0,slash);
}
std::string fileName(const std::string& path) {
    const auto slash=path.find_last_of('/');
    return path.substr(slash==std::string::npos?0:slash+1);
}
std::string asciiLower(std::string value) {
    for(auto& c:value)if(c>='A'&&c<='Z')c=static_cast<char>(c-'A'+'a');
    return value;
}
int filenameOrdinal(const std::string& name) noexcept {
    std::size_t i=0;unsigned value=0;
    while(i<name.size()&&name[i]>='0'&&name[i]<='9') {
        const auto digit=static_cast<unsigned>(name[i]-'0');
        if(value>(static_cast<unsigned>(std::numeric_limits<int>::max())-digit)/10U)return -1;
        value=value*10U+digit;++i;
    }
    return i!=0&&i<name.size()&&name[i]=='.'&&value!=0?static_cast<int>(value):-1;
}
Pa5xCatalogStyle styleIdentity(const std::string& path,const std::string& relative) {
    Pa5xCatalogStyle entry;
    entry.path=path;entry.relativePath=relative;entry.fileName=fileName(relative);
    entry.categoryPath=parentPath(relative);
    if(entry.categoryPath.empty())entry.categoryPath="STYLE";
    entry.bankName=fileName(entry.categoryPath);
    entry.positionOrdinal=filenameOrdinal(entry.fileName);entry.name=baseName(relative);
    return entry;
}
bool resourcePath(const std::string& root, const std::string& relative, std::string& full) {
    if (root.empty() || relative.empty() || relative.front() == '/' || relative.find('\0') != std::string::npos)
        return false;
    std::size_t start = 0;
    for (;;) {
        const auto end = relative.find('/', start);
        const auto part = relative.substr(start, end == std::string::npos ? end : end - start);
        if (part.empty() || part == "." || part == "..") return false;
        if (end == std::string::npos) break;
        start = end + 1;
    }
    full = root + "/" + relative;
    return true;
}
bool readResource(const std::string& path, std::vector<std::uint8_t>& bytes, std::string& error) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) { error = "Cannot open catalog resource"; return false; }
    const auto length = file.tellg();
    if (length < 0 || length > static_cast<std::streamoff>(kMaximumResourceBytes)) {
        error = "Catalog resource exceeds the 64 MiB format-reader limit"; return false;
    }
    bytes.resize(static_cast<std::size_t>(length)); file.seekg(0);
    if (!bytes.empty()) file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!file) { error = "Catalog resource read failed"; return false; }
    return true;
}
struct SampleLink { Pa5xKmpSample sample; std::string path; bool ambiguous{false}; };
using SampleLinks = std::map<std::uint64_t, SampleLink>;
using SampleResources = std::map<std::string,const Pa5xSampleIndex*>;

const Pa5xSampleIndex* sampleResource(const std::string& path,const SampleResources& shared,
    bool sharedOnly,Pa5xSampleIndex& local) {
    if(sharedOnly) {
        const auto found=shared.find(path);
        return found==shared.end()?nullptr:found->second;
    }
    local=inspectPa5xSampleFile(path);
    return &local;
}

Pa5xCatalogStyle styleEntry(const std::string& path,const std::string& relative,
        const Pa5xKstMetadataCache* cache) {
    auto entry=styleIdentity(path,relative);
    const auto* shared=cache?cache->style(path):nullptr;
    KstCatalogStyleMetadata local;
    if(!shared){
        std::vector<std::uint8_t> bytes;
        if(!readResource(path,bytes,entry.error)){
            entry.originalSettings=unavailablePa5xStyleSourceSettings(entry.error);return entry;
        }
        local=kstMidiStyle(relative)?kstImportedStyleMetadata(importMidiBytes(bytes,entry.name)):
            kstCatalogStyleMetadata(inspectKorgStyleBytes(bytes));
        shared=&local;
    }
    if(!shared->name.empty())entry.name=shared->name;
    entry.bpm=shared->bpm;entry.numerator=shared->numerator;entry.denominator=shared->denominator;
    entry.loadable=shared->loadable;entry.error=shared->error;entry.warnings=shared->warnings;
    entry.originalSettings=shared->originalSettings;
    return entry;
}

bool readDirectoryMetadata(const std::string& path,std::string& json,std::string& error) {
    std::ifstream file(path,std::ios::binary|std::ios::ate);
    if(!file){error="Cannot open metadir.json";return false;}
    const auto bytes=file.tellg();
    if(bytes<0||bytes>8*1024*1024){error="metadir.json exceeds its 8 MiB reader limit";return false;}
    json.resize(static_cast<std::size_t>(bytes));file.seekg(0);
    if(!json.empty())file.read(&json[0],static_cast<std::streamsize>(json.size()));
    if(!file){error="Cannot read complete metadir.json";return false;}
    return true;
}

void styleGroups(Pa5xKstCatalog& out,const Pa5xKstIndex& index,const std::atomic<bool>* cancel) {
    std::map<std::string,std::vector<std::size_t>> members;
    std::map<std::string,std::vector<std::string>> metadata;
    std::set<std::string> folders;
    const auto addParents=[&](std::string folder) {
        while(!folder.empty()){folders.insert(folder);folder=parentPath(folder);}
    };
    for(std::size_t i=0;i<out.styles.size();++i) {
        members[out.styles[i].categoryPath].push_back(i);addParents(out.styles[i].categoryPath);
    }
    for(const auto& resource:index.resources) {
        const auto slash=resource.relativePath.find('/');
        if(slash==std::string::npos||asciiLower(resource.relativePath.substr(0,slash))!="style"||
            asciiLower(fileName(resource.relativePath))!="metadir.json")continue;
        const auto folder=parentPath(resource.relativePath);addParents(folder);
        metadata[folder].push_back(resource.relativePath);
    }
    std::vector<std::string> orderedFolders(folders.begin(),folders.end());
    std::sort(orderedFolders.begin(),orderedFolders.end(),style_directory::naturalLess);
    std::map<std::string,std::size_t> groupIndices;
    for(const auto& folder:orderedFolders) {
        Pa5xCatalogStyleGroup group;
        group.relativePath=folder;group.name=paStyleBankPath(folder)?baseName(folder):fileName(folder);group.parentPath=parentPath(folder);
        group.depth=static_cast<std::size_t>(std::count(folder.begin(),folder.end(),'/'));
        groupIndices.emplace(folder,out.styleGroups.size());out.styleGroups.push_back(std::move(group));
    }
    for(std::size_t i=0;i<out.styleGroups.size();++i) {
        auto& group=out.styleGroups[i];
        const auto parent=groupIndices.find(group.parentPath);
        if(parent!=groupIndices.end())out.styleGroups[parent->second].childGroups.push_back(i);
        auto actual=members[group.relativePath];
        std::sort(actual.begin(),actual.end(),[&](std::size_t a,std::size_t b) {
            const auto& left=out.styles[a];const auto& right=out.styles[b];
            if(left.fileName!=right.fileName)return style_directory::naturalLess(left.fileName,right.fileName);
            return style_directory::naturalLess(left.relativePath,right.relativePath);
        });
        std::map<std::string,std::vector<std::size_t>> exact,aliases;
        for(const auto style:actual) {
            exact[out.styles[style].fileName].push_back(style);
            for(const auto& key:style_directory::nameKeys(out.styles[style].fileName)) {
                auto& matches=aliases[key];
                if(std::find(matches.begin(),matches.end(),style)==matches.end())matches.push_back(style);
            }
        }
        std::set<std::size_t> used;
        const auto append=[&](std::size_t style) {
            out.styles[style].positionSlot=static_cast<int>(group.slotStyleIndices.size());
            group.styleIndices.push_back(style);group.slotStyleIndices.push_back(static_cast<int>(style));used.insert(style);
        };
        const auto meta=metadata.find(group.relativePath);
        if(meta!=metadata.end()&&meta->second.size()==1U) {
            std::string path,json,error;
            std::vector<style_directory::MetadataFile> files;
            bool parsed=false;
            try {
                parsed=resourcePath(index.rootPath,meta->second.front(),path)&&
                    readDirectoryMetadata(path,json,error)&&style_directory::parseMetadata(json,files,error);
            } catch(const std::exception& e){error=e.what();}
            if(parsed) {
                group.metadataOrderUsed=true;
                for(const auto& reference:files) {
                    if(stopped(cancel)){out.cancelled=true;return;}
                    if(reference.blank||reference.file.empty()){group.slotStyleIndices.push_back(-1);continue;}
                    std::set<std::size_t> matches;
                    const auto direct=exact.find(reference.file);
                    if(direct!=exact.end())matches.insert(direct->second.begin(),direct->second.end());
                    else for(const auto& key:style_directory::nameKeys(reference.file)) {
                        const auto alias=aliases.find(key);
                        if(alias!=aliases.end())matches.insert(alias->second.begin(),alias->second.end());
                    }
                    if(matches.size()!=1U) {
                        group.missingMetadataFiles.push_back(reference.file);
                        group.missingSlotFiles.emplace(group.slotStyleIndices.size(),reference.file);
                        group.slotStyleIndices.push_back(-1);continue;
                    }
                    const auto selected=*matches.begin();
                    if(used.find(selected)!=used.end()) {
                        out.warnings.push_back(group.relativePath+": Duplicate metadir Style reference: "+reference.file);
                        group.missingSlotFiles.emplace(group.slotStyleIndices.size(),"Duplicate saved reference: "+reference.file);
                        group.slotStyleIndices.push_back(-1);continue;
                    }
                    auto& entry=out.styles[selected];entry.metadataFileName=reference.file;entry.iconName=reference.icon;
                    entry.name=baseName(reference.file);append(selected);
                }
                if(!group.missingMetadataFiles.empty())out.warnings.push_back(group.relativePath+": "+
                    std::to_string(group.missingMetadataFiles.size())+" metadir Style references are missing or ambiguous; all actual STG files remain listed");
            } else out.warnings.push_back(group.relativePath+": Invalid metadir order; using all actual STG files: "+error);
        } else if(meta!=metadata.end())out.warnings.push_back(group.relativePath+": Multiple metadir files; using actual STG file order");
        for(const auto style:actual)if(used.find(style)==used.end()){
            if(paStyleBankPath(group.relativePath))while(out.styles[style].positionOrdinal>static_cast<int>(group.slotStyleIndices.size()+1))
                group.slotStyleIndices.push_back(-1);
            append(style);
        }
    }
    // Make All Styles follow the same bank/metadir order as each folder, while
    // every real source entry still occurs exactly once in the catalog.
    std::vector<std::size_t> remap(out.styles.size());
    std::vector<Pa5xCatalogStyle> ordered;ordered.reserve(out.styles.size());
    for(auto& group:out.styleGroups)for(auto& style:group.styleIndices) {
        const auto original=style;style=ordered.size();remap[original]=style;
        ordered.push_back(std::move(out.styles[original]));
    }
    for(auto& group:out.styleGroups)for(auto& slot:group.slotStyleIndices)
        if(slot>=0)slot=static_cast<int>(remap[static_cast<std::size_t>(slot)]);
    out.styles=std::move(ordered);
    for(const auto& group:out.styleGroups) {
        auto folder=group.relativePath;
        while(!folder.empty()) {
            const auto found=groupIndices.find(folder);
            if(found!=groupIndices.end())out.styleGroups[found->second].descendantStyleCount+=group.styleIndices.size();
            folder=parentPath(folder);
        }
    }
}

bool styleDiscoveryIncomplete(const Pa5xKstIndex& index) {
    for(const auto& diagnostic:index.diagnostics) {
        // The resource cap aborts the entire walk even when reached in PCM
        // before STYLE is visited; its path cannot localize the omission.
        if(diagnostic.code=="TOO_MANY_FILES")return true;
        const auto& path=diagnostic.relativePath;const auto slash=path.find('/');
        if(!path.empty()&&asciiLower(path.substr(0,slash))!="style")continue;
        if(diagnostic.code=="DIRECTORY_DEPTH"||diagnostic.code=="TOO_MANY_FILES"||
            diagnostic.code=="FOLDER_UNREADABLE"||diagnostic.code=="FOLDER_READ_FAILED"||
            diagnostic.code=="RESOURCE_MISSING"||diagnostic.code=="LINKED_RESOURCE")return true;
    }
    return false;
}

Pa5xCatalogSound soundEntry(const Pa5xPcgSound& sound,const Pa5xSoundReferenceGraph& graph,
        const std::string& path,const std::string& relative) {
    Pa5xCatalogSound entry;entry.name=sound.name;entry.path=path;entry.relativePath=relative;
    entry.internalBank=sound.internalBank;entry.rawProgram=sound.rawProgram;
    entry.program=sound.rawProgram;entry.resourceVersion=sound.resourceVersion;entry.addressKnown=sound.addressKnown;
    if(sound.addressKnown){entry.msb=sound.msb;entry.lsb=sound.lsb;}
    entry.drumKit=sound.kind==Pa5xPcgSoundKind::DrumKit;
    entry.graphSupported=graph.referenceGraphDecoded;entry.oscillatorCount=graph.oscillators.size();
    entry.blocker=entry.graphSupported?
        "Reference graph only; complete Sound DSP and PCM/Factory resource activation are not implemented":graph.error;
    if(entry.blocker.empty())entry.blocker="Sound synthesis parameters are not decoded";
    if(!entry.addressKnown)entry.blocker+="; original external bank address is not established";
    return entry;
}
void soundEntries(Pa5xKstCatalog& out,const std::string& path,const std::string& relative,
        const std::atomic<bool>* cancel,const Pa5xSetBank* bank,const Pa5xKstMetadataCache* cache) {
    std::string error;std::vector<const Pa5xSetBankSound*> retained;
    if(bank&&bank->status().rootPath==out.rootPath&&bank->soundMetadataForPath(path,retained,error)){
        if(!error.empty()){out.warnings.push_back(relative+": "+error);return;}
        for(const auto* sound:retained){
            if(stopped(cancel)){out.cancelled=true;return;}
            if(sound->descriptor.kind==Pa5xPcgSoundKind::DrumKit){
                Pa5xSoundReferenceGraph unsupported;unsupported.error="Drum Kit layer references require their own version-aware decoder";
                out.sounds.push_back(soundEntry(sound->descriptor,unsupported,path,relative));
            }else out.sounds.push_back(soundEntry(sound->descriptor,sound->graph,path,relative));
        }
        return;
    }
    const auto shared=cache?cache->pcg(path):std::shared_ptr<const Pa5xKstMetadataCache::Pcg>{};
    std::vector<std::uint8_t> bytes;
    if(!shared&&!readResource(path,bytes,error)){out.warnings.push_back(relative+": "+error);return;}
    const auto& raw=shared?shared->bytes:bytes;
    const auto local=shared?Pa5xPcgInspection{}:inspectPa5xPcgBytes(raw,path);
    const auto& inspected=shared?shared->inspection:local;
    if(!inspected.valid){out.warnings.push_back(relative+": "+inspected.error);return;}
    for(const auto& sound:inspected.sounds){
        if(stopped(cancel)){out.cancelled=true;return;}
        out.sounds.push_back(soundEntry(sound,inspectPa5xSoundGraph(raw,sound),path,relative));
    }
}

Pa5xCatalogKeyboardSet keyboardEntry(const std::string& path,const std::string& relative,
        const Pa5xKstMetadataCache* cache) {
    Pa5xCatalogKeyboardSet entry;entry.name=baseName(relative);entry.path=path;entry.relativePath=relative;
    const auto* shared=cache?cache->keyboard(path):nullptr;KstCatalogKeyboardMetadata local;
    if(!shared){local=kstCatalogKeyboardMetadata(inspectPa5xPerformanceFile(path));shared=&local;}
    if(!shared->name.empty())entry.name=shared->name;
    entry.ordinal=shared->ordinal;entry.metadataSupported=shared->supported;entry.blocker=shared->blocker;
    entry.splitPoint=shared->splitPoint;entry.useGlobalSplit=shared->useGlobalSplit;entry.upperOctaveTransposeRaw=shared->upperOctave;
    entry.chordScanningRaw=shared->scan;entry.keyboardModeRaw=shared->mode;entry.parts=shared->parts;return entry;
}

void sampleEntries(Pa5xKstCatalog& out, const std::string& path, const std::string& relative,
                   const Pa5xSampleIndex& pcm,const SampleLinks& links, const std::atomic<bool>* cancel) {
    if (!pcm.valid || pcm.kind != Pa5xSampleContainerKind::PcmSamples) {
        out.warnings.push_back(relative + ": " + (pcm.error.empty() ? "Not a supported PCM sample bank" : pcm.error));
        return;
    }
    for (const auto& object : pcm.objects) {
        if (stopped(cancel)) { out.cancelled = true; return; }
        Pa5xCatalogSample entry; entry.name = object.name; entry.pcmPath = path; entry.relativePath = relative;
        entry.resourceId = object.resourceId; entry.rate = object.sampleRate; entry.frames = object.encodedSampleCount;
        const auto link = object.hasId ? links.find(object.resourceId) : links.end();
        if (link == links.end()) entry.blocker = "No exact KMP sample UID link is available";
        else if (link->second.ambiguous) entry.blocker = "Sample UID occurs in multiple KMP scopes";
        else {
            const auto& sample = link->second.sample;
            entry.kmpPath = link->second.path;
            entry.root = sample.originalNote <= 127 ? sample.originalNote : -1;
            if (object.encrypted) entry.blocker = "Encrypted waveform preview is unsupported";
            else if (!object.audioMetadataDecoded && !object.decodeError.empty()) entry.blocker = object.decodeError;
            else if (object.oc31Compressed || !object.audioMetadataDecoded || object.channelTag != 1)
                entry.blocker = "Waveform metadata/container is not supported for raw preview";
            else if (sample.sampleRate != object.sampleRate)
                entry.blocker = "PCM and KMP sample rates disagree for the exact UID";
            else if (object.encodedSampleCount == 0 || object.encodedSampleCount > kMaximumPreviewFrames)
                entry.blocker = "Waveform exceeds the bounded one-shot preview length";
            else if (object.sampleFormat == 16 && object.pcmByteOrder != Pa5xPcmByteOrder::Unknown)
                entry.previewable = true;
            else if (object.sampleFormat == 128 && sample.predictorsKnown &&
                (!sample.predictorsDerived||pa5xPredictiveCoefficientsStable(sample.predictor1,sample.predictor2)))
                entry.previewable = true;
            else entry.blocker = "Waveform codec or predictor metadata is unsupported";
        }
        out.samples.push_back(std::move(entry));
    }
}
} // namespace

Pa5xKstCatalog buildPa5xKstCatalog(const Pa5xKstIndex& index,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel,
    const Pa5xSetBank* resourceBank) {
    Pa5xKstCatalog out; out.rootPath = index.rootPath; out.name = index.name; out.recognized = index.recognized;
    for(const auto& resource:index.resources)if(resource.kind==KstResourceKind::Style)++out.discoveredStyleFiles;
    if (index.cancelled || stopped(cancel)) { out.cancelled = true; return out; }
    if (!index.recognized || index.rootPath.empty()) { out.error = "Choose a recognized KST resource root"; return out; }
    SampleLinks links;
    SampleResources sharedSamples;
    bool missingSharedSampleWarning=false;
    const auto missingSharedSample=[&]() {
        if(missingSharedSampleWarning)return;
        missingSharedSampleWarning=true;
        out.warnings.push_back("Some PCM/KMP metadata is unavailable in the loaded bank; those files were not reopened");
    };
    if(resourceBank!=nullptr) {
        // A catalog cannot accidentally resolve sample metadata from another
        // SET. Even an absent/invalid shared resource is not reread here.
        if(resourceBank->status().rootPath!=index.rootPath)
            out.warnings.push_back("Shared sample metadata belongs to another KST root; PCM/KMP entries remain unavailable");
        else for(const auto& inventory:resourceBank->sampleResourceInventories()) {
            if(stopped(cancel)){out.cancelled=true;return out;}
            if(inventory.index==nullptr)continue;
            const auto inserted=sharedSamples.emplace(inventory.sourcePath,inventory.index);
            if(!inserted.second&&inserted.first->second!=inventory.index)inserted.first->second=nullptr;
        }
    }
    const auto total = static_cast<std::uint64_t>(index.resources.size());
    if(resourceBank!=nullptr&&progress)progress({0,total,"Reusing loaded sample metadata",{}});
    for (std::size_t i = 0; i < index.resources.size(); ++i) {
        if (stopped(cancel)) { out.cancelled = true; return out; }
        const auto& resource = index.resources[i];
        if (resource.kind != KstResourceKind::Multisample || !resource.readable) continue;
        if (resourceBank==nullptr&&progress)
            progress({static_cast<std::uint64_t>(i), total, "Reading sample metadata", resource.relativePath});
        std::string path;
        if (!resourcePath(index.rootPath, resource.relativePath, path)) {
            out.warnings.push_back("Invalid catalog relative resource path"); continue;
        }
        Pa5xSampleIndex localMapping;
        const auto* mapping=sampleResource(path,sharedSamples,resourceBank!=nullptr,localMapping);
        if(mapping==nullptr) {
            missingSharedSample();continue;
        }
        if (!mapping->valid || mapping->kind!=Pa5xSampleContainerKind::Multisamples || !mapping->multisampleMappingDecoded) {
            if(resourceBank!=nullptr)missingSharedSample();
            else out.warnings.push_back(resource.relativePath + ": KMP sample mapping is unsupported");
            continue;
        }
        for (const auto& sample : mapping->samples) {
            if(stopped(cancel)){out.cancelled=true;return out;}
            const auto found = links.find(sample.resourceId);
            if (found != links.end()) found->second.ambiguous = true;
            else links.emplace(sample.resourceId, SampleLink{sample,path,false});
        }
    }
    for (std::size_t i = 0; i < index.resources.size(); ++i) {
        if (stopped(cancel)) { out.cancelled = true; return out; }
        const auto& resource = index.resources[i];
        if (progress&&!(resourceBank!=nullptr&&
            (resource.kind==KstResourceKind::Sample||resource.kind==KstResourceKind::Multisample)))
            progress({static_cast<std::uint64_t>(i), total, "Building resource lists", resource.relativePath});
        std::string path;
        if(resource.kind==KstResourceKind::Style) {
            const bool validPath=resourcePath(index.rootPath,resource.relativePath,path);
            if(validPath&&resource.readable&&paStyleBankPath(path)){
                std::string error;
                const auto oldSize=out.styles.size();
                auto append=[&](int slot,const KstCatalogStyleMetadata& m){
                    auto e=styleIdentity(path,resource.relativePath);
                    e.categoryPath=resource.relativePath;e.bankName=baseName(resource.relativePath);
                    e.path+="!/"+std::to_string(slot);e.relativePath+="!/"+std::to_string(slot);
                    e.fileName=std::to_string(slot+1)+"."+m.name;e.name=m.name;
                    e.positionOrdinal=slot+1;e.bpm=m.bpm;e.numerator=m.numerator;e.denominator=m.denominator;
                    e.loadable=m.loadable;e.warnings=m.warnings;e.error=m.error;e.originalSettings=m.originalSettings;
                    out.styles.push_back(std::move(e));
                };
                bool cached=false;
                if(index.metadataReadCache){
                    const auto& banks=index.metadataReadCache->legacy;auto found=banks.find(path);
                    if(found!=banks.end()&&sameKstMetadataRevision(found->second.first,kstMetadataRevision(path))){
                        for(const auto& row:found->second.second)append(row.slot,row.metadata);
                        cached=true;
                    }
                }
                if(!cached)inspectPaStyleBank(path,[&](int slot,const std::string& name,const Pa5xStyleRead& read){
                    if(stopped(cancel))return false;
                    auto m=kstReadStyleMetadata(read);m.name=name;
                    if(read.nativeStyle&&!m.loadable&&std::none_of(read.nativeStyle->sections.begin(),read.nativeStyle->sections.end(),[](const auto& sec){return sec.available;}))
                        m.error="Empty Style slot: no MIDI phrases";
                    append(slot,m);return true;
                },error);
                if(stopped(cancel)){out.cancelled=true;return out;}
                if(error.empty()){
                    out.discoveredStyleFiles+=out.styles.size()-oldSize;
                    --out.discoveredStyleFiles;
                    continue;
                }
                auto failed=styleIdentity(path,resource.relativePath);failed.categoryPath=resource.relativePath;failed.error=error;
                failed.originalSettings=unavailablePa5xStyleSourceSettings(error);out.styles.push_back(std::move(failed));
                continue;
            }
            auto entry=styleIdentity(path,resource.relativePath);
            if(!validPath)entry.error="Invalid relative Style resource path";
            else if(!resource.readable)entry.error="Style resource is not readable";
            else try {entry=styleEntry(path,resource.relativePath,index.metadataReadCache.get());}
            catch(const std::exception& e){entry.error=e.what();}
            catch(...){entry.error="Style reader failed with an unknown error";}
            if(!entry.originalSettings.indexed)entry.originalSettings=unavailablePa5xStyleSourceSettings(entry.error);
            // Every discovered Style stays visible, including a failed or
            // unsupported resource. Selection can show its exact error.
            out.styles.push_back(std::move(entry));
            continue;
        }
        if (!resourcePath(index.rootPath, resource.relativePath, path)) {
            out.warnings.push_back("Invalid catalog relative resource path"); continue;
        }
        const auto reportResourceFailure = [&](const std::string& reason) {
            out.warnings.push_back(resource.relativePath + ": " + reason);
            if (resource.kind == KstResourceKind::KeyboardSet && paPerformanceBankPath(path)) {
                Pa5xCatalogKeyboardSet failed;
                failed.name=baseName(resource.relativePath); failed.path=path;
                failed.relativePath=resource.relativePath; failed.blocker=reason;
                out.keyboardSets.push_back(std::move(failed));
            }
        };
        if (!resource.readable) { reportResourceFailure("Resource is not readable"); continue; }
        try {
            switch (resource.kind) {
                case KstResourceKind::Style: break; // retained above even on a reader failure
                case KstResourceKind::Sound: soundEntries(out,path,resource.relativePath,cancel,resourceBank,index.metadataReadCache.get()); break;
                case KstResourceKind::KeyboardSet:
                    if(paPerformanceBankPath(path)){
                        std::string error;
                        inspectPaPerformanceBank(path,[&](int slot,const Pa5xPerformanceInspection& k){
                            if(stopped(cancel))return false;
                            Pa5xCatalogKeyboardSet e;e.name=k.displayName;e.path=k.sourcePath;e.ordinal=slot+1;
                            e.relativePath=resource.relativePath+"!/"+std::to_string(slot);e.parts=k.parts;
                            e.splitPoint=k.splitPoint;e.useGlobalSplit=k.useGlobalSplit;e.metadataSupported=k.valid;e.blocker=k.error;
                            out.keyboardSets.push_back(std::move(e));return true;
                        },error);
                        if(!error.empty())reportResourceFailure(error);
                    }else out.keyboardSets.push_back(keyboardEntry(path,resource.relativePath,index.metadataReadCache.get()));
                    break;
                case KstResourceKind::Sample: {
                    Pa5xSampleIndex localPcm;
                    const auto* pcm=sampleResource(path,sharedSamples,resourceBank!=nullptr,localPcm);
                    if(pcm==nullptr)missingSharedSample();
                    else if(resourceBank!=nullptr&&(!pcm->valid||pcm->kind!=Pa5xSampleContainerKind::PcmSamples))
                        missingSharedSample();
                    else sampleEntries(out,path,resource.relativePath,*pcm,links,cancel);
                    break;
                }
                default: break;
            }
        } catch (const std::exception& e) { reportResourceFailure(e.what()); }
        if (out.cancelled) return out;
    }
    styleGroups(out,index,cancel);
    if(out.cancelled)return out;
    for(const auto& style:out.styles)if(!style.loadable)++out.unavailableStyles;
    out.styleListComplete=out.styles.size()==out.discoveredStyleFiles&&!styleDiscoveryIncomplete(index);
    if(out.styles.size()!=out.discoveredStyleFiles)out.warnings.push_back("Style catalog count mismatch: "+
        std::to_string(out.styles.size())+" listed of "+std::to_string(out.discoveredStyleFiles)+" discovered STG files");
    else if(!out.styleListComplete)out.warnings.push_back("STYLE discovery was incomplete; all "+
        std::to_string(out.discoveredStyleFiles)+" discovered STG files remain listed");
    if (!out.samples.empty()) out.warnings.push_back("Sample preview is raw one-shot PCM at its stored rate/root; PCG DSP and loop parameters are not applied");
    if (progress) progress({total,total,"Resource lists ready",{}});
    return out;
}

bool refreshPa5xKstStyleMetadata(Pa5xKstCatalog& catalog,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel) {
    if(catalog.cancelled||stopped(cancel)){catalog.cancelled=true;return false;}
    const auto needsRead=[](const Pa5xCatalogStyle& entry){
        return !entry.originalSettings.indexed||!entry.originalSettings.valid();
    };
    if(std::none_of(catalog.styles.begin(),catalog.styles.end(),needsRead))return true;
    if(catalog.rootPath.empty()||catalog.rootPath.find('\0')!=std::string::npos)return false;
    std::unique_ptr<char,decltype(&std::free)> resolvedRoot(::realpath(catalog.rootPath.c_str(),nullptr),&std::free);
    if(!resolvedRoot)return false;
    const std::string root=resolvedRoot.get();
    struct Target {std::size_t index;int slot;};
    std::map<std::string,std::vector<Target>> files;
    const auto fail=[&](std::size_t index,const std::string& error){
        auto& entry=catalog.styles[index];entry.loadable=false;entry.error=error;
        entry.originalSettings=unavailablePa5xStyleSourceSettings(error);
    };
    const auto apply=[&](std::size_t index,const KstCatalogStyleMetadata& metadata){
        auto& entry=catalog.styles[index];
        // Display names, metadir ordering, categories and slot identities are
        // retained from the saved catalog, not reconstructed during migration.
        entry.bpm=metadata.bpm;entry.numerator=metadata.numerator;entry.denominator=metadata.denominator;
        entry.loadable=metadata.loadable;entry.error=metadata.error;entry.warnings=metadata.warnings;
        entry.originalSettings=metadata.originalSettings;
    };
    for(std::size_t i=0;i<catalog.styles.size();++i){
        if(stopped(cancel)){catalog.cancelled=true;return false;}
        auto& entry=catalog.styles[i];if(!needsRead(entry))continue;
        entry.originalSettings={};
        std::string expected,physical;int slot=-1;
        if(!resourcePath(catalog.rootPath,entry.relativePath,expected)||expected!=entry.path){
            fail(i,"Invalid retained Style resource path");continue;
        }
        if(!paStyleSlot(entry.path,&physical,&slot))physical=entry.path;
        const auto suffix=asciiLower(physical.substr(physical.find_last_of('.')==std::string::npos?
            physical.size():physical.find_last_of('.')));
        if(suffix!=".sty"&&suffix!=".stg"&&!kstMidiStyle(physical)){
            fail(i,"Unsupported retained Style resource path");continue;
        }
        std::unique_ptr<char,decltype(&std::free)> resolved(::realpath(physical.c_str(),nullptr),&std::free);
        if(!resolved){fail(i,"Original Style resource is unavailable");continue;}
        const std::string path=resolved.get();
        if(path.size()<=root.size()||path.compare(0,root.size(),root)!=0||
            (root!="/"&&path[root.size()]!='/')){
            fail(i,"Original Style resource is outside its SET root");continue;
        }
        files[path].push_back({i,slot});
    }
    const auto total=static_cast<std::uint64_t>(files.size());std::uint64_t completed=0;
    for(const auto& file:files){
        if(stopped(cancel)){catalog.cancelled=true;return false;}
        if(progress)progress({completed,total,"Reading original Style settings",catalog.styles[file.second.front().index].relativePath});
        const auto before=kstMetadataRevision(file.first);
        std::string error;
        if(!before.valid)error="Original Style resource is not a regular readable file";
        else try{
            if(paStyleBankPath(file.first)){
                // The bank reader opens/decompresses a physical STY once. Its
                // callback reduces each requested slot without retaining MIDI.
                std::map<int,std::vector<std::size_t>> slots;
                for(const auto& target:file.second)if(target.slot>=0)slots[target.slot].push_back(target.index);
                const bool read=inspectPaStyleBank(file.first,[&](int slot,const std::string&,const Pa5xStyleRead& style){
                    if(stopped(cancel))return false;
                    const auto found=slots.find(slot);if(found==slots.end())return true;
                    auto metadata=kstReadStyleMetadata(style);
                    if(style.nativeStyle&&!metadata.loadable&&std::none_of(style.nativeStyle->sections.begin(),
                        style.nativeStyle->sections.end(),[](const auto& section){return section.available;}))
                        metadata.error="Empty Style slot: no MIDI phrases";
                    for(const auto index:found->second)apply(index,metadata);
                    return true;
                },error);
                if(!read&&error.empty()&&!stopped(cancel))error="Original Style bank inspection did not complete";
            }else{
                const auto& first=catalog.styles[file.second.front().index];
                const auto metadata=styleEntry(file.first,first.relativePath,nullptr);
                for(const auto& target:file.second){
                    auto& entry=catalog.styles[target.index];
                    entry.bpm=metadata.bpm;entry.numerator=metadata.numerator;entry.denominator=metadata.denominator;
                    entry.loadable=metadata.loadable;entry.error=metadata.error;entry.warnings=metadata.warnings;
                    entry.originalSettings=metadata.originalSettings;
                }
            }
        }catch(const std::exception& failure){error=failure.what();}
        catch(...){error="Original Style settings reader failed with an unknown error";}
        if(stopped(cancel)){catalog.cancelled=true;return false;}
        if(before.valid&&!sameKstMetadataRevision(before,kstMetadataRevision(file.first))){
            catalog.error="Original Style resource changed while its settings were read; reload the SET";
            return false;
        }
        for(const auto& target:file.second){
            auto& summary=catalog.styles[target.index].originalSettings;
            if(!error.empty())fail(target.index,error);
            else if(!summary.indexed||!summary.valid())fail(target.index,target.slot<0?
                "Original Style bank has no retained slot to refresh; reload the SET":
                "Original Style slot is missing from its retained bank");
        }
        ++completed;
    }
    catalog.unavailableStyles=static_cast<std::uint64_t>(std::count_if(catalog.styles.begin(),catalog.styles.end(),
        [](const auto& entry){return !entry.loadable;}));
    if(progress)progress({total,total,"Original Style settings ready",{}});
    return true;
}

Pa5xKstCatalog buildPa5xKstCatalog(const std::string& rootPath,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel) {
    // This convenience path has no reusable bank. Let the catalog itself do
    // the one sample-container inspection instead of repeating the index pass.
    const auto index = indexPa5xKst(rootPath,progress,cancel,true);
    return buildPa5xKstCatalog(index,progress,cancel);
}
} // namespace silveton::arranger
