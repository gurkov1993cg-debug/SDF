#include "silveton/arranger/Pa5xPredictiveDecoder.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace silveton::arranger {
namespace {

// The residual transfer curve is generated from its exponential law, rounded
// to six decimal places and then represented as float32. The published curve
// has one exceptional magnitude at |code|=124. No reference source or lookup
// table is embedded here. Format behavior was checked with the original
// aczwink/KORG-Tools src/PCMFormat/Compression.cpp in a separate test executable.
const std::array<float, 256>& residualCurve() {
    static const auto curve = [] {
        std::array<float, 256> values{};
        for (std::size_t raw = 0; raw < values.size(); ++raw) {
            const int code = raw < 128U ? static_cast<int>(raw)
                                        : static_cast<int>(raw) - 256;
            const int magnitude = code < 0 ? -code : code;
            double value = (std::exp2(static_cast<double>(magnitude) / 16.0) - 1.0) / 255.0;
            value = std::floor(value * 1000000.0 + 0.5) / 1000000.0;
            if (magnitude == 124) value = 0.840273;
            values[raw] = static_cast<float>(code < 0 ? -value : value);
        }
        return values;
    }();
    return curve;
}

}

bool pa5xPredictiveCoefficientsStable(std::int16_t predictor1,
                                    std::int16_t predictor2) noexcept {
    const int first = predictor1, second = predictor2;
    // Jury conditions for z^2 - (first/16384)z - second/16384.
    return second > -16384 && second < 16384 &&
           first + second < 16384 && second - first < 16384;
}

Pa5xPredictiveAudio decodePa5xPredictive(
    const std::uint8_t* encoded, std::size_t encodedBytes,
    std::size_t expectedSamples, std::int16_t predictor1, std::int16_t predictor2,
    std::size_t maximumSamples, bool coefficientsFromDeclaredFields) {
    Pa5xPredictiveAudio result;
    if (expectedSamples == 0 || expectedSamples > maximumSamples ||
        encodedBytes != expectedSamples || encoded == nullptr) {
        result.error = "Predictive PCM sample count or byte span is invalid";
        return result;
    }
    const bool stable=pa5xPredictiveCoefficientsStable(predictor1,predictor2);
    if (!stable && !coefficientsFromDeclaredFields) {
        result.error = "Predictive PCM coefficients are unstable or unsupported";
        return result;
    }
    const double first = static_cast<double>(predictor1) / 16384.0;
    const double second = static_cast<double>(predictor2) / 16384.0;
    const double discriminant = first * first + 4.0 * second;
    const double radius = discriminant < 0.0
        ? std::sqrt(-second)
        : std::max(std::abs((first + std::sqrt(discriminant)) * 0.5),
                   std::abs((first - std::sqrt(discriminant)) * 0.5));
    if (!std::isfinite(radius) || (stable && radius >= 1.0)) {
        result.error = "Predictive PCM feedback bound is invalid";
        return result;
    }
    // Each impulse coefficient is a sum of n+1 products of the two poles:
    // |h[n]| <= (n+1)*radius^n. Since |residual| <= 1, the infinite input/output
    // bound is 1/(1-radius)^2, including a repeated-pole predictor. A small
    // margin accommodates double rounding; output clipping never feeds back.
    const double gap = 1.0 - radius;
    // Older KMPs explicitly store both predictors. Genuine Pa1000 short samples
    // can have poles outside the unit circle. Decode their finite record with
    // the same recurrence and clipping, rejecting floating-point overflow.
    const double feedbackLimit = stable ? (1.0 / (gap * gap)) * 1.000001 :
        std::numeric_limits<double>::max()/32768.0;
    const auto& curve = residualCurve();
    result.samples.resize(expectedSamples);
    double recent = 0.0, older = 0.0;
    for (std::size_t index = 0; index < expectedSamples; ++index) {
        // Keep separate products and their order on targets with fused multiply
        // instructions, matching the validated non-fused reference model.
        const volatile double olderContribution = older * second;
        const volatile double recentContribution = recent * first;
        const double value = (olderContribution + recentContribution) +
                             static_cast<double>(curve[encoded[index]]);
        if (!std::isfinite(value) || std::abs(value) > feedbackLimit) {
            result.samples.clear();
            result.error = "Predictive PCM exceeded its finite feedback bound";
            return result;
        }
        older = recent;
        recent = value;
        const double scaled = std::clamp(value * 32768.0, -32767.0, 32767.0);
        result.samples[index] = static_cast<std::int16_t>(scaled);
    }
    return result;
}

}
