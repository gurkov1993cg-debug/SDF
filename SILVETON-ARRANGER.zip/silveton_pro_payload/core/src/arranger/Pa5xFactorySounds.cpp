#include "silveton/arranger/Pa5xFactorySounds.h"

namespace silveton::arranger {
namespace {

#include "Pa5xFactorySoundData.inc"

constexpr std::size_t kCount = sizeof(kCatalog) / sizeof(kCatalog[0]);
constexpr Pa5xFactorySoundCatalogInfo kInfo{
    "KORG Pa5X User Manual v1.5 (English)", "1.5", "EN13",
    "https://www.korg.com/us/support/download/manual/0/895/5749/",
    "https://cdn.korg.com/us/support/download/files/bcf8ec4dbc7820739bc28e0d1bbfb1af.zip",
    "6450ce557f66e25b205e283c29c616b8da58fcba8e94b9d9ef554303676be7f5",
    1590, 1637, 1639, 1641, 1949, true
};

constexpr std::uint32_t address(const Pa5xFactorySound& sound) noexcept {
    return (static_cast<std::uint32_t>(sound.msb) << 14U) |
           (static_cast<std::uint32_t>(sound.lsb) << 7U) | sound.rawProgram;
}

}

const Pa5xFactorySound* findPa5xFactorySound(int msb, int lsb, int rawProgram) noexcept {
    if (msb < 0 || msb > 127 || lsb < 0 || lsb > 127 || rawProgram < 0 || rawProgram > 127)
        return nullptr;
    const auto wanted = (static_cast<std::uint32_t>(msb) << 14U) |
                        (static_cast<std::uint32_t>(lsb) << 7U) |
                        static_cast<std::uint32_t>(rawProgram);
    std::size_t first = 0, last = kCount;
    while (first < last) {
        const auto middle = first + (last - first) / 2U;
        if (address(kCatalog[middle]) < wanted) first = middle + 1U;
        else last = middle;
    }
    return first < kCount && address(kCatalog[first]) == wanted ? &kCatalog[first] : nullptr;
}

const Pa5xFactorySound* pa5xFactorySounds() noexcept { return kCatalog; }
std::size_t pa5xFactorySoundCount() noexcept { return kCount; }
const Pa5xFactorySoundCatalogInfo& pa5xFactorySoundCatalogInfo() noexcept { return kInfo; }

}
