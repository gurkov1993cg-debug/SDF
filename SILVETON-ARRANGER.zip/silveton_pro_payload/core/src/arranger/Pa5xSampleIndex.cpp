#include "silveton/arranger/Pa5xSampleIndex.h"
#include "silveton/arranger/Pa5xOc31.h"
#include "silveton/arranger/Pa5xPredictiveDecoder.h"

#include <algorithm>
#include <cstring>
#include <fstream>
#include <limits>
#include <set>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumFile = 256U * 1024U * 1024U;
std::uint16_t u16(const std::vector<std::uint8_t>& b, std::size_t p) {
    return static_cast<std::uint16_t>((static_cast<unsigned>(b[p]) << 8U) | b[p+1]);
}
std::int16_t i16(const std::vector<std::uint8_t>& b, std::size_t p) {
    const auto v=u16(b,p);return static_cast<std::int16_t>(v<32768?v:static_cast<int>(v)-65536);
}
std::uint32_t u32(const std::vector<std::uint8_t>& b, std::size_t p) {
    return (static_cast<std::uint32_t>(b[p])<<24U)|(static_cast<std::uint32_t>(b[p+1])<<16U)|
        (static_cast<std::uint32_t>(b[p+2])<<8U)|b[p+3];
}
std::uint64_t u64(const std::vector<std::uint8_t>& b, std::size_t p) {
    return (static_cast<std::uint64_t>(u32(b,p))<<32U)|u32(b,p+4);
}
std::int32_t i32(const std::vector<std::uint8_t>& b, std::size_t p) {
    const auto n = u32(b,p);
    return n <= 0x7FFFFFFFU ? static_cast<std::int32_t>(n)
        : -1 - static_cast<std::int32_t>(0xFFFFFFFFU - n);
}
std::string text(const std::vector<std::uint8_t>& b,std::size_t p,std::size_t n) {
    std::size_t count=0;while(count<n&&b[p+count]!=0)++count;
    std::string out(reinterpret_cast<const char*>(b.data()+p),count);
    while(!out.empty()&&out.back()==' ')out.pop_back();
    return out;
}
bool parseKmp(const std::vector<std::uint8_t>& b,Pa5xSampleIndex& out) {
    if(b.size()<10||(u16(b,0)!=3 && u16(b,0)!=0x0103U)){out.blockers.push_back("Unsupported decoded KMP table revision");return false;}
    const std::size_t ns=u16(b,2),nd=u16(b,4),nz=u16(b,6),nm=u16(b,8);
    if(10+ns*111+nd*48+nz*20+nm*166!=b.size()){
        out.blockers.push_back("Decoded KMP v5 table lengths do not match the resource boundary");return false;
    }
    std::size_t p=10;
    out.samples.reserve(ns);out.drumSamples.reserve(nd);out.keyZones.reserve(nz);out.multisamples.reserve(nm);
    for(std::size_t n=0;n<ns;++n,p+=111){
        Pa5xKmpSample s;s.name=text(b,p+80,16);s.resourceId=u64(b,p+96);s.bank=b[p+6];
        s.packedData=u16(b,p+4);s.predictor1=i16(b,p+60);s.predictor2=i16(b,p+62);
        s.sampleRate=u32(b,p+106);s.originalNote=b[p+110];out.samples.push_back(std::move(s));
    }
    for(std::size_t n=0;n<nd;++n,p+=48){
        Pa5xKmpDrumSample s;s.leftSample=i16(b,p);s.rightSample=i16(b,p+2);s.bank=b[p+8];s.family=b[p+9];
        s.name=text(b,p+12,24);s.resourceId=u64(b,p+40);out.drumSamples.push_back(std::move(s));
        const auto& published=out.drumSamples.back();
        for(const auto index:{published.leftSample,published.rightSample})if(index < -1 || (index>=0&&static_cast<std::size_t>(index)>=ns)){
            out.blockers.push_back("KMP drum map references a missing sample entry");return false;
        }
    }
    for(std::size_t n=0;n<nz;++n,p+=20){
        Pa5xKmpKeyZone z;z.sampleIndex=i16(b,p);z.highNote=b[p+3];z.originalNote=b[p+4];
        z.pitch=i16(b,p+6);z.level=static_cast<std::int8_t>(b[p+8]<128?b[p+8]:static_cast<int>(b[p+8])-256);
        std::copy_n(b.begin()+static_cast<std::ptrdiff_t>(p),20,z.version5Record.begin());
        if(z.sampleIndex < -1 || (z.sampleIndex>=0&&static_cast<std::size_t>(z.sampleIndex)>=ns)){out.blockers.push_back("KMP key zone references a missing sample entry");return false;}
        out.keyZones.push_back(z);
    }
    for(std::size_t n=0;n<nm;++n,p+=166){
        Pa5xKmpMultisample m;m.name=text(b,p+2,24);m.firstZone=u16(b,p+26);m.zoneCount=b[p+156];m.resourceId=u64(b,p+158);
        std::copy_n(b.begin()+static_cast<std::ptrdiff_t>(p+28),128,m.zoneIndices.begin());
        if(static_cast<std::size_t>(m.firstZone)+m.zoneCount>nz){out.blockers.push_back("KMP multisample zone range exceeds its key-zone table");return false;}
        for(const auto index:m.zoneIndices)if(index!=255&&index>=m.zoneCount){out.blockers.push_back("KMP key map references a zone outside its multisample");return false;}
        out.multisamples.push_back(std::move(m));
    }
    out.multisampleMappingDecoded=true;return true;
}
bool parseKmp8(const std::vector<std::uint8_t>& b,Pa5xSampleIndex& out) {
    // Version 8 layout is evidenced by the uploaded Pa5X v1.4.3 bank. Every
    // table consumes its exact declared boundary, and all numerical sample,
    // drum and zone references are checked before mapping publication.
    if(b.size()<18||u16(b,0)!=0x0103U){out.blockers.push_back("Unsupported decoded KMP v8 table revision");return false;}
    const std::size_t ns=u32(b,2),nd=u32(b,6),nz=u32(b,10),nm=u32(b,14);
    const std::uint64_t expected=18ULL+static_cast<std::uint64_t>(ns)*122ULL+
        static_cast<std::uint64_t>(nd)*126ULL+static_cast<std::uint64_t>(nz)*16ULL+
        static_cast<std::uint64_t>(nm)*176ULL;
    if(expected!=b.size()){out.blockers.push_back("Decoded KMP v8 table lengths do not match the resource boundary");return false;}
    std::size_t p=18;
    out.samples.reserve(ns);out.drumSamples.reserve(nd);out.keyZones.reserve(nz);out.multisamples.reserve(nm);
    for(std::size_t n=0;n<ns;++n,p+=122){
        Pa5xKmpSample s;s.name=text(b,p+75,32);s.resourceId=u64(b,p+107);
        s.packedData=u16(b,p+4);s.bankKnown=false;
        // The v8 prefix removes one byte before the old Q14 pair. Every
        // paired predictive resource in the supplied corpus has stable values
        // here; every paired linear resource has the zero pair. Keep the
        // empirical provenance explicit and reject unsupported predictors.
        s.predictor1=i16(b,p+59);s.predictor2=i16(b,p+61);s.predictorsDerived=true;
        s.predictorsKnown=pa5xPredictiveCoefficientsStable(s.predictor1,s.predictor2);
        std::copy_n(b.begin()+static_cast<std::ptrdiff_t>(p),75,s.version8Prefix.begin());
        s.sampleRate=u32(b,p+117);s.originalNote=b[p+121];
        if(s.sampleRate<8000||s.sampleRate>192000){out.blockers.push_back("KMP v8 sample rate is outside the supported range");return false;}
        out.samples.push_back(std::move(s));
    }
    for(std::size_t n=0;n<nd;++n,p+=126){
        Pa5xKmpDrumSample s;s.name=text(b,p,32);s.bank=b[p+112];s.family=b[p+113];s.resourceId=u64(b,p+118);
        s.version8ReferencesPresent=true;s.stereoPairingKnown=false;
        for(std::size_t layer=0;layer<4;++layer)for(std::size_t ref=0;ref<4;++ref){
            const auto index=i32(b,p+32+layer*20+ref*4);
            if(index < -1 || (index>=0&&static_cast<std::size_t>(index)>=ns)){
                out.blockers.push_back("KMP v8 drum map references a missing sample entry");return false;
            }
            s.version8References[layer*4+ref]=index;
        }
        s.leftSample=s.version8References[0];s.rightSample=s.version8References[1];
        out.drumSamples.push_back(std::move(s));
    }
    for(std::size_t n=0;n<nz;++n,p+=16){
        Pa5xKmpKeyZone z;z.sampleIndex=i32(b,p);z.highNote=b[p+10];z.originalNote=b[p+11];
        z.pitchLevelDecoded=false;
        std::copy_n(b.begin()+static_cast<std::ptrdiff_t>(p),16,z.version8Record.begin());
        if(z.sampleIndex < -1 || (z.sampleIndex>=0&&static_cast<std::size_t>(z.sampleIndex)>=ns)){
            out.blockers.push_back("KMP v8 key zone references a missing sample entry");return false;
        }
        if(z.highNote>127){out.blockers.push_back("KMP v8 key zone has an invalid high note");return false;}
        out.keyZones.push_back(z);
    }
    for(std::size_t n=0;n<nm;++n,p+=176){
        Pa5xKmpMultisample m;m.name=text(b,p,32);m.firstZone=u32(b,p+32);m.zoneCount=b[p+166];m.resourceId=u64(b,p+168);
        std::copy_n(b.begin()+static_cast<std::ptrdiff_t>(p+36),128,m.zoneIndices.begin());
        if(static_cast<std::uint64_t>(m.firstZone)+m.zoneCount>nz){out.blockers.push_back("KMP v8 multisample zone range exceeds its key-zone table");return false;}
        for(const auto index:m.zoneIndices)if(index!=255&&index>=m.zoneCount){out.blockers.push_back("KMP v8 key map references a zone outside its multisample");return false;}
        out.multisamples.push_back(std::move(m));
    }
    out.blockers.push_back("KMP v8 sample predictors are empirically derived; other sample/zone DSP parameters remain undecoded");
    out.multisampleMappingDecoded=true;return true;
}
}

Pa5xSampleIndex inspectPa5xSampleBytes(const std::vector<std::uint8_t>& b,
                                     bool allowPartialAudio) {
    Pa5xSampleIndex out;
    const auto fail=[&](const std::string& error){out.error=error;out.valid=false;return out;};
    if(b.size()<56||b.size()>kMaximumFile)return fail("Korg sample container size is unsupported");
    if(b[0]!=1||std::memcmp(b.data()+23,"KORF",4)!=0)return fail("Korg KORF sample container header is missing");
    out.recognized=true;
    if(u32(b,0)!=0x01000114U||u32(b,8)!=0x02000018U||u32(b,16)!=0x0B000000U||
       b[20]!=0||b[21]!=0||b[22]!=0||b[27]!=0)
        return fail("Unsupported Korg root or metadata revision/flags");
    if(u32(b,4)!=b.size()-8)return fail("Korg outer container length is inconsistent");
    if(b[8]!=2||u32(b,12)!=12||b[28]!=5)return fail("Unsupported Korg KORF/TOC chunk layout");
    out.tocVersionMajor=b[29];out.tocVersionMinor=b[30];
    if(out.tocVersionMajor!=1||out.tocVersionMinor>1||b[31]!=0x18)return fail("Unsupported Korg sample TOC version or flags");
    const std::size_t tocSize=u32(b,32),tocEnd=36+tocSize;
    if(tocEnd>b.size()-20)return fail("Korg sample TOC exceeds the container");
    std::size_t pos=36;
    std::set<std::uint64_t> ids;
    while(pos<tocEnd){
        if(tocEnd-pos<8)return fail("Korg sample TOC entry is truncated");
        const std::size_t size=u16(b,pos),entryEnd=pos+2+size;
        if(size<6||entryEnd>tocEnd)return fail("Korg sample TOC entry exceeds its chunk");
        const auto properties=u16(b,pos+2);if(properties>64)return fail("Korg sample TOC has too many properties");
        Pa5xSampleObject object;bool typed=false,versioned=false,named=false;
        std::set<unsigned> seen;std::size_t q=pos+4;
        for(unsigned prop=0;prop<properties;++prop){
            if(entryEnd-4-q<4)return fail("Korg sample TOC property header is truncated");
            const auto type=u16(b,q);const std::size_t length=u16(b,q+2);q+=4;
            if(length>entryEnd-4-q||!seen.insert(type).second)return fail("Korg sample TOC property boundary or duplicate is invalid");
            if(type==0){if(length!=3)return fail("Korg object address has the wrong size");object.objectType=b[q];object.rawBank=b[q+1];object.rawSlot=b[q+2];typed=true;}
            else if(type==1){if(length!=2)return fail("Korg object version has the wrong size");object.versionMajor=b[q];object.versionMinor=b[q+1];versioned=true;}
            else if(type==2){if(length==0||length>1024)return fail("Korg object name has the wrong size");object.name=text(b,q,length);named=true;}
            else if(type==4){if(length!=8)return fail("Korg object ID has the wrong size");object.resourceId=u64(b,q);object.hasId=true;}
            q+=length;
        }
        if(q!=entryEnd-4||!typed||!versioned||!named)return fail("Korg sample TOC entry is incomplete");
        if(object.objectType!=5&&object.objectType!=6)return fail("This KORF container is not PCM or multisample data");
        const auto kind=object.objectType==5?Pa5xSampleContainerKind::Multisamples:Pa5xSampleContainerKind::PcmSamples;
        if(out.kind!=Pa5xSampleContainerKind::Unknown&&out.kind!=kind)return fail("Mixed Korg sample object classes are unsupported");
        out.kind=kind;
        if(object.hasId&&!ids.insert(object.resourceId).second)return fail("Duplicate resource ID inside a Korg sample container");
        out.objects.push_back(std::move(object));pos=entryEnd;
    }
    if(out.objects.empty())return fail("Korg sample container has no objects");
    if(out.kind==Pa5xSampleContainerKind::Multisamples&&out.objects.size()!=1)
        return fail("Multiple independently scoped KMP objects are not supported");
    const std::size_t count=u32(b,b.size()-4);
    if(count!=out.objects.size()+1||count>(b.size()-20)/4)return fail("Korg sample cross-reference count does not match its TOC");
    const std::size_t xref=b.size()-20-count*4;
    if(xref<tocEnd||b[xref]!=0xFE||u32(b,xref+4)!=count*4+12||
       std::memcmp(b.data()+xref+8,"KBEG",4)!=0||std::memcmp(b.data()+b.size()-8,"KEND",4)!=0||u32(b,xref+12)!=28)
        return fail("Korg sample cross-reference trailer is invalid");
    std::size_t next=tocEnd;
    for(std::size_t n=0;n<out.objects.size();++n){
        auto& object=out.objects[n];const std::size_t at=u32(b,xref+16+n*4);
        if(at!=next||at>xref||xref-at<8)return fail("Korg sample payload offsets overlap or are out of order");
        object.payloadFlags=b[at+3];object.payloadOffset=at+8;object.payloadBytes=u32(b,at+4);
        if(object.payloadBytes>xref-object.payloadOffset)return fail("Korg sample payload exceeds its container");
        const unsigned expectedType=object.objectType==5?0x11:0x12;
        if(b[at]!=expectedType||b[at+1]!=object.versionMajor||b[at+2]!=object.versionMinor)
            return fail("Korg sample payload type/version does not match its TOC");
        const bool nestedPcm=object.objectType==6&&object.versionMajor==2&&object.versionMinor==0;
        // 0x08 is the Korg leaf flag. Version 2 PCM is instead a non-leaf
        // bank-marked resource containing two separately bounded leaf chunks.
        if(nestedPcm?object.payloadFlags!=0x10U:
           ((object.payloadFlags&~0x78U)!=0||(object.payloadFlags&0x18U)!=0x18U))
            return fail("Unknown Korg sample payload flags");
        object.oc31Compressed=(object.payloadFlags&0x20U)!=0;object.encrypted=(object.payloadFlags&0x40U)!=0;
        const std::uint8_t* payload=b.data()+object.payloadOffset;std::size_t payloadSize=object.payloadBytes;
        std::vector<std::uint8_t> decoded;
        if(object.encrypted){object.decodeError="Encrypted Korg resource requires its supported authorization/decryption path";}
        else {
            if(object.oc31Compressed){auto result=decodePa5xOc31(payload,payloadSize);
                if(!result)return fail("Korg OC31 resource failed validation: "+result.error);
                decoded=std::move(result.data);payload=decoded.data();payloadSize=decoded.size();}
            object.containerDecoded=true;object.decodedContainerBytes=payloadSize;
            if(object.objectType==5){
                if(!object.oc31Compressed)decoded.assign(payload,payload+payloadSize);
                if((object.versionMajor==5||object.versionMajor==8)&&object.versionMinor==0){
                    Pa5xSampleIndex mapping;
                    const bool mapped=object.versionMajor==5?parseKmp(decoded,mapping):parseKmp8(decoded,mapping);
                    if(mapped){
                        out.samples=std::move(mapping.samples);out.drumSamples=std::move(mapping.drumSamples);
                        out.keyZones=std::move(mapping.keyZones);out.multisamples=std::move(mapping.multisamples);
                        out.multisampleMappingDecoded=true;
                        out.blockers.insert(out.blockers.end(),mapping.blockers.begin(),mapping.blockers.end());
                    }else{
                        out.blockers.insert(out.blockers.end(),mapping.blockers.begin(),mapping.blockers.end());
                        if(decoded.size()>=2&&(u16(decoded,0)==3||u16(decoded,0)==0x0103U))return fail("Invalid decoded KMP table: "+out.blockers.back());
                    }
                }
                else out.blockers.push_back("Unsupported Korg multisample payload version");
            } else if((object.versionMajor==0||object.versionMajor==2)&&object.versionMinor==0){
                const bool nested=object.versionMajor==2;
                const std::size_t metadataOffset=nested?8U:0U;
                const std::size_t audioOffset=nested?82U:66U;
                const auto read32=[&](std::size_t o){return (static_cast<std::uint32_t>(payload[o])<<24U)|(static_cast<std::uint32_t>(payload[o+1])<<16U)|(static_cast<std::uint32_t>(payload[o+2])<<8U)|payload[o+3];};
                // The outer payload has already been bounded against the xref.
                // Keep its identifier validation strict even when its local
                // audio header cannot be played. A truncated header may retain
                // its TOC identifier, but never publishes a usable audio span.
                if(payloadSize>=metadataOffset+8U){
                    const auto id=(static_cast<std::uint64_t>(read32(metadataOffset))<<32U)|read32(metadataOffset+4);
                    if(object.hasId&&id!=object.resourceId)return fail("Korg PCM data ID does not match its TOC ID");
                    if(!object.hasId){
                        if(!ids.insert(id).second)return fail("Duplicate PCM ID read from an object payload");
                        object.resourceId=id;object.hasId=true;object.idFromPayload=true;
                    }
                }
                std::string audioError;
                if(payloadSize<audioOffset)audioError="Korg PCM metadata is truncated";
                else if(nested&&(read32(0)!=0x00000008U||read32(4)!=66U||
                    read32(74)!=0x01000008U||static_cast<std::uint64_t>(read32(78))!=payloadSize-audioOffset))
                    audioError="Korg PCM v2 nested metadata/audio boundaries are invalid";
                else {
                    object.channelTag=payload[metadataOffset+8];object.sampleFormat=payload[metadataOffset+9];
                    object.sampleRate=read32(metadataOffset+10);object.encodedSampleCount=read32(metadataOffset+14);object.loopStart=read32(metadataOffset+50);
                    for(std::size_t word=0;word<object.rawAudioHeaderWords.size();++word)
                        object.rawAudioHeaderWords[word]=read32(metadataOffset+18+word*4);
                    object.endPositionRaw=read32(metadataOffset+54);object.secondaryEndPositionRaw=read32(metadataOffset+62);
                    const std::size_t width=object.sampleFormat==16?2:(object.sampleFormat==128?1:0);
                    const std::uint64_t audioBytes=static_cast<std::uint64_t>(object.encodedSampleCount)*width;
                    if(object.channelTag!=1)
                        audioError="Unsupported Korg PCM channel tag="+std::to_string(object.channelTag)+
                                   " (supported: mono tag 1); sample-rate="+std::to_string(object.sampleRate);
                    else if(object.sampleRate<8000||object.sampleRate>192000)
                        audioError="Unsupported Korg PCM sample-rate="+std::to_string(object.sampleRate)+
                                   " (supported: 8000..192000 Hz); channel tag="+std::to_string(object.channelTag);
                    else if(width==0)audioError="Unsupported Korg PCM sample format";
                    else if(audioBytes!=payloadSize-audioOffset)
                        audioError="Korg PCM audio length does not match its header";
                    else {
                        object.audioMetadataDecoded=true;object.audioDataBytes=static_cast<std::size_t>(audioBytes);
                        if(object.sampleFormat==16)object.pcmByteOrder=nested?Pa5xPcmByteOrder::LittleEndian:Pa5xPcmByteOrder::BigEndian;
                        if(!object.oc31Compressed)object.audioDataOffset=object.payloadOffset+audioOffset;
                        if(object.sampleFormat==128)object.decodeError="Predictive compressed audio requires KMP coefficients and golden-reference validation";
                    }
                }
                if(!audioError.empty()){
                    if(!allowPartialAudio)return fail(audioError);
                    object.decodeError=std::move(audioError);
                }
            }else object.decodeError="Unsupported Korg PCM payload version";
        }
        next=object.payloadOffset+object.payloadBytes;
    }
    if(next!=xref)return fail("Korg sample payloads leave an unindexed resource gap");
    if(out.kind==Pa5xSampleContainerKind::PcmSamples){
        std::size_t encrypted=0,predictive=0,unsupported=0;for(const auto& object:out.objects){encrypted+=object.encrypted?1U:0U;predictive+=object.audioMetadataDecoded&&object.sampleFormat==128?1U:0U;unsupported+=!object.encrypted&&!object.audioMetadataDecoded?1U:0U;}
        if(encrypted)out.blockers.push_back(std::to_string(encrypted)+" encrypted PCM resources are not decoded");
        if(predictive)out.blockers.push_back(std::to_string(predictive)+" predictive PCM resources need validated audio decoding");
        if(allowPartialAudio&&unsupported)out.blockers.push_back(std::to_string(unsupported)+" unsupported PCM audio resources remain silent; see each object's decodeError");
    }
    out.valid=true;return out;
}

Pa5xSampleIndex inspectPa5xSampleFile(const std::string& path) {
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    Pa5xSampleIndex out;if(!f){out.error="Cannot open Korg sample container";return out;}
    const auto size=f.tellg();if(size<0||static_cast<std::uint64_t>(size)>kMaximumFile){out.error="Korg sample container exceeds the 256 MiB per-file inspection limit";return out;}
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));f.seekg(0);
    if(!bytes.empty())f.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    if(!f){out.error="Cannot read Korg sample container";return out;}
    return inspectPa5xSampleBytes(bytes);
}

Pa5xLinearAudio decodePa5xLinearPcm(const std::vector<std::uint8_t>& bytes,const Pa5xSampleObject& object) {
    Pa5xLinearAudio out;
    if(object.encrypted||object.oc31Compressed||!object.audioMetadataDecoded||object.sampleFormat!=16||object.channelTag!=1||object.pcmByteOrder==Pa5xPcmByteOrder::Unknown){out.error="Only validated unencrypted format16 mono PCM is supported";return out;}
    if(object.audioDataOffset>bytes.size()||object.audioDataBytes>bytes.size()-object.audioDataOffset||object.audioDataBytes%2!=0){out.error="Korg linear PCM audio span is invalid";return out;}
    out.sampleRate=object.sampleRate;out.mono.resize(object.audioDataBytes/2);
    for(std::size_t n=0;n<out.mono.size();++n){
        const auto at=object.audioDataOffset+n*2;
        const auto raw=object.pcmByteOrder==Pa5xPcmByteOrder::LittleEndian
            ?static_cast<std::uint16_t>(static_cast<unsigned>(bytes[at])|(static_cast<unsigned>(bytes[at+1])<<8U))
            :u16(bytes,at);
        const int value=raw<32768U?static_cast<int>(raw):static_cast<int>(raw)-65536;
        out.mono[n]=static_cast<float>(value)/32768.0F;
    }
    return out;
}

Pa5xSampleAudio decodePa5xSampleAudio(const std::vector<std::uint8_t>& bytes,
                                    const Pa5xSampleObject& object,
                                    const Pa5xKmpSample& sample,
                                    std::size_t maximumSamples) {
    Pa5xSampleAudio out;
    if(!object.hasId||object.resourceId!=sample.resourceId){out.error="PCM and KMP sample identifiers do not match";return out;}
    if(!object.audioMetadataDecoded){out.error=object.decodeError.empty()?"PCM audio metadata is unavailable":object.decodeError;return out;}
    if(object.sampleRate!=sample.sampleRate){out.error="PCM and KMP sample rates do not match";return out;}
    if(object.encrypted||object.oc31Compressed||object.channelTag!=1){out.error="PCM audio requires validated ordinary mono metadata";return out;}
    if(object.encodedSampleCount==0||object.encodedSampleCount>maximumSamples){out.error="PCM sample count exceeds the raw-audio decode limit";return out;}
    if(object.audioDataOffset>bytes.size()||object.audioDataBytes>bytes.size()-object.audioDataOffset){out.error="PCM audio span is outside its container";return out;}
    if(object.sampleFormat==16){
        if(static_cast<std::uint64_t>(object.encodedSampleCount)*2U!=object.audioDataBytes){out.error="PCM linear frame count does not match its audio span";return out;}
        return decodePa5xLinearPcm(bytes,object);
    }
    if(object.sampleFormat!=128){out.error="Unsupported Korg PCM audio codec";return out;}
    if(!sample.predictorsKnown){out.error="PCM predictive coefficients are unknown or unsupported";return out;}
    const auto decoded=decodePa5xPredictive(bytes.data()+object.audioDataOffset,object.audioDataBytes,
        object.encodedSampleCount,sample.predictor1,sample.predictor2,maximumSamples,!sample.predictorsDerived);
    if(!decoded){out.error=decoded.error;return out;}
    out.sampleRate=object.sampleRate;out.mono.resize(decoded.samples.size());
    for(std::size_t n=0;n<out.mono.size();++n)out.mono[n]=static_cast<float>(decoded.samples[n])/32768.0F;
    return out;
}

Pa5xSamplePlaybackMetadata inspectPa5xSamplePlayback(
    const Pa5xSampleObject& object,const Pa5xKmpSample& sample,
    Pa5xSampleEndConvention endConvention) {
    Pa5xSamplePlaybackMetadata out;out.endConvention=endConvention;
    const auto fail=[&](const std::string& message){out.error=message;return out;};
    if(!object.hasId||object.resourceId!=sample.resourceId)return fail("PCM and KMP sample identifiers do not match");
    if(object.sampleRate!=sample.sampleRate)return fail("PCM and KMP sample rates do not match");
    if(!object.audioMetadataDecoded||object.encrypted||object.oc31Compressed||object.channelTag!=1||
       object.encodedSampleCount==0||object.sampleRate<8000||object.sampleRate>192000)
        return fail("Sample playback needs validated ordinary mono PCM metadata");
    const auto packed=sample.packedData;
    out.storedSampleType=static_cast<std::uint8_t>(packed&15U);
    out.interpolationMode=static_cast<std::uint8_t>((packed>>5U)&3U);
    out.reverse=(packed&0x80U)!=0;out.useLoopPitch=(packed&0x100U)!=0;
    out.oneShotFlag=(packed&0x200U)!=0;out.loopEnabled=!out.oneShotFlag;
    out.twelveDbBoost=(packed&0x400U)!=0;out.doNotStream=(packed&0x800U)!=0;
    out.gainDb=out.twelveDbBoost?12.0F:0.0F;
    if((packed&0xF000U)!=0||(packed&0x10U)==0)
        return fail("Sample packed flags contain unknown bits or omit the extended identifier flag");
    if((out.storedSampleType!=0&&out.storedSampleType!=2)||
       (out.storedSampleType==0?object.sampleFormat!=16:object.sampleFormat!=128))
        return fail("KMP stored sample type does not match the PCM codec");
    out.flagsDecoded=true;out.rootKeyKnown=sample.originalNote<128;
    if(out.rootKeyKnown)out.rootKey=sample.originalNote;
    else out.uncertainties.push_back("Sample original-note sentinel has no established meaning; use an explicit valid zone root");
    if(out.interpolationMode!=0)
        out.uncertainties.push_back("Sample interpolation mode is preserved numerically; its hardware interpolation law is not established");
    if(out.useLoopPitch)
        out.uncertainties.push_back("Loop-pitch flag is known but its separate pitch correction is not decoded");
    if(std::any_of(object.rawAudioHeaderWords.begin(),object.rawAudioHeaderWords.begin()+8,
                   [](std::uint32_t value){return value!=0;})||object.rawAudioHeaderWords[10]!=0)
        return fail("Nonzero opaque PCM header parameters prevent a verified playback conversion");
    if(object.endPositionRaw!=object.secondaryEndPositionRaw)
        out.uncertainties.push_back("PCM end-like header fields differ; the secondary field's playback role is unknown");
    if(endConvention==Pa5xSampleEndConvention::Unknown)
        return fail("PCM endpoint convention must be selected explicitly before loop conversion");
    const std::uint64_t count=object.encodedSampleCount,end=object.endPositionRaw;
    if(endConvention==Pa5xSampleEndConvention::InclusiveIndex){
        if(end>=count)return fail("Inclusive PCM end index is outside the waveform");
        out.sampleEndFrame=end+1;
    }else if(endConvention==Pa5xSampleEndConvention::ExclusiveBoundary){
        if(end==0||end>count)return fail("Exclusive PCM end boundary is outside the waveform");
        out.sampleEndFrame=end;
    }else if(endConvention==Pa5xSampleEndConvention::InclusiveIndexOrCountBoundary||
             endConvention==Pa5xSampleEndConvention::KorgLoopBoundary){
        if(end>count)return fail("PCM end index or count sentinel is outside the waveform");
        out.sampleEndFrame=end==count?count:end+1;
        if(endConvention==Pa5xSampleEndConvention::InclusiveIndexOrCountBoundary)
            out.uncertainties.push_back("PCM end was converted under the caller-selected empirical inclusive/count-sentinel policy");
    }else return fail("Unsupported PCM endpoint convention");
    out.loopStartFrame=object.loopStart;
    // The stored end is a wrap boundary, not an extra audible loop frame.
    // In the paired PCM/KMP corpus it can point to a copy of the loop head
    // (including three interpolation guards) or to the frame-count boundary.
    // Retain the existing decoded audio extent for cache compatibility; the
    // loop cursor must never play those guards as part of its period.
    out.loopEndFrame=endConvention==Pa5xSampleEndConvention::KorgLoopBoundary&&out.loopEnabled
        ? end : out.sampleEndFrame;
    if(out.loopEnabled&&out.loopStartFrame>=out.loopEndFrame)
        return fail("PCM loop start is outside its converted end boundary");
    return out;
}
}
