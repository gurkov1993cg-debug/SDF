#include "silveton/arranger/GuitarMode.h"

#include <algorithm>

namespace silveton::arranger {
namespace {
constexpr int pc(int n) noexcept {const int p=n%12;return p<0?p+12:p;}
constexpr std::array<int,6> tuning{{40,45,50,55,59,64}};
constexpr std::array<int,5> formRoots{{0,9,7,4,2}}; // C, A, G, E, D
using Frets=std::array<int,6>;
using Forms=std::array<Frets,5>;
// Ordinary playable open/barre forms. Transposing the fingering also moves
// its open strings to the barre. The G form uses the common doubled fifth.
constexpr Forms major{{{{-1,3,2,0,1,0}},{{-1,0,2,2,2,0}},{{3,2,0,0,3,3}},{{0,2,2,1,0,0}},{{-1,-1,0,2,3,2}}}};
constexpr Forms minor{{{{-1,3,1,0,1,3}},{{-1,0,2,2,1,0}},{{3,1,0,0,3,3}},{{0,2,2,0,0,0}},{{-1,-1,0,2,3,1}}}};
constexpr Forms seventh{{{{-1,3,2,3,1,0}},{{-1,0,2,0,2,0}},{{3,2,0,0,0,1}},{{0,2,0,1,0,0}},{{-1,-1,0,2,1,2}}}};
constexpr Forms major7{{{{-1,3,2,0,0,0}},{{-1,0,2,1,2,0}},{{3,2,0,0,0,2}},{{0,2,1,1,0,0}},{{-1,-1,0,2,2,2}}}};
constexpr Forms minor7{{{{-1,3,1,3,1,3}},{{-1,0,2,0,1,0}},{{3,1,0,0,3,1}},{{0,2,0,0,0,0}},{{-1,-1,0,2,1,1}}}};
constexpr Forms sus2{{{{-1,3,0,0,1,3}},{{-1,0,2,2,0,0}},{{3,0,0,0,3,3}},{{0,2,4,4,0,0}},{{-1,-1,0,2,3,0}}}};
constexpr Forms sus4{{{{-1,3,3,0,1,1}},{{-1,0,2,2,3,0}},{{3,3,0,0,3,3}},{{0,2,2,2,0,0}},{{-1,-1,0,2,3,3}}}};
constexpr Forms major6{{{{-1,3,2,2,1,0}},{{-1,0,2,2,2,2}},{{3,2,0,0,0,0}},{{0,2,2,1,2,0}},{{-1,-1,0,2,0,2}}}};
constexpr Forms minor6{{{{-1,3,1,2,1,3}},{{-1,0,2,2,1,2}},{{3,1,0,0,3,0}},{{0,2,2,0,2,0}},{{-1,-1,0,2,0,1}}}};
constexpr Forms seventhSus4{{{{-1,3,3,3,1,1}},{{-1,0,2,0,3,0}},{{3,3,0,0,1,1}},{{0,2,0,2,0,0}},{{-1,-1,0,2,1,3}}}};

const Forms& baseForms(ChordType type) noexcept {
    switch(type){
        case ChordType::Minor:case ChordType::Diminished:return minor;
        case ChordType::Seventh:case ChordType::SeventhFlat5:case ChordType::Augmented7:return seventh;
        case ChordType::Major7:case ChordType::Major7Flat5:case ChordType::Major7Sus4:case ChordType::AugmentedMajor7:return major7;
        case ChordType::Minor7:case ChordType::MinorMajor7:case ChordType::Diminished7:
        case ChordType::DiminishedMajor7:case ChordType::Minor7Flat5:return minor7;
        case ChordType::Sus2:return sus2;
        case ChordType::Sus4:return sus4;
        case ChordType::Major6:return major6;
        case ChordType::Minor6:return minor6;
        case ChordType::SeventhSus4:return seventhSus4;
        default:return major;
    }
}
int degreeChange(ChordType type,int degree) noexcept {
    switch(type){
        case ChordType::Diminished:case ChordType::MajorFlat5:case ChordType::SeventhFlat5:
        case ChordType::Major7Flat5:case ChordType::Minor7Flat5:return degree==7?-1:0;
        case ChordType::Augmented:case ChordType::Augmented7:case ChordType::AugmentedMajor7:return degree==7?1:0;
        case ChordType::Major7Sus4:return degree==4?1:0;
        case ChordType::MinorMajor7:return degree==10?1:0;
        case ChordType::Diminished7:return degree==7||degree==10?-1:0;
        case ChordType::DiminishedMajor7:return degree==7?-1:(degree==10?1:0);
        default:return 0;
    }
}
struct Candidate {GuitarVoicing voicing;int score{0};};
bool sameNotes(const GuitarVoicing& a,const GuitarVoicing& b) noexcept {return a.notes==b.notes;}
int firstNote(const GuitarVoicing& v) noexcept {for(const int n:v.notes)if(n>=0)return n;return -1;}

GuitarStrokeNote cueNote(int pitchClass,int high,int low,int lowestFret,int capo) noexcept {
    GuitarStrokeNote found;
    // The root/fifth cue also uses strings muted in the ordinary shape. For
    // open C major this finds C on A3 and G on low E3 (the manual's white dot).
    for(int s=6-low;s<=6-high;++s){
        const int fret=std::max(capo,lowestFret)+pc(pitchClass-tuning[static_cast<std::size_t>(s)]-std::max(capo,lowestFret));
        if(fret>24)continue;
        const int pitch=tuning[static_cast<std::size_t>(s)]+fret;
        const int previousFret=found.string>=0?found.pitch-tuning[static_cast<std::size_t>(found.string)]:25;
        if(found.pitch<0||pitch<found.pitch||(pitch==found.pitch&&fret<previousFret))found={s,pitch};
    }
    return found;
}
} // namespace

GuitarPatternSettings resolveGuitarSettings(GuitarPatternSettings source,const GuitarOverride& edit) noexcept {
    if(!source.valid())source={};
    if(!edit.valid())return source;
    auto out=source;
    if(edit.capo>=0)out.capo=edit.capo;
    if(edit.humanize>=0)out.humanize=edit.humanize;
    if(edit.highString>=0)out.highString=edit.highString;
    if(edit.lowString>=0)out.lowString=edit.lowString;
    if(out.highString>out.lowString){out.highString=source.highString;out.lowString=source.lowString;}
    return out;
}
bool guitarShapeFromVelocity(int velocity,GuitarShape& shape) noexcept {
    if(velocity<1||velocity>90)return false;
    constexpr std::array<std::array<int,2>,15> ranges{{
        {{1,6}},{{2,6}},{{1,5}},{{3,6}},{{2,5}},{{1,4}},{{4,6}},{{3,5}},
        {{2,4}},{{1,3}},{{5,6}},{{4,5}},{{3,4}},{{2,3}},{{1,2}}
    }};
    const auto& range=ranges[static_cast<std::size_t>((velocity-1)/6)];
    shape={range[0],range[1],(velocity-1)%6};return true;
}
GuitarVoicing makeGuitarVoicing(Chord chord,int capo,int position) noexcept {
    GuitarVoicing empty;
    if(!chord.valid()||capo<0||capo>12||position<0||position>5)return empty;
    const auto required=chordPitchClassMask(chord.type);
    if(required==0)return empty;
    const auto& forms=baseForms(chord.type);
    std::array<Candidate,15> candidates{};std::size_t count=0;
    for(std::size_t form=0;form<forms.size();++form)for(int octave=0;octave<3;++octave){
        GuitarVoicing v;
        const int shift=pc(chord.root-formRoots[form])+12*octave;
        for(std::size_t s=0;s<tuning.size();++s){
            const int base= forms[form][s];if(base<0)continue;
            const int degree=pc(tuning[s]+base-formRoots[form]);
            const int adjusted=degree+degreeChange(chord.type,degree);
            if((required&(1U<<static_cast<unsigned>(pc(adjusted))))==0)continue;
            const int fret=base+shift+degreeChange(chord.type,degree);
            if(fret>=capo&&fret<=24)v.notes[s]=tuning[s]+fret;
        }
        // A requested slash bass can use a lower, otherwise muted string if
        // the same hand position permits it. Do not invent an extra chord tone.
        if(pc(chord.bass)!=pc(chord.root)&&(required&(1U<<static_cast<unsigned>(pc(chord.bass-chord.root))))!=0){
            int first=0;while(first<6&&v.notes[static_cast<std::size_t>(first)]<0)++first;
            for(int s=first-1;s>=0;--s){
                const int fret=capo+pc(chord.bass-tuning[static_cast<std::size_t>(s)]-capo);
                if(fret<=24&&first<6&&tuning[static_cast<std::size_t>(s)]+fret<v.notes[static_cast<std::size_t>(first)]){
                    v.notes[static_cast<std::size_t>(s)]=tuning[static_cast<std::size_t>(s)]+fret;break;
                }
            }
        }
        int minFret=25,maxFret=-1,notes=0;std::uint16_t covered=0;
        for(std::size_t s=0;s<tuning.size();++s)if(v.notes[s]>=0){
            const int fret=v.notes[s]-tuning[s];minFret=std::min(minFret,fret);maxFret=std::max(maxFret,fret);++notes;
            covered=static_cast<std::uint16_t>(covered|(1U<<static_cast<unsigned>(pc(v.notes[s]-chord.root))));
        }
        if(notes==0||(covered&required)!=required||maxFret-minFret>4)continue;
        bool duplicate=false;for(std::size_t n=0;n<count;++n)if(sameNotes(candidates[n].voicing,v)){duplicate=true;break;}
        if(duplicate)continue;
        v.lowestFret=minFret;
        const int wantedBass=pc(chord.bass);
        const int score=minFret*128+maxFret*4+(6-notes)*6+(pc(firstNote(v))==wantedBass?0:256);
        Candidate next{v,score};std::size_t insert=count;
        while(insert>0&&candidates[insert-1].score>next.score){candidates[insert]=candidates[insert-1];--insert;}
        candidates[insert]=next;++count;
    }
    if(count==0)return empty;
    return candidates[std::min(static_cast<std::size_t>(position),count-1)].voicing;
}

GuitarStroke makeGuitarStroke(int command,int velocity,Chord chord,const GuitarPatternSettings& settings,
    const GuitarShape& shape,const GuitarVoicing& voicing,bool alternatingUp) noexcept {
    GuitarStroke out;
    if(command==42){out.muteAll=true;return out;}
    if(command<24||command>47||!chord.valid()||!settings.valid())return out;
    const int high=std::max(settings.highString,shape.highString);
    int low=std::min(settings.lowString,shape.lowString);
    if(high>low)return out;
    const auto append=[&](int string,int pitch){if(string>=6-low&&string<=6-high&&pitch>=0&&pitch<=127&&out.count<6)out.notes[static_cast<std::size_t>(out.count++)]={string,pitch};};
    if(command==37||command==39){
        const auto cue=cueNote(pc(chord.root+(command==39?7:0)),high,low,voicing.lowestFret,settings.capo);
        append(cue.string,cue.pitch);return out;
    }
    if(command==36||command==38||command==40||command==41||command==43||command==45){
        const int string=command==36?0:command==38?1:command==40?2:command==41?3:command==43?4:5;
        append(string,voicing.notes[static_cast<std::size_t>(string)]);return out;
    }
    if(command==44){
        // A power chord is root, perfect fifth, octave even when the recognized
        // harmony is minor/diminished/augmented. Keep it on adjacent playable
        // strings in the root's hand position, not the full chord's thirds.
        const auto root=cueNote(pc(chord.root),high,low,voicing.lowestFret,settings.capo);
        if(root.pitch<0)return out;
        append(root.string,root.pitch);
        int previousString=root.string;
        const int rootFret=root.pitch-tuning[static_cast<std::size_t>(root.string)];
        for(const int interval:std::array<int,2>{{7,12}}){
            const int pitch=root.pitch+interval;
            for(int s=previousString+1;s<=6-high;++s){
                const int fret=pitch-tuning[static_cast<std::size_t>(s)];
                if(fret>=settings.capo&&fret<=24&&fret>=rootFret-4&&fret<=rootFret+4){
                    append(s,pitch);previousString=s;break;
                }
            }
        }
        out.spacingMs=3.0;return out;
    }
    bool up=command==26||command==27||command==31||command==32||command==35;
    if(command==46||command==47)up=alternatingUp;
    const bool four=command==32||command==33||command==34||command==35||command==47;
    if(four)low=std::min(low,high+3);
    const bool slow=command==29||command==30||command==31;
    const bool muted=command==25||command==27||command==28||command==30||command==32||command==34;
    // Faster/harder strokes cross the strings sooner. These intervals do not
    // purport to reproduce an undocumented Korg timing or articulation table.
    const double soft=static_cast<double>(127-std::clamp(velocity,1,127))/126.0;
    out.spacingMs=slow?14.0+10.0*soft:4.0+4.0*soft;
    if(muted)out.gateMs=command==28?22.0:38.0;
    if(up){for(int s=6-high;s>=6-low;--s)append(s,voicing.notes[static_cast<std::size_t>(s)]);}
    else {for(int s=6-low;s<=6-high;++s)append(s,voicing.notes[static_cast<std::size_t>(s)]);}
    return out;
}
} // namespace silveton::arranger
