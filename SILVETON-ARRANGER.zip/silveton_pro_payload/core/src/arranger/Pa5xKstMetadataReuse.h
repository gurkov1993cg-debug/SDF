#pragma once

#include "silveton/arranger/Pa5xPcgIndex.h"
#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/arranger/Pa5xStyleRead.h"
#include "silveton/arranger/Pa5xStyleSourceSettings.h"
#include <fstream>
#include <map>
#include <memory>
#include <set>
#include <sys/stat.h>

namespace silveton::arranger {

// A same-operation cache key, not a persistent content identity. Both inode
// and nanosecond modification/change stamps must still match before reuse.
struct KstMetadataRevision {
    std::uint64_t device{0},inode{0},size{0};
    std::int64_t modifiedSeconds{0},changedSeconds{0};
    long modifiedNanos{0},changedNanos{0};
    bool valid{false};
};
inline KstMetadataRevision kstMetadataRevision(const std::string& path) {
    struct stat value{};KstMetadataRevision out;
    if(::stat(path.c_str(),&value)!=0||!S_ISREG(value.st_mode)||value.st_size<0)return out;
    out.device=static_cast<std::uint64_t>(value.st_dev);out.inode=static_cast<std::uint64_t>(value.st_ino);
    out.size=static_cast<std::uint64_t>(value.st_size);
#if defined(__APPLE__)
    out.modifiedSeconds=value.st_mtimespec.tv_sec;out.modifiedNanos=value.st_mtimespec.tv_nsec;
    out.changedSeconds=value.st_ctimespec.tv_sec;out.changedNanos=value.st_ctimespec.tv_nsec;
#else
    out.modifiedSeconds=value.st_mtim.tv_sec;out.modifiedNanos=value.st_mtim.tv_nsec;
    out.changedSeconds=value.st_ctim.tv_sec;out.changedNanos=value.st_ctim.tv_nsec;
#endif
    out.valid=true;return out;
}
inline bool sameKstMetadataRevision(const KstMetadataRevision& a,const KstMetadataRevision& b) {
    return a.valid&&b.valid&&a.device==b.device&&a.inode==b.inode&&a.size==b.size&&
        a.modifiedSeconds==b.modifiedSeconds&&a.modifiedNanos==b.modifiedNanos&&
        a.changedSeconds==b.changedSeconds&&a.changedNanos==b.changedNanos;
}
inline bool readKstMetadataBytes(const std::string& path,std::vector<std::uint8_t>& bytes,
        KstMetadataRevision& revision,std::string& error) {
    constexpr std::uint64_t maximum=64U*1024U*1024U;
    revision=kstMetadataRevision(path);
    if(!revision.valid||revision.size>maximum){error="Metadata resource is unreadable or exceeds the 64 MiB reader limit";return false;}
    std::ifstream input(path,std::ios::binary);
    if(!input){error="Cannot open metadata resource";return false;}
    bytes.resize(static_cast<std::size_t>(revision.size));
    if(!bytes.empty())input.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    if(!input){error="Cannot read complete metadata resource";return false;}
    if(!sameKstMetadataRevision(revision,kstMetadataRevision(path))){error="Metadata resource changed while being read; reload the SET";return false;}
    return true;
}

struct KstCatalogStyleMetadata {
    std::string name,error;
    double bpm{0};int numerator{0},denominator{0};bool loadable{false};
    std::vector<std::string> warnings;
    Pa5xStyleSourceSettings originalSettings;
};
inline bool kstMidiStyle(const std::string& path) {
    const auto dot=path.find_last_of('.');
    if(dot==std::string::npos)return false;
    auto ext=path.substr(dot);
    for(char& c:ext)if(c>='A'&&c<='Z')c=static_cast<char>(c-'A'+'a');
    return ext==".mid"||ext==".midi";
}
inline KstCatalogStyleMetadata kstImportedStyleMetadata(const ImportResult& imported,bool summarize=true) {
    KstCatalogStyleMetadata out;
    if(!imported){out.error=imported.error;out.originalSettings=unavailablePa5xStyleSourceSettings(out.error);return out;}
    if(summarize)out.originalSettings=summarizePa5xStyleSourceSettings(*imported.style);
    out.name=imported.style->name;out.bpm=imported.style->tempoBpm;
    out.warnings=imported.warnings;const Section* selected=nullptr;
    for(int i=static_cast<int>(Element::Var1);i<=static_cast<int>(Element::Var4);++i)
        if(imported.style->sections[static_cast<std::size_t>(i)].available){selected=&imported.style->sections[static_cast<std::size_t>(i)];break;}
    if(!selected)for(const auto& section:imported.style->sections)if(section.available){selected=&section;break;}
    if(selected){out.numerator=selected->numerator;out.denominator=selected->denominator;}
    ArrangerEngine validator;out.loadable=validator.installStyle(0,imported.style);
    if(!out.loadable){
        out.error="Native Style graph is outside the current arranger playback contract";
        for(auto& track:out.originalSettings.tracks)track.available=false;
    }
    return out;
}

inline KstCatalogStyleMetadata kstCatalogStyleMetadata(const KorgStyleInspection& inspected) {
    if(inspected.valid){
        const auto imported=importKorgStyleInspection(inspected);
        auto out=kstImportedStyleMetadata(imported,false);
        out.originalSettings=summarizePa5xStyleSourceSettings(inspected,imported.style.get());
        if(!out.loadable)for(auto& track:out.originalSettings.tracks)track.available=false;
        return out;
    }
    KstCatalogStyleMetadata out;out.name=inspected.name;out.bpm=inspected.tempoBpm;out.error=inspected.error;
    out.originalSettings=unavailablePa5xStyleSourceSettings(out.error);return out;
}
inline KstCatalogStyleMetadata kstReadStyleMetadata(const Pa5xStyleRead& read) {
    auto out=kstImportedStyleMetadata({read.nativeStyle,read.error,read.warnings},false);
    out.originalSettings=summarizePa5xStyleSourceSettings(read);
    if(!out.loadable)for(auto& track:out.originalSettings.tracks)track.available=false;
    return out;
}

struct KstCatalogKeyboardMetadata {
    std::string name,blocker;int ordinal{-1},splitPoint{-1},useGlobalSplit{-1},upperOctave{0},scan{-1},mode{-1};
    bool supported{false};std::vector<Pa5xPerformancePart> parts;
};
inline KstCatalogKeyboardMetadata kstCatalogKeyboardMetadata(const Pa5xPerformanceInspection& inspected) {
    KstCatalogKeyboardMetadata out;out.name=inspected.displayName;out.ordinal=inspected.filenameOrdinal;
    out.supported=inspected.valid&&inspected.kind==Pa5xPerformanceKind::KeyboardSet;
    if(!out.supported){out.blocker=inspected.error.empty()?"Resource is not a supported Keyboard Set":inspected.error;return out;}
    out.splitPoint=inspected.splitPoint;out.useGlobalSplit=inspected.useGlobalSplit;out.upperOctave=inspected.upperOctaveTransposeRaw;
    out.scan=inspected.chordScanningRaw;out.mode=inspected.keyboardModeRaw;out.parts=inspected.parts;
    out.blocker="Keyboard Set metadata only; Sound and original FX playback support is assessed on recall";return out;
}
inline std::size_t kstPerformancePartsBytes(const std::vector<Pa5xPerformancePart>& parts) {
    std::size_t bytes=parts.capacity()*sizeof(Pa5xPerformancePart);
    std::set<const KorgSourceEffects*> countedEffects;
    for(const auto& part:parts){
        bytes+=part.name.capacity()+part.resourcePath.capacity()+part.patternType.capacity();
        bytes+=part.patches.capacity()*sizeof(Pa5xPerformancePatch)+part.channels.capacity()*sizeof(Pa5xPerformanceChannel);
        bytes+=part.channelEvents.capacity()*sizeof(KorgMidiChannelEvent)+part.opaqueMidiEvents.capacity()*sizeof(KorgMidiOpaqueEvent);
        for(const auto& event:part.opaqueMidiEvents)bytes+=event.payload.capacity();
        bytes+=part.cvSources.capacity()*sizeof(Pa5xPerformanceCv)+part.chordSelections.capacity()*sizeof(Pa5xPerformanceChordSelection);
        for(const auto& cv:part.cvSources)bytes+=cv.root.capacity()+cv.chord.capacity();
        for(const auto& chord:part.chordSelections)bytes+=chord.chord.capacity();
        if(part.sourceEffects&&countedEffects.insert(part.sourceEffects.get()).second){
            const auto& fx=*part.sourceEffects;
            bytes+=64U+sizeof(KorgSourceEffects)+fx.resourcePath.capacity()+fx.error.capacity();
            bytes+=fx.definitions.capacity()*sizeof(KorgSourceFxDefinition)+fx.sends.capacity()*sizeof(KorgSourceFxSend);
            bytes+=fx.unknownMessages.capacity()*sizeof(KorgMidiOpaqueEvent);
            for(const auto& definition:fx.definitions)bytes+=definition.originalRecord.capacity();
            for(const auto& event:fx.unknownMessages)bytes+=event.payload.capacity();
        }
    }
    return bytes;
}

class Pa5xKstMetadataCache {
public:
    struct LegacySlot {int slot; KstCatalogStyleMetadata metadata;};
    std::map<std::string,std::pair<KstMetadataRevision,std::vector<LegacySlot>>> legacy;
    struct Pcg {KstMetadataRevision revision;std::vector<std::uint8_t> bytes;Pa5xPcgInspection inspection;};
    struct Style {KstMetadataRevision revision;KstCatalogStyleMetadata metadata;};
    struct Keyboard {KstMetadataRevision revision;KstCatalogKeyboardMetadata metadata;};
    std::shared_ptr<const Pcg> pcg(const std::string& path) const {
        const auto found=pcgs_.find(path);
        if(found==pcgs_.end()||!sameKstMetadataRevision(found->second->revision,kstMetadataRevision(path)))return {};
        return found->second;
    }
    const KstCatalogStyleMetadata* style(const std::string& path) const {
        const auto found=styles_.find(path);
        if(found==styles_.end()||!sameKstMetadataRevision(found->second.revision,kstMetadataRevision(path)))return nullptr;
        return &found->second.metadata;
    }
    const KstCatalogKeyboardMetadata* keyboard(const std::string& path) const {
        const auto found=keyboards_.find(path);
        if(found==keyboards_.end()||!sameKstMetadataRevision(found->second.revision,kstMetadataRevision(path)))return nullptr;
        return &found->second.metadata;
    }
    void retainPcg(const std::string& path,const KstMetadataRevision& revision,
            std::vector<std::uint8_t>&& bytes,const Pa5xPcgInspection& inspected) {
        if(!revision.valid||!sameKstMetadataRevision(revision,kstMetadataRevision(path))||pcgs_.count(path))return;
        std::size_t cost=96U+bytes.capacity()+path.capacity()+sizeof(Pcg)+inspected.sourcePath.capacity()+inspected.error.capacity();
        cost+=inspected.sounds.capacity()*sizeof(Pa5xPcgSound)+inspected.warnings.capacity()*sizeof(std::string);
        for(const auto& sound:inspected.sounds)cost+=sound.name.capacity();
        for(const auto& warning:inspected.warnings)cost+=warning.capacity();
        if(cost>kMaximumPcgBytes-pcgBytes_)return;
        auto retained=std::make_shared<Pcg>();retained->revision=revision;retained->bytes=std::move(bytes);retained->inspection=inspected;
        pcgs_.emplace(path,std::move(retained));pcgBytes_+=cost;
    }
    void retainStyle(const std::string& path,const KstMetadataRevision& revision,KstCatalogStyleMetadata&& metadata) {
        if(!revision.valid||!sameKstMetadataRevision(revision,kstMetadataRevision(path))||styles_.count(path))return;
        std::size_t cost=96U+sizeof(Style)+path.capacity()+metadata.name.capacity()+metadata.error.capacity();
        cost+=metadata.warnings.capacity()*sizeof(std::string);for(const auto& warning:metadata.warnings)cost+=warning.capacity();
        cost+=metadata.originalSettings.error.capacity()+metadata.originalSettings.tracks.capacity()*sizeof(Pa5xStyleSourceTrack);
        for(const auto& track:metadata.originalSettings.tracks)
            cost+=track.declaredType.capacity()+track.sounds.capacity()*sizeof(Pa5xStyleSourceSound);
        if(cost>kMaximumStyleBytes-styleBytes_)return;
        styles_.emplace(path,Style{revision,std::move(metadata)});styleBytes_+=cost;
    }
    void retainKeyboard(const std::string& path,const KstMetadataRevision& revision,const Pa5xPerformanceInspection& inspected) {
        if(!revision.valid||!sameKstMetadataRevision(revision,kstMetadataRevision(path))||keyboards_.count(path))return;
        const auto cost=512U+path.capacity()+sizeof(Keyboard)+inspected.displayName.capacity()+inspected.error.capacity()+
            kstPerformancePartsBytes(inspected.parts);
        // Check before copying potentially large original opaque MIDI data.
        if(cost>kMaximumKeyboardBytes-keyboardBytes_)return;
        keyboards_.emplace(path,Keyboard{revision,kstCatalogKeyboardMetadata(inspected)});keyboardBytes_+=cost;
    }
private:
    // Keep bounded source summaries through the same SET-load operation so
    // catalog construction does not reread the already inspected Styles.
    static constexpr std::size_t kMaximumPcgBytes=32U*1024U*1024U,kMaximumStyleBytes=32U*1024U*1024U,kMaximumKeyboardBytes=8U*1024U*1024U;
    std::size_t pcgBytes_{0},styleBytes_{0},keyboardBytes_{0};
    std::map<std::string,std::shared_ptr<const Pcg>> pcgs_;
    std::map<std::string,Style> styles_;
    std::map<std::string,Keyboard> keyboards_;
};
} // namespace silveton::arranger
