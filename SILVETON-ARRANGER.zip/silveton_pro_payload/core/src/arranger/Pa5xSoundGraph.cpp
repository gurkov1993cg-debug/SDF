#include "silveton/arranger/Pa5xSoundGraph.h"
#include "silveton/arranger/Pa5xOc31.h"
#include <algorithm>
#include <fstream>
#include <utility>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumPcgBytes = 64U * 1024U * 1024U;
constexpr std::size_t kMaximumNormalBodyBytes = 64U * 1024U;
struct SoundFxLayout {
    std::size_t start{0},count{0},stride{0},prefix{0},countOffset{0},oscillatorStride{0},controls{0};
};
SoundFxLayout soundFxLayout(std::uint8_t version) noexcept {
    switch(version) {
        case 0:return {26,2,66,183,161,177,3};
        case 1:return {26,2,66,186,161,179,3};
        case 2:return {26,4,67,325,300,191,6};
        case 3:return {10,4,67,309,284,191,6};
        case 5:return {14,4,67,313,288,198,6};
        case 6:return {14,4,67,313,288,200,6};
        case 7:return {15,6,67,448,423,202,6};
        case 8:return {15,6,67,450,423,202,6};
        default:return {};
    }
}
bool readSoundFxRecords(const std::vector<std::uint8_t>& bytes,std::size_t inputStart,
                       const SoundFxLayout& layout,Pa5xSoundEffectsRaw& out) {
    if(layout.count==0U||layout.count>6U||layout.stride<66U||layout.stride>67U||
       layout.controls>out.commonControlsRaw.size()||inputStart>bytes.size()||
       layout.count*layout.stride+layout.controls>bytes.size()-inputStart)return false;
    out.records.reserve(layout.count);
    for(std::size_t i=0;i<layout.count;++i) {
        Pa5xSoundFxRecordRaw record;record.decodedBodyOffset=layout.start+i*layout.stride;
        const auto input=inputStart+i*layout.stride;
        record.recordIndex=static_cast<std::uint8_t>(i);
        record.recordBytes=static_cast<std::uint8_t>(layout.stride);
        record.leadingRaw=bytes[input];
        std::copy_n(bytes.begin()+static_cast<std::ptrdiff_t>(input+1U),
            record.parameters.size(),record.parameters.begin());
        record.selectorLowRaw=bytes[input+65U];record.selectorDecoded=record.leadingRaw==0U;
        if(record.selectorDecoded)record.selector=record.selectorLowRaw;
        record.trailingControlPresent=layout.stride==67U;
        if(record.trailingControlPresent)record.trailingControlRaw=bytes[input+66U];
        out.records.push_back(record);
    }
    out.commonControlsBodyOffset=layout.start+layout.count*layout.stride;
    out.commonControlsBytes=static_cast<std::uint8_t>(layout.controls);
    std::copy_n(bytes.begin()+static_cast<std::ptrdiff_t>(inputStart+layout.count*layout.stride),
        layout.controls,out.commonControlsRaw.begin());
    out.framingDecoded=true;
    return true;
}
// Field-layout provenance: the original format research in aczwink/KORG-Tools,
// SoundFormat readers 0.0..3.0 and their legacy base layouts. Only documented
// field lengths/order are used; no implementation text is embedded here.
class BodyReader {
public:
    explicit BodyReader(const std::vector<std::uint8_t>& bytes) : bytes_(bytes) {}
    std::size_t position() const noexcept { return position_; }
    bool good() const noexcept { return good_; }
    std::uint8_t byte() noexcept {
        if (position_ >= bytes_.size()) { good_ = false; return 0; }
        return bytes_[position_++];
    }
    std::uint16_t word() noexcept {
        const auto high = byte(); const auto low = byte();
        return static_cast<std::uint16_t>((static_cast<unsigned>(high) << 8U) | low);
    }
    std::int16_t signedWord() noexcept {
        const auto raw = word();
        const int value = raw <= 32767 ? static_cast<int>(raw) : static_cast<int>(raw) - 65536;
        return static_cast<std::int16_t>(value);
    }
    std::uint64_t id() noexcept {
        std::uint64_t out = 0;
        for (int i = 0; i < 8; ++i) out = (out << 8U) | byte();
        return out;
    }
    void skip(std::size_t count) noexcept {
        if (count > bytes_.size() - position_) { good_ = false; return; }
        position_ += count;
    }
    std::string name() {
        std::string out;
        for (int i = 0; i < 16; ++i) {
            const auto c = byte();
            if (c != 0) out.push_back(static_cast<char>(c));
            else { skip(static_cast<std::size_t>(15 - i)); break; }
        }
        return out;
    }
private:
    const std::vector<std::uint8_t>& bytes_;
    std::size_t position_{0};
    bool good_{true};
};

bool readSource(BodyReader& r, int version, Pa5xOscillatorSource& out) {
    out.multisampleId = r.id();
    const auto number = r.word();
    out.numberFlagsRaw = number;
    const auto source = r.byte(); out.levelRaw = r.byte();
    if (source > 1 || out.levelRaw > 127) return false;
    out.source = static_cast<Pa5xMultisampleSource>(source);
    if (version >= 2) {
        out.multisampleNumber = number;
        const auto reversed = r.byte();
        if (reversed > 1) return false;
        out.reversed = reversed != 0; out.offsetRaw = r.byte();
    } else {
        out.multisampleNumber = static_cast<std::uint16_t>(number & 0x0FFFU);
        out.reversed = (number & 0x4000U) != 0;
        out.offsetRaw = (number & 0x8000U) != 0 ? 8 : 0;
    }
    return r.good();
}
bool readNewSource(BodyReader& r, std::uint8_t extensionBytes, Pa5xOscillatorSource& out) {
    out.multisampleId = r.id();out.multisampleNumber = r.word();out.numberFlagsRaw = out.multisampleNumber;
    const auto source = r.byte();out.levelRaw = r.byte();
    if(source > 1) return false;
    out.source = static_cast<Pa5xMultisampleSource>(source);
    out.levelDecoded = false;out.reverseDecoded = false;out.offsetDecoded = false;
    out.extensionBytes = extensionBytes;
    for(std::uint8_t i=0;i<extensionBytes;++i) out.extensionRaw[i] = r.byte();
    return r.good();
}
std::int8_t signedByte(std::uint8_t value) noexcept {
    return static_cast<std::int8_t>(value < 128 ? static_cast<int>(value) : static_cast<int>(value)-256);
}
template<std::size_t N>
Pa5xAmsParameterRaw amsPair(const std::array<std::uint8_t,N>& bytes, std::size_t offset) noexcept {
    return {bytes[offset],signedByte(bytes[offset+1])};
}
template<std::size_t N>
Pa5xKeyboardTrackingRaw keyboardTracking(const std::array<std::uint8_t,N>& bytes, std::size_t offset) noexcept {
    return {bytes[offset],bytes[offset+2],signedByte(bytes[offset+1]),signedByte(bytes[offset+3])};
}
void decodeCorroboratedOscillatorDsp(Pa5xOscillatorReferences& osc) noexcept {
    // Field facts from the independently corroborated Triton OSC layout:
    // OSC266..355 retained as Pa DSP90, OSC356..377 retained as Pa amp-EG22,
    // with Pa's scaled-velocity pair inserted between the two blocks. Identical
    // named SFZ Brass ST and White Pad EP programs corroborate the ordering;
    // runtime scaling, AMS identities and newer layouts are separate work.
    auto& p=osc.dsp;
    const auto& d=osc.opaqueDsp;
    const auto& a=osc.amplitudeEnvelopeRaw;
    for(std::size_t i=0;i<2;++i) {
        const auto base=i*10;
        auto& lfo=p.lfos[i];
        lfo.waveformFlags=osc.lfoRaw[base];lfo.frequency=osc.lfoRaw[base+1];
        lfo.offset=signedByte(osc.lfoRaw[base+2]);lfo.delay=osc.lfoRaw[base+3];
        lfo.fade=osc.lfoRaw[base+4];lfo.tempoSyncFlags=osc.lfoRaw[base+5];
        lfo.frequencyModulation[0]=amsPair(osc.lfoRaw,base+6);
        lfo.frequencyModulation[1]=amsPair(osc.lfoRaw,base+8);
    }
    p.pitchModulation=amsPair(d,0);p.pitchTrackingSlope=d[2];
    p.pitchEnvelopeIntensity=signedByte(d[3]);p.pitchEnvelopeModulation=amsPair(d,4);
    p.pitchLfoIntensity={signedByte(d[6]),signedByte(d[7])};
    p.portamentoFlags=d[8];p.portamentoTime=d[9];
    p.pitchBendRange={signedByte(d[10]),signedByte(d[11])};
    p.pitchRibbonIntensity=signedByte(d[12]);p.pitchReserved=d[13];
    p.pitchJoystickLfoIntensity={signedByte(d[14]),signedByte(d[15])};
    p.pitchLfoModulation={amsPair(d,16),amsPair(d,18)};
    p.filterType=d[20];p.filterTrim=d[21];p.filterResonance=d[22];
    p.filterResonanceModulation=amsPair(d,23);p.filterEnvelopeAmsSource=d[25];
    p.filterLfoAmsSource={d[26],d[27]};
    for(std::size_t i=0;i<2;++i) {
        const auto base=28+i*15;
        auto& filter=p.filters[i];
        filter.frequency=d[base];filter.keyboardTrackingIntensity=signedByte(d[base+1]);
        filter.modulation={amsPair(d,base+2),amsPair(d,base+4)};
        filter.envelopeIntensity=signedByte(d[base+6]);filter.velocityIntensity=signedByte(d[base+7]);
        filter.lfoIntensity={signedByte(d[base+8]),signedByte(d[base+9])};
        filter.joystickLfoIntensity={signedByte(d[base+10]),signedByte(d[base+11])};
        filter.envelopeAmsIntensity=signedByte(d[base+12]);
        filter.lfoAmsIntensity={signedByte(d[base+13]),signedByte(d[base+14])};
    }
    auto& f=p.filterEnvelope;
    f.startLevel=signedByte(d[58]);f.attackTime=d[59];f.attackLevel=signedByte(d[60]);
    f.decayTime=d[61];f.breakLevel=signedByte(d[62]);f.slopeTime=d[63];
    f.sustainLevel=signedByte(d[64]);f.releaseTime=d[65];f.releaseLevel=signedByte(d[66]);
    f.hasReleaseLevel=true;
    auto& fm=p.filterEnvelopeModulation;
    fm.timeDirections={d[67],d[68]};fm.levelDirections=d[69];
    fm.time={amsPair(d,70),amsPair(d,72)};fm.level=amsPair(d,74);
    p.filterKeyboardTracking=keyboardTracking(d,76);
    p.amplitudeLevel=d[80];p.amplitudeVelocityIntensity=signedByte(d[81]);
    p.amplitudeModulation=amsPair(d,82);
    p.amplitudeLfoIntensity={signedByte(d[84]),signedByte(d[85])};
    p.amplitudeLfoModulation={amsPair(d,86),amsPair(d,88)};
    auto& e=p.amplitudeEnvelope;
    e.startLevel=a[0];e.attackTime=a[1];e.attackLevel=a[2];e.decayTime=a[3];
    e.breakLevel=a[4];e.slopeTime=a[5];e.sustainLevel=a[6];e.releaseTime=a[7];
    e.releaseLevel=0;e.hasReleaseLevel=false;
    auto& em=p.amplitudeEnvelopeModulation;
    em.time={amsPair(a,8),amsPair(a,10)};em.level=amsPair(a,12);
    em.timeDirections={a[14],a[15]};em.levelDirections=a[16];
    p.amplitudeReserved=a[17];p.amplitudeKeyboardTracking=keyboardTracking(a,18);
    const auto envelopeRange=[](const Pa5xEnvelopeParametersRaw& env,bool signedLevels) {
        const int minimum=signedLevels?-99:0;
        for(const auto level:{env.startLevel,env.attackLevel,env.breakLevel,env.sustainLevel,env.releaseLevel})
            if(level<minimum||level>99)return false;
        return env.attackTime<=99&&env.decayTime<=99&&env.slopeTime<=99&&env.releaseTime<=99;
    };
    p.nominalRangesValid=p.filterType<=1&&p.filterTrim<=99&&p.filterResonance<=99&&
        p.filters[0].frequency<=99&&p.filters[1].frequency<=99&&p.amplitudeLevel<=127&&
        envelopeRange(f,true)&&envelopeRange(e,false)&&
        p.filterKeyboardTracking.lowKey<=127&&p.filterKeyboardTracking.highKey<=127&&
        p.amplitudeKeyboardTracking.lowKey<=127&&p.amplitudeKeyboardTracking.highKey<=127;
    p.fieldLayoutDecoded=true;p.legacyTritonLayoutCorroborated=true;
    p.amplitudeLevelEncodingDecoded=true;p.portamentoEncodingDecoded=true;
}
void decodeStaticPitch(Pa5xOscillatorReferences& osc) noexcept {
    const int transpose=osc.transposeRaw<=127?osc.transposeRaw:static_cast<int>(osc.transposeRaw)-256;
    osc.transposeSemitones=static_cast<std::int8_t>(transpose);
    osc.staticPitchDecoded=osc.octaveRaw>=-2&&osc.octaveRaw<=1&&transpose>=-12&&transpose<=12&&
        osc.tuneRaw>=-1200&&osc.tuneRaw<=1200;
    if(osc.staticPitchDecoded)osc.staticPitchOffsetCents=static_cast<int>(osc.octaveRaw)*1200+transpose*100+osc.tuneRaw;
}
void decodeNewOscillatorDsp(Pa5xOscillatorReferences& osc,int version,
    const std::vector<std::uint8_t>& body) noexcept {
    // Cross-version paired Sounds establish the retained parameter blocks and
    // insertions, independently of names/UID searching during actual decoding.
    // v2/v6:33paired OSCs have identical amp-EG22; their normalized DSP90 only
    // differs at saved portamento/bend settings. v5/v6 and v6/v7/v8 pairs then
    // establish the inserted bytes. The entire raw tail remains available.
    const auto start=osc.decodedBodyOffset;
    const std::size_t shift=version>=7?2U:0U;
    const std::size_t lfo=47U+shift,pitch=67U+shift,dsp=71U+shift;
    const std::size_t envelope=(version==5?166U:168U)+shift;
    for(std::size_t i=0;i<osc.lfoRaw.size();++i)osc.lfoRaw[i]=body[start+lfo+i];
    osc.octaveRaw=signedByte(body[start+pitch]);osc.transposeRaw=body[start+pitch+1];
    const auto tune=static_cast<unsigned>(body[start+pitch+2])*256U+body[start+pitch+3];
    osc.tuneRaw=static_cast<std::int16_t>(tune<32768U?static_cast<int>(tune):static_cast<int>(tune)-65536);
    decodeStaticPitch(osc);
    for(std::size_t i=0;i<osc.opaqueDsp.size();++i) {
        const std::size_t insertion=version==5?(i<81U?0U:(i<84U?1U:3U)):
            (i<10U?0U:(i<81U?2U:(i<84U?3U:5U)));
        osc.opaqueDsp[i]=body[start+dsp+i+insertion];
    }
    std::size_t extra=0;
    if(version>=6) {
        osc.additionalDspRaw[extra++]=body[start+81U+shift];
        osc.additionalDspRaw[extra++]=body[start+82U+shift];
    }
    const std::size_t ampInsert=(version==5?152U:154U)+shift;
    osc.additionalDspRaw[extra++]=body[start+ampInsert];
    osc.additionalDspRaw[extra++]=body[start+ampInsert+4U];
    osc.additionalDspRaw[extra++]=body[start+ampInsert+5U];
    osc.additionalDspBytes=static_cast<std::uint8_t>(extra);
    osc.scaledVelocityLow=body[start+envelope-2U];osc.scaledVelocityHigh=body[start+envelope-1U];
    osc.scaledVelocityDecoded=osc.scaledVelocityLow<=127&&osc.scaledVelocityHigh<=127&&
        osc.scaledVelocityLow<=osc.scaledVelocityHigh;
    for(std::size_t i=0;i<osc.amplitudeEnvelopeRaw.size();++i)osc.amplitudeEnvelopeRaw[i]=body[start+envelope+i];
    const auto eq=start+envelope+osc.amplitudeEnvelopeRaw.size();
    osc.equalizer.present=true;osc.equalizer.enabledRaw=body[eq];osc.equalizer.trimRaw=body[eq+1];
    osc.equalizer.lowGainTimes2Raw=body[eq+2];osc.equalizer.frequencyRaw=body[eq+3];
    osc.equalizer.midGainTimes2Raw=body[eq+4];osc.equalizer.highGainTimes2Raw=body[eq+5];
    decodeCorroboratedOscillatorDsp(osc);
    osc.dsp.legacyTritonLayoutCorroborated=false;osc.dsp.newerPaLayoutCorroborated=true;
    // New bytes adjacent to amplitude level and portamento can extend their
    // encodings. Preserve the old-position byte without claiming whole values.
    osc.dsp.amplitudeLevelEncodingDecoded=false;osc.dsp.portamentoEncodingDecoded=false;
}
} // namespace

Pa5xSourceVelocityUse pa5xSourceVelocityUse(const Pa5xOscillatorReferences& osc, bool high) noexcept {
    if(osc.velocitySwitch<1||osc.velocitySwitch>127||osc.velocityLow>127||osc.velocityHigh>127||osc.velocityLow>osc.velocityHigh)
        return {};
    // User Manual printed1077–1078: switch1 means only High. Keep velocity0
    // in the conservative domain because release-triggered oscillators exist.
    if(osc.velocitySwitch==1) return {true,high};
    return {true,high ? osc.velocityHigh>=osc.velocitySwitch : osc.velocityLow<osc.velocitySwitch};
}
Pa5xVelocityLayer pa5xVelocityLayer(const Pa5xOscillatorReferences& osc, int key, int velocity) noexcept {
    if(osc.velocitySwitch < 1 || osc.velocitySwitch > 127) return Pa5xVelocityLayer::Unknown;
    if(key < 0 || key > 127 || velocity < 1 || velocity > 127 ||
       key < osc.keyLow || key > osc.keyHigh || velocity < osc.velocityLow || velocity > osc.velocityHigh)
        return Pa5xVelocityLayer::None;
    return velocity >= osc.velocitySwitch ? Pa5xVelocityLayer::High : Pa5xVelocityLayer::Low;
}

void derivePa5xSoundCommonParameters(Pa5xSoundReferenceGraph& graph) noexcept {
    graph.pitchEnvelopeRaw={};graph.pitchEnvelopePresent=false;graph.pitchEnvelopeDecoded=false;
    for(auto& oscillator:graph.oscillators){
        oscillator.outputRaw={};oscillator.outputRawPresent=false;
    }
    if(!graph.referenceGraphDecoded||graph.resourceVersion[1]!=0U)return;
    const auto version=graph.resourceVersion[0];
    const auto layout=soundFxLayout(version);
    const auto& bytes=graph.commonRaw;
    if(layout.prefix==0U||bytes.size()!=layout.prefix)return;
    const std::size_t voiceOffset=version<3U?18U:2U;
    if(bytes[voiceOffset]!=graph.voiceFlagsRaw||(graph.voiceFlagsRaw&2U)!=0U||
       bytes[layout.countOffset]!=graph.oscillatorFlagsRaw||
       static_cast<std::size_t>(graph.oscillatorFlagsRaw&63U)!=graph.oscillators.size()||
       graph.decodedBodyBytes!=layout.prefix+layout.oscillatorStride*graph.oscillators.size())return;
    const std::size_t expectedTail=version<=3U?4U:
        layout.oscillatorStride-(2U*(12U+(version<7U?3U:4U))+6U);
    for(auto& oscillator:graph.oscillators){
        if(oscillator.undecodedTail.size()!=expectedTail)continue;
        std::copy_n(oscillator.undecodedTail.end()-static_cast<std::ptrdiff_t>(oscillator.outputRaw.size()),
            oscillator.outputRaw.size(),oscillator.outputRaw.begin());
        oscillator.outputRawPresent=true;
    }
    // Revision 8 inserts its independent Legato-mode pair before this block.
    // Nine same-Sound cross-revision pairs retain all 14 bytes; the normalized
    // fields match the official TRITON Program 216..229 declaration.
    const auto offset=layout.countOffset+8U+(version==8U?2U:0U);
    if(offset>bytes.size()||graph.pitchEnvelopeRaw.size()>bytes.size()-offset)return;
    std::copy_n(bytes.begin()+static_cast<std::ptrdiff_t>(offset),
        graph.pitchEnvelopeRaw.size(),graph.pitchEnvelopeRaw.begin());
    graph.pitchEnvelopePresent=true;
    const auto& raw=graph.pitchEnvelopeRaw;
    for(const auto index:std::array<std::size_t,6>{{0U,2U,5U,7U,9U,11U}}){
        const int value=raw[index]<=127U?static_cast<int>(raw[index]):static_cast<int>(raw[index])-256;
        if(value < -99||value > 99)return;
    }
    for(const auto index:std::array<std::size_t,3>{{1U,3U,4U}})if(raw[index]>99U)return;
    for(unsigned shift=0U;shift<8U;shift+=2U)if(((raw[12]>>shift)&3U)==2U)return;
    if((raw[13]&0xF0U)!=0U||(raw[13]&3U)==2U||((raw[13]>>2U)&3U)==2U)return;
    graph.pitchEnvelopeDecoded=true;
}

Pa5xSoundEffectsRaw inspectPa5xSoundEffects(const Pa5xSoundReferenceGraph& graph) {
    Pa5xSoundEffectsRaw out;out.resourceVersion=graph.resourceVersion;
    const auto reject=[&](const char* reason) {
        out.records.clear();out.framingDecoded=false;out.error=reason;return out;
    };
    if(!graph.referenceGraphDecoded||graph.resourceVersion[1]!=0U)
        return reject("Sound FX require a successfully bounded normal Sound graph");
    // Legacy framing follows the existing versioned Sound reader. Newer
    // placement is independently corroborated by complete64-byte equality with
    // the original KSC FX records and exact common/oscillator boundaries across
    // all450 newer normal Sounds in the supplied corpus. See
    // docs/PA5X_SOUND_FX_IMPORT.md. These are record ordinals, not IFX/MFX slots.
    const auto layout=soundFxLayout(graph.resourceVersion[0]);
    if(layout.count==0U)return reject("Sound FX framing is unsupported for this resource revision");
    const auto& bytes=graph.commonRaw;
    if(bytes.size()!=layout.prefix||layout.countOffset>=bytes.size()||layout.start>bytes.size()||
       layout.count>(bytes.size()-layout.start)/layout.stride||
       layout.start+layout.count*layout.stride>bytes.size()-layout.controls||
       layout.start+layout.count*layout.stride+layout.controls!=layout.countOffset)
        return reject("Sound FX records do not fit the exact versioned common boundary");
    const auto voiceOffset=graph.resourceVersion[0]<3U?18U:2U;
    const std::size_t oscillatorCount=bytes[layout.countOffset]&63U;
    if((bytes[voiceOffset]&2U)!=0U||bytes[voiceOffset]!=graph.voiceFlagsRaw||
       bytes[layout.countOffset]!=graph.oscillatorFlagsRaw||oscillatorCount!=graph.oscillators.size()||
       graph.decodedBodyBytes!=layout.prefix+oscillatorCount*layout.oscillatorStride)
        return reject("Sound FX framing disagrees with the validated normal Sound body");
    if(!readSoundFxRecords(bytes,layout.start,layout,out))
        return reject("Sound FX record extraction exceeded the common boundary");
    return out;
}

std::vector<std::uint8_t> encodePa5xSoundEffects(const Pa5xSoundEffectsRaw& effects) {
    const auto layout=soundFxLayout(effects.resourceVersion[0]);
    if(!effects.framingDecoded||effects.resourceVersion[1]!=0U||layout.count==0U||
       effects.records.size()!=layout.count||effects.commonControlsBytes!=layout.controls||
       effects.commonControlsBodyOffset!=layout.start+layout.count*layout.stride||
       effects.activationDecoded||effects.slotOwnershipDecoded||effects.routingDecoded||!effects.error.empty())return {};
    for(std::size_t i=layout.controls;i<effects.commonControlsRaw.size();++i)
        if(effects.commonControlsRaw[i]!=0U)return {};
    std::vector<std::uint8_t> out;
    out.reserve(4U+layout.count*layout.stride+layout.controls);
    out.push_back(1U);out.push_back(effects.resourceVersion[0]);out.push_back(effects.resourceVersion[1]);
    out.push_back(static_cast<std::uint8_t>(layout.count));
    for(std::size_t i=0;i<layout.count;++i) {
        const auto& record=effects.records[i];
        if(record.recordIndex!=i||record.recordBytes!=layout.stride||
           record.decodedBodyOffset!=layout.start+i*layout.stride||
           record.trailingControlPresent!=(layout.stride==67U)||
           (!record.trailingControlPresent&&record.trailingControlRaw!=0U)||
           record.selectorDecoded!=(record.leadingRaw==0U)||
           record.selector!=(record.selectorDecoded?record.selectorLowRaw:0U))return {};
        out.push_back(record.leadingRaw);
        out.insert(out.end(),record.parameters.begin(),record.parameters.end());
        out.push_back(record.selectorLowRaw);
        if(record.trailingControlPresent)out.push_back(record.trailingControlRaw);
    }
    out.insert(out.end(),effects.commonControlsRaw.begin(),
        effects.commonControlsRaw.begin()+static_cast<std::ptrdiff_t>(layout.controls));
    return out;
}

bool decodePa5xSoundEffects(const std::vector<std::uint8_t>& bytes,
                           Pa5xSoundEffectsRaw& effects,std::string& error) {
    effects={};error.clear();
    const auto reject=[&](const char* reason) {error=reason;effects.error=reason;return false;};
    if(bytes.size()<4U||bytes.size()>412U||bytes[0]!=1U||bytes[2]!=0U)
        return reject("Unsupported or truncated stored Sound FX metadata header");
    const auto layout=soundFxLayout(bytes[1]);
    if(layout.count==0U||bytes[3]!=layout.count||
       bytes.size()!=4U+layout.count*layout.stride+layout.controls)
        return reject("Stored Sound FX metadata does not match its exact versioned record count/length");
    effects.resourceVersion={bytes[1],bytes[2]};
    if(!readSoundFxRecords(bytes,4U,layout,effects))
        return reject("Stored Sound FX metadata records are truncated");
    return true;
}

Pa5xSoundReferenceGraph inspectPa5xSoundGraph(const std::vector<std::uint8_t>& bytes,
                                            const Pa5xPcgSound& sound) {
    Pa5xSoundReferenceGraph out;
    out.resourceVersion = sound.resourceVersion;
    out.synthesisBlockers.push_back("Normal Sound runtime envelope time/gain laws, filter response, AMS routing, pan and effect behavior are not decoded; no default ADSR is substituted.");
    const auto reject = [&](const std::string& error) {
        out.referenceGraphDecoded = false; out.parametersDecoded = false;
        out.oscillators.clear(); out.error = error; return out;
    };
    const int version = sound.resourceVersion[0];
    if (sound.resourceClass != 4 || sound.resourceVersion[1] != 0 || version == 4 || version > 8)
        return reject("Normal Sound reference layout is unsupported for this resource revision");
    out.recognized = true;
    if (sound.kind == Pa5xPcgSoundKind::DrumKit)
        return reject("Drum Kit layer references require their own version-aware decoder");
    if (bytes.size() > kMaximumPcgBytes || sound.payloadOffset > bytes.size() ||
        sound.payloadLength > bytes.size() - sound.payloadOffset || sound.payloadLength < 9)
        return reject("Sound payload exceeds its PCG file boundary");
    const auto decoded = decodePa5xOc31(bytes.data() + sound.payloadOffset,
        sound.payloadLength, kMaximumNormalBodyBytes);
    if (!decoded) return reject("Sound resource decompression failed: " + decoded.error);
    out.decodedBodyBytes = decoded.data.size();
    if(version >= 5) {
        // Independently derived framing facts, validated across every normal
        // object of these revisions in the supplied corpus (450objects). Each
        // version has one count-field/stride/prefix solution across all lengths.
        // The repeated source grammar and all key/velocity ranges consume the
        // complete body; UID joins are corroboration, never a byte-search rule.
        const std::size_t countOffset = version < 7 ? 288U : 423U;
        const std::size_t prefix = version < 7 ? 313U : (version == 7 ? 448U : 450U);
        const std::size_t stride = version == 5 ? 198U : (version == 6 ? 200U : 202U);
        const std::uint8_t extension = version < 7 ? 3 : 4;
        if(decoded.data.size() < prefix) return reject("New Sound common settings are truncated");
        out.voiceFlagsRaw = decoded.data[2];out.multisampleMapRaw = static_cast<std::uint16_t>((decoded.data[0]<<8U)|decoded.data[1]);
        if((out.voiceFlagsRaw & 2U)!=0) return reject("New Sound body is a Drum Kit");
        out.oscillatorFlagsRaw = decoded.data[countOffset];const std::size_t count = out.oscillatorFlagsRaw & 63U;
        if((decoded.data.size()-prefix)%stride != 0 || (decoded.data.size()-prefix)/stride != count)
            return reject("New Sound oscillator count/stride does not consume the exact body");
        out.commonRaw.assign(decoded.data.begin(),decoded.data.begin()+static_cast<std::ptrdiff_t>(prefix));
        out.corpusDerivedReferenceLayout = true;
        BodyReader fields(decoded.data);fields.skip(prefix);
        for(std::size_t i=0;i<count;++i) {
            Pa5xOscillatorReferences osc;osc.decodedBodyOffset = fields.position();
            if(!readNewSource(fields,extension,osc.high)||!readNewSource(fields,extension,osc.low))
                return reject("New Sound oscillator source grammar is malformed");
            osc.delayRaw=fields.byte();osc.velocitySwitch=fields.byte();osc.velocityLow=fields.byte();osc.velocityHigh=fields.byte();osc.keyLow=fields.byte();osc.keyHigh=fields.byte();
            if(osc.velocitySwitch<1||osc.velocitySwitch>127||osc.velocityLow>127||osc.velocityHigh>127||osc.velocityLow>osc.velocityHigh||osc.keyLow>127||osc.keyHigh>127||osc.keyLow>osc.keyHigh)
                return reject("New Sound oscillator key/velocity grammar is malformed");
            const auto highUse=pa5xSourceVelocityUse(osc,true),lowUse=pa5xSourceVelocityUse(osc,false);
            osc.high.velocityUseKnown=highUse.known;osc.high.velocityCanSelect=highUse.possible;
            osc.low.velocityUseKnown=lowUse.known;osc.low.velocityCanSelect=lowUse.possible;
            osc.staticPitchDecoded=false;osc.triggerFieldsDecoded=false;osc.scaledVelocityDecoded=false;
            const auto remaining = stride-(fields.position()-osc.decodedBodyOffset);
            osc.undecodedTail.reserve(remaining);for(std::size_t n=0;n<remaining;++n)osc.undecodedTail.push_back(fields.byte());
            if(!fields.good()) return reject("New Sound oscillator tail is truncated");
            decodeNewOscillatorDsp(osc,version,decoded.data);
            out.oscillators.push_back(std::move(osc));
        }
        if(fields.position()!=decoded.data.size()) return reject("New Sound has unconsumed bytes");
        out.synthesisBlockers.push_back("New oscillator source flags, added amplitude/portamento fields and their runtime scaling remain unestablished; retained DSP field layouts are decoded separately.");
        out.referenceGraphDecoded=true;out.effects=inspectPa5xSoundEffects(out);
        derivePa5xSoundCommonParameters(out);return out;
    }
    BodyReader r(decoded.data);
    out.multisampleMapRaw = r.word();
    if (version < 3) out.bodyName = r.name();
    out.voiceFlagsRaw = r.byte();
    if ((out.voiceFlagsRaw & 0x02U) != 0)
        return reject("Sound body is a Drum Kit; normal oscillator decoding is not applicable");
    r.skip(5);
    const auto transposeLow = r.byte(), transposeHigh = r.byte();
    if (!r.good() || transposeLow > 127 || transposeHigh > 127 || transposeLow > transposeHigh)
        return reject("Sound transpose range is malformed or unsupported");
    const int effects = version >= 2 ? 4 : 2;
    for (int i = 0; i < effects; ++i) {
        r.skip(1); r.skip(64); r.skip(1);
        if (version >= 2) r.skip(1);
    }
    r.skip(3);
    if (version >= 2) r.skip(3);
    out.oscillatorFlagsRaw = r.byte();
    const unsigned count = out.oscillatorFlagsRaw & 0x3FU;
    r.skip(1); // low-priority policy
    r.skip(6); // opaque Sound fields
    r.skip(14); // opaque common synthesis fields
    if (version >= 1) r.skip(3); // maximum time/range
    if (!r.good()) return reject("Sound common settings are truncated");
    out.commonRaw.assign(decoded.data.begin(),decoded.data.begin()+static_cast<std::ptrdiff_t>(r.position()));
    out.oscillators.reserve(count);
    for (unsigned i = 0; i < count; ++i) {
        Pa5xOscillatorReferences osc;
        osc.decodedBodyOffset = r.position();
        if (!readSource(r, version, osc.high) || !readSource(r, version, osc.low))
            return reject("Oscillator multisample source is truncated or unsupported");
        osc.delayRaw = r.byte(); osc.velocitySwitch = r.byte();
        osc.velocityLow = r.byte(); osc.velocityHigh = r.byte();
        osc.keyLow = r.byte(); osc.keyHigh = r.byte();
        if (osc.velocityLow > 127 || osc.velocityHigh > 127 || osc.velocityLow > osc.velocityHigh ||
            osc.keyLow > 127 || osc.keyHigh > 127 || osc.keyLow > osc.keyHigh)
            return reject("Oscillator key/velocity range is malformed or unsupported");
        const auto highUse=pa5xSourceVelocityUse(osc,true),lowUse=pa5xSourceVelocityUse(osc,false);
        osc.high.velocityUseKnown=highUse.known;osc.high.velocityCanSelect=highUse.possible;
        osc.low.velocityUseKnown=lowUse.known;osc.low.velocityCanSelect=lowUse.possible;
        r.skip(1);
        if (version >= 1) { osc.triggerModeRaw = r.byte(); osc.controllerExceptionRaw = r.byte(); }
        if (version >= 2) r.skip(2);
        r.skip(4);
        for(auto& value:osc.lfoRaw)value=r.byte();
        const int octave = r.byte();
        osc.octaveRaw = static_cast<std::int8_t>(octave <= 127 ? octave : octave - 256);
        osc.transposeRaw = r.byte(); osc.tuneRaw = r.signedWord();
        decodeStaticPitch(osc);
        for (auto& value : osc.opaqueDsp) value = r.byte();
        osc.scaledVelocityLow = r.byte(); osc.scaledVelocityHigh = r.byte();
        for(auto& value:osc.amplitudeEnvelopeRaw)value=r.byte();
        decodeCorroboratedOscillatorDsp(osc);
        if (version >= 2) {
            osc.equalizer.present=true;osc.equalizer.enabledRaw=r.byte();osc.equalizer.trimRaw=r.byte();
            osc.equalizer.lowGainTimes2Raw=r.byte();osc.equalizer.frequencyRaw=r.byte();
            osc.equalizer.midGainTimes2Raw=r.byte();osc.equalizer.highGainTimes2Raw=r.byte();
        }
        // Reuse the existing optional raw-tail archive field: adding original
        // output metadata does not alter the durable graph's base layout.
        for(std::size_t n=0;n<osc.outputRaw.size();++n)osc.undecodedTail.push_back(r.byte());
        if (!r.good()) return reject("Oscillator settings are truncated");
        out.oscillators.push_back(std::move(osc));
    }
    if (r.position() != decoded.data.size())
        return reject("Sound layout has trailing or unconsumed bytes; reference graph is not published");
    out.referenceGraphDecoded = true;
    out.effects=inspectPa5xSoundEffects(out);
    derivePa5xSoundCommonParameters(out);
    return out;
}

Pa5xSoundReferenceGraph inspectPa5xSoundGraphFile(const std::string& path,
                                                int internalBank, int rawProgram) {
    const auto index = inspectPa5xPcgFile(path);
    Pa5xSoundReferenceGraph out;
    if (!index.valid) { out.error = index.error; return out; }
    const Pa5xPcgSound* selected = nullptr;
    for (const auto& sound : index.sounds) {
        if (sound.internalBank == internalBank && sound.rawProgram == rawProgram) { selected = &sound; break; }
    }
    if (!selected) { out.error = "Sound raw bank/program is not present in the PCG index"; return out; }
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) { out.error = "Cannot open Sound PCG file"; return out; }
    const auto length = file.tellg();
    if (length < 0 || length > static_cast<std::streamoff>(kMaximumPcgBytes)) {
        out.error = "Sound PCG file exceeds the reference decoder size limit"; return out;
    }
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length)); file.seekg(0);
    file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!file) { out.error = "Sound PCG file read failed"; return out; }
    return inspectPa5xSoundGraph(bytes, *selected);
}
} // namespace silveton::arranger
