#pragma once
#include <array>
#include <cstdint>

namespace silveton::arranger::detail {
// Legacy Pa master cues may overlap on the same track and share an output
// pitch or pedal. Resets invalidate their previous ownership in constant time.
struct PaCueState {
    std::array<bool,128> held{};
    bool pedalDown{false};
    unsigned notesGeneration{0},pedalGeneration{0};
};
class PaCueGate {
public:
    constexpr void sync(PaCueState& cue) const noexcept {
        if(cue.notesGeneration!=notesGeneration_){
            cue.held={};cue.notesGeneration=notesGeneration_;
        }
        if(cue.pedalGeneration!=pedalGeneration_){
            cue.pedalDown=false;cue.pedalGeneration=pedalGeneration_;
        }
    }
    constexpr bool note(PaCueState& cue,unsigned key,bool attack) noexcept {
        if(attack){
            if(!cue.held[key])++owners_[key];
            cue.held[key]=true;
            return true;
        }
        if(!cue.held[key])return false;
        cue.held[key]=false;
        return --owners_[key]==0;
    }
    constexpr bool pedal(PaCueState& cue,bool down) noexcept {
        if(cue.pedalDown!=down){
            cue.pedalDown=down;
            if(down)++pedals_;else --pedals_;
        }
        return down || pedals_==0;
    }
    constexpr void reset(bool notes) noexcept {
        if(notes){owners_={};++notesGeneration_;}
        pedals_=0;++pedalGeneration_;
    }
private:
    std::array<unsigned,128> owners_{};
    unsigned pedals_{0},notesGeneration_{0},pedalGeneration_{0};
};
}
