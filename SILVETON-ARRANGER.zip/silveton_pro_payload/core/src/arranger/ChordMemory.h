#pragma once
#include "silveton/arranger/ChordRecognition.h"

namespace silveton::arranger {
// A release changes the physical key scan. With Memory on, it must not
// replace a played chord with the accidental shape left under the fingers.
constexpr Chord chordAfterScan(Chord sounding,Chord detected,bool memory,bool releaseOnly) noexcept {
    if(!memory)return detected;
    if(releaseOnly && sounding.valid())return sounding;
    return detected.valid()?detected:sounding;
}
} // namespace silveton::arranger
