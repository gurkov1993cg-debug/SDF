#include "silveton/arranger/Pa5xOc31.h"
#include <algorithm>
#include <cstring>

namespace silveton::arranger {

// Format provenance: the original independent OC31 research published by
// Amir Czwink, https://github.com/aczwink/KORG-Tools . No implementation text
// from that project is included here. This decoder uses a bounded output
// vector and validates every token and the complete stream before publishing.
Pa5xOc31Result decodePa5xOc31(const std::uint8_t* bytes, std::size_t size,
                            std::size_t maximumOutputBytes) {
    Pa5xOc31Result result;
    const auto reject = [&](const std::string& message) {
        result.data.clear(); result.error = message; return result;
    };
    if (bytes == nullptr || size < 9 || std::memcmp(bytes, "OC31", 4) != 0)
        return reject("OC31 header is missing or truncated");
    const std::size_t expected = static_cast<std::size_t>(bytes[4]) |
        (static_cast<std::size_t>(bytes[5]) << 8U) |
        (static_cast<std::size_t>(bytes[6]) << 16U) |
        (static_cast<std::size_t>(bytes[7]) << 24U);
    if (expected > maximumOutputBytes) return reject("OC31 decoded size exceeds the configured limit");
    result.data.reserve(expected);
    std::size_t input = 8;
    bool truncated = false;
    const auto get = [&]() -> unsigned {
        if (input >= size - 1) { truncated = true; return 0; }
        return bytes[input++];
    };
    const auto get16 = [&]() -> std::size_t {
        const auto high = get(); const auto low = get();
        return static_cast<std::size_t>((high << 8U) | low);
    };
    while (result.data.size() < expected) {
        const unsigned token = get();
        if (truncated) return reject("OC31 token is truncated");
        std::size_t length = 0, distance = 0, extra = 0;
        if (token < 16) {
            if (token == 0) length = static_cast<std::size_t>(get()) + 18;
            else if (token == 1) length = get16();
            else length = static_cast<std::size_t>(token) + 2;
            if (truncated || length == 0 || length > expected - result.data.size() || length > size - 1 - input)
                return reject("OC31 literal run exceeds its input or decoded boundary");
            result.data.insert(result.data.end(), bytes + input, bytes + input + length);
            input += length;
            continue;
        }
        if (token >= 64) {
            const unsigned tail = get();
            length = static_cast<std::size_t>(token >> 5U) + 1;
            distance = (static_cast<std::size_t>(token & 31U) << 6U) | (tail >> 2U);
            extra = tail & 3U;
        } else {
            const unsigned indicator = token >= 32 ? token & 31U : token & 7U;
            const std::size_t extendedBase = token >= 32 ? 34 : 10;
            if (indicator == 0) length = static_cast<std::size_t>(get()) + extendedBase;
            else if (indicator == 1) length = get16();
            else length = static_cast<std::size_t>(indicator) + 2;
            const auto packed = get16();
            distance = packed >> 2U;
            extra = packed & 3U;
            if (token < 32) distance += 16384 + ((token & 8U) != 0 ? 16384 : 0);
        }
        ++distance;
        if (truncated || length == 0 || distance > result.data.size())
            return reject("OC31 back-reference points outside decoded history");
        if (length > expected - result.data.size() || extra > expected - result.data.size() - length || extra > size - 1 - input)
            return reject("OC31 back-reference exceeds its input or decoded boundary");
        // Copy one byte at a time: overlapping dictionary references are legal.
        for (std::size_t n = 0; n < length; ++n)
            result.data.push_back(result.data[result.data.size() - distance]);
        result.data.insert(result.data.end(), bytes + input, bytes + input + extra);
        input += extra;
    }
    // Bank resources may finish with an explicit zero-length extended literal
    // token (01 00 00). It produces no bytes and precedes the XOR checksum.
    if (size - input == 4 && bytes[input] == 1 && bytes[input + 1] == 0 && bytes[input + 2] == 0)
        input += 3;
    if (input != size - 1) return reject("OC31 stream contains trailing or unconsumed bytes: decoded end " + std::to_string(input) + ", checksum position " + std::to_string(size - 1));
    std::uint8_t checksum = 0;
    for (const auto value : result.data) checksum ^= value;
    if (checksum != bytes[size - 1]) return reject("OC31 decoded checksum does not match");
    result.checksumVerified = true;
    return result;
}
}
