#include "silveton/arranger/ChordRecognition.h"

#include <cstddef>

namespace silveton::arranger {
namespace {
constexpr int pitchClass(int n) noexcept { const int p=n%12; return p<0?p+12:p; }
constexpr std::uint16_t note(int n) noexcept { return static_cast<std::uint16_t>(1U<<static_cast<unsigned>(n)); }
struct Notes {
    std::uint16_t mask{0};
    int count{0}, lowest{-1}, highest{-1};
};
constexpr Notes collect(const std::array<bool,128>& held) noexcept {
    Notes out;
    for(int n=0;n<128;++n) if(held[static_cast<std::size_t>(n)]) {
        out.mask=static_cast<std::uint16_t>(out.mask|note(pitchClass(n)));
        ++out.count;
        if(out.lowest<0) out.lowest=n;
        out.highest=n;
    }
    return out;
}
constexpr unsigned population(std::uint16_t mask) noexcept {
    unsigned count=0;
    for(unsigned m=mask;m;m>>=1U) count+=m&1U;
    return count;
}
constexpr std::uint16_t relativeMask(std::uint16_t mask,int root) noexcept {
    const unsigned value=mask;
    return static_cast<std::uint16_t>(((value>>static_cast<unsigned>(root))|
        (value<<static_cast<unsigned>(12-root)))&0xFFFU);
}
constexpr bool white(int key) noexcept {
    const int p=pitchClass(key);
    return p==0||p==2||p==4||p==5||p==7||p==9||p==11;
}
constexpr Chord makeChord(int root,ChordType type,int lowest,bool bassInversion) noexcept {
    return {pitchClass(root),type,bassInversion?pitchClass(lowest):pitchClass(root)};
}
struct Shape { ChordType type; std::uint16_t mask,tensions; };
// Constituent (circle) and optional tension (T) keys from the current Pa5X
// User Manual v1.5 EN13, printed pp1918-1919. A tension is not an arbitrary
// extra pitch: each full/reduced diagram declares its own allowed set. The
// recognized family selects its named original CV; this does not synthesize
// extra Korg NTT/Tension voices or infer an undocumented rootless chord.
constexpr Shape complete[]{
    {ChordType::Major7,0x891,0x044}, {ChordType::Minor7,0x489,0x024},
    {ChordType::Seventh,0x491,0x24E}, {ChordType::Major,0x091,0x06E},
    {ChordType::Minor,0x089,0x024}, {ChordType::Diminished,0x049,0x006},
    {ChordType::Augmented,0x111,0x00C}, {ChordType::Sus2,0x085,0x000},
    {ChordType::Sus4,0x0A1,0x006}, {ChordType::Major6,0x291,0x044},
    {ChordType::Minor6,0x289,0x024}, {ChordType::SeventhSus4,0x4A1,0x006},
    {ChordType::MajorFlat5,0x051,0x000}, {ChordType::SeventhFlat5,0x451,0x20E},
    {ChordType::Major7Flat5,0x851,0x004}, {ChordType::Major7Sus4,0x8A1,0x006},
    {ChordType::MinorMajor7,0x889,0x204}, {ChordType::Diminished7,0x249,0x000},
    {ChordType::DiminishedMajor7,0x849,0x024}, {ChordType::Minor7Flat5,0x449,0x224},
    {ChordType::Augmented7,0x511,0x04E}, {ChordType::AugmentedMajor7,0x911,0x04E}
};
// Fifth/third-omitted shapes are explicit separate diagrams. Fingered3 still
// requires three physical keys, so two pitch classes need octave doubling.
constexpr Shape reduced[]{
    {ChordType::Major,0x011,0x06C}, {ChordType::Minor,0x009,0x020},
    {ChordType::Major6,0x201,0x000}, {ChordType::Major7,0x811,0x004},
    {ChordType::Major7,0x801,0x004}, {ChordType::Sus4,0x021,0x000},
    {ChordType::Seventh,0x411,0x20E}, {ChordType::Seventh,0x401,0x206},
    {ChordType::SeventhSus4,0x421,0x006}, {ChordType::Minor7,0x409,0x004},
    {ChordType::MinorMajor7,0x809,0x004}
};
template<std::size_t N>
constexpr Chord matchShapeTable(const Notes& notes,const Shape (&shapes)[N],bool bassInversion,
                      bool allowTensions) noexcept {
    Chord found;
    int best=-1;
    // Every table shape includes its root. Keep the original table-first
    // tie order, but only test roots actually present in this voicing.
    std::array<int,12> roots{};
    std::array<std::uint16_t,12> relativeMasks{};
    std::size_t rootCount=0;
    for(int root=0;root<12;++root){
        if((notes.mask&note(root))==0)continue;
        roots[rootCount]=root;
        relativeMasks[rootCount++]=relativeMask(notes.mask,root);
    }
    for(const auto& shape:shapes) for(std::size_t i=0;i<rootCount;++i) {
        const auto relative=relativeMasks[i];
        if(allowTensions){
            if((relative&shape.mask)!=shape.mask ||
               (relative&static_cast<std::uint16_t>(~(shape.mask|shape.tensions)))!=0)continue;
        }else if(relative!=shape.mask)continue;
        // Keep the earlier exact-form root/bass tie-breaker and table order.
        // Among tension forms prefer more actual constituent notes, then a
        // root at the lowest played key. Dense arbitrary clusters fail the
        // per-diagram allowed mask instead of becoming a guessed major chord.
        const int root=roots[i];
        const int score=static_cast<int>(population(shape.mask))*2+
            (root==pitchClass(notes.lowest)?1:0);
        if(score>best){best=score;found=makeChord(root,shape.type,notes.lowest,bassInversion);}
    }
    return found;
}
constexpr Chord matchShapes(const Notes& notes,bool bassInversion,bool allowReduced) noexcept {
    auto found=matchShapeTable(notes,complete,bassInversion,false);
    if(found.valid())return found;
    found=matchShapeTable(notes,complete,bassInversion,true);
    if(found.valid()||!allowReduced)return found;
    found=matchShapeTable(notes,reduced,bassInversion,false);
    return found.valid()?found:matchShapeTable(notes,reduced,bassInversion,true);
}
// In Advanced mode, the third and seventh (guide tones) plus extensions
// can identify a jazz voicing without its root. A remembered matching root
// resolves otherwise identical note sets. Exact independent chords keep
// priority over a possible rootless reading of the same keys.
constexpr Chord rootless(const Notes& notes,Chord previous,bool bassInversion,bool contextualOnly) noexcept {
    if(population(notes.mask)<3)return {};
    struct Voicing {ChordType family;std::uint16_t guide,requiredColor,allowed;};
    constexpr auto n2=note(2),p5=note(7),n6=note(9),p4=note(5);
    constexpr Voicing shapes[]{
        {ChordType::Seventh,note(4)|note(10),n2|n6,note(4)|note(10)|n2|p5|n6},
        {ChordType::Major7,note(4)|note(11),n2|n6,note(4)|note(11)|n2|p5|n6},
        {ChordType::Minor7,note(3)|note(10),n2|p4,note(3)|note(10)|n2|p4|p5}
    };
    Chord best{};int bestScore=-1;bool ambiguous=false;
    for(int root=0;root<12;++root)for(const auto& shape:shapes){
        const auto rel=relativeMask(notes.mask,root);
        if((rel&shape.guide)!=shape.guide||!(rel&shape.requiredColor)||(rel&~shape.allowed))continue;
        const bool related=previous.valid()&&previous.root==root&&
            (previous.type==shape.family||(previous.type==ChordType::Major&&shape.family!=ChordType::Minor7)||
             (previous.type==ChordType::Minor&&shape.family==ChordType::Minor7));
        if(contextualOnly&&!related)continue;
        const int score=(related?4:0)+((note(pitchClass(notes.lowest-root))&shape.guide)?1:0);
        if(score>bestScore){bestScore=score;best=makeChord(root,shape.family,notes.lowest,bassInversion);ambiguous=false;}
        else if(score==bestScore&&(root!=best.root||shape.family!=best.type))ambiguous=true;
    }
    return ambiguous?Chord{}:best;
}
constexpr Chord oneFinger(const std::array<bool,128>& held,const Notes& notes,bool nearbyOnly,bool bassInversion) noexcept {
    const int root=notes.highest;
    bool lowerWhite=false,lowerBlack=false;
    int nearbyWhite=root-1,nearbyBlack=root-1;
    while(nearbyWhite>=0&&!white(nearbyWhite)) --nearbyWhite;
    while(nearbyBlack>=0&&white(nearbyBlack)) --nearbyBlack;
    for(int n=0;n<root;++n) if(held[static_cast<std::size_t>(n)]) {
        // "Close" is described by examples, not an exact numeric radius. Plus
        // conservatively accepts the nearest lower white and black keys only.
        if(nearbyOnly&&n!=nearbyWhite&&n!=nearbyBlack) return {};
        if(white(n)) lowerWhite=true; else lowerBlack=true;
    }
    const ChordType type=lowerBlack?(lowerWhite?ChordType::Minor7:ChordType::Minor)
                                   :(lowerWhite?ChordType::Seventh:ChordType::Major);
    return makeChord(root,type,notes.lowest,bassInversion);
}
} // namespace

std::uint16_t chordPitchClassMask(ChordType type) noexcept {
    if(type==ChordType::RootOctave) return 0x001;
    if(type==ChordType::RootFifth) return 0x081;
    for(const auto& shape:complete) if(shape.type==type) return shape.mask;
    return 0;
}

std::string chordName(Chord chord) {
    if(!chord.valid()) return "N.C.";
    static const char* roots[]{"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
    const char* suffix="";
    switch(chord.type) {
        case ChordType::Major: break;
        case ChordType::Minor: suffix="m"; break;
        case ChordType::Seventh: suffix="7"; break;
        case ChordType::Major7: suffix="maj7"; break;
        case ChordType::Minor7: suffix="m7"; break;
        case ChordType::Diminished: suffix="dim"; break;
        case ChordType::Augmented: suffix="aug"; break;
        case ChordType::Sus2: suffix="sus2"; break;
        case ChordType::Sus4: suffix="sus4"; break;
        case ChordType::Major6: suffix="6"; break;
        case ChordType::Minor6: suffix="m6"; break;
        case ChordType::SeventhSus4: suffix="7sus4"; break;
        case ChordType::MajorFlat5: suffix="(b5)"; break;
        case ChordType::SeventhFlat5: suffix="7b5"; break;
        case ChordType::Major7Flat5: suffix="maj7b5"; break;
        case ChordType::Major7Sus4: suffix="maj7sus4"; break;
        case ChordType::MinorMajor7: suffix="m(maj7)"; break;
        case ChordType::Diminished7: suffix="dim7"; break;
        case ChordType::DiminishedMajor7: suffix="dim(maj7)"; break;
        case ChordType::Minor7Flat5: suffix="m7b5"; break;
        case ChordType::Augmented7: suffix="aug7"; break;
        case ChordType::AugmentedMajor7: suffix="aug(maj7)"; break;
        case ChordType::RootOctave: suffix="(no3,no5)"; break;
        case ChordType::RootFifth: suffix="5"; break;
        case ChordType::None: return "N.C.";
        default: return "N.C.";
    }
    std::string out=roots[pitchClass(chord.root)];
    out+=suffix;
    if(pitchClass(chord.bass)!=pitchClass(chord.root)) {out+='/';out+=roots[pitchClass(chord.bass)];}
    return out;
}

namespace {
constexpr Chord recognizeKeys(const std::array<bool,128>& held,ChordRecognitionMode mode,
                     bool simplifiedAllowed,bool bassInversion,Chord previous) noexcept {
    const auto notes=collect(held);
    if(notes.count==0) return {};
    switch(mode) {
        case ChordRecognitionMode::OneFinger: case ChordRecognitionMode::OneFingerPlus:
        case ChordRecognitionMode::FingeredOneNote: case ChordRecognitionMode::FingeredThreeNotes:
        case ChordRecognitionMode::Advanced: break;
        default: return {};
    }
    // Upper/full keyboard and SPLIT-off require at least three keys; One Finger
    // explicitly switches to Fingered (3 Notes) when SPLIT is off.
    if(!simplifiedAllowed) {
        if(notes.count<3) return {};
        if(mode==ChordRecognitionMode::OneFinger||mode==ChordRecognitionMode::OneFingerPlus)
            mode=ChordRecognitionMode::FingeredThreeNotes;
    }
    if(mode==ChordRecognitionMode::FingeredThreeNotes&&notes.count<3) return {};
    if(mode==ChordRecognitionMode::OneFinger) return oneFinger(held,notes,false,bassInversion);
    if(mode==ChordRecognitionMode::OneFingerPlus) {
        if(notes.count>=3){
            const auto exact=matchShapeTable(notes,complete,bassInversion,false);
            if(exact.valid())return exact;
        }
        // A nearby white/black modifier is part of the shortcut. The same
        // three keys can also match a tension on an incomplete fingered chord.
        const auto shortcut=oneFinger(held,notes,true,bassInversion);
        if(shortcut.valid())return shortcut;
        return recognizeKeys(held,ChordRecognitionMode::FingeredThreeNotes,true,bassInversion,{});
    }
    const auto distinct=population(notes.mask);
    if(distinct==1) {
        return makeChord(notes.lowest,mode==ChordRecognitionMode::FingeredOneNote
            ?ChordType::Major:ChordType::RootOctave,notes.lowest,bassInversion);
    }
    for(int root=0;root<12;++root) if(relativeMask(notes.mask,root)==0x081)
        return makeChord(root,ChordType::RootFifth,notes.lowest,bassInversion);
    if(mode==ChordRecognitionMode::Advanced){
        const auto exact=matchShapeTable(notes,complete,bassInversion,false);
        if(exact.valid() && exact.root==pitchClass(notes.lowest))return exact;
        if(distinct>=4){
            // Re-evaluate the upper voicing independently of a separate bass.
            // Octave-doubled basses are still part of the upper chord if held.
            auto upperKeys=held;upperKeys[static_cast<std::size_t>(notes.lowest)]=false;
            const auto upper=collect(upperKeys);
            if(population(upper.mask)>=3){
                auto upperChord=matchShapeTable(upper,complete,false,false);
                if(upperChord.valid()){
                    const int bass=pitchClass(notes.lowest);
                    const bool distinctBass=(upper.mask&note(bass))==0&&upper.lowest-notes.lowest>=7;
                    if(bassInversion && (!exact.valid()||distinctBass)){
                        upperChord.bass=bass;return upperChord;
                    }
                    // An isolated bass below a complete upper chord can spell
                    // an explicit slash chord in Advanced even with inversion
                    // off. Keep normal inversions and root-position tensions.
                    if(!bassInversion && !exact.valid() && distinctBass && upper.lowest-notes.lowest>=12){
                        const auto relative=relativeMask(notes.mask,bass);
                        bool rooted=false;
                        for(const auto& shape:complete)
                            if((relative&shape.mask)==shape.mask && !(relative&~(shape.mask|shape.tensions)))rooted=true;
                        if(!rooted){upperChord.bass=bass;return upperChord;}
                    }
                }
            }
        }
        if(exact.valid())return exact;
        const auto withContext=rootless(notes,previous,bassInversion,true);
        if(withContext.valid())return withContext;
        const auto voicing=rootless(notes,{},bassInversion,false);
        if(voicing.valid())return voicing;
    }
    return matchShapes(notes,bassInversion,true);
}

} // namespace

Chord recognizeChord(const std::array<bool,128>& held,ChordRecognitionMode mode,
                     bool simplifiedAllowed,bool bassInversion,Chord previous) noexcept {
    return recognizeKeys(held,mode,simplifiedAllowed,bassInversion,previous);
}

Chord detectChord(const std::array<bool,128>& held) noexcept {
    const auto notes=collect(held);
    if(notes.mask==0) return {};
    const unsigned count=population(notes.mask);
    if(count==1) return {pitchClass(notes.lowest),ChordType::Major,pitchClass(notes.lowest)};
    struct Pattern { ChordType type; unsigned mask; unsigned notes; };
    constexpr Pattern patterns[]{
        {ChordType::Major7,0x891,4}, {ChordType::Minor7,0x489,4},
        {ChordType::Seventh,0x491,4}, {ChordType::Major,0x091,3},
        {ChordType::Minor,0x089,3}, {ChordType::Diminished,0x049,3},
        {ChordType::Augmented,0x111,3}, {ChordType::Sus2,0x085,3},
        {ChordType::Sus4,0x0A1,3}
    };
    Chord result;
    int best=-1000;
    for(int root=0;root<12;++root) {
        const unsigned relative=relativeMask(notes.mask,root);
        for(const auto& pattern:patterns) {
            if((relative&pattern.mask)!=pattern.mask) continue;
            const int score=static_cast<int>(pattern.notes)*10-static_cast<int>(count-pattern.notes)*12+
                (root==pitchClass(notes.lowest)?2:0);
            if(score>best) { best=score; result={root,pattern.type,pitchClass(notes.lowest)}; }
        }
    }
    return result;
}
} // namespace silveton::arranger
