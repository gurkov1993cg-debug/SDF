#pragma once

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

// Internal, bounded metadir reader and filename correspondence helpers. The
// catalog retains original filesystem paths; these keys never rename files.
namespace silveton::arranger::style_directory {

struct MetadataFile {
    std::string file,icon;
    bool blank{false};
};

namespace detail {
inline bool appendUtf8(std::string& out,std::uint32_t cp) {
    if(cp>0x10FFFFU||(cp>=0xD800U&&cp<=0xDFFFU))return false;
    if(cp<0x80U)out.push_back(static_cast<char>(cp));
    else if(cp<0x800U) {
        out.push_back(static_cast<char>(0xC0U|(cp>>6U)));
        out.push_back(static_cast<char>(0x80U|(cp&63U)));
    } else if(cp<0x10000U) {
        out.push_back(static_cast<char>(0xE0U|(cp>>12U)));
        out.push_back(static_cast<char>(0x80U|((cp>>6U)&63U)));
        out.push_back(static_cast<char>(0x80U|(cp&63U)));
    } else {
        out.push_back(static_cast<char>(0xF0U|(cp>>18U)));
        out.push_back(static_cast<char>(0x80U|((cp>>12U)&63U)));
        out.push_back(static_cast<char>(0x80U|((cp>>6U)&63U)));
        out.push_back(static_cast<char>(0x80U|(cp&63U)));
    }
    return true;
}

inline bool decodeUtf8(const std::string& value,std::vector<std::uint32_t>& out) {
    out.clear();
    for(std::size_t i=0;i<value.size();) {
        const auto first=static_cast<unsigned char>(value[i++]);
        if(first<0x80U){out.push_back(first);continue;}
        unsigned count=0;std::uint32_t cp=0,minimum=0;
        if(first>=0xC2U&&first<=0xDFU){count=1;cp=first&31U;minimum=0x80U;}
        else if(first>=0xE0U&&first<=0xEFU){count=2;cp=first&15U;minimum=0x800U;}
        else if(first>=0xF0U&&first<=0xF4U){count=3;cp=first&7U;minimum=0x10000U;}
        else return false;
        if(value.size()-i<count)return false;
        for(unsigned n=0;n<count;++n) {
            const auto next=static_cast<unsigned char>(value[i++]);
            if((next&0xC0U)!=0x80U)return false;
            cp=(cp<<6U)|(next&63U);
        }
        if(cp<minimum||cp>0x10FFFFU||(cp>=0xD800U&&cp<=0xDFFFU))return false;
        out.push_back(cp);
    }
    return true;
}

class MetadataReader {
public:
    explicit MetadataReader(const std::string& text):text_(text) {}
    bool read(std::vector<MetadataFile>& entries,std::string& error) {
        if(text_.size()>8U*1024U*1024U){error="Style directory metadata exceeds the 8 MiB bound";return false;}
        // An optional UTF-8 BOM does not alter any stored filename.
        if(text_.size()>=3U&&static_cast<unsigned char>(text_[0])==0xEFU&&
           static_cast<unsigned char>(text_[1])==0xBBU&&static_cast<unsigned char>(text_[2])==0xBFU)pos_=3;
        if(!take('{'))return failed(error,"Expected a metadata object");
        bool hasFiles=false;
        if(!peek('}'))for(;;) {
            std::string key;
            if(!string(key)||!take(':'))return failed(error,"Invalid metadata object property");
            if(key=="files") {
                if(hasFiles)return failed(error,"Duplicate files arrays are ambiguous");
                hasFiles=true;
                if(!files(entries))return failed(error,"Invalid files array");
            } else if(!skipValue(1))return failed(error,"Invalid metadata value");
            if(!take(','))break;
        }
        if(!take('}'))return failed(error,"Unterminated metadata object");
        whitespace();
        if(pos_!=text_.size())return failed(error,"Unexpected trailing metadata data");
        if(!hasFiles)return failed(error,"Style directory metadata has no files array");
        return true;
    }
private:
    const std::string& text_;
    std::size_t pos_{0};
    void whitespace() {
        while(pos_<text_.size()&&(text_[pos_]==' '||text_[pos_]=='\t'||text_[pos_]=='\r'||text_[pos_]=='\n'))++pos_;
    }
    bool peek(char expected) {
        whitespace();return pos_<text_.size()&&text_[pos_]==expected;
    }
    bool take(char expected) {
        if(!peek(expected))return false;
        ++pos_;return true;
    }
    bool failed(std::string& error,const char* message) const {
        error=std::string(message)+" at byte "+std::to_string(pos_);return false;
    }
    bool literal(const char* value,std::size_t length) {
        whitespace();
        if(text_.size()-pos_<length||text_.compare(pos_,length,value)!=0)return false;
        pos_+=length;return true;
    }
    bool hex4(std::uint32_t& out) {
        if(text_.size()-pos_<4U)return false;
        out=0;
        for(unsigned i=0;i<4U;++i) {
            const auto c=static_cast<unsigned char>(text_[pos_++]);
            unsigned value=0;
            if(c>='0'&&c<='9')value=c-'0';
            else if(c>='a'&&c<='f')value=c-'a'+10U;
            else if(c>='A'&&c<='F')value=c-'A'+10U;
            else return false;
            out=(out<<4U)|value;
        }
        return true;
    }
    bool string(std::string& out) {
        if(!take('"'))return false;
        out.clear();
        while(pos_<text_.size()) {
            const auto c=static_cast<unsigned char>(text_[pos_++]);
            if(c=='"') {
                std::vector<std::uint32_t> decoded;
                return decodeUtf8(out,decoded);
            }
            if(c<0x20U)return false;
            if(c!='\\'){out.push_back(static_cast<char>(c));continue;}
            if(pos_==text_.size())return false;
            const char escape=text_[pos_++];
            switch(escape) {
                case '"':out.push_back('"');break;
                case '\\':out.push_back('\\');break;
                case '/':out.push_back('/');break;
                case 'b':out.push_back('\b');break;
                case 'f':out.push_back('\f');break;
                case 'n':out.push_back('\n');break;
                case 'r':out.push_back('\r');break;
                case 't':out.push_back('\t');break;
                case 'u': {
                    std::uint32_t cp=0;
                    if(!hex4(cp))return false;
                    if(cp>=0xD800U&&cp<=0xDBFFU) {
                        if(text_.size()-pos_<2U||text_[pos_]!='\\'||text_[pos_+1U]!='u')return false;
                        pos_+=2U;std::uint32_t low=0;
                        if(!hex4(low)||low<0xDC00U||low>0xDFFFU)return false;
                        cp=0x10000U+((cp-0xD800U)<<10U)+(low-0xDC00U);
                    }
                    if(!appendUtf8(out,cp))return false;
                    break;
                }
                default:return false;
            }
        }
        return false;
    }
    bool files(std::vector<MetadataFile>& entries) {
        if(!take('['))return false;
        if(!peek(']'))for(;;) {
            if(entries.size()>=50000U)return false;
            MetadataFile entry;
            if(peek('{')) {
                (void)take('{');bool hasFile=false,hasIcon=false;
                if(!peek('}'))for(;;) {
                    std::string key;
                    if(!string(key)||!take(':'))return false;
                    if(key=="file"||key=="icon") {
                        bool& seen=key=="file"?hasFile:hasIcon;
                        if(seen)return false;
                        seen=true;
                        auto& target=key=="file"?entry.file:entry.icon;
                        if(peek('"')){if(!string(target))return false;}
                        else if(!literal("null",4U))return false;
                    } else if(!skipValue(3))return false;
                    if(!take(','))break;
                }
                if(!take('}')||!hasFile)return false;
                entry.blank=entry.file.empty();
            } else if(peek('"')) {
                if(!string(entry.file))return false;
                entry.blank=entry.file.empty();
            } else {
                if(!literal("null",4U))return false;
                entry.blank=true;
            }
            entries.push_back(std::move(entry));
            if(!take(','))break;
        }
        return take(']');
    }
    bool number() {
        whitespace();const auto begin=pos_;
        if(pos_<text_.size()&&text_[pos_]=='-')++pos_;
        if(pos_==text_.size())return false;
        if(text_[pos_]=='0')++pos_;
        else {
            if(text_[pos_]<'1'||text_[pos_]>'9')return false;
            while(pos_<text_.size()&&text_[pos_]>='0'&&text_[pos_]<='9')++pos_;
        }
        if(pos_<text_.size()&&text_[pos_]=='.') {
            ++pos_;const auto fraction=pos_;
            while(pos_<text_.size()&&text_[pos_]>='0'&&text_[pos_]<='9')++pos_;
            if(pos_==fraction)return false;
        }
        if(pos_<text_.size()&&(text_[pos_]=='e'||text_[pos_]=='E')) {
            ++pos_;
            if(pos_<text_.size()&&(text_[pos_]=='+'||text_[pos_]=='-'))++pos_;
            const auto exponent=pos_;
            while(pos_<text_.size()&&text_[pos_]>='0'&&text_[pos_]<='9')++pos_;
            if(pos_==exponent)return false;
        }
        return pos_>begin;
    }
    bool skipValue(unsigned depth) {
        if(depth>32U)return false;
        if(peek('"')){std::string ignored;return string(ignored);}
        if(take('{')) {
            if(!peek('}'))for(;;) {
                std::string ignored;
                if(!string(ignored)||!take(':')||!skipValue(depth+1U))return false;
                if(!take(','))break;
            }
            return take('}');
        }
        if(take('[')) {
            if(!peek(']'))for(;;) {
                if(!skipValue(depth+1U))return false;
                if(!take(','))break;
            }
            return take(']');
        }
        if(peek('t'))return literal("true",4U);
        if(peek('f'))return literal("false",5U);
        if(peek('n'))return literal("null",4U);
        return number();
    }
};

// Unicode character/decomposition data, generated from standard character
// facts rather than copied library implementation. Canonical normalization is
// intentionally limited to Latin characters used by the directory filenames.
struct LatinDecomposition { std::uint32_t codepoint,first,second; };
inline constexpr LatinDecomposition latinDecompositions[] = {
    {0x00C0U,0x0041U,0x0300U},
    {0x00C1U,0x0041U,0x0301U},
    {0x00C2U,0x0041U,0x0302U},
    {0x00C3U,0x0041U,0x0303U},
    {0x00C4U,0x0041U,0x0308U},
    {0x00C5U,0x0041U,0x030AU},
    {0x00C7U,0x0043U,0x0327U},
    {0x00C8U,0x0045U,0x0300U},
    {0x00C9U,0x0045U,0x0301U},
    {0x00CAU,0x0045U,0x0302U},
    {0x00CBU,0x0045U,0x0308U},
    {0x00CCU,0x0049U,0x0300U},
    {0x00CDU,0x0049U,0x0301U},
    {0x00CEU,0x0049U,0x0302U},
    {0x00CFU,0x0049U,0x0308U},
    {0x00D1U,0x004EU,0x0303U},
    {0x00D2U,0x004FU,0x0300U},
    {0x00D3U,0x004FU,0x0301U},
    {0x00D4U,0x004FU,0x0302U},
    {0x00D5U,0x004FU,0x0303U},
    {0x00D6U,0x004FU,0x0308U},
    {0x00D9U,0x0055U,0x0300U},
    {0x00DAU,0x0055U,0x0301U},
    {0x00DBU,0x0055U,0x0302U},
    {0x00DCU,0x0055U,0x0308U},
    {0x00DDU,0x0059U,0x0301U},
    {0x00E0U,0x0061U,0x0300U},
    {0x00E1U,0x0061U,0x0301U},
    {0x00E2U,0x0061U,0x0302U},
    {0x00E3U,0x0061U,0x0303U},
    {0x00E4U,0x0061U,0x0308U},
    {0x00E5U,0x0061U,0x030AU},
    {0x00E7U,0x0063U,0x0327U},
    {0x00E8U,0x0065U,0x0300U},
    {0x00E9U,0x0065U,0x0301U},
    {0x00EAU,0x0065U,0x0302U},
    {0x00EBU,0x0065U,0x0308U},
    {0x00ECU,0x0069U,0x0300U},
    {0x00EDU,0x0069U,0x0301U},
    {0x00EEU,0x0069U,0x0302U},
    {0x00EFU,0x0069U,0x0308U},
    {0x00F1U,0x006EU,0x0303U},
    {0x00F2U,0x006FU,0x0300U},
    {0x00F3U,0x006FU,0x0301U},
    {0x00F4U,0x006FU,0x0302U},
    {0x00F5U,0x006FU,0x0303U},
    {0x00F6U,0x006FU,0x0308U},
    {0x00F9U,0x0075U,0x0300U},
    {0x00FAU,0x0075U,0x0301U},
    {0x00FBU,0x0075U,0x0302U},
    {0x00FCU,0x0075U,0x0308U},
    {0x00FDU,0x0079U,0x0301U},
    {0x00FFU,0x0079U,0x0308U},
    {0x0100U,0x0041U,0x0304U},
    {0x0101U,0x0061U,0x0304U},
    {0x0102U,0x0041U,0x0306U},
    {0x0103U,0x0061U,0x0306U},
    {0x0104U,0x0041U,0x0328U},
    {0x0105U,0x0061U,0x0328U},
    {0x0106U,0x0043U,0x0301U},
    {0x0107U,0x0063U,0x0301U},
    {0x0108U,0x0043U,0x0302U},
    {0x0109U,0x0063U,0x0302U},
    {0x010AU,0x0043U,0x0307U},
    {0x010BU,0x0063U,0x0307U},
    {0x010CU,0x0043U,0x030CU},
    {0x010DU,0x0063U,0x030CU},
    {0x010EU,0x0044U,0x030CU},
    {0x010FU,0x0064U,0x030CU},
    {0x0112U,0x0045U,0x0304U},
    {0x0113U,0x0065U,0x0304U},
    {0x0114U,0x0045U,0x0306U},
    {0x0115U,0x0065U,0x0306U},
    {0x0116U,0x0045U,0x0307U},
    {0x0117U,0x0065U,0x0307U},
    {0x0118U,0x0045U,0x0328U},
    {0x0119U,0x0065U,0x0328U},
    {0x011AU,0x0045U,0x030CU},
    {0x011BU,0x0065U,0x030CU},
    {0x011CU,0x0047U,0x0302U},
    {0x011DU,0x0067U,0x0302U},
    {0x011EU,0x0047U,0x0306U},
    {0x011FU,0x0067U,0x0306U},
    {0x0120U,0x0047U,0x0307U},
    {0x0121U,0x0067U,0x0307U},
    {0x0122U,0x0047U,0x0327U},
    {0x0123U,0x0067U,0x0327U},
    {0x0124U,0x0048U,0x0302U},
    {0x0125U,0x0068U,0x0302U},
    {0x0128U,0x0049U,0x0303U},
    {0x0129U,0x0069U,0x0303U},
    {0x012AU,0x0049U,0x0304U},
    {0x012BU,0x0069U,0x0304U},
    {0x012CU,0x0049U,0x0306U},
    {0x012DU,0x0069U,0x0306U},
    {0x012EU,0x0049U,0x0328U},
    {0x012FU,0x0069U,0x0328U},
    {0x0130U,0x0049U,0x0307U},
    {0x0134U,0x004AU,0x0302U},
    {0x0135U,0x006AU,0x0302U},
    {0x0136U,0x004BU,0x0327U},
    {0x0137U,0x006BU,0x0327U},
    {0x0139U,0x004CU,0x0301U},
    {0x013AU,0x006CU,0x0301U},
    {0x013BU,0x004CU,0x0327U},
    {0x013CU,0x006CU,0x0327U},
    {0x013DU,0x004CU,0x030CU},
    {0x013EU,0x006CU,0x030CU},
    {0x0143U,0x004EU,0x0301U},
    {0x0144U,0x006EU,0x0301U},
    {0x0145U,0x004EU,0x0327U},
    {0x0146U,0x006EU,0x0327U},
    {0x0147U,0x004EU,0x030CU},
    {0x0148U,0x006EU,0x030CU},
    {0x014CU,0x004FU,0x0304U},
    {0x014DU,0x006FU,0x0304U},
    {0x014EU,0x004FU,0x0306U},
    {0x014FU,0x006FU,0x0306U},
    {0x0150U,0x004FU,0x030BU},
    {0x0151U,0x006FU,0x030BU},
    {0x0154U,0x0052U,0x0301U},
    {0x0155U,0x0072U,0x0301U},
    {0x0156U,0x0052U,0x0327U},
    {0x0157U,0x0072U,0x0327U},
    {0x0158U,0x0052U,0x030CU},
    {0x0159U,0x0072U,0x030CU},
    {0x015AU,0x0053U,0x0301U},
    {0x015BU,0x0073U,0x0301U},
    {0x015CU,0x0053U,0x0302U},
    {0x015DU,0x0073U,0x0302U},
    {0x015EU,0x0053U,0x0327U},
    {0x015FU,0x0073U,0x0327U},
    {0x0160U,0x0053U,0x030CU},
    {0x0161U,0x0073U,0x030CU},
    {0x0162U,0x0054U,0x0327U},
    {0x0163U,0x0074U,0x0327U},
    {0x0164U,0x0054U,0x030CU},
    {0x0165U,0x0074U,0x030CU},
    {0x0168U,0x0055U,0x0303U},
    {0x0169U,0x0075U,0x0303U},
    {0x016AU,0x0055U,0x0304U},
    {0x016BU,0x0075U,0x0304U},
    {0x016CU,0x0055U,0x0306U},
    {0x016DU,0x0075U,0x0306U},
    {0x016EU,0x0055U,0x030AU},
    {0x016FU,0x0075U,0x030AU},
    {0x0170U,0x0055U,0x030BU},
    {0x0171U,0x0075U,0x030BU},
    {0x0172U,0x0055U,0x0328U},
    {0x0173U,0x0075U,0x0328U},
    {0x0174U,0x0057U,0x0302U},
    {0x0175U,0x0077U,0x0302U},
    {0x0176U,0x0059U,0x0302U},
    {0x0177U,0x0079U,0x0302U},
    {0x0178U,0x0059U,0x0308U},
    {0x0179U,0x005AU,0x0301U},
    {0x017AU,0x007AU,0x0301U},
    {0x017BU,0x005AU,0x0307U},
    {0x017CU,0x007AU,0x0307U},
    {0x017DU,0x005AU,0x030CU},
    {0x017EU,0x007AU,0x030CU},
    {0x01A0U,0x004FU,0x031BU},
    {0x01A1U,0x006FU,0x031BU},
    {0x01AFU,0x0055U,0x031BU},
    {0x01B0U,0x0075U,0x031BU},
    {0x01CDU,0x0041U,0x030CU},
    {0x01CEU,0x0061U,0x030CU},
    {0x01CFU,0x0049U,0x030CU},
    {0x01D0U,0x0069U,0x030CU},
    {0x01D1U,0x004FU,0x030CU},
    {0x01D2U,0x006FU,0x030CU},
    {0x01D3U,0x0055U,0x030CU},
    {0x01D4U,0x0075U,0x030CU},
    {0x01D5U,0x00DCU,0x0304U},
    {0x01D6U,0x00FCU,0x0304U},
    {0x01D7U,0x00DCU,0x0301U},
    {0x01D8U,0x00FCU,0x0301U},
    {0x01D9U,0x00DCU,0x030CU},
    {0x01DAU,0x00FCU,0x030CU},
    {0x01DBU,0x00DCU,0x0300U},
    {0x01DCU,0x00FCU,0x0300U},
    {0x01DEU,0x00C4U,0x0304U},
    {0x01DFU,0x00E4U,0x0304U},
    {0x01E0U,0x0226U,0x0304U},
    {0x01E1U,0x0227U,0x0304U},
    {0x01E2U,0x00C6U,0x0304U},
    {0x01E3U,0x00E6U,0x0304U},
    {0x01E6U,0x0047U,0x030CU},
    {0x01E7U,0x0067U,0x030CU},
    {0x01E8U,0x004BU,0x030CU},
    {0x01E9U,0x006BU,0x030CU},
    {0x01EAU,0x004FU,0x0328U},
    {0x01EBU,0x006FU,0x0328U},
    {0x01ECU,0x01EAU,0x0304U},
    {0x01EDU,0x01EBU,0x0304U},
    {0x01EEU,0x01B7U,0x030CU},
    {0x01EFU,0x0292U,0x030CU},
    {0x01F0U,0x006AU,0x030CU},
    {0x01F4U,0x0047U,0x0301U},
    {0x01F5U,0x0067U,0x0301U},
    {0x01F8U,0x004EU,0x0300U},
    {0x01F9U,0x006EU,0x0300U},
    {0x01FAU,0x00C5U,0x0301U},
    {0x01FBU,0x00E5U,0x0301U},
    {0x01FCU,0x00C6U,0x0301U},
    {0x01FDU,0x00E6U,0x0301U},
    {0x01FEU,0x00D8U,0x0301U},
    {0x01FFU,0x00F8U,0x0301U},
    {0x0200U,0x0041U,0x030FU},
    {0x0201U,0x0061U,0x030FU},
    {0x0202U,0x0041U,0x0311U},
    {0x0203U,0x0061U,0x0311U},
    {0x0204U,0x0045U,0x030FU},
    {0x0205U,0x0065U,0x030FU},
    {0x0206U,0x0045U,0x0311U},
    {0x0207U,0x0065U,0x0311U},
    {0x0208U,0x0049U,0x030FU},
    {0x0209U,0x0069U,0x030FU},
    {0x020AU,0x0049U,0x0311U},
    {0x020BU,0x0069U,0x0311U},
    {0x020CU,0x004FU,0x030FU},
    {0x020DU,0x006FU,0x030FU},
    {0x020EU,0x004FU,0x0311U},
    {0x020FU,0x006FU,0x0311U},
    {0x0210U,0x0052U,0x030FU},
    {0x0211U,0x0072U,0x030FU},
    {0x0212U,0x0052U,0x0311U},
    {0x0213U,0x0072U,0x0311U},
    {0x0214U,0x0055U,0x030FU},
    {0x0215U,0x0075U,0x030FU},
    {0x0216U,0x0055U,0x0311U},
    {0x0217U,0x0075U,0x0311U},
    {0x0218U,0x0053U,0x0326U},
    {0x0219U,0x0073U,0x0326U},
    {0x021AU,0x0054U,0x0326U},
    {0x021BU,0x0074U,0x0326U},
    {0x021EU,0x0048U,0x030CU},
    {0x021FU,0x0068U,0x030CU},
    {0x0226U,0x0041U,0x0307U},
    {0x0227U,0x0061U,0x0307U},
    {0x0228U,0x0045U,0x0327U},
    {0x0229U,0x0065U,0x0327U},
    {0x022AU,0x00D6U,0x0304U},
    {0x022BU,0x00F6U,0x0304U},
    {0x022CU,0x00D5U,0x0304U},
    {0x022DU,0x00F5U,0x0304U},
    {0x022EU,0x004FU,0x0307U},
    {0x022FU,0x006FU,0x0307U},
    {0x0230U,0x022EU,0x0304U},
    {0x0231U,0x022FU,0x0304U},
    {0x0232U,0x0059U,0x0304U},
    {0x0233U,0x0079U,0x0304U},
};
inline constexpr std::array<std::uint32_t,128> cp437High{{
    0x00C7U,0x00FCU,0x00E9U,0x00E2U,0x00E4U,0x00E0U,0x00E5U,0x00E7U,
    0x00EAU,0x00EBU,0x00E8U,0x00EFU,0x00EEU,0x00ECU,0x00C4U,0x00C5U,
    0x00C9U,0x00E6U,0x00C6U,0x00F4U,0x00F6U,0x00F2U,0x00FBU,0x00F9U,
    0x00FFU,0x00D6U,0x00DCU,0x00A2U,0x00A3U,0x00A5U,0x20A7U,0x0192U,
    0x00E1U,0x00EDU,0x00F3U,0x00FAU,0x00F1U,0x00D1U,0x00AAU,0x00BAU,
    0x00BFU,0x2310U,0x00ACU,0x00BDU,0x00BCU,0x00A1U,0x00ABU,0x00BBU,
    0x2591U,0x2592U,0x2593U,0x2502U,0x2524U,0x2561U,0x2562U,0x2556U,
    0x2555U,0x2563U,0x2551U,0x2557U,0x255DU,0x255CU,0x255BU,0x2510U,
    0x2514U,0x2534U,0x252CU,0x251CU,0x2500U,0x253CU,0x255EU,0x255FU,
    0x255AU,0x2554U,0x2569U,0x2566U,0x2560U,0x2550U,0x256CU,0x2567U,
    0x2568U,0x2564U,0x2565U,0x2559U,0x2558U,0x2552U,0x2553U,0x256BU,
    0x256AU,0x2518U,0x250CU,0x2588U,0x2584U,0x258CU,0x2590U,0x2580U,
    0x03B1U,0x00DFU,0x0393U,0x03C0U,0x03A3U,0x03C3U,0x00B5U,0x03C4U,
    0x03A6U,0x0398U,0x03A9U,0x03B4U,0x221EU,0x03C6U,0x03B5U,0x2229U,
    0x2261U,0x00B1U,0x2265U,0x2264U,0x2320U,0x2321U,0x00F7U,0x2248U,
    0x00B0U,0x2219U,0x00B7U,0x221AU,0x207FU,0x00B2U,0x25A0U,0x00A0U,
}};
inline constexpr std::array<unsigned char,112> combiningClasses{{
    230,230,230,230,230,230,230,230,230,230,230,230,230,230,230,230,
    230,230,230,230,230,232,220,220,220,220,232,216,220,220,220,220,
    220,202,202,220,220,220,220,202,202,220,220,220,220,220,220,220,
    220,220,220,220,1,1,1,1,1,220,220,220,220,230,230,230,
    230,230,230,230,230,240,230,220,220,220,230,230,230,220,220,0,
    230,230,230,220,220,220,220,230,232,220,220,230,233,234,234,233,
    234,234,233,230,230,230,230,230,230,230,230,230,230,230,230,230,
}};

inline void appendLatinDecomposed(std::vector<std::uint32_t>& out,std::uint32_t cp,unsigned depth=0) {
    if(depth<8U) {
        const auto* first=std::begin(latinDecompositions);
        const auto* last=std::end(latinDecompositions);
        const auto* found=std::lower_bound(first,last,cp,[](const LatinDecomposition& value,std::uint32_t key){
            return value.codepoint<key;
        });
        if(found!=last&&found->codepoint==cp) {
            appendLatinDecomposed(out,found->first,depth+1U);
            appendLatinDecomposed(out,found->second,depth+1U);
            return;
        }
    }
    out.push_back(cp);
}
inline unsigned combiningClass(std::uint32_t cp) noexcept {
    return cp>=0x0300U&&cp<=0x036FU?combiningClasses[cp-0x0300U]:0U;
}
inline std::string normalizedLatin(const std::vector<std::uint32_t>& input) {
    std::vector<std::uint32_t> decomposed;
    decomposed.reserve(input.size());
    for(const auto cp:input)appendLatinDecomposed(decomposed,cp);
    for(std::size_t first=0;first<decomposed.size();) {
        if(combiningClass(decomposed[first])==0U){++first;continue;}
        auto last=first+1U;
        while(last<decomposed.size()&&combiningClass(decomposed[last])!=0U)++last;
        std::stable_sort(decomposed.begin()+static_cast<std::ptrdiff_t>(first),
            decomposed.begin()+static_cast<std::ptrdiff_t>(last),[](std::uint32_t a,std::uint32_t b){
                return combiningClass(a)<combiningClass(b);
            });
        first=last;
    }
    std::string out;out.reserve(input.size());
    for(const auto cp:decomposed)(void)appendUtf8(out,cp);
    return out;
}
} // namespace detail

inline bool parseMetadata(const std::string& json,std::vector<MetadataFile>& entries,std::string& error) {
    std::vector<MetadataFile> parsed;error.clear();
    detail::MetadataReader reader(json);
    if(!reader.read(parsed,error)){entries.clear();return false;}
    entries=std::move(parsed);return true;
}

inline bool naturalLess(const std::string& a,const std::string& b) {
    std::size_t ai=0,bi=0;
    const auto digit=[](unsigned char c){return c>='0'&&c<='9';};
    const auto folded=[](unsigned char c){return c>='A'&&c<='Z'?static_cast<unsigned char>(c-'A'+'a'):c;};
    while(ai<a.size()&&bi<b.size()) {
        const auto ac=static_cast<unsigned char>(a[ai]),bc=static_cast<unsigned char>(b[bi]);
        if(digit(ac)&&digit(bc)) {
            auto aend=ai,bend=bi;
            while(aend<a.size()&&digit(static_cast<unsigned char>(a[aend])))++aend;
            while(bend<b.size()&&digit(static_cast<unsigned char>(b[bend])))++bend;
            auto asig=ai,bsig=bi;
            while(asig<aend&&a[asig]=='0')++asig;
            while(bsig<bend&&b[bsig]=='0')++bsig;
            if(aend-asig!=bend-bsig)return aend-asig<bend-bsig;
            const auto comparison=a.compare(asig,aend-asig,b,bsig,bend-bsig);
            if(comparison!=0)return comparison<0;
            ai=aend;bi=bend;continue;
        }
        if(folded(ac)!=folded(bc))return folded(ac)<folded(bc);
        ++ai;++bi;
    }
    if(ai!=a.size()||bi!=b.size())return ai==a.size();
    return a<b;
}

inline std::vector<std::string> nameKeys(const std::string& actualName) {
    std::vector<std::uint32_t> points;
    if(!detail::decodeUtf8(actualName,points))return {actualName};
    std::vector<std::string> out{detail::normalizedLatin(points)};
    std::string recovered;recovered.reserve(points.size());
    for(const auto cp:points) {
        if(cp<128U){recovered.push_back(static_cast<char>(cp));continue;}
        const auto found=std::find(detail::cp437High.begin(),detail::cp437High.end(),cp);
        if(found==detail::cp437High.end())return out;
        recovered.push_back(static_cast<char>(128U+static_cast<unsigned>(found-detail::cp437High.begin())));
    }
    std::vector<std::uint32_t> recoveredPoints;
    if(detail::decodeUtf8(recovered,recoveredPoints)) {
        auto repaired=detail::normalizedLatin(recoveredPoints);
        if(repaired!=out.front())out.push_back(std::move(repaired));
    }
    return out;
}

} // namespace silveton::arranger::style_directory
