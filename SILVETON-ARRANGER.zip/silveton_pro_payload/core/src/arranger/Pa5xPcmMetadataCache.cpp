#include "silveton/arranger/Pa5xPcmMetadataCache.h"
#include "silveton/sampler/SvBankFormat.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <limits>
#include <set>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>

namespace silveton::arranger {
namespace {
constexpr std::size_t kHeaderBytes=64U;
constexpr std::size_t kMaximumMetadataBytes=32U*1024U*1024U;
constexpr std::uint64_t kMaximumSourceBytes=256U*1024U*1024U;
constexpr std::uint32_t kMaximumObjects=131072U;
constexpr std::uint32_t kMaximumStringBytes=65536U;
// Increment whenever the serialized schema or PCM inspector interpretation
// changes. Old parser results must not survive a decoder revision implicitly.
constexpr std::uint32_t kVersion=1U;
constexpr std::array<std::uint8_t,8> kMagic{{'S','V','P','5','M','E','T','A'}};
using Digest=std::array<std::uint8_t,32>;

bool cancelled(const std::atomic<bool>* cancel) noexcept {
    return cancel&&cancel->load(std::memory_order_relaxed);
}
bool validPath(const std::string& path) {
    return !path.empty()&&path.front()=='/'&&path.size()<=4096U&&path.find('\0')==std::string::npos;
}
bool validHash(const std::string& hash) {
    return hash.size()==64U&&std::all_of(hash.begin(),hash.end(),[](char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');});
}
bool validStamp(const Pa5xPcmSourceStamp& stamp) {
    return stamp.valid&&validPath(stamp.canonicalPath)&&stamp.size>=56U&&stamp.size<=kMaximumSourceBytes&&
        stamp.mtimeNanoseconds<1000000000U&&stamp.ctimeNanoseconds<1000000000U;
}
std::string cachePath(const std::string& directory,const std::string& canonicalPath) {
    const auto digest=silveton::sampler::sha256(reinterpret_cast<const std::uint8_t*>(canonicalPath.data()),canonicalPath.size());
    constexpr char digits[]="0123456789abcdef";
    std::string path=directory;
    if(path.back()!='/')path.push_back('/');
    path+="pcm-meta-";
    for(const auto byte:digest){path.push_back(digits[byte>>4U]);path.push_back(digits[byte&15U]);}
    path+=".svmeta";return path;
}
struct Writer {
    std::vector<std::uint8_t> bytes;
    bool valid{true};
    void integer(std::uint64_t value,unsigned width) {
        if(!valid||bytes.size()>kMaximumMetadataBytes-width){valid=false;return;}
        for(unsigned i=0;i<width;++i)bytes.push_back(static_cast<std::uint8_t>(value>>(i*8U)));
    }
    void string(const std::string& value) {
        if(value.size()>kMaximumStringBytes||bytes.size()>kMaximumMetadataBytes-value.size()-4U){valid=false;return;}
        integer(static_cast<std::uint32_t>(value.size()),4U);
        if(valid)bytes.insert(bytes.end(),value.begin(),value.end());
    }
};
struct Reader {
    const std::vector<std::uint8_t>& bytes;
    std::size_t position{0};
    bool valid{true};
    std::uint64_t integer(unsigned width) {
        if(!valid||position>bytes.size()||width>bytes.size()-position){valid=false;return 0;}
        std::uint64_t value=0;
        for(unsigned i=0;i<width;++i)value|=static_cast<std::uint64_t>(bytes[position++])<<(i*8U);
        return value;
    }
    std::uint8_t byte(){return static_cast<std::uint8_t>(integer(1U));}
    std::uint32_t word(){return static_cast<std::uint32_t>(integer(4U));}
    std::uint64_t wide(){return integer(8U);}
    std::int64_t signedWide(){const auto value=wide();return value<=static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())?
        static_cast<std::int64_t>(value):-1-static_cast<std::int64_t>(~value);}
    std::size_t size() {
        const auto value=wide();
        if(value>std::numeric_limits<std::size_t>::max()){valid=false;return 0;}
        return static_cast<std::size_t>(value);
    }
    std::string string() {
        const auto size=word();
        if(!valid||size>kMaximumStringBytes||position>bytes.size()||size>bytes.size()-position){valid=false;return {};}
        std::string value(reinterpret_cast<const char*>(bytes.data()+position),size);position+=size;return value;
    }
};
void writeStamp(Writer& writer,const Pa5xPcmSourceStamp& stamp) {
    writer.string(stamp.canonicalPath);writer.integer(stamp.size,8U);writer.integer(stamp.device,8U);writer.integer(stamp.inode,8U);
    writer.integer(static_cast<std::uint64_t>(stamp.mtimeSeconds),8U);writer.integer(stamp.mtimeNanoseconds,4U);
    writer.integer(static_cast<std::uint64_t>(stamp.ctimeSeconds),8U);writer.integer(stamp.ctimeNanoseconds,4U);
}
Pa5xPcmSourceStamp readStamp(Reader& reader) {
    Pa5xPcmSourceStamp stamp;stamp.canonicalPath=reader.string();stamp.size=reader.wide();stamp.device=reader.wide();stamp.inode=reader.wide();
    stamp.mtimeSeconds=reader.signedWide();stamp.mtimeNanoseconds=reader.word();stamp.ctimeSeconds=reader.signedWide();stamp.ctimeNanoseconds=reader.word();
    stamp.valid=reader.valid;return stamp;
}
void writeObject(Writer& writer,const Pa5xSampleObject& object) {
    writer.string(object.name);
    for(const auto value:{object.objectType,object.rawBank,object.rawSlot,object.versionMajor,object.versionMinor})writer.integer(value,1U);
    const unsigned flags=(object.hasId?1U:0U)|(object.idFromPayload?2U:0U)|(object.oc31Compressed?4U:0U)|
        (object.encrypted?8U:0U)|(object.containerDecoded?16U:0U)|(object.audioMetadataDecoded?32U:0U);
    writer.integer(flags,1U);writer.integer(object.resourceId,8U);writer.integer(object.payloadOffset,8U);writer.integer(object.payloadBytes,8U);
    writer.integer(object.payloadFlags,1U);writer.integer(object.decodedContainerBytes,8U);writer.string(object.decodeError);
    writer.integer(object.sampleFormat,1U);writer.integer(object.channelTag,1U);writer.integer(static_cast<unsigned>(object.pcmByteOrder),1U);
    writer.integer(object.sampleRate,4U);writer.integer(object.encodedSampleCount,4U);writer.integer(object.loopStart,4U);
    for(const auto value:object.rawAudioHeaderWords)writer.integer(value,4U);
    writer.integer(object.endPositionRaw,4U);writer.integer(object.secondaryEndPositionRaw,4U);
    writer.integer(object.audioDataOffset,8U);writer.integer(object.audioDataBytes,8U);
}
Pa5xSampleObject readObject(Reader& reader) {
    Pa5xSampleObject object;object.name=reader.string();
    object.objectType=reader.byte();object.rawBank=reader.byte();object.rawSlot=reader.byte();object.versionMajor=reader.byte();object.versionMinor=reader.byte();
    const auto flags=reader.byte();if(flags>63U)reader.valid=false;
    object.hasId=(flags&1U)!=0;object.idFromPayload=(flags&2U)!=0;object.oc31Compressed=(flags&4U)!=0;
    object.encrypted=(flags&8U)!=0;object.containerDecoded=(flags&16U)!=0;object.audioMetadataDecoded=(flags&32U)!=0;
    object.resourceId=reader.wide();object.payloadOffset=reader.size();object.payloadBytes=reader.size();
    object.payloadFlags=reader.byte();object.decodedContainerBytes=reader.size();object.decodeError=reader.string();
    object.sampleFormat=reader.byte();object.channelTag=reader.byte();const auto order=reader.byte();
    if(order>static_cast<unsigned>(Pa5xPcmByteOrder::LittleEndian))reader.valid=false;
    object.pcmByteOrder=static_cast<Pa5xPcmByteOrder>(order);
    object.sampleRate=reader.word();object.encodedSampleCount=reader.word();object.loopStart=reader.word();
    for(auto& value:object.rawAudioHeaderWords)value=reader.word();
    object.endPositionRaw=reader.word();object.secondaryEndPositionRaw=reader.word();
    object.audioDataOffset=reader.size();object.audioDataBytes=reader.size();return object;
}
bool validIndex(const Pa5xSampleIndex& index,const Pa5xPcmSourceStamp& stamp) {
    if(!validStamp(stamp)||!index.recognized||!index.valid||index.kind!=Pa5xSampleContainerKind::PcmSamples||!index.error.empty()||
       index.tocVersionMajor!=1U||index.tocVersionMinor>1U||index.objects.empty()||index.objects.size()>kMaximumObjects||
       index.waveformDecoded||index.multisampleMappingDecoded||!index.samples.empty()||!index.drumSamples.empty()||
       !index.keyZones.empty()||!index.multisamples.empty()||index.blockers.size()>1024U)return false;
    std::set<std::uint64_t> ids;
    std::uint64_t previousEnd=0;
    for(const auto& object:index.objects){
        const auto offset=static_cast<std::uint64_t>(object.payloadOffset),size=static_cast<std::uint64_t>(object.payloadBytes);
        const bool nested=object.versionMajor==2U&&object.versionMinor==0U;
        if(object.objectType!=6U||object.name.size()>1024U||object.decodeError.size()>kMaximumStringBytes||
           offset<36U||offset>stamp.size||size>stamp.size-offset||
           (previousEnd!=0U&&offset!=previousEnd+8U)||object.decodedContainerBytes>kMaximumSourceBytes||
           (object.idFromPayload&&!object.hasId)||(object.hasId&&!ids.insert(object.resourceId).second)||
           (nested?object.payloadFlags!=0x10U:((object.payloadFlags&~0x78U)!=0U||(object.payloadFlags&0x18U)!=0x18U))||
           object.oc31Compressed!=((object.payloadFlags&0x20U)!=0U)||object.encrypted!=((object.payloadFlags&0x40U)!=0U)||
           object.containerDecoded==object.encrypted)return false;
        previousEnd=offset+size;
        if(!object.oc31Compressed&&object.containerDecoded&&object.decodedContainerBytes!=size)return false;
        if(object.rawAudioHeaderWords[8]!=object.loopStart||object.rawAudioHeaderWords[9]!=object.endPositionRaw||
           object.rawAudioHeaderWords[11]!=object.secondaryEndPositionRaw)return false;
        if(object.audioMetadataDecoded){
            const std::uint64_t header=nested?82U:66U;
            const std::uint64_t width=object.sampleFormat==16U?2U:(object.sampleFormat==128U?1U:0U);
            if(!object.hasId||object.encrypted||object.versionMinor!=0U||(object.versionMajor!=0U&&object.versionMajor!=2U)||
               object.channelTag!=1U||object.sampleRate<8000U||object.sampleRate>192000U||width==0U||
               object.audioDataBytes!=static_cast<std::uint64_t>(object.encodedSampleCount)*width||
               object.decodedContainerBytes!=header+object.audioDataBytes||
               (!object.oc31Compressed&&object.audioDataOffset!=offset+header)||
               (object.oc31Compressed&&object.audioDataOffset!=0U)||
               object.pcmByteOrder!=(object.sampleFormat==16U?(nested?Pa5xPcmByteOrder::LittleEndian:Pa5xPcmByteOrder::BigEndian):Pa5xPcmByteOrder::Unknown))return false;
        }else if(object.audioDataOffset!=0U||object.audioDataBytes!=0U||object.pcmByteOrder!=Pa5xPcmByteOrder::Unknown||object.decodeError.empty())return false;
    }
    return true;
}
bool ensureDirectory(const std::string& directory) {
    if(!validPath(directory))return false;
    for(std::size_t end=1U;end<=directory.size();++end){
        if(end!=directory.size()&&directory[end]!='/')continue;
        const auto path=directory.substr(0,end);if(path=="/")continue;
        if(::mkdir(path.c_str(),0700)!=0&&errno!=EEXIST)return false;
        struct stat stamp{};if(::stat(path.c_str(),&stamp)!=0||!S_ISDIR(stamp.st_mode))return false;
    }
    return true;
}
bool transfer(int fd,std::uint8_t* bytes,std::size_t size,bool writing,const std::atomic<bool>* cancel=nullptr) {
    while(size!=0U){
        if(cancelled(cancel))return false;
        const auto chunk=std::min<std::size_t>(size,65536U);
        const auto count=writing ? ::write(fd,bytes,chunk) : ::read(fd,bytes,chunk);
        if(count<0&&errno==EINTR)continue;
        if(count<=0)return false;
        bytes+=static_cast<std::size_t>(count);size-=static_cast<std::size_t>(count);
    }
    return true;
}
} // namespace

Pa5xPcmSourceStamp inspectPa5xPcmSourceStamp(const std::string& sourcePath) {
    Pa5xPcmSourceStamp result;
    if(sourcePath.empty()||sourcePath.size()>4096U||sourcePath.find('\0')!=std::string::npos)return result;
    char* canonical=::realpath(sourcePath.c_str(),nullptr);
    if(!canonical)return result;
    result.canonicalPath=canonical;std::free(canonical);
    struct stat source{},alias{};
    if(!validPath(result.canonicalPath)||::stat(result.canonicalPath.c_str(),&source)!=0||!S_ISREG(source.st_mode)||source.st_size<0||
       ::stat(sourcePath.c_str(),&alias)!=0||alias.st_dev!=source.st_dev||alias.st_ino!=source.st_ino)return {};
    result.size=static_cast<std::uint64_t>(source.st_size);result.device=static_cast<std::uint64_t>(source.st_dev);result.inode=static_cast<std::uint64_t>(source.st_ino);
#if defined(__APPLE__)
    result.mtimeSeconds=source.st_mtimespec.tv_sec;result.mtimeNanoseconds=static_cast<std::uint32_t>(source.st_mtimespec.tv_nsec);
    result.ctimeSeconds=source.st_ctimespec.tv_sec;result.ctimeNanoseconds=static_cast<std::uint32_t>(source.st_ctimespec.tv_nsec);
#else
    result.mtimeSeconds=source.st_mtim.tv_sec;result.mtimeNanoseconds=static_cast<std::uint32_t>(source.st_mtim.tv_nsec);
    result.ctimeSeconds=source.st_ctim.tv_sec;result.ctimeNanoseconds=static_cast<std::uint32_t>(source.st_ctim.tv_nsec);
#endif
    result.valid=true;if(!validStamp(result))return {};return result;
}

bool samePa5xPcmSourceStamp(const Pa5xPcmSourceStamp& left,const Pa5xPcmSourceStamp& right) noexcept {
    return left.valid&&right.valid&&left.canonicalPath==right.canonicalPath&&left.size==right.size&&left.device==right.device&&left.inode==right.inode&&
        left.mtimeSeconds==right.mtimeSeconds&&left.mtimeNanoseconds==right.mtimeNanoseconds&&
        left.ctimeSeconds==right.ctimeSeconds&&left.ctimeNanoseconds==right.ctimeNanoseconds;
}

Pa5xPcmMetadataImport loadPa5xPcmMetadataCache(const std::string& sourcePath,const std::string& directory) {
    Pa5xPcmMetadataImport result;result.sourceStamp=inspectPa5xPcmSourceStamp(sourcePath);
    if(!validStamp(result.sourceStamp)||!validPath(directory)){result.error="PCM metadata cache source or directory is unavailable";return result;}
    const auto path=cachePath(directory,result.sourceStamp.canonicalPath);
    int flags=O_RDONLY|O_CLOEXEC;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    const int fd=::open(path.c_str(),flags);
    if(fd<0){result.error="PCM metadata cache is unavailable";return result;}
    struct stat file{};std::vector<std::uint8_t> header(kHeaderBytes);
    bool okay=::fstat(fd,&file)==0&&S_ISREG(file.st_mode)&&file.st_size>=static_cast<off_t>(kHeaderBytes)&&
        file.st_size<=static_cast<off_t>(kHeaderBytes+kMaximumMetadataBytes)&&transfer(fd,header.data(),header.size(),false);
    Reader head{header};for(const auto magic:kMagic)if(head.byte()!=magic)okay=false;
    const auto version=head.word(),headerSize=head.word();const auto payloadSize=head.wide();Digest storedDigest{};
    for(auto& value:storedDigest)value=head.byte();
    const auto reserved=head.wide();
    okay=okay&&head.valid&&version==kVersion&&headerSize==kHeaderBytes&&reserved==0U&&payloadSize<=kMaximumMetadataBytes&&
        static_cast<std::uint64_t>(file.st_size)==kHeaderBytes+payloadSize;
    std::vector<std::uint8_t> payload;
    if(okay){payload.resize(static_cast<std::size_t>(payloadSize));okay=transfer(fd,payload.data(),payload.size(),false);}
    ::close(fd);
    if(!okay||silveton::sampler::sha256(payload.data(),payload.size())!=storedDigest){result.error="PCM metadata cache checksum or format is invalid";return result;}
    Reader reader{payload};const auto storedStamp=readStamp(reader);result.contentHash=reader.string();
    Pa5xSampleIndex index;const auto indexFlags=reader.byte();
    index.recognized=(indexFlags&1U)!=0;index.valid=(indexFlags&2U)!=0;index.waveformDecoded=(indexFlags&4U)!=0;index.multisampleMappingDecoded=(indexFlags&8U)!=0;
    const auto kind=reader.byte();index.kind=static_cast<Pa5xSampleContainerKind>(kind);index.error=reader.string();
    index.tocVersionMajor=reader.byte();index.tocVersionMinor=reader.byte();const auto blockers=reader.word();
    if(blockers>1024U)reader.valid=false;
    for(std::uint32_t n=0;reader.valid&&n<blockers;++n)index.blockers.push_back(reader.string());
    const auto objects=reader.word();if(objects==0U||objects>kMaximumObjects||objects>(payload.size()-std::min(reader.position,payload.size()))/134U)reader.valid=false;
    for(std::uint32_t n=0;reader.valid&&n<objects;++n)index.objects.push_back(readObject(reader));
    if(!reader.valid||reader.position!=payload.size()||indexFlags>15U||kind!=static_cast<unsigned>(Pa5xSampleContainerKind::PcmSamples)||
       !samePa5xPcmSourceStamp(storedStamp,result.sourceStamp)||!validHash(result.contentHash)||!validIndex(index,storedStamp)||
       !samePa5xPcmSourceStamp(result.sourceStamp,inspectPa5xPcmSourceStamp(sourcePath))){
        result.contentHash.clear();result.error="PCM metadata cache does not match the unchanged source";return result;
    }
    result.index=std::move(index);result.cacheHit=true;return result;
}

bool storePa5xPcmMetadataCache(const std::string& sourcePath,const std::string& directory,const Pa5xSampleIndex& index,
                              const std::string& contentHash,const Pa5xPcmSourceStamp& expectedSource,const std::atomic<bool>* cancel) {
    if(cancelled(cancel)||!validHash(contentHash)||!validIndex(index,expectedSource)||!ensureDirectory(directory)||
       !samePa5xPcmSourceStamp(expectedSource,inspectPa5xPcmSourceStamp(sourcePath)))return false;
    Writer writer;writeStamp(writer,expectedSource);writer.string(contentHash);
    writer.integer((index.recognized?1U:0U)|(index.valid?2U:0U)|(index.waveformDecoded?4U:0U)|(index.multisampleMappingDecoded?8U:0U),1U);
    writer.integer(static_cast<unsigned>(index.kind),1U);writer.string(index.error);writer.integer(index.tocVersionMajor,1U);writer.integer(index.tocVersionMinor,1U);
    writer.integer(index.blockers.size(),4U);for(const auto& blocker:index.blockers)writer.string(blocker);
    writer.integer(index.objects.size(),4U);for(const auto& object:index.objects){if(cancelled(cancel))return false;writeObject(writer,object);}
    if(!writer.valid||cancelled(cancel))return false;
    const auto digest=silveton::sampler::sha256(writer.bytes.data(),writer.bytes.size());
    Writer header;for(const auto magic:kMagic)header.integer(magic,1U);header.integer(kVersion,4U);header.integer(kHeaderBytes,4U);header.integer(writer.bytes.size(),8U);
    for(const auto value:digest)header.integer(value,1U);
    header.integer(0U,8U);
    const auto path=cachePath(directory,expectedSource.canonicalPath);std::string temporary=path+".tmp-XXXXXX";
    std::vector<char> name(temporary.begin(),temporary.end());name.push_back(0);const int fd=::mkstemp(name.data());if(fd<0)return false;
    temporary=name.data();(void)::fcntl(fd,F_SETFD,FD_CLOEXEC);
    bool okay=transfer(fd,header.bytes.data(),header.bytes.size(),true,cancel)&&transfer(fd,writer.bytes.data(),writer.bytes.size(),true,cancel);
    if(::close(fd)!=0)okay=false;
    if(okay)okay=!cancelled(cancel)&&samePa5xPcmSourceStamp(expectedSource,inspectPa5xPcmSourceStamp(sourcePath))&&::rename(temporary.c_str(),path.c_str())==0;
    if(!okay)::unlink(temporary.c_str());
    return okay;
}
} // namespace silveton::arranger
