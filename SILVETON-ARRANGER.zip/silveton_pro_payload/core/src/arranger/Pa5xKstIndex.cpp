#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/Pa5xKstIndex.h"
#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xPcgIndex.h"
#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/arranger/Pa5xSampleIndex.h"
#include "silveton/arranger/Pa5xFactorySounds.h"
#include "Pa5xKstMetadataReuse.h"

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <sys/stat.h>
#include <tuple>
#include <unistd.h>

namespace silveton::arranger {
namespace {
constexpr std::size_t kMaximumResources = 50000;
constexpr std::size_t kMaximumDiagnostics = 10000;
constexpr const char* kTrackLabels[8] = {"Drum", "Perc", "Bass", "ACC1", "ACC2", "ACC3", "ACC4", "ACC5"};
std::string lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}
std::string extension(const std::string& s) {
    const auto p = s.find_last_of('.');
    return p == std::string::npos ? std::string() : lower(s.substr(p));
}
KstResourceKind classify(const std::string& relative) {
    const auto slash = relative.find('/');
    const auto folder = lower(relative.substr(0, slash));
    const auto ext = extension(relative);
    if (folder == "style" && (ext == ".sty" || ext == ".stg" || ext == ".mid" || ext == ".midi")) return KstResourceKind::Style;
    if (folder == "sound" && ext == ".pcg") return KstResourceKind::Sound;
    if (folder == "multismp" && ext == ".kmp") return KstResourceKind::Multisample;
    if (folder == "pcm" && ext == ".pcm") return KstResourceKind::Sample;
    if ((folder=="perform"||folder=="keyboardset")&&ext==".prf")return KstResourceKind::KeyboardSet;
    if ((folder == "keyboardset" || folder == "settings") && ext == ".ksc") return KstResourceKind::KeyboardSet;
    if (folder == "pad" && (ext == ".pdc"||ext==".pad")) return KstResourceKind::Pad;
    if (folder == "songbook") return KstResourceKind::SongBook;
    return KstResourceKind::Other;
}
void add(Pa5xKstIndex& out, KstSeverity severity, const std::string& code,
         const std::string& path, const std::string& message) {
    if (out.diagnostics.size() < kMaximumDiagnostics)
        out.diagnostics.push_back({severity, code, path, message});
}
bool cancelled(const std::atomic<bool>* cancel) {
    return cancel != nullptr && cancel->load(std::memory_order_relaxed);
}
struct Walk {
    Pa5xKstIndex& out;
    const std::function<void(const KstProgress&)>& progress;
    const std::atomic<bool>* cancel;
    bool ok{true};
    bool visit(const std::string& relative, unsigned depth) {
        if (cancelled(cancel)) { out.cancelled = true; return false; }
        if (depth > 32) {
            add(out, KstSeverity::Blocking, "DIRECTORY_DEPTH", relative, "Too many nested folders");
            ok = false; return true;
        }
        const std::string path = out.rootPath + (relative.empty() ? "" : "/" + relative);
        std::unique_ptr<DIR, int(*)(DIR*)> dir(::opendir(path.c_str()), ::closedir);
        if (!dir) {
            add(out, KstSeverity::Blocking, "FOLDER_UNREADABLE", relative, "Cannot read folder: " + std::string(std::strerror(errno)));
            ok = false; return true;
        }
        std::vector<std::string> names;
        errno = 0;
        while (const dirent* entry = ::readdir(dir.get())) {
            if (cancelled(cancel)) { out.cancelled = true; return false; }
            const std::string name = entry->d_name;
            if (!name.empty() && name.front() != '.' && name != "__MACOSX") names.push_back(name);
            if (names.size() > kMaximumResources) {
                add(out, KstSeverity::Blocking, "TOO_MANY_FILES", relative, "Folder contains too many entries");
                ok = false; return false;
            }
        }
        if (errno != 0) {
            add(out, KstSeverity::Blocking, "FOLDER_READ_FAILED", relative, "Directory listing is incomplete");
            ok = false;
        }
        std::sort(names.begin(), names.end());
        for (const auto& name : names) {
            if (cancelled(cancel)) { out.cancelled = true; return false; }
            const auto child = relative.empty() ? name : relative + "/" + name;
            const auto full = out.rootPath + "/" + child;
            struct stat st{};
            if (::lstat(full.c_str(), &st) != 0) {
                add(out, KstSeverity::Blocking, "RESOURCE_MISSING", child, "Cannot read file metadata");
                ok = false; continue;
            }
            if (S_ISLNK(st.st_mode)) {
                add(out, KstSeverity::Blocking, "LINKED_RESOURCE", child, "Linked files must be copied into the KST folder");
                ok = false; continue;
            }
            if (S_ISDIR(st.st_mode)) { if (!visit(child, depth + 1)) return false; continue; }
            if (!S_ISREG(st.st_mode)) continue;
            if (out.resources.size() >= kMaximumResources) {
                add(out, KstSeverity::Blocking, "TOO_MANY_FILES", child, "KST contains more than 50000 files");
                ok = false; return false;
            }
            KstResourceEntry item;
            item.kind = classify(child); item.relativePath = child;
            item.sizeBytes = st.st_size > 0 ? static_cast<std::uint64_t>(st.st_size) : 0;
            item.readable = ::access(full.c_str(), R_OK) == 0;
            ++out.counts[static_cast<std::size_t>(item.kind)];
            if (item.sizeBytes > std::numeric_limits<std::uint64_t>::max() - out.totalBytes) {
                add(out, KstSeverity::Blocking, "SIZE_OVERFLOW", child, "KST file size exceeds index capacity");
                ok = false; return false;
            }
            out.totalBytes += item.sizeBytes;
            if (!item.readable || (item.sizeBytes == 0 && item.kind != KstResourceKind::Other)) {
                add(out, KstSeverity::Blocking, "RESOURCE_UNREADABLE", child, "Resource is empty or cannot be read");
                ok = false;
            }
            out.resources.push_back(std::move(item));
            if (progress) progress({static_cast<std::uint64_t>(out.resources.size()), 0, "Finding resources", child});
        }
        return true;
    }
};
using Address = std::tuple<int, int, int>;
struct Sound { std::string path, name; };
} // namespace

const char* kstResourceKindName(KstResourceKind kind) noexcept {
    static const char* names[] = {"STYLE", "SOUND", "MULTISMP", "PCM", "KEYBOARDSET", "PAD", "SONGBOOK", "OTHER"};
    const auto n = static_cast<std::size_t>(kind);
    return n < static_cast<std::size_t>(KstResourceKind::Count) ? names[n] : "UNKNOWN";
}

bool canSelectPa5xKstDirectory(const std::string& directory) {
    std::unique_ptr<char, decltype(&std::free)> real(::realpath(directory.c_str(), nullptr), &std::free);
    if (!real) return false;
    const std::string root = real.get();
    struct stat st{};
    if (::stat(root.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) return false;
    if (extension(root) == ".kst") return true;
    std::unique_ptr<DIR, int(*)(DIR*)> dir(::opendir(root.c_str()), ::closedir);
    if (!dir) return false;
    const bool namedSet = extension(root) == ".set";
    unsigned style = 0, sound = 0, keyboard = 0;
    while (const dirent* entry = ::readdir(dir.get())) {
        const std::string name = entry->d_name;
        const auto canonical = lower(name);
        const bool coreFolder = canonical == "style" || canonical == "sound" || canonical == "keyboardset";
        if (!coreFolder && canonical != "pcm" && canonical != "multismp" &&
            canonical != "perform" && canonical != "pad") continue;
        const std::string child = root + "/" + name;
        if (::lstat(child.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) continue;
        if (namedSet) return true;
        if (canonical == "style" || canonical == "perform" || canonical == "keyboardset") {
            std::unique_ptr<DIR, int(*)(DIR*)> banks(::opendir(child.c_str()), ::closedir);
            if (banks) while (const dirent* file = ::readdir(banks.get())) {
                const std::string bank = file->d_name;
                if (bank.empty() || bank.front() == '.') continue;
                const auto kind = classify(name + "/" + bank);
                if ((kind == KstResourceKind::Style || kind == KstResourceKind::KeyboardSet) &&
                    ::lstat((child + "/" + bank).c_str(), &st) == 0 && S_ISREG(st.st_mode)) return true;
            }
        }
        if (!coreFolder) continue;
        if (canonical == "style") ++style;
        else if (canonical == "sound") ++sound;
        else ++keyboard;
    }
    return sound == 1 && (style == 1 || keyboard == 1);
}

Pa5xKstIndex indexPa5xKst(const std::string& directory,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel,
    bool deferSampleResources) {
    Pa5xKstIndex out;
    out.sampleResourcesDeferred=deferSampleResources;
    if(deferSampleResources)out.metadataReadCache=std::make_shared<Pa5xKstMetadataCache>();
    std::unique_ptr<char, decltype(&std::free)> real(::realpath(directory.c_str(), nullptr), &std::free);
    if (!real) {
        add(out, KstSeverity::Blocking, "KST_UNREADABLE", directory, "Cannot open selected KST folder");
        return out;
    }
    out.rootPath = real.get();
    const auto slash = out.rootPath.find_last_of('/');
    out.name = out.rootPath.substr(slash == std::string::npos ? 0 : slash + 1);
    struct stat st{};
    if (::stat(out.rootPath.c_str(), &st) != 0 || !S_ISDIR(st.st_mode) || !canSelectPa5xKstDirectory(out.rootPath)) {
        add(out, KstSeverity::Blocking, "SELECT_KST_FOLDER", out.name, "Choose the Pa .SET or .KST folder containing the resource folders");
        return out;
    }
    out.recognized = true;
    Walk walk{out, progress, cancel};
    (void)walk.visit({}, 0);
    if (out.cancelled) return out;
    bool valid = walk.ok;
    if (out.resources.empty()) {
        add(out, KstSeverity::Blocking, "EMPTY_KST", {}, "The KST folder contains no resources");
        return out;
    }
    std::uint64_t knownResources = 0;
    for (std::size_t i = 0; i < static_cast<std::size_t>(KstResourceKind::Other); ++i)
        knownResources += out.counts[i];
    if (knownResources == 0) {
        add(out, KstSeverity::Blocking, "NO_PA5X_RESOURCES", {}, "No supported resources were found in the Pa SET folders");
        valid = false;
    }
    std::map<Address, std::vector<Sound>> sounds;
    bool undecodedUserBank = false;
    std::set<std::string> styleReasons, performanceReasons;
    const auto total = static_cast<std::uint64_t>(out.resources.size());
    for (std::size_t i = 0; i < out.resources.size(); ++i) {
        if (cancelled(cancel)) { out.cancelled = true; return out; }
        auto& item = out.resources[i];
        // The directory walker has already collected path, size and access.
        // The bank stage will read each PCM/KMP payload once and retain its
        // inspection for catalog construction and actual sample preparation.
        if(deferSampleResources&&(item.kind==KstResourceKind::Multisample||item.kind==KstResourceKind::Sample))continue;
        if (progress) progress({static_cast<std::uint64_t>(i), total, "Checking resources", item.relativePath});
        if (!item.readable || item.sizeBytes == 0) {
            if (item.kind == KstResourceKind::Sound) undecodedUserBank = true;
            continue;
        }
        const std::string full = out.rootPath + "/" + item.relativePath;
        try {
            if (item.kind == KstResourceKind::Style) {
                const auto revision=out.metadataReadCache?kstMetadataRevision(full):KstMetadataRevision{};
                if(paStyleBankPath(full)){
                    std::vector<Pa5xKstMetadataCache::LegacySlot> rows;
                    std::string error;
                    item.indexed=inspectPaStyleBank(full,[&](int slot,const std::string& name,const Pa5xStyleRead& read){
                        if(cancelled(cancel))return false;
                        auto m=kstReadStyleMetadata(read);m.name=name;
                        if(read.nativeStyle&&!m.loadable&&std::none_of(read.nativeStyle->sections.begin(),read.nativeStyle->sections.end(),[](const auto& section){return section.available;}))
                            m.error="Empty Style slot: no MIDI phrases";
                        if(!m.loadable){valid=false;add(out,KstSeverity::Warning,"PA_STYLE_SLOT",item.relativePath,name+": "+m.error);}
                        const auto location=item.relativePath+"!/"+std::to_string(slot);
                        for(std::size_t e=0;e<read.sections.size();++e){
                            const auto& section=read.sections[e];if(!section.available)continue;
                            for(std::size_t t=0;t<section.tracks.size();++t){
                                const auto& track=section.tracks[t];if(!track.present)continue;
                                for(const auto& sound:track.setupSoundChanges){
                                    KstSoundReference ref;ref.stylePath=location;ref.element=elementName(static_cast<Element>(e));
                                    ref.track=kTrackLabels[t];ref.msb=sound.msb;ref.lsb=sound.lsb;ref.program=sound.program;
                                    out.soundReferences.push_back(std::move(ref));
                                }
                            }
                        }
                        rows.push_back({slot,std::move(m)});
                        return true;
                    },error);
                    if(cancelled(cancel)){out.cancelled=true;return out;}
                    if(!item.indexed){valid=false;add(out,KstSeverity::Blocking,"PA_STYLE_BANK",item.relativePath,error);}
                    if(item.indexed&&out.metadataReadCache&&sameKstMetadataRevision(revision,kstMetadataRevision(full)))
                        out.metadataReadCache->legacy.emplace(full,std::make_pair(revision,std::move(rows)));
                    continue;
                }
                if(kstMidiStyle(full)){
                    const auto imported=importMidiFile(full);
                    auto metadata=kstImportedStyleMetadata(imported);
                    item.indexed=metadata.loadable;
                    if(!item.indexed){
                        add(out,KstSeverity::Blocking,"STYLE_UNSUPPORTED",item.relativePath,metadata.error);
                        valid=false;
                    }
                    if(out.metadataReadCache&&sameKstMetadataRevision(revision,kstMetadataRevision(full)))
                        out.metadataReadCache->retainStyle(full,revision,std::move(metadata));
                    continue;
                }
                const auto style = inspectKorgStyleFile(full);
                if(out.metadataReadCache&&sameKstMetadataRevision(revision,kstMetadataRevision(full)))
                    out.metadataReadCache->retainStyle(full,revision,kstCatalogStyleMetadata(style));
                if (!style.valid) {
                    add(out, KstSeverity::Blocking, "STYLE_UNSUPPORTED", item.relativePath, style.error);
                    valid = false; continue;
                }
                item.indexed = true;
                for (const auto& reason : style.playbackBlockers) styleReasons.insert(reason);
                std::set<std::tuple<int,int,int,int,int>> seen;
                for (const auto& element : style.elements) for (const auto& clip : element.clips) {
                    for (const auto& patch : clip.patches) {
                        const auto key = std::make_tuple(static_cast<int>(element.element), clip.track,
                            static_cast<int>(patch.msb), static_cast<int>(patch.lsb), static_cast<int>(patch.program));
                        if (!seen.insert(key).second) continue;
                        KstSoundReference ref;
                        ref.stylePath = item.relativePath; ref.element = elementName(element.element);
                        ref.track = clip.track >= 0 && clip.track < 8 ? kTrackLabels[clip.track] : "Unknown track";
                        ref.msb = patch.msb; ref.lsb = patch.lsb; ref.program = patch.program;
                        out.soundReferences.push_back(std::move(ref));
                    }
                }
            } else if (item.kind == KstResourceKind::Sound) {
                Pa5xPcgInspection pcg;
                if(out.metadataReadCache){
                    std::vector<std::uint8_t> bytes;KstMetadataRevision revision;std::string error;
                    if(readKstMetadataBytes(full,bytes,revision,error)){
                        pcg=inspectPa5xPcgBytes(bytes,full);
                        out.metadataReadCache->retainPcg(full,revision,std::move(bytes),pcg);
                    }else pcg.error=std::move(error);
                }else pcg=inspectPa5xPcgFile(full);
                if (!pcg.valid) {
                    add(out, KstSeverity::Blocking, "SOUND_BANK_UNSUPPORTED", item.relativePath, pcg.error);
                    undecodedUserBank = true; valid = false; continue;
                }
                item.indexed = true; out.indexedSounds += pcg.sounds.size();
                for (const auto& sound : pcg.sounds) {
                    if (sound.addressKnown)
                        sounds[{sound.msb, sound.lsb, sound.rawProgram}].push_back({item.relativePath, sound.name});
                    else {
                        undecodedUserBank = true;
                        add(out, KstSeverity::Blocking, "BANK_ADDRESS_UNSUPPORTED", item.relativePath,
                            "Sound bank address is not decoded: " + sound.name);
                    }
                }
                if (!pcg.sounds.empty()) add(out, KstSeverity::Blocking, "SOUND_PARAMETERS_UNSUPPORTED", item.relativePath,
                    "Sound names and positions are indexed; oscillator, sample and effect settings still need decoding");
            } else if (item.kind == KstResourceKind::Multisample || item.kind == KstResourceKind::Sample) {
                const auto sample = inspectPa5xSampleFile(full);
                if (!sample.valid) {
                    add(out, KstSeverity::Blocking, "SAMPLE_CONTAINER_UNSUPPORTED", item.relativePath, sample.error);
                    valid = false; continue;
                }
                const auto expected = item.kind == KstResourceKind::Sample
                    ? Pa5xSampleContainerKind::PcmSamples : Pa5xSampleContainerKind::Multisamples;
                if (sample.kind != expected) {
                    add(out, KstSeverity::Blocking, "SAMPLE_CONTAINER_KIND_MISMATCH", item.relativePath,
                        "The file contents do not match this KST resource category");
                    valid = false; continue;
                }
                item.indexed = true;
                if (item.kind == KstResourceKind::Sample) out.indexedSamples += sample.objects.size();
                else out.indexedMultisamples += sample.multisamples.size();
                for (const auto& why : sample.blockers)
                    add(out, KstSeverity::Blocking, "SAMPLE_DECODE_REQUIRED", item.relativePath, why);
                if (item.kind == KstResourceKind::Multisample && !sample.multisampleMappingDecoded)
                    add(out, KstSeverity::Blocking, "SAMPLE_MAP_UNSUPPORTED", item.relativePath, "Key ranges and sample references need decoding");
                if (item.kind == KstResourceKind::Sample && !sample.waveformDecoded)
                    add(out, KstSeverity::Blocking, "AUDIO_DECODE_UNSUPPORTED", item.relativePath, "Sample audio is not ready for playback");
            } else if (item.kind == KstResourceKind::KeyboardSet || item.kind == KstResourceKind::Pad) {
                const auto revision=out.metadataReadCache?kstMetadataRevision(full):KstMetadataRevision{};
                if(item.kind==KstResourceKind::Pad&&extension(full)==".pad"){
                    std::string error;std::size_t supported=0,totalPads=0;
                    item.indexed=inspectPaPadBank(full,[&](const std::string& name,bool decoded){
                        ++totalPads;
                        if(decoded)++supported;
                        else add(out,KstSeverity::Warning,"PA_PAD_UNSUPPORTED",item.relativePath,name);
                        return !cancelled(cancel);
                    },error);
                    if(cancelled(cancel)){out.cancelled=true;return out;}
                    out.indexedPads+=supported;
                    add(out,KstSeverity::Blocking,"LEGACY_PA_BANK",item.relativePath,item.indexed?
                        std::to_string(supported)+"/"+std::to_string(totalPads)+" native Pads decoded; independent Pad playback unavailable":error);
                    valid=false;continue;
                }
                if(paPerformanceBankPath(full)){
                    std::string error;
                    item.indexed=inspectPaPerformanceBank(full,[&](int,const Pa5xPerformanceInspection& k){
                        if(cancelled(cancel))return false;
                        if(k.valid){
                            ++out.indexedKeyboardSets;
                            for(const auto& part:k.parts)for(const auto& patch:part.patches){
                                KstSoundReference ref;ref.resourceKind=item.kind;ref.stylePath=item.relativePath+"!/"+std::to_string(k.filenameOrdinal-1);
                                ref.element="Keyboard Set";ref.track=part.name;ref.msb=patch.msb;ref.lsb=patch.lsb;ref.program=patch.program;
                                out.soundReferences.push_back(std::move(ref));
                            }
                        }
                        else add(out,KstSeverity::Warning,"PA_KEYBOARD_SET",item.relativePath,k.displayName+": "+k.error);
                        return true;
                    },error);
                    if(cancelled(cancel)){out.cancelled=true;return out;}
                    if(!item.indexed){valid=false;add(out,KstSeverity::Blocking,"PA_PERFORMANCE_BANK",item.relativePath,error);}
                    continue;
                }
                const auto performance = inspectPa5xPerformanceFile(full);
                if(item.kind==KstResourceKind::KeyboardSet&&out.metadataReadCache&&sameKstMetadataRevision(revision,kstMetadataRevision(full)))
                    out.metadataReadCache->retainKeyboard(full,revision,performance);
                const auto expected = item.kind == KstResourceKind::Pad
                    ? Pa5xPerformanceKind::Pad : Pa5xPerformanceKind::KeyboardSet;
                if (!performance.valid) {
                    add(out, KstSeverity::Blocking, "PERFORMANCE_RESOURCE_UNSUPPORTED", item.relativePath, performance.error);
                    valid = false; continue;
                }
                if (performance.kind != expected) {
                    add(out, KstSeverity::Blocking, "PERFORMANCE_RESOURCE_KIND_MISMATCH", item.relativePath,
                        "The file contents do not match this KST resource category");
                    valid = false; continue;
                }
                item.indexed = true;
                if (item.kind == KstResourceKind::KeyboardSet) ++out.indexedKeyboardSets;
                else ++out.indexedPads;
                for (const auto& why : performance.playbackBlockers) performanceReasons.insert(why);
                for (const auto& why : performance.warnings)
                    add(out, KstSeverity::Warning, "PERFORMANCE_METADATA_WARNING", item.relativePath, why);
                std::set<std::tuple<int,int,int,int,int>> seen;
                bool incomplete = false;
                for (const auto& part : performance.parts) for (const auto& patch : part.patches) {
                    if (!patch.addressComplete) { incomplete = true; continue; }
                    const auto key = std::make_tuple(part.track, patch.channel, patch.msb, patch.lsb, patch.program);
                    if (!seen.insert(key).second) continue;
                    KstSoundReference ref;
                    ref.resourceKind = item.kind;
                    ref.stylePath = item.relativePath;
                    ref.element = item.kind == KstResourceKind::Pad ? "Pad" : "Keyboard Set";
                    ref.track = part.name.empty() ? "Part " + std::to_string(part.track) : part.name;
                    ref.msb = patch.msb; ref.lsb = patch.lsb; ref.program = patch.program;
                    out.soundReferences.push_back(std::move(ref));
                }
                if (incomplete) add(out, KstSeverity::Blocking, "PERFORMANCE_SOUND_ADDRESS_INCOMPLETE", item.relativePath,
                    "Some MIDI patch selections do not supply a complete bank/program address");
            } else if (item.kind == KstResourceKind::Other) {
                const auto folder = lower(item.relativePath.substr(0, item.relativePath.find('/')));
                const auto suffix = extension(item.relativePath);
                if (((folder == "perform" || folder == "keyboardset") && suffix == ".prf") || (folder == "pad" && suffix == ".pad")) {
                    add(out, KstSeverity::Blocking, "LEGACY_PA_BANK", item.relativePath,
                        "Legacy Performance or Pad bank: direct playback of this resource is unavailable.");
                    valid = false;
                }
            } else if (item.kind == KstResourceKind::SongBook) {
                add(out, KstSeverity::Blocking, "PERFORMANCE_RESOURCE_UNSUPPORTED", item.relativePath,
                    "SongBook settings are not decoded yet");
            }
        } catch (const std::exception& e) {
            add(out, KstSeverity::Blocking, "RESOURCE_READ_FAILED", item.relativePath, e.what());
            if (item.kind == KstResourceKind::Sound) undecodedUserBank = true;
            valid = false;
        }
    }
    for (auto& ref : out.soundReferences) {
        if (cancelled(cancel)) { out.cancelled = true; return out; }
        if(ref.msb<0||ref.msb>127||ref.lsb<0||ref.lsb>127||ref.program<0||ref.program>127){
            ref.resolution=KstResolution::UnsupportedSoundAddress;
            add(out,KstSeverity::Blocking,"SOUND_ADDRESS_INCOMPLETE",ref.stylePath,
                "The original Sound address has undeclared or invalid MIDI fields");
            continue;
        }
        const auto found = sounds.find({ref.msb, ref.lsb, ref.program});
        if (found != sounds.end() && found->second.size() == 1) {
            ref.resolution = KstResolution::ExactUserSound; ref.soundPath = found->second[0].path;
            ref.soundName = found->second[0].name; ++out.resolvedUserReferences;
        } else if (found != sounds.end()) {
            ref.resolution = KstResolution::AmbiguousSound;
            add(out, KstSeverity::Blocking, "DUPLICATE_SOUND_ADDRESS", ref.stylePath,
                "More than one Sound uses address " + std::to_string(ref.msb) + "/" + std::to_string(ref.lsb) + "/" + std::to_string(ref.program));
        } else if (const auto* factory = findPa5xFactorySound(ref.msb,ref.lsb,ref.program)) {
            ref.resolution = KstResolution::FactorySoundRequired;
            ref.soundName = factory->name; ++out.factoryReferences;
        } else if ((ref.msb == 120 || ref.msb == 121) && ref.lsb >= 64) {
            if (undecodedUserBank) ref.resolution = KstResolution::UnsupportedSoundAddress;
            else { ref.resolution = KstResolution::MissingUserSound; ++out.missingUserReferences; }
        } else if ((ref.msb == 120 || ref.msb == 121) && ref.lsb >= 0 && ref.lsb < 64) {
            ref.resolution = KstResolution::FactorySoundRequired; ++out.factoryReferences;
        } else {
            ref.resolution = KstResolution::UnsupportedSoundAddress;
            add(out, KstSeverity::Blocking, "SOUND_ADDRESS_UNSUPPORTED", ref.stylePath,
                "The required Sound bank needs an address catalog");
        }
    }
    if (undecodedUserBank) add(out, KstSeverity::Blocking, "USER_BANK_INDEX_INCOMPLETE", {},
        "Some User banks cannot be indexed yet. Unresolved links may exist in those banks and are not marked missing");
    if (out.missingUserReferences) add(out, KstSeverity::Blocking, "USER_SOUNDS_MISSING", {},
        std::to_string(out.missingUserReferences) + " Sound references were not found in the decoded User banks");
    if (out.factoryReferences) add(out, KstSeverity::Blocking, "FACTORY_SOUNDS_REQUIRED", {},
        std::to_string(out.factoryReferences) + " Sound references require the Factory sound catalog");
    for (const auto& reason : styleReasons) add(out, KstSeverity::Blocking, "STYLE_PLAYBACK_UNSUPPORTED", {}, reason);
    for (const auto& reason : performanceReasons) add(out, KstSeverity::Blocking, "PERFORMANCE_PLAYBACK_UNSUPPORTED", {}, reason);
    if(deferSampleResources)add(out,KstSeverity::Info,"SAMPLE_RESOURCES_DEFERRED",{},
        "PCM/KMP files were discovered; payload inspection is deferred to the shared bank loader");
    add(out, KstSeverity::Info, "CURRENT_PERFORMANCE_PRESERVED", {}, "The current performance has not changed");
    add(out, KstSeverity::Blocking, "EXACT_KST_PLAYBACK_UNAVAILABLE", {},
        "KST checked. Exact Korg playback is not available until every required Sound, sample and Style rule is supported");
    out.structurallyValid = valid;
    out.playable = false;
    if (progress) progress({total, total, "KST checked", {}});
    return out;
}

std::string pa5xKstSummary(const Pa5xKstIndex& index) {
    std::ostringstream text;
    if (index.cancelled) { text << "KST check cancelled"; return text.str(); }
    text << index.name << '\n';
    for (std::size_t i = 0; i < index.counts.size(); ++i)
        text << kstResourceKindName(static_cast<KstResourceKind>(i)) << ": " << index.counts[i] << '\n';
    text << "Sound entries: " << index.indexedSounds << "\nSample entries: " << index.indexedSamples
         << "\nKeyboard Sets indexed: " << index.indexedKeyboardSets << "\nPads indexed: " << index.indexedPads
         << "\nExact User Sound references: " << index.resolvedUserReferences
         << "\nUnresolved User references: " << index.missingUserReferences
         << "\nFactory references: " << index.factoryReferences
         << "\nPlayback unavailable; current performance preserved.";
    if(index.sampleResourcesDeferred)text << "\nSample payload inspection is deferred to the shared bank loader.";
    return text.str();
}
} // namespace silveton::arranger
