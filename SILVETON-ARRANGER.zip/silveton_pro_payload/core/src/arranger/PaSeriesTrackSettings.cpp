#include "silveton/arranger/PaSeriesTrackSettings.h"

namespace silveton::arranger {

PaSeriesTrackSettings readPaSeriesTrackSettings(std::uint32_t tag,
        const std::uint8_t* bytes,std::size_t size) {
    PaSeriesTrackSettings out;out.tag=tag;
    out.recognized=tag==0x09000008U||tag==0x09010008U||tag==0x09010108U;
    if(size>kMaximumPaSeriesTrackRecordBytes||(!bytes&&size!=0U)) {
        out.error="Native Pa mixer-part record exceeds its bounded storage or has no data";
        return out;
    }
    if(size)out.originalRecord.assign(bytes,bytes+size);
    if(!out.recognized) {
        out.error="Unsupported native Pa mixer-part version; original bytes retained";
        return out;
    }
    // Format facts corroborated by KORG-Tools' independent versioned reader,
    // writer and TrackSettings struct (31c8fa6), and Korg's unprotected Styles
    // vol.18/35: 242-byte common layout; v1.0/1.1 append two 70-byte IFX blocks.
    // No implementation from that project is included here.
    const std::size_t expected=tag==0x09000008U?242U:382U;
    if(size!=expected) {
        out.error="Native Pa mixer-part size does not match its declared version";
        return out;
    }
    out.trackIndex=(std::uint32_t(bytes[0])<<24U)|(std::uint32_t(bytes[1])<<16U)|
        (std::uint32_t(bytes[2])<<8U)|bytes[3];
    // The common layout has a mandatory zero word between the two MFX sends
    // and the raw Dry byte. Reject a conflicting layout rather than shifting
    // offsets or interpreting unknown bytes as user settings.
    if(bytes[33]!=0U||bytes[34]!=0U) {
        out.error="Native Pa mixer-part reserved word is not recognized";
        return out;
    }
    out.structurallyValid=true;
    if(bytes[18]<=127U) {
        out.detuneKnown=true;out.detuneCents=static_cast<int>(bytes[18])-64;
    }
    const int transpose=bytes[19]<128U?bytes[19]:static_cast<int>(bytes[19])-256;
    if(transpose>=-36&&transpose<=36&&transpose%12==0) {
        out.octaveTransposeKnown=true;out.octaveTranspose=transpose/12;
    }
    for(std::size_t i=0;i<2U;++i)
        if(bytes[31U+i]<=127U)out.masterFxSendRaw[i]=bytes[31U+i];
    if(bytes[35]<=1U)out.dryRaw=bytes[35];
    if(bytes[40]<=12U)out.pitchBendRangeSemitones=bytes[40];
    // Pa4X User Manual: Tuning p172, EQ p169, Pitch Bend p814. The native
    // field uses two units per dB; retain the integer to avoid unit ambiguity.
    for(std::size_t i=0;i<3U;++i) {
        const int raw=bytes[43U+i]<128U?bytes[43U+i]:static_cast<int>(bytes[43U+i])-256;
        if(raw>=-36&&raw<=36) {
            out.eqGainKnownMask|=static_cast<std::uint8_t>(1U<<i);
            out.eqGainHalfDb[i]=raw;
        }
    }
    return out;
}

} // namespace silveton::arranger
