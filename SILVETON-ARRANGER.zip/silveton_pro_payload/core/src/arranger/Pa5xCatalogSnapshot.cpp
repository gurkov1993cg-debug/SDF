#include "silveton/arranger/Pa5xCatalogSnapshot.h"
#include "Pa5xSnapshotArchive.h"
#include "silveton/arranger/PaSeriesTrackSettings.h"

#include <utility>

namespace silveton::arranger {

void archiveFields(snapshot::Archive& a, KstResourceEntry& v) {
    a(v.kind,v.relativePath,v.sizeBytes,v.readable,v.indexed);
}
void archiveFields(snapshot::Archive& a, KstSoundReference& v) {
    a(v.resourceKind,v.stylePath,v.element,v.track,v.msb,v.lsb,v.program,
      v.resolution,v.soundPath,v.soundName);
}
void archiveFields(snapshot::Archive& a, KstDiagnostic& v) {
    a(v.severity,v.code,v.relativePath,v.message);
}
void archiveFields(snapshot::Archive& a, Pa5xKstIndex& v) {
    a(v.rootPath,v.name,v.recognized,v.structurallyValid,v.playable,v.cancelled,
      v.sampleResourcesDeferred,v.totalBytes,v.counts,v.resources,
      v.soundReferences,v.diagnostics,v.indexedSounds,v.indexedMultisamples,
      v.indexedSamples,v.indexedKeyboardSets,v.indexedPads,
      v.resolvedUserReferences,v.missingUserReferences,v.factoryReferences);
}
void archiveFields(snapshot::Archive& a, Pa5xCatalogStyle& v) {
    // Keep the CAT1 base layout intact. CAT2 stores bounded original track
    // settings in a separate, path-bound appendix after the complete catalog.
    a(v.name,v.path,v.relativePath,v.categoryPath,v.bankName,v.fileName,
      v.metadataFileName,v.iconName,v.positionOrdinal,v.positionSlot,v.bpm,
      v.numerator,v.denominator,v.loadable,v.error,v.warnings);
}
void archiveFields(snapshot::Archive& a, Pa5xCatalogStyleGroup& v) {
    a(v.name,v.relativePath,v.parentPath,v.depth,v.descendantStyleCount,
      v.metadataOrderUsed,v.styleIndices,v.childGroups,v.slotStyleIndices,
      v.missingSlotFiles,v.missingMetadataFiles);
}
void archiveFields(snapshot::Archive& a, Pa5xCatalogSound& v) {
    a(v.name,v.path,v.relativePath,v.msb,v.lsb,v.program,v.internalBank,
      v.rawProgram,v.resourceVersion,v.addressKnown,v.drumKit,v.graphSupported,
      v.playable,v.oscillatorCount,v.blocker);
}
void archiveFields(snapshot::Archive& a, Pa5xPerformanceCv& v) {
    a(v.number,v.root,v.chord);
}
void archiveFields(snapshot::Archive& a, Pa5xPerformanceChordSelection& v) {
    a(v.chord,v.cv);
}
void archiveFields(snapshot::Archive& a, Pa5xPerformancePart& v) {
    a(v.track,v.name,v.resourcePath,v.present,v.mute,v.keyLow,v.keyHigh,
      v.velocityLow,v.velocityHigh,v.trackRoute,v.actuatorRaw,v.controllersRaw,
      v.transpositionRaw,v.transpositionDeclared,v.ppq,v.midiSpanTicks,
      v.midiEventCount,v.hasNoteEvents,v.patches,v.channels,v.channelEvents,
      v.patternType,v.ntt,v.ntr,v.retrigger,v.wrapAroundDegree,v.loopNumberRaw,
      v.loopLengthRaw,v.loopDeclared,v.cvSources,v.chordSelections);
}
void archiveFields(snapshot::Archive& a, Pa5xCatalogKeyboardSet& v) {
    a(v.name,v.path,v.relativePath,v.ordinal,v.splitPoint,v.useGlobalSplit,
      v.upperOctaveTransposeRaw,v.chordScanningRaw,v.keyboardModeRaw,
      v.metadataSupported,v.playable,v.parts,v.blocker);
}
void archiveFields(snapshot::Archive& a, Pa5xCatalogSample& v) {
    a(v.name,v.pcmPath,v.kmpPath,v.relativePath,v.resourceId,v.rate,v.frames,
      v.root,v.previewable,v.blocker);
}
void archiveFields(snapshot::Archive& a, Pa5xKstCatalog& v) {
    a(v.rootPath,v.name,v.error,v.recognized,v.cancelled,v.discoveredStyleFiles,
      v.unavailableStyles,v.styleListComplete,v.styles,v.styleGroups,v.sounds,
      v.keyboardSets,v.samples,v.warnings);
}

namespace {
constexpr const char* catalogMagic="SILVCAT3";
constexpr const char* previousCatalogMagic="SILVCAT2";
constexpr const char* oldestCatalogMagic="SILVCAT1";

void sourceText(snapshot::Archive& a,std::string& value,std::size_t maximum) {
    if(!a.reading()&&value.size()>maximum)throw std::runtime_error("Style source text exceeds its limit");
    std::uint64_t size=value.size();a(size);
    if(size>maximum||(a.reading()&&size>a.remaining()))throw std::runtime_error("Invalid Style source text");
    if(a.reading())value.resize(static_cast<std::size_t>(size));
    for(auto& c:value)a(c);
}

void sourceTrack(snapshot::Archive& a,Pa5xStyleSourceTrack& value) {
    a(value.element,value.track);
    sourceText(a,value.declaredType,kPa5xStyleSourceMaximumTypeBytes);
    auto mode=static_cast<std::uint8_t>(value.nativeMode);
    std::uint8_t flags=static_cast<std::uint8_t>((value.available?1U:0U)|(value.capoKnown?2U:0U)|
        (value.humanizeKnown?4U:0U)|(value.keyRangeKnown?8U:0U)|(value.keyRangeEnabled?16U:0U));
    a(mode,flags);
    if(mode>static_cast<std::uint8_t>(NativePatternMode::Guitar)||(flags&~31U)!=0)
        throw std::runtime_error("Invalid Style source track flags");
    if(a.reading()){
        value.nativeMode=static_cast<NativePatternMode>(mode);value.available=(flags&1U)!=0;
        value.capoKnown=(flags&2U)!=0;value.humanizeKnown=(flags&4U)!=0;
        value.keyRangeKnown=(flags&8U)!=0;value.keyRangeEnabled=(flags&16U)!=0;
    }
    a(value.capo,value.humanize,value.stringHighRaw,value.stringLowRaw,value.nttRaw,value.ntrRaw,
      value.retriggerRaw,value.keyLow,value.keyHigh,value.wrapRaw,value.noiseOffsetRaw,value.tensionRaw);
    if(!a.reading()&&value.sounds.size()>kPa5xStyleSourceMaximumSounds)
        throw std::runtime_error("Style source Sound count exceeds its limit");
    std::uint32_t count=static_cast<std::uint32_t>(value.sounds.size());a(count);
    if(count>kPa5xStyleSourceMaximumSounds)throw std::runtime_error("Invalid Style source Sound count");
    if(a.reading())value.sounds.resize(count);
    for(auto& sound:value.sounds){
        std::uint8_t varies=sound.varies?1U:0U;
        a(sound.cv,sound.channel,sound.msb,sound.lsb,sound.program,varies);
        if(varies>1U)throw std::runtime_error("Invalid Style source Sound flag");
        if(a.reading())sound.varies=varies!=0;
    }
}

void sourceSettings(snapshot::Archive& a,Pa5xStyleSourceSettings& value) {
    std::uint8_t flags=static_cast<std::uint8_t>((value.indexed?1U:0U)|(value.readable?2U:0U));
    a(flags,value.muteKnownMask,value.muteMask);
    if((flags&~3U)!=0)throw std::runtime_error("Invalid Style source settings flags");
    if(a.reading()){value.indexed=(flags&1U)!=0;value.readable=(flags&2U)!=0;}
    sourceText(a,value.error,kPa5xStyleSourceMaximumErrorBytes);
    if(!a.reading()&&value.tracks.size()>kPa5xStyleSourceMaximumTracks)
        throw std::runtime_error("Style source track count exceeds its limit");
    std::uint32_t count=static_cast<std::uint32_t>(value.tracks.size());a(count);
    if(count>kPa5xStyleSourceMaximumTracks)throw std::runtime_error("Invalid Style source track count");
    if(a.reading())value.tracks.resize(count);
    for(auto& track:value.tracks)sourceTrack(a,track);
    if(!value.indexed||!value.valid())throw std::runtime_error("Invalid original Style source settings");
}

void sourceSettingsAppendix(snapshot::Archive& a,Pa5xKstCatalog& catalog) {
    std::uint32_t version=1;a(version);
    std::uint64_t count=catalog.styles.size();a(count);
    if(version!=1||count!=catalog.styles.size())throw std::runtime_error("Invalid Style source settings appendix");
    for(auto& style:catalog.styles){
        std::string path=style.path;sourceText(a,path,style.path.size());
        if(path!=style.path)throw std::runtime_error("Style source settings identity mismatch");
        sourceSettings(a,style.originalSettings);
    }
}

// CAT1/CAT2 base fields remain byte-compatible. Store unchanged native
// records in a bounded identity-bound appendix; revalidate derived values
// through the same reader used for an original PRF/STS on every restore.
void nativeKeyboardAppendix(snapshot::Archive& a,Pa5xKstCatalog& catalog) {
    std::uint32_t version=1U;a(version);
    std::uint64_t count=catalog.keyboardSets.size();a(count);
    if(version!=1U||count!=catalog.keyboardSets.size())
        throw std::runtime_error("Invalid native Keyboard Set appendix");
    for(auto& keyboard:catalog.keyboardSets){
        std::string path=keyboard.path;sourceText(a,path,keyboard.path.size());
        if(path!=keyboard.path)throw std::runtime_error("Native Keyboard Set identity mismatch");
        std::uint64_t parts=keyboard.parts.size();a(parts);
        if(parts!=keyboard.parts.size())throw std::runtime_error("Native Keyboard Set part count mismatch");
        for(auto& part:keyboard.parts){
            int role=part.track;a(role);
            if(role!=part.track)throw std::runtime_error("Native Keyboard Set part role mismatch");
            std::uint8_t present=part.sourceNativeTrack?1U:0U;a(present);
            if(present>1U)throw std::runtime_error("Invalid native Keyboard Set presence flag");
            if(!present){if(a.reading())part.sourceNativeTrack.reset();continue;}
            if(!a.reading()&&part.sourceNativeTrack->originalRecord.size()>kMaximumPaSeriesTrackRecordBytes)
                throw std::runtime_error("Native Keyboard Set record exceeds its limit");
            std::uint32_t tag=a.reading()?0U:part.sourceNativeTrack->tag;
            std::vector<std::uint8_t> bytes=a.reading()?std::vector<std::uint8_t>{}:part.sourceNativeTrack->originalRecord;
            std::uint32_t size=static_cast<std::uint32_t>(bytes.size());a(tag,size);
            if(size>kMaximumPaSeriesTrackRecordBytes||(a.reading()&&size>a.remaining()))
                throw std::runtime_error("Invalid native Keyboard Set record size");
            if(a.reading())bytes.resize(size);
            for(auto& byte:bytes)a(byte);
            auto decoded=readPaSeriesTrackSettings(tag,bytes.data(),bytes.size());
            if(decoded.structurallyValid&&(part.track<1||part.track>4||decoded.trackIndex+1U!=static_cast<unsigned>(part.track)))
                throw std::runtime_error("Native Keyboard Set body role mismatch");
            if(a.reading())part.sourceNativeTrack=std::make_shared<PaSeriesTrackSettings>(std::move(decoded));
        }
    }
}

bool usable(const Pa5xKstIndex& index,const Pa5xKstCatalog& catalog) {
    if(!index.recognized||index.cancelled||index.rootPath.empty()||
       !catalog.recognized||catalog.cancelled||catalog.rootPath!=index.rootPath)
        return false;
    for(const auto& group:catalog.styleGroups) {
        for(const auto i:group.styleIndices)if(i>=catalog.styles.size())return false;
        for(const auto i:group.childGroups)if(i>=catalog.styleGroups.size())return false;
        for(const auto i:group.slotStyleIndices)
            if(i < -1 || (i >= 0 && static_cast<std::size_t>(i)>=catalog.styles.size()))return false;
        for(const auto& missing:group.missingSlotFiles)
            if(missing.first>=group.slotStyleIndices.size())return false;
    }
    return true;
}
}

bool savePa5xCatalogSnapshot(const std::string& path,
        const Pa5xKstIndex& index,const Pa5xKstCatalog& catalog) {
    try {
        if(!usable(index,catalog))return false;
        auto savedIndex=index;
        auto savedCatalog=catalog;
        snapshot::Archive a;
        a(savedIndex,savedCatalog);
        sourceSettingsAppendix(a,savedCatalog);
        nativeKeyboardAppendix(a,savedCatalog);
        return a.writeFile(path,catalogMagic);
    }catch(...) {return false;}
}

bool loadPa5xCatalogSnapshot(const std::string& path,
        Pa5xKstIndex& index,Pa5xKstCatalog& catalog,bool* needsStyleMetadataUpgrade,bool* needsNativeTrackUpgrade) {
    if(needsStyleMetadataUpgrade)*needsStyleMetadataUpgrade=false;
    if(needsNativeTrackUpgrade)*needsNativeTrackUpgrade=false;
    try {
        snapshot::Archive a;unsigned version=3U;
        try{a=snapshot::Archive::readFile(path,catalogMagic);}
        catch(...){
            try{a=snapshot::Archive::readFile(path,previousCatalogMagic);version=2U;}
            catch(...){a=snapshot::Archive::readFile(path,oldestCatalogMagic);version=1U;}
        }
        Pa5xKstIndex loadedIndex;
        Pa5xKstCatalog loadedCatalog;
        a(loadedIndex,loadedCatalog);
        if(!usable(loadedIndex,loadedCatalog))return false;
        bool needsRefresh=version==1U;
        if(version==1U)a.finish();
        else if(version==3U){
            // A malformed current appendix is not silently accepted with
            // missing Sound settings. Rebuild metadata; PCM remains cached.
            sourceSettingsAppendix(a,loadedCatalog);
            nativeKeyboardAppendix(a,loadedCatalog);a.finish();
        }else {
            // The envelope/checksum and full base catalog are already valid.
            // A bad optional appendix must not discard a reusable sample
            // graph. Drop every summary before asking for a Style-only read.
            try{sourceSettingsAppendix(a,loadedCatalog);a.finish();}
            catch(const std::runtime_error&){
                for(auto& style:loadedCatalog.styles)style.originalSettings={};
                needsRefresh=true;
            }
        }
        index=std::move(loadedIndex);
        catalog=std::move(loadedCatalog);
        if(needsStyleMetadataUpgrade)*needsStyleMetadataUpgrade=needsRefresh;
        if(needsNativeTrackUpgrade)*needsNativeTrackUpgrade=version<3U;
        return true;
    }catch(...) {return false;}
}

} // namespace silveton::arranger
