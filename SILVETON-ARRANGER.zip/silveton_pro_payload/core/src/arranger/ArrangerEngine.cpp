#include "silveton/arranger/ArrangerEngine.h"
#include "ChordMemory.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <sstream>
#include <utility>

namespace silveton::arranger {
namespace {
const Style kClearStyle{};
constexpr std::array<const char*,kElementCount> kNames{{"INTRO 1","INTRO 2","INTRO 3","VAR 1","VAR 2","VAR 3","VAR 4","FILL 1","FILL 2","FILL 3","FILL 4","BREAK","ENDING 1","ENDING 2","ENDING 3"}};
constexpr int pc(int n) noexcept { const int p = n % 12; return p < 0 ? p + 12 : p; }
bool variation(Element e) noexcept { return e >= Element::Var1 && e <= Element::Var4; }
bool fill(Element e) noexcept { return e >= Element::Fill1 && e <= Element::Fill4; }
bool ending(Element e) noexcept { return e >= Element::Ending1 && e <= Element::Ending3; }
bool mixController(std::uint8_t controller) noexcept {
    // Pa master sends must catch up when entering a Fill/CV part-way through
    // its measure, and while a track is muted, just like level/expression.
    return controller==7U||controller==10U||controller==11U||
        controller==91U||controller==93U||controller==94U;
}
bool restoreController(std::uint8_t cc) noexcept {
    // Rebuild the ordered controller state when entering a phrase mid-way.
    // Sound edits, AMS inputs and RPN/NRPN data are state, like volume/bank.
    // Do not replay All Sound/Notes Off or channel-mode commands as history.
    return cc<120U||cc==121U;
}
// Replaying controller history at a phase entry must also reconstruct
// sustain state after All Sound/Notes Off, without replaying their kill.
// The style backend treats both as safety releases that clear its pedal.
bool restoreStyleState(MidiEvent& event) noexcept {
    const auto type=event.status&0xf0U;
    if(type==0xb0U&&(event.data1==120U||event.data1==123U)){
        event.data1=64U;event.data2=0U;return true;
    }
    return type==0xc0U||type==0xd0U||type==0xe0U||
           (type==0xb0U&&restoreController(event.data1));
}
bool styleDamperMessage(int type,int cc) noexcept { return type==0xb0 && (cc==64 || cc==121); }
bool sameGuitarFingering(const GuitarPatternSettings& a,const GuitarPatternSettings& b) noexcept {
    return a.capo==b.capo&&a.highString==b.highString&&a.lowString==b.lowString;
}
bool guitarMode(const TrackPattern& pattern,const GuitarOverride& edit) noexcept {
    if(pattern.mode!=NativePatternMode::RecordedSourceOnly&&pattern.mode!=NativePatternMode::Guitar)return false;
    return edit.valid()&&edit.mode>=0?edit.mode==1:pattern.mode==NativePatternMode::Guitar;
}
std::uint32_t guitarRandom(std::uint32_t& state) noexcept {
    if(state==0)state=0x6D2B79F5U;
    state^=state<<13U;state^=state>>17U;state^=state<<5U;return state;
}
double guitarRandomUnit(std::uint32_t& state) noexcept {
    return static_cast<double>(guitarRandom(state)&0xFFFFU)/65535.0;
}
Chord legacyGuitarChord(int key,int velocity) noexcept {
    // Pa4X User Manual, printed pp261-262. This table is NOT the Pa5X
    // progression protocol; callers require a proven legacy .STY track.
    constexpr std::array<ChordType,24> types{{
        ChordType::Major,ChordType::Major6,ChordType::Major7,ChordType::Major7Flat5,
        ChordType::Sus4,ChordType::Sus2,ChordType::Major7Sus4,ChordType::Minor,
        ChordType::Minor6,ChordType::Minor7,ChordType::Minor7Flat5,ChordType::MinorMajor7,
        ChordType::Seventh,ChordType::SeventhFlat5,ChordType::SeventhSus4,ChordType::Diminished,
        ChordType::DiminishedMajor7,ChordType::Augmented,ChordType::Augmented7,ChordType::AugmentedMajor7,
        ChordType::RootFifth,ChordType::RootOctave,ChordType::MajorFlat5,ChordType::Diminished7
    }};
    return key>=0&&key<=11&&velocity>=1&&velocity<=24?Chord{key,types[static_cast<std::size_t>(velocity-1)],key}:Chord{};
}
Chord pa5xGuitarChord(int key,int velocity) noexcept {
    // Pa5X New Features v1.3.0, printed p108: documented base chord
    // velocity codes. Not the Pa4X ordering. Use the actual table (the
    // worked example on p111 has an inconsistent m7 velocity).
    constexpr std::array<ChordType,24> types{{
        ChordType::Major,ChordType::Major7,ChordType::Sus4,ChordType::Major7Sus4,
        ChordType::Minor6,ChordType::Minor7Flat5,ChordType::Seventh,ChordType::SeventhSus4,
        ChordType::DiminishedMajor7,ChordType::Augmented7,ChordType::RootFifth,ChordType::MajorFlat5,
        ChordType::Major6,ChordType::Major7Flat5,ChordType::Sus2,ChordType::Minor,
        ChordType::Minor7,ChordType::MinorMajor7,ChordType::SeventhFlat5,ChordType::Diminished,
        ChordType::Augmented,ChordType::AugmentedMajor7,ChordType::RootOctave,ChordType::Diminished7
    }};
    return key>=0&&key<=11&&velocity>=1&&velocity<=24?Chord{key,types[static_cast<std::size_t>(velocity-1)],key}:Chord{};
}
bool usesGuitarProgression(const TrackPattern& pattern,Element element,int selected,const ChordVariation* cv) noexcept {
    if(!cv||!cv->sourceRootKnown||selected<0||selected>=2)return false;
    if(pattern.pa5xGuitarProgression)return element<=Element::Intro3||ending(element);
    return pattern.legacyGuitarProgression&&(element==Element::Intro1||element==Element::Ending1);
}
Chord decodeGuitarProgression(const TrackPattern& pattern,int key,int velocity) noexcept {
    return pattern.pa5xGuitarProgression?pa5xGuitarChord(key,velocity):legacyGuitarChord(key,velocity);
}
int chordThird(ChordType t) noexcept {
    const auto mask=chordPitchClassMask(t);
    if((mask&(1U<<3))!=0)return 3;
    if((mask&(1U<<4))!=0)return 4;
    if((mask&(1U<<2))!=0)return 2;
    return (mask&(1U<<5))!=0?5:0;
}
int chordFifth(ChordType t) noexcept {
    const auto mask=chordPitchClassMask(t);
    if((mask&(1U<<6))!=0)return 6;
    if((mask&(1U<<8))!=0)return 8;
    return (mask&(1U<<7))!=0?7:0;
}
int chordSeventh(ChordType t) noexcept {
    const auto mask=chordPitchClassMask(t);
    if((mask&(1U<<11))!=0)return 11;
    if((mask&(1U<<10))!=0)return 10;
    return (mask&(1U<<9))!=0?9:0;
}
// SILVETON harmonic adapter. Imported raw enum numbers remain provenance;
// they are not assumed to encode our own policies. Keep chromatic passing
// notes, map structural chord degrees, and preserve exact-source phrases.
int nearestChordDegree(int relative, std::uint16_t mask) noexcept {
    int best=relative, distance=128;
    for(int candidate=relative-6;candidate<=relative+6;++candidate){
        if(!(mask&(1U<<pc(candidate))))continue;
        const int d=std::abs(candidate-relative);
        if(d<distance){distance=d;best=candidate;}
    }
    return best;
}
int transposePhraseNote(int key,int sourceRoot,ChordType sourceChord,Chord chord,TrackRole role) noexcept {
    if (!chord.valid() || role == TrackRole::Drums || role == TrackRole::Percussion) return key;
    const int relative=pc(key-sourceRoot);
    const auto sourceMask=chordPitchClassMask(sourceChord), targetMask=chordPitchClassMask(chord.type);
    if(!sourceMask||!targetMask)return key;
    int mapped=relative;
    if(chord.type==ChordType::RootOctave||chord.type==ChordType::RootFifth){
        mapped=nearestChordDegree(relative,targetMask);
    }else if(relative!=0 && (sourceMask&(1U<<relative)) && sourceChord!=chord.type){
        int preferred=0;
        if(relative==chordThird(sourceChord))preferred=chordThird(chord.type);
        else if(relative==chordFifth(sourceChord))preferred=chordFifth(chord.type);
        else if(relative==chordSeventh(sourceChord))preferred=chordSeventh(chord.type);
        // A missing extension must never jump to the root of the same octave.
        // Prefer the closest actually available chord tone, including octaves.
        if(preferred!=0){mapped=relative+pc(preferred-relative);if(mapped-relative>6)mapped-=12;}
        else if(!(targetMask&(1U<<relative)))mapped=nearestChordDegree(relative,targetMask);
    }
    if(role==TrackRole::Bass&&relative==0){
        int inversion=pc(chord.bass-chord.root);if(inversion>6)inversion-=12;
        mapped=inversion;
    }
    int shift=chord.root-sourceRoot;
    if(shift>6)shift-=12;else if(shift< -6)shift+=12;
    return key+shift+mapped-relative;
}
int applyPhraseRange(int pitch,PhraseRange range) noexcept {
    if(range.enabled==1){
        while(pitch<range.low)pitch+=12;
        while(pitch>range.high)pitch-=12;
        if(pitch<range.low)return -1;
    }
    return pitch>=0&&pitch<=127?pitch:-1;
}
int wrapOffset(int source,Chord chord,int maximum) noexcept {
    if(!chord.valid()||maximum<1||maximum>12)return 0;
    int ordinary=chord.root-source;
    if(ordinary>6)ordinary-=12;
    if(ordinary< -6)ordinary+=12;
    int wrapped=pc(chord.root-source);
    // At the wrap point the phrase starts the lower octave (1..12).
    if(wrapped>=maximum)wrapped-=12;
    return wrapped-ordinary;
}
int transposeNote(int key,const Style& style,Chord chord,TrackRole role,PhraseRange range) noexcept {
    if(role==TrackRole::Drums||role==TrackRole::Percussion)return key;
    const int pitch=transposePhraseNote(key,style.sourceRoot,style.sourceChord,chord,role)
        +wrapOffset(style.sourceRoot,chord,range.wrap);
    if(range.enabled!=1)return std::clamp(pitch,0,127);
    return applyPhraseRange(pitch,range);
}

Element firstVariation(const Style* style) noexcept {
    if (style == nullptr) return Element::Count;
    for (int n=static_cast<int>(Element::Var1); n<=static_cast<int>(Element::Var4); ++n)
        if (style->sections[static_cast<std::size_t>(n)].available) return static_cast<Element>(n);
    return Element::Count;
}
Element firstPlayableElement(const Style* style) noexcept {
    const auto preferred=firstVariation(style);
    if(preferred!=Element::Count||style==nullptr||!style->nativeKorg)return preferred;
    for(std::size_t i=0;i<kElementCount;++i)if(style->sections[i].available)return static_cast<Element>(i);
    return Element::Count;
}
double measureTicks(const Style& s, const Section& sec) noexcept {
    return static_cast<double>(s.ppq) * 4.0 * sec.numerator / sec.denominator;
}
bool validStyle(const Style& style) noexcept {
    if(style.ppq==0||!std::isfinite(style.tempoBpm)||style.tempoBpm<20||style.tempoBpm>400||firstPlayableElement(&style)==Element::Count)return false;
    for(const auto& sec:style.sections)if(sec.available){
        if(sec.lengthTicks==0||sec.numerator==0||sec.denominator==0)return false;
        std::uint32_t previous=0;
        for(const auto& ev:sec.events){if(ev.tick<previous||ev.tick>sec.lengthTicks||ev.track>=kTracks||ev.data1>127||ev.data2>127)return false;previous=ev.tick;}
        if(sec.nativePatterns)for(const auto& pattern:sec.patterns){
            if(!pattern.guitar.valid())return false;
            if(pattern.keyRangeEnabled&&(pattern.keyLow<0||pattern.keyHigh>127||pattern.keyLow>pattern.keyHigh))return false;
            for(const auto cv:pattern.chordCv)if(cv>6)return false;
            for(const auto& ev:pattern.setupEvents)if(ev.track>=kTracks||ev.data1>127||ev.data2>127)return false;
            for(const auto& cv:pattern.cvs)if(cv.available){
                if(cv.lengthTicks==0||cv.sourceRoot<0||cv.sourceRoot>11)return false;
                previous=0;
                for(const auto& ev:cv.events){if(ev.tick<previous||ev.tick>cv.lengthTicks||ev.track>=kTracks||ev.data1>127||ev.data2>127)return false;previous=ev.tick;}
                previous=0;
                for(const auto& tempo:cv.tempoEvents){if(tempo.tick<previous||tempo.tick>cv.lengthTicks||!std::isfinite(tempo.bpm)||tempo.bpm<20||tempo.bpm>400)return false;previous=tempo.tick;}
            }
        }
    }
    return true;
}
} // namespace

const char* elementName(Element e) noexcept { const auto n=static_cast<std::size_t>(e); return n<kNames.size()?kNames[n]:"--"; }
ArrangerEngine::ArrangerEngine() noexcept {
    for(std::size_t i=0;i<kQueueSize;++i)queue_[i].sequence.store(i,std::memory_order_relaxed);
    for(std::size_t player=0;player<players_.size();++player)for(std::size_t track=0;track<kTracks;++track)
        players_[player].guitars[track].randomState=0x6D2B79F5U^static_cast<std::uint32_t>((player*kTracks+track+1U)*0x9E3779B9U);
}
ArrangerEngine::~ArrangerEngine() = default;

bool ArrangerEngine::installStyle(int player,std::shared_ptr<const Style> style) {
    return publishStyleInstallation(player,std::move(style),false,nullptr,false);
}
bool ArrangerEngine::stageStyle(int player,std::shared_ptr<const Style> style,
    bool samplePlaybackMode,const void* commitToken) {
    if(!style)return false;
    return publishStyleInstallation(player,std::move(style),samplePlaybackMode,commitToken,true);
}
void ArrangerEngine::reclaimRetiredStyleOwners() {
    for(const auto& installation:retainedInstallations_)
        if(installation->retired.load(std::memory_order_acquire))installation->owner.reset();
}
bool ArrangerEngine::publishStyleInstallation(int player,std::shared_ptr<const Style> style,
    bool samplePlaybackMode,const void* token,bool quantized) {
    if(player<0||player>=kPlayers||(style&&!validStyle(*style)))return false;
    auto installation=std::make_unique<StyleInstallation>();
    installation->style=style?style.get():&kClearStyle;
    installation->samplePlaybackMode=samplePlaybackMode;
    installation->commitToken=token;installation->quantized=quantized;
    installation->owner=std::move(style);
    const auto* published=installation.get();
    retainedInstallations_.push_back(std::move(installation));
    // Exchange assigns an unconsumed superseded token exclusively to control;
    // audio can no longer acquire it. Already consumed tokens retire on audio
    // only after their replacement has been published at the end of a block.
    const auto* replaced=pending_[static_cast<std::size_t>(player)].exchange(published,std::memory_order_acq_rel);
    if(replaced)replaced->retired.store(true,std::memory_order_release);
    reclaimRetiredStyleOwners();
    return true;
}
void ArrangerEngine::commitStyle(int player,const StyleInstallation& installation,
    bool keepPlaying,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    // returnTo also carries an explicitly requested Variation while its old
    // Auto Fill is pending; do not lose that choice during a Style handoff.
    if(player==sequencePlayer_&&p.style&&p.style!=installation.style&&!sequenceLocked_){
        const bool playingSequence=sequenceMode_==ChordSequenceMode::Playing;
        sequence_={};sequenceMode_=ChordSequenceMode::Idle;sequenceCurrent_=-1;sequenceDirty_=true;
        if(playingSequence)releaseSequenceHarmony(cb);
    }
    const Element preferred=variation(p.returnTo)?p.returnTo:p.element;
    const bool syncStart=installation.quantized&&p.syncStart;
    const bool liveHandoff=keepPlaying&&installation.quantized;
    if(liveHandoff)cb.styleChanging(player,installation.style);
    const bool keepManual=p.manualBass;
    if(keepManual)setManualBass(player,false,cb);
    silence(player,cb,-1,false,false); // releases use the old routing bundle
    p.pendingStyle=nullptr;p.styleSwitchTicksRemaining=0;
    if(installation.style==&kClearStyle){
        const double retainedGain=p.fadeGain;p=Player{};p.fadeGain=retainedGain;p.autoFill=autoFill_;cb.styleCommitted(player,nullptr,installation.commitToken);cb.sourceStyle(player,nullptr);return;
    }
    p.style=installation.style;p.styleInstallation=&installation;p.styleCommitToken=installation.commitToken;
    p.cursors={};p.blockedTrackMask=0;p.tick=0;p.eventIndex=0;
    p.playing=keepPlaying;p.syncStart=syncStart;
    p.samplePlaybackMode=installation.samplePlaybackMode;
    p.tempo=tempoLock_?lockedTempo_:p.style->tempoBpm;
    p.element=firstPlayableElement(p.style);
    if(installation.quantized&&variation(preferred)&&p.style->sections[static_cast<std::size_t>(preferred)].available)
        p.element=preferred;
    const auto savedElement=cb.committedStyleElement(player,p.styleCommitToken,p.playing,p.element);
    if(static_cast<std::size_t>(savedElement)<p.style->sections.size()&&p.style->sections[static_cast<std::size_t>(savedElement)].available)
        p.element=savedElement;
    p.autoFill=autoFill_; // manual p195: a Style cannot replace this global setting
    p.returnTo=variation(p.element)?p.element:firstVariation(p.style);
    p.queued=Element::Count;p.loopElement=Element::Count;p.lastElementPress=Element::Count;
    if(!keepPlaying)p.fadeDirection=0;
    // The host activates the prepared audio bank before the new setup/PC stream.
    cb.styleCommitted(player,p.style,p.styleCommitToken);
    cb.sourceStyle(player,p.style);
    const auto sourceMute=static_cast<std::uint8_t>(p.style->initialMuteMask&p.style->initialMuteKnownMask);
    p.muteMask=cb.committedStyleMuteMask(player,p.styleCommitToken,sourceMute);
    // MIDI mix state belongs to this Style. Its setup/CV declarations below
    // override the neutral fallback before any new note can sound.
    cb.initializeStyleControllers(player);
    if(p.playing)begin(player,p.element,cb);
    if(keepManual&&splitEnabled_)setManualBass(player,true,cb);
    if(liveHandoff)cb.styleChangeFinished(player);
}
void ArrangerEngine::commitStoppedSelection(int player,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    if(p.pendingStyle){const auto* next=p.pendingStyle;commitStyle(player,*next,false,cb);}
}

bool ArrangerEngine::post(const Command& command) noexcept {
    std::size_t pos=enqueue_.load(std::memory_order_relaxed);
    for(;;){
        QueueSlot& slot=queue_[pos&(kQueueSize-1)];
        const std::size_t seq=slot.sequence.load(std::memory_order_acquire);
        const auto difference=static_cast<std::intptr_t>(seq)-static_cast<std::intptr_t>(pos);
        if(difference==0){
            if(enqueue_.compare_exchange_weak(pos,pos+1,std::memory_order_relaxed)){
                slot.command=command;slot.sequence.store(pos+1,std::memory_order_release);return true;
            }
        } else if(difference<0){
            dropped_.fetch_add(1,std::memory_order_relaxed);
            // A lost keyboard event can leave chord notes held. Repair just
            // that input channel. Unrelated players must keep their transport.
            if (command.type == CommandType::Midi)
                inputResetMask_.fetch_or(1U << (command.index & 15), std::memory_order_release);
            else
                panicPending_.store(true,std::memory_order_release);
            return false;
        } else pos=enqueue_.load(std::memory_order_relaxed);
    }
}
bool ArrangerEngine::pop(Command& command) noexcept {
    const std::size_t pos=dequeue_.load(std::memory_order_relaxed);
    QueueSlot& slot=queue_[pos&(kQueueSize-1)];
    if(slot.sequence.load(std::memory_order_acquire)!=pos+1)return false;
    command=slot.command;slot.sequence.store(pos+kQueueSize,std::memory_order_release);
    dequeue_.store(pos+1,std::memory_order_relaxed);return true;
}
bool ArrangerEngine::postMidi(int status,int data1,int data2) noexcept {
    const int type = status & 0xf0;
    const int cc = data1 & 127;
    // The keyboard synth already receives the full MIDI stream. Only inputs
    // consumed by observeMidi belong in the arranger's chord/transport queue.
    if (type != 0x80 && type != 0x90 &&
        !(type == 0xb0 && (cc == 64 || cc == 120 || cc == 121 || cc == 123))) return true;
    return post({CommandType::Midi,0,status&255,static_cast<double>(cc),data2&127});
}
bool ArrangerEngine::postChordControls(int mode,int area,bool splitEnabled,bool bassInversion,
    bool damperLatch,int splitNote,bool memory,int memoryMode) noexcept {
    if(mode<0||mode>4||area<0||area>3||splitNote<1||splitNote>127||memoryMode<0||memoryMode>2)return false;
    const unsigned flags=static_cast<unsigned>(splitNote)|(memory?128U:0U)|(splitEnabled?256U:0U)|
        (bassInversion?512U:0U)|(damperLatch?1024U:0U)|(static_cast<unsigned>(memoryMode)<<11);
    return post({CommandType::ApplyChordControls,0,mode,static_cast<double>(flags),area});
}
const Section* ArrangerEngine::section(const Player& p) const noexcept {
    const auto i=static_cast<std::size_t>(p.element);
    return p.style&&i<kElementCount&&p.style->sections[i].available?&p.style->sections[i]:nullptr;
}
void ArrangerEngine::silence(int player,RenderCallbacks& cb,int onlyTrack,bool immediate,bool preserveManualBass) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    for(int tr=0;tr<kTracks;++tr){if(onlyTrack>=0&&onlyTrack!=tr)continue;
        if(tr==2&&p.manualBass){
            if(preserveManualBass&&!immediate)continue;
            if(p.manualBassKey>=0)(void)cb.manualBassNote(player,p.manualBassKey,0);
            p.manualBassKey=-1;
        }
        cb.midi(player,tr,0xB0,64,0);
        const auto track=static_cast<std::size_t>(tr);
        p.styleDamper[track]=0;
        auto& owners=p.outputOwners[track];
        for(std::size_t key=0;key<128;++key)if(owners[key])
            cb.midi(player,tr,0x80,static_cast<std::uint8_t>(key),0);
        owners.fill(0);
        p.harmonyExtra[track]=0;
        p.active[track].fill(0);
        p.velocities[track].fill(0);
        // Keep the deterministic PRNG stream advancing across CV loops; every
        // musical/lifecycle reset still discards pending attacks and gates.
        const auto random=p.guitars[track].randomState;
        p.guitars[track]={};p.guitars[track].randomState=random;
        cb.midi(player,tr,0xB0,immediate?120:123,0);
    }
}
void ArrangerEngine::setManualBass(int player,bool enabled,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    if(p.manualBass==enabled)return;
    if(enabled){
        if(!splitEnabled_||!p.style||!p.style->tracks[2].used||p.style->tracks[2].role!=TrackRole::Bass||!cb.manualBassAvailable(player,p.style))return;
        for(int i=0;i<kPlayers;++i)if(i!=player&&players_[static_cast<std::size_t>(i)].manualBass)setManualBass(i,false,cb);
        for(int tr=2;tr<kTracks;++tr)silence(player,cb,tr,false,false);
        p.manualBass=true;cb.manualBassMode(player,true);
    }else{
        silence(player,cb,2,false,false);
        p.manualBass=false;cb.manualBassMode(player,false);
    }
}
void ArrangerEngine::refreshManualBass(RenderCallbacks& cb) noexcept {
    for(int i=0;i<kPlayers;++i){
        auto& p=players_[static_cast<std::size_t>(i)];if(!p.manualBass)continue;
        if(!splitEnabled_||!p.style||!cb.manualBassAvailable(i,p.style)){setManualBass(i,false,cb);continue;}
        // Lowest physically held Lower key has priority. Key releases fall
        // back to the next held key, independently of chord Memory/damper.
        int key=-1;std::uint8_t velocity=0;
        for(int k=0;k<=split_;++k){
            for(std::size_t ch=0;ch<held_.size();++ch)if(held_[ch][static_cast<std::size_t>(k)])
                velocity=std::max(velocity,heldVelocity_[ch][static_cast<std::size_t>(k)]);
            if(velocity){key=k;break;}
        }
        if(key==p.manualBassKey)continue;
        if(p.manualBassKey>=0){(void)cb.manualBassNote(i,p.manualBassKey,0);p.manualBassKey=-1;}
        if(key>=0&&cb.manualBassNote(i,key,velocity))p.manualBassKey=key;
    }
}
void ArrangerEngine::setTempo(int player,double bpm) noexcept {
    if(!std::isfinite(bpm)||bpm<20||bpm>400||player<0||player>=kPlayers)return;
    if(tempoLock_){lockedTempo_=bpm;for(auto& p:players_)p.tempo=bpm;}
    else players_[static_cast<std::size_t>(player)].tempo=bpm;
}
int ArrangerEngine::chosenCv(const TrackPattern& pattern,int previous) const noexcept {
    if(!pattern.present)return -1;
    if(!chord_.valid() && previous>=0)return previous;
    const auto type=chord_.valid()?static_cast<std::size_t>(chord_.type):static_cast<std::size_t>(ChordType::Major);
    if(type>=pattern.chordCv.size())return -1;
    const auto number=pattern.chordCv[type];
    const int declared=number>=1&&number<=6?static_cast<int>(number)-1:-1;
    if(declared>=0&&pattern.cvs[static_cast<std::size_t>(declared)].available)return declared;
    // Drum and unknown pattern types retain the literal CV selection. Pitched
    // phrases may use a known harmonic source when the target CV is absent.
    if(pattern.mode!=NativePatternMode::RecordedSourceOnly&&pattern.mode!=NativePatternMode::Guitar)return declared;
    const auto target=chordPitchClassMask(static_cast<ChordType>(type));
    int best=-1,bestCost=100;
    for(int i=0;i<6;++i){
        const auto& cv=pattern.cvs[static_cast<std::size_t>(i)];
        const auto mask=chordPitchClassMask(cv.sourceChord);
        if(!cv.available||!mask)continue;
        int diff=0;for(unsigned bits=static_cast<unsigned>(target^mask);bits;bits&=bits-1)++diff;
        const int cost=diff*4+(i==previous?0:1);
        if(cost<bestCost){bestCost=cost;best=i;}
    }
    return best;
}
int ArrangerEngine::nativeNote(const TrackPattern& pattern,const ChordVariation& cv,int key,Chord chord,TrackRole role,bool samplePlaybackMode,PhraseRange range,bool guitarEnabled) const noexcept {
    if(pattern.mode==NativePatternMode::Drum)return key;
    if((pattern.mode!=NativePatternMode::RecordedSourceOnly&&pattern.mode!=NativePatternMode::Guitar)||cv.sourceChord==ChordType::None)return -1;
    if(!chord.valid()&&(scanArea_==0||!holdsChord()||(!samplePlaybackMode&&!guitarEnabled)))return -1;
    int mapped=key;
    if(chord.valid())mapped=transposePhraseNote(key,cv.sourceRoot,cv.sourceChord,chord,
        role==TrackRole::Bass?TrackRole::Bass:TrackRole::Accompaniment);
    if(range.enabled<0){range.enabled=pattern.keyRangeEnabled;range.low=pattern.keyLow;range.high=pattern.keyHigh;}
    mapped+=wrapOffset(cv.sourceRoot,chord,range.wrap?range.wrap:pattern.wrapAroundDegree);
    // Folding by octaves never changes the intended pitch class.
    if(range.enabled!=1){while(mapped<0)mapped+=12;while(mapped>127)mapped-=12;}
    return applyPhraseRange(mapped,range);
}
void ArrangerEngine::restoreGuitarShape(int player,int track,const TrackPattern& pattern,
    const ChordVariation* cv,std::size_t before) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];auto& guitar=p.guitars[static_cast<std::size_t>(track)];
    guitar.shape={};guitar.progression={};guitar.voicingCapo=-1;guitar.voicingPosition=-1;
    const int selected=p.cursors[static_cast<std::size_t>(track)].cv;
    const bool progression=usesGuitarProgression(pattern,p.element,selected,cv);
    const auto restore=[&](const MidiEvent& event){
        if((event.status&0xF0U)!=0x90U||event.data2==0)return;
        if(event.data1==12)(void)guitarShapeFromVelocity(event.data2,guitar.shape);
        else if(progression&&event.data1<=11){const auto chord=decodeGuitarProgression(pattern,event.data1,event.data2);if(chord.valid())guitar.progression=chord;}
    };
    for(const auto& event:pattern.setupEvents)restore(event);
    if(cv)for(std::size_t i=0;i<std::min(before,cv->events.size());++i)restore(cv->events[i]);
}
void ArrangerEngine::configureGuitar(int player,int track,const TrackPattern& pattern,
    const ChordVariation* cv,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto tr=static_cast<std::size_t>(track);
    if(p.manualBass&&track==2)return;
    auto edit=cb.guitarSettings(p.styleCommitToken,p.element,track);if(!edit.valid())edit={};
    const auto settings=resolveGuitarSettings(pattern.guitar,edit);
    const bool enabled=guitarMode(pattern,edit);
    auto& guitar=p.guitars[tr];
    const bool modeChanged=guitar.configured&&guitar.enabled!=enabled;
    if(modeChanged){
        const auto pedal=p.styleDamper[tr];silence(player,cb,track);
        p.styleDamper[tr]=pedal;if(pedal>=64)cb.midi(player,track,0xB0,64,pedal);
    }
    else if(guitar.configured&&enabled&&!sameGuitarFingering(guitar.settings,settings))
        releaseGuitarVoices(player,track,cb,true);
    if(guitar.configured&&enabled&&guitar.settings.rxIntensity!=0&&settings.rxIntensity==0){
        for(int key=96;key<128;++key)if(p.active[tr][static_cast<std::size_t>(key)])
            phraseNote(player,track,key,-1,0,0,cb);
    }
    const bool restore=!guitar.configured;
    guitar.configured=true;guitar.enabled=enabled;guitar.settings=settings;
    if(restore)restoreGuitarShape(player,track,pattern,cv,p.cursors[tr].eventIndex);
    const bool blocked=cv&&cv->available&&(pattern.mode==NativePatternMode::Unsupported||
        (!enabled&&pattern.mode!=NativePatternMode::Drum&&cv->sourceChord==ChordType::None));
    if(blocked)p.blockedTrackMask=static_cast<std::uint8_t>(p.blockedTrackMask|(1U<<track));
    else p.blockedTrackMask=static_cast<std::uint8_t>(p.blockedTrackMask&~(1U<<track));
}
void ArrangerEngine::releaseGuitarString(int player,int track,std::size_t string,RenderCallbacks& cb,bool damp) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto tr=static_cast<std::size_t>(track);
    auto& voice=p.guitars[tr].strings[string];
    if(voice.pitch>=0){
        const auto key=static_cast<std::size_t>(voice.pitch);auto& owner=p.outputOwners[tr][key];
        if(owner>0&&--owner==0){
            const auto pedal=p.styleDamper[tr];
            if(damp&&pedal>=64)cb.midi(player,track,0xB0,64,0);
            cb.midi(player,track,0x80,static_cast<std::uint8_t>(key),0);
            if(damp&&pedal>=64)cb.midi(player,track,0xB0,64,pedal);
        }
    }
    voice.pitch=-1;voice.sourceKey=-1;voice.ageMs=0;voice.releaseMs=-1;voice.damp=false;
}
void ArrangerEngine::releaseGuitarVoices(int player,int track,RenderCallbacks& cb,bool damp) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto tr=static_cast<std::size_t>(track);
    auto& guitar=p.guitars[tr];const auto pedal=p.styleDamper[tr];
    // Pedal-held notes can already have lost their key ownership. A forced
    // mute must release those tails too, even if every physical key is up.
    if(damp&&pedal>=64)cb.midi(player,track,0xB0,64,0);
    for(std::size_t s=0;s<guitar.strings.size();++s){releaseGuitarString(player,track,s,cb);guitar.strings[s]={};}
    if(damp&&pedal>=64)cb.midi(player,track,0xB0,64,pedal);
}
Chord ArrangerEngine::guitarChord(const Player& p,int track,const ChordVariation& cv) const noexcept {
    if(!chord_.valid()&&(scanArea_==0||!holdsChord()))return {};
    const auto& guitar=p.guitars[static_cast<std::size_t>(track)];
    if(guitar.progression.valid()&&cv.sourceRootKnown){
        const int root=pc(guitar.progression.root+(chord_.valid()?chord_.root-cv.sourceRoot:0));
        return {root,guitar.progression.type,root};
    }
    if(chord_.valid())return chord_;
    return cv.sourceChord!=ChordType::None?Chord{cv.sourceRoot,cv.sourceChord,cv.sourceRoot}:Chord{};
}
void ArrangerEngine::guitarEvent(int player,int track,const TrackPattern& pattern,
    const ChordVariation& cv,const MidiEvent& event,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto tr=static_cast<std::size_t>(track);
    auto& guitar=p.guitars[tr];const int key=event.data1;
    const bool attack=(event.status&0xF0U)==0x90U&&event.data2>0;
    if(key==12){if(attack)(void)guitarShapeFromVelocity(event.data2,guitar.shape);return;}
    if(key<=11){
        const int selected=p.cursors[tr].cv;
        if(attack&&usesGuitarProgression(pattern,p.element,selected,&cv)){
            const auto progression=decodeGuitarProgression(pattern,key,event.data2);
            if(progression.valid()){
                const auto previous=guitarChord(p,track,cv);guitar.progression=progression;
                const auto chord=guitarChord(p,track,cv);
                if(previous.root==chord.root&&previous.type==chord.type&&previous.bass==chord.bass)return;
                releaseGuitarVoices(player,track,cb,true);
                for(int source=48;source<96;++source){const auto velocity=p.velocities[tr][static_cast<std::size_t>(source)];if(!velocity)continue;
                    const int target=nativeNote(pattern,cv,source,chord,TrackRole::Accompaniment,p.samplePlaybackMode,cb.phraseRange(p.styleCommitToken,p.element,track),true);
                    phraseNote(player,track,source,target,velocity,0,cb);
                }
            }
        }
        return; // Unsupported progression events never become audible MIDI notes.
    }
    if(key<24)return;
    if(!attack){
        if(key>=48){phraseNote(player,track,key,-1,0,(event.status&0xF0U)==0x90U?64U:event.data2,cb);return;}
        for(auto& voice:guitar.strings){
            const double amount=static_cast<double>(guitar.settings.humanize)/127.0;
            if(voice.pitch>=0&&voice.sourceKey==key){
                const double delay=std::max(0.0,8.0-voice.ageMs)+(amount>0?12.0*amount*guitarRandomUnit(guitar.randomState):0.0);
                voice.releaseMs=voice.releaseMs>=0?std::min(voice.releaseMs,delay):delay;
            }
            if(voice.pendingPitch>=0&&voice.pendingSource==key){
                // A short MIDI trigger must not erase the later strings of a
                // slow stroke. They still get a short gate after their attack.
                const double gate=8.0+(amount>0?12.0*amount*guitarRandomUnit(guitar.randomState):0.0);
                voice.pendingGateMs=voice.pendingGateMs>=0?std::min(voice.pendingGateMs,gate):gate;
            }
        }
        return;
    }
    if(key==42){
        releaseGuitarVoices(player,track,cb,true);
        const auto pedal=p.styleDamper[tr];if(pedal>=64)cb.midi(player,track,0xB0,64,0);
        for(int source=48;source<96;++source)if(p.velocities[tr][static_cast<std::size_t>(source)])phraseNote(player,track,source,-1,0,0,cb);
        if(pedal>=64)cb.midi(player,track,0xB0,64,pedal);
        return;
    }
    if(p.suppressAccompaniment(track)||((p.muteMask&(1U<<track))&&!cb.rendersTrackMutes()))return;
    const auto chord=guitarChord(p,track,cv);
    if(key>=96){
        // Literal RX keys bypass transposition, but retain the pitched part's
        // Chord Scan/Memory gate. No unrecorded noise notes are synthesized.
        if(!chord_.valid()&&(scanArea_==0||!holdsChord()))return;
        // This is an RX-only MIDI dynamics control, not a channel-volume
        // edit. Keep the original noise pitch and do not change strum velocity.
        const int intensity=guitar.settings.rxIntensity;
        if(intensity==0){phraseNote(player,track,key,-1,0,0,cb);return;}
        const auto velocity=static_cast<std::uint8_t>(std::max(1,(int(event.data2)*intensity+63)/127));
        phraseNote(player,track,key,key,velocity,0,cb);return;
    }
    if(key>=48){
        const int target=nativeNote(pattern,cv,key,chord,TrackRole::Accompaniment,p.samplePlaybackMode,cb.phraseRange(p.styleCommitToken,p.element,track),true);
        phraseNote(player,track,key,target,event.data2,0,cb);return;
    }
    if(!chord.valid())return;
    if(guitar.voicingCapo!=guitar.settings.capo||guitar.voicingPosition!=guitar.shape.position||
       guitar.voicingChord.root!=chord.root||guitar.voicingChord.type!=chord.type||guitar.voicingChord.bass!=chord.bass){
        guitar.voicing=makeGuitarVoicing(chord,guitar.settings.capo,guitar.shape.position);
        guitar.voicingChord=chord;guitar.voicingCapo=guitar.settings.capo;guitar.voicingPosition=guitar.shape.position;
    }
    const auto stroke=makeGuitarStroke(key,event.data2,chord,guitar.settings,guitar.shape,guitar.voicing,guitar.alternatingUp);
    if(key==46||key==47)guitar.alternatingUp=!guitar.alternatingUp;
    const double amount=static_cast<double>(guitar.settings.humanize)/127.0;
    double previousDelay=0;
    for(int n=0;n<stroke.count;++n){
        const auto& note=stroke.notes[static_cast<std::size_t>(n)];auto& voice=guitar.strings[static_cast<std::size_t>(note.string)];
        const double jitter=amount>0?8.0*amount*guitarRandomUnit(guitar.randomState):0.0;
        const double ordered=n>0?previousDelay+0.25:0.0;
        const double delay=std::max(ordered,static_cast<double>(n)*stroke.spacingMs+jitter);previousDelay=delay;
        const int spread=(guitar.settings.humanize*12+63)/127;
        const int jitterVelocity=spread>0?static_cast<int>(guitarRandom(guitar.randomState)%static_cast<std::uint32_t>(spread*2+1))-spread:0;
        voice.pendingPitch=note.pitch;voice.pendingSource=key;
        voice.pendingVelocity=static_cast<std::uint8_t>(std::clamp(static_cast<int>(event.data2)+jitterVelocity,1,127));
        voice.attackMs=delay;voice.pendingGateMs=stroke.gateMs;
        if(stroke.gateMs>=0&&amount>0)voice.pendingGateMs*=1.0+0.15*amount*(2.0*guitarRandomUnit(guitar.randomState)-1.0);
        voice.pendingDamp=stroke.gateMs>=0;
    }
}
void ArrangerEngine::drainGuitarEvents(int player,int track,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto tr=static_cast<std::size_t>(track);auto& guitar=p.guitars[tr];
    if(!guitar.enabled)return;
    if(!chord_.valid()&&(scanArea_==0||!holdsChord())){
        const bool pending=std::any_of(guitar.strings.begin(),guitar.strings.end(),[](const auto& voice){return voice.pitch>=0||voice.pendingPitch>=0;});
        if(pending)releaseGuitarVoices(player,track,cb,true);
        return;
    }
    for(std::size_t s=0;s<guitar.strings.size();++s){auto& voice=guitar.strings[s];
        if(voice.pitch>=0&&voice.releaseMs>=0&&voice.releaseMs<=1e-7)releaseGuitarString(player,track,s,cb,voice.damp);
    }
    for(std::size_t s=0;s<guitar.strings.size();++s){auto& voice=guitar.strings[s];
        if(voice.pendingPitch<0||voice.attackMs>1e-7)continue;
        releaseGuitarString(player,track,s,cb);
        voice.pitch=voice.pendingPitch;voice.sourceKey=voice.pendingSource;
        voice.releaseMs=voice.pendingGateMs;voice.damp=voice.pendingDamp;voice.ageMs=0;
        auto& owners=p.outputOwners[tr][static_cast<std::size_t>(voice.pitch)];
        // Shared MIDI pitches retain the existing ownership discipline. A
        // unison on two strings must not accumulate an unbounded voice stack.
        if(owners++==0)cb.midi(player,track,0x90,static_cast<std::uint8_t>(voice.pitch),voice.pendingVelocity);
        voice.pendingPitch=-1;voice.pendingSource=-1;voice.attackMs=-1;voice.pendingGateMs=-1;voice.pendingDamp=false;
    }
}
double ArrangerEngine::nextGuitarEventMs(const Player& p) const noexcept {
    double next=std::numeric_limits<double>::infinity();
    for(const auto& guitar:p.guitars)if(guitar.enabled)for(const auto& voice:guitar.strings){
        if(voice.pendingPitch>=0)next=std::min(next,std::max(0.0,voice.attackMs));
        if(voice.pitch>=0&&voice.releaseMs>=0)next=std::min(next,std::max(0.0,voice.releaseMs));
    }
    return next;
}
void ArrangerEngine::advanceGuitarEvents(Player& p,double elapsedMs) noexcept {
    for(auto& guitar:p.guitars)if(guitar.enabled)for(auto& voice:guitar.strings){
        if(voice.pendingPitch>=0)voice.attackMs=std::max(0.0,voice.attackMs-elapsedMs);
        if(voice.pitch>=0){voice.ageMs+=elapsedMs;if(voice.releaseMs>=0)voice.releaseMs=std::max(0.0,voice.releaseMs-elapsedMs);}
    }
}
void ArrangerEngine::selectPatternCvs(int player,RenderCallbacks& cb,bool reset) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto* sec=section(p);
    if(!sec||!sec->nativePatterns)return;
    p.blockedTrackMask=0;
    for(int tr=0;tr<kTracks;++tr){
        const auto& pattern=sec->patterns[static_cast<std::size_t>(tr)];
        auto& cursor=p.cursors[static_cast<std::size_t>(tr)];
        const int selected=chosenCv(pattern,reset?-1:cursor.cv);
        if(reset||selected!=cursor.cv){
            // beginAt has already released every track at section start.
            if(!reset)silence(player,cb,tr);
            cb.patternStart(player,tr);cursor={};cursor.cv=selected;
            if(selected>=0){
                const auto& cv=pattern.cvs[static_cast<std::size_t>(selected)];
                if(cv.available&&cv.lengthTicks>0){
                    cursor.tick=reset?0.0:std::fmod(p.tick,static_cast<double>(cv.lengthTicks));
                    while(cursor.eventIndex<cv.events.size()&&cv.events[cursor.eventIndex].tick+1e-7<cursor.tick)++cursor.eventIndex;
                    while(cursor.tempoIndex<cv.tempoEvents.size()&&cv.tempoEvents[cursor.tempoIndex].tick+1e-7<cursor.tick)++cursor.tempoIndex;
                    if(!tempoLock_&&cursor.tempoIndex>0U)setTempo(player,cv.tempoEvents[cursor.tempoIndex-1U].bpm);
                    for(const auto& event:pattern.setupEvents){const auto type=static_cast<std::uint8_t>(event.status&0xF0U);if(type!=0x80U&&type!=0x90U)sendStyleMessage(player,tr,event,cb);}
                    // Entering a different CV can preserve the musical phase.
                    // Restore earlier bank/program and sound/controller state;
                    // skipped notes must never be retriggered during selection.
                    for(std::size_t i=0;i<cursor.eventIndex;++i){
                        auto event=cv.events[i];
                        if(restoreStyleState(event))sendStyleMessage(player,tr,event,cb);
                    }
                }
            }
        }
        configureGuitar(player,tr,pattern,selected>=0?&pattern.cvs[static_cast<std::size_t>(selected)]:nullptr,cb);
    }
}
void ArrangerEngine::phraseNote(int player,int track,int sourceKey,int outputKey,
    std::uint8_t attack,std::uint8_t release,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    const auto tr=static_cast<std::size_t>(track);
    const auto source=static_cast<std::size_t>(sourceKey);
    auto& mapped=p.active[tr][source];
    auto& owners=p.outputOwners[tr];
    if(mapped){
        const auto old=static_cast<std::uint8_t>(mapped-1);
        if(--owners[old]==0)cb.midi(player,track,0x80,old,release);
        mapped=0;
    }
    if(p.suppressAccompaniment(track)){p.velocities[tr][source]=0;return;}
    p.velocities[tr][source]=attack;
    if(outputKey<0)return;
    mapped=static_cast<std::uint16_t>(outputKey+1);
    if(owners[static_cast<std::size_t>(outputKey)]++==0)
        cb.midi(player,track,0x90,static_cast<std::uint8_t>(outputKey),attack);
}
// Complete extended chords only on a held complete native source triad.
// No extra notes on Bass, drums, guitar, single-note or authored seventh phrases.
int ArrangerEngine::harmonyExtension(const Player& p,int track,RenderCallbacks& cb,std::uint8_t& velocity) const noexcept {
    const auto tr=static_cast<std::size_t>(track);const auto* sec=section(p);
    if(!chord_.valid()||!sec||!sec->nativePatterns||p.suppressAccompaniment(track)||
       p.style->tracks[tr].role!=TrackRole::Accompaniment||p.guitars[tr].enabled||
       (!cb.rendersTrackMutes()&&(p.muteMask&(1U<<track))))return -1;
    const auto& pattern=sec->patterns[tr];const int index=p.cursors[tr].cv;
    if(pattern.mode!=NativePatternMode::RecordedSourceOnly||index<0)return -1;
    const auto& cv=pattern.cvs[static_cast<std::size_t>(index)];
    const auto source=chordPitchClassMask(cv.sourceChord),target=chordPitchClassMask(chord_.type);
    const int extension=chordSeventh(chord_.type);
    auto population=[](unsigned bits){int n=0;for(;bits;bits&=bits-1)++n;return n;};
    if(!cv.available||population(source)!=3||population(target)!=4||!extension||chordSeventh(cv.sourceChord))return -1;
    const int wanted=pc(chord_.root+extension);
    unsigned held=0;int highest=-1;velocity=127;
    for(int key=0;key<128;++key){
        const auto i=static_cast<std::size_t>(key);const int mapped=static_cast<int>(p.active[tr][i])-1;
        if(mapped<0||!p.velocities[tr][i])continue;
        if(pc(mapped)==wanted)return -1;
        const unsigned degree=1U<<pc(key-cv.sourceRoot);
        if(!(source&degree))continue;
        held|=degree;highest=std::max(highest,mapped);velocity=std::min(velocity,p.velocities[tr][i]);
    }
    if((held&source)!=source||highest<0)return -1;
    auto range=cb.phraseRange(p.styleCommitToken,p.element,track);
    if(range.enabled<0){range.enabled=pattern.keyRangeEnabled;range.low=pattern.keyLow;range.high=pattern.keyHigh;}
    const int low=range.enabled==1?std::clamp(range.low,0,127):0;
    const int high=range.enabled==1?std::clamp(range.high,0,127):127;
    int pitch=highest+pc(wanted-pc(highest));if(pitch==highest)pitch+=12;
    while(pitch>high)pitch-=12;
    while(pitch<low)pitch+=12;
    return pitch<=high?pitch:-1;
}
void ArrangerEngine::refreshHarmonyExtension(int player,int track,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto tr=static_cast<std::size_t>(track);
    std::uint8_t velocity=0;const int next=harmonyExtension(p,track,cb,velocity);
    auto& extra=p.harmonyExtra[tr];auto& owners=p.outputOwners[tr];
    if(extra==static_cast<std::uint16_t>(next+1))return;
    if(extra){const auto old=static_cast<std::uint8_t>(extra-1);if(owners[old]&&--owners[old]==0)cb.midi(player,track,0x80,old,0);}
    extra=static_cast<std::uint16_t>(next+1);
    if(next>=0&&owners[static_cast<std::size_t>(next)]++==0)cb.midi(player,track,0x90,static_cast<std::uint8_t>(next),velocity);
}
void ArrangerEngine::sendStyleMessage(int player,int track,const MidiEvent& event,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    if(p.manualBass&&track==2){
        const auto kind=event.status&0xF0U;
        // Keep exact bank/PC and mix messages; source pedal, panic and pitch
        // automation must not release or bend the live Bass note.
        if(kind!=0xC0U&&!(kind==0xB0U&&(event.data1==0||event.data1==32||mixController(event.data1))))return;
    }
    if((event.status&0xF0U)==0xA0U){
        if(event.data1>127U||((p.muteMask&(1U<<track))&&!cb.rendersTrackMutes()))return;
        // Poly pressure follows the actual sounding pitches after chord/NTT
        // translation. Guitar triggers may own several currently sounding
        // strings. Pending strings and skipped notes own no pressure target.
        std::array<std::uint64_t,2> emitted{};
        const auto send=[&](int key){
            if(key<0||key>127)return;
            const auto word=static_cast<std::size_t>(key/64);
            const auto bit=std::uint64_t{1}<<static_cast<unsigned>(key%64);
            if((emitted[word]&bit)!=0U)return;
            emitted[word]|=bit;
            cb.midi(player,track,event.status,static_cast<std::uint8_t>(key),event.data2);
        };
        const auto mapped=p.active[static_cast<std::size_t>(track)][event.data1];
        if(mapped!=0U)send(static_cast<int>(mapped)-1);
        for(const auto& string:p.guitars[static_cast<std::size_t>(track)].strings)
            if(string.sourceKey==event.data1)send(string.pitch);
        return;
    }
    if((event.status&0xf0U)==0xb0U){
        auto& damper=p.styleDamper[static_cast<std::size_t>(track)];
        if(event.data1==64){
            damper=event.data2;
            if((p.muteMask&(1U<<track))&&!cb.rendersTrackMutes())return;
        }else if(event.data1==120 || event.data1==121 || event.data1==123){
            // The style sampler consumes CC64 for pedal-up. CC121 alone does
            // not release a sustained voice in that existing backend.
            if(event.data1==121 && damper>=64)cb.midi(player,track,0xb0,64,0);
            damper=0;
        }
    }
    cb.midi(player,track,event.status,event.data1,event.data2);
}
void ArrangerEngine::emitNative(int player,int tr,const MidiEvent& event,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto* sec=section(p);
    if(!sec)return;
    const auto& pattern=sec->patterns[static_cast<std::size_t>(tr)];
    if(p.manualBass&&tr==2){const auto kind=event.status&0xf0U;if(kind!=0x80U&&kind!=0x90U)sendStyleMessage(player,tr,event,cb);return;}
    const int cvIndex=p.cursors[static_cast<std::size_t>(tr)].cv;
    if(cvIndex<0)return;
    const auto& cv=pattern.cvs[static_cast<std::size_t>(cvIndex)];
    const auto type=static_cast<std::uint8_t>(event.status&0xF0U);
    if(p.guitars[static_cast<std::size_t>(tr)].enabled&&(type==0x90U||type==0x80U)){
        guitarEvent(player,tr,pattern,cv,event,cb);
    }else if(type==0x90U&&event.data2>0){
        if((p.muteMask&(1U<<tr))&&!cb.rendersTrackMutes())return;
        const int key=nativeNote(pattern,cv,event.data1,chord_,p.style->tracks[static_cast<std::size_t>(tr)].role,p.samplePlaybackMode,cb.phraseRange(p.styleCommitToken,p.element,tr));
        phraseNote(player,tr,event.data1,key,event.data2,0,cb);
    }else if(type==0x80U||(type==0x90U&&event.data2==0)){
        phraseNote(player,tr,event.data1,-1,0,type==0x90U?64U:event.data2,cb);
    }else if(type==0xB0U&&(event.data1==120U||event.data1==123U)){
        const auto track=static_cast<std::size_t>(tr);
        p.active[track].fill(0);
        p.velocities[track].fill(0);
        p.outputOwners[track].fill(0);
        p.harmonyExtra[track]=0;
        p.guitars[track].strings={};
        sendStyleMessage(player,tr,event,cb);
    }else if(cb.rendersTrackMutes() || (p.muteMask&(1U<<tr))==0 || type==0xC0U || styleDamperMessage(type,event.data1) ||
        (type==0xB0U && (event.data1==0 || event.data1==32 || mixController(event.data1))))
        sendStyleMessage(player,tr,event,cb);
}
void ArrangerEngine::drainPatternEvents(int player,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];const auto* sec=section(p);
    if(!sec||!sec->nativePatterns)return;
    for(int tr=0;tr<kTracks;++tr){
        const auto& pattern=sec->patterns[static_cast<std::size_t>(tr)];auto& cursor=p.cursors[static_cast<std::size_t>(tr)];
        if(cursor.cv<0)continue;
        const auto& cv=pattern.cvs[static_cast<std::size_t>(cursor.cv)];if(!cv.available)continue;
        for(;;){
            // Host settings are atomic UI edits, not queued engine commands.
            // Observe them even during a rest, before any scheduled attack.
            configureGuitar(player,tr,pattern,&cv,cb);
            bool noteChanged=false;
            while(cursor.eventIndex<cv.events.size()&&cv.events[cursor.eventIndex].tick<=cursor.tick+1e-7){
                const auto& event=cv.events[cursor.eventIndex++];const auto type=event.status&0xf0U;
                noteChanged|=type==0x90U||type==0x80U;
                emitNative(player,tr,event,cb);
            }
            if(noteChanged&&cursor.tick+1e-7<cv.lengthTicks)refreshHarmonyExtension(player,tr,cb);
            while(cursor.tempoIndex<cv.tempoEvents.size()&&cv.tempoEvents[cursor.tempoIndex].tick<=cursor.tick+1e-7){
                // Locked tempo-event policy needs physical Pa5X calibration;
                // until then keep the explicitly selected locked tempo stable.
                const auto tempo=cv.tempoEvents[cursor.tempoIndex++].bpm;
                if(!tempoLock_)setTempo(player,tempo);
            }
            if(cursor.tick+1e-7<cv.lengthTicks){drainGuitarEvents(player,tr,cb);break;}
            silence(player,cb,tr);cursor.tick=std::max(0.0,cursor.tick-cv.lengthTicks);
            cursor.eventIndex=0;cursor.tempoIndex=0;
            // The CV has its own loop, independent of the section boundary.
            // Rebuild the original per-track bank/PC state as at section
            // start. A pending bank or a later PC must never select a wrong
            // sample program at tick zero. Restore all recorded setup state,
            // including FX/AMS controls and pitch; never replay setup notes.
            cb.patternStart(player,tr);
            for(const auto& setup:pattern.setupEvents){
                const auto type=setup.status&0xf0U;
                if(type!=0x80U&&type!=0x90U)sendStyleMessage(player,tr,setup,cb);
            }
        }
    }
}
double ArrangerEngine::patternBoundary(const Player& p) const noexcept {
    const auto* sec=section(p);if(!sec)return 0;
    double result=0;
    for(int tr=0;tr<kTracks;++tr){
        const int index=p.cursors[static_cast<std::size_t>(tr)].cv;
        if(index<0)continue;
        const auto& cv=sec->patterns[static_cast<std::size_t>(tr)].cvs[static_cast<std::size_t>(index)];
        if(cv.available)result=std::max(result,static_cast<double>(cv.lengthTicks));
    }
    return result>0?result:sec->lengthTicks;
}
void ArrangerEngine::begin(int player,Element element,RenderCallbacks& cb) noexcept {
    beginAt(player,element,0.0,cb);
}
void ArrangerEngine::beginAt(int player,Element element,double tick,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    if(!p.style||element==Element::Count||!p.style->sections[static_cast<std::size_t>(element)].available){cb.liveEvent({"SECTION_UNAVAILABLE",player});p.playing=false;return;}
    silence(player,cb);p.element=element;p.tick=std::max(0.0,tick);p.eventIndex=0;p.queued=Element::Count;p.cursors={};
    const auto* sec=section(p);
    selectPatternCvs(player,cb,p.tick<=1e-7);
    if(sec&&!sec->nativePatterns&&p.tick>1e-7){
        // A Fill entered during the current measure keeps that measure's phase.
        // Restore setup/controller state without replaying earlier notes.
        while(p.eventIndex<sec->events.size()&&sec->events[p.eventIndex].tick+1e-7<p.tick){
            auto event=sec->events[p.eventIndex++];
            if(restoreStyleState(event))sendStyleMessage(player,event.track,event,cb);
        }
    }
}
void ArrangerEngine::boundary(int player,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    if(p.queued!=Element::Count){const Element next=p.queued;begin(player,next,cb);return;}
    if(p.loopElement==p.element){begin(player,p.element,cb);return;}
    if(ending(p.element)){
        // A prepared successor must not be stranded by an outgoing Ending.
        // Normally the old bar handoff runs first; a shorter Ending hands over
        // at its own natural end rather than stopping the transport.
        if(p.pendingStyle){const auto* next=p.pendingStyle;commitStyle(player,*next,true,cb);return;}
        cb.liveEvent({"ENDING_COMPLETE",player});silence(player,cb);p.playing=false;p.fadeDirection=0;p.fadeGain=1.0;p.tick=0;p.eventIndex=0;return;
    }
    if(!variation(p.element)){
        const Element next=p.returnTo!=Element::Count?p.returnTo:firstVariation(p.style);
        begin(player,next,cb);return;
    }
    begin(player,p.element,cb);
}
void ArrangerEngine::emit(int player,const MidiEvent& event,RenderCallbacks& cb) noexcept {
    auto& p=players_[static_cast<std::size_t>(player)];
    const int tr=event.track;const auto type=static_cast<std::uint8_t>(event.status&0xF0U);
    if(p.manualBass&&tr==2){if(type!=0x80U&&type!=0x90U)sendStyleMessage(player,tr,event,cb);return;}
    if(type==0x90&&event.data2>0){
        if((p.muteMask&(1U<<tr))&&!cb.rendersTrackMutes())return;
        const TrackRole role=p.style->tracks[static_cast<std::size_t>(tr)].role;
        const bool pitched=role!=TrackRole::Drums&&role!=TrackRole::Percussion;
        const int key=pitched&&!chord_.valid()?-1:transposeNote(event.data1,*p.style,chord_,role,cb.phraseRange(p.styleCommitToken,p.element,tr));
        phraseNote(player,tr,event.data1,key,event.data2,0,cb);
    }else if(type==0x80||(type==0x90&&event.data2==0)){
        phraseNote(player,tr,event.data1,-1,0,type==0x90U?64U:event.data2,cb);
    }else if(type==0xB0U&&(event.data1==120U||event.data1==123U)){
        const auto track=static_cast<std::size_t>(tr);
        p.active[track].fill(0);
        p.velocities[track].fill(0);
        p.outputOwners[track].fill(0);
        sendStyleMessage(player,tr,event,cb);
    }else if(cb.rendersTrackMutes() || (p.muteMask&(1U<<tr))==0 || styleDamperMessage(type,event.data1) || (type==0xB0U&&mixController(event.data1)))
        sendStyleMessage(player,tr,event,cb);
}
bool ArrangerEngine::anyDamperDown() const noexcept {
    for (const bool down : damperDown_) if (down) return true;
    return false;
}
void ArrangerEngine::normalizeChordControls() noexcept {
    if (!splitEnabled_ && recognitionMode_ == ChordRecognitionMode::OneFinger)
        recognitionMode_ = ChordRecognitionMode::FingeredThreeNotes;
    if (scanArea_ != 0) previousScanArea_ = scanArea_;
    if (!damperLatch_ || scanArea_ == 0) chordLatched_ = false;
}
bool ArrangerEngine::scansKey(int key) const noexcept {
    // The displayed split key is the last Lower key: C4 (MIDI 60) must
    // still control accompaniment. Upper starts at the following semitone.
    return scanArea_!=0 && (scanArea_==3 || !splitEnabled_ || (scanArea_==1 ? key<=split_ : key>split_));
}
void ArrangerEngine::observeMidi(int status,int data1,int data2,RenderCallbacks& cb,bool deferRecognition) noexcept {
    const int type=status&0xF0,ch=status&15;
    const bool attack=type==0x90 && data2>0;
    if(attack&&pendingVelocityKey_<0)velocityWasPlaying_=players_[static_cast<std::size_t>(velocityPlayer_)].playing;
    if(type==0xB0 && (data1==64 || data1==121)){
        const bool wasDown=anyDamperDown();
        const bool wasLatched=chordLatched_;
        damperDown_[static_cast<std::size_t>(ch)]=data1==64 && data2>=64;
        const bool nowDown=anyDamperDown();
        if(damperLatch_ && !wasDown && nowDown && chord_.valid()){
            chordLatched_=true;latchAttacks_={};
        }
        if(!nowDown)chordLatched_=false;
        if(wasLatched && !chordLatched_){
            const bool newKeys=latchAttacks_[0]|latchAttacks_[1]|latchAttacks_[2]|latchAttacks_[3];
            refreshChord(cb,newKeys?ScanReason::Control:ScanReason::Recovery);
            latchAttacks_={};
        }
        cb.liveEvent({data1==64?"DAMPER":"MIDI",-1,status,data1,data2,static_cast<int>(recognitionMode_),scanArea_,split_,scannedNotes_,lastDetected_,chord_});
        return;
    }else if(type==0xB0&&(data1==120||data1==123)){
        held_[static_cast<std::size_t>(ch)].fill(0);heldVelocity_[static_cast<std::size_t>(ch)].fill(0);
        // The host uses these as channel safety releases (including a MIDI
        // disconnect). Its sampler clears sustain too. Match that contract:
        // an unplugged pedal must not latch the old harmony indefinitely.
        damperDown_[static_cast<std::size_t>(ch)]=false;
        if(!anyDamperDown()){chordLatched_=false;latchAttacks_={};}
    }else if((type==0x80||(type==0x90&&data2==0))&&data1>=0&&data1<128){
        auto& held=held_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(data1)];if(held>0)--held;if(!held)heldVelocity_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(data1)]=0;
    }else if(type==0x90&&data2>0&&data1>=0&&data1<128){
        auto& held=held_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(data1)];if(held<255)++held;heldVelocity_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(data1)]=static_cast<std::uint8_t>(data2);
    }else return;
    const bool keyEvent=type==0x80 || type==0x90;
    const bool inZone=keyEvent && scansKey(data1);
    if(inZone){
        const auto word=static_cast<unsigned>(data1)/32;
        const auto bit=1U<<(data1%32);
        if(attack){
            transition_.attack(scannedNotes_,data1,chord_.valid());
            if(chordLatched_)latchAttacks_[word]|=bit;
            scannedNotes_[word]|=bit;
        }else if(std::none_of(held_.begin(),held_.end(),[data1](const auto& channel){return channel[static_cast<std::size_t>(data1)]>0;})){
            if(scannedNotes_[word]&bit)transition_.release(data1);
            latchAttacks_[word]&=~bit;
            scannedNotes_[word]&=~bit;
        }
    }else if(!keyEvent){
        transition_.clear();
    }
    if(!deferRecognition && (!keyEvent || inZone))
        refreshChord(cb,attack?ScanReason::Attack:ScanReason::Release);
    if(attack&&data1<=split_&&data2>pendingVelocityValue_){pendingVelocityKey_=data1;pendingVelocityValue_=data2;}
    if(!deferRecognition){
        if(pendingVelocityKey_>=0)velocityGesture(true,pendingVelocityKey_,pendingVelocityValue_,cb);
        pendingVelocityKey_=-1;pendingVelocityValue_=0;
        if(!attack)velocityGesture(false,keyEvent?data1:-1,data2,cb);
    }
    cb.liveEvent({"MIDI",-1,status,data1,data2,static_cast<int>(recognitionMode_),scanArea_,split_,scannedNotes_,lastDetected_,chord_});
}
void ArrangerEngine::velocityGesture(bool attack,int key,int velocity,RenderCallbacks& cb) noexcept {
    // The gesture is armed once per Lower-hand chord, rather than once per
    // note. A multi-note chord must never toggle START or MEMORY repeatedly.
    if(!attack){
        if(!velocityTriggered_)return;
        bool down=false;
        for(const auto& channel:held_)for(int k=0;k<=split_;++k)if(channel[static_cast<std::size_t>(k)]){down=true;break;}
        if(!down)velocityTriggered_=false;
        return;
    }
    if(!splitEnabled_||key>split_||velocityControl_==0||velocity<=velocityThreshold_||velocityTriggered_)return;
    velocityTriggered_=true;
    const int player=velocityPlayer_;
    auto& state=players_[static_cast<std::size_t>(player)];
    switch(velocityControl_){
        case 1:
            if(state.playing&&state.style&&state.style->sections[static_cast<std::size_t>(Element::Break)].available)
                handle({CommandType::SelectElement,player,static_cast<int>(Element::Break)},cb);
            break;
        case 2:
            if(state.playing&&!velocityWasPlaying_)break; // Synchro Start already performed this gesture
            if(state.playing||(state.style&&cb.canStartFromVelocity(player)))handle({CommandType::TogglePlay,player},cb);
            break;
        case 3:handle({CommandType::ToggleBassInversion},cb);cb.velocityPreferenceChanged();break;
        case 4:handle({CommandType::ToggleMemory},cb);cb.velocityPreferenceChanged();break;
        default:break;
    }
}
void ArrangerEngine::applyChord(Chord found,RenderCallbacks& cb) noexcept {
    if(sequenceMode_==ChordSequenceMode::Recording&&found.valid())recordSequenceChord(found);
    const bool harmonyChanged=found.root!=chord_.root || found.type!=chord_.type;
    const bool bassChanged=found.bass!=chord_.bass;
    const bool stopPitched=!found.valid()&&(scanArea_==0||!holdsChord());
    const bool closePitchedGate=stopPitched&&!pitchedGateClosed_;
    pitchedGateClosed_=stopPitched;
    chord_=found;
    if(!harmonyChanged&&!bassChanged&&!closePitchedGate)return;
    for(int player=0;player<kPlayers;++player){
        auto& p=players_[static_cast<std::size_t>(player)];if(!p.playing||!p.style)continue;
        const auto* sec=section(p);if(sec&&sec->nativePatterns)selectPatternCvs(player,cb,false);
        for(int tr=0;tr<kTracks;++tr){
            if(p.manualBass&&tr==2)continue;
            const auto role=p.style->tracks[static_cast<std::size_t>(tr)].role;
            const bool native=sec&&sec->nativePatterns;
            const TrackPattern* pattern=native?&sec->patterns[static_cast<std::size_t>(tr)]:nullptr;
            const bool guitar=pattern&&p.guitars[static_cast<std::size_t>(tr)].enabled;
            if(pattern&&pattern->mode==NativePatternMode::Drum)continue;
            if(!native&&(role==TrackRole::Drums||role==TrackRole::Percussion))continue;
            if(!harmonyChanged&&!stopPitched&&role!=TrackRole::Bass&&!guitar)continue;
            const auto track=static_cast<std::size_t>(tr);
            const auto cvIndex=p.cursors[track].cv;
            const auto* cv=pattern&&cvIndex>=0?&pattern->cvs[static_cast<std::size_t>(cvIndex)]:nullptr;
            if(guitar)releaseGuitarVoices(player,tr,cb,true);
            const auto targetChord=guitar&&cv?guitarChord(p,tr,*cv):found;
            auto& owners=p.outputOwners[track];
            const auto range=cb.phraseRange(p.styleCommitToken,p.element,tr);
            const auto previous=owners;
            owners.fill(0);
            std::array<std::uint8_t,128> attacks{};
            for(std::size_t key=0;key<128;++key){
                const auto velocity=p.velocities[track][key];
                if(!velocity)continue;
                if(guitar&&key>=96&&stopPitched)p.velocities[track][key]=0;
                int target=-1;
                if(!p.suppressAccompaniment(tr)&&found.valid() && (cb.rendersTrackMutes()||!(p.muteMask&(1U<<tr)))){
                    if(!pattern)target=transposeNote(static_cast<int>(key),*p.style,found,role,range);
                    else if(cv&&cv->available){
                        if(guitar&&key>=96)target=static_cast<int>(key);
                        else target=nativeNote(*pattern,*cv,static_cast<int>(key),targetChord,guitar?TrackRole::Accompaniment:role,p.samplePlaybackMode,range,guitar);
                    }
                }
                p.active[track][key]=static_cast<std::uint16_t>(target+1);
                if(target>=0){
                    const auto pitch=static_cast<std::size_t>(target);
                    ++owners[pitch];
                    attacks[pitch]=std::max(attacks[pitch],velocity);
                }
            }
            std::uint8_t extensionVelocity=0;
            const int extension=harmonyExtension(p,tr,cb,extensionVelocity);
            p.harmonyExtra[track]=static_cast<std::uint16_t>(extension+1);
            if(extension>=0){const auto k=static_cast<std::size_t>(extension);++owners[k];attacks[k]=std::max(attacks[k],extensionVelocity);}
            const auto pedal=p.styleDamper[track];
            if(pedal>=64)cb.midi(player,tr,0xb0,64,0);
            // Release vanished pitches before any new attack. Common notes
            // keep their envelope even when another source key now owns them.
            for(std::size_t key=0;key<128;++key)
                if(previous[key]&&!owners[key])cb.midi(player,tr,0x80,static_cast<std::uint8_t>(key),0);
            if(pedal>=64 && found.valid() && (cb.rendersTrackMutes()||!(p.muteMask&(1U<<tr))))
                cb.midi(player,tr,0xb0,64,pedal);
            for(std::size_t key=0;key<128;++key)
                if(!previous[key]&&owners[key])cb.midi(player,tr,0x90,static_cast<std::uint8_t>(key),attacks[key]);
        }
    }
}
void ArrangerEngine::refreshChord(RenderCallbacks& cb,ScanReason reason) noexcept {
    if(reason==ScanReason::Control || reason==ScanReason::Recovery)transition_.clear();
    std::array<bool,128> scan{};
    int heldKeyCount=0;
    scannedNotes_={};
    for(int key=0;key<128;++key){
        if(scanArea_==0)break;
        if(!scansKey(key))continue;
        for(const auto& channel:held_)if(channel[static_cast<std::size_t>(key)]>0){scan[static_cast<std::size_t>(key)]=true;++heldKeyCount;
            const auto midiKey=static_cast<unsigned>(key);scannedNotes_[midiKey/32]|=1U<<(midiKey%32);break;}
    }
    const bool keysDown=heldKeyCount!=0;
    for(std::size_t i=0;i<latchAttacks_.size();++i)latchAttacks_[i]&=scannedNotes_[i];
    if(!keysDown)transition_.clear();
    lastDetected_={};
    chordKeysDown_=keysDown;
    if((reason==ScanReason::Attack||reason==ScanReason::Release)&&scanArea_!=0)for(int player=0;player<kPlayers;++player){
        auto& state=players_[static_cast<std::size_t>(player)];
        if(player==sequencePlayer_&&(sequenceMode_==ChordSequenceMode::Playing||sequenceMode_==ChordSequenceMode::PlayArmed))continue;
        if(!state.syncStop)continue;
        if(keysDown)state.syncStopReady=true;
        else if(state.playing&&state.syncStopReady){
            cb.liveEvent({"SYNC_STOP_KEYS_UP",player});silence(player,cb);state.playing=false;state.syncStopReady=false;state.fadeDirection=0;state.fadeGain=1.0;
            state.tick=0;state.eventIndex=0;commitStoppedSelection(player,cb);
        }
    }
    if(scanArea_==0){chordLatched_=false;if(sequenceMode_!=ChordSequenceMode::Playing)applyChord({},cb);return;}
    const bool simplifiedAllowed=splitEnabled_ && scanArea_==1;
    const Chord found=recognizeChord(scan,recognitionMode_,simplifiedAllowed,bassInversion_,chord_);
    lastDetected_=found;
    if(sequenceMode_==ChordSequenceMode::Playing)return; // physical solo keys never replace the playback harmony
    if(damperLatch_ && chordLatched_ && anyDamperDown())return;
    // The key scan and Sync Stop still see every release. Memory holds the
    // last sounded chord (and slash bass) while the hand lifts in stages.
    const bool releaseOnly=(reason==ScanReason::Release && !transition_.resolving()) || reason==ScanReason::Recovery;
    applyChord(chordAfterScan(chord_,found,holdsChord(),releaseOnly),cb);
    if(reason==ScanReason::Release && !releaseOnly && found.valid()){
        // A settled triad must survive the remainder of the lift too. The
        // shortcut modes can still need their older modifier keys to clear.
        const bool shortcut=recognitionMode_==ChordRecognitionMode::OneFinger ||
                            recognitionMode_==ChordRecognitionMode::OneFingerPlus;
        if(heldKeyCount==1 || (!shortcut && heldKeyCount<=3))transition_.clear();
    }
    if(reason==ScanReason::Attack && found.valid())for(int player=0;player<kPlayers;++player){auto& state=players_[static_cast<std::size_t>(player)];if(state.syncStart&&!state.playing&&state.style){state.playing=true;if(syncStartAutoOff_)state.syncStart=false;state.syncStopReady=keysDown;state.fadeDirection=0;state.fadeGain=1.0;begin(player,state.element,cb);}}
}

void ArrangerEngine::handle(const Command& c,RenderCallbacks& cb) noexcept {
    if(c.type==CommandType::ToggleSequenceRecord||c.type==CommandType::ToggleSequencePlay||
       c.type==CommandType::ClearSequence||c.type==CommandType::ToggleSequenceLock){sequenceCommand(c,cb);return;}
    if(c.type==CommandType::Panic){if(sequenceMode_==ChordSequenceMode::Recording)finishSequenceRecording();sequenceMode_=ChordSequenceMode::Idle;sequenceCurrent_=-1;sequenceDirty_=true;}
    if(c.type==CommandType::Midi){if(std::isfinite(c.value)&&c.value>=0&&c.value<=127&&c.data2>=0&&c.data2<=127)observeMidi(c.index,static_cast<int>(c.value),c.data2,cb);return;}
    if(c.type==CommandType::Panic){cb.liveEvent({"PANIC"});for(int p=0;p<kPlayers;++p){setManualBass(p,false,cb);silence(p,cb,-1,true,false);auto& state=players_[static_cast<std::size_t>(p)];state.playing=false;state.syncStart=false;state.syncStop=false;state.syncStopReady=false;state.loopElement=Element::Count;state.fadeDirection=0;state.fadeGain=1.0;commitStoppedSelection(p,cb);}for(auto& h:held_)h.fill(0);for(auto& h:heldVelocity_)h.fill(0);velocityTriggered_=false;pendingVelocityKey_=-1;pendingVelocityValue_=0;damperDown_.fill(false);chordLatched_=false;chordKeysDown_=false;chord_={};lastDetected_={};scannedNotes_={};transition_.clear();latchAttacks_={};return;}
    if(c.type==CommandType::SetVelocityControl){
        if(c.player>=0&&c.player<kPlayers&&c.index>=0&&c.index<=4&&std::isfinite(c.value)&&c.value>=1&&c.value<=127&&std::floor(c.value)==c.value){
            velocityControl_=c.index;velocityThreshold_=static_cast<int>(c.value);velocityPlayer_=c.player;
            velocityTriggered_=false;pendingVelocityKey_=-1;pendingVelocityValue_=0;
        }
        return;
    }
    if(c.type==CommandType::SetSplit){if(std::isfinite(c.value))split_=static_cast<int>(std::clamp(c.value,1.0,127.0));refreshChord(cb);return;}
    if(c.type==CommandType::SetKeyboardSplit){
        if(!std::isfinite(c.value)||c.value<1||c.value>127||std::floor(c.value)!=c.value||(c.index!=0&&c.index!=1))return;
        // The panel SPLIT state is shared by sound zones and recognition rules.
        // CHORD Lower/Upper selection remains an independent recognition area.
        split_=static_cast<int>(c.value);splitEnabled_=c.index!=0;
        chordLatched_=false;normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::ApplyKeyboardRecall){
        if(c.player!=0||c.data2<=0||static_cast<std::uint32_t>(c.data2)>0x7fffffffU||c.sourceStyle!=nullptr||
           !std::isfinite(c.value)||c.value<1||c.value>127||std::floor(c.value)!=c.value||
           c.index<0||c.index>63)return;
        const int flags=c.index,area=(flags>>2)&3;
        const bool hasScan=(flags&2)!=0,hasBass=(flags&16)!=0;
        if((!hasScan&&area!=0)||(!hasBass&&(flags&32)!=0))return;
        // One ordered recall changes only explicitly supplied fields. Other
        // controls retain their current audio-owned values, including changes
        // already queued before this recall but not yet visible to the UI.
        split_=static_cast<int>(c.value);splitEnabled_=(flags&1)!=0;
        if(hasScan)scanArea_=area;
        if(hasBass)bassInversion_=(flags&32)!=0;
        chordLatched_=false;normalizeChordControls();refreshChord(cb);
        lastKeyboardRecallSerial_=static_cast<std::uint32_t>(c.data2);return;
    }
    if(c.type==CommandType::SetMemoryMode){if(c.value==0.0||c.value==1.0||c.value==2.0){memoryMode_=static_cast<int>(c.value);refreshChord(cb);}return;}
    if(c.type==CommandType::SetMemory||c.type==CommandType::ToggleMemory){memory_=c.type==CommandType::ToggleMemory?!memory_:c.value!=0;refreshChord(cb);return;}
    if(c.type==CommandType::SetChordScan){
        if(c.value==0)scanArea_=0;else if(scanArea_==0)scanArea_=previousScanArea_;
        normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::SetChordRecognition){
        if(std::isfinite(c.value)&&c.value>=0&&c.value<=4&&std::floor(c.value)==c.value)
            recognitionMode_=static_cast<ChordRecognitionMode>(static_cast<int>(c.value));
        chordLatched_=false;normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::ToggleChordScanAreaBit){
        if(c.index!=1&&c.index!=2)return;
        // Physical CHORD LOWER/UPPER buttons toggle their audio-owned bits.
        // Two accepted presses retain queue order even before a UI repaint.
        scanArea_^=c.index;
        chordLatched_=false;normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::SetChordScanArea){
        if(std::isfinite(c.value)&&c.value>=0&&c.value<=3&&std::floor(c.value)==c.value)scanArea_=static_cast<int>(c.value);
        chordLatched_=false;normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::SetChordScanZone){
        // An explicit Lower/Upper UI choice means that split zone, even after
        // a saved full-keyboard recognition configuration. Publish both in
        // one command; the keyboard's sound SPLIT remains independent.
        if(c.value!=1.0&&c.value!=2.0)return;
        scanArea_=static_cast<int>(c.value);splitEnabled_=true;
        chordLatched_=false;normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::SetSplitEnabled||c.type==CommandType::ToggleChordSplit){splitEnabled_=c.type==CommandType::ToggleChordSplit?!splitEnabled_:c.value!=0;chordLatched_=false;normalizeChordControls();refreshChord(cb);return;}
    if(c.type==CommandType::SetBassInversion||c.type==CommandType::ToggleBassInversion){bassInversion_=c.type==CommandType::ToggleBassInversion?!bassInversion_:c.value!=0;chordLatched_=false;refreshChord(cb);return;}
    if(c.type==CommandType::SetDamperLatch||c.type==CommandType::ToggleDamperLatch){damperLatch_=c.type==CommandType::ToggleDamperLatch?!damperLatch_:c.value!=0;chordLatched_=damperLatch_&&anyDamperDown()&&chord_.valid();latchAttacks_={};refreshChord(cb);return;}
    if(c.type==CommandType::ApplyChordControls){
        if(!std::isfinite(c.value)||c.value<0||c.value>6143||std::floor(c.value)!=c.value||
           c.index<0||c.index>4||c.data2<0||c.data2>3)return;
        const auto flags=static_cast<unsigned>(c.value);
        if((flags&127U)==0)return;
        recognitionMode_=static_cast<ChordRecognitionMode>(c.index);scanArea_=c.data2;
        split_=static_cast<int>(flags&127U);memory_=(flags&128U)!=0;memoryMode_=static_cast<int>((flags>>11)&3U);
        splitEnabled_=(flags&256U)!=0;bassInversion_=(flags&512U)!=0;damperLatch_=(flags&1024U)!=0;
        chordLatched_=false;normalizeChordControls();refreshChord(cb);return;
    }
    if(c.type==CommandType::SetTempoLock||c.type==CommandType::ToggleTempoLock){
        if(c.player<0||c.player>=kPlayers)return;
        tempoLock_=c.type==CommandType::ToggleTempoLock?!tempoLock_:c.value!=0;
        if(tempoLock_){lockedTempo_=players_[static_cast<std::size_t>(c.player)].tempo;for(auto& p:players_)p.tempo=lockedTempo_;}
        return;
    }
    if(c.type==CommandType::SetAutoFill||c.type==CommandType::ToggleAutoFill){
        autoFill_=c.type==CommandType::ToggleAutoFill?!autoFill_:c.value!=0;
        for(auto& player:players_)player.autoFill=autoFill_;
        return;
    }
    if(c.type==CommandType::SetAutoFillMode||c.type==CommandType::CycleAutoFillMode){
        if(c.type==CommandType::CycleAutoFillMode)autoFillMode_=autoFillMode_==0?1:0;
        else if(c.value==0.0||c.value==1.0)autoFillMode_=static_cast<int>(c.value);
        return;
    }
    if(c.type==CommandType::SetSyncStartAutoOff||c.type==CommandType::ToggleSyncStartAutoOff){syncStartAutoOff_=c.type==CommandType::ToggleSyncStartAutoOff?!syncStartAutoOff_:c.value!=0;return;}
    if(c.type==CommandType::SetFadeTimes){
        if(std::isfinite(c.value)&&c.value>=0.1&&c.value<=60&&c.index>=100&&c.index<=60000){fadeInSeconds_=static_cast<float>(c.value);fadeOutSeconds_=static_cast<float>(c.index)/1000.0F;}
        return;
    }
    if(c.type==CommandType::AdjustFadeTimes){
        if(std::isfinite(c.value)&&c.value>=-60&&c.value<=60&&c.index>=-60000&&c.index<=60000){
            fadeInSeconds_=std::clamp(fadeInSeconds_+static_cast<float>(c.value),0.1F,60.0F);
            fadeOutSeconds_=std::clamp(fadeOutSeconds_+static_cast<float>(c.index)/1000.0F,0.1F,60.0F);
        }
        return;
    }
    if(c.player<0||c.player>=kPlayers)return;
    auto& p=players_[static_cast<std::size_t>(c.player)];
    switch(c.type){
        case CommandType::StartWithTempo:
            if(!p.playing&&p.style&&c.sourceStyle==p.style&&std::isfinite(c.value)&&c.value>=20&&c.value<=400){
                setTempo(c.player,c.value);p.playing=true;p.syncStart=false;p.syncStopReady=chordKeysDown_;p.fadeDirection=0;p.fadeGain=1.0;
                if(!section(p))p.element=firstPlayableElement(p.style);
                ++p.transportMeasure;begin(c.player,p.element,cb);
            }
            break;
        case CommandType::ResetPosition:
            if(p.playing&&p.style&&c.sourceStyle==p.style){++p.transportMeasure;begin(c.player,p.element,cb);}
            break;
        case CommandType::Play:case CommandType::TogglePlay:{
            if(c.type==CommandType::TogglePlay&&p.playing){cb.liveEvent({"STOP_TOGGLE",c.player});silence(c.player,cb);p.playing=false;p.syncStart=false;p.loopElement=Element::Count;p.fadeDirection=0;p.fadeGain=1.0;commitStoppedSelection(c.player,cb);break;}
            if(p.style){p.playing=true;p.syncStart=false;p.syncStopReady=chordKeysDown_;p.fadeDirection=0;p.fadeGain=1.0;if(!section(p))p.element=firstPlayableElement(p.style);begin(c.player,p.element,cb);}break;}
        case CommandType::Stop:cb.liveEvent({"STOP_COMMAND",c.player});silence(c.player,cb);p.playing=false;p.syncStart=false;p.syncStopReady=false;p.loopElement=Element::Count;p.fadeDirection=0;p.fadeGain=1.0;p.tick=0;p.eventIndex=0;commitStoppedSelection(c.player,cb);break;
        case CommandType::Fade:
            if(c.sourceStyle!=p.style||!p.style)break;
            if(!p.playing){p.fadeGain=0.0;p.fadeDirection=1;p.playing=true;p.syncStart=false;p.syncStopReady=chordKeysDown_;if(!section(p))p.element=firstPlayableElement(p.style);begin(c.player,p.element,cb);}
            else p.fadeDirection=-1;
            break;
        case CommandType::ToggleSectionLoop:{
            const auto selected=p.queued!=Element::Count?p.queued:p.element;
            if(selected!=Element::Count&&!variation(selected))p.loopElement=p.loopElement==selected?Element::Count:selected;
            break;}
        case CommandType::SelectElement:{
            if(c.index<0||c.index>=static_cast<int>(Element::Count)||!p.style||!p.style->sections[static_cast<std::size_t>(c.index)].available)break;
            const Element selected=static_cast<Element>(c.index);
            const bool repeated=p.lastElementPress==selected;p.lastElementPress=selected;
            if(!variation(selected)&&(p.element==selected||p.queued==selected)&&(p.loopElement==selected||repeated)){
                if(p.loopElement==selected){p.loopElement=Element::Count;p.lastElementPress=Element::Count;}
                else p.loopElement=selected;
                break;
            }
            p.loopElement=Element::Count;
            const bool manualFill=fill(selected)||selected==Element::Break;
            if(manualFill){
                const int slot=static_cast<int>(selected)-static_cast<int>(Element::Fill1);
                const int mode=cb.manualFillMode(p.styleCommitToken,slot);
                const Element before=variation(p.element)?p.element:p.returnTo;
                const int from=std::clamp(int(before)-int(Element::Var1),0,3);
                int to=from;
                if(mode>=1&&mode<=6){
                    constexpr int pair[6][2]={{0,1},{0,2},{0,3},{1,2},{1,3},{2,3}};
                    const auto& ab=pair[mode-1];
                    if(from==ab[0])to=ab[1];else if(from==ab[1])to=ab[0];
                }else if(mode==7)to=(from+1)%4;
                else if(mode==8)to=(from+3)%4;
                else if(mode==9)to=std::min(3,from+1);
                else if(mode==10)to=std::max(0,from-1);
                else if(mode>=11&&mode<=14)to=mode-11;
                const auto destination=static_cast<Element>(int(Element::Var1)+to);
                p.returnTo=p.style->sections[static_cast<std::size_t>(destination)].available?destination:before;
            }
            if(!p.playing){p.element=selected;if(variation(selected))p.returnTo=selected;break;}
            Element next=selected;
            if(variation(selected)){
                p.returnTo=selected;
                const auto fillVariation=autoFillMode_==0&&variation(p.element)?p.element:selected;
                const auto fill=static_cast<Element>(static_cast<int>(Element::Fill1)+static_cast<int>(fillVariation)-static_cast<int>(Element::Var1));
                if(p.autoFill&&variation(p.element)&&selected!=p.element&&p.style->sections[static_cast<std::size_t>(fill)].available)next=fill;
            }else if(!manualFill&&variation(p.element))p.returnTo=p.element;
            // Fills enter at the current measure position (Smart Fill Off,
            // manual p173). Ending3 starts immediately from its beginning
            // (p174). These commands are applied by the next audio block.
            if(fill(next)){
                const auto* current=section(p);
                const double phase=current?std::fmod(p.tick,measureTicks(*p.style,*current)):0.0;
                const auto& target=p.style->sections[static_cast<std::size_t>(next)];
                beginAt(c.player,next,std::fmod(phase,measureTicks(*p.style,target)),cb);break;
            }
            if(selected==Element::Ending3){begin(c.player,selected,cb);break;}
            p.queued=next;break;}
        case CommandType::SetTempo:if(std::isfinite(c.value))setTempo(c.player,std::clamp(c.value,20.0,400.0));break;
        case CommandType::SetSyncStart:case CommandType::ToggleSyncStart:
            // Toggle against audio-owned state, never the previous UI frame.
            // A host readiness flag may forbid arming while still allowing off.
            if(c.type==CommandType::ToggleSyncStart&&!p.syncStart&&c.value<0)break;
            p.syncStart=c.type==CommandType::ToggleSyncStart?!p.syncStart:c.value!=0;
            cb.liveEvent({c.type==CommandType::ToggleSyncStart?"SYNC_START_TOGGLE":"SYNC_START_SET",
                          c.player,-1,-1,p.syncStart?1:0});
            // Arming start only changes how a stopped player starts. An active
            // pattern, including any booked transition, keeps its clock.
            break;
        case CommandType::SetSyncStop:case CommandType::ToggleSyncStop:
            if(c.type==CommandType::ToggleSyncStop&&!p.syncStop&&c.value<0)break;
            p.syncStop=c.type==CommandType::ToggleSyncStop?!p.syncStop:c.value!=0;p.syncStopReady=p.syncStop&&chordKeysDown_;
            if(p.syncStop&&syncStartAutoOff_)p.syncStart=true;
            break;
        case CommandType::SetSamplePlaybackMode:
            if(c.sourceStyle!=p.style)break;
            if(p.samplePlaybackMode!=(c.value!=0)){
                silence(c.player,cb);p.samplePlaybackMode=c.value!=0;
                if(p.playing)selectPatternCvs(c.player,cb,true);
            }
            break;
        case CommandType::ToggleManualBass:setManualBass(c.player,!p.manualBass,cb);break;
        case CommandType::ToggleDrumBass:
            // Keep the transport and stored per-track mix intact. Release all
            // sounding/pedal-held ACC notes, cancel scheduled guitar strokes,
            // and continue to process original controller/program events.
            p.drumBassOnly=!p.drumBassOnly;
            if(p.drumBassOnly){
                for(int tr=3;tr<kTracks;++tr){
                    const auto pedal=p.styleDamper[static_cast<std::size_t>(tr)];
                    silence(c.player,cb,tr);
                    p.styleDamper[static_cast<std::size_t>(tr)]=pedal;
                }
            }else{
                for(int tr=3;tr<kTracks;++tr){
                    const auto pedal=p.styleDamper[static_cast<std::size_t>(tr)];
                    if(pedal>=64)cb.midi(c.player,tr,0xB0,64,pedal);
                }
            }
            break;
        case CommandType::SetTrackMute:
            if(c.sourceStyle&&c.sourceStyle!=p.style)break;
            if(c.index>=0 && c.index<kTracks){
                const auto bit=static_cast<std::uint8_t>(1U<<c.index);
                const auto track=static_cast<std::size_t>(c.index);
                const auto pedal=p.styleDamper[track];
                if(c.value!=0 && !(p.muteMask&bit)){
                    p.muteMask|=bit;
                    if(!cb.rendersTrackMutes()){silence(c.player,cb,c.index);p.styleDamper[track]=pedal;}
                }else if(c.value==0 && (p.muteMask&bit)){
                    p.muteMask=static_cast<std::uint8_t>(p.muteMask&~bit);
                    if(!cb.rendersTrackMutes()&&pedal>=64)cb.midi(c.player,c.index,0xb0,64,pedal);
                }
            }
            break;
        default:break;
    }
}
void ArrangerEngine::publish() noexcept {
    for(int i=0;i<kPlayers;++i){
        const auto& p=players_[static_cast<std::size_t>(i)];auto& out=published_[static_cast<std::size_t>(i)];
        out.revision.fetch_add(1,std::memory_order_acq_rel);
        out.pendingStyle.store(p.pendingStyle?p.pendingStyle->style:nullptr,std::memory_order_relaxed);
        out.styleCommitToken.store(p.styleCommitToken,std::memory_order_relaxed);
        out.pendingStyleCommitToken.store(p.pendingStyle?p.pendingStyle->commitToken:nullptr,std::memory_order_relaxed);
        out.blockedTrackMask.store(p.blockedTrackMask,std::memory_order_relaxed);
        out.transportMeasure.store(p.transportMeasure,std::memory_order_relaxed);
        out.syncStop.store(p.syncStop?1:0,std::memory_order_relaxed);out.loopElement.store(static_cast<int>(p.loopElement),std::memory_order_relaxed);
        out.fadeDirection.store(p.fadeDirection,std::memory_order_relaxed);out.fadeGain.store(static_cast<float>(p.fadeGain),std::memory_order_relaxed);
        out.returnVariation.store(static_cast<int>(p.returnTo),std::memory_order_relaxed);
        out.drumBassOnly.store(p.drumBassOnly,std::memory_order_relaxed);out.manualBass.store(p.manualBass,std::memory_order_relaxed);
        for(int track=0;track<kTracks;++track){
            const int cv=p.cursors[static_cast<std::size_t>(track)].cv;
            const auto* activeSection=section(p);
            const bool available=activeSection&&activeSection->nativePatterns&&cv>=0&&
                activeSection->patterns[static_cast<std::size_t>(track)].cvs[static_cast<std::size_t>(cv)].available;
            out.selectedCvs[static_cast<std::size_t>(track)].store(available?cv+1:0,std::memory_order_relaxed);
            const auto tick=available?std::clamp(p.cursors[static_cast<std::size_t>(track)].tick,
                0.0,static_cast<double>(std::numeric_limits<std::uint32_t>::max())):0.0;
            out.cvTicks[static_cast<std::size_t>(track)].store(static_cast<std::uint32_t>(tick),std::memory_order_relaxed);
        }
        out.style.store(p.style,std::memory_order_release);out.playing.store(p.playing,std::memory_order_relaxed);out.syncStart.store(p.syncStart,std::memory_order_relaxed);out.autoFill.store(p.autoFill,std::memory_order_relaxed);out.element.store(static_cast<int>(p.element),std::memory_order_relaxed);out.queued.store(static_cast<int>(p.queued),std::memory_order_relaxed);out.tempo.store(p.tempo,std::memory_order_relaxed);out.muteMask.store(p.muteMask,std::memory_order_relaxed);
        const Section* sec=section(p);
        if(sec){const double beats=p.tick/(static_cast<double>(p.style->ppq)*4.0/sec->denominator);out.bar.store(1U+static_cast<std::uint32_t>(beats/sec->numerator),std::memory_order_relaxed);out.beat.store(1U+static_cast<std::uint32_t>(beats)%sec->numerator,std::memory_order_relaxed);out.numerator.store(sec->numerator,std::memory_order_relaxed);out.denominator.store(sec->denominator,std::memory_order_relaxed);}
        out.chordRoot.store(chord_.root,std::memory_order_relaxed);
        out.chordType.store(static_cast<int>(chord_.type),std::memory_order_relaxed);
        out.chordBass.store(chord_.bass,std::memory_order_relaxed);
        out.revision.fetch_add(1,std::memory_order_release);
    }
    publishSequence();
    publishedManualBass_.store((players_[0].manualBass||players_[1].manualBass)?1:0,std::memory_order_release);
    publishedVelocity_.store(velocityControl_|(velocityThreshold_<<3)|(velocityPlayer_<<10),std::memory_order_release);
    publishedTempoLock_.store(tempoLock_?1:0,std::memory_order_relaxed);
    publishedAutoFillMode_.store(autoFillMode_,std::memory_order_relaxed);
    publishedSyncStartAutoOff_.store(syncStartAutoOff_,std::memory_order_relaxed);
    publishedFadeInSeconds_.store(fadeInSeconds_,std::memory_order_relaxed);publishedFadeOutSeconds_.store(fadeOutSeconds_,std::memory_order_relaxed);
    publishedRecognitionMode_.store(static_cast<int>(recognitionMode_),std::memory_order_relaxed);
    publishedScanArea_.store(scanArea_,std::memory_order_relaxed);
    publishedSplitEnabled_.store(splitEnabled_?1:0,std::memory_order_relaxed);
    publishedBassInversion_.store(bassInversion_?1:0,std::memory_order_relaxed);
    publishedDamperLatch_.store(damperLatch_?1:0,std::memory_order_relaxed);
    publishedSplit_.store(split_,std::memory_order_relaxed);publishedMemory_.store(memory_,std::memory_order_relaxed);publishedMemoryMode_.store(memoryMode_,std::memory_order_relaxed);publishedChordRoot_.store(chord_.root,std::memory_order_relaxed);publishedChordType_.store(static_cast<int>(chord_.type),std::memory_order_relaxed);publishedBass_.store(chord_.bass,std::memory_order_relaxed);
    // An acquired recall ACK must never precede the matching control values.
    publishedKeyboardRecallSerial_.store(lastKeyboardRecallSerial_,std::memory_order_release);
}
PlayerSnapshot ArrangerEngine::snapshot(int player) const noexcept {
    PlayerSnapshot result;if(player<0||player>=kPlayers)return result;
    const auto& out=published_[static_cast<std::size_t>(player)];
    // UI/control-thread snapshot: never combine one section's meter with a
    // different section/CV's Sound or tick during an audio publication.
    for(;;){
        const auto revision=out.revision.load(std::memory_order_acquire);
        if((revision&1U)!=0U)continue;
        result.style=out.style.load(std::memory_order_relaxed);
        result.pendingStyle=out.pendingStyle.load(std::memory_order_relaxed);
        result.styleCommitToken=out.styleCommitToken.load(std::memory_order_relaxed);
        result.pendingStyleCommitToken=out.pendingStyleCommitToken.load(std::memory_order_relaxed);
        result.playing=out.playing.load(std::memory_order_relaxed)!=0;
        result.syncStart=out.syncStart.load(std::memory_order_relaxed)!=0;
        result.syncStop=out.syncStop.load(std::memory_order_relaxed)!=0;
        result.loopElement=static_cast<Element>(out.loopElement.load(std::memory_order_relaxed));
        result.returnVariation=static_cast<Element>(out.returnVariation.load(std::memory_order_relaxed));
        result.fadeDirection=out.fadeDirection.load(std::memory_order_relaxed);result.fadeGain=out.fadeGain.load(std::memory_order_relaxed);
        result.autoFill=out.autoFill.load(std::memory_order_relaxed)!=0;
        result.drumBassOnly=out.drumBassOnly.load(std::memory_order_relaxed)!=0;result.manualBass=out.manualBass.load(std::memory_order_relaxed)!=0;
        result.transportMeasure=out.transportMeasure.load(std::memory_order_relaxed);
        result.element=static_cast<Element>(out.element.load(std::memory_order_relaxed));
        result.queued=static_cast<Element>(out.queued.load(std::memory_order_relaxed));
        result.tempoBpm=out.tempo.load(std::memory_order_relaxed);
        result.bar=out.bar.load(std::memory_order_relaxed);result.beat=out.beat.load(std::memory_order_relaxed);
        result.numerator=static_cast<std::uint8_t>(out.numerator.load(std::memory_order_relaxed));
        result.denominator=static_cast<std::uint8_t>(out.denominator.load(std::memory_order_relaxed));
        result.muteMask=static_cast<std::uint8_t>(out.muteMask.load(std::memory_order_relaxed));
        result.blockedTrackMask=static_cast<std::uint8_t>(out.blockedTrackMask.load(std::memory_order_relaxed));
        for(int track=0;track<kTracks;++track){
            result.selectedCvs[static_cast<std::size_t>(track)]=out.selectedCvs[static_cast<std::size_t>(track)].load(std::memory_order_relaxed);
            result.cvTicks[static_cast<std::size_t>(track)]=out.cvTicks[static_cast<std::size_t>(track)].load(std::memory_order_relaxed);
        }
        result.chord={out.chordRoot.load(std::memory_order_relaxed),static_cast<ChordType>(out.chordType.load(std::memory_order_relaxed)),out.chordBass.load(std::memory_order_relaxed)};
        std::atomic_thread_fence(std::memory_order_acquire);
        if(out.revision.load(std::memory_order_relaxed)==revision)return result;
    }
}
void ArrangerEngine::process(std::uint32_t frames,double sampleRate,RenderCallbacks& cb) noexcept {
    std::array<const StyleInstallation*,kPlayers*2> previousInstallations{};
    for(int i=0;i<kPlayers;++i){
        const auto index=static_cast<std::size_t>(i);
        previousInstallations[index*2]=players_[index].styleInstallation;
        previousInstallations[index*2+1]=players_[index].pendingStyle;
    }
    const std::array<bool,2> wasPlaying{{players_[0].playing,players_[1].playing}};
    const auto finishPublication=[&]() noexcept {
        for(std::size_t i=0;i<players_.size();++i)if(wasPlaying[i]!=players_[i].playing)
            cb.liveEvent({players_[i].playing?"STARTED":"STOPPED",static_cast<int>(i)});
        publish();
        // There is one incoming adoption per player per block. Any abandoned
        // audio-owned installation was therefore active/pending at block entry.
        // Publish first so borrowed snapshot pointers no longer refer to it.
        for(int i=0;i<kPlayers;++i){
            const auto index=static_cast<std::size_t>(i);const auto& p=players_[index];
            for(std::size_t slot=0;slot<2;++slot){
                const auto* previous=previousInstallations[index*2+slot];
                if(previous&&previous!=p.styleInstallation&&previous!=p.pendingStyle)
                    previous->retired.store(true,std::memory_order_release);
            }
        }
    };
    for(int i=0;i<kPlayers;++i){
        const auto* next=pending_[static_cast<std::size_t>(i)].exchange(nullptr,std::memory_order_acq_rel);
        if(next){
            auto& p=players_[static_cast<std::size_t>(i)];
            const auto* sec=section(p);
            if(next->quantized&&p.playing&&p.style&&sec){
                p.pendingStyle=next;
                const double bar=measureTicks(*p.style,*sec);
                p.styleSwitchTicksRemaining=(std::floor((p.tick+1e-7)/bar)+1.0)*bar-p.tick;
            }else commitStyle(i,*next,false,cb);
        }
    }
    adoptSequence(cb);
    for(int i=0;i<kPlayers;++i)cb.sourceStyle(i,players_[static_cast<std::size_t>(i)].style);
    // Coalesce adjacent key attacks (or releases) at the same render boundary.
    // Pedal, transport and a change of direction always commit the previous group.
    const auto gesture=[this](const Command& cmd) noexcept {
        if(cmd.type!=CommandType::Midi || !(cmd.value>=0 && cmd.value<=127) ||
           cmd.data2<0 || cmd.data2>127 || !scansKey(static_cast<int>(cmd.value)))return 0;
        const auto kind=cmd.index&0xF0;
        if(kind==0x90 && cmd.data2>0)return 1;
        return kind==0x80 || kind==0x90 ? -1 : 0;
    };
    Command current,following;
    if(pop(current)){
        for(std::size_t n=1;;++n){
            const bool more=n<kQueueSize && pop(following);
            const auto direction=gesture(current);
            if(more && direction && direction==gesture(following))
                observeMidi(current.index,static_cast<int>(current.value),current.data2,cb,true);
            else {handle(current,cb);refreshManualBass(cb);}
            if(!more)break;
            current=following;
        }
    }
    const unsigned resetChannels=inputResetMask_.exchange(0,std::memory_order_acq_rel);
    if(panicPending_.exchange(false,std::memory_order_acq_rel)){
        cb.liveEvent({"CONTROL_QUEUE_OVERFLOW"});handle({CommandType::Panic},cb);
    }
    else if(resetChannels){
        cb.liveEvent({"MIDI_QUEUE_RECOVERY",-1,-1,-1,static_cast<int>(resetChannels)});
        for(unsigned ch=0;ch<held_.size();++ch)if(resetChannels&(1U<<ch)){
            held_[ch].fill(0);heldVelocity_[ch].fill(0);
            damperDown_[ch]=false;
        }
        if(!anyDamperDown())chordLatched_=false;
        velocityGesture(false,-1,0,cb);
        refreshChord(cb,ScanReason::Recovery); // do not manufacture a physical gesture
    }
    refreshManualBass(cb);
    serviceSequence(cb);
    if(!std::isfinite(sampleRate)||sampleRate<8000){if(frames>0)cb.render(0,frames);finishPublication();return;}
    std::uint32_t offset=0;
    while(offset<frames){
        serviceSequence(cb);
        for(int i=0;i<kPlayers;++i){
            auto& p=players_[static_cast<std::size_t>(i)];
            if(p.pendingStyle&&!p.playing)commitStoppedSelection(i,cb);
            if(!p.playing)continue;
            for(;;){
                const auto* sec=section(p);if(!sec){cb.liveEvent({"SECTION_MISSING",i});p.playing=false;break;}
                if(sec->nativePatterns){
                    if(!variation(p.element)&&p.tick+1e-7>=patternBoundary(p)){
                        const double overshoot=p.tick-patternBoundary(p);
                        const auto* previous=p.styleInstallation;boundary(i,cb);
                        if(p.styleInstallation==previous){
                            p.tick=std::max(0.0,overshoot);
                            if(p.playing)for(auto& cursor:p.cursors)if(cursor.cv>=0)cursor.tick=p.tick;
                        }
                        if(!p.playing)break;
                        continue; // route the fresh section/Style's tick-zero events now
                    }
                    drainPatternEvents(i,cb);break;
                }
                while(p.eventIndex<sec->events.size()&&static_cast<double>(sec->events[p.eventIndex].tick)<=p.tick+1e-7)
                    emit(i,sec->events[p.eventIndex++],cb);
                if(p.tick+1e-7<sec->lengthTicks)break;
                const double overshoot=p.tick-sec->lengthTicks;
                const auto* previous=p.styleInstallation;boundary(i,cb);
                if(p.styleInstallation==previous)p.tick=std::max(0.0,overshoot);
                if(!p.playing)break;
            }
        }
        serviceSequence(cb); // an Ending may have stopped the selected transport
        std::uint32_t step=frames-offset;
        const double chordFrames=nextSequenceFrames(sampleRate);
        if(std::isfinite(chordFrames)&&chordFrames>0)
            step=std::min(step,static_cast<std::uint32_t>(std::min<double>(step,std::max(1.0,std::ceil(chordFrames-1e-7)))));
        for(const auto& player:players_)if(player.playing&&player.fadeDirection!=0){
            const double distance=player.fadeDirection>0?1.0-player.fadeGain:player.fadeGain;
            const double duration=player.fadeDirection>0?fadeInSeconds_:fadeOutSeconds_;
            const double remaining=std::max(1.0,std::ceil(distance*duration*sampleRate-1e-7));
            step=std::min(step,static_cast<std::uint32_t>(std::min<double>(step,remaining)));
        }
        for(int i=0;i<kPlayers;++i){
            auto& p=players_[static_cast<std::size_t>(i)];if(!p.playing)continue;const auto* sec=section(p);if(!sec)continue;
            double remainingTicks=std::numeric_limits<double>::infinity();
            if(sec->nativePatterns){
                if(!variation(p.element))remainingTicks=std::max(0.0,patternBoundary(p)-p.tick);
                for(int tr=0;tr<kTracks;++tr){
                    const auto& cursor=p.cursors[static_cast<std::size_t>(tr)];if(cursor.cv<0)continue;
                    const auto& cv=sec->patterns[static_cast<std::size_t>(tr)].cvs[static_cast<std::size_t>(cursor.cv)];if(!cv.available)continue;
                    double target=cv.lengthTicks;
                    if(cursor.eventIndex<cv.events.size())target=std::min(target,static_cast<double>(cv.events[cursor.eventIndex].tick));
                    if(!tempoLock_&&cursor.tempoIndex<cv.tempoEvents.size())target=std::min(target,static_cast<double>(cv.tempoEvents[cursor.tempoIndex].tick));
                    remainingTicks=std::min(remainingTicks,target-cursor.tick);
                }
            }else{
                double target=sec->lengthTicks;
                if(p.eventIndex<sec->events.size())target=std::min(target,static_cast<double>(sec->events[p.eventIndex].tick));
                remainingTicks=target-p.tick;
            }
            if(p.queued!=Element::Count){const double bar=measureTicks(*p.style,*sec);remainingTicks=std::min(remainingTicks,(std::floor((p.tick+1e-7)/bar)+1.0)*bar-p.tick);}
            if(p.pendingStyle)remainingTicks=std::min(remainingTicks,p.styleSwitchTicksRemaining);
            const double ticksPerFrame=p.tempo*p.style->ppq/(60.0*sampleRate);
            const double remaining=remainingTicks/ticksPerFrame;
            if(std::isfinite(remaining)&&remaining>0)step=std::min(step,static_cast<std::uint32_t>(std::min<double>(frames-offset,std::max(1.0,std::ceil(remaining-1e-7)))));
            const double guitarFrames=nextGuitarEventMs(p)*sampleRate/1000.0;
            if(std::isfinite(guitarFrames)&&guitarFrames>0)
                step=std::min(step,static_cast<std::uint32_t>(std::min<double>(frames-offset,std::max(1.0,std::ceil(guitarFrames-1e-7)))));
        }
        if(step==0)step=1;
        for(int player=0;player<kPlayers;++player){
            auto& state=players_[static_cast<std::size_t>(player)];const double first=state.fadeGain;
            if(state.playing&&state.fadeDirection!=0){
                const double duration=state.fadeDirection>0?fadeInSeconds_:fadeOutSeconds_;
                state.fadeGain=std::clamp(first+state.fadeDirection*static_cast<double>(step)/(duration*sampleRate),0.0,1.0);
            }
            cb.transportGain(player,static_cast<float>(first),static_cast<float>(state.fadeGain));
            cb.sourceTempo(player,state.tempo,state.playing);
        }
        cb.render(offset,step);
        advanceSequence(step,sampleRate);
        for(int i=0;i<kPlayers;++i){
            auto& p=players_[static_cast<std::size_t>(i)];if(!p.playing)continue;const auto* sec=section(p);if(!sec)continue;
            const double previous=p.tick;
            const double delta=static_cast<double>(step)*p.tempo*p.style->ppq/(60.0*sampleRate);
            p.tick+=delta;
            advanceGuitarEvents(p,1000.0*static_cast<double>(step)/sampleRate);
            const double bar=measureTicks(*p.style,*sec);
            const auto crossed=std::floor((p.tick+1e-7)/bar)-std::floor((previous+1e-7)/bar);
            if(crossed>0)p.transportMeasure+=static_cast<std::uint64_t>(crossed);
            if(p.fadeDirection>0&&p.fadeGain>=1.0-1e-9)p.fadeDirection=0;
            else if(p.fadeDirection<0&&p.fadeGain<=1e-9){
                cb.liveEvent({"FADE_OUT_COMPLETE",i});silence(i,cb);p.playing=false;p.syncStart=false;p.syncStopReady=false;p.loopElement=Element::Count;
                p.fadeDirection=0;p.tick=0;p.eventIndex=0;commitStoppedSelection(i,cb);p.fadeGain=0.0;continue;
            }
            if(sec->nativePatterns)for(int tr=0;tr<kTracks;++tr){auto& cursor=p.cursors[static_cast<std::size_t>(tr)];if(cursor.cv>=0)cursor.tick+=delta;}
            if(p.pendingStyle){
                p.styleSwitchTicksRemaining-=delta;
                if(p.styleSwitchTicksRemaining<=1e-7){
                    const auto* next=p.pendingStyle;
                    // Never carry an old PPQ/tempo overshoot into the new graph.
                    commitStyle(i,*next,true,cb);continue;
                }
            }
            if(p.queued!=Element::Count){
                const double target=(std::floor((previous+1e-7)/bar)+1.0)*bar;
                const bool boundaryInside=sec->nativePatterns?(variation(p.element)||target<patternBoundary(p)):target<sec->lengthTicks;
                if(p.tick+1e-7>=target&&boundaryInside){
                    const double overshoot=p.tick-target;const auto* previousInstallation=p.styleInstallation;
                    boundary(i,cb);
                    if(p.styleInstallation==previousInstallation){
                        p.tick=std::max(0.0,overshoot);
                        if(p.playing)for(auto& cursor:p.cursors)if(cursor.cv>=0)cursor.tick=p.tick;
                    }
                }
            }
        }
        offset+=step;
    }

    if(!players_[static_cast<std::size_t>(sequencePlayer_)].playing)serviceSequence(cb);
    transition_.advance(1000.0*frames/sampleRate);
    finishPublication();
}
#include "ChordSequence.inc"
} // namespace silveton::arranger
