#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xFactorySounds.h"
#include "silveton/arranger/Pa5xSampleDiskCache.h"
#include "silveton/arranger/Pa5xPcmMetadataCache.h"
#include "Pa5xSnapshotArchive.h"
#include "Pa5xKstMetadataReuse.h"

#include <fstream>
#include <cctype>
#include <map>
#include <tuple>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <set>

namespace silveton::arranger {
// These fields preserve the decoded metadata exactly. Trivial parameter
// records use the archive's ABI-gated POD encoding; no Korg parser is run
// while reopening the private snapshot.
void archiveFields(snapshot::Archive& a, Pa5xPcgSound& v) {
    a(v.name,v.rawName,v.resourceClass,v.internalBank,v.rawProgram,v.kind,
      v.addressKnown,v.addressEvidence,v.msb,v.lsb,v.resourceVersion,v.rawChecksum,
      v.rawObjectId,v.objectIdPresent,v.indexOrdinal,v.recordOffset,v.recordLength,
      v.payloadOffset,v.payloadLength,v.payloadChunkTag,v.oc31Encoded,v.parametersDecoded);
}
void archiveFields(snapshot::Archive& a, Pa5xOscillatorReferences& v) {
    a(v.decodedBodyOffset,v.high,v.low,v.delayRaw,v.velocitySwitch,v.velocityLow,
      v.velocityHigh,v.keyLow,v.keyHigh,v.triggerModeRaw,v.controllerExceptionRaw,
      v.octaveRaw,v.transposeRaw,v.tuneRaw,v.scaledVelocityLow,v.scaledVelocityHigh,
      v.opaqueDsp,v.lfoRaw,v.amplitudeEnvelopeRaw,v.additionalDspRaw,v.additionalDspBytes,
      v.dsp,v.staticPitchDecoded,v.triggerFieldsDecoded,v.scaledVelocityDecoded,
      v.transposeSemitones,v.staticPitchOffsetCents,v.equalizer,v.undecodedTail);
}
void archiveFields(snapshot::Archive& a, Pa5xSoundReferenceGraph& v) {
    a(v.recognized,v.referenceGraphDecoded,v.parametersDecoded,v.resourceVersion,
      v.error,v.bodyName,v.multisampleMapRaw,v.voiceFlagsRaw,v.oscillatorFlagsRaw,
      v.decodedBodyBytes,v.oscillators,v.corpusDerivedReferenceLayout,v.commonRaw,
      v.synthesisBlockers);
    // Keep the durable graph archive layout unchanged. Original common metadata
    // is derived from retained bytes, including when an older cache is restored.
    if(a.reading()){
        v.effects=inspectPa5xSoundEffects(v);
        derivePa5xSoundCommonParameters(v);
    }
}
void archiveFields(snapshot::Archive& a, Pa5xDrumKitKey& v) {
    a(v.firstLayer,v.opaqueIndexRaw,v.layerCount,v.velocitySwitchesRaw,v.opaqueA,
      v.opaqueB,v.legacyOpaque,v.opaqueC,v.velocitySwitchesExtendedRaw,v.rawRecord);
}
void archiveFields(snapshot::Archive& a, Pa5xDrumKitLayer& v) {
    a(v.sampleBankRaw,v.reverseRaw,v.drumSampleNumber,v.hasDrumSampleId,v.drumSampleId,
      v.layerParametersIdentified,v.levelRaw,v.transposeRaw,v.attackRaw,v.cutoffRaw,
      v.tuneRaw,v.decayRaw,v.resonanceRaw,v.detailRaw,v.detailBytes,v.rawRecord);
}
void archiveFields(snapshot::Archive& a, Pa5xDrumKitInspection& v) {
    a(v.recognized,v.referenceGraphDecoded,v.parametersDecoded,v.playable,
      v.resourceVersion,v.name,v.error,v.multisampleMapRaw,v.voiceFlagsRaw,
      v.oscillatorFlagsRaw,v.decodedBodyBytes,v.drumTableOffset,v.layerIdsPresent,
      v.drumTableFlagsRaw,v.commonRaw,v.commonOscillatorsRaw,v.keys,v.layers,v.blockers);
}
void archiveFields(snapshot::Archive& a, Pa5xSetBankSound& v) {
    a(v.path,v.descriptor,v.graph,v.drumKit);
}
void archiveFields(snapshot::Archive& a, Pa5xSetBankIssue& v) {
    a(v.code,v.path,v.message,v.resourceId);
}
void archiveFields(snapshot::Archive& a, Pa5xPcmFileStatus& v) {
    a(v.path,v.indexed,v.preparationComplete,v.sourceRead,v.metadataCacheHit,
      v.restored,v.samples,v.attempted,v.ready,v.failed,v.unlinked,v.error);
}
void archiveFields(snapshot::Archive& a, Pa5xSetBankStatus& v) {
    a(v.rootPath,v.recognized,v.indexed,v.cancelled,v.soundDirectoryComplete,
      v.pcmFiles,v.pcmSamples,v.kmpFiles,v.sounds,v.pcmFileBytes,
      v.samplePreparationComplete,v.samplesAttempted,v.samplesReady,v.samplesFailed,
      v.samplesUnlinked,v.samplesRamFallbacks,v.pcmSourceFilesRead,v.pcmMetadataCacheHits,
      v.samplesDiskCacheHits,v.samplesDecoded,v.samplePreparationIssues,v.issues);
}
void archiveFields(snapshot::Archive& a, Pa5xSampleObject& v) {
    a(v.name,v.objectType,v.rawBank,v.rawSlot,v.versionMajor,v.versionMinor,
      v.hasId,v.idFromPayload,v.resourceId,v.payloadOffset,v.payloadBytes,
      v.payloadFlags,v.oc31Compressed,v.encrypted,v.containerDecoded,
      v.decodedContainerBytes,v.decodeError,v.audioMetadataDecoded,v.sampleFormat,
      v.channelTag,v.pcmByteOrder,v.sampleRate,v.encodedSampleCount,v.loopStart,
      v.rawAudioHeaderWords,v.endPositionRaw,v.secondaryEndPositionRaw,
      v.audioDataOffset,v.audioDataBytes);
}
void archiveFields(snapshot::Archive& a, Pa5xKmpSample& v) {
    a(v.name,v.resourceId,v.bank,v.originalNote,v.bankKnown,v.predictorsKnown,
      v.predictorsDerived,v.packedData,v.predictor1,v.predictor2,v.sampleRate,v.version8Prefix);
}
void archiveFields(snapshot::Archive& a, Pa5xKmpDrumSample& v) {
    a(v.name,v.resourceId,v.leftSample,v.rightSample,v.bank,v.family,
      v.version8ReferencesPresent,v.stereoPairingKnown,v.version8References);
}
void archiveFields(snapshot::Archive& a, Pa5xKmpMultisample& v) {
    a(v.name,v.resourceId,v.firstZone,v.zoneIndices,v.zoneCount);
}
void archiveFields(snapshot::Archive& a, Pa5xSampleIndex& v) {
    a(v.recognized,v.valid,v.kind,v.error,v.tocVersionMajor,v.tocVersionMinor,
      v.objects,v.blockers,v.waveformDecoded,v.multisampleMappingDecoded,
      v.samples,v.drumSamples,v.keyZones,v.multisamples);
}
namespace {
using Address = std::tuple<int,int,int>;
constexpr std::size_t maximumFileBytes = 256U * 1024U * 1024U;
bool stopped(const std::atomic<bool>* cancel) {
    return cancel != nullptr && cancel->load(std::memory_order_relaxed);
}
bool join(const std::string& root, const std::string& relative, std::string& full) {
    if (root.empty() || relative.empty() || relative.front() == '/' ||
        relative.find('\0') != std::string::npos) return false;
    std::size_t start = 0;
    for (;;) {
        const auto end = relative.find('/', start);
        const auto part = relative.substr(start, end == std::string::npos ? end : end-start);
        if (part.empty() || part == "." || part == "..") return false;
        if (end == std::string::npos) break;
        start = end + 1;
    }
    full = root + "/" + relative;
    return true;
}
bool read(const std::string& path, std::vector<std::uint8_t>& bytes, std::string& error) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) { error = "Cannot open SET resource"; return false; }
    const auto size = file.tellg();
    if (size <= 0 || size > static_cast<std::streamoff>(maximumFileBytes)) {
        error = "SET resource is empty or exceeds the 256 MiB per-file limit"; return false;
    }
    bytes.resize(static_cast<std::size_t>(size)); file.seekg(0);
    if (!file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()))) {
        error = "SET resource read failed"; return false;
    }
    return true;
}
}
struct Pa5xSetBank::Impl {
    struct SampleFile {
        std::string path; Pa5xSampleIndex index; std::string contentHash;
        friend void archiveFields(snapshot::Archive& a, SampleFile& v) {
            a(v.path,v.index,v.contentHash);
        }
    };
    struct Location { std::size_t file, object; };
    Pa5xSetBankStatus status;
    std::vector<SampleFile> pcm, kmp;
    std::vector<Pa5xPcmFileStatus> pcmFileStatuses;
    std::vector<Pa5xSetBankSound> sounds;
    struct SoundMetadata {KstMetadataRevision revision;std::string error;};
    std::map<std::string,SoundMetadata> soundMetadata;
    std::map<Address,std::vector<std::size_t>> addresses;
    std::map<std::uint64_t,std::vector<Location>> pcmSamples, kmpSamples, multisamples, drumSamples;
    void issue(const std::string& code, const std::string& path, const std::string& message,
               std::uint64_t uid = 0) { status.issues.push_back({code,path,message,uid}); }
};
Pa5xSetBank::Pa5xSetBank() : impl_(std::make_unique<Impl>()) {}
Pa5xSetBank::~Pa5xSetBank() = default;
bool Pa5xSetBank::saveSnapshot(const std::string& path) const {
    if (!impl_->status.recognized || impl_->status.cancelled ||
        !impl_->status.samplePreparationComplete) return false;
    try {
        snapshot::Archive a;
        // Archive writing is deliberately detached from the live immutable
        // bank. Startup never mutates a bank retained by sounding voices.
        auto status=impl_->status;
        auto sounds=impl_->sounds;
        auto pcm=impl_->pcm;
        auto kmp=impl_->kmp;
        auto pcmFiles=impl_->pcmFileStatuses;
        a(status,sounds,pcm,kmp,pcmFiles);
        return a.writeFile(path,"SVP5BANK2");
    } catch (...) { return false; }
}
bool Pa5xSetBank::loadSnapshot(const std::string& path, const std::string& expectedRoot) {
    try {
        snapshot::Archive a;
        bool reportsAvailable=true;
        try { a=snapshot::Archive::readFile(path,"SVP5BANK2"); }
        catch (...) {
            a=snapshot::Archive::readFile(path,"SVP5BANK1");
            reportsAvailable=false;
        }
        auto next=std::make_unique<Impl>();
        a(next->status,next->sounds,next->pcm,next->kmp);
        if(reportsAvailable)a(next->pcmFileStatuses);
        a.finish();
        const auto& status=next->status;
        if (expectedRoot.empty() || status.rootPath!=expectedRoot || !status.recognized ||
            status.cancelled || !status.samplePreparationComplete ||
            status.sounds!=next->sounds.size() || status.pcmFiles!=next->pcm.size() ||
            status.kmpFiles!=next->kmp.size()) return false;
        const auto underRoot=[&](const std::string& source) {
            return source.size()>expectedRoot.size()+1U &&
                source.compare(0,expectedRoot.size(),expectedRoot)==0 &&
                source[expectedRoot.size()]=='/' && source.find('\0')==std::string::npos;
        };
        for (std::size_t n=0;n<next->sounds.size();++n) {
            const auto& sound=next->sounds[n];
            if (!underRoot(sound.path)) return false;
            const auto& d=sound.descriptor;
            if (d.addressKnown) next->addresses[{d.msb,d.lsb,d.rawProgram}].push_back(n);
        }
        std::size_t pcmObjects=0;
        for (std::size_t file=0;file<next->pcm.size();++file) {
            const auto& item=next->pcm[file];
            if (!underRoot(item.path) || !item.index.valid ||
                item.index.kind!=Pa5xSampleContainerKind::PcmSamples) return false;
            pcmObjects+=item.index.objects.size();
            for (std::size_t n=0;n<item.index.objects.size();++n)
                if (item.index.objects[n].hasId)
                    next->pcmSamples[item.index.objects[n].resourceId].push_back({file,n});
        }
        if (pcmObjects!=status.pcmSamples) return false;
        for (std::size_t file=0;file<next->kmp.size();++file) {
            const auto& item=next->kmp[file];
            if (!underRoot(item.path) || !item.index.valid ||
                item.index.kind!=Pa5xSampleContainerKind::Multisamples) return false;
            for (std::size_t n=0;n<item.index.samples.size();++n)
                next->kmpSamples[item.index.samples[n].resourceId].push_back({file,n});
            for (std::size_t n=0;n<item.index.multisamples.size();++n)
                next->multisamples[item.index.multisamples[n].resourceId].push_back({file,n});
            for (std::size_t n=0;n<item.index.drumSamples.size();++n)
                next->drumSamples[item.index.drumSamples[n].resourceId].push_back({file,n});
        }
        if(!reportsAvailable) {
            // BANK1 did not record per-file preparation outcomes. Reuse its
            // working PCM cache without inventing loaded recording counts.
            for(const auto& file:next->pcm) {
                Pa5xPcmFileStatus report;
                report.path=file.path;report.indexed=true;
                report.samples=file.index.objects.size();
                next->pcmFileStatuses.push_back(std::move(report));
            }
            for(const auto& issue:status.issues) {
                std::string source=issue.path;
                if(!underRoot(source)&&!join(expectedRoot,issue.path,source))continue;
                const auto slash=source.find_last_of('/');
                auto name=source.substr(slash==std::string::npos?0U:slash+1U);
                std::transform(name.begin(),name.end(),name.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});
                if(name.size()<4U||name.compare(name.size()-4U,4U,".pcm")!=0)continue;
                const auto found=std::find_if(next->pcmFileStatuses.begin(),next->pcmFileStatuses.end(),
                    [&](const Pa5xPcmFileStatus& item){return item.path==source;});
                if(found==next->pcmFileStatuses.end()) {
                    Pa5xPcmFileStatus report;report.path=source;report.error=issue.message;
                    next->pcmFileStatuses.push_back(std::move(report));
                }
            }
        }
        std::set<std::string> reportedPaths;
        std::size_t indexedFiles=0;
        for(auto& report:next->pcmFileStatuses) {
            if(!underRoot(report.path)||!reportedPaths.insert(report.path).second||
               report.attempted>report.samples||report.failed>report.attempted||
               report.ready>report.attempted-report.failed||
               report.unlinked>report.samples-report.attempted||
               (report.preparationComplete&&!report.indexed))return false;
            if(report.indexed) {
                const auto file=std::find_if(next->pcm.begin(),next->pcm.end(),
                    [&](const Impl::SampleFile& item){return item.path==report.path;});
                if(file==next->pcm.end()||report.samples!=file->index.objects.size())return false;
                ++indexedFiles;
            }
            // Source I/O and index-cache hits describe this open only. The
            // historical preparation outcomes remain useful after restore.
            report.restored=true;report.sourceRead=false;report.metadataCacheHit=false;
        }
        if(indexedFiles!=next->pcm.size())return false;
        // These are activity counters for this open, not historical totals.
        next->status.pcmSourceFilesRead=0;
        next->status.pcmMetadataCacheHits=0;
        next->status.samplesDiskCacheHits=0;
        next->status.samplesDecoded=0;
        impl_.swap(next);
        return true;
    } catch (...) { return false; }
}
bool Pa5xSetBank::load(const std::string& root,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel) {
    const auto index = indexPa5xKst(root,progress,cancel);
    return load(index,progress,cancel);
}
bool Pa5xSetBank::load(const Pa5xKstIndex& index,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel) {
    return loadResources(index,progress,cancel,false);
}
bool Pa5xSetBank::loadForSamplePlayback(const Pa5xKstIndex& index,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel,
    const Pa5xMultisampleBuildOptions* sampleOptions,Pa5xMultisampleCache* sampleCache) {
    return loadResources(index,progress,cancel,true,sampleOptions,sampleCache);
}
bool Pa5xSetBank::loadResources(const Pa5xKstIndex& index,
    const std::function<void(const KstProgress&)>& progress, const std::atomic<bool>* cancel, bool allowPartial,
    const Pa5xMultisampleBuildOptions* sampleOptions,Pa5xMultisampleCache* sampleCache) {
    // Publish only after the entire metadata pass. An incomplete candidate is
    // retained for status, with all audio/Sound lookups disabled. Callers keep
    // a separate previous bank object if their performance must stay active.
    auto next = std::make_unique<Impl>(); next->status.recognized = index.recognized;
    next->status.rootPath = index.rootPath;
    std::map<std::size_t,std::size_t> pcmReportPositions;
    for(std::size_t n=0;n<index.resources.size();++n) {
        const auto& resource=index.resources[n];
        if(resource.kind!=KstResourceKind::Sample)continue;
        Pa5xPcmFileStatus report;
        if(!join(index.rootPath,resource.relativePath,report.path))
            report.path=index.rootPath+"/"+resource.relativePath;
        pcmReportPositions.emplace(n,next->pcmFileStatuses.size());
        next->pcmFileStatuses.push_back(std::move(report));
    }
    if (!index.recognized || (!allowPartial && !index.structurallyValid) || index.resources.empty() || index.cancelled || stopped(cancel)) {
        next->status.cancelled = index.cancelled || stopped(cancel);
        next->issue("SET_NOT_INDEXED",index.rootPath,"A recognized complete KST resource root is required");
        impl_.swap(next); return false;
    }
    // KMP metadata is required to decode the PCM predictive recordings. Read
    // it first; unchanged PCM inventories and decoded audio reopen from cache.
    std::vector<std::size_t> order;
    for(std::size_t i=0;i<index.resources.size();++i)
        if(index.resources[i].kind==KstResourceKind::Multisample)order.push_back(i);
    for(std::size_t i=0;i<index.resources.size();++i)
        if(index.resources[i].kind==KstResourceKind::Sample||index.resources[i].kind==KstResourceKind::Sound)order.push_back(i);
    const auto total = static_cast<std::uint64_t>(order.size());
    std::set<std::uint64_t> attemptedSamples;
    std::map<std::uint64_t,bool> preparedSamples;
    std::map<std::uint64_t,std::size_t> preparedFileReports;
    next->status.soundDirectoryComplete = true;
    for (std::size_t i = 0; i < order.size(); ++i) {
        if (stopped(cancel)||(sampleOptions&&stopped(sampleOptions->cancel))) { next->status.cancelled = true; break; }
        const auto& resource = index.resources[order[i]];
        const auto reportPosition=pcmReportPositions.find(order[i]);
        auto* fileReport=reportPosition==pcmReportPositions.end()?nullptr:
            &next->pcmFileStatuses[reportPosition->second];
        const auto pcmPhase=[&](const std::string& action) {
            return fileReport?"PCM "+std::to_string(reportPosition->second+1U)+" / "+
                std::to_string(next->pcmFileStatuses.size())+" — "+action:action;
        };
        const auto fileError=[&](const std::string& message) {
            if(fileReport&&fileReport->error.empty())fileReport->error=message;
        };
        if (resource.kind != KstResourceKind::Sample && resource.kind != KstResourceKind::Multisample &&
            resource.kind != KstResourceKind::Sound) continue;
        std::string path;
        if (!resource.readable || !join(index.rootPath,resource.relativePath,path)) {
            if (resource.kind == KstResourceKind::Sound) next->status.soundDirectoryComplete = false;
            fileError("SET resource is unreadable or its path is invalid");
            if(progress&&fileReport)progress({static_cast<std::uint64_t>(i),total,pcmPhase("Cannot read file"),resource.relativePath});
            next->issue("RESOURCE_UNREADABLE",resource.relativePath,"SET resource is unreadable or its path is invalid"); continue;
        }
        std::vector<std::uint8_t> bytes; std::string error,contentHash;
        const auto sharedPcg=resource.kind==KstResourceKind::Sound&&index.metadataReadCache?
            index.metadataReadCache->pcg(path):std::shared_ptr<const Pa5xKstMetadataCache::Pcg>{};
        const auto soundRevision=resource.kind==KstResourceKind::Sound?
            (sharedPcg?sharedPcg->revision:kstMetadataRevision(path)):KstMetadataRevision{};
        Pa5xSampleIndex parsed;
        Pa5xPcmSourceStamp sourceStamp;
        const bool usePcmCache=allowPartial&&resource.kind==KstResourceKind::Sample&&sampleOptions&&
            !sampleOptions->streamCacheDirectory.empty();
        bool metadataHit=false;
        if(usePcmCache){
            auto cached=loadPa5xPcmMetadataCache(path,sampleOptions->streamCacheDirectory);
            if(cached.cacheHit){
                parsed=std::move(cached.index);contentHash=std::move(cached.contentHash);
                sourceStamp=std::move(cached.sourceStamp);metadataHit=true;
                ++next->status.pcmMetadataCacheHits;
                if(fileReport)fileReport->metadataCacheHit=true;
            }else sourceStamp=inspectPa5xPcmSourceStamp(path);
        }
        if(progress)progress({static_cast<std::uint64_t>(i),total,
            resource.kind==KstResourceKind::Sample?pcmPhase(metadataHit?"Opening cached index":"Reading source"):
                (sharedPcg?"Using checked Sound metadata":"Reading SET sound metadata"),resource.relativePath});
        if (!metadataHit&&!sharedPcg&&!read(path,bytes,error)) {
            if (resource.kind == KstResourceKind::Sound) next->status.soundDirectoryComplete = false;
            fileError(error);
            next->issue("RESOURCE_READ_FAILED",path,error); continue;
        }
        if(resource.kind==KstResourceKind::Sample&&!metadataHit){
            ++next->status.pcmSourceFilesRead;
            if(fileReport)fileReport->sourceRead=true;
            if(sourceStamp.valid&&!samePa5xPcmSourceStamp(sourceStamp,inspectPa5xPcmSourceStamp(path))){
                fileError("PCM source changed while being read; reload the SET");
                next->issue("PCM_SOURCE_CHANGED",path,"PCM source changed while being read; reload the SET");continue;
            }
        }
        if (resource.kind == KstResourceKind::Sound) {
            const auto& soundBytes=sharedPcg?sharedPcg->bytes:bytes;
            const auto localPcg=sharedPcg?Pa5xPcgInspection{}:inspectPa5xPcgBytes(soundBytes,path);
            const auto& pcg=sharedPcg?sharedPcg->inspection:localPcg;
            if(sameKstMetadataRevision(soundRevision,kstMetadataRevision(path)))
                next->soundMetadata.emplace(path,Impl::SoundMetadata{soundRevision,pcg.valid?std::string{}:pcg.error});
            else {next->status.soundDirectoryComplete=false;next->issue("PCG_SOURCE_CHANGED",path,"Sound metadata changed while being read; reload the SET");continue;}
            if (!pcg.valid) { next->status.soundDirectoryComplete = false; next->issue("PCG_INVALID",path,pcg.error); continue; }
            for (const auto& sound : pcg.sounds) {
                const auto position = next->sounds.size();
                Pa5xSetBankSound resourceSound; resourceSound.path = path; resourceSound.descriptor = sound;
                if (sound.kind == Pa5xPcgSoundKind::DrumKit) resourceSound.drumKit = inspectPa5xDrumKitBytes(soundBytes,sound);
                else resourceSound.graph = inspectPa5xSoundGraph(soundBytes,sound);
                next->sounds.push_back(std::move(resourceSound));
                if (sound.addressKnown) next->addresses[{sound.msb,sound.lsb,sound.rawProgram}].push_back(position);
                else next->status.soundDirectoryComplete = false;
            }
        } else {
            if(!metadataHit)parsed=inspectPa5xSampleBytes(bytes,allowPartial && resource.kind == KstResourceKind::Sample);
            const auto kind = resource.kind == KstResourceKind::Sample ? Pa5xSampleContainerKind::PcmSamples
                                                                        : Pa5xSampleContainerKind::Multisamples;
            if (!parsed.valid || parsed.kind != kind) {
                fileError(parsed.error.empty()?"Unexpected sample container kind":parsed.error);
                next->issue("SAMPLE_CONTAINER_INVALID",path,parsed.error.empty() ? "Unexpected sample container kind" : parsed.error); continue;
            }
            if (kind == Pa5xSampleContainerKind::PcmSamples) {
                if(fileReport){fileReport->indexed=true;fileReport->samples=parsed.objects.size();}
                const auto file = next->pcm.size();
                for (std::size_t n = 0; n < parsed.objects.size(); ++n)
                    if (parsed.objects[n].hasId) next->pcmSamples[parsed.objects[n].resourceId].push_back({file,n});
                next->status.pcmFileBytes += metadataHit?sourceStamp.size:static_cast<std::uint64_t>(bytes.size());
                next->status.pcmSamples += parsed.objects.size();
                if(!metadataHit&&sampleOptions&&!sampleOptions->streamCacheDirectory.empty())
                    contentHash=pa5xSampleContentHash(bytes.data(),bytes.size());
                if(usePcmCache&&!metadataHit&&sourceStamp.valid&&
                   !storePa5xPcmMetadataCache(path,sampleOptions->streamCacheDirectory,parsed,contentHash,sourceStamp,sampleOptions->cancel)&&
                   !stopped(cancel)&&!stopped(sampleOptions->cancel)&&next->status.samplePreparationIssues.size()<24U)
                    next->status.samplePreparationIssues.push_back({"PCM_INDEX_CACHE_UNAVAILABLE",path,
                        "PCM index could not be saved; this source will be read again on the next SET load",0});
                next->pcm.push_back({path,std::move(parsed),std::move(contentHash)});
                if(sampleOptions&&sampleCache&&!sampleOptions->streamCacheDirectory.empty()){
                    sampleCache->encodedPath.clear();sampleCache->encodedError.clear();sampleCache->encodedBytes.clear();sampleCache->encodedIndex.reset();
                    if(!metadataHit){
                        sampleCache->encodedPath=path;sampleCache->encodedBytes=std::move(bytes);
                        sampleCache->encodedIndex=std::make_shared<Pa5xSampleIndex>(next->pcm.back().index);
                    }
                    if(progress)progress({static_cast<std::uint64_t>(i),total,
                        pcmPhase(metadataHit?"Opening cached sample buffers":"Preparing sample buffers"),resource.relativePath});
                    for(const auto& object:next->pcm.back().index.objects){
                        if(stopped(cancel)||stopped(sampleOptions->cancel)){next->status.cancelled=true;break;}
                        if(!object.hasId||next->kmpSamples.find(object.resourceId)==next->kmpSamples.end()){
                            ++next->status.samplesUnlinked;
                            if(fileReport)++fileReport->unlinked;
                            fileError(object.name+": no exact sample UID link in KMP metadata");
                            continue;
                        }
                        if(fileReport)++fileReport->attempted;
                        if(!attemptedSamples.insert(object.resourceId).second){
                            if(fileReport)++fileReport->failed;
                            fileError("Sample UID "+std::to_string(object.resourceId)+" occurs in multiple PCM objects");
                            continue;
                        }
                        // Individual unavailable recordings are accounted by
                        // their actual Sound/key regions during Program build.
                        ++next->status.samplesAttempted;
                        const auto prepared=buildSampleFrom(*next,object.resourceId,*sampleOptions,sampleCache);
                        if(prepared.diskCacheHit)++next->status.samplesDiskCacheHits;
                        if(prepared.decodedFromSource)++next->status.samplesDecoded;
                        if(prepared.sourceFileRead){
                            ++next->status.pcmSourceFilesRead;
                            if(fileReport)fileReport->sourceRead=true;
                        }
                        if(prepared){
                            ++next->status.samplesReady;
                            if(fileReport){
                                ++fileReport->ready;
                                preparedFileReports.emplace(object.resourceId,reportPosition->second);
                            }
                            preparedSamples.emplace(object.resourceId,prepared.ramFallback);
                            if(prepared.ramFallback){
                                ++next->status.samplesRamFallbacks;
                                if(next->status.samplePreparationIssues.size()<24U)
                                    next->status.samplePreparationIssues.push_back({"PCM_RAM_FALLBACK",path,
                                        object.name+": "+(prepared.warnings.empty()?"Disk cache unavailable; recording retained in RAM":prepared.warnings.back()),object.resourceId});
                            }
                        }else{
                            ++next->status.samplesFailed;
                            if(fileReport)++fileReport->failed;
                            fileError(object.name+": "+prepared.error);
                            if(next->status.samplePreparationIssues.size()<24U)
                                next->status.samplePreparationIssues.push_back({"PCM_PREPARATION_FAILED",path,
                                    object.name+": "+prepared.error,object.resourceId});
                        }
                    }
                    if(fileReport)fileReport->preparationComplete=!next->status.cancelled&&
                        !stopped(cancel)&&!stopped(sampleOptions->cancel);
                    // The next PCM read must not overlap a retained full
                    // encoded bank. All prepared recordings now own only
                    // bounded prefixes and mapped decoded audio.
                    sampleCache->encodedPath.clear();sampleCache->encodedError.clear();sampleCache->encodedIndex.reset();
                    std::vector<std::uint8_t>().swap(sampleCache->encodedBytes);
                }
            } else {
                const auto file = next->kmp.size();
                for (std::size_t n = 0; n < parsed.samples.size(); ++n)
                    next->kmpSamples[parsed.samples[n].resourceId].push_back({file,n});
                for (std::size_t n = 0; n < parsed.multisamples.size(); ++n)
                    next->multisamples[parsed.multisamples[n].resourceId].push_back({file,n});
                for (std::size_t n = 0; n < parsed.drumSamples.size(); ++n)
                    next->drumSamples[parsed.drumSamples[n].resourceId].push_back({file,n});
                next->kmp.push_back({path,std::move(parsed),{}});
            }
        }
    }
    next->status.pcmFiles = next->pcm.size(); next->status.kmpFiles = next->kmp.size();
    if(stopped(cancel))next->status.cancelled=true;
    next->status.samplePreparationComplete=sampleOptions&&sampleCache&&!sampleOptions->streamCacheDirectory.empty()&&!next->status.cancelled;
    next->status.sounds = next->sounds.size();
    for (const auto& entry : next->addresses) if (entry.second.size() != 1)
        next->issue("SOUND_ADDRESS_AMBIGUOUS","","Multiple PCG Sounds use the same original MIDI address");
    for (const auto& entry : next->pcmSamples) if (entry.second.size() != 1) {
        next->issue("PCM_UID_AMBIGUOUS","","Multiple PCM objects use the same sample UID",entry.first);
        // Preparation follows each file's single read. A later file can expose
        // a duplicate UID, so reconcile the final playable count only after
        // the complete inventory is known.
        const auto prepared=preparedSamples.find(entry.first);
        if(prepared!=preparedSamples.end()){
            --next->status.samplesReady;++next->status.samplesFailed;
            const auto sourceReport=preparedFileReports.find(entry.first);
            if(sourceReport!=preparedFileReports.end()) {
                auto& report=next->pcmFileStatuses[sourceReport->second];
                if(report.ready>0U){--report.ready;++report.failed;}
                if(report.error.empty())report.error="Sample UID "+std::to_string(entry.first)+" occurs in multiple PCM objects";
            }
            if(prepared->second)--next->status.samplesRamFallbacks;
            if(next->status.samplePreparationIssues.size()<24U)
                next->status.samplePreparationIssues.push_back({"PCM_PREPARATION_FAILED",{},
                    "Sample UID "+std::to_string(entry.first)+" occurs in multiple PCM objects",entry.first});
        }
    }
    next->status.indexed = !next->status.cancelled && next->status.issues.empty();
    if (next->status.cancelled) next->status.soundDirectoryComplete = false;
    if (progress) progress({total,total,"SET sound resources indexed",index.rootPath});
    const bool ok = next->status.indexed || (allowPartial && !next->status.cancelled && !next->sounds.empty());
    impl_.swap(next); return ok;
}
Pa5xSetBankStatus Pa5xSetBank::status() const { return impl_->status; }
const std::vector<Pa5xPcmFileStatus>& Pa5xSetBank::pcmFileStatuses() const noexcept {
    return impl_->pcmFileStatuses;
}
bool Pa5xSetBank::loadSoundDirectory(const Pa5xKstIndex& index,
    const std::function<void(const KstProgress&)>& progress,const std::atomic<bool>* cancel){
    auto next=std::make_unique<Impl>();next->status.rootPath=index.rootPath;next->status.recognized=index.recognized;
    if(!index.recognized||index.resources.empty()||index.cancelled||stopped(cancel)){
        next->status.cancelled=index.cancelled||stopped(cancel);
        next->issue("SOUND_DIRECTORY_UNAVAILABLE",index.rootPath,"A completed KST resource directory is required");
        impl_.swap(next);return false;
    }
    next->status.soundDirectoryComplete=true;
    // Discovery failures in SOUND (or at the root) may hide definitions.
    // Format/audio errors in PCM, STYLE or KMP cannot erase known PCG names.
    for(const auto& issue:index.diagnostics){
        if(issue.code!="FOLDER_UNREADABLE"&&issue.code!="FOLDER_READ_FAILED"&&issue.code!="DIRECTORY_DEPTH"&&
           issue.code!="TOO_MANY_FILES"&&issue.code!="RESOURCE_MISSING"&&issue.code!="LINKED_RESOURCE")continue;
        const auto slash=issue.relativePath.find('/');
        std::string scope=issue.relativePath.substr(0,slash);
        for(char& c:scope)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if(scope.empty()||scope=="sound"||issue.relativePath==index.rootPath){
            next->status.soundDirectoryComplete=false;
            next->issue(issue.code,issue.relativePath,issue.message);
        }
    }
    std::uint64_t total=0,done=0;
    for(const auto& resource:index.resources)if(resource.kind==KstResourceKind::Sound)++total;
    for(const auto& resource:index.resources){
        if(resource.kind!=KstResourceKind::Sound)continue;
        if(stopped(cancel)){next->status.cancelled=true;next->status.soundDirectoryComplete=false;break;}
        if(progress)progress({done,total,"Reading original Sound definitions",resource.relativePath});
        std::string path,error;std::vector<std::uint8_t> bytes;
        if(!resource.readable||!join(index.rootPath,resource.relativePath,path)){
            next->status.soundDirectoryComplete=false;
            next->issue("PCG_UNREADABLE",resource.relativePath,error.empty()?"PCG resource cannot be read":error);++done;continue;
        }
        const auto sharedPcg=index.metadataReadCache?index.metadataReadCache->pcg(path):std::shared_ptr<const Pa5xKstMetadataCache::Pcg>{};
        const auto revision=sharedPcg?sharedPcg->revision:kstMetadataRevision(path);
        if(!sharedPcg&&!read(path,bytes,error)){
            next->status.soundDirectoryComplete=false;next->issue("PCG_UNREADABLE",resource.relativePath,error);++done;continue;
        }
        const auto& soundBytes=sharedPcg?sharedPcg->bytes:bytes;
        const auto localPcg=sharedPcg?Pa5xPcgInspection{}:inspectPa5xPcgBytes(soundBytes,path);
        const auto& pcg=sharedPcg?sharedPcg->inspection:localPcg;
        if(!sameKstMetadataRevision(revision,kstMetadataRevision(path))){
            next->status.soundDirectoryComplete=false;next->issue("PCG_SOURCE_CHANGED",path,"Sound metadata changed while being read; reload the SET");++done;continue;
        }
        next->soundMetadata.emplace(path,Impl::SoundMetadata{revision,pcg.valid?std::string{}:pcg.error});
        if(!pcg.valid){next->status.soundDirectoryComplete=false;next->issue("PCG_INVALID",path,pcg.error);++done;continue;}
        for(const auto& sound:pcg.sounds){
            Pa5xSetBankSound item;item.path=path;item.descriptor=sound;
            if(sound.kind==Pa5xPcgSoundKind::DrumKit)item.drumKit=inspectPa5xDrumKitBytes(soundBytes,sound);
            else item.graph=inspectPa5xSoundGraph(soundBytes,sound);
            const auto position=next->sounds.size();next->sounds.push_back(std::move(item));
            if(sound.addressKnown)next->addresses[{sound.msb,sound.lsb,sound.rawProgram}].push_back(position);
            else next->status.soundDirectoryComplete=false;
        }
        ++done;
    }
    next->status.sounds=next->sounds.size();
    if(stopped(cancel)){next->status.cancelled=true;next->status.soundDirectoryComplete=false;}
    for(const auto& address:next->addresses)if(address.second.size()!=1)
        next->issue("SOUND_ADDRESS_AMBIGUOUS","","Multiple PCG Sounds use this original MIDI address");
    // status.indexed intentionally remains false: this directory has no audio
    // inventory, so full-bank playback lookups remain unavailable.
    const bool complete=next->status.soundDirectoryComplete&&!next->status.cancelled;
    if(progress)progress({done,total,complete?"Original Sound definitions read":"Sound directory has unresolved entries",index.rootPath});
    impl_.swap(next);return complete;
}
const std::vector<Pa5xSetBankSound>& Pa5xSetBank::sounds() const noexcept { return impl_->sounds; }
bool Pa5xSetBank::soundMetadataForPath(const std::string& path,
        std::vector<const Pa5xSetBankSound*>& sounds,std::string& error) const {
    sounds.clear();error.clear();
    const auto found=impl_->soundMetadata.find(path);
    if(found==impl_->soundMetadata.end()||!sameKstMetadataRevision(found->second.revision,kstMetadataRevision(path)))return false;
    error=found->second.error;
    for(const auto& sound:impl_->sounds)if(sound.path==path)sounds.push_back(&sound);
    return true;
}
const Pa5xSetBankSound* Pa5xSetBank::findSound(int msb, int lsb, int program) const noexcept {
    if (!impl_->status.indexed) return nullptr;
    return findSampleSound(msb,lsb,program);
}
const Pa5xSetBankSound* Pa5xSetBank::findSampleSound(int msb, int lsb, int program) const noexcept {
    if (!impl_->status.recognized || impl_->status.cancelled) return nullptr;
    const auto found = impl_->addresses.find({msb,lsb,program});
    return found != impl_->addresses.end() && found->second.size() == 1 ? &impl_->sounds[found->second.front()] : nullptr;
}
Pa5xSoundAddressRead Pa5xSetBank::resolveSoundAddress(int msb, int lsb, int program) const {
    Pa5xSoundAddressRead result; result.msb = msb; result.lsb = lsb; result.program = program;
    result.addressComplete = msb >= 0 && msb <= 127 && lsb >= 0 && lsb <= 127 && program >= 0 && program <= 127;
    if (!result.addressComplete) { result.message = "Original MIDI Sound address is incomplete or invalid"; return result; }
    const auto found = impl_->addresses.find({msb,lsb,program});
    if (impl_->status.recognized && !impl_->status.cancelled && found != impl_->addresses.end()) {
        if (found->second.size() != 1) {
            result.resolution = KstResolution::AmbiguousSound;
            result.message = "Multiple PCG definitions have this original Sound address"; return result;
        }
        const auto& source = impl_->sounds[found->second.front()];
        result.resolution = KstResolution::ExactUserSound;
        result.name = source.descriptor.name; result.path = source.path; result.soundKind = source.descriptor.kind;
        result.graphDecoded = source.descriptor.kind == Pa5xPcgSoundKind::DrumKit
            ? source.drumKit.referenceGraphDecoded : source.graph.referenceGraphDecoded;
        result.parametersDecoded = source.descriptor.kind == Pa5xPcgSoundKind::DrumKit
            ? source.drumKit.parametersDecoded : source.graph.parametersDecoded;
        result.message = "Exact original PCG Sound definition; playback readiness is separate";
        return result;
    }
    if (const auto* factory = findPa5xFactorySound(msb,lsb,program)) {
        result.resolution = KstResolution::FactorySoundRequired; result.name = factory->name;
        result.soundKind = factory->kind == Pa5xFactorySoundKind::DrumKit ? Pa5xPcgSoundKind::DrumKit : Pa5xPcgSoundKind::Sound;
        result.message = "Original Factory Sound identified; Factory audio is not supplied by this KST";
        return result;
    }
    if ((msb == 120 || msb == 121) && lsb < 64) {
        result.resolution = KstResolution::FactorySoundRequired;
        result.message = "Original Factory address; no exact name exists in the available Factory catalog";
    } else if (!impl_->status.recognized || impl_->status.cancelled) {
        result.message = "No completed KST Sound directory is available";
    } else if ((msb == 120 || msb == 121) && lsb >= 64 && impl_->status.soundDirectoryComplete) {
        result.resolution = KstResolution::MissingUserSound;
        result.message = "Original User Sound is missing from this KST's complete PCG directory";
    } else result.message = impl_->status.soundDirectoryComplete
        ? "Original Sound address is outside the supported address catalogs"
        : "Some PCG definitions are unreadable; this Sound cannot be declared missing";
    return result;
}
std::vector<Pa5xPcmInventory> Pa5xSetBank::pcmInventories() const {
    std::vector<Pa5xPcmInventory> result;
    if (impl_->status.indexed) for (const auto& file : impl_->pcm) result.push_back({file.path,&file.index});
    return result;
}
std::vector<Pa5xPcmInventory> Pa5xSetBank::sampleResourceInventories() const {
    std::vector<Pa5xPcmInventory> result;
    if(!impl_->status.recognized||impl_->status.cancelled)return result;
    for(const auto& file:impl_->kmp)result.push_back({file.path,&file.index});
    for(const auto& file:impl_->pcm)result.push_back({file.path,&file.index});
    return result;
}
const Pa5xSampleIndex* Pa5xSetBank::multisampleIndex(std::uint64_t uid) const noexcept {
    if (!impl_->status.indexed) return nullptr;
    const auto found = impl_->multisamples.find(uid);
    return found != impl_->multisamples.end() && found->second.size() == 1 ? &impl_->kmp[found->second.front().file].index : nullptr;
}
Pa5xProgramCandidate Pa5xSetBank::inspectSound(int msb, int lsb, int program) const {
    const auto* sound = findSound(msb,lsb,program);
    Pa5xProgramCandidate failed; failed.msb = msb; failed.lsb = lsb; failed.program = program;
    if (sound == nullptr) { failed.blockers.push_back("Original Sound address is absent, ambiguous or the SET bank failed validation"); return failed; }
    if (sound->descriptor.kind == Pa5xPcgSoundKind::DrumKit) {
        failed.found = true; failed.name = sound->descriptor.name;
        failed.blockers = sound->drumKit.blockers;
        if (!sound->drumKit.error.empty()) failed.blockers.push_back(sound->drumKit.error);
        if (failed.blockers.empty()) failed.blockers.push_back("Drum Kit references require the dedicated kit importer; original kit synthesis is not activated");
        return failed;
    }
    const Pa5xSampleIndex* mapping = impl_->kmp.size() == 1 ? &impl_->kmp.front().index : nullptr;
    for (const auto& oscillator : sound->graph.oscillators) for (const auto* source : {&oscillator.high,&oscillator.low}) {
        if (source->source != Pa5xMultisampleSource::Ram) continue;
        const auto* candidate = multisampleIndex(source->multisampleId);
        // With one canonical KMP scope the dependency inspector can retain
        // every missing UID and the remaining valid graph, instead of losing
        // the whole Sound description at its first unresolved multisample.
        if (candidate == nullptr && impl_->kmp.size() == 1) continue;
        if (candidate == nullptr || (mapping != nullptr && mapping != candidate)) {
            failed.found = true; failed.name = sound->descriptor.name;
            failed.blockers.push_back("Sound multisample UIDs are missing, ambiguous or span incompatible KMP scopes"); return failed;
        }
        mapping = candidate;
    }
    if (mapping == nullptr) {
        static const Pa5xSampleIndex empty;
        return inspectPa5xProgramCandidate(sound->descriptor,sound->graph,empty,pcmInventories());
    }
    return inspectPa5xProgramCandidate(sound->descriptor,sound->graph,*mapping,pcmInventories());
}
Pa5xDrumKitSampleLinks Pa5xSetBank::inspectDrumKit(int msb, int lsb, int program) const {
    if (!impl_->status.indexed) {
        Pa5xDrumKitSampleLinks failed;
        failed.blockers.push_back("SET bank has not completed full validation"); return failed;
    }
    return sampleDrumKitLinks(msb,lsb,program);
}
Pa5xDrumKitSampleLinks Pa5xSetBank::sampleDrumKitLinks(int msb, int lsb, int program) const {
    const auto* sound = findSampleSound(msb,lsb,program);
    Pa5xDrumKitSampleLinks result;
    if (sound == nullptr || sound->descriptor.kind != Pa5xPcgSoundKind::DrumKit) {
        result.blockers.push_back("Original address does not resolve uniquely to a Drum Kit in this SET"); return result;
    }
    if (!sound->drumKit.referenceGraphDecoded) {
        result.blockers.push_back("A decoded Drum Kit key/layer graph is required"); return result;
    }
    result.completeRamReferences = true;
    // Resolve each layer in its own exact KMP scope. A missing drum UID on one
    // key must not erase valid recordings elsewhere in the same kit. Reuse the
    // typed linker's duplicate-UID/number checks within each selected scope.
    std::map<std::size_t,Pa5xDrumKitSampleLinks> scopedLinks;
    for (std::size_t i = 0; i < sound->drumKit.layers.size(); ++i) {
        const auto& layer = sound->drumKit.layers[i];
        Pa5xDrumLayerSampleLink link;
        link.layer = i; link.ram = layer.sampleBankRaw == 1;
        link.drumSampleId = layer.drumSampleId;
        if (layer.sampleBankRaw == 0) link.blocker = "Factory ROM drum content is not supplied by User PCM";
        else if (!link.ram) link.blocker = "Drum sample bank code is unsupported";
        else if (!layer.hasDrumSampleId || layer.drumSampleId == 0)
            link.blocker = "RAM drum reference has no exact UID";
        else {
            const auto found = impl_->drumSamples.find(layer.drumSampleId);
            if (found == impl_->drumSamples.end() || found->second.empty())
                link.blocker = "Exact Drum Sample UID is missing from this SET's KMP mapping";
            else {
                const auto scope = found->second.front().file;
                const bool sameScope = std::all_of(found->second.begin(),found->second.end(),
                    [scope](const Impl::Location& location) { return location.file == scope; });
                if (!sameScope) link.blocker = "This Drum Sample UID is ambiguous across KMP scopes";
                else {
                    auto cached = scopedLinks.find(scope);
                    if (cached == scopedLinks.end())
                        cached = scopedLinks.emplace(scope,linkPa5xDrumKitSamples(
                            sound->drumKit,impl_->kmp[scope].index)).first;
                    const auto& links = cached->second.layers;
                    const auto selected = std::find_if(links.begin(),links.end(),
                        [i](const Pa5xDrumLayerSampleLink& item) { return item.layer == i; });
                    if (selected != links.end()) link = *selected;
                    else link.blocker = "The typed KMP linker did not return this Drum Kit layer";
                }
            }
        }
        if (layer.sampleBankRaw != 0 && !link.resolved) result.completeRamReferences = false;
        result.layers.push_back(std::move(link));
    }
    result.blockers.push_back("Linked User drum recordings use simplified sample playback; original Drum Kit DSP remains unsupported");
    return result;
}
Pa5xSampleAudio Pa5xSetBank::decodeSample(std::uint64_t uid, std::size_t maximumFrames) const {
    const auto fail = [](const std::string& error) { Pa5xSampleAudio result; result.error = error; return result; };
    if (!impl_->status.indexed) return fail("SET bank has not completed validation");
    const auto source = impl_->pcmSamples.find(uid), metadata = impl_->kmpSamples.find(uid);
    if (source == impl_->pcmSamples.end() || source->second.size() != 1 ||
        metadata == impl_->kmpSamples.end() || metadata->second.size() != 1)
        return fail("Sample UID must resolve uniquely in both PCM and KMP within this SET");
    const auto pcm = source->second.front(), kmp = metadata->second.front();
    const auto& file = impl_->pcm[pcm.file]; const auto& sample = impl_->kmp[kmp.file].index.samples[kmp.object];
    std::vector<std::uint8_t> bytes; std::string error;
    if (!read(file.path,bytes,error)) return fail(error);
    // Revalidate current bytes rather than decoding stale offsets if a user
    // replaces a source PCM file after the bank was loaded.
    const auto current = inspectPa5xSampleBytes(bytes,true);
    if (!current.valid || current.kind != Pa5xSampleContainerKind::PcmSamples) return fail("PCM source changed or became invalid; reload the SET");
    const Pa5xSampleObject* selected = nullptr;
    for (const auto& object : current.objects) if (object.hasId && object.resourceId == uid) {
        if (selected != nullptr) return fail("PCM source now contains a duplicate UID; reload the SET");
        selected = &object;
    }
    if (selected == nullptr) return fail("PCM source no longer contains the requested UID; reload the SET");
    return decodePa5xSampleAudio(bytes,*selected,sample,maximumFrames);
}
Pa5xMultisampleImport Pa5xSetBank::buildMultisample(std::uint64_t uid,
    const Pa5xMultisampleBuildOptions& options, Pa5xMultisampleCache* cache) const {
    const auto found = impl_->multisamples.find(uid);
    if (!impl_->status.indexed || found == impl_->multisamples.end() || found->second.size() != 1) {
        Pa5xMultisampleImport failed; failed.resourceId = uid;
        failed.blockers.push_back({"MULTISAMPLE_UID_UNRESOLVED",uid,0,
            "Multisample UID is absent, ambiguous or the SET bank has not completed validation"});
        return failed;
    }
    const auto location = found->second.front();
    const auto& kmp = impl_->kmp[location.file].index;
    // The grouped loader reads and revalidates each source PCM once while
    // building this multisample. Calling decodeSample for each zone's UID
    // would reread the same multi-megabyte file for every recording.
    // The builder still checks the exact UID, source metadata and KMP rate.
    return buildPa5xMultisample(kmp,location.object,pcmInventories(),{},cache,options);
}

Pa5xSampleImport Pa5xSetBank::buildSample(std::uint64_t uid,
    const Pa5xMultisampleBuildOptions& options, Pa5xMultisampleCache* externalCache) const {
    return buildSampleFrom(*impl_,uid,options,externalCache);
}
Pa5xSampleImport Pa5xSetBank::buildSampleFrom(const Impl& bank,std::uint64_t uid,
    const Pa5xMultisampleBuildOptions& options, Pa5xMultisampleCache* externalCache) const {
    Pa5xSampleImport out;
    if (stopped(options.cancel)) { out.error="Sample preparation cancelled"; return out; }
    if (!bank.status.recognized || bank.status.cancelled) { out.error="No loaded User sample bank"; return out; }
    const auto pcmFound=bank.pcmSamples.find(uid), kmpFound=bank.kmpSamples.find(uid);
    if (uid==0 || pcmFound==bank.pcmSamples.end() || pcmFound->second.size()!=1 ||
        kmpFound==bank.kmpSamples.end() || kmpFound->second.empty()) {
        out.error="User sample UID is missing or ambiguous in PCM/KMP"; return out;
    }
    const auto pcmLocation=pcmFound->second.front(), kmpLocation=kmpFound->second.front();
    const auto& source=bank.pcm[pcmLocation.file];
    const auto& expected=source.index.objects[pcmLocation.object];
    const auto& sample=bank.kmp[kmpLocation.file].index.samples[kmpLocation.object];
    if(!expected.audioMetadataDecoded||expected.encrypted){
        out.error=expected.decodeError.empty()?"User PCM audio metadata is unsupported":expected.decodeError;
        return out;
    }
    for (const auto& location:kmpFound->second) {
        const auto& other=bank.kmp[location.file].index.samples[location.object];
        if (other.sampleRate!=sample.sampleRate || other.packedData!=sample.packedData ||
            other.predictor1!=sample.predictor1 || other.predictor2!=sample.predictor2 ||
            other.originalNote!=sample.originalNote) {
            out.error="User sample UID has conflicting KMP playback metadata"; return out;
        }
    }
    const auto convention=options.endConvention==Pa5xSampleEndConvention::Unknown
        ? Pa5xSampleEndConvention::KorgLoopBoundary:options.endConvention;
    auto playback=inspectPa5xSamplePlayback(expected,sample,convention);
    const auto count=static_cast<std::uint64_t>(expected.encodedSampleCount);
    if (count==0 || count>options.maximumSamplesPerWaveform) { out.error="User sample exceeds waveform decode limit"; return out; }
    std::uint64_t first=playback.sampleStartFrame, end=playback.sampleEndFrame;
    bool loop=playback.loopEnabled;
    auto loopStart=playback.loopStartFrame, loopEnd=playback.loopEndFrame;
    if (!playback || first>=end || end>count) {
        // Basic sample mode uses the bounded recording when an original
        // playback parameter cannot be represented; it never invents audio.
        first=0;end=count;loop=false;
        out.warnings.push_back("Sample playback uses the full recording without an unverified loop: "+playback.error);
    }
    if (loop && (loopStart<first || loopStart>=loopEnd || loopEnd>end)) {
        loop=false;out.warnings.push_back("Invalid sample loop disabled for sample playback");
    }
    out.reverse=playback.flagsDecoded&&playback.reverse;
    out.gainDb=playback.flagsDecoded?playback.gainDb:0.0F;
    out.usesDerivedMetadata=true;
    for (const auto& warning:playback.uncertainties) out.warnings.push_back(warning);
    Pa5xMultisampleCache localCache;
    auto& cache=externalCache?*externalCache:localCache;
    std::ostringstream identity;
    identity<<"Pa5xUserSampleCache2:"<<source.path<<':'<<source.contentHash<<':'<<uid<<':'<<sample.packedData<<':'<<sample.predictor1<<':'<<sample.predictor2
        <<':'<<static_cast<int>(sample.originalNote)<<':'<<expected.sampleRate<<':'<<first<<':'<<end
        // This is the immutable decoded AUDIO identity. Keep its previous
        // spelling/extent so fixing playback metadata reuses existing svpcm
        // files, without rereading or decoding the original PCM recordings.
        <<':'<<loop<<':'<<loopStart<<':'
        <<(loop&&convention==Pa5xSampleEndConvention::KorgLoopBoundary?end:loopEnd);
    const auto key=identity.str();
    // A single preparation may explicitly request different loop policies.
    // Audio bytes can be shared on disk; SampleData playback bounds cannot.
    const auto memoryKey=key+":PlaybackLoopEnd:"+std::to_string(loopEnd);
    const auto cached=cache.samples.find(memoryKey);
    if (cached!=cache.samples.end()) { out.sample=cached->second; return out; }
    const auto previousError=cache.sampleErrors.find(memoryKey);
    if(previousError!=cache.sampleErrors.end()){out.error=previousError->second;return out;}
    // Keep failures after the bounded encoded buffer is released. Reopening
    // the same immutable source for another UID cannot repair a failed full
    // read, hash check or container parse within this preparation operation.
    // The NUL separator avoids confusing path/hash boundaries; this identity
    // is never shared with another source just because its basename matches.
    const auto sourceIdentity=source.path+'\0'+source.contentHash;
    const auto rememberSampleError=[&] {
        if(!out.error.empty())cache.sampleErrors.emplace(memoryKey,out.error);
    };
    const auto rememberSourceError=[&] {
        if(!out.error.empty())cache.sourceErrors.emplace(sourceIdentity,out.error);
        rememberSampleError();
    };
    if (cache.decodedFrames==0 && !cache.samples.empty()) {
        for (const auto& entry:cache.samples) if(entry.second)
            cache.decodedFrames+=static_cast<std::size_t>(entry.second->preloadedFrameCount());
    }
    const auto budget=std::min(options.maximumTotalFrames,cache.maximumDecodedFrames);
    const auto retainedFrames=static_cast<std::size_t>(end-first);
    // Honor the sample's stored preload-only flag when bounded resident memory
    // permits it. A shortage can still use streaming, with an explicit warning.
    bool preloadOnly=options.respectPreloadOnly&&playback.flagsDecoded&&playback.doNotStream;
    const auto remaining=cache.decodedFrames<=budget?budget-cache.decodedFrames:0U;
    if(preloadOnly&&retainedFrames>remaining&&!options.streamCacheDirectory.empty()){
        preloadOnly=false;
        out.warnings.push_back("Preload-only recording exceeds available RAM; streamed cache is used");
    }
    const bool streamed=!options.streamCacheDirectory.empty()&&!preloadOnly;
    const auto residentFrames=streamed?std::min(retainedFrames,options.preloadFrames):retainedFrames;
    if (cache.decodedFrames>budget || residentFrames>budget-cache.decodedFrames) {
        out.error="SET sample preload memory budget reached; remaining zones are silent"; return out;
    }
    auto native=std::make_shared<silveton::sampler::SampleData>();
    native->name=sample.name;native->sourcePath=source.path;native->sourceIdentity=key;
    native->sampleRate=expected.sampleRate;native->channels=1;
    native->rootKey=sample.originalNote<=127?sample.originalNote:60;
    native->totalFrames=retainedFrames;native->loop.enabled=loop;
    if(loop){native->loop.startFrame=loopStart-first;native->loop.endFrame=loopEnd-first;}
    Pa5xSampleDiskSpec diskSpec{key,uid,retainedFrames,expected.sampleRate};
    if(streamed){
        auto disk=openPa5xSampleDiskCache(options.streamCacheDirectory,diskSpec,options.preloadFrames);
        if(disk){
            native->stream=std::move(disk.stream);native->interleaved=std::move(disk.attackPrefix);
            if(out.reverse&&native->stream)warmPa5xReverseSampleEntry(*native->stream);
            cache.decodedFrames+=static_cast<std::size_t>(native->preloadedFrameCount());
            cache.samples.emplace(memoryKey,native);out.sample=std::move(native);out.diskCacheHit=true;return out;
        }
    }
    // A failure repairing one recording must not silence another recording
    // whose decoded disk cache is already valid. Only suppress another raw
    // source repair after that recording's ordinary cache-open opportunity.
    const auto previousSourceError=cache.sourceErrors.find(sourceIdentity);
    if(previousSourceError!=cache.sourceErrors.end()){out.error=previousSourceError->second;return out;}
    if (cache.encodedPath!=source.path || (!cache.encodedIndex&&cache.encodedError.empty())) {
        cache.encodedPath=source.path;cache.encodedError.clear();cache.encodedIndex.reset();cache.encodedBytes.clear();
        if (!read(source.path,cache.encodedBytes,out.error)) {
            cache.encodedError=out.error;rememberSourceError();return out;
        }
        out.sourceFileRead=true;
        // A rare missing/corrupt decoded recording can require repairing from
        // the source after a metadata-cache hit. Never publish changed audio
        // under the earlier source hash just because its headers still match.
        if(!source.contentHash.empty()&&pa5xSampleContentHash(cache.encodedBytes.data(),cache.encodedBytes.size())!=source.contentHash){
            out.error="PCM source content changed; reload the SET";cache.encodedError=out.error;
            cache.encodedBytes.clear();rememberSourceError();return out;
        }
        auto fresh=std::make_shared<Pa5xSampleIndex>(inspectPa5xSampleBytes(cache.encodedBytes,true));
        if (!fresh->valid || fresh->kind!=Pa5xSampleContainerKind::PcmSamples) {
            out.error="PCM source failed revalidation; reload the SET";cache.encodedError=out.error;
            cache.encodedBytes.clear();rememberSourceError();return out;
        }
        cache.encodedIndex=std::move(fresh);
    }
    if(!cache.encodedError.empty()){out.error=cache.encodedError;rememberSourceError();return out;}
    if(!cache.encodedIndex||cache.encodedBytes.empty()){
        out.error="PCM encoded source is unavailable";rememberSourceError();return out;
    }
    const Pa5xSampleObject* fresh=nullptr;
    for(const auto& object:cache.encodedIndex->objects) if(object.hasId&&object.resourceId==uid) {
        if(fresh) { out.error="PCM source now contains a duplicate sample UID";rememberSampleError();return out; }
        fresh=&object;
    }
    if (!fresh || fresh->sampleRate!=expected.sampleRate || fresh->sampleFormat!=expected.sampleFormat ||
        fresh->encodedSampleCount!=expected.encodedSampleCount || fresh->rawAudioHeaderWords!=expected.rawAudioHeaderWords ||
        fresh->channelTag!=expected.channelTag || fresh->pcmByteOrder!=expected.pcmByteOrder) {
        out.error="PCM sample metadata changed; reload the SET";rememberSampleError();return out;
    }
    if (stopped(options.cancel)) { out.error="Sample preparation cancelled";return out; }
    auto audio=decodePa5xSampleAudio(cache.encodedBytes,*fresh,sample,options.maximumSamplesPerWaveform);
    if (!audio) { out.error=audio.error;rememberSampleError();return out; }
    out.decodedFromSource=true;
    if (audio.sampleRate!=expected.sampleRate || audio.mono.size()!=count ||
        std::any_of(audio.mono.begin(),audio.mono.end(),[](float value){return !std::isfinite(value);})) {
        out.error="Decoded User sample does not match its UID/rate/frame metadata";rememberSampleError();return out;
    }
    if(streamed){
        auto disk=storePa5xSampleDiskCache(options.streamCacheDirectory,diskSpec,
            audio.mono.data()+static_cast<std::size_t>(first),retainedFrames,options.cancel,options.preloadFrames);
        if(!disk){
            if(stopped(options.cancel)){out.error=disk.error;return out;}
            if(!options.allowMemoryFallback||retainedFrames>remaining){out.error=disk.error;rememberSampleError();return out;}
            native->interleaved.assign(audio.mono.begin()+static_cast<std::ptrdiff_t>(first),audio.mono.begin()+static_cast<std::ptrdiff_t>(end));
            out.ramFallback=true;
            out.warnings.push_back("Disk cache unavailable; recording retained in RAM: "+disk.error);
        }else{
            native->stream=std::move(disk.stream);native->interleaved=std::move(disk.attackPrefix);
        }
    }else if(first==0&&end==count)native->interleaved=std::move(audio.mono);
    else native->interleaved.assign(audio.mono.begin()+static_cast<std::ptrdiff_t>(first),audio.mono.begin()+static_cast<std::ptrdiff_t>(end));
    if(out.reverse&&native->stream)warmPa5xReverseSampleEntry(*native->stream);
    cache.decodedFrames+=static_cast<std::size_t>(native->preloadedFrameCount());
    cache.samples.emplace(memoryKey,native);out.sample=std::move(native);return out;
}

Pa5xMultisampleImport Pa5xSetBank::buildSampleMultisample(std::uint64_t uid,
    const Pa5xMultisampleBuildOptions& options,Pa5xMultisampleCache* externalCache) const {
    Pa5xMultisampleImport out;out.resourceId=uid;out.usesDerivedMetadata=true;
    Pa5xMultisampleCache localCache;auto* cache=externalCache?externalCache:&localCache;
    std::ostringstream scope;
    scope<<impl_.get()<<':'<<uid<<':'<<static_cast<int>(options.endConvention)<<':'
        <<options.streamCacheDirectory<<':'<<options.preloadFrames;
    const auto cacheKey=scope.str();
    const auto cached=cache->sampleMultisamples.find(cacheKey);
    if(cached!=cache->sampleMultisamples.end()&&cached->second)return *cached->second;
    if(stopped(options.cancel)){out.blockers.push_back({"CANCELLED",uid,0,"Sample preparation cancelled"});return out;}
    const auto found=impl_->multisamples.find(uid);
    if(!impl_->status.recognized||impl_->status.cancelled||found==impl_->multisamples.end()||found->second.size()!=1){
        out.blockers.push_back({"USER_MULTISAMPLE_MISSING",uid,0,"User multisample UID is missing or ambiguous"});return out;
    }
    const auto where=found->second.front();const auto& kmp=impl_->kmp[where.file].index;
    const auto& source=kmp.multisamples[where.object];out.found=true;out.name=source.name;
    auto native=std::make_shared<silveton::sampler::Multisample>();
    native->name=source.name;native->sourceIdentity=impl_->status.rootPath+":UserSamples:"+std::to_string(uid);
    std::map<std::uint64_t,Pa5xSampleImport> prepared;
    for(std::size_t key=0;key<128;++key){
        if(stopped(options.cancel)){out.blockers.push_back({"CANCELLED",uid,key,"Sample preparation cancelled"});return out;}
        const auto local=source.zoneIndices[key];
        if(local==255U){++out.silentKeys;continue;}
        const auto zoneIndex=static_cast<std::size_t>(source.firstZone)+local;
        if(local>=source.zoneCount||zoneIndex>=kmp.keyZones.size()){++out.silentKeys;continue;}
        const auto& sourceZone=kmp.keyZones[zoneIndex];
        if(sourceZone.sampleIndex<0||static_cast<std::size_t>(sourceZone.sampleIndex)>=kmp.samples.size()){
            ++out.silentKeys;continue;
        }
        const auto sampleUid=kmp.samples[static_cast<std::size_t>(sourceZone.sampleIndex)].resourceId;
        auto existing=prepared.find(sampleUid);
        if(existing==prepared.end())existing=prepared.emplace(sampleUid,buildSample(sampleUid,options,cache)).first;
        const auto& imported=existing->second;
        if(!imported){
            ++out.silentKeys;
            if(std::find(out.missingSampleIds.begin(),out.missingSampleIds.end(),sampleUid)==out.missingSampleIds.end()){
                out.missingSampleIds.push_back(sampleUid);
                out.warnings.push_back(imported.error);
            }
            continue;
        }
        silveton::sampler::SampleZone zone;zone.sample=imported.sample;
        zone.keyLow=zone.keyHigh=static_cast<std::uint8_t>(key);
        zone.rootKey=sourceZone.originalNote<=127?sourceZone.originalNote:imported.sample->rootKey;
        zone.gainDb=imported.gainDb;zone.reverse=imported.reverse;
        if(sourceZone.pitchLevelDecoded)zone.tuneCents=static_cast<float>(sourceZone.pitch);
        else {
            const auto& raw=sourceZone.version8Record;
            const auto rawPitch=static_cast<unsigned>(raw[4])*256U+raw[5];
            zone.tuneCents=static_cast<float>(rawPitch<32768U?static_cast<int>(rawPitch):static_cast<int>(rawPitch)-65536);
        }
        // Adjacent keys referring to the same recording/parameters are one
        // native zone; the original KMP's exact 128-key assignment is retained.
        if(!native->zones.empty()){
            auto& previous=native->zones.back();
            if(static_cast<unsigned>(previous.keyHigh)+1U==key&&previous.sample==zone.sample&&
               previous.rootKey==zone.rootKey&&previous.tuneCents==zone.tuneCents&&
               previous.gainDb==zone.gainDb&&previous.reverse==zone.reverse){
                previous.keyHigh=static_cast<std::uint8_t>(key);++out.mappedKeys;continue;
            }
        }
        native->zones.push_back(std::move(zone));++out.mappedKeys;
    }
    for(const auto& entry:prepared)if(entry.second)++out.decodedSampleCount;
    out.parametersDecoded=false;out.samplesDecoded=!native->zones.empty();out.ready=out.samplesDecoded;
    if(out.ready)out.multisample=std::move(native);
    out.warnings.push_back("User sample playback: original zone gain and complete Korg DSP are not recreated");
    if(!out.ready)out.blockers.push_back({"NO_AVAILABLE_USER_ZONES",uid,0,"No available exact-UID User samples in this multisample"});
    // Memory-budget refusals may be retried with a different budget; a cancelled
    // candidate must never become the persistent result for this bank/UID.
    const bool budgetFailure=std::any_of(out.warnings.begin(),out.warnings.end(),[](const std::string& value){
        return value.find("memory budget")!=std::string::npos;
    });
    if(!budgetFailure&&!stopped(options.cancel))
        cache->sampleMultisamples.emplace(cacheKey,std::make_shared<Pa5xMultisampleImport>(out));
    return out;
}
} // namespace silveton::arranger
