#include "silveton/sampler/SourceAmpEnvelope.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <utility>

using namespace silveton::sampler;
namespace {
bool near(float a,float b,float tolerance=.00001F){return std::abs(a-b)<=tolerance;}
SourceOscillatorDsp profile(){
    SourceOscillatorDsp source;source.resourceVersion=2U;source.layoutCorroborated=true;
    source.dspRaw[2]=10U;source.dspRaw[10]=2U;source.dspRaw[11]=254U;
    source.dspRaw[21]=99U;source.dspRaw[28]=99U;source.dspRaw[43]=60U;
    source.dspRaw[78]=127U;source.dspRaw[80]=127U;
    source.amplitudeEnvelopeRaw[2]=99U;source.amplitudeEnvelopeRaw[4]=49U;
    source.amplitudeEnvelopeRaw[6]=80U;source.amplitudeEnvelopeRaw[20]=127U;
    source.lfoRaw[0]=6U;source.lfoRaw[1]=20U;source.lfoRaw[10]=6U;source.lfoRaw[11]=20U;
    source.multisampleLevelDecoded=true;source.multisampleLevelRaw=127U;
    source.pitchEnvelopePresent=true;source.outputRawPresent=true;source.outputRaw[1]=64U;
    return source;
}
void moduleBoundaries(){
    auto source=profile();const auto complete=sourceOscillatorSupport(source);
    assert(complete.pitch&&complete.pitchEnvelope&&complete.filter&&complete.filterEnvelope);
    assert(complete.lfo[0]&&complete.lfo[1]&&complete.amplitude&&complete.level&&complete.pan);
    source.dspRaw[30]=255U;source.dspRaw[31]=20U;
    const auto partial=sourceOscillatorSupport(source);assert(!partial.filter&&partial.pitch&&partial.amplitude);
    source=profile();source.manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Filter)|
        static_cast<std::uint16_t>(SourceOscillatorModule::FilterEnvelope)|static_cast<std::uint16_t>(SourceOscillatorModule::Lfo2);
    const auto manual=sourceOscillatorSupport(source);
    assert(!manual.filter&&!manual.filterEnvelope&&!manual.lfo[1]&&manual.lfo[0]&&manual.pitch);
    source.resourceVersion=4U;assert(!sourceOscillatorSupport(source).pitch);
}
void modulationHasActualContext(){
    std::array<float,128> cc{};std::array<bool,128> seen{};
    SourceModulationContext first;first.controllers=&cc;first.controllersSeen=&seen;
    first.key=60;first.velocity=32;first.releaseVelocity=96;first.portamentoSwitch=127;
    first.pressure=.4F;first.polyPressure=.7F;
    auto second=first;second.portamentoSwitch=0;
    assert(sourceModulationValues(first)[35]==1.0F&&sourceModulationValues(second)[35]==0.0F);
    assert(cc[65]==0.0F&&!seen[65]); // saved part state must not mutate shared input
    assert(sourceModulationValues(first)[24]==0.0F&&sourceModulationValues(first)[26]==0.0F);
    cc[16]=64.0F/127.0F;seen[16]=true;cc[17]=1.0F;seen[17]=true;
    cc[18]=64.0F/127.0F;seen[18]=true;
    auto values=sourceModulationValues(first);
    assert(near(values[24],0.0F)&&near(values[26],1.0F)&&near(values[25],64.0F/127.0F));
    assert(near(values[16],.7F)&&near(values[17],.4F)&&near(values[43],32.0F/127.0F));
    // Knob +/- and Knob [+] have different centres. The positive variant
    // retains the complete controller range, including its first half.
    constexpr std::array<unsigned,4> knobs{{17U,19U,20U,21U}};
    for(const int raw:{0,64,127}){
        for(const auto knob:knobs){cc[knob]=static_cast<float>(raw)/127.0F;seen[knob]=true;}
        values=sourceModulationValues(first);
        for(unsigned i=0;i<4U;++i){
            assert(near(values[26U+i],raw==0?-1.0F:raw==64?0.0F:1.0F));
            assert(near(values[30U+i],static_cast<float>(raw)/127.0F));
        }
    }
    first.released=true;values=sourceModulationValues(first);assert(near(values[43],96.0F/127.0F));
    first.key=36;assert(near(sourceModulationValues(first)[14],-1.0F));
    first.key=84;assert(near(sourceModulationValues(first)[14],1.0F));
    first.key=60;assert(near(sourceModulationValues(first)[14],0.0F));
    first.tempoBpm=60;assert(near(sourceModulationValues(first)[42],-1.0F));
    first.tempoBpm=240;assert(near(sourceModulationValues(first)[42],1.0F));
    first.controlEnabled=false;first.pressureEnabled=false;first.bendEnabled=false;
    values=sourceModulationValues(first);
    for(const unsigned index:{16U,17U,18U,19U,20U,24U,25U,26U,27U,28U,29U,30U,31U,32U,33U,35U})assert(values[index]==0.0F);
    for(const auto& [raw,semitones]:std::array<std::pair<unsigned,float>,7>{{{0,0},{50,.5F},{60,1},{65,2},{115,12},{196,-1},{141,-12}}})
        assert(near(sourcePitchSemitones(static_cast<std::uint8_t>(raw)),semitones));
}
void signedEnvelopeAndCancellation(){
    SourceEnvelopeCursor envelope;envelope.prepare(false);
    const std::array<float,5> levels{{-.7F,.9F,.2F,-.2F,-.4F}};
    envelope.configure(levels,{{0,0,0,0}},48000);envelope.trigger();
    assert(near(envelope.process(),-.2F)&&envelope.stage==SourceEnvelopeCursor::Stage::Sustain);
    envelope.release();assert(near(envelope.process(),-.4F)&&envelope.stage==SourceEnvelopeCursor::Stage::Released);
    envelope.prepare(false);envelope.configure(levels,{{.1F,.2F,.3F,.4F}},48000);envelope.trigger();
    envelope.release();assert(envelope.stage==SourceEnvelopeCursor::Stage::Idle&&envelope.process()==0.0F);
    SourceAmpEnvelope source;source.present=true;source.enabled=true;source.modulationEncodingSupported=true;
    source.levels={{30,99,49,80}};source.times={{0,0,0,20}};
    source.amsSources[0]=43U;source.amsIntensities[0]=40;source.amsDirections[0]=64U;
    assert(source.valid());SourceModulationContext context;context.velocity=32;context.releaseVelocity=96;
    const auto held=sourceAmpNoteIndices(source,sourceModulationValues(context));
    context.released=true;const auto released=sourceAmpNoteIndices(source,sourceModulationValues(context));
    assert(released.times[3]>held.times[3]&&near(released.times[3],20.0F+40.0F*96.0F/127.0F));
    SourceAmpCursor amp;amp.prepare(source,60,100);amp.configure(0,0,SourceAmpEnvelope::levelGain(80),100,48000);amp.trigger();
    amp.release();assert(amp.stage==SourceAmpCursor::Stage::Idle&&amp.process()==0.0F);
}
void lfoTempoAndNeutralControls(){
    std::array<std::uint8_t,10> raw{};raw[0]=6U;raw[1]=90U;raw[5]=128U;
    SourceLfoCursor lfo;lfo.reset(raw.data(),11U);SourceModulationValues input;SourceSoundEdits edits;
    lfo.configure(raw.data(),input,edits,120,48000);assert(std::abs(lfo.increment-8.0/48000.0)<1.0e-12);
    raw[5]=143U;lfo.configure(raw.data(),input,edits,120,48000);assert(std::abs(lfo.increment-.5/48000.0)<1.0e-12);
    raw[5]=0U;
    for(unsigned waveform=0;waveform<=20U;++waveform){
        raw[0]=static_cast<std::uint8_t>(waveform);lfo.reset(raw.data(),11U);lfo.configure(raw.data(),input,edits,120,48000);
        for(unsigned frame=0;frame<5000U;++frame){const float value=lfo.process(48000);assert(std::isfinite(value)&&std::abs(value)<=1.0001F);}
    }
    auto source=profile();source.dspRaw[6]=141U; // exact retained-12semitone depth
    SourceOscillatorRuntime absent,neutral;absent.prepare(&source,42U,0);neutral.prepare(&source,42U,0);
    SourceModulationContext context;SourceSoundEdits centre;
    for(int controller=71;controller<=78;++controller)assert(centre.setController(controller,64));
    absent.start(context,edits,48000);neutral.start(context,centre,48000);
    for(unsigned frame=0;frame<2000U;++frame){
        absent.tick(context,edits,48000,{{0,0}},{{false,false}});
        neutral.tick(context,centre,48000,{{0,0}},{{false,false}});
        assert(absent.pitchSemitones==neutral.pitchSemitones&&absent.amplitudeGain==neutral.amplitudeGain);
        float al=frame==0?.5F:0.0F,ar=al,nl=al,nr=al;absent.processFilter(al,ar);neutral.processFilter(nl,nr);
        assert(al==nl&&ar==nr&&std::isfinite(al)&&std::isfinite(absent.pitchSemitones));
    }
}
void serialFilterTopologyIsFinite(){
    for(const unsigned type:{0U,1U}){
        auto source=profile();source.dspRaw[20]=static_cast<std::uint8_t>(type);source.dspRaw[22]=99;
        SourceOscillatorRuntime runtime;runtime.prepare(&source,1U,0);SourceModulationContext context;SourceSoundEdits edits;
        runtime.start(context,edits,96000);float last=0;
        for(unsigned frame=0;frame<9600U;++frame){
            runtime.tick(context,edits,96000,{{0,0}},{{false,false}});
            float left=.5F,right=-.5F;runtime.processFilter(left,right);
            assert(std::isfinite(left)&&std::isfinite(right)&&near(left,-right,.0001F));last=left;
        }
        if(type==0U)assert(near(last,.5F,.001F));else assert(std::abs(last)<.001F);
    }
}
}
int main(){moduleBoundaries();modulationHasActualContext();signedEnvelopeAndCancellation();
    lfoTempoAndNeutralControls();serialFilterTopologyIsFinite();
    std::puts("PASS source helper module admission, controller/part isolation, signed EG and early release, exact pitch anchors, neutral edits, LFO tempo/waves and finite serial filters");}
