#include "silveton/sampler/SourceAmpEnvelope.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <utility>

using namespace silveton::sampler;
namespace {
bool near(float a,float b,float tolerance=.00001F){return std::abs(a-b)<=tolerance;}
SourceOscillatorDsp profile(){
    SourceOscillatorDsp source;source.resourceVersion=2U;source.layoutCorroborated=true;
    source.dspRaw[2]=10U;source.dspRaw[10]=2U;source.dspRaw[11]=254U;
    source.dspRaw[21]=99U;source.dspRaw[28]=99U;source.dspRaw[43]=60U;
    source.dspRaw[78]=127U;source.dspRaw[80]=127U;
    source.amplitudeEnvelopeRaw[2]=99U;source.amplitudeEnvelopeRaw[4]=49U;
    source.amplitudeEnvelopeRaw[6]=80U;source.amplitudeEnvelopeRaw[20]=127U;
    source.lfoRaw[0]=6U;source.lfoRaw[1]=20U;source.lfoRaw[10]=6U;source.lfoRaw[11]=20U;
    source.multisampleLevelDecoded=true;source.multisampleLevelRaw=127U;
    source.pitchEnvelopePresent=true;source.outputRawPresent=true;source.outputRaw[1]=64U;
    return source;
}
void moduleBoundaries(){
    auto source=profile();const auto complete=sourceOscillatorSupport(source);
    assert(complete.pitch&&complete.pitchEnvelope&&complete.filter&&complete.filterEnvelope);
    assert(complete.lfo[0]&&complete.lfo[1]&&complete.amplitude&&complete.level&&complete.pan);
    source.dspRaw[30]=255U;source.dspRaw[31]=20U;
    const auto partial=sourceOscillatorSupport(source);assert(!partial.filter&&partial.pitch&&partial.amplitude);
    source=profile();source.manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Filter)|
        static_cast<std::uint16_t>(SourceOscillatorModule::FilterEnvelope)|static_cast<std::uint16_t>(SourceOscillatorModule::Lfo2);
    const auto manual=sourceOscillatorSupport(source);
    assert(!manual.filter&&!manual.filterEnvelope&&!manual.lfo[1]&&manual.lfo[0]&&manual.pitch);
    source.resourceVersion=4U;assert(!sourceOscillatorSupport(source).pitch);
}
void modulationHasActualContext(){
    std::array<float,128> cc{};std::array<bool,128> seen{};
    SourceModulationContext first;first.controllers=&cc;first.controllersSeen=&seen;
    first.key=60;first.velocity=32;first.releaseVelocity=96;first.portamentoSwitch=127;
    first.pressure=.4F;first.polyPressure=.7F;
    auto second=first;second.portamentoSwitch=0;
    assert(sourceModulationValues(first)[35]==1.0F&&sourceModulationValues(second)[35]==0.0F);
    assert(cc[65]==0.0F&&!seen[65]); // saved part state must not mutate shared input
    assert(sourceModulationValues(first)[24]==0.0F&&sourceModulationValues(first)[26]==0.0F);
    cc[16]=64.0F/127.0F;seen[16]=true;cc[17]=1.0F;seen[17]=true;
    cc[18]=64.0F/127.0F;seen[18]=true;
    auto values=sourceModulationValues(first);
    assert(near(values[24],0.0F)&&near(values[26],1.0F)&&near(values[25],64.0F/127.0F));
    assert(near(values[16],.7F)&&near(values[17],.4F)&&near(values[43],32.0F/127.0F));
    // Knob +/- and Knob [+] have different centres. The positive variant
    // retains the complete controller range, including its first half.
    constexpr std::array<unsigned,4> knobs{{17U,19U,20U,21U}};
    for(const int raw:{0,64,127}){
        for(const auto knob:knobs){cc[knob]=static_cast<float>(raw)/127.0F;seen[knob]=true;}
        values=sourceModulationValues(first);
        for(unsigned i=0;i<4U;++i){
            assert(near(values[26U+i],raw==0?-1.0F:raw==64?0.0F:1.0F));
            assert(near(values[30U+i],static_cast<float>(raw)/127.0F));
        }
    }
    first.released=true;values=sourceModulationValues(first);assert(near(values[43],96.0F/127.0F));
    first.key=36;assert(near(sourceModulationValues(first)[14],-1.0F));
    first.key=84;assert(near(sourceModulationValues(first)[14],1.0F));
    first.key=60;assert(near(sourceModulationValues(first)[14],0.0F));
    first.tempoBpm=60;assert(near(sourceModulationValues(first)[42],-1.0F));
    first.tempoBpm=240;assert(near(sourceModulationValues(first)[42],1.0F));
    first.controlEnabled=false;first.pressureEnabled=false;first.bendEnabled=false;
    values=sourceModulationValues(first);
    for(const unsigned index:{16U,17U,18U,19U,20U,24U,25U,26U,27U,28U,29U,30U,31U,32U,33U,35U})assert(values[index]==0.0F);
    for(const auto& [raw,semitones]:std::array<std::pair<unsigned,float>,7>{{{0,0},{50,.5F},{60,1},{65,2},{115,12},{196,-1},{141,-12}}})
        assert(near(sourcePitchSemitones(static_cast<std::uint8_t>(raw)),semitones));
}
void signedEnvelopeAndCancellation(){
    SourceEnvelopeCursor envelope;envelope.prepare(false);
    const std::array<float,5> levels{{-.7F,.9F,.2F,-.2F,-.4F}};
    envelope.configure(levels,{{0,0,0,0}},48000);envelope.trigger();
    assert(near(envelope.process(),-.2F)&&envelope.stage==SourceEnvelopeCursor::Stage::Sustain);
    envelope.release();assert(near(envelope.process(),-.4F)&&envelope.stage==SourceEnvelopeCursor::Stage::Released);
    envelope.prepare(false);envelope.configure(levels,{{.1F,.2F,.3F,.4F}},48000);envelope.trigger();
    envelope.release();assert(envelope.stage==SourceEnvelopeCursor::Stage::Idle&&envelope.process()==0.0F);
    SourceAmpEnvelope source;source.present=true;source.enabled=true;source.modulationEncodingSupported=true;
    source.levels={{30,99,49,80}};source.times={{0,0,0,20}};
    source.amsSources[0]=43U;source.amsIntensities[0]=40;source.amsDirections[0]=64U;
    assert(source.valid());SourceModulationContext context;context.velocity=32;context.releaseVelocity=96;
    const auto held=sourceAmpNoteIndices(source,sourceModulationValues(context));
    context.released=true;const auto released=sourceAmpNoteIndices(source,sourceModulationValues(context));
    assert(released.times[3]>held.times[3]&&near(released.times[3],20.0F+40.0F*96.0F/127.0F));
    SourceAmpCursor amp;amp.prepare(source,60,100);amp.configure(0,0,SourceAmpEnvelope::levelGain(80),100,48000);amp.trigger();
    amp.release();assert(amp.stage==SourceAmpCursor::Stage::Idle&&amp.process()==0.0F);
}
void lfoTempoAndNeutralControls(){
    std::array<std::uint8_t,10> raw{};raw[0]=6U;raw[1]=90U;raw[5]=128U;
    SourceLfoCursor lfo;lfo.reset(raw.data(),11U);SourceModulationValues input;SourceSoundEdits edits;
    lfo.configure(raw.data(),input,edits,120,48000);assert(std::abs(lfo.increment-8.0/48000.0)<1.0e-12);
    raw[5]=143U;lfo.configure(raw.data(),input,edits,120,48000);assert(std::abs(lfo.increment-.5/48000.0)<1.0e-12);
    raw[5]=0U;
    for(unsigned waveform=0;waveform<=20U;++waveform){
        raw[0]=static_cast<std::uint8_t>(waveform);lfo.reset(raw.data(),11U);lfo.configure(raw.data(),input,edits,120,48000);
        for(unsigned frame=0;frame<5000U;++frame){const float value=lfo.process(48000);assert(std::isfinite(value)&&std::abs(value)<=1.0001F);}
    }
    auto source=profile();source.dspRaw[6]=141U; // exact retained-12semitone depth
    SourceOscillatorRuntime absent,neutral;absent.prepare(&source,42U,0);neutral.prepare(&source,42U,0);
    SourceModulationContext context;SourceSoundEdits centre;
    for(int controller=71;controller<=78;++controller)assert(centre.setController(controller,64));
    absent.start(context,edits,48000);neutral.start(context,centre,48000);
    for(unsigned frame=0;frame<2000U;++frame){
        absent.tick(context,edits,48000,{{0,0}},{{false,false}});
        neutral.tick(context,centre,48000,{{0,0}},{{false,false}});
        assert(absent.pitchSemitones==neutral.pitchSemitones&&absent.amplitudeGain==neutral.amplitudeGain);
        float al=frame==0?.5F:0.0F,ar=al,nl=al,nr=al;absent.processFilter(al,ar);neutral.processFilter(nl,nr);
        assert(al==nl&&ar==nr&&std::isfinite(al)&&std::isfinite(absent.pitchSemitones));
    }
}
void unchangedCoefficientsKeepHistoryAndFollowModulation(){
    SourceFilterSection cached,reference;
    for(unsigned i=0;i<4096U;++i){
        const float hz=i<1000U?250.0F:(i<2000U?7500.0F:250.0F);
        const double q=i<3000U?.70710678:1.2;
        const double sr=i<3500U?96000.0:48000.0;
        cached.set(hz,q,sr);
        const double g=std::tan(3.141592653589793*std::clamp(static_cast<double>(hz),5.0,.45*sr)/std::max(1.0,sr));
        reference.k=1.0/std::clamp(q,.5,16.0);
        reference.a1=1.0/(1.0+g*(g+reference.k));reference.a2=g*reference.a1;reference.a3=g*reference.a2;
        assert(cached.a1==reference.a1&&cached.a2==reference.a2&&cached.a3==reference.a3&&cached.k==reference.k);
        const float x=.25F*std::sin(static_cast<float>(i)*.031F);
        assert(cached.process(x,0U,false)==reference.process(x,0U,false));
        assert(cached.process(-x,1U,true)==reference.process(-x,1U,true));
    }
    SourceAmpEnvelope source;source.present=true;source.enabled=true;source.modulationEncodingSupported=true;
    source.levels={{0,99,69,75}};source.times={{25,34,36,21}};
    source.amsSources={{43U,15U,15U}};source.amsIntensities={{30,20,10}};
    source.amsDirections={{64U,1U,4U}};assert(source.valid());
    SourceAmpCursor repeated,changed;SourceModulationValues values{};
    repeated.prepare(source,60,90);changed.prepare(source,60,90);
    auto apply=[](SourceAmpCursor& cursor){auto d=cursor.defaults;cursor.configure(d.attackSec*1000.0F,d.decaySec*1000.0F,d.sustain,d.releaseSec*1000.0F,96000.0);};
    repeated.rekey(source,60,90,&values);changed.rekey(source,60,90,&values);apply(repeated);apply(changed);
    repeated.trigger();changed.trigger();
    for(unsigned i=0;i<20000U;++i){
        bool update=i==6000U||i==9000U||i==12000U;
        if(i==6000U)values.value[15]=.9F;
        if(i==9000U)values.value[43]=.8F;
        if(i==12000U)values.value[15]=.2F;
        repeated.rekey(source,60,90,&values);apply(repeated);
        if(update){changed.rekey(source,60,90,&values);apply(changed);}
        if(i==9000U){repeated.release();changed.release();}
        assert(repeated.defaults.attackSec==changed.defaults.attackSec&&repeated.defaults.decaySec==changed.defaults.decaySec&&
            repeated.defaults.sustain==changed.defaults.sustain&&repeated.defaults.releaseSec==changed.defaults.releaseSec);
        assert(repeated.process()==changed.process());assert(repeated.stage==changed.stage);
    }
    // Reusing the same cursor must rebuild its initial coefficients after prepare.
    repeated.prepare(source,60,90);changed.prepare(source,60,90);
    apply(repeated);apply(changed);repeated.trigger();changed.trigger();
    for(unsigned i=0;i<1000U;++i)assert(repeated.process()==changed.process());
}
// Recompute the 0.1.79 output equations for every sample, using the live AMS
// values after the envelope/LFO updates. No caching in this reference.
void compareUncachedOutputs(const SourceOscillatorRuntime& runtime,const SourceModulationContext& context,
                            const SourceSoundEdits& edits){
    const auto& d=runtime.source->dspRaw;const auto& source=*runtime.source;
    const auto& support=runtime.support;const auto& inputs=runtime.inputs;
    const auto raw=[&](unsigned i){return static_cast<float>(sourceSignedByte(d[i]));};
    float pitch=0.0F,amp=runtime.levelGain;
    if(support.pitch){
        pitch=(static_cast<float>(context.key)-60.0F)*(raw(2U)*.1F-1.0F)+
            sourcePitchSemitones(d[1])*inputs[d[0]]+raw(12U)*inputs[24U];
        for(unsigned i=0U;i<2U;++i){
            if(source.overridden(i==0U?SourceOscillatorModule::Lfo1:SourceOscillatorModule::Lfo2))continue;
            const float sourceDepth=sourcePitchSemitones(d[6U+i])*100.0F;
            const float depth=i==0U||sourceDepth!=0.0F?
                std::copysign(sourceSoundEditDepthCents(std::abs(sourceDepth),edits.controller(77)),sourceDepth):0.0F;
            const float amount=depth*.01F+sourcePitchSemitones(d[14U+i])*inputs[19U]+
                sourcePitchSemitones(d[17U+2U*i])*inputs[d[16U+2U*i]];
            pitch+=inputs[4U+i]*amount;
        }
    }
    if(support.pitchEnvelope)pitch+=inputs[1U]*(sourcePitchSemitones(d[3])+sourcePitchSemitones(d[5])*inputs[d[4]]);
    if(support.amplitude){
        const float velocity=inputs[15U],intensity=raw(81U)/99.0F*std::clamp(context.velocityLevelScale,0.0F,1.0F);
        const float velocityGain=intensity>=0.0F?1.0F-intensity*(1.0F-velocity):1.0F+intensity*velocity;
        const float adjustment=raw(83U)*inputs[d[82]]/99.0F+inputs[10U];
        const float amsGain=adjustment>=0.0F?1.0F+7.0F*adjustment:std::max(0.0F,1.0F+adjustment);
        float tremolo=1.0F;
        for(unsigned i=0U;i<2U;++i)if(!source.overridden(i==0U?SourceOscillatorModule::Lfo1:SourceOscillatorModule::Lfo2))
            tremolo+=inputs[4U+i]*(raw(84U+i)+raw(87U+2U*i)*inputs[d[86U+2U*i]])/99.0F;
        amp=std::clamp(runtime.levelGain*velocityGain*amsGain*std::max(0.0F,tremolo),0.0F,1.0F);
    }
    assert(pitch==runtime.pitchSemitones&&amp==runtime.amplitudeGain);
    if(support.pan){const auto& p=source.outputRaw;
        const float base=p[1]==0U?runtime.randomPan:(static_cast<float>(p[1])-64.0F)/63.0F;
        assert(runtime.pan==std::clamp(base+static_cast<float>(sourceSignedByte(p[3]))*.02F*inputs[p[2]],-1.0F,1.0F));}
}
void outputCachePreservesAudioRateModulation(){
    for(unsigned mode=0;mode<8;++mode){
        auto source=profile();auto& d=source.dspRaw;
        d[81]=60;d[82]=17;d[83]=20;d[0]=17;d[1]=25;d[12]=1;
        source.outputRaw[2]=17;source.outputRaw[3]=20;
        if(mode&1U){d[0]=3;d[1]=40;d[3]=35;d[4]=4;d[5]=30;d[6]=65;d[7]=35;d[16]=3;d[17]=40;}
        if(mode&2U){d[82]=3;d[84]=70;d[86]=1;d[87]=20;d[85]=20;}
        if(mode&4U){source.outputRaw[2]=4;source.outputRaw[3]=20;}
        SourceOscillatorRuntime runtime;runtime.prepare(&source,123U,-.3F);
        assert(runtime.support.pitch&&runtime.support.pitchEnvelope&&runtime.support.amplitude&&runtime.support.pan);
        assert(runtime.pitchAudioRate==((mode&1U)!=0)&&runtime.ampAudioRate==((mode&2U)!=0)&&runtime.panAudioRate==((mode&4U)!=0));
        SourceModulationContext context;std::array<float,128> cc{};std::array<bool,128> seen{};
        context.controllers=&cc;context.controllersSeen=&seen;SourceSoundEdits edits;
        runtime.start(context,edits,96000.0);
        for(unsigned i=0;i<12000;++i){
            context.amplitudeEnvelope=.5F+.4F*std::sin(i*.013F);
            context.velocityLevelScale=(i%23U<10U)?.8F:1.0F;
            context.key=i%113U<48U?60U:74U;
            context.velocity=static_cast<std::uint8_t>(32+i%85U);
            cc[16]=static_cast<float>(i%128U)/127.0F;seen[16]=true;
            context.pressure=static_cast<float>(i%93U)/92.0F;
            const auto edit=(i%117U<35U)?90:64;edits.setController(77,edit);
            const std::array<float,2> shared{{std::sin(i*.031F),std::cos(i*.027F)}};
            if(i==4319U){context.released=true;runtime.inputs=sourceModulationValues(context);runtime.configureEnvelopes(edits,96000.0);runtime.release();}
            runtime.tick(context,edits,96000.0,shared,{{true,true}});
            compareUncachedOutputs(runtime,context,edits);
            assert(runtime.pitchMultiplier()==std::exp2(static_cast<double>(std::clamp(runtime.pitchSemitones,-120.0F,120.0F))/12.0));
        }
    }
}
void cachedControlConfigurationsPreserveState(){
    auto source=profile();auto& d=source.dspRaw;auto& p=source.pitchEnvelopeRaw;
    d[58]=12;d[59]=25;d[60]=60;d[61]=40;d[62]=10;d[63]=25;d[64]=30;d[65]=35;
    d[67]=1;d[70]=15;d[71]=15;d[69]=1;d[74]=3;d[75]=25;
    p[0]=10;p[1]=20;p[2]=60;p[3]=30;p[4]=40;p[5]=20;p[6]=15;p[7]=10;p[12]=1;p[10]=3;p[11]=33;p[13]=1;
    source.lfoRaw[6]=15;source.lfoRaw[7]=25;source.lfoRaw[8]=3;source.lfoRaw[9]=10;
    source.lfoRaw[3]=20;source.lfoRaw[4]=10;
    SourceOscillatorRuntime cached,uncached;cached.prepare(&source,123U,.5F);uncached.prepare(&source,123U,.5F);
    SourceModulationContext context;SourceSoundEdits edits;double rate=96000;
    assert(cached.support.pitchEnvelope&&cached.support.filterEnvelope&&cached.support.lfo[0]);
    cached.start(context,edits,rate);uncached.start(context,edits,rate);
    for(unsigned i=0;i<18000U;++i){
        context.amplitudeEnvelope=(i%7000U<3500U)?.2F:.7F;
        context.velocity=i%5000U<2000U?50U:90U;context.tempoBpm=i<10000U?120.0F:144.0F;
        edits.setController(73,i<2500U?64:73);edits.setController(76,i<5000U?64:83);edits.setController(78,i<12000U?64:79);
        if(i==11001U){cached.release();uncached.release();}
        // The reference executes all coefficient and output computations every
        // time the uncached engine used to do so. The cursor clocks are identical.
        uncached.envelopeConfigValid=false;uncached.outputCacheValid=false;
        for(auto& lfo:uncached.lfo)lfo.configValid=false;
        cached.tick(context,edits,rate,{{0,0}},{{false,false}});
        uncached.tick(context,edits,rate,{{0,0}},{{false,false}});
        assert(cached.pitchEnvelope.value==uncached.pitchEnvelope.value&&cached.pitchEnvelope.stage==uncached.pitchEnvelope.stage);
        assert(cached.filterEnvelope.value==uncached.filterEnvelope.value&&cached.filterEnvelope.stage==uncached.filterEnvelope.stage);
        for(unsigned l=0;l<2;++l){assert(cached.lfo[l].value==uncached.lfo[l].value&&cached.lfo[l].phase==uncached.lfo[l].phase&&cached.lfo[l].increment==uncached.lfo[l].increment);}
        assert(cached.inputs.value==uncached.inputs.value&&cached.pitchSemitones==uncached.pitchSemitones&&cached.amplitudeGain==uncached.amplitudeGain&&cached.pan==uncached.pan);
        float a=.1F*std::sin(i*.017F),b=-a,c=a,e=b;cached.processFilter(a,b);uncached.processFilter(c,e);assert(a==c&&b==e);
    }
}
void serialFilterTopologyIsFinite(){
    for(const unsigned type:{0U,1U}){
        auto source=profile();source.dspRaw[20]=static_cast<std::uint8_t>(type);source.dspRaw[22]=99;
        SourceOscillatorRuntime runtime;runtime.prepare(&source,1U,0);SourceModulationContext context;SourceSoundEdits edits;
        runtime.start(context,edits,96000);float last=0;
        for(unsigned frame=0;frame<9600U;++frame){
            runtime.tick(context,edits,96000,{{0,0}},{{false,false}});
            float left=.5F,right=-.5F;runtime.processFilter(left,right);
            assert(std::isfinite(left)&&std::isfinite(right)&&near(left,-right,.0001F));last=left;
        }
        if(type==0U)assert(near(last,.5F,.001F));else assert(std::abs(last)<.001F);
    }
}
}
int main(){moduleBoundaries();modulationHasActualContext();signedEnvelopeAndCancellation();
    lfoTempoAndNeutralControls();serialFilterTopologyIsFinite();unchangedCoefficientsKeepHistoryAndFollowModulation();outputCachePreservesAudioRateModulation();cachedControlConfigurationsPreserveState();
    std::puts("PASS source helper module admission, controller/part isolation, signed EG and early release, exact pitch anchors, neutral edits, LFO tempo/waves and finite serial filters");}
