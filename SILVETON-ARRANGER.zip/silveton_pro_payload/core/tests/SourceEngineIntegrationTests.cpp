#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SourceOscillatorDsp.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <vector>

using namespace silveton::sampler;
namespace {
constexpr double sampleRate=48000.0;
constexpr std::uint32_t blockSize=256U;
std::shared_ptr<Program> sound(bool sine=false){
    auto pcm=std::make_shared<SampleData>();pcm->name="Synthetic source engine fixture";
    pcm->sampleRate=48000;pcm->channels=1;pcm->rootKey=60;pcm->interleaved.resize(256U);
    for(std::size_t i=0;i<pcm->interleaved.size();++i)
        pcm->interleaved[i]=sine?.2F*static_cast<float>(std::sin(6.283185307179586*static_cast<double>(i)/256.0)):.2F;
    pcm->loop.enabled=true;pcm->loop.endFrame=pcm->interleaved.size();
    auto multisample=std::make_shared<Multisample>();SampleZone zone;zone.sample=pcm;multisample->zones.push_back(zone);
    auto program=std::make_shared<Program>();ProgramLayer layer;layer.multisample=multisample;layer.filter.mode=FilterMode::Bypass;
    layer.ampEnvelope={0,0,1,.05F};
    layer.sourceAmpEnvelope.present=true;layer.sourceAmpEnvelope.enabled=true;
    layer.sourceAmpEnvelope.levels={{0,99,99,99}};layer.sourceAmpEnvelope.times={{50,0,0,50}};
    program->layers.push_back(layer);return program;
}
std::shared_ptr<EngineState> state(const ProgramPtr& program,std::uint32_t generation=1U){
    auto value=std::make_shared<EngineState>();value->combiGeneration=generation;
    auto& part=value->combi.uppers[0];part.program=program;part.enabled=true;part.breathEnabled=false;
    value->global.masterGainDb=0;value->global.limiterEnabled=false;return value;
}
std::vector<float> render(SamplerEngine& engine,std::uint32_t frames){
    std::vector<float> output(static_cast<std::size_t>(frames)*2U);
    for(std::uint32_t offset=0;offset<frames;offset+=blockSize)
        engine.render(output.data()+static_cast<std::size_t>(offset)*2U,std::min(blockSize,frames-offset));
    for(const float value:output)assert(std::isfinite(value));
    return output;
}
float channelRms(const std::vector<float>& output,unsigned channel){
    double sum=0;for(std::size_t i=channel;i<output.size();i+=2U)sum+=static_cast<double>(output[i])*output[i];
    return static_cast<float>(std::sqrt(sum/(static_cast<double>(output.size())*.5)));
}
void independentSavedParts(){
    const auto program=sound();auto settings=state(program);
    const std::array<int,4> attack{{0,64,96,127}};
    for(std::size_t i=0;i<4U;++i){auto& part=settings->combi.uppers[i];part=settings->combi.uppers[0];
        assert(part.sourceSoundEdits.setController(73,attack[i]));}
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    assert(engine.postNoteOn(0,60,127));render(engine,480U);const auto meters=engine.meters();
    for(std::size_t i=0;i<3U;++i){
        assert(meters.upperPeakLeft[i]>2.5F*meters.upperPeakLeft[i+1U]);
        assert(meters.upperPeakLeft[i+1U]>0.0F);
    }
}
void setupOrderingResetAndProgramSelect(){
    const auto program=sound();auto settings=state(program);
    assert(settings->combi.uppers[0].sourceSoundEdits.setController(73,127));
    auto selected=state(program);selected->combi.uppers[0].sourceSoundEdits=settings->combi.uppers[0].sourceSoundEdits;
    auto bank=std::make_shared<RealtimeProgramBank>();bank->revision=1;bank->sourceIdentity=program.get();
    bank->routes.push_back({0,121,64,1,selected});
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    assert(engine.setRealtimeProgramBank(bank));
    // The authored setup must reach the next NoteOn in queue order. CC121
    // resets performance switches, while retaining the Sound edit settings.
    assert(engine.postControlChange(0,73,0));assert(engine.postControlChange(0,121,0));
    assert(engine.postProgramSelection(0,121,64,1,1,program.get()));assert(engine.postNoteOn(0,60,127));
    const auto output=render(engine,480U);assert(channelRms(output,0)>.02F);
}
void oldOwnerAndNewRecall(){
    const auto program=sound();auto old=state(program);old->combi.uppers[0].pan=-1;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(old);
    assert(engine.postControlChange(0,72,127));assert(engine.postNoteOn(0,60,127));render(engine,9600U);
    auto recalled=state(program,2U);recalled->combi.uppers[0].pan=1;
    assert(recalled->combi.uppers[0].sourceSoundEdits.setController(72,0));
    engine.setState(recalled);assert(engine.postNoteOn(0,64,127));render(engine,9600U);
    assert(engine.postNoteOff(0,60));assert(engine.postNoteOff(0,64));render(engine,2400U);
    const auto tail=render(engine,1024U);
    // Same Program pointer is deliberate: the former generation keeps its
    // original left pan and long live release, the newly recalled part uses
    // its own short release instead of the prior channel edit.
    assert(channelRms(tail,0)>.02F);assert(channelRms(tail,1)<.00001F);
}
void noteOffVelocityAndDamper(){
    auto program=sound();auto& envelope=program->layers[0].sourceAmpEnvelope;
    envelope.times={{0,0,0,20}};envelope.modulationEncodingSupported=true;
    envelope.amsSources[0]=43;envelope.amsIntensities[0]=40;envelope.amsDirections[0]=64;
    auto settings=state(program);settings->combi.uppers[0].keyLow=60;settings->combi.uppers[0].keyHigh=60;
    settings->combi.uppers[0].independentLayerRanges=false;settings->combi.uppers[0].pan=-1;
    settings->combi.uppers[1]=settings->combi.uppers[0];settings->combi.uppers[1].keyLow=64;
    settings->combi.uppers[1].keyHigh=64;settings->combi.uppers[1].pan=1;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    assert(engine.postNoteOn(0,60,127));assert(engine.postNoteOn(0,64,127));render(engine,512U);
    assert(engine.postControlChange(0,64,127));assert(engine.postNoteOff(0,60,0));assert(engine.postNoteOff(0,64,127));
    const auto sustained=render(engine,4800U);assert(channelRms(sustained,0)>.02F&&channelRms(sustained,1)>.02F);
    assert(engine.postControlChange(0,64,0));render(engine,2400U);const auto tail=render(engine,512U);
    assert(channelRms(tail,0)<.00001F);assert(channelRms(tail,1)>.02F);
}
std::vector<float> releaseVelocityOutput(int mode){
    auto program=sound();auto& envelope=program->layers[0].sourceAmpEnvelope;
    envelope.times={{0,0,0,20}};envelope.modulationEncodingSupported=true;
    envelope.amsSources[0]=43;envelope.amsIntensities[0]=40;envelope.amsDirections[0]=64;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(state(program));
    assert(engine.postNoteOn(0,60,127));render(engine,512U);
    if(mode<0)assert(engine.postNoteOn(0,60,0));
    else assert(engine.postNoteOff(0,60,static_cast<std::uint8_t>(mode)));
    render(engine,512U);return render(engine,512U);
}
void noteOnZeroUsesDefaultReleaseVelocity(){
    const auto implicit=releaseVelocityOutput(-1),explicit64=releaseVelocityOutput(64),explicit0=releaseVelocityOutput(0);
    assert(implicit==explicit64);assert(channelRms(implicit,0)>.005F&&channelRms(explicit0,0)<.00001F);
}
unsigned positiveCrossings(const std::vector<float>& output){
    unsigned result=0;for(std::size_t i=2;i<output.size();i+=2U)if(output[i-2U]<=0&&output[i]>0)++result;return result;
}
unsigned portamentoCrossings(bool cc65,bool reset,bool newer=false){
    auto program=sound(true);program->layers[0].sourceAmpEnvelope.times={{0,0,0,0}};
    auto& portamento=program->layers[0].sourcePortamento;portamento.present=true;portamento.encodingSupported=true;
    portamento.resourceVersion=2;portamento.flagsRaw=0;portamento.timeRaw=80;
    if(newer){portamento.resourceVersion=8;portamento.encodingSupported=false;portamento.extensionByteCount=2;}
    auto settings=state(program);settings->combi.uppers[0].voiceMode=UpperVoiceMode::Mono;
    settings->combi.uppers[0].sourceVoiceInherit=false;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    if(cc65)assert(engine.postControlChange(0,65,127));
    assert(engine.postNoteOn(0,60,127));render(engine,4096U);
    if(reset)assert(engine.postControlChange(0,121,0));
    assert(engine.postNoteOn(0,72,127));return positiveCrossings(render(engine,4096U));
}
void explicitPortamentoOn(){
    const auto immediate=portamentoCrossings(false,false),glide=portamentoCrossings(true,false),reset=portamentoCrossings(true,true);
    assert(immediate>=30U&&glide>=15U&&glide<=20U&&reset>=30U);
    assert(portamentoCrossings(false,false,true)==immediate);
    assert(portamentoCrossings(true,false,true)==glide);
    assert(portamentoCrossings(true,true,true)==reset);
}
std::shared_ptr<SourceOscillatorDsp> filterProfile(){
    auto source=std::make_shared<SourceOscillatorDsp>();source->resourceVersion=2;source->layoutCorroborated=true;
    source->dspRaw[2]=10;source->dspRaw[21]=99;source->dspRaw[28]=10;source->dspRaw[43]=60;
    source->dspRaw[78]=127;source->dspRaw[80]=127;
    source->amplitudeEnvelopeRaw[2]=99;source->amplitudeEnvelopeRaw[4]=99;source->amplitudeEnvelopeRaw[6]=99;
    source->amplitudeEnvelopeRaw[20]=127;source->outputRawPresent=true;source->outputRaw[1]=64;
    return source;
}
std::vector<float> filteredOutput(float manualCutoff,int threads){
    auto program=sound(true);auto pcm=std::make_shared<SampleData>(*program->layers[0].multisample->zones[0].sample);
    for(std::size_t i=0;i<pcm->interleaved.size();++i)pcm->interleaved[i]=.05F*static_cast<float>(std::sin(6.283185307179586*16.0*static_cast<double>(i)/256.0));
    auto multisample=std::make_shared<Multisample>(*program->layers[0].multisample);multisample->zones[0].sample=pcm;
    program->layers[0].multisample=multisample;program->layers[0].sourceAmpEnvelope.times={{0,0,0,0}};
    program->layers[0].sourceOscillatorDsp=filterProfile();auto settings=state(program);
    settings->combi.uppers[0].toneCutoffHz=manualCutoff;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setRenderThreads(threads);engine.setState(settings);
    // Sixteen independent pitches reach the worker-pool split threshold.
    // The production scheduler gate may still keep this offline host serial;
    // report the actually participating cores instead of claiming parallelism.
    for(std::uint8_t key=60;key<76;++key)assert(engine.postNoteOn(0,key,127));
    render(engine,4096U);auto output=render(engine,4096U);
    std::printf("Source filter threads requested=%d cores active=%u\n",threads,static_cast<unsigned>(engine.meters().coresWorking));
    return output;
}
void manualToneReopensOriginalFilter(){
    const auto original=filteredOutput(-1,1),open=filteredOutput(18000,1),parallel=filteredOutput(18000,2);
    const float originalLevel=channelRms(original,0),openLevel=channelRms(open,0);
    std::printf("Source filter RMS: original=%g manual18000=%g\n",static_cast<double>(originalLevel),static_cast<double>(openLevel));
    assert(openLevel>.005F&&originalLevel<openLevel*.02F);
    assert(open.size()==parallel.size());
    for(std::size_t i=0;i<open.size();++i)assert(std::abs(open[i]-parallel[i])<.000001F);
}
std::vector<float> resetControllerOutput(bool dirty,bool reset){
    auto program=sound(true);program->layers[0].sourceAmpEnvelope.times={{0,0,0,50}};
    auto profile=filterProfile();profile->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Filter);
    profile->dspRaw[0]=37U;profile->dspRaw[1]=65U; // Soft pedal AMS adds two semitones
    profile->dspRaw[82]=19U;profile->dspRaw[83]=157U; // Modulation AMS attenuates Amp, intensity-99
    program->layers[0].sourceOscillatorDsp=profile;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(state(program));
    assert(engine.postControlChange(0,72,127)); // retained Sound edit: long Release
    if(dirty){assert(engine.postControlChange(0,1,64));assert(engine.postControlChange(0,11,32));
        assert(engine.postControlChange(0,67,127));}
    if(reset)assert(engine.postControlChange(0,121,0));
    assert(engine.postNoteOn(0,60,127));auto output=render(engine,4096U);
    assert(engine.postNoteOff(0,60,64));render(engine,4800U);const auto tail=render(engine,512U);
    // Without the retained CC72 edit, source Release50 has ended by here.
    assert(channelRms(tail,0)>.001F);output.insert(output.end(),tail.begin(),tail.end());return output;
}
void resetClearsMomentaryAmsAndExpression(){
    const auto pristine=resetControllerOutput(false,false),reset=resetControllerOutput(true,true),
        dirty=resetControllerOutput(true,false);
    assert(pristine==reset);
    float dirtyDifference=0;
    for(std::size_t i=0;i<pristine.size();++i)dirtyDifference=std::max(dirtyDifference,std::abs(pristine[i]-dirty[i]));
    assert(dirtyDifference>.01F);
}
std::vector<float> sharedLfoOutput(bool delayedSecond,bool keySync){
    auto program=sound();program->layers[0].sourceAmpEnvelope.times={{0,0,0,0}};
    auto profile=filterProfile();profile->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Filter);
    profile->dspRaw[84]=80U;profile->lfoRaw[0]=static_cast<std::uint8_t>(6U|(keySync?128U:0U));
    profile->lfoRaw[1]=70;profile->lfoRaw[3]=30;profile->lfoRaw[4]=20;
    program->layers[0].sourceOscillatorDsp=profile;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(state(program));
    assert(engine.postNoteOn(0,60,127));if(!delayedSecond)assert(engine.postNoteOn(0,64,127));
    render(engine,8192U);if(delayedSecond)assert(engine.postNoteOn(0,64,127));
    render(engine,1024U);return render(engine,4096U);
}
void keySyncOffSharesPhaseAndDelay(){
    const auto together=sharedLfoOutput(false,false),late=sharedLfoOutput(true,false),keySynced=sharedLfoOutput(true,true);
    assert(together.size()==late.size());float keySyncDifference=0;
    for(std::size_t i=0;i<together.size();++i){
        assert(std::abs(together[i]-late[i])<.00001F);
        keySyncDifference=std::max(keySyncDifference,std::abs(together[i]-keySynced[i]));
    }
    assert(keySyncDifference>.005F);
}

std::shared_ptr<SourceOscillatorDsp> velocityProfile(bool mapped=true){
    auto source=filterProfile();
    source->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Filter);
    source->dspRaw[81]=99U;
    source->scaledVelocityDecoded=true;source->scaledVelocityRaw={{0U,127U}};
    source->velocityZonePresent=mapped;source->velocityZoneRaw={{10U,20U}};
    return source;
}
std::shared_ptr<Program> splitVelocitySound(){
    auto program=sound();auto low=program->layers[0];
    low.sourceAmpEnvelope.times={{0U,0U,0U,0U}};
    auto source=velocityProfile();source->highSource=false;low.sourceOscillatorDsp=source;
    low.velocityLow=10U;low.velocityHigh=14U;low.pan=-1.0F;
    auto multisample=std::make_shared<Multisample>(*low.multisample);
    multisample->zones[0].velocityLow=10U;multisample->zones[0].velocityHigh=20U;
    low.multisample=multisample;
    auto high=low;high.velocityLow=15U;high.velocityHigh=20U;high.pan=1.0F;
    source=std::make_shared<SourceOscillatorDsp>(*source);source->highSource=true;high.sourceOscillatorDsp=source;
    program->layers={low,high};return program;
}
struct NoteResult {std::vector<float> output;MeterSnapshot meters;};
NoteResult oneNote(const ProgramPtr& program,std::uint8_t velocity,std::uint8_t curve=0U,float response=1.0F){
    auto settings=state(program);settings->global.velocityCurve=curve;
    settings->combi.uppers[0].velocityResponse=response;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    assert(engine.postNoteOn(0,60U,velocity));render(engine,2048U);
    auto output=render(engine,4096U);return {std::move(output),engine.meters()};
}
void scaledVelocityKeepsOriginalLayerAndSampleSelection(){
    const auto program=splitVelocitySound();
    const auto low=oneNote(program,14U),high=oneNote(program,15U),full=oneNote(program,20U),zero=oneNote(program,10U);
    assert(low.meters.activeVoices==1U&&high.meters.activeVoices==1U&&full.meters.activeVoices==1U);
    assert(zero.meters.activeVoices==1U); // mapped0 is a silent NoteOn, not NoteOff
    const float level=channelRms(full.output,1U);assert(level>.02F);
    assert(std::abs(channelRms(low.output,0U)/level-.4F)<.00001F);
    assert(channelRms(low.output,1U)<.000001F&&channelRms(high.output,0U)<.000001F);
    assert(std::abs(channelRms(high.output,1U)/level-.5F)<.00001F);
    assert(channelRms(zero.output,0U)==0.0F&&channelRms(zero.output,1U)==0.0F);
    for(const std::uint8_t velocity:{9U,21U}){
        const auto outside=oneNote(program,velocity);
        assert(outside.meters.activeVoices==0U&&channelRms(outside.output,0U)==0.0F&&channelRms(outside.output,1U)==0.0F);
    }
    const auto curved=oneNote(program,15U,2U,2.0F);
    assert(std::abs(channelRms(curved.output,1U)/level-.0625F)<.00001F);
    auto fallback=std::make_shared<Program>(*program);
    for(auto& layer:fallback->layers){
        auto source=std::make_shared<SourceOscillatorDsp>(*layer.sourceOscillatorDsp);
        source->manualOverrideMask|=static_cast<std::uint16_t>(SourceOscillatorModule::Amplitude);
        layer.sourceOscillatorDsp=source;
    }
    const auto fallbackFull=oneNote(fallback,20U),fallbackMid=oneNote(fallback,15U,2U,2.0F);
    assert(std::abs(channelRms(fallbackMid.output,1U)/channelRms(fallbackFull.output,1U)-.0625F)<.00001F);
}
void identityVelocityAndNativeAttackKeepTheirAudio(){
    auto program=sound(true);program->layers[0].sourceAmpEnvelope.times={{0U,0U,0U,0U}};
    auto source=velocityProfile(false);source->scaledVelocityRaw={{1U,127U}};source->velocityZoneRaw={{1U,127U}};
    program->layers[0].sourceOscillatorDsp=source;
    const auto old=oneNote(program,37U,1U,1.7F);
    source=std::make_shared<SourceOscillatorDsp>(*source);source->velocityZonePresent=true;
    program->layers[0].sourceOscillatorDsp=source;
    assert(old.output==oneNote(program,37U,1U,1.7F).output);

    const auto attackOutput=[](bool mapped){
        auto program=sound();program->layers[0].sourceAmpEnvelope.times={{0U,0U,0U,0U}};
        auto source=velocityProfile(mapped);source->dspRaw[81]=0U;
        source->scaledVelocityRaw={{127U,127U}};program->layers[0].sourceOscillatorDsp=source;
        auto settings=state(program);settings->combi.uppers[0].velocityShape.toAttack=1.0F;
        SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
        assert(engine.postNoteOn(0,60U,15U));return render(engine,8192U);
    };
    // The saved source map has no active source velocity destination here.
    // A native velocity->Attack edit still uses received15 rather than mapped127.
    assert(attackOutput(false)==attackOutput(true));
}
std::vector<float> originalEqOutput(int mode){
    auto program=sound();program->layers[0].sourceAmpEnvelope.times={{0U,0U,0U,0U}};
    auto source=filterProfile();source->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Filter);
    source->equalizerPresent=mode!=0;source->equalizerRaw={{1U,99U,0U,165U,0U,0U}};
    if(mode==2)source->equalizerRaw[2]=12U; // saved +6dB lowshelf
    if(mode==3)source->equalizerRaw[1]=60U;
    if(mode==4)source->equalizerRaw[4]=12U; // unknown mid frequency must remain gated
    if(mode==5)source->equalizerRaw={{0U,35U,36U,165U,36U,36U}};
    program->layers[0].sourceOscillatorDsp=source;
    return oneNote(program,127U).output;
}
void originalEqReachesAudioAndNeutralIsBitExact(){
    const auto absent=originalEqOutput(0),flat=originalEqOutput(1),boost=originalEqOutput(2),trim=originalEqOutput(3);
    assert(absent==flat&&flat==originalEqOutput(4)&&flat==originalEqOutput(5));
    const float level=channelRms(flat,0U);assert(level>.02F);
    assert(std::abs(channelRms(boost,0U)/level-std::pow(10.0F,6.0F/20.0F))<.0001F);
    assert(std::abs(channelRms(trim,0U)/level-60.0F/99.0F)<.00001F);
}

std::vector<float> velocitySharedLfoOutput(bool keySync,bool fractional,bool delayedSecond){
    auto program=sound();program->layers[0].sourceAmpEnvelope.times={{0U,0U,0U,0U}};
    auto source=velocityProfile();source->dspRaw[81]=0U;source->dspRaw[84]=80U;
    source->lfoRaw[0]=static_cast<std::uint8_t>(6U|(keySync?128U:0U));source->lfoRaw[1]=50U;
    source->lfoRaw[6]=15U;source->lfoRaw[7]=99U;
    if(!fractional)source->scaledVelocityRaw={{64U,64U}};
    program->layers[0].sourceOscillatorDsp=source;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(state(program));
    assert(engine.postNoteOn(0,60U,15U));
    if(!delayedSecond)assert(engine.postNoteOn(0,64U,15U));
    render(engine,8192U);
    if(delayedSecond)assert(engine.postNoteOn(0,64U,15U));
    render(engine,1024U);return render(engine,4096U);
}
void sharedLfoKeepsFractionalMappedVelocity(){
    const auto shared=velocitySharedLfoOutput(false,true,false);
    const auto local=velocitySharedLfoOutput(true,true,false);
    const auto late=velocitySharedLfoOutput(false,true,true);
    const auto rounded=velocitySharedLfoOutput(false,false,false);
    float roundedDifference=0.0F;
    for(std::size_t i=0U;i<shared.size();++i){
        assert(std::abs(shared[i]-local[i])<.00001F);
        assert(std::abs(shared[i]-late[i])<.00001F);
        roundedDifference=std::max(roundedDifference,std::abs(shared[i]-rounded[i]));
    }
    assert(roundedDifference>.001F);
}

std::vector<float> partialAmpOutput(bool unsupported){
    auto program=sound();auto& eg=program->layers[0].sourceAmpEnvelope;
    eg.modulationEncodingSupported=true;
    eg.amsSources[1]=1U;eg.amsIntensities[1]=20;eg.amsDirections[1]=1U;
    if(unsupported){eg.enabled=false;eg.amsSources[0]=99U;eg.amsIntensities[0]=40;eg.amsDirections[0]=1U;}
    assert(eg.valid()&&eg.runtimeEnabled());
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(state(program));
    assert(engine.postNoteOn(0,60,100));auto early=render(engine,256U);
    render(engine,8192U);auto held=render(engine,256U);
    assert(channelRms(early,0)<channelRms(held,0)*.3F);
    assert(engine.postNoteOff(0,60));render(engine,1024U);auto tail=render(engine,256U);
    assert(channelRms(tail,0)>.01F);render(engine,16384U);assert(engine.meters().activeVoices==0U);
    early.insert(early.end(),held.begin(),held.end());early.insert(early.end(),tail.begin(),tail.end());return early;
}
void partialAmpKeepsDecodedBase(){assert(partialAmpOutput(false)==partialAmpOutput(true));}
std::vector<float> styleResetOutput(bool dirty,bool newMix){
    auto program=sound(true);auto settings=state(program);
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);engine.setChannelMixEnabled(true);
    if(dirty){
        assert(engine.postControlChange(0,7,20));assert(engine.postControlChange(0,10,0));
        assert(engine.postControlChange(0,11,25));assert(engine.postControlChange(0,73,0));
        assert(engine.postControlChange(0,91,99));assert(engine.postControlChange(0,64,127));
        assert(engine.postPitchBend(0,4096));
    }
    assert(engine.postResetSourceChannel(0));
    if(newMix){assert(engine.postControlChange(0,7,64));assert(engine.postControlChange(0,10,127));}
    assert(engine.postNoteOn(0,60,127));auto output=render(engine,8192U);
    assert(engine.postNoteOff(0,60));render(engine,16384U);assert(engine.meters().activeVoices==0U);return output;
}
void styleResetPreservesOrderedSetup(){
    const auto base=styleResetOutput(false,false),reset=styleResetOutput(true,false);
    assert(base==reset);assert(channelRms(base,0)>.01F);
    const auto newMix=styleResetOutput(true,true);assert(channelRms(newMix,0)<.00001F);
    assert(channelRms(newMix,1)>.005F);assert(styleResetOutput(false,true)==newMix);
}
std::size_t savedPartGlideCrossings(int time,int on,int flags){
    auto program=sound(true);auto& porta=program->layers[0].sourcePortamento;
    porta.present=true;porta.resourceVersion=8;porta.flagsRaw=static_cast<std::uint8_t>(flags);
    porta.timeRaw=80;porta.extensionByteCount=2;porta.extensionRaw[0]=1;
    auto settings=state(program);auto& part=settings->combi.uppers[0];
    part.voiceMode=UpperVoiceMode::Mono;part.sourceVoiceInherit=false;
    part.sourceSoundEdits.setController(5,time);part.sourceSoundEdits.setController(65,on);
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    assert(engine.postNoteOn(0,60,127));render(engine,4096U);
    assert(engine.postNoteOn(0,72,127));return positiveCrossings(render(engine,4096U));
}
void keyboardSetSourceGlide(){
    const auto off=savedPartGlideCrossings(100,0,9);
    const auto inherited=savedPartGlideCrossings(-1,-1,9);
    const auto slow=savedPartGlideCrossings(120,127,9);
    const auto zero=savedPartGlideCrossings(0,127,9);
    assert(off>=30U&&inherited>=15U&&inherited<=20U&&slow>=15U&&slow<=20U&&zero==off);
}
void keyboardPortamentoEditWinsOverOldMidi(){
    auto program=sound(true);program->layers[0].sourceAmpEnvelope.times={{0,0,0,0}};
    auto& porta=program->layers[0].sourcePortamento;
    porta={true,false,8U,9U,100U,2U,{}};
    auto settings=state(program);auto& left=settings->combi.uppers[0];
    left.voiceMode=UpperVoiceMode::Mono;left.sourceVoiceInherit=false;left.livePartMix=true;left.pan=-1;
    left.sourceSoundEdits.setController(5,30);
    settings->combi.uppers[1]=left;settings->combi.uppers[1].pan=1;
    SamplerEngine engine;engine.prepare(sampleRate,blockSize);engine.setState(settings);
    assert(engine.postControlChange(0,5,100));assert(engine.postControlChange(0,65,127));
    assert(engine.postNoteOn(0,60,127));render(engine,4096);
    auto edited=std::make_shared<EngineState>(*settings);
    edited->combi.uppers[0].sourceSoundEdits.setController(5,0);
    engine.setState(edited);assert(engine.postNoteOn(0,72,127));
    auto stereo=render(engine,4096);
    auto crossings=[](const auto& a,unsigned ch){unsigned n=0;for(std::size_t i=ch+2;i<a.size();i+=2)if(a[i-2]<=0&&a[i]>0)++n;return n;};
    assert(crossings(stereo,0)>=30U);assert(crossings(stereo,1)>=15U&&crossings(stereo,1)<=20U);
    assert(engine.postNoteOff(0,72));assert(engine.postNoteOff(0,60));render(engine,16384);
    // New MIDI can intentionally take over again; UI edits do not disable it.
    assert(engine.postControlChange(0,5,100));assert(engine.postNoteOn(0,60,127));render(engine,4096);
    assert(engine.postNoteOn(0,72,127));stereo=render(engine,4096);
    assert(crossings(stereo,0)>=15U&&crossings(stereo,0)<=20U);
    assert(crossings(stereo,1)>=15U&&crossings(stereo,1)<=20U);
    // Off is a separate switch; the next note must not glide despite old CC65 On.
    assert(engine.postNoteOff(0,72));assert(engine.postNoteOff(0,60));render(engine,16384);
    auto off=std::make_shared<EngineState>(*edited);off->combi.uppers[0].sourceSoundEdits.setController(65,0);
    engine.setState(off);assert(engine.postNoteOn(0,60,127));render(engine,4096);
    assert(engine.postNoteOn(0,72,127));stereo=render(engine,4096);
    assert(crossings(stereo,0)>=30U&&crossings(stereo,1)<=20U);
    assert(engine.postNoteOff(0,72));assert(engine.postNoteOff(0,60));render(engine,16384);
    assert(engine.meters().activeVoices==0U);
}
void basicNewerPortamento(){
    SourcePortamento p;p.present=true;p.resourceVersion=8;p.flagsRaw=3;p.timeRaw=80;p.extensionByteCount=2;
    assert(!p.encodingSupported&&p.basicPlaybackSupported()&&p.enabled()&&p.fingered()&&p.seconds()>0);
    p.flagsRaw=11;assert(p.basicPlaybackSupported()&&p.enabled()&&p.fingered());
    p.extensionRaw[0]=1;assert(p.basicPlaybackSupported()&&p.enabled()&&!p.encodingSupported);
    p.flagsRaw=8;assert(p.basicPlaybackSupported()&&!p.enabled());
    p.flagsRaw=0x20;assert(!p.basicPlaybackSupported()&&!p.enabled());
    p.flagsRaw=9;SourceSoundEdits edits;
    assert(sourcePortamentoPlaybackSeconds(p,edits,false)==p.seconds());
    edits.setController(5,40);assert(sourcePortamentoPlaybackSeconds(p,edits,false)==SourcePortamento::indexSeconds(40));
    edits.setController(65,0);assert(sourcePortamentoPlaybackSeconds(p,edits,true)==0);
    p.flagsRaw=11;edits.setController(65,127);
    assert(sourcePortamentoPlaybackSeconds(p,edits,false)==0);
    assert(sourcePortamentoPlaybackSeconds(p,edits,true)==SourcePortamento::indexSeconds(40));
}
}

int main(){
    partialAmpKeepsDecodedBase();styleResetPreservesOrderedSetup();basicNewerPortamento();keyboardSetSourceGlide();keyboardPortamentoEditWinsOverOldMidi();
    independentSavedParts();setupOrderingResetAndProgramSelect();oldOwnerAndNewRecall();
    noteOffVelocityAndDamper();noteOnZeroUsesDefaultReleaseVelocity();explicitPortamentoOn();
    manualToneReopensOriginalFilter();resetClearsMomentaryAmsAndExpression();keySyncOffSharesPhaseAndDelay();
    scaledVelocityKeepsOriginalLayerAndSampleSelection();identityVelocityAndNativeAttackKeepTheirAudio();
    originalEqReachesAudioAndNeutralIsBitExact();sharedLfoKeepsFractionalMappedVelocity();
    std::puts("PASS engine source controls: independent saved parts, ordered setup/ProgramSelect/CC121, recall isolation, NoteOff velocity plus damper, explicit CC65 glide and manual TONE filter precedence");
    std::puts("PASS engine original OSC velocity/EQ: received zone selection, fractional source mapping, native attack and identity preservation, audible shelf/trim, neutral bit identity, shared LFO fractional velocity");
}
