#include "silveton/arranger/KorgSourceEffects.h"
#include "silveton/arranger/Pa5xSoundGraph.h"
#include "silveton/sampler/NumberedModFx.h"
#include "silveton/sampler/SourceEffects.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

using namespace silveton::sampler;
namespace pa = silveton::arranger;
namespace {
constexpr double pi=3.14159265358979323846;
constexpr std::array<double,10> noteFractions{{1.0/32,1.0/24,1.0/16,1.0/12,1.0/8,1.0/6,1.0/4,1.0/3,1.0/2,1}};
struct Rows {std::uint16_t index;const char* sync;const char* frequency;const char* stepNote;const char* stepFrequency;};
constexpr Rows rows[]{
    {26,"c_1","b_1",nullptr,nullptr},{27,"c_1","b_1",nullptr,nullptr},
    {32,"e_1","d_1",nullptr,nullptr},{33,"e_1","c_1","f_1","d_1"},
    {35,"d_1","c_1",nullptr,nullptr},{36,"d_1","b_1","e_1","c_1"},
    {38,"f_1","e_1",nullptr,nullptr},{41,"d_1","c_1",nullptr,nullptr},
    {43,"d_1","c_1",nullptr,nullptr},{44,"d_1","c_1",nullptr,nullptr},
    {46,"d_1","c_1",nullptr,nullptr},{47,"c_1","b_1",nullptr,nullptr},
    {48,"e_1","d_1",nullptr,nullptr},{52,"d_1","c_1",nullptr,nullptr}
};
const NumberedFxParamDescriptor& parameter(std::uint16_t index,const char* row){
    const auto* p=findNumberedFxParam(index,row);assert(p);return *p;
}
void put(NumberedFxState& state,const char* row,double value){
    const auto& p=parameter(state.index,row);assert(numberedFxValueValid(p,value));
    state.values[p.ordinal]=value;state.knownMask|=std::uint64_t{1}<<p.ordinal;
}
void forget(NumberedFxState& state,const char* row){
    state.knownMask&=~(std::uint64_t{1}<<parameter(state.index,row).ordinal);
}
void bits(std::array<std::uint8_t,64>& data,unsigned first,unsigned width,unsigned value){
    assert(first+width<=512U&&width<32U);
    for(unsigned bit=0;bit<width;++bit){
        const auto at=first+bit;const auto mask=static_cast<std::uint8_t>(1U<<(at%8U));
        data[at/8U]=static_cast<std::uint8_t>((data[at/8U]&~mask)|((value&(1U<<bit))?mask:0U));
    }
}
pa::Pa5xSoundFxRecordRaw chorusRecord(unsigned note,bool sync=false,unsigned tempo=12000,unsigned times=1){
    // Synthetic explicit Stereo Chorus fields from the reviewed official
    // compact table. No original SET or vendor preset bytes are embedded.
    pa::Pa5xSoundFxRecordRaw r;r.recordBytes=67;r.trailingControlPresent=true;
    r.selectorDecoded=true;r.selector=r.selectorLowRaw=26;
    bits(r.parameters,1,8,100);bits(r.parameters,23,7,100);bits(r.parameters,30,1,1);
    bits(r.parameters,45,8,50); // 1.00 Hz independent free-running LFO.
    bits(r.parameters,67,1,sync?1U:0U);bits(r.parameters,68,15,tempo);
    bits(r.parameters,83,4,note);bits(r.parameters,87,6,times);
    bits(r.parameters,93,8,30);bits(r.parameters,101,8,40);bits(r.parameters,109,7,50);
    return r;
}
std::shared_ptr<const pa::KorgSourceEffects> masterProfile(const pa::Pa5xSoundFxRecordRaw& record){
    pa::KorgSourceFxContext context;context.scope=pa::KorgSourceFxScope::KeyboardMaster;
    context.resourcePath="synthetic/KeyboardSetMaster.mid";
    pa::KorgMidiOpaqueEvent event;event.status=0xF0;
    event.payload={0x42,0x7F,0x78,0x02,0x10,1,0,1,0,0,0,record.selectorLowRaw};
    for(std::size_t at=0;at<record.parameters.size();at+=7U){
        const auto count=std::min<std::size_t>(7,record.parameters.size()-at);
        std::uint8_t mask=0;
        for(std::size_t n=0;n<count;++n)if(record.parameters[at+n]&0x80U)mask|=static_cast<std::uint8_t>(1U<<(6U-n));
        event.payload.push_back(mask);
        for(std::size_t n=0;n<count;++n)event.payload.push_back(record.parameters[at+n]&0x7FU);
    }
    event.payload.push_back(0xF7);assert(event.payload.size()==87U);
    auto result=pa::makeKorgSourceEffects(context,{}, {event});assert(result&&result->valid()&&result->complete);
    return result;
}
void checkSourceDecode(){
    for(unsigned code=0;code<10;++code){
        const auto record=chorusRecord(code);
        const auto status=inspectSoundEffectParameters(record);
        assert(status.parameterLayoutKnown&&status.parameterBlockValid&&status.parametersComplete);
        const auto& note=parameter(26,"c_3");
        assert(status.decoded.known(note.ordinal)&&status.decoded.values[note.ordinal]==noteFractions[code]);
        assert(formatNumberedFxValue(status.decoded,note.ordinal)==note.choices[code].label);
        assert(status.soundRecord&&status.status==SourceFxStatus::Unsupported&&status.ownerRaw==-1);
        assert(numberedModFxCanRender(status.decoded));
        Combi combi;std::array<int,8> map{{0,1,2,3,-1,-1,-1,-1}};
        applySourceEffects(combi,{masterProfile(record)},map,false);
        assert(combi.sourceEffects&&combi.sourceEffects->slots.size()==1U);
        assert(combi.sourceEffects->slots[0].status==SourceFxStatus::Applied);
        assert(sameNumberedFx(status.decoded,combi.sourceEffects->masterRender[0].numbered));
    }
    for(unsigned invalid=10;invalid<16;++invalid){
        auto status=inspectSoundEffectParameters(chorusRecord(invalid));
        assert(status.parameterLayoutKnown&&!status.parameterBlockValid&&!status.parametersComplete&&status.decoded.knownMask==0);
    }
    assert(!inspectSoundEffectParameters(chorusRecord(0,false,12000,0)).parameterBlockValid);
    auto original=inspectSoundEffectParameters(chorusRecord(7,false,3999,31));
    assert(original.parametersComplete&&numberedModFxCanRender(original.decoded));
    assert(original.decoded.values[parameter(26,"c_2").ordinal]==kNumberedFxChoiceBase);
    auto incomplete=original.decoded;forget(incomplete,"c_3");
    assert(incomplete.valid()&&!numberedModFxCanRender(incomplete));
    auto invalid=original.decoded;invalid.values[parameter(26,"c_3").ordinal]=.2;
    assert(!invalid.valid()&&!numberedModFxCanRender(invalid));
    const auto external=inspectSoundEffectParameters(chorusRecord(7,true,3999,31));
    assert(external.parametersComplete&&!numberedModFxCanRender(external.decoded));
    Combi combi;std::array<int,8> map{{0,1,2,3,-1,-1,-1,-1}};
    applySourceEffects(combi,{masterProfile(chorusRecord(7,true,3999,31))},map,false);
    assert(combi.sourceEffects->slots[0].status==SourceFxStatus::Unsupported&&!combi.sourceEffects->masterRender[0].active);
    auto unframed=chorusRecord(0);unframed.leadingRaw=1;
    assert(!inspectSoundEffectParameters(unframed).selectorKnown);
}
void compareAudio(const NumberedFxState& left,const NumberedFxState& right,double seconds){
    constexpr double sampleRate=8000;
    NumberedFxProcessor a,b;a.prepare(sampleRate);b.prepare(sampleRate);a.configure(left);b.configure(right);
    assert(a.active()&&b.active());
    double difference=0,processed=0;
    for(unsigned n=0;n<static_cast<unsigned>(sampleRate*seconds);++n){
        const float input=static_cast<float>(.2*std::sin(2*pi*317*n/sampleRate)+.1*std::cos(2*pi*719*n/sampleRate));
        float al=0,ar=0,bl=0,br=0;a.process(input,input*.7F,al,ar);b.process(input,input*.7F,bl,br);
        assert(std::isfinite(al)&&std::isfinite(ar)&&std::isfinite(bl)&&std::isfinite(br));
        difference+=std::abs(al-bl)+std::abs(ar-br);processed+=std::abs(al-input)+std::abs(ar-input*.7F);
    }
    assert(difference<1.e-6&&processed>1);
}
void checkFamiliesAndLegacy(){
    for(const auto& r:rows){
        NumberedFxState state;assert(initializeNumberedModFx(r.index,state));
        char bpm[]{r.sync[0],'_','2','\0'},note[]{r.sync[0],'_','3','\0'},times[]{r.sync[0],'_','4','\0'};
        const auto& p=parameter(r.index,note);assert(p.domainComplete&&p.choiceCount==10);
        for(unsigned code=0;code<10;++code)assert(p.choices[code].value==noteFractions[code]);
        const auto support=numberedModFxSupport(r.index);
        assert((support.editableMask&(std::uint64_t{1}<<p.ordinal))!=0);
        auto legacy=state;forget(legacy,note);if(r.stepNote)forget(legacy,r.stepNote);
        assert(legacy.valid()&&numberedModFxCanRender(legacy));
        compareAudio(state,legacy,.75);
        const auto savedMask=legacy.knownMask;legacy.origin=NumberedFxOrigin::Manual;
        assert(numberedModFxCanRender(legacy)&&legacy.knownMask==savedMask);
        auto missing=legacy;forget(missing,r.frequency);assert(!numberedModFxCanRender(missing));
        put(legacy,r.sync,1);assert(!numberedModFxCanRender(legacy));
        put(legacy,r.sync,0);legacy.origin=NumberedFxOrigin::Decoded;assert(!numberedModFxCanRender(legacy));
        auto dormant=state;put(dormant,bpm,kNumberedFxChoiceBase);put(dormant,note,1.0/3);put(dormant,times,31);
        if(r.stepNote){put(dormant,r.stepNote,1.0/12);char count[]{r.stepNote[0],'_','2','\0'};put(dormant,count,29);}
        assert(numberedModFxCanRender(dormant));compareAudio(state,dormant,.75);
        auto synced=state;put(synced,r.sync,1);put(synced,bpm,120);put(synced,note,.25);put(synced,times,1);
        auto free=state;put(free,r.frequency,2);
        if(r.stepNote){
            put(synced,r.stepNote,1.0/6);char count[]{r.stepNote[0],'_','2','\0'};put(synced,count,1);
            put(free,r.stepFrequency,3);
        }
        assert(numberedModFxCanRender(synced));compareAudio(synced,free,1.25);
        put(synced,bpm,kNumberedFxChoiceBase);assert(!numberedModFxCanRender(synced));
        // A legitimate editor action can select the new semantic note value.
        assert(setNumberedFxValue(state,p.ordinal,1.0/24)&&state.origin==NumberedFxOrigin::Manual);
    }
    // Source identities outside the reviewed modulation subset are unchanged.
    assert(parameter(60,"g_3").kind==NumberedFxValueKind::Reference);
    assert(parameter(51,"e_1").kind==NumberedFxValueKind::Reference);
    assert(parameter(10,"e_3").kind==NumberedFxValueKind::Reference);
}
void checkMeasuredTremolo(){
    // At120 quarter-note BPM, a half-note triplet lasts2/3 second. Observe
    // actual output crossings; this does not inspect private DSP state.
    constexpr double rate=12000;
    for(const auto count:{1.0,2.0}){
        NumberedFxState state;assert(initializeNumberedModFx(44,state));
        put(state,"d_1",1);put(state,"d_2",120);put(state,"d_3",1.0/3);put(state,"d_4",count);
        put(state,"a_1",1);put(state,"a_2",0);put(state,"b_1",0);put(state,"e_1",100);put(state,"f_1",100);
        NumberedFxProcessor fx;fx.prepare(rate);fx.configure(state);assert(fx.active());
        std::vector<unsigned> crossings;float previous=.125F;
        for(unsigned n=0;n<static_cast<unsigned>(rate*6);++n){
            float l=0,r=0;fx.process(.25F,.25F,l,r);
            if(previous<.125F&&l>=.125F)crossings.push_back(n);
            previous=l;
        }
        assert(crossings.size()>=4U);
        for(std::size_t i=1;i<crossings.size();++i)
            assert(std::abs(static_cast<double>(crossings[i]-crossings[i-1])-8000*count)<=1);
    }
}
int inspectInput(){
    unsigned index=0;std::string hex;
    while(std::cin>>index>>hex){
        if(index>255||hex.size()!=128)return 2;
        auto record=chorusRecord(0);record.selector=record.selectorLowRaw=static_cast<std::uint8_t>(index);
        for(unsigned i=0;i<64;++i)record.parameters[i]=static_cast<std::uint8_t>(std::stoul(hex.substr(i*2,2),nullptr,16));
        auto status=inspectSoundEffectParameters(record);
        std::cout<<status.parameterLayoutKnown<<' '<<status.parameterBlockValid<<' '<<status.parametersComplete<<' '
                 <<numberedFxCanRender(status.decoded)<<' '<<status.decoded.knownMask<<'\n';
    }
    return 0;
}
} // namespace
int main(int argc,char** argv){
    if(argc==2&&std::string(argv[1])=="--inspect")return inspectInput();
    checkSourceDecode();checkFamiliesAndLegacy();checkMeasuredTremolo();
    std::cout<<"PASS: sixteen source note fields, fourteen modulation families, exact saved note values, actual LFO/step rates, dormant original values, legacy manual absence and unbound MIDI tempo rejection\n";
}
