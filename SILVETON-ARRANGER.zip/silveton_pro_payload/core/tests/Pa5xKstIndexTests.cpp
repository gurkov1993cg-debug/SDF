#include "silveton/arranger/Pa5xKstIndex.h"
#include "silveton/sampler/FsCompat.h"
#include <atomic>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>

using namespace silveton::arranger;
namespace fs = silveton::fsx;
static bool hasCode(const Pa5xKstIndex& r, const std::string& code) {
    for (const auto& d : r.diagnostics) if (d.code == code) return true;
    return false;
}
static void append32(std::vector<std::uint8_t>& bytes, std::size_t value) {
    for (int shift=24; shift>=0; shift-=8) bytes.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
static void appendText(std::vector<std::uint8_t>& bytes, const std::string& value) {
    bytes.insert(bytes.end(), value.begin(), value.end());
}
static void appendLeaf(std::vector<std::uint8_t>& bytes, const std::string& name, const std::vector<std::uint8_t>& payload) {
    appendText(bytes, "Leaf"); bytes.push_back(0); appendText(bytes, name); bytes.push_back(0); append32(bytes, payload.size());
    bytes.insert(bytes.end(), payload.begin(), payload.end());
}
static void writePerformance(const fs::path& path, bool keyboard, bool banks=true) {
    std::vector<std::uint8_t> events;
    if (banks) events = {0,0xB0,0,121,0,0xB0,32,66};
    events.insert(events.end(), {0,0xC0,20,0,0xFF,0x2F,0});
    std::vector<std::uint8_t> midi{'M','T','h','d',0,0,0,6,0,0,0,1,1,128,'M','T','r','k'};
    append32(midi, events.size()); midi.insert(midi.end(),events.begin(),events.end());
    std::vector<std::uint8_t> content;
    std::string xml;
    if (keyboard) {
        for (const char* name : {"Lower.mid","Upper1.mid","Upper2.mid","Upper3.mid"}) appendLeaf(content,name,midi);
        xml = "<CLIP type=\"KeyboardSetClip\" subtype=\"4\" version=\"1\" release=\"0\"><RESOURCE track1=\"Lower.mid\" track2=\"Upper1.mid\" track3=\"Upper2.mid\" track4=\"Upper3.mid\"/><PARAMS><KeyboardProcessing splitpoint=\"60\" globalsplit=\"0\"/><Track1Params/><Track2Params/><Track3Params/><Track4Params/></PARAMS></CLIP>";
    } else {
        appendLeaf(content,"Main.mid",midi);
        xml = "<CLIP type=\"PadClip\" version=\"0\" release=\"4\"><RESOURCE name=\"Main.mid\"/><PARAMS/></CLIP>";
    }
    appendLeaf(content,"ClipDescription.xml",std::vector<std::uint8_t>(xml.begin(),xml.end()));
    std::vector<std::uint8_t> bytes{'R','o','o','t',0,1,0}; append32(bytes,content.size());bytes.insert(bytes.end(),content.begin(),content.end());
    std::ofstream out(path.string(),std::ios::binary);out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
}
int main(int argc, char** argv) {
    char pattern[] = "/tmp/silveton-kst-XXXXXX";
    char* tmp = ::mkdtemp(pattern); assert(tmp);
    const fs::path base(tmp), root = base / "Reference.KST";
    fs::create_directories(root);
    assert(!indexPa5xKst(base.string()).recognized);
    auto result = indexPa5xKst(root.string());
    assert(result.recognized && !result.structurallyValid && !result.playable);
    { std::ofstream f((root / "readme.txt").string()); f << "not a Korg resource"; }
    result = indexPa5xKst(root.string());
    assert(!result.structurallyValid && hasCode(result, "NO_PA5X_RESOURCES"));
    fs::create_directories(root / "STYLE");
    { std::ofstream f((root / "STYLE" / "empty.stg").string()); }
    result = indexPa5xKst(root.string());
    assert(!result.structurallyValid && hasCode(result, "RESOURCE_UNREADABLE"));
    (void)fs::remove_all(root / "STYLE");
    std::atomic<bool> cancel{false};
    result = indexPa5xKst(root.string(), [&](const KstProgress&) { cancel.store(true); }, &cancel);
    assert(result.cancelled && !result.playable);
    const auto link = (root / "linked").string();
    assert(::symlink(base.string().c_str(), link.c_str()) == 0);
    result = indexPa5xKst(root.string());
    assert(!result.structurallyValid && hasCode(result, "LINKED_RESOURCE"));
    assert(::unlink(link.c_str()) == 0);

    const auto plain = base / "Resources";
    fs::create_directories(plain / "STYLE");
    assert(!canSelectPa5xKstDirectory(plain.string()));
    assert(::symlink((plain / "STYLE").string().c_str(), (plain / "SOUND").string().c_str()) == 0);
    assert(!canSelectPa5xKstDirectory(plain.string()));
    assert(::unlink((plain / "SOUND").string().c_str()) == 0);
    fs::create_directories(plain / "SOUND");
    assert(canSelectPa5xKstDirectory(plain.string()));
    (void)fs::remove_all(plain / "STYLE");
    fs::create_directories(plain / "KEYBOARDSET");
    fs::create_directories(plain / "PAD");
    fs::create_directories(plain / "SETTINGS");
    assert(canSelectPa5xKstDirectory(plain.string()));
    writePerformance(plain / "KEYBOARDSET" / "001.Test.ksc",true);
    writePerformance(plain / "SETTINGS" / "My Setting.ksc",true);
    writePerformance(plain / "PAD" / "001.Test.pdc",false);
    result = indexPa5xKst(plain.string());
    assert(result.recognized && result.structurallyValid && !result.playable);
    assert(result.indexedKeyboardSets == 2 && result.indexedPads == 1 && result.soundReferences.size() == 9);
    assert(result.missingUserReferences == 9);
    for (const auto& ref : result.soundReferences) {
        assert(ref.resourceKind == KstResourceKind::KeyboardSet || ref.resourceKind == KstResourceKind::Pad);
        assert(ref.msb == 121 && ref.lsb == 66 && ref.program == 20);
    }
    writePerformance(plain / "PAD" / "002.Incomplete.pdc",false,false);
    result = indexPa5xKst(plain.string());
    assert(result.structurallyValid && result.indexedPads == 2 && result.soundReferences.size() == 9);
    assert(hasCode(result,"PERFORMANCE_SOUND_ADDRESS_INCOMPLETE"));
    writePerformance(plain / "PAD" / "003.WrongKind.pdc",true);
    result = indexPa5xKst(plain.string());
    assert(!result.structurallyValid && hasCode(result,"PERFORMANCE_RESOURCE_KIND_MISMATCH"));

    if (argc == 3) {
        const fs::path resources(argv[1]);
        for (const char* dir : {"STYLE", "SOUND", "MULTISMP", "PCM"}) fs::create_directories(root / dir);
        assert(fs::copy_file(argv[2], root / "STYLE" / "reference.stg"));
        for (const char* name : {"user03.pcg", "userdk01.pcg"})
            assert(fs::copy_file(resources / name, root / "SOUND" / name));
        assert(fs::copy_file(resources / "ram.kmp", root / "MULTISMP" / "ram.kmp"));
        for (const char* name : {"ram01.pcm", "ram02.pcm", "ram03.pcm", "ram04.pcm", "ram05.pcm"})
            assert(fs::copy_file(resources / name, root / "PCM" / name));
        result = indexPa5xKst(root.string());
        assert(result.recognized && result.structurallyValid && !result.playable);
        assert(result.indexedSounds == 192 && result.indexedSamples > 0);
        assert(result.resolvedUserReferences > 0 && result.missingUserReferences > 0 && result.factoryReferences > 0);
        bool normal = false, drum = false;
        for (const auto& ref : result.soundReferences) {
            if (ref.msb == 121 && ref.lsb == 66 && ref.program == 20) {
                assert(ref.resolution == KstResolution::ExactUserSound && ref.soundName == "2-4 genel 100"); normal = true;
            }
            if (ref.msb == 120 && ref.lsb == 64 && ref.program == 121) {
                assert(ref.resolution == KstResolution::ExactUserSound && ref.soundName == "Session kit 4x"); drum = true;
            }
        }
        assert(normal && drum);
        fs::create_directories(root / "SOUND" / "duplicate");
        assert(fs::copy_file(resources / "user03.pcg", root / "SOUND" / "duplicate" / "user03.pcg"));
        assert(hasCode(indexPa5xKst(root.string()), "DUPLICATE_SOUND_ADDRESS"));
        (void)fs::remove_all(root / "SOUND" / "duplicate");
        { std::ofstream f((root / "SOUND" / "unknown.pcg").string()); f << "undecoded bank"; }
        result = indexPa5xKst(root.string());
        assert(!result.structurallyValid && result.missingUserReferences == 0);
        assert(hasCode(result, "USER_BANK_INDEX_INCOMPLETE"));
        (void)fs::remove_all(root / "SOUND" / "unknown.pcg");
        assert(fs::copy_file(resources / "ram01.pcm", root / "MULTISMP" / "wrong.kmp"));
        assert(hasCode(indexPa5xKst(root.string()), "SAMPLE_CONTAINER_KIND_MISMATCH"));
    }
    (void)fs::remove_all(base);
    std::cout << "Pa5X KST: PASS (folder bounds, cancellation, exact addresses, KSC/PDC links, canonical roots, incomplete banks, strict playback gate)\n";
}
