#include "silveton/arranger/Pa5xSampleIndex.h"
#include "silveton/arranger/Pa5xOc31.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton::arranger;
namespace {
using Bytes=std::vector<std::uint8_t>;
void require(bool ok,const char* why){if(!ok){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
void be16(Bytes& b,std::size_t n){b.push_back(static_cast<std::uint8_t>(n>>8U));b.push_back(static_cast<std::uint8_t>(n));}
void be32(Bytes& b,std::size_t n){for(int i=3;i>=0;--i)b.push_back(static_cast<std::uint8_t>(n>>(i*8)));}
void set32(Bytes& b,std::size_t p,std::uint32_t n){for(int i=3;i>=0;--i)b[p++]=static_cast<std::uint8_t>(n>>(i*8));}
void str(Bytes& b,const std::string& s){b.insert(b.end(),s.begin(),s.end());}
void chunk(Bytes& b,std::uint32_t tag,const Bytes& body){be32(b,tag);be32(b,body.size());b.insert(b.end(),body.begin(),body.end());}
void property(Bytes& b,unsigned type,const Bytes& value){be16(b,type);be16(b,value.size());b.insert(b.end(),value.begin(),value.end());}
Bytes bank(bool kmp,bool encrypted=false,unsigned kmpVersion=5){
    Bytes props;be16(props,4);
    property(props,0,{static_cast<std::uint8_t>(kmp?5:6),0,1});
    property(props,1,{static_cast<std::uint8_t>(kmp?kmpVersion:0),0});
    property(props,2,{'T','e','s','t',0});property(props,4,{0,0,0,0,0,0,0,1});be32(props,0);
    Bytes toc;be16(toc,props.size());toc.insert(toc.end(),props.begin(),props.end());
    Bytes b;be32(b,0x01000114U);be32(b,0);
    chunk(b,0x02000018U,{0x0B,0,0,0,0,0,0,'K','O','R','F',0});chunk(b,0x05010018U,toc);
    const auto dataAt=b.size();Bytes payload;
    if(kmp){
        if(kmpVersion==8){
            payload.resize(18+2*122+126+2*16+176,0);payload[0]=1;payload[1]=3;
            set32(payload,2,2);set32(payload,6,1);set32(payload,10,2);set32(payload,14,1);
            for(std::size_t n=0;n<2;++n){const auto p=18+n*122;payload[p+75]=static_cast<std::uint8_t>('A'+n);payload[p+114]=static_cast<std::uint8_t>(n+1);set32(payload,p+117,44100);payload[p+121]=static_cast<std::uint8_t>(60+n*12);}
            const std::size_t drum=262;payload[drum]='D';payload[drum+125]=3;
            for(std::size_t l=0;l<4;++l)for(std::size_t n=0;n<4;++n)set32(payload,drum+32+l*20+n*4,0xFFFFFFFFU);
            set32(payload,drum+32,0);set32(payload,drum+36,1);payload[drum+112]=1;
            const std::size_t zone=388;payload[zone+10]=63;payload[zone+11]=60;set32(payload,zone+16,1);payload[zone+26]=127;payload[zone+27]=72;
            const std::size_t multi=420;payload[multi]='M';payload[multi+166]=2;payload[multi+175]=4;
            for(std::size_t k=64;k<128;++k)payload[multi+36+k]=1;
        }else{
            payload.resize(10+111+48+20+166,0);payload[1]=3;payload[3]=1;payload[5]=1;payload[7]=1;payload[9]=1;
            payload[10+103]=1;payload[10+110]=60;
            payload[121]=0xFF;payload[122]=0xFF;
            const std::size_t zone=169;payload[zone+3]=127;payload[zone+4]=60;
            const std::size_t multi=189;payload[multi+156]=1;payload[multi+165]=9;
        }
        chunk(b,0x11000018U|(static_cast<std::uint32_t>(kmpVersion)<<16U),payload);
    }else{
        payload.resize(72,0);payload[7]=1;payload[8]=1;payload[9]=16;set32(payload,10,48000);set32(payload,14,3);
        payload[66]=0x80;payload[67]=0;payload[68]=0;payload[69]=0;payload[70]=0x7F;payload[71]=0xFF;
        if(encrypted)std::fill(payload.begin(),payload.end(),0xDE);
        chunk(b,encrypted?0x12000058U:0x12000018U,payload);
    }
    Bytes xref;str(xref,"KBEG");be32(xref,28);be32(xref,dataAt);str(xref,"KEND");be32(xref,2);chunk(b,0xFE000018U,xref);
    set32(b,4,static_cast<std::uint32_t>(b.size()-8));return b;
}
Bytes read(const std::string& path){std::ifstream f(path,std::ios::binary|std::ios::ate);require(bool(f),"fixture opens");const auto size=f.tellg();Bytes b(static_cast<std::size_t>(size));f.seekg(0);f.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(b.size()));require(bool(f),"fixture reads");return b;}
}
int main(int argc,char** argv){
    Bytes compressed={'O','C','3','1',8,0,0,0,2,'A','B','C','D',0x40,0x0D,'Z',1,0,0,0};
    for(char c:std::string("ABCDABCZ"))compressed.back()^=static_cast<std::uint8_t>(c);
    auto decoded=decodePa5xOc31(compressed);require(bool(decoded)&&decoded.checksumVerified,"OC31 literals, overlap-distance and extra-byte decode");
    require(std::string(decoded.data.begin(),decoded.data.end())=="ABCDABCZ","OC31 decoded byte identity");
    for(std::size_t n=0;n<compressed.size();++n)require(!decodePa5xOc31(compressed.data(),n),"truncated OC31 rejects");
    compressed.back()^=1;require(!decodePa5xOc31(compressed),"OC31 checksum rejects");
    Bytes history={'O','C','3','1',3,0,0,0,0x40,0,0};require(!decodePa5xOc31(history),"OC31 invalid history rejects");
    require(!decodePa5xOc31(compressed,2),"OC31 decoded limit enforced");

    const auto pcm=bank(false);const auto index=inspectPa5xSampleBytes(pcm);
    require(index.valid&&index.kind==Pa5xSampleContainerKind::PcmSamples&&index.objects.size()==1,"linear PCM container indexes");
    require(index.objects[0].hasId&&index.objects[0].resourceId==1&&index.objects[0].sampleRate==48000,"PCM address and metadata retained");
    const auto audio=decodePa5xLinearPcm(pcm,index.objects[0]);require(bool(audio)&&audio.mono.size()==3,"linear audio publishes exact frame count");
    require(audio.mono[0]==-1.0F&&audio.mono[1]==0.0F&&std::fabs(audio.mono[2]-32767.0F/32768.0F)<1e-7F,"S16BE byte order and scale");
    Pa5xKmpSample linkedSample;linkedSample.resourceId=1;linkedSample.sampleRate=48000;
    require(bool(decodePa5xSampleAudio(pcm,index.objects[0],linkedSample)),"raw sample wrapper requires an exact KMP link");
    linkedSample.resourceId=2;require(!decodePa5xSampleAudio(pcm,index.objects[0],linkedSample),"raw sample wrapper rejects a different sample UID");
    linkedSample.resourceId=1;linkedSample.sampleRate=44100;require(!decodePa5xSampleAudio(pcm,index.objects[0],linkedSample),"raw sample wrapper rejects a different sample rate");
    linkedSample.sampleRate=48000;require(!decodePa5xSampleAudio(pcm,index.objects[0],linkedSample,2),"raw sample wrapper bounds allocation before decoding");
    auto forged=index.objects[0];forged.encodedSampleCount=1;require(!decodePa5xSampleAudio(pcm,forged,linkedSample),"raw sample wrapper rejects inconsistent linear counts");
    auto channelIssue=pcm;channelIssue[index.objects[0].payloadOffset+8]=2;
    const auto partialChannel=inspectPa5xSampleBytes(channelIssue,true);
    require(partialChannel.valid && !partialChannel.objects[0].audioMetadataDecoded &&
            partialChannel.objects[0].decodeError.find("channel tag=2")!=std::string::npos &&
            partialChannel.objects[0].decodeError.find("48000")!=std::string::npos,
            "unsupported PCM channel preserves raw channel/rate diagnostics without faking a decoded waveform");
    auto rateIssue=pcm;set32(rateIssue,index.objects[0].payloadOffset+10,0);
    const auto partialRate=inspectPa5xSampleBytes(rateIssue,true);
    require(partialRate.valid && !partialRate.objects[0].audioMetadataDecoded &&
            partialRate.objects[0].decodeError.find("sample-rate=0")!=std::string::npos,
            "unsupported PCM rate is reported with its exact encoded value");
    auto bad=pcm;bad[index.objects[0].payloadOffset+7]=2;require(!inspectPa5xSampleBytes(bad).valid,"TOC/body ID mismatch rejects");
    bad=pcm;bad[2]=2;require(!inspectPa5xSampleBytes(bad).valid,"unknown root revision rejects");
    for(std::size_t n=0;n<pcm.size();++n){Bytes prefix(pcm.begin(),pcm.begin()+static_cast<std::ptrdiff_t>(n));require(!inspectPa5xSampleBytes(prefix).valid,"truncated KORF rejects");}
    const auto encrypted=bank(false,true);const auto locked=inspectPa5xSampleBytes(encrypted);
    require(locked.valid&&locked.objects[0].encrypted&&!locked.objects[0].audioMetadataDecoded&&!locked.blockers.empty(),"encrypted object stays indexed without interpreting payload");
    require(!decodePa5xLinearPcm(encrypted,locked.objects[0]),"encrypted audio never publishes");
    const auto kmpFixture=bank(true);const auto mapping=inspectPa5xSampleBytes(kmpFixture);
    require(mapping.valid&&mapping.multisampleMappingDecoded&&mapping.samples.size()==1&&mapping.keyZones.size()==1&&mapping.multisamples.size()==1,"ordinary uncompressed KMP tables map");
    require(mapping.multisamples[0].resourceId==9&&mapping.keyZones[0].sampleIndex==0,"KMP exact zone/sample address");
    require(mapping.drumSamples[0].stereoPairingKnown,"legacy drum left/right semantics remain explicit");
    bad=kmpFixture;bad[mapping.objects[0].payloadOffset+169+8]=0xFE;
    const auto negativeLevel=inspectPa5xSampleBytes(bad);
    require(negativeLevel.valid&&negativeLevel.keyZones[0].level==-2&&negativeLevel.keyZones[0].version5Record[8]==0xFE,"legacy signed zone level and original record bits retained");
    bad=kmpFixture;bad[mapping.objects[0].payloadOffset+124]=1;
    require(!inspectPa5xSampleBytes(bad).valid,"KMP drum references outside sample table reject");
    bad=kmpFixture;bad[mapping.objects[0].payloadOffset+169]=0xFF;bad[mapping.objects[0].payloadOffset+170]=0xFE;
    require(!inspectPa5xSampleBytes(bad).valid,"KMP unknown negative sample sentinel rejects");

    const auto v8=bank(true,false,8);const auto indexed8=inspectPa5xSampleBytes(v8);
    require(indexed8.valid&&indexed8.multisampleMappingDecoded&&indexed8.samples.size()==2&&indexed8.drumSamples.size()==1&&indexed8.keyZones.size()==2&&indexed8.multisamples.size()==1,"KMP v8 exact 32-bit table directories map");
    require(indexed8.samples[0].name=="A"&&indexed8.samples[1].resourceId==2&&indexed8.samples[0].sampleRate==44100,"KMP v8 sample name UID and rate retained");
    require(!indexed8.samples[0].bankKnown&&indexed8.samples[0].predictorsKnown&&indexed8.samples[0].predictorsDerived&&!indexed8.keyZones[0].pitchLevelDecoded,"KMP v8 derived stable predictors are separate from unknown bank and zone DSP");
    require(indexed8.drumSamples[0].leftSample==0&&indexed8.drumSamples[0].rightSample==1&&indexed8.drumSamples[0].version8ReferencesPresent,"KMP v8 drum reference layout retained");
    require(!indexed8.drumSamples[0].stereoPairingKnown,"v8 reference matrix is not asserted to be a decoded stereo pair");
    require(indexed8.multisamples[0].resourceId==4&&indexed8.multisamples[0].zoneIndices[127]==1&&indexed8.keyZones[1].highNote==127,"KMP v8 key maps retain exact sample addresses");
    bad=v8;set32(bad,indexed8.objects[0].payloadOffset+2,0x7FFFFFFFU);require(!inspectPa5xSampleBytes(bad).valid,"KMP v8 oversized table count rejected before allocation");
    bad=v8;set32(bad,indexed8.objects[0].payloadOffset+262+32+3*20,2);require(!inspectPa5xSampleBytes(bad).valid,"KMP v8 later drum reference bounds validated");
    bad=v8;set32(bad,indexed8.objects[0].payloadOffset+388,0xFFFFFFFEU);require(!inspectPa5xSampleBytes(bad).valid,"KMP v8 unknown negative sample reference rejected");
    bad=v8;set32(bad,indexed8.objects[0].payloadOffset+420+32,2);require(!inspectPa5xSampleBytes(bad).valid,"KMP v8 multisample zone span bounded");

    if(argc>=2){
        const std::string root=argv[1];const auto kmp=inspectPa5xSampleFile(root+"/ram.kmp");
        require(kmp.valid&&kmp.multisampleMappingDecoded&&kmp.samples.size()==12487&&kmp.drumSamples.size()==2298&&kmp.keyZones.size()==10081&&kmp.multisamples.size()==439,"real KMP exact complete table boundaries");
        std::size_t total=0,lockedCount=0,linearCount=0,predictiveCount=0;
        for(int n=1;n<=5;++n){
            const auto path=root+"/ram0"+std::to_string(n)+".pcm";const auto data=read(path);const auto r=inspectPa5xSampleBytes(data);require(r.valid,"real PCM complete container indexes");
            total+=r.objects.size();
            for(const auto& o:r.objects){
                if(o.encrypted){++lockedCount;continue;}
                require(o.audioMetadataDecoded&&o.hasId,"ordinary sample metadata/ID validates");
                const auto match=std::find_if(kmp.samples.begin(),kmp.samples.end(),[&](const Pa5xKmpSample& s){return s.resourceId==o.resourceId;});
                require(match!=kmp.samples.end()&&match->sampleRate==o.sampleRate,"PCM exact UID/rate links to KMP");
                if(o.sampleFormat==16){++linearCount;require(bool(decodePa5xLinearPcm(data,o)),"real linear PCM converts");}
                else if(o.sampleFormat==128)++predictiveCount;
            }
        }
        require(total==605&&lockedCount==91&&linearCount==8&&predictiveCount==506,"real PCM codec/encryption counts");
    }
    if(argc>=3){
        const auto incoming=inspectPa5xSampleFile(argv[2]);
        require(incoming.valid&&incoming.multisampleMappingDecoded&&incoming.samples.size()==19460&&incoming.drumSamples.size()==4565&&incoming.keyZones.size()==14731&&incoming.multisamples.size()==651,"uploaded KMP v8 exact complete table lengths");
        require(incoming.samples.front().name=="Musi 1"&&incoming.multisamples.front().name=="Musi 1"&&incoming.multisamples[1].firstZone==17,"uploaded KMP v8 names and 32-bit multisample offsets");
        require(incoming.samples.front().resourceId==0x4546550B84036E8CULL&&!incoming.samples.front().bankKnown,"uploaded KMP v8 exact sample UID without guessed PCM bank");
        require(incoming.samples.front().predictorsDerived&&incoming.samples.front().predictorsKnown&&incoming.samples.front().predictor1==31028&&incoming.samples.front().predictor2==-14695,"uploaded KMP v8 empirically located stable predictor pair retained");
        require(incoming.drumSamples.front().leftSample==2081&&incoming.drumSamples.front().rightSample==2082,"uploaded KMP v8 drum references");
    }
    if(argc>=4){
        const auto kmp=inspectPa5xSampleFile(argv[2]);const auto data=read(argv[3]);
        const auto pcm2=inspectPa5xSampleBytes(data);
        require(pcm2.valid&&pcm2.objects.size()==93,"uploaded PCM v2 nested resources validate");
        std::size_t linear=0,predictive=0,frames=0;
        for(const auto& object:pcm2.objects){
            const auto sample=std::find_if(kmp.samples.begin(),kmp.samples.end(),[&](const Pa5xKmpSample& s){return s.resourceId==object.resourceId;});
            require(sample!=kmp.samples.end(),"uploaded PCM resource has an exact typed KMP sample link");
            const auto decodedAudio=decodePa5xSampleAudio(data,object,*sample);
            require(bool(decodedAudio)&&decodedAudio.sampleRate==object.sampleRate&&decodedAudio.mono.size()==object.encodedSampleCount,"uploaded raw sample decode retains exact rate and frame count");
            for(const auto value:decodedAudio.mono)require(std::isfinite(value)&&value>=-1.0F&&value<=1.0F,"uploaded decoded waveform stays finite in signed PCM range");
            frames+=decodedAudio.mono.size();
            if(object.sampleFormat==16)++linear;else if(object.sampleFormat==128)++predictive;
        }
        require(linear==36&&predictive==57&&frames==6143052,"uploaded PCM all93 actual linear and predictive waveform counts");
        const auto& object=pcm2.objects.front();auto sample=kmp.samples.front();
        require(object.resourceId==sample.resourceId&&object.sampleFormat==128,"first uploaded raw predictive sample uses exact first KMP entry");
        sample.predictorsKnown=false;require(!decodePa5xSampleAudio(data,object,sample),"unknown predictive coefficients never publish a waveform");
        sample=kmp.samples.front();auto shortAudio=object;--shortAudio.audioDataBytes;
        require(!decodePa5xSampleAudio(data,shortAudio,sample),"predictive frame count and byte span must agree");
        require(!decodePa5xSampleAudio(data,object,sample,object.encodedSampleCount-1U),"predictive allocation limit is applied before waveform decoding");
    }
    std::cout<<"Pa5X sample index: PASS (OC31 bounds/checksum, KMP maps, PCM metadata, UID/rate gate and raw linear decode)\n";
}
