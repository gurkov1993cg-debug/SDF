#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>

using namespace silveton::sampler;
namespace {
SourceOscillatorDsp profile(){
    SourceOscillatorDsp source;source.resourceVersion=2U;source.layoutCorroborated=true;
    source.equalizerPresent=true;source.equalizerRaw={{1U,99U,0U,90U,0U,0U}};
    return source;
}
SourceOscillatorRuntime runtimeFor(const SourceOscillatorDsp& source,double rate=48000.0){
    SourceOscillatorRuntime result;result.prepare(&source,1U,0.0F);
    result.start(SourceModulationContext{},SourceSoundEdits{},rate);return result;
}
std::uint8_t signedByte(int value){return static_cast<std::uint8_t>(value&255);}
bool bitSame(float a,float b){return std::memcmp(&a,&b,sizeof(float))==0;}

void neutralAndDisabledAreExactBypass(){
    for(unsigned setting=0U;setting<5U;++setting){
        auto source=profile();
        if(setting==0U)source.equalizerPresent=false;
        if(setting==1U)source.equalizerRaw={{0U,255U,127U,255U,127U,127U}};
        if(setting==2U)source.equalizerRaw[3]=165U; // unused frequency is not an error
        if(setting==3U)source.manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Equalizer);
        if(setting==4U)source.layoutCorroborated=false;
        auto runtime=runtimeFor(source);
        const std::array<float,8> input{{0.0F,-0.0F,.5F,-.5F,1.0e-20F,-1.0e-20F,127.0F,-127.0F}};
        for(unsigned frame=0U;frame<1024U;++frame){
            const float originalLeft=input[frame%input.size()],originalRight=input[(frame+3U)%input.size()];
            float left=originalLeft,right=originalRight;runtime.processEqualizer(left,right);
            assert(bitSame(left,originalLeft)&&bitSame(right,originalRight));
        }
        if(setting==1U||setting==2U)assert(runtime.support.equalizerComplete&&!runtime.support.equalizerUnknown);
    }
}

void trimHasExactEndpointsAndIndependentAdmission(){
    for(unsigned trim:{0U,35U,60U,89U,99U}){
        auto source=profile();source.equalizerRaw[1]=static_cast<std::uint8_t>(trim);
        auto runtime=runtimeFor(source);
        assert(runtime.support.equalizerTrim&&runtime.support.equalizerShelves&&runtime.support.equalizerComplete);
        const float gain=static_cast<float>(trim)/99.0F;
        for(unsigned frame=0U;frame<1000U;++frame){
            const float leftIn=std::sin(static_cast<float>(frame)*.1F),rightIn=-leftIn*.3F;
            float left=leftIn,right=rightIn;runtime.processEqualizer(left,right);
            assert(bitSame(left,leftIn*gain)&&bitSame(right,rightIn*gain));
        }
    }
    auto source=profile();source.equalizerRaw={{1U,200U,12U,90U,0U,0U}};
    auto runtime=runtimeFor(source);
    assert(!runtime.support.equalizerTrim&&runtime.support.equalizerShelves&&runtime.support.equalizerUnknown);
    assert(runtime.equalizerTrim==1.0F&&runtime.equalizerLow.enabled);
    source.equalizerRaw={{1U,60U,127U,90U,0U,0U}};runtime=runtimeFor(source);
    assert(runtime.support.equalizerTrim&&!runtime.support.equalizerShelves&&runtime.support.equalizerUnknown);
    float left=.5F,right=-.5F;runtime.processEqualizer(left,right);
    assert(left==.5F*60.0F/99.0F&&right==-left);
}

void activeMidAndUnrecognizedEnableRemainUnknown(){
    auto source=profile();source.equalizerRaw={{1U,99U,12U,165U,36U,244U}};
    const auto original=source.equalizerRaw;auto runtime=runtimeFor(source);
    assert(runtime.support.equalizerTrim&&runtime.support.equalizerShelves);
    assert(!runtime.support.equalizerComplete&&runtime.support.equalizerUnknown);
    assert(runtime.equalizerLow.enabled&&runtime.equalizerHigh.enabled);
    float left=.1F,right=0.0F;runtime.processEqualizer(left,right);
    assert(left!=.1F&&right==0.0F&&source.equalizerRaw==original);
    source.equalizerRaw[0]=2U;runtime=runtimeFor(source);
    assert(!runtime.support.equalizerTrim&&!runtime.support.equalizerShelves);
    assert(!runtime.support.equalizerComplete&&runtime.support.equalizerUnknown);
    left=.1F;right=-.2F;runtime.processEqualizer(left,right);
    assert(left==.1F&&right==-.2F);
    // Merely retaining a raw index never manufactures a middle frequency.
    source=profile();source.equalizerRaw[3]=165U;source.equalizerRaw[4]=12U;
    runtime=runtimeFor(source);assert(runtime.support.equalizerUnknown);
    left=.1F;right=-.2F;runtime.processEqualizer(left,right);
    assert(left==.1F&&right==-.2F);
}

void shelfGainEndpointsAndStereoIndependence(){
    for(const bool high:{false,true})for(const int halfDb:{-36,-24,-1,0,1,24,36}){
        auto source=profile();source.equalizerRaw[high?5U:2U]=signedByte(halfDb);
        auto runtime=runtimeFor(source);
        const double expected=std::pow(10.0,static_cast<double>(halfDb)*.5/20.0);
        double inputEnergy=0.0,outputEnergy=0.0;
        for(unsigned frame=0U;frame<24000U;++frame){
            // DC and Nyquist alternating audio expose the exact shelf plateaus
            // without relying on this implementation's filter coefficients.
            const float input=high&&frame%2U!=0U?-.01F:.01F;
            float left=input,right=0.0F;runtime.processEqualizer(left,right);
            assert(std::isfinite(left)&&right==0.0F);
            if(frame>=12000U){inputEnergy+=input*input;outputEnergy+=static_cast<double>(left)*left;}
        }
        const double measured=std::sqrt(outputEnergy/inputEnergy);
        assert(std::abs(measured-expected)<expected*.00005);
    }
}

void maximumBoostImpulseTailsStayFinite(){
    for(const double rate:{8000.0,44100.0,48000.0,96000.0,192000.0})
        for(const int low:{-36,0,36})for(const int high:{-36,0,36}){
            auto source=profile();source.equalizerRaw[2]=signedByte(low);source.equalizerRaw[5]=signedByte(high);
            auto runtime=runtimeFor(source,rate);double energy=0.0;float finalPeak=0.0F;
            for(unsigned frame=0U;frame<32768U;++frame){
                float left=frame==0U?.25F:0.0F,right=-left;
                runtime.processEqualizer(left,right);
                assert(std::isfinite(left)&&std::isfinite(right)&&left==-right&&std::abs(left)<16.0F);
                energy+=static_cast<double>(left)*left;
                if(frame>31744U)finalPeak=std::max(finalPeak,std::abs(left));
            }
            assert(std::isfinite(energy)&&energy<256.0&&finalPeak<.00001F);
        }
    auto source=profile();source.equalizerRaw[2]=36U;auto runtime=runtimeFor(source);
    float left=std::numeric_limits<float>::infinity(),right=0.0F;
    runtime.processEqualizer(left,right);assert(left==0.0F&&right==0.0F);
    left=.1F;runtime.processEqualizer(left,right);
    assert(std::isfinite(left)&&left!=0.0F&&right==0.0F);
    left=std::numeric_limits<float>::max();runtime.processEqualizer(left,right);
    assert(left==0.0F&&right==0.0F);
}
}

int main(){
    neutralAndDisabledAreExactBypass();trimHasExactEndpointsAndIndependentAdmission();
    activeMidAndUnrecognizedEnableRemainUnknown();shelfGainEndpointsAndStereoIndependence();
    maximumBoostImpulseTailsStayFinite();
    std::puts("PASS source EQ: exact neutral/disabled bypass; own trim/shelves; saved half-dB plateau gains; stereo isolation; finite impulse tails8-192kHz; active mid-frequency remains explicit unknown");
}
