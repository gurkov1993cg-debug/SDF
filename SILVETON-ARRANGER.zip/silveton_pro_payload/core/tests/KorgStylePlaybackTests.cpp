#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/arranger/KorgStyleImport.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <initializer_list>
#include <memory>
#include <string>
#include <tuple>
#include <vector>

using namespace silveton::arranger;

namespace {
struct Capture final : RenderCallbacks {
    struct Event { std::uint64_t sample; int player, track, status, key, velocity; };
    std::vector<Event> events;
    std::uint64_t base{0};
    std::uint32_t cursor{0};
    void render(std::uint32_t offset, std::uint32_t frames) noexcept override {
        assert(offset == cursor); cursor += frames;
    }
    void midi(int p, int t, std::uint8_t s, std::uint8_t a, std::uint8_t b) noexcept override {
        events.push_back({base + cursor, p, t, s, a, b});
    }
    void run(ArrangerEngine& engine, std::uint32_t frames) {
        cursor = 0; engine.process(frames, 48000.0, *this); assert(cursor == frames); base += frames;
    }
    std::vector<Event> starts(int track = -1) const {
        std::vector<Event> out;
        for (const auto& event : events)
            if (event.status == 0x90 && event.velocity > 0 && (track < 0 || event.track == track)) out.push_back(event);
        return out;
    }
};

std::shared_ptr<Style> nativeStyle(unsigned numerator = 4, unsigned denominator = 4) {
    auto style = std::make_shared<Style>();
    style->name = "Independent native CV fixture"; style->nativeKorg = true;
    style->ppq = 384; style->tempoBpm = 60.0;
    auto& section = style->sections[static_cast<std::size_t>(Element::Var1)];
    section.available = true; section.nativePatterns = true; section.lengthTicks = 1536;
    section.numerator = static_cast<std::uint8_t>(numerator);
    section.denominator = static_cast<std::uint8_t>(denominator);
    return style;
}

TrackPattern& pattern(Style& style, int track, NativePatternMode mode, TrackRole role) {
    style.tracks[static_cast<std::size_t>(track)].used = true;
    style.tracks[static_cast<std::size_t>(track)].role = role;
    auto& out = style.sections[static_cast<std::size_t>(Element::Var1)].patterns[static_cast<std::size_t>(track)];
    out.present = true; out.mode = mode;
    for (std::size_t chord = 0; chord < out.chordCv.size(); ++chord)
        if (chord != static_cast<std::size_t>(ChordType::None)) out.chordCv[chord] = 1;
    return out;
}

ChordVariation& cv(TrackPattern& track, int number, std::uint32_t length,
                   int key, std::uint32_t rest = 0, int sourceRoot = 0,
                   ChordType sourceChord = ChordType::Major) {
    auto& out = track.cvs[static_cast<std::size_t>(number - 1)];
    out.available = true; out.lengthTicks = length;
    out.sourceRoot = sourceRoot; out.sourceChord = sourceChord;
    out.events = {{rest, 0, 0x90, static_cast<std::uint8_t>(key), 100},
                  {rest + 1U, 0, 0x80, static_cast<std::uint8_t>(key), 0}};
    return out;
}

void keys(ArrangerEngine& engine, std::initializer_list<int> notes, bool down = true) {
    for (const int note : notes) assert(engine.postMidi(down ? 0x90 : 0x80, note, down ? 100 : 0));
}

void begin(ArrangerEngine& engine, const std::shared_ptr<Style>& style) {
    assert(engine.installStyle(0, style));
    assert(engine.postChordControls(static_cast<int>(ChordRecognitionMode::FingeredThreeNotes), 3,
                                    true, false, false, 60, true));
    keys(engine, {48, 52, 55});
    assert(engine.post({CommandType::Play, 0}));
}

std::vector<std::uint64_t> times(const std::vector<Capture::Event>& events) {
    std::vector<std::uint64_t> out; for (const auto& event : events) out.push_back(event.sample); return out;
}

using Bytes = std::vector<std::uint8_t>;
void bytes(Bytes& target, const Bytes& source) { target.insert(target.end(), source.begin(), source.end()); }
void u32(Bytes& out, std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) out.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
void delta(Bytes& out, std::uint32_t value) {
    std::array<std::uint8_t, 4> encoded{}; std::size_t count = 0;
    do { encoded[count++] = static_cast<std::uint8_t>(value & 127U); value >>= 7U; } while (value);
    while (count > 0) { --count; out.push_back(static_cast<std::uint8_t>(encoded[count] | (count > 0 ? 128U : 0U))); }
}
Bytes resource(const char* kind, const std::string& name, const Bytes& payload) {
    const std::string type(kind); Bytes out(type.begin(), type.end()); out.push_back(0);
    out.insert(out.end(), name.begin(), name.end()); out.push_back(0); u32(out, static_cast<std::uint32_t>(payload.size())); bytes(out, payload); return out;
}
Bytes xml(const std::string& name, const std::string& text) { return resource("Leaf", name, Bytes(text.begin(), text.end())); }

Bytes nativeContainer(bool declaredPatch, bool allDrum = false, bool mixed = false, bool guitar = false) {
    // Pa5X layout observed across all 70,284 clip MIDIs: track0 setup ends
    // after one actual measure; track n contains CVn, including empty slots.
    Bytes setup{0, 0xFF, 0x58, 4, 5, 3, 24, 8};
    if (declaredPatch) bytes(setup, {24, 0xB0, 0, 121, 0, 0xB0, 32, 66, 0, 0xC0, 20, 0, 0xB0, 7, 77});
    delta(setup, declaredPatch ? 936 : 960); bytes(setup, {0xFF, 0x2F, 0});
    Bytes first; delta(first, 1200); bytes(first, {0x90, 60, 100, 48, 0x80, 60, 0});
    delta(first, 1632); bytes(first, {0xFF, 0x2F, 0});
    Bytes fourth; delta(fourth, 1440); bytes(fourth, {0x90, 62, 100, 48, 0x80, 62, 0});
    delta(fourth, 3312); bytes(fourth, {0xFF, 0x2F, 0});
    Bytes midi{'M', 'T', 'h', 'd', 0, 0, 0, 6, 0, 1, 0, 5, 1, 128};
    for (const auto& track : std::array<Bytes, 5>{{setup, first, {0, 0xFF, 0x2F, 0}, {0, 0xFF, 0x2F, 0}, fourth}}) {
        bytes(midi, {'M', 'T', 'r', 'k'}); u32(midi, static_cast<std::uint32_t>(track.size())); bytes(midi, track);
    }
    const std::string description =
        "<CLIP type=\"PadClip\" version=\"0\" release=\"4\"><RESOURCE name=\"Main.mid\"/><PARAMS>"
        "<Pattern type=\"Accompaniment\"/><Loop number=\"-1\" length=\"-1\"/>"
        "<TimeStretching numerator=\"1\" denominator=\"1\"/><Start fineSlide=\"0\"/>"
        "<NTT value=\"1\"/><NTR value=\"0\"/><ReTrigger mode=\"2\"/>"
        "<ORIGINAL_CHORD><CV1 root=\"C\" chord=\"Maj\"/><CV4 root=\"D\" chord=\"Min\"/></ORIGINAL_CHORD>"
        "<CHORD_TABLE><Maj cv=\"1\"/><Min cv=\"4\"/><Dom7 cv=\"6\"/></CHORD_TABLE></PARAMS></CLIP>";
    const auto sceneWithPattern = [&](const std::string& patternName) {
        auto changed = description;
        const std::string original = "<Pattern type=\"Accompaniment\"/>";
        changed.replace(changed.find(original), original.size(), "<Pattern type=\"" + patternName + "\"/>");
        Bytes clip = resource("Leaf", "Main.mid", midi); bytes(clip, xml("ClipDescription.xml", changed));
        Bytes scene = resource("Branch", "Acc1.pdc", clip);
        bytes(scene, xml("SceneDescription.xml", "<SCENE><PARAMS><TimeSignature numerator=\"5\" denominator=\"3\"/></PARAMS></SCENE>"));
        return scene;
    };
    Bytes elements = resource("Branch", "Var1.scn", sceneWithPattern(guitar ? "Guitar" : (allDrum ? "Drum" : "Accompaniment")));
    if (mixed) bytes(elements, resource("Branch", "Var2.scn", sceneWithPattern("Drum")));
    Bytes payload = resource("Branch", "Example.stc", resource("Branch", "Main.ssn", elements));
    bytes(payload, xml("StageDescription.xml", "<STAGE><PARAMS><Tempo value=\"1000000\"/></PARAMS></STAGE>"));
    Bytes root{'R', 'o', 'o', 't', 0, 1, 0}; u32(root, static_cast<std::uint32_t>(payload.size())); bytes(root, payload); return root;
}

void converterPreservesRestSlotsAndAddresses() {
    const auto imported = importKorgStyleBytes(nativeContainer(true));
    assert(imported && imported.style->nativeKorg && imported.style->tempoBpm == 60.0);
    const auto& section = imported.style->sections[static_cast<std::size_t>(Element::Var1)];
    const auto& track = section.patterns[3];
    assert(section.numerator == 5 && section.denominator == 8);
    assert(track.present && track.mode == NativePatternMode::RecordedSourceOnly);
    assert(track.cvs[0].available && track.cvs[0].lengthTicks == 1920 && track.cvs[0].events[0].tick == 240);
    assert(!track.cvs[1].available && !track.cvs[2].available);
    assert(track.cvs[3].available && track.cvs[3].lengthTicks == 3840 && track.cvs[3].events[0].tick == 480);
    assert(track.cvs[3].sourceRoot == 2 && track.cvs[3].sourceChord == ChordType::Minor);
    assert(track.chordCv[static_cast<std::size_t>(ChordType::Seventh)] == 6 && !track.cvs[5].available);
    const auto& address = imported.style->tracks[3];
    assert(address.addressKnown && !address.addressVaries && address.msb == 121 && address.lsb == 66 && address.program == 20);
    assert(!imported.warnings.empty());
    ArrangerEngine engine; Capture capture;
    assert(engine.installStyle(0, imported.style));
    keys(engine, {48, 52, 55}); assert(engine.post({CommandType::Play, 0})); capture.run(engine, 300001);
    assert((times(capture.starts(3)) == std::vector<std::uint64_t>{30000, 270000}));
    const auto unknown = importKorgStyleBytes(nativeContainer(false));
    assert(unknown && !unknown.style->tracks[3].addressKnown);
}

void converterUsesActualPatternRole() {
    const auto drum = importKorgStyleBytes(nativeContainer(true, true));
    assert(drum && drum.style->tracks[3].role == TrackRole::Drums);
    assert(drum.style->sections[static_cast<std::size_t>(Element::Var1)].patterns[3].mode == NativePatternMode::Drum);
    const auto mixed = importKorgStyleBytes(nativeContainer(true, false, true));
    assert(mixed && !mixed.warnings.empty());
    for (const auto element : {Element::Var1, Element::Var2}) {
        const auto& track = mixed.style->sections[static_cast<std::size_t>(element)].patterns[3];
        assert(track.present && track.mode == NativePatternMode::Unsupported);
        assert(track.cvs[0].available && !track.cvs[0].events.empty());
    }
}

void independentCvLoops() {
    // Actual STGs contain independent per-track/CV EOTs. Two- and three-bar
    // tracks must retain their phase across the section's three-bar boundary.
    auto style = nativeStyle();
    style->sections[static_cast<std::size_t>(Element::Var1)].lengthTicks = 4608;
    cv(pattern(*style, 0, NativePatternMode::Drum, TrackRole::Drums), 1, 3072, 36);
    cv(pattern(*style, 1, NativePatternMode::Drum, TrackRole::Percussion), 1, 4608, 42);
    auto collect = [&](std::uint32_t block) {
        ArrangerEngine engine; Capture capture; begin(engine, style);
        for (std::uint32_t remaining = 1200001; remaining > 0;) {
            const auto step = std::min(block, remaining); capture.run(engine, step); remaining -= step;
        }
        return capture;
    };
    const auto small = collect(97), large = collect(4096);
    assert((times(small.starts(0)) == std::vector<std::uint64_t>{0, 384000, 768000, 1152000}));
    assert((times(small.starts(1)) == std::vector<std::uint64_t>{0, 576000, 1152000}));
    assert(small.events.size() == large.events.size());
    for (std::size_t i = 0; i < small.events.size(); ++i) {
        const auto& a = small.events[i]; const auto& b = large.events[i];
        assert(std::tie(a.sample, a.player, a.track, a.status, a.key, a.velocity) ==
               std::tie(b.sample, b.player, b.track, b.status, b.key, b.velocity));
    }
}

void independentCvRestoresRecordedMix() {
    auto style = nativeStyle();
    auto& shortTrack = pattern(*style, 0, NativePatternMode::Drum, TrackRole::Drums);
    auto& phrase = cv(shortTrack, 1, 384, 36);
    cv(pattern(*style, 1, NativePatternMode::Drum, TrackRole::Percussion), 1, 1536, 42);
    constexpr std::array<std::uint8_t,6> cc{{7,10,11,91,93,94}};
    constexpr std::array<int,6> initial{{96,40,110,30,45,55}};
    constexpr std::array<int,6> changed{{12,110,32,90,80,70}};
    for(std::size_t i=0;i<cc.size();++i){
        shortTrack.setupEvents.push_back({0,0,0xb0,cc[i],static_cast<std::uint8_t>(initial[i])});
        phrase.events.push_back({192,0,0xb0,cc[i],static_cast<std::uint8_t>(changed[i])});
    }
    ArrangerEngine engine; Capture capture; begin(engine,style);
    capture.run(engine,100000);
    std::array<int,6> mix{}; mix.fill(-1);
    int starts=0;
    for(const auto& e:capture.events){
        if(e.player!=0 || e.track!=0)continue;
        if(e.status==0xb0)for(std::size_t i=0;i<cc.size();++i)if(e.key==cc[i])mix[i]=e.velocity;
        if(e.status==0x90 && e.velocity>0){
            std::fprintf(stderr,"CV start %d: volume=%d pan=%d expression=%d sends=%d,%d,%d\n",++starts,mix[0],mix[1],mix[2],mix[3],mix[4],mix[5]);
            assert(mix==initial);
        }
    }
    assert(starts==3);
}

void introDurationUsesSelectedCv() {
    auto style = nativeStyle();
    auto& main = pattern(*style, 0, NativePatternMode::Drum, TrackRole::Drums);
    cv(main, 1, 1536, 40);
    auto& intro = style->sections[static_cast<std::size_t>(Element::Intro1)];
    intro.available = true; intro.nativePatterns = true; intro.lengthTicks = 6144;
    intro.patterns[0] = main;
    cv(intro.patterns[0], 1, 1536, 36);
    cv(intro.patterns[0], 2, 6144, 38); // longer CV exists but is not selected
    ArrangerEngine engine; Capture capture;
    assert(engine.installStyle(0, style));
    keys(engine, {48, 52, 55});
    assert(engine.post({CommandType::SelectElement, 0, static_cast<int>(Element::Intro1)}));
    assert(engine.post({CommandType::Play, 0})); capture.run(engine, 192001);
    const auto starts = capture.starts();
    assert(starts.size() == 2 && starts[0].key == 36 && starts[0].sample == 0);
    assert(starts[1].key == 40 && starts[1].sample == 192000);
    assert(engine.snapshot(0).element == Element::Var1);
}

void nativeIntroWithoutVariationStopsAtEnd() {
    auto style = nativeStyle();
    cv(pattern(*style, 0, NativePatternMode::Drum, TrackRole::Drums), 1, 1536, 36);
    auto& variation = style->sections[static_cast<std::size_t>(Element::Var1)];
    style->sections[static_cast<std::size_t>(Element::Intro1)] = variation;
    variation = Section{};
    ArrangerEngine engine; Capture capture; begin(engine, style); capture.run(engine, 1);
    assert(engine.snapshot(0).playing && engine.snapshot(0).element == Element::Intro1);
    capture.run(engine, 192000);
    assert(!engine.snapshot(0).playing);
    assert(capture.starts().size() == 1 && capture.starts()[0].key == 36 && capture.starts()[0].sample == 0);

    auto generic = std::make_shared<Style>(); generic->name = "Generic Intro without Variation";
    auto& intro = generic->sections[static_cast<std::size_t>(Element::Intro1)];
    intro.available = true; intro.lengthTicks = 1920;
    intro.events = {{0, 0, 0x90, 60, 100}, {1, 0, 0x80, 60, 0}};
    ArrangerEngine genericEngine;
    assert(!genericEngine.installStyle(0, generic));
}

void quarterTempoAndMeters() {
    for (const unsigned numerator : {5U, 9U}) {
        auto style = nativeStyle(numerator, 8);
        const auto bar = static_cast<std::uint32_t>(384U * numerator / 2U);
        style->tempoBpm = 120.0;
        style->sections[static_cast<std::size_t>(Element::Var1)].lengthTicks = bar;
        cv(pattern(*style, 0, NativePatternMode::Drum, TrackRole::Drums), 1, bar, 36);
        ArrangerEngine engine; Capture capture; begin(engine, style); capture.run(engine, 120001);
        const auto starts = capture.starts();
        assert(starts.size() >= 2 && starts[0].sample == 0);
        assert(starts[1].sample == static_cast<std::uint64_t>(numerator) * 12000U);
        const auto state = engine.snapshot(0);
        assert(state.numerator == numerator && state.denominator == 8 && state.tempoBpm == 120.0);
    }
}

void tempoEventsAreSampleAccurate() {
    auto style = nativeStyle();
    auto& variation = cv(pattern(*style, 0, NativePatternMode::Drum, TrackRole::Drums), 1, 1536, 36);
    variation.events = {{0, 0, 0x90, 36, 100}, {1, 0, 0x80, 36, 0},
                        {384, 0, 0x90, 37, 100}, {385, 0, 0x80, 37, 0},
                        {768, 0, 0x90, 38, 100}, {769, 0, 0x80, 38, 0}};
    variation.tempoEvents = {{384, 120.0}};
    ArrangerEngine engine; Capture capture; begin(engine, style); capture.run(engine, 72001);
    assert((times(capture.starts()) == std::vector<std::uint64_t>{0, 48000, 72000}));
    assert(engine.snapshot(0).tempoBpm == 120.0);
}

void cvSelectionPreservesPhaseAndMissingMeansSilence() {
    auto style = nativeStyle();
    auto& track = pattern(*style, 3, NativePatternMode::Drum, TrackRole::Accompaniment);
    cv(track, 1, 1536, 60);
    auto& second = cv(track, 2, 768, 67, 384);
    second.events.insert(second.events.begin(), {{0, 0, 0x90, 65, 100}, {1, 0, 0x80, 65, 0}});
    track.chordCv[static_cast<std::size_t>(ChordType::Minor)] = 2;
    track.chordCv[static_cast<std::size_t>(ChordType::Seventh)] = 6; // intentionally empty CV6
    ArrangerEngine engine; Capture capture; begin(engine, style); capture.run(engine, 24000);
    assert(engine.snapshot(0).selectedCvs[3] == 1);
    capture.events.clear(); keys(engine, {52}, false); keys(engine, {51}); capture.run(engine, 24001);
    const auto selected = engine.snapshot(0);
    assert(selected.chord.type == ChordType::Minor && selected.selectedCvs[3] == 2);
    const auto starts = capture.starts(3);
    // The switch at section tick192 must not restart/chase CV2's tick0 note.
    assert(starts.size() == 1 && starts[0].key == 67 && starts[0].sample == 48000);
    capture.events.clear(); keys(engine, {51}, false); keys(engine, {52, 58}); capture.run(engine, 200000);
    assert(engine.snapshot(0).chord.type == ChordType::Seventh);
    assert(capture.starts(3).empty());
    assert(engine.snapshot(0).selectedCvs[3] == 0);
}

void harmonicAdaptationAndPatternType() {
    auto style = nativeStyle();
    cv(pattern(*style, 2, NativePatternMode::RecordedSourceOnly, TrackRole::Bass),
       1, 1536, 55, 0, 7, ChordType::Minor7);
    // A Drum pattern in an ACC lane stays a drum pattern, including its pitch.
    cv(pattern(*style, 3, NativePatternMode::Drum, TrackRole::Accompaniment), 1, 1536, 74);
    // The opposite mapping is also authoritative: pitched phrases can live in a percussion lane.
    cv(pattern(*style, 1, NativePatternMode::RecordedSourceOnly, TrackRole::Percussion),
       1, 1536, 58, 0, 7, ChordType::Minor7);
    ArrangerEngine engine; Capture capture;
    assert(engine.installStyle(0, style));
    assert(engine.postChordControls(static_cast<int>(ChordRecognitionMode::FingeredThreeNotes), 3,
                                    true, false, false, 60, true));
    keys(engine, {43, 46, 50, 53}); assert(engine.post({CommandType::Play, 0})); capture.run(engine, 100);
    assert(engine.snapshot(0).chord.root == 7 && engine.snapshot(0).chord.type == ChordType::Minor7);
    assert(capture.starts(2).size() == 1 && capture.starts(2)[0].key == 55);
    assert(capture.starts(3).size() == 1 && capture.starts(3)[0].key == 74);
    assert(capture.starts(1).size() == 1 && capture.starts(1)[0].key == 58);
    capture.events.clear(); keys(engine, {43, 46, 50, 53}, false); keys(engine, {48, 52, 55}); capture.run(engine, 200000);
    assert((engine.snapshot(0).blockedTrackMask & (1U << 2)) == 0);
    assert(!capture.starts(2).empty());
    for(const auto& event:capture.starts(2))assert(event.key==60);
    assert(!capture.starts(1).empty());
    for(const auto& event:capture.starts(1))assert(event.key==64);
    for (const auto& event : capture.starts(3)) assert(event.key == 74);
}

void adaptiveHeldHarmonyAndMissingCv() {
    auto style=nativeStyle();
    auto& bass=pattern(*style,2,NativePatternMode::RecordedSourceOnly,TrackRole::Bass);
    auto& accompaniment=pattern(*style,3,NativePatternMode::RecordedSourceOnly,TrackRole::Accompaniment);
    auto& b=cv(bass,1,1536,48);auto& a=cv(accompaniment,1,1536,60);
    bass.chordCv[static_cast<std::size_t>(ChordType::Minor)]=6;
    accompaniment.chordCv[static_cast<std::size_t>(ChordType::Minor)]=0;
    b.events={{0,2,0x90,48,100},{1200,2,0x80,48,0}};
    a.events={{0,3,0x90,60,100},{0,3,0x90,64,100},{0,3,0x90,67,100},
              {1200,3,0x80,60,0},{1200,3,0x80,64,0},{1200,3,0x80,67,0}};
    ArrangerEngine engine;Capture capture;begin(engine,style);capture.run(engine,2000);
    assert(capture.starts(3).size()==3);
    capture.events.clear();keys(engine,{52},false);keys(engine,{51});capture.run(engine,2000);
    assert(engine.snapshot(0).chord.type==ChordType::Minor);
    assert(engine.snapshot(0).selectedCvs[3]==1&&engine.snapshot(0).selectedCvs[2]==1);
    const auto starts=capture.starts(3);assert(starts.size()==1&&starts[0].key==63);
    int offs=0;for(const auto& e:capture.events)if(e.track==3&&e.status==0x80){assert(e.key==64);++offs;}
    assert(offs==1&&capture.starts(2).empty());
    assert(engine.post({CommandType::SetMemoryMode,0,0,1}));capture.run(engine,1);
    assert(engine.lowerMemory()&&engine.memoryMode()==1);
    keys(engine,{48,51,55},false);capture.run(engine,1000);
    assert(!engine.snapshot(0).chord.valid());
    assert(engine.post({CommandType::SetMemoryMode,0,0,2}));keys(engine,{48,52,55});capture.run(engine,1000);
    keys(engine,{48,52,55},false);capture.run(engine,1000);
    assert(engine.lowerMemory()&&engine.snapshot(0).chord.type==ChordType::Major);
    assert(engine.post({CommandType::SetMemory,0,0,0}));capture.run(engine,1);
    assert(!engine.lowerMemory()&&!engine.snapshot(0).chord.valid());
}
void playableGuitarVoicings() {
    const int tuning[]={40,45,50,55,59,64};
    int tested=0;
    for(int type=0;type<25;++type){
        if(type==static_cast<int>(ChordType::None))continue;
        const auto mask=chordPitchClassMask(static_cast<ChordType>(type));
        for(int root=0;root<12;++root)for(int capo=0;capo<=12;++capo)for(int position=0;position<=5;++position){
            Chord chord{root,static_cast<ChordType>(type),root};
            const auto v=makeGuitarVoicing(chord,capo,position);
            int low=25,high=-1;unsigned covered=0;
            for(int string=0;string<6;++string)if(v.notes[string]>=0){
                const int fret=v.notes[string]-tuning[string];assert(fret>=capo&&fret<=24);
                const unsigned bit=1U<<((v.notes[string]-root+120)%12);assert(mask&bit);covered|=bit;
                low=std::min(low,fret);high=std::max(high,fret);
            }
            if(covered!=mask||high-low>4)std::fprintf(stderr,"invalid guitar type=%d root=%d capo=%d position=%d\n",type,root,capo,position);
            assert(covered==mask&&high-low<=4);++tested;
        }
    }
    std::printf("PASS %d physically bounded guitar root/type/capo/position combinations\n",tested);
}

void guitarCommandZonesAndProgression() {
    // Fixed six-note E-major voicing permits an independent check of all
    // 24 documented gesture keys, including individual string identities.
    const Chord e{4,ChordType::Major,4};
    GuitarVoicing v;v.notes={{40,47,52,56,59,64}};
    const GuitarPatternSettings settings{};const GuitarShape shape{};
    for(int key=24;key<48;++key){
        const auto s=makeGuitarStroke(key,100,e,settings,shape,v,false);
        if(key==42){assert(s.muteAll&&s.count==0);continue;}
        assert(s.count>0&&s.count<=6);
        for(int i=0;i<s.count;++i){const auto n=s.notes[i];assert(n.string>=0&&n.string<6&&n.pitch>=40&&n.pitch<=88);}
        if(key<36||key>=46){
            const bool up=key==26||key==27||key==31||key==32||key==35;
            const int count=(key>=32&&key<=35)||key==47?4:6;
            assert(s.count==count);
            for(int i=0;i<count;++i)assert(s.notes[i].string==(up?5-i:6-count+i));
        }
        if(key==25||key==27||key==28||key==30||key==32||key==34)assert(s.gateMs>0);
        else assert(s.gateMs<0);
        if(key==29||key==30||key==31)assert(s.spacingMs>10);
        if(key==36||key==38||key==40||key==41||key==43||key==45){
            const int str=key==36?0:key==38?1:key==40?2:key==41?3:key==43?4:5;
            assert(s.count==1&&s.notes[0].string==str&&s.notes[0].pitch==v.notes[str]);
        }
        if(key==37||key==39)assert(s.count==1&&s.notes[0].pitch%12==(key==37?4:11));
        if(key==44){assert(s.count==3);assert(s.notes[1].pitch-s.notes[0].pitch==7);assert(s.notes[2].pitch-s.notes[0].pitch==12);}
    }
    assert(makeGuitarStroke(46,100,e,settings,shape,v,true).notes[0].string==5);
    assert(makeGuitarStroke(47,100,e,settings,shape,v,true).notes[0].string==5);
    for(int velocity=1;velocity<=90;++velocity){GuitarShape g;assert(guitarShapeFromVelocity(velocity,g));assert(g.highString>=1&&g.lowString<=6&&g.highString<=g.lowString&&g.position==(velocity-1)%6);}
    GuitarShape g;assert(!guitarShapeFromVelocity(0,g)&&!guitarShapeFromVelocity(91,g));
    const auto imported=importKorgStyleBytes(nativeContainer(true,false,false,true));
    assert(imported&&imported.style->sections[static_cast<std::size_t>(Element::Var1)].patterns[3].pa5xGuitarProgression);
    // Pa5X velocity 16 means Minor (legacy 16 means Diminished). With a
    // live E major root, a C reference progression on C minor becomes E minor.
    auto style=nativeStyle();
    auto& guitar=pattern(*style,3,NativePatternMode::Guitar,TrackRole::Accompaniment);
    guitar.pa5xGuitarProgression=true;
    auto& phrase=cv(guitar,1,1536,24);phrase.sourceRootKnown=true;
    phrase.events={{0,3,0x90,0,16},{0,3,0x90,12,1},{0,3,0x90,24,100},
        {80,3,0x80,24,0},{100,3,0x90,64,100},{120,3,0x80,64,0},
        {140,3,0x90,100,100},{160,3,0x80,100,0},{180,3,0x90,42,100},
        {200,3,0x90,7,7},{200,3,0x90,37,100},{220,3,0x80,37,0}};
    auto& intro=style->sections[static_cast<std::size_t>(Element::Intro1)];intro=style->sections[static_cast<std::size_t>(Element::Var1)];
    // Ordinary ACC with the same MIDI note stays a normal musical note.
    auto& acc=intro.patterns[4];acc.present=true;acc.mode=NativePatternMode::RecordedSourceOnly;
    acc.chordCv[static_cast<std::size_t>(ChordType::Major)]=1;cv(acc,1,1536,24).sourceRootKnown=true;
    style->tracks[4].used=true;style->tracks[4].role=TrackRole::Accompaniment;
    ArrangerEngine engine;Capture capture;
    assert(engine.installStyle(0,style));
    assert(engine.postChordControls(static_cast<int>(ChordRecognitionMode::FingeredThreeNotes),3,true,false,false,60,true));
    keys(engine,{52,56,59});
    assert(engine.post({CommandType::SelectElement,0,static_cast<int>(Element::Intro1)}));
    assert(engine.post({CommandType::Play,0}));capture.run(engine,35000);
    bool minorThird=false,melody=false,rx=false,root=false;
    for(const auto& n:capture.starts(3)){
        assert(n.key>=40);
        if(n.sample<10000){const int pc=n.key%12;assert(pc==4||pc==7||pc==11);minorThird|=pc==7;}
        if(n.sample==12500)melody=true;
        if(n.sample==17500){assert(n.key==100);rx=true;}
        if(n.sample>=25000&&n.sample<27500&&n.key%12==11)root=true;
    }
    assert(minorThird&&melody&&rx&&root);
    assert(capture.starts(4).size()==1&&capture.starts(4)[0].key==28);
    std::puts("PASS 24 Guitar gesture keys, 90 C0 selectors, Pa5X progression, melody, RX and isolated ACC");
}

void soundRangePreservesPitchClass() {
    auto style = nativeStyle();
    auto& pitched = pattern(*style, 2, NativePatternMode::RecordedSourceOnly, TrackRole::Accompaniment);
    pitched.keyRangeEnabled = true; pitched.keyLow = 60; pitched.keyHigh = 71;
    auto& source = cv(pitched, 1, 1536, 48);
    source.events = {{0, 2, 0x90, 48, 100}, {0, 2, 0x90, 84, 100},
                     {1, 2, 0x80, 48, 0}, {2, 2, 0x80, 84, 0}};
    auto& drums = pattern(*style, 3, NativePatternMode::Drum, TrackRole::Drums);
    drums.keyRangeEnabled = true; drums.keyLow = 60; drums.keyHigh = 71;
    cv(drums, 1, 1536, 36);
    ArrangerEngine engine; Capture capture; begin(engine, style); capture.run(engine, 300);
    const auto starts = capture.starts(2);
    assert(starts.size() == 1 && starts[0].key == 60);
    int releases=0;
    for(const auto& event:capture.events)if(event.track==2 && event.status==0x80 && event.key==60){
        assert(event.sample==250); // 2 ticks at 384 PPQ, 60 BPM and 48 kHz
        ++releases;
    }
    assert(releases==1);
    assert(capture.starts(3).size() == 1 && capture.starts(3)[0].key == 36);

    auto narrow = nativeStyle();
    auto& limited = pattern(*narrow, 2, NativePatternMode::RecordedSourceOnly, TrackRole::Accompaniment);
    limited.keyRangeEnabled = true; limited.keyLow = 61; limited.keyHigh = 62;
    cv(limited, 1, 1536, 48); // no octave of C exists in C#..D
    ArrangerEngine noFit; Capture silent; begin(noFit, narrow); silent.run(noFit, 200);
    assert(silent.starts(2).empty());
    auto invalid = std::make_shared<Style>(*narrow);
    invalid->sections[static_cast<std::size_t>(Element::Var1)].patterns[2].keyLow = 63;
    ArrangerEngine reject; assert(!reject.installStyle(0, invalid));
}

void tempoLockSurvivesStyleLoad() {
    auto first = nativeStyle(); first->tempoBpm = 96.0;
    cv(pattern(*first, 0, NativePatternMode::Drum, TrackRole::Drums), 1, 1536, 36);
    ArrangerEngine engine; Capture capture; begin(engine, first); capture.run(engine, 1);
    assert(engine.snapshot(0).tempoBpm == 96.0);
    assert(engine.post({CommandType::SetTempoLock, 0, 0, 1.0}));
    assert(engine.post({CommandType::SetTempo, 0, 0, 111.0})); capture.run(engine, 1);
    assert(engine.tempoLock() && engine.snapshot(0).tempoBpm == 111.0 && engine.snapshot(1).tempoBpm == 111.0);
    auto second = nativeStyle(); second->tempoBpm = 137.0;
    cv(pattern(*second, 0, NativePatternMode::Drum, TrackRole::Drums), 1, 1536, 42);
    assert(engine.installStyle(1, std::make_shared<Style>(*second))); capture.run(engine, 1);
    assert(engine.snapshot(1).tempoBpm == 111.0);
    assert(engine.post({CommandType::SetTempoLock, 0, 0, 0.0})); capture.run(engine, 1);
    assert(!engine.tempoLock());
    assert(engine.installStyle(1, second)); capture.run(engine, 1);
    assert(engine.snapshot(1).tempoBpm == 137.0);
}

void realMultiCvFixture(const char* path) {
    const auto imported = importKorgStyleFile(path);
    assert(imported && imported.style->nativeKorg);
    const auto& var = imported.style->sections[static_cast<std::size_t>(Element::Var3)];
    assert(var.nativePatterns && imported.style->ppq == 384);
    // 001.Musi9_8 DEYNO: independent SMF tracks1/2/3, setup EOT1728.
    const auto& bass = var.patterns[2];
    assert(bass.cvs[0].available && bass.cvs[1].available && bass.cvs[2].available);
    assert(bass.cvs[0].lengthTicks == 27648 && bass.cvs[1].lengthTicks == 27648);
    assert(bass.cvs[2].lengthTicks == 13824);
    const auto& acc = imported.style->sections[static_cast<std::size_t>(Element::Var1)].patterns[6];
    assert(acc.cvs[0].available && !acc.cvs[1].available && !acc.cvs[2].available && acc.cvs[3].available);
    assert(acc.cvs[0].lengthTicks == 13824 && acc.cvs[3].lengthTicks == 13824);
}
} // namespace

int main(int argc, char** argv) {
    if (argc >= 2 && std::string(argv[1]) == "--write-fixture") {
        if (argc != 3) { std::fputs("Usage: --write-fixture PATH\n", stderr); return 2; }
        const auto fixture = nativeContainer(true);
        std::ofstream output(argv[2], std::ios::binary | std::ios::trunc);
        if (!output) { std::fputs("Cannot create STG fixture\n", stderr); return 1; }
        output.write(reinterpret_cast<const char*>(fixture.data()), static_cast<std::streamsize>(fixture.size()));
        output.close();
        return output ? 0 : 1;
    }
    converterPreservesRestSlotsAndAddresses(); converterUsesActualPatternRole();
    independentCvLoops(); independentCvRestoresRecordedMix(); introDurationUsesSelectedCv(); nativeIntroWithoutVariationStopsAtEnd();
    quarterTempoAndMeters(); tempoEventsAreSampleAccurate();
    cvSelectionPreservesPhaseAndMissingMeansSilence(); harmonicAdaptationAndPatternType(); adaptiveHeldHarmonyAndMissingCv(); playableGuitarVoicings(); guitarCommandZonesAndProgression(); soundRangePreservesPitchClass(); tempoLockSurvivesStyleLoad();
    if (argc == 2) realMultiCvFixture(argv[1]);
    std::puts("Korg style playback: PASS (independent CV loops, phase, empty CVs, source gates, meter/tempo, lock)");
    return 0;
}
