#include "silveton/arranger/Pa5xPcgIndex.h"

#include <cstdlib>
#include <iostream>
#include <set>
#include <string>
#include <tuple>
#include <vector>

using namespace silveton::arranger;
namespace {
void check(bool value, const char* message) {
    if (!value) { std::cerr << "FAIL " << message << '\n'; std::exit(1); }
}
void u16(std::vector<std::uint8_t>& b, unsigned value) {
    b.push_back(static_cast<std::uint8_t>(value >> 8U));
    b.push_back(static_cast<std::uint8_t>(value));
}
void u32(std::vector<std::uint8_t>& b, std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) b.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
void chunk(std::vector<std::uint8_t>& out, std::uint32_t tag, const std::vector<std::uint8_t>& payload) {
    u32(out, tag); u32(out, static_cast<std::uint32_t>(payload.size())); out.insert(out.end(), payload.begin(), payload.end());
}
std::vector<std::uint8_t> fixture(std::uint8_t bank = 0x0C, std::uint8_t major = 2, std::uint8_t minor = 0) {
    std::vector<std::uint8_t> fields;
    u16(fields, 3);
    u16(fields, 2); u16(fields, 28);
    const std::string name = "Z named sound";
    fields.insert(fields.end(), name.begin(), name.end()); fields.insert(fields.end(), 28 - name.size(), 0);
    u16(fields, 0); u16(fields, 3); fields.insert(fields.end(), {4, bank, 20});
    u16(fields, 1); u16(fields, 2); fields.insert(fields.end(), {major, minor});
    u32(fields, 0x12345678);
    std::vector<std::uint8_t> table; u16(table, static_cast<unsigned>(fields.size())); table.insert(table.end(), fields.begin(), fields.end());
    std::vector<std::uint8_t> children;
    chunk(children, 0x02000018, {11,0,0,0,0,0,0,'K','O','R','F',0});
    const auto directoryOffset = static_cast<std::uint32_t>(children.size() + 8);
    chunk(children, 0x05010018, table);
    const auto dataOffset = static_cast<std::uint32_t>(children.size() + 8);
    chunk(children, 0x10000038U | (static_cast<std::uint32_t>(major) << 16U) |
          (static_cast<std::uint32_t>(minor) << 8U), {'O','C','3','1'});
    std::vector<std::uint8_t> refs{'K','B','E','G'};
    u32(refs, directoryOffset); u32(refs, dataOffset);
    refs.insert(refs.end(), {'K','E','N','D'}); u32(refs, 2);
    chunk(children, 0xFE000018, refs);
    std::vector<std::uint8_t> file; chunk(file, 0x01000114, children); return file;
}
}

int main(int argc, char** argv) {
    const auto valid = fixture();
    auto index = inspectPa5xPcgBytes(valid, "SOUND/user03.pcg");
    check(index.valid && index.sounds.size() == 1, "structured KORF directory indexes");
    const auto* sound = findPa5xPcgSound(index, 121, 66, 20);
    check(sound && sound->name == "Z named sound", "original raw address selects exact sound");
    check(sound->rawProgram == 20 && sound->internalBank == 12 && sound->rawChecksum == 0x12345678,
          "raw program/bank/checksum are preserved");
    check(sound->payloadLength == 4 && sound->oc31Encoded && !sound->parametersDecoded,
          "encoded body is not reported as decoded synthesis");
    check(!findPa5xPcgSound(index, 121, 66, 21), "program index does not use display +1");
    index = inspectPa5xPcgBytes(fixture(13), "SOUND/user09.pcg");
    check(index.valid && !index.sounds[0].addressKnown, "unknown bank filename is not guessed or remapped");
    index = inspectPa5xPcgBytes(fixture(11), "SOUND/user02.pcg");
    check(index.valid && !index.sounds[0].addressKnown && index.sounds[0].kind == Pa5xPcgSoundKind::Unknown,
          "raw bank 0B without verified DrumKit context is never mapped as drums");
    index = inspectPa5xPcgBytes(valid);
    check(index.valid && !index.sounds[0].addressKnown, "missing bank context does not guess an external address");
    struct Bank { const char* name; std::uint8_t raw; int msb, lsb; std::size_t count; };
    const Bank banks[] = {
        {"USER01.PCG",0x09,121,64,128}, {"USER02.PCG",0x0A,121,65,128},
        {"USER03.PCG",0x0C,121,66,128}, {"USER04.PCG",0x0D,121,67,128},
        {"USER05.PCG",0x18,121,68,77}, {"USER06.PCG",0x19,121,69,106},
        {"USER07.PCG",0x1B,121,70,43}, {"USER08.PCG",0x1C,121,71,70},
        {"USERDK01.PCG",0x0B,120,64,128}, {"USERDK02.PCG",0x14,120,65,5},
        {"USERDK03.PCG",0x1A,120,66,21}
    };
    for (const auto& bank : banks) {
        index = inspectPa5xPcgBytes(fixture(bank.raw), std::string("SOUND/") + bank.name);
        const auto* mapped = findPa5xPcgSound(index, bank.msb, bank.lsb, 20);
        check(mapped != nullptr && mapped->internalBank == bank.raw, "canonical Pa5X bank resolves its exact original address");
        check(mapped->kind == (bank.msb == 120 ? Pa5xPcgSoundKind::DrumKit : Pa5xPcgSoundKind::Sound),
              "normal and Drum Kit namespaces do not collide");
        index = inspectPa5xPcgBytes(fixture(static_cast<std::uint8_t>(bank.raw ^ 0x40U)), bank.name);
        check(index.valid && !index.sounds[0].addressKnown, "canonical filename cannot override a mismatched raw bank");
        index = inspectPa5xPcgBytes(fixture(bank.raw), "SOUND/export.pcg");
        check(index.valid && !index.sounds[0].addressKnown, "renamed file never receives a guessed bank address");
        index = inspectPa5xPcgBytes(fixture(bank.raw), bank.raw == 0x09 ? "USER08.PCG" : "USER01.PCG");
        check(index.valid && !index.sounds[0].addressKnown, "rearranged bank files do not exchange external addresses");
    }
    index = inspectPa5xPcgBytes(fixture(0x0C, 9), "USER03.PCG");
    check(index.valid && !index.sounds[0].addressKnown, "unverified resource major version is retained without address publication");
    index = inspectPa5xPcgBytes(fixture(0x0C, 2, 1), "USER03.PCG");
    check(index.valid && !index.sounds[0].addressKnown, "unverified resource minor version is retained without address publication");
    for (std::size_t length = 0; length < valid.size(); ++length) {
        check(!inspectPa5xPcgBytes(std::vector<std::uint8_t>(valid.begin(), valid.begin() + static_cast<std::ptrdiff_t>(length))).valid,
              "all truncated fixtures fail closed");
    }
    auto bad = valid; bad[7] ^= 1;
    check(!inspectPa5xPcgBytes(bad).valid, "root length mismatch rejected");
    bad = valid; bad[37] = 0xFF;
    check(!inspectPa5xPcgBytes(bad).valid, "directory entry cannot escape table");
    bad = valid; bad[bad.size() - 13] ^= 1;
    check(!inspectPa5xPcgBytes(bad).valid, "cross-reference does not silently pair wrong object");
    check(!inspectPa5xPcgBytes({'2','-','4',' ','g','e','n','e','l',' ','1','0','0'}).valid,
          "name text alone is not a PCG sound index");

    if (argc == 3 && std::string(argv[1]) == "--uploaded") {
        std::set<std::tuple<int, int, int>> addresses;
        std::size_t normal = 0, drumCount = 0;
        for (const auto& bank : banks) {
            const auto corpus = inspectPa5xPcgFile(std::string(argv[2]) + "/" + bank.name);
            check(corpus.valid && corpus.sounds.size() == bank.count, "uploaded bank retains all exact directory records");
            for (const auto& item : corpus.sounds) {
                check(item.addressKnown && item.msb == bank.msb && item.lsb == bank.lsb && item.internalBank == bank.raw,
                      "all uploaded canonical bank records publish exact address context");
                check(addresses.insert({item.msb,item.lsb,item.rawProgram}).second, "all original external addresses remain unique");
                check(!item.parametersDecoded, "indexing does not pretend complete synthesis decode");
                if (item.kind == Pa5xPcgSoundKind::Sound) ++normal; else ++drumCount;
            }
        }
        check(normal == 808 && drumCount == 154 && addresses.size() == 962,
              "all 962 uploaded sound records survive without fixed-slot truncation");
        const auto selected = inspectPa5xPcgFile(std::string(argv[2]) + "/USER08.PCG");
        const auto* yayli = findPa5xPcgSound(selected, 121, 71, 7);
        check(yayli && yayli->name == "Yayli Tavir C", "uploaded flat KSC 121/71/7 joins exact User08 sound");
        std::cout << "Uploaded PCG: 808 normal + 154 Drum Kits; all 962 original addresses indexed\n";
    } else if (argc == 3) {
        const auto sounds = inspectPa5xPcgFile(argv[1]);
        const auto drums = inspectPa5xPcgFile(argv[2]);
        check(sounds.valid && sounds.sounds.size() == 104, "real user03 has 104 exact directory entries");
        check(drums.valid && drums.sounds.size() == 88, "real userdk01 has 88 exact directory entries");
        const auto* acc = findPa5xPcgSound(sounds, 121, 66, 20);
        const auto* drum = findPa5xPcgSound(drums, 120, 64, 121);
        check(acc && acc->name == "2-4 genel 100", "real Style 121/66/20 resolves to 2-4 genel 100");
        check(drum && drum->name == "Session kit 4x", "real Style 120/64/121 resolves to Session kit 4x");
        check(sounds.sounds[1].rawProgram == 2, "non-alphabetical original positions are retained");
    }
    std::cout << "PASS Pa5X PCG exact directory, original addresses, object bounds and unsupported-body status\n";
}
