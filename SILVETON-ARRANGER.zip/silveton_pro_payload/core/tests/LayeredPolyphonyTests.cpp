#include "silveton/sampler/SamplerEngine.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>
using namespace silveton::sampler;
namespace {
std::shared_ptr<EngineState> layered(int simultaneous, bool singleLow=true) {
    auto p=std::make_shared<Program>(); p->name="Layered velocity test";
    for(int i=0;i<simultaneous+(singleLow?1:0);++i){
        auto sample=std::make_shared<SampleData>(); sample->name="OSC "+std::to_string(i+1);
        sample->sampleRate=48000; sample->channels=1; sample->rootKey=60; sample->totalFrames=4800;
        sample->interleaved.resize(4800);
        for(int f=0;f<4800;++f)sample->interleaved[f]=.025F*std::sin(6.283185307179586*(i+2)*f/480.0);
        sample->loop.enabled=true; sample->loop.startFrame=480; sample->loop.endFrame=4320;
        auto ms=std::make_shared<Multisample>(); SampleZone z{};z.sample=sample;z.rootKey=60;ms->zones.push_back(z);
        ProgramLayer l{};l.multisample=ms;l.filter.mode=FilterMode::Bypass;l.ampEnvelope={.005F,0,1,.01F};
        if(singleLow){l.velocityLow=i==0?1:64;l.velocityHigh=i==0?63:127;}
        p->layers.push_back(l);
    }
    auto st=std::make_shared<EngineState>(); auto& u=st->combi.uppers[0];u.program=p;u.enabled=true;u.midiChannel=0;u.breathEnabled=false;
    st->global.limiterEnabled=false;st->global.masterGainDb=0;return st;
}
void render(SamplerEngine& e,int n=1){std::vector<float> out(192); for(int i=0;i<n;++i){e.render(out.data(),96);for(auto v:out)assert(std::isfinite(v));}}
void on(SamplerEngine& e,int k,int v){assert(e.postNoteOn(0,k,v));}
void off(SamplerEngine& e,int k){assert(e.postNoteOff(0,k));}
void expect(SamplerEngine& e,unsigned n,const char* label){const auto got=e.activeVoiceCount();std::printf("%s: expected %u, got %u\n",label,n,got);std::fflush(stdout);assert(got==n);}
void incomingLayers(){SamplerEngine e;e.prepare(48000,96);e.setState(layered(4));e.setVoiceCeiling(8);
    for(int k=40;k<48;++k)on(e,k,45);render(e,30);expect(e,8,"eight old voices");
    on(e,60,110);render(e,30);for(int k=40;k<48;++k)off(e,k);render(e,30);expect(e,4,"all incoming oscillators survive");
    off(e,60);render(e,30);expect(e,0,"release all new oscillators");
}
void wholeOlderAttack(){SamplerEngine e;e.prepare(48000,96);e.setState(layered(4));e.setVoiceCeiling(8);
    on(e,55,110);on(e,57,110);render(e,30);expect(e,8,"two complete four-layer notes");
    on(e,60,45);render(e,30);expect(e,5,"one complete old note and new single layer");
    off(e,55);off(e,57);off(e,60);render(e,30);expect(e,0,"no stuck voices");
}
void velocityAndDamper(){SamplerEngine e;e.prepare(48000,96);e.setState(layered(12));e.setVoiceCeiling(128);
    on(e,60,63);render(e,20);expect(e,1,"velocity below split");off(e,60);render(e,30);expect(e,0,"low velocity release");
    assert(e.postControlChange(0,64,127));for(int k=60;k<68;++k){on(e,k,64);off(e,k);}render(e,30);expect(e,96,"96 legitimate layered oscillators under sustain");
    assert(e.postControlChange(0,64,0));render(e,30);expect(e,0,"damper releases all 96 oscillators");
}
void realCapacity(){SamplerEngine e;e.prepare(48000,96);e.setState(layered(12));e.setVoiceCeiling(kMaxVoices);
    for(int k=40;k<50;++k){on(e,k,100);render(e,4);}expect(e,120,"ten complete twelve-layer attacks");
    on(e,60,110);render(e,20);expect(e,120,"twelve-layer takeover at real capacity");
    for(int k=40;k<50;++k)off(e,k);render(e,40);expect(e,12,"new twelve-layer note stays complete");
    off(e,60);render(e,40);expect(e,0,"real-capacity release");
}
}
int main(){incomingLayers();wholeOlderAttack();velocityAndDamper();realCapacity();std::puts("PASS layered polyphony");}
