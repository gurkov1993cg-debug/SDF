#include "silveton/arranger/Pa5xPerformanceIndex.h"
#include "silveton/sampler/FsCompat.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <dirent.h>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton::arranger;
namespace fs = silveton::fsx;
namespace {
void check(bool value,const char* message){if(!value){std::cerr<<"FAIL "<<message<<'\n';std::exit(1);}}
void be32(std::vector<std::uint8_t>& bytes,std::size_t value){
    for(int shift=24;shift>=0;shift-=8)bytes.push_back(static_cast<std::uint8_t>(value>>static_cast<unsigned>(shift)));
}
void text(std::vector<std::uint8_t>& bytes,const std::string& value){bytes.insert(bytes.end(),value.begin(),value.end());}
std::vector<std::uint8_t> midi(int program=10,bool banks=true){
    std::vector<std::uint8_t> events;
    if(banks)events={0,0xB0,0,121,0,0xB0,32,66};
    const std::uint8_t tail[]{0,0xC0,static_cast<std::uint8_t>(program),0,0xB0,7,93,0,0xB0,10,72,0,0xB0,11,112,0,0xFF,0x2F,0};
    events.insert(events.end(),std::begin(tail),std::end(tail));
    std::vector<std::uint8_t> out{'M','T','h','d',0,0,0,6,0,0,0,1,1,128,'M','T','r','k'};
    be32(out,events.size());out.insert(out.end(),events.begin(),events.end());return out;
}
void leaf(std::vector<std::uint8_t>& bytes,const std::string& name,const std::vector<std::uint8_t>& payload){
    text(bytes,"Leaf");bytes.push_back(0);text(bytes,name);bytes.push_back(0);be32(bytes,payload.size());
    bytes.insert(bytes.end(),payload.begin(),payload.end());
}
std::vector<std::uint8_t> root(const std::vector<std::uint8_t>& content){
    std::vector<std::uint8_t> out{'R','o','o','t',0,1,0};be32(out,content.size());out.insert(out.end(),content.begin(),content.end());return out;
}
std::vector<std::uint8_t> keyboard(const std::string& revision="1",bool banks=true,int highKey=108,bool duplicate=false){
    std::vector<std::uint8_t> content;
    const char* names[]{"Lower.mid","Upper1.mid","Upper2.mid","Upper3.mid"};
    for(int i=0;i<4;++i)leaf(content,names[i],midi(10+i,banks));
    if(duplicate)leaf(content,names[0],midi());
    std::string xml="<CLIP type=\"KeyboardSetClip\" subtype=\"4\" version=\""+revision+"\" release=\"0\">"
        "<RESOURCE track1=\"Lower.mid\" track2=\"Upper1.mid\" track3=\"Upper2.mid\" track4=\"Upper3.mid\"/>"
        "<PARAMS><Lower use=\"1\"/>";
    for(int i=1;i<=4;++i)xml+="<Track"+std::to_string(i)+"Params mute=\""+(i==1?"1":"0")+"\" keyrangelow=\"21\" keyrangehigh=\""+
        std::to_string(highKey)+"\" dynamicrangelow=\"1\" dynamicrangehigh=\"127\" trackroute=\"1\" actuator=\"49415\"/>";
    xml+="<KeyboardProcessing splitpoint=\"57\" globalsplit=\"0\" chordscanning=\"4\" keyboardmode=\"2\" upperoctavetranspose=\"-1\"/>"
         "</PARAMS></CLIP>";
    leaf(content,"ClipDescription.xml",std::vector<std::uint8_t>(xml.begin(),xml.end()));return root(content);
}
std::vector<std::uint8_t> pad(){
    std::vector<std::uint8_t> content;leaf(content,"Main.mid",midi());
    const std::string xml="<CLIP type=\"PadClip\" version=\"0\" release=\"4\"><RESOURCE name=\"Main.mid\"/><PARAMS>"
        "<Pattern type=\"Accompaniment\"/><NTT value=\"1\"/><NTR value=\"0\"/><ReTrigger mode=\"2\"/>"
        "<KeyLow value=\"21\"/><KeyHigh value=\"108\"/><WrapAroundDegree value=\"8\"/><Loop number=\"-1\" length=\"-1\"/>"
        "<Pitch transposition=\"0\"/><ORIGINAL_CHORD><CV1 root=\"D\" chord=\"Min7\"/><CV2 root=\"C\" chord=\"Maj\"/></ORIGINAL_CHORD>"
        "<CHORD_TABLE><Maj cv=\"2\"/><Min cv=\"1\"/></CHORD_TABLE></PARAMS></CLIP>";
    leaf(content,"ClipDescription.xml",std::vector<std::uint8_t>(xml.begin(),xml.end()));return root(content);
}
void corpus(const fs::path& directory,std::size_t& keyboardCount,std::size_t& padCount,std::size_t& patchCount){
    DIR* handle=::opendir(directory.c_str());check(handle!=nullptr,"reference folder opens");
    std::vector<std::string> names;
    while(const auto* entry=::readdir(handle)){const std::string name=entry->d_name;if(name!="."&&name!="..")names.push_back(name);}
    ::closedir(handle);
    for(const auto& name:names){const auto entry=directory/name;
        if(fs::is_directory(entry)){corpus(entry,keyboardCount,padCount,patchCount);continue;}
        auto extension=entry.extension().string();
        std::transform(extension.begin(),extension.end(),extension.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
        if(extension!=".ksc"&&extension!=".pdc")continue;
        const auto result=inspectPa5xPerformanceFile(entry.string());
        if(!result.valid){std::cerr<<entry.string()<<": "<<result.error<<'\n';check(false,"real performance resource indexes");}
        check(!result.playable,"real performance index never declares full playback");
        if(result.kind==Pa5xPerformanceKind::KeyboardSet){++keyboardCount;check(result.parts.size()==4,"four exact Keyboard Set roles");}
        else{++padCount;check(result.parts.size()==1,"one Pad track");}
        for(const auto& part:result.parts)for(const auto& patch:part.patches){++patchCount;check(patch.addressComplete,"real patch address is complete");}
    }
}
}

int main(int argc,char** argv){
    check(!inspectPa5xPerformanceBytes({}).valid,"empty file rejected");
    auto bytes=keyboard();
    auto result=inspectPa5xPerformanceBytes(bytes,"/set/KEYBOARDSET/007.Unit Test.ksc");
    check(result.valid&&result.kind==Pa5xPerformanceKind::KeyboardSet&&!result.playable,"supported direct Keyboard Set is metadata only");
    check(result.filenameOrdinal==7&&result.displayName=="Unit Test"&&!result.stableResourceIdKnown,"filename position is not an invented Sound ID");
    check(result.parts.size()==4&&result.parts[0].name=="Lower"&&result.parts[3].name=="Upper3","part roles retain Korg order");
    check(result.splitPoint==57&&result.useGlobalSplit==0&&result.upperOctaveDeclared&&result.upperOctaveTransposeRaw==-1,"keyboard split and octave metadata exact");
    check(result.parts[0].mute==1&&result.parts[1].mute==0&&result.parts[0].keyLow==21&&result.parts[0].keyHigh==108,"mute and key ranges preserved");
    check(result.parts[0].velocityLow==1&&result.parts[0].velocityHigh==127,"velocity range remains independent of key range");
    const auto& patch=result.parts[0].patches[0];
    check(patch.msb==121&&patch.lsb==66&&patch.program==10&&patch.addressComplete,"raw patch is not renumbered");
    const auto& channel=result.parts[0].channels[0];
    check(channel.volumeRaw==93&&channel.panRaw==72&&channel.expressionRaw==112,"explicit MIDI controller settings preserved");
    result=inspectPa5xPerformanceBytes(keyboard("1",false));
    check(result.valid&&!result.parts[0].patches[0].addressComplete&&result.parts[0].patches[0].msb==-1,"absent bank declarations remain unknown");
    check(!inspectPa5xPerformanceBytes(keyboard("2")).valid,"unknown Keyboard Set revision rejected");
    check(!inspectPa5xPerformanceBytes(keyboard("1",true,128)).valid,"out-of-range keys rejected");
    check(!inspectPa5xPerformanceBytes(keyboard("1",true,108,true)).valid,"duplicate resource paths rejected");
    for(std::size_t size=0;size<bytes.size();size+=31){const std::vector<std::uint8_t> truncated(bytes.begin(),bytes.begin()+static_cast<std::ptrdiff_t>(size));check(!inspectPa5xPerformanceBytes(truncated).valid,"container truncations rejected");}
    result=inspectPa5xPerformanceBytes(pad());
    check(result.valid&&result.kind==Pa5xPerformanceKind::Pad&&result.parts.size()==1&&!result.playable,"Pad indexes without playback substitution");
    const auto& p=result.parts[0];
    check(p.patternType=="Accompaniment"&&p.ntt==1&&p.ntr==0&&p.retrigger==2&&p.wrapAroundDegree==8,"Pad numeric rules stay raw");
    check(p.cvSources.size()==2&&p.cvSources[0].root=="D"&&p.cvSources[0].chord=="Min7"&&p.chordSelections.size()==2,"per-CV original chords and selection table preserved");
    if(argc==2){std::size_t keyboards=0,pads=0,patches=0;corpus(argv[1],keyboards,pads,patches);check(keyboards==772&&pads==110&&patches==3198,"complete uploaded corpus coverage");std::cout<<"Corpus: "<<keyboards<<" Keyboard Sets, "<<pads<<" Pads, "<<patches<<" exact patch selections\n";}
    std::cout<<"Pa5X performance index: PASS (KSC/PDC structure, raw addresses, settings, CV metadata, bounds)\n";
}
