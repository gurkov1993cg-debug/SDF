#include "silveton/arranger/Pa5xCatalogSnapshot.h"
#include "silveton/arranger/PaStyleBank.h"
#include "silveton/sampler/SvBankFormat.h"
#include "../src/arranger/Pa5xSnapshotArchive.h"
#include "fixtures/PaSeriesBankFixtures.h"
#include <cstring>
#include <filesystem>

using namespace silveton::arranger;
using namespace silveton::test::pa_series;
namespace silveton::arranger {
void archiveFields(snapshot::Archive&,Pa5xKstIndex&);
void archiveFields(snapshot::Archive&,Pa5xKstCatalog&);
}
namespace {
Bytes readBytes(const std::string& path){std::ifstream f(path,std::ios::binary);return Bytes((std::istreambuf_iterator<char>(f)),{});}
void checksum(Bytes& bytes){check(bytes.size()>=64,"snapshot envelope exists");const auto hash=silveton::sampler::sha256(bytes.data()+64,bytes.size()-64);std::copy(hash.begin(),hash.end(),bytes.begin()+32);}
std::size_t unique(const Bytes& haystack,const Bytes& needle){
    const auto p=std::search(haystack.begin(),haystack.end(),needle.begin(),needle.end());
    check(p!=haystack.end(),"original native payload is present in snapshot");
    check(std::search(p+1,haystack.end(),needle.begin(),needle.end())==haystack.end(),"native payload fixture is unambiguous");
    return static_cast<std::size_t>(p-haystack.begin());
}
void currentAndLegacyRoundTrip(){
    File original;original.write(bank(keyboard(0x09010108U)));
    auto inspected=readPaKeyboardLocation(original.path+"!/17");check(inspected.valid,"source fixture is a valid native keyboard");
    Pa5xKstIndex index;index.recognized=true;index.rootPath=std::filesystem::path(original.path).parent_path().string();index.name="Authored source";
    Pa5xKstCatalog catalog;catalog.recognized=true;catalog.rootPath=index.rootPath;catalog.name=index.name;
    Pa5xCatalogKeyboardSet entry;entry.name=inspected.displayName;entry.path=original.path+"!/17";entry.relativePath="USER02.PRF!/17";
    entry.metadataSupported=true;entry.parts=inspected.parts;catalog.keyboardSets.push_back(entry);
    // Derived fields are intentionally inconsistent. A persistent snapshot
    // must reconstruct them from the original tag and bytes on restore.
    auto altered=std::make_shared<PaSeriesTrackSettings>(*entry.parts[0].sourceNativeTrack);
    altered->detuneCents=777;altered->octaveTranspose=99;altered->masterFxSendRaw[0]=255;
    catalog.keyboardSets[0].parts[0].sourceNativeTrack=altered;
    File snapshotFile("catalog.cache");check(savePa5xCatalogSnapshot(snapshotFile.path,index,catalog),"current catalog with native source records saves");
    const auto saved=readBytes(snapshotFile.path);Pa5xKstIndex loadedIndex;Pa5xKstCatalog loaded;bool styleUpgrade=true,nativeUpgrade=true;
    check(loadPa5xCatalogSnapshot(snapshotFile.path,loadedIndex,loaded,&styleUpgrade,&nativeUpgrade)&&!styleUpgrade&&!nativeUpgrade,
          "CAT3 restores without a missing-native-metadata upgrade");
    check(loaded.keyboardSets.size()==1&&loaded.keyboardSets[0].parts.size()==4,"catalog order and all original roles survive");
    for(std::size_t i=0;i<4;++i){const auto& native=loaded.keyboardSets[0].parts[i].sourceNativeTrack;
        check(native&&native->structurallyValid&&native->tag==0x09010108U&&native->trackIndex==i&&native->originalRecord==track(0x09010108U,static_cast<unsigned>(i)),
              "native tag, body and role survive byte-exact snapshot roundtrip");}
    check(loaded.keyboardSets[0].parts[0].sourceNativeTrack->detuneCents==-64&&
          loaded.keyboardSets[0].parts[0].sourceNativeTrack->octaveTranspose==-3&&
          loaded.keyboardSets[0].parts[0].sourceNativeTrack->masterFxSendRaw[0]==0,
          "derived values are revalidated instead of trusting serialized helper state");

    const auto nativeAt=unique(saved,track(0x09010108U,0));
    const auto rejectAtomic=[&](Bytes bytes,const char* why){checksum(bytes);snapshotFile.write(bytes);
        Pa5xKstIndex untouchedIndex;untouchedIndex.rootPath="untouched";Pa5xKstCatalog untouched;untouched.name="untouched";
        check(!loadPa5xCatalogSnapshot(snapshotFile.path,untouchedIndex,untouched),why);
        check(untouchedIndex.rootPath=="untouched"&&untouched.name=="untouched","failed snapshot does not publish partial metadata");};
    auto wrongRole=saved;wrongRole[nativeAt+3]=3;rejectAtomic(std::move(wrongRole),"native body cannot change its appendix-bound part role");
    auto excessive=saved;const std::uint32_t invalidSize=kMaximumPaSeriesTrackRecordBytes+1U;
    std::memcpy(excessive.data()+nativeAt-4U,&invalidSize,sizeof(invalidSize));rejectAtomic(std::move(excessive),"native record allocation bound is enforced during restore");
    auto wrongPath=saved;const Bytes identity(entry.path.begin(),entry.path.end());
    const auto pathAt=std::find_end(wrongPath.begin(),wrongPath.end(),identity.begin(),identity.end());
    check(pathAt!=wrongPath.end(),"path-bound native appendix exists");*pathAt=static_cast<std::uint8_t>(*pathAt=='/'?'X':'/');
    rejectAtomic(std::move(wrongPath),"native appendix is bound to the exact original Keyboard Set path");

    auto future=saved;const std::uint32_t futureTag=0x09020008U;
    std::memcpy(future.data()+nativeAt-8U,&futureTag,sizeof(futureTag));checksum(future);snapshotFile.write(future);
    check(loadPa5xCatalogSnapshot(snapshotFile.path,loadedIndex,loaded),"unknown native record can remain available as bounded original metadata");
    const auto& unknown=loaded.keyboardSets[0].parts[0].sourceNativeTrack;
    check(unknown&&!unknown->recognized&&!unknown->structurallyValid&&!unknown->detuneKnown,
          "future native record does not regain old decoder semantics on warm reload");
    inspected.parts=loaded.keyboardSets[0].parts;
    check(!readPa5xKeyboardSet(inspected).parts[0].recallSetupValid,"opaque future record remains unusable during actual recall");

    for(unsigned version:{1U,2U}){
        snapshot::Archive legacy;auto legacyIndex=index;auto legacyCatalog=catalog;legacy(legacyIndex,legacyCatalog);
        if(version==2U){std::uint32_t schema=1;std::uint64_t styles=0;legacy(schema,styles);}
        check(legacy.writeFile(snapshotFile.path,version==1U?"SILVCAT1":"SILVCAT2"),"legacy envelope fixture saves");
        styleUpgrade=false;nativeUpgrade=false;
        check(loadPa5xCatalogSnapshot(snapshotFile.path,loadedIndex,loaded,&styleUpgrade,&nativeUpgrade)&&nativeUpgrade,
              "both prior catalog generations request missing native mixer metadata refresh");
        check(styleUpgrade==(version==1U),"legacy Style metadata upgrade remains independent of native keyboard refresh");
        check(!loaded.keyboardSets[0].parts[0].sourceNativeTrack,"older snapshots never manufacture native zero controls");
    }
}
}
int main(){currentAndLegacyRoundTrip();std::cout<<"Native Pa CAT3 provenance and compatibility tests passed\n";}
