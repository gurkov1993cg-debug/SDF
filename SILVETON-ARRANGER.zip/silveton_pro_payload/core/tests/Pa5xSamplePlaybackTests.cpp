#include "silveton/arranger/Pa5xSampleIndex.h"

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <string>
#include <utility>

using namespace silveton::arranger;

namespace {

std::pair<Pa5xSampleObject, Pa5xKmpSample> fixture() {
    Pa5xSampleObject object;
    object.hasId = true; object.resourceId = 17; object.audioMetadataDecoded = true;
    object.channelTag = 1; object.sampleFormat = 16; object.sampleRate = 48000;
    object.encodedSampleCount = 10; object.loopStart = 3;
    object.endPositionRaw = object.secondaryEndPositionRaw = 8;
    object.rawAudioHeaderWords[8] = 3;
    object.rawAudioHeaderWords[9] = object.rawAudioHeaderWords[11] = 8;
    Pa5xKmpSample sample;
    sample.resourceId = 17; sample.sampleRate = 48000; sample.originalNote = 60;
    sample.packedData = 0x50; // Extended-ID linear sample, interpolation code2.
    return {object, sample};
}

bool mentions(const Pa5xSamplePlaybackMetadata& metadata, const std::string& text) {
    return std::any_of(metadata.uncertainties.begin(), metadata.uncertainties.end(),
                       [&](const std::string& line) { return line.find(text) != std::string::npos; });
}

void endpoints() {
    auto pair = fixture(); auto& object = pair.first; auto& sample = pair.second;
    const auto unknown = inspectPa5xSamplePlayback(object, sample);
    assert(!unknown && !unknown.error.empty() && unknown.flagsDecoded);
    const auto inclusive = inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex);
    assert(inclusive && inclusive.sampleStartFrame == 0 && inclusive.sampleEndFrame == 9);
    assert(inclusive.loopEnabled && inclusive.loopStartFrame == 3 && inclusive.loopEndFrame == 9);
    const auto exclusive = inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::ExclusiveBoundary);
    assert(exclusive && exclusive.sampleEndFrame == 8 && exclusive.loopEndFrame == 8);
    object.endPositionRaw = object.secondaryEndPositionRaw = 10;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    const auto sentinel = inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndexOrCountBoundary);
    assert(sentinel && sentinel.sampleEndFrame == 10 && mentions(sentinel, "empirical"));
    object.endPositionRaw = 11;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndexOrCountBoundary));
    object.endPositionRaw = 0;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::ExclusiveBoundary));
    object.endPositionRaw = 2; object.loopStart = 3;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
}

void flagsAndRoot() {
    auto pair = fixture(); auto& object = pair.first; auto& sample = pair.second;
    // Published packedData bits are independent of the chosen end convention.
    sample.packedData = 0xED0; // reverse, loop-off/one-shot, +12dB, no streaming.
    const auto converted = inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex);
    assert(converted && converted.reverse && converted.oneShotFlag && !converted.loopEnabled);
    assert(converted.twelveDbBoost && converted.gainDb == 12.0F && converted.doNotStream);
    assert(!converted.useLoopPitch && converted.storedSampleType == 0 && converted.interpolationMode == 2);
    assert(converted.rootKeyKnown && converted.rootKey == 60);
    sample.packedData = 0x150;
    const auto loopPitch = inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex);
    assert(loopPitch && loopPitch.useLoopPitch && mentions(loopPitch, "pitch correction"));
    sample.originalNote = 255;
    const auto missingRoot = inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex);
    assert(missingRoot && !missingRoot.rootKeyKnown && mentions(missingRoot, "zone root"));
    sample.originalNote = 128;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex).rootKeyKnown);
    object.secondaryEndPositionRaw = 7;
    assert(mentions(inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex), "secondary field"));
    object.sampleFormat = 128; sample.packedData = 0x52;
    assert(inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex).storedSampleType == 2);
}

void mismatchesAndOpaqueParameters() {
    const auto valid = fixture();
    auto object = valid.first; auto sample = valid.second;
    object.resourceId = 18;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    object = valid.first; sample.sampleRate = 44100;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    sample = valid.second; object.encrypted = true;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    object = valid.first; object.channelTag = 2;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    object = valid.first; object.encodedSampleCount = 0;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    object = valid.first; sample.packedData = 0x1050;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    sample.packedData = 0x40; // Absent extended-ID bit.
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    sample.packedData = 0x52; // Predictive KMP type contradicts linear PCM.
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    sample = valid.second; object.rawAudioHeaderWords[0] = 1;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
    object = valid.first; object.rawAudioHeaderWords[10] = 1;
    assert(!inspectPa5xSamplePlayback(object, sample, Pa5xSampleEndConvention::InclusiveIndex));
}

void corpusMetadata(const Pa5xSampleIndex& pcm, const Pa5xSampleIndex& kmp,
                    std::size_t expectedOrdinary, std::size_t expectedLoops) {
    assert(pcm.valid && kmp.valid && kmp.multisampleMappingDecoded);
    std::size_t ordinary = 0, loops = 0;
    for (const auto& object : pcm.objects) {
        if (object.encrypted) continue;
        const auto sample = std::find_if(kmp.samples.begin(), kmp.samples.end(),
            [&](const Pa5xKmpSample& candidate) { return candidate.resourceId == object.resourceId; });
        assert(sample != kmp.samples.end());
        assert(object.rawAudioHeaderWords[8] == object.loopStart);
        assert(object.rawAudioHeaderWords[9] == object.endPositionRaw);
        assert(object.rawAudioHeaderWords[11] == object.secondaryEndPositionRaw);
        const auto playback = inspectPa5xSamplePlayback(object, *sample,
            Pa5xSampleEndConvention::InclusiveIndexOrCountBoundary);
        assert(playback && playback.sampleEndFrame <= object.encodedSampleCount);
        assert(mentions(playback, "empirical"));
        if (playback.loopEnabled) {
            ++loops;
            assert(playback.loopStartFrame > 0 && playback.loopStartFrame < playback.loopEndFrame);
        } else assert(object.loopStart == 0);
        ++ordinary;
    }
    assert(ordinary == expectedOrdinary && loops == expectedLoops);
}

}

int main(int argc, char** argv) {
    endpoints(); flagsAndRoot(); mismatchesAndOpaqueParameters();
    if (argc == 4) {
        const std::string oldRoot = argv[1];
        const auto oldKmp = inspectPa5xSampleFile(oldRoot + "/ram.kmp");
        Pa5xSampleIndex oldPcm; oldPcm.valid = true;
        for (int bank = 1; bank <= 5; ++bank) {
            const auto parsed = inspectPa5xSampleFile(oldRoot + "/ram0" + std::to_string(bank) + ".pcm");
            assert(parsed.valid);
            oldPcm.objects.insert(oldPcm.objects.end(), parsed.objects.begin(), parsed.objects.end());
        }
        corpusMetadata(oldPcm, oldKmp, 514, 114);
        corpusMetadata(inspectPa5xSampleFile(argv[3]), inspectPa5xSampleFile(argv[2]), 93, 35);
        std::cout << "Real playback metadata: 514 old + 93 new ordinary samples, 149 explicit loop conversions\n";
    }
    std::puts("Pa5X playback metadata: flags, explicit endpoint policies, raw-root uncertainty and mismatch guards passed");
}
