#include "silveton/arranger/Pa5xPredictiveDecoder.h"

#include <array>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <utility>
#include <vector>

using namespace silveton::arranger;

namespace {

// Golden outputs were measured using the unmodified public KORG-Tools decoder
// (src/PCMFormat/Compression.cpp, Git blob
// cca616e22ee5aaa9568bec5e012fd9dbe38ccfcf), built as a separate executable.
// These generated numerical fingerprints contain no reference source, lookup
// table, user samples or external test dependency. Hash byte order is explicitly
// little endian regardless of the host running the tests.
std::uint64_t fingerprint(const std::vector<std::int16_t>& samples) {
    std::uint64_t hash = UINT64_C(14695981039346656037);
    for (const auto sample : samples) {
        const auto raw = static_cast<std::uint16_t>(sample);
        hash = (hash ^ (raw & 255U)) * UINT64_C(1099511628211);
        hash = (hash ^ (raw >> 8U)) * UINT64_C(1099511628211);
    }
    return hash;
}

void expectFailure(const Pa5xPredictiveAudio& result) {
    assert(!result);
    assert(!result.error.empty());
    assert(result.samples.empty());
}

void residualCodes() {
    std::array<std::uint8_t, 256> encoded{};
    for (std::size_t index = 0; index < encoded.size(); ++index)
        encoded[index] = static_cast<std::uint8_t>(index);
    const auto result = decodePa5xPredictive(encoded.data(), encoded.size(), encoded.size(), 0, 0);
    assert(result && result.samples.size() == encoded.size());
    assert(fingerprint(result.samples) == UINT64_C(0xD8E7C47CFD591823));
    assert(result.samples[0] == 0 && result.samples[1] == 5);
    assert(result.samples[128] == -32767); // The model excludes -32768.
    assert(result.samples[255] == -5);     // Stored residual bytes are signed.

    // At zero feedback the exceptional |code|=124 rounding is partly hidden by
    // PCM16 quantization. Its slowly decaying tails make that behavior visible.
    std::vector<std::uint8_t> tail(1024, 0);
    tail[0] = 124;
    const auto positive = decodePa5xPredictive(tail.data(), tail.size(), tail.size(), 16383, 0);
    assert(positive && fingerprint(positive.samples) == UINT64_C(0x25EC8B7BF7BF8CA7));
    tail[0] = 132; // signed -124
    const auto negative = decodePa5xPredictive(tail.data(), tail.size(), tail.size(), 16383, 0);
    assert(negative && fingerprint(negative.samples) == UINT64_C(0x2965F274E8F420B0));
}

void feedbackAndSaturation() {
    const std::array<std::uint8_t, 10> encoded{{127, 127, 0, 0, 0, 128, 0, 0, 0, 0}};
    const std::vector<std::int16_t> expected{
        31373, 32767, 23529, 11764, 5882, -29826, -14913, -7456, -3728, -1864};
    const auto result = decodePa5xPredictive(encoded.data(), encoded.size(), encoded.size(), 8192, 0);
    assert(result && result.samples == expected);
    // The third sample differs if clipping or PCM16 rounding is fed back.

    const std::array<std::uint8_t, 10> impulse{{1, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
    const auto repeatedPole = decodePa5xPredictive(impulse.data(), impulse.size(), impulse.size(), 16384, -4096);
    assert(repeatedPole && repeatedPole.samples ==
           std::vector<std::int16_t>({5, 5, 4, 2, 1, 1, 0, 0, 0, 0}));

    // A reproducible mixture exercises both feedback terms and all residual
    // magnitudes without relying on any uploaded bank or reference executable.
    std::vector<std::uint8_t> mixed(4096);
    std::uint32_t state = UINT32_C(0x51624BB3);
    for (auto& code : mixed) {
        state = state * UINT32_C(1664525) + UINT32_C(1013904223);
        code = static_cast<std::uint8_t>(state >> 24U);
    }
    const auto sequence = decodePa5xPredictive(mixed.data(), mixed.size(), mixed.size(), 23000, -10000);
    assert(sequence && fingerprint(sequence.samples) == UINT64_C(0xCC419AD6FA66223D));
}

void boundsAndUnsupportedPredictors() {
    const std::array<std::uint8_t, 4> input{{1, 0, 0, 0}};
    expectFailure(decodePa5xPredictive(nullptr, input.size(), input.size(), 0, 0));
    expectFailure(decodePa5xPredictive(input.data(), 0, 0, 0, 0));
    expectFailure(decodePa5xPredictive(input.data(), input.size() - 1, input.size(), 0, 0));
    expectFailure(decodePa5xPredictive(input.data(), input.size(), input.size() - 1, 0, 0));
    expectFailure(decodePa5xPredictive(input.data(), input.size(), input.size(), 0, 0, input.size() - 1));
    const auto exactLimit = decodePa5xPredictive(input.data(), input.size(), input.size(), 0, 0, input.size());
    assert(exactLimit && exactLimit.samples.size() == input.size());
    const auto enormous = std::numeric_limits<std::size_t>::max();
    expectFailure(decodePa5xPredictive(input.data(), enormous, enormous, 0, 0));
    // This inaccessible pointer is only paired with rejected lengths; no read
    // or allocation may occur before the configured count limit is checked.
    constexpr std::size_t beyondDefault = 16U * 1024U * 1024U + 1U;
    expectFailure(decodePa5xPredictive(input.data(), beyondDefault, beyondDefault, 0, 0));

    const std::array<std::pair<std::int16_t, std::int16_t>, 8> unsupported{{
        {16384, 0}, {-16384, 0}, {0, 16384}, {0, -16384},
        {32767, -16383}, {-32768, -16383}, {32767, 32767}, {-32768, -32768}}};
    for (const auto& pair : unsupported) {
        assert(!pa5xPredictiveCoefficientsStable(pair.first, pair.second));
        expectFailure(decodePa5xPredictive(input.data(), input.size(), input.size(), pair.first, pair.second));
    }

    // Stable predictors close to each boundary must still be accepted. The
    // repeated-near-unit-pole case also exercises the conservative finite bound.
    const std::array<std::pair<std::int16_t, std::int16_t>, 6> supported{{
        {16383, 0}, {-16383, 0}, {0, 16383}, {0, -16383},
        {32766, -16383}, {-32766, -16383}}};
    const std::vector<std::uint8_t> sustained(4096, 127);
    for (const auto& pair : supported) {
        assert(pa5xPredictiveCoefficientsStable(pair.first, pair.second));
        const auto result = decodePa5xPredictive(sustained.data(), sustained.size(), sustained.size(), pair.first, pair.second);
        assert(result && result.samples.size() == sustained.size());
    }
}

}

int main() {
    residualCodes();
    feedbackAndSaturation();
    boundsAndUnsupportedPredictors();
    std::puts("Pa5X predictive decoder tests passed");
}
