#include "silveton/arranger/Pa5xSetBank.h"

#include <algorithm>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <set>
#include <string>
#include <sys/stat.h>
#include <tuple>
#include <unistd.h>

using namespace silveton::arranger;

namespace {
constexpr std::uint64_t firstUid = 0x4546550B84036E8CULL;

void unavailableLookupsFail(const Pa5xSetBank& bank) {
    assert(!bank.status().indexed);
    assert(bank.findSound(121, 64, 0) == nullptr);
    const auto sound = bank.inspectSound(121, 64, 0);
    assert(!sound.found && !sound.programActivationSupported && !sound.blockers.empty());
    assert(!bank.decodeSample(firstUid));
    assert(bank.pcmInventories().empty());
    assert(bank.multisampleIndex(firstUid) == nullptr);
}

void invalidAndCancelledSelections() {
    Pa5xSetBank bank; unavailableLookupsFail(bank);
    assert(!bank.load("/missing/silveton-set-bank.KST")); unavailableLookupsFail(bank);
    char temporary[] = "/tmp/silveton-set-bank-XXXXXX";
    const char* parent = ::mkdtemp(temporary); assert(parent != nullptr);
    const std::string empty = std::string(parent) + "/Empty.KST";
    assert(::mkdir(empty.c_str(), 0700) == 0);
    // A real .KST directory is recognizable but has no valid resource bank.
    // Recognizing its suffix must not publish an empty successful bank.
    assert(!bank.load(empty)); assert(bank.status().recognized); unavailableLookupsFail(bank);
    std::atomic<bool> stop{true};
    assert(!bank.load(empty, {}, &stop)); assert(bank.status().cancelled); unavailableLookupsFail(bank);
    assert(::rmdir(empty.c_str()) == 0 && ::rmdir(parent) == 0);
}

void suppliedWorkingSet(const std::string& root) {
    const auto index = indexPa5xKst(root);
    assert(index.recognized && index.structurallyValid && !index.cancelled);
    Pa5xSetBank bank;
    assert(bank.load(index)); const auto status = bank.status();
    assert(status.recognized && status.indexed && !status.cancelled && status.issues.empty());
    assert(status.sounds == 962 && status.pcmFiles == 1 && status.pcmSamples == 93 && status.kmpFiles == 1);
    assert(status.pcmFileBytes == 8678138);
    std::set<std::tuple<int, int, int>> addresses;
    for (const auto& sound : bank.sounds()) {
        const auto& descriptor = sound.descriptor;
        assert(descriptor.addressKnown);
        const auto address = std::make_tuple(descriptor.msb, descriptor.lsb, descriptor.rawProgram);
        assert(addresses.insert(address).second);
        // Address resolution is independent of a filename or display name.
        assert(bank.findSound(descriptor.msb, descriptor.lsb, descriptor.rawProgram) == &sound);
        const auto candidate = bank.inspectSound(descriptor.msb, descriptor.lsb, descriptor.rawProgram);
        assert(candidate.found && candidate.name == descriptor.name);
        assert(candidate.msb == descriptor.msb && candidate.lsb == descriptor.lsb && candidate.program == descriptor.rawProgram);
        assert(!candidate.programActivationSupported && !candidate.parametersDecoded && !candidate.blockers.empty());
    }
    assert(addresses.size() == 962);
    assert(bank.findSound(127, 127, 127) == nullptr);
    assert(!bank.inspectSound(127, 127, 127).programActivationSupported);
    for (const auto& resource : index.resources) if (resource.kind == KstResourceKind::Multisample) {
        const auto kmp = inspectPa5xSampleFile(index.rootPath + "/" + resource.relativePath);
        assert(kmp.valid && kmp.multisampleMappingDecoded && kmp.multisamples.size() == 651);
        for (const auto& multisample : kmp.multisamples) {
            const auto* scope = bank.multisampleIndex(multisample.resourceId);
            assert(scope != nullptr && scope->multisampleMappingDecoded);
            assert(std::any_of(scope->multisamples.begin(), scope->multisamples.end(), [&](const Pa5xKmpMultisample& item) {
                return item.resourceId == multisample.resourceId;
            }));
        }
    }
    const auto inventory = bank.pcmInventories();
    assert(inventory.size() == 1 && inventory[0].index != nullptr && inventory[0].index->objects.size() == 93);
    std::uint64_t totalFrames = 0; std::size_t decoded = 0;
    for (const auto& object : inventory[0].index->objects) {
        assert(object.hasId);
        const auto audio = bank.decodeSample(object.resourceId);
        if (!audio) std::fprintf(stderr, "SET decode failed for %s: %s\n", object.name.c_str(), audio.error.c_str());
        assert(audio && audio.sampleRate == object.sampleRate && audio.mono.size() == object.encodedSampleCount);
        float peak = 0;
        for (const float value : audio.mono) { assert(std::isfinite(value)); peak = std::max(peak, std::fabs(value)); }
        assert(peak > 0.0F); totalFrames += audio.mono.size(); ++decoded;
    }
    assert(decoded == 93 && totalFrames == 6143052);
    assert(!bank.decodeSample(std::numeric_limits<std::uint64_t>::max()));
    assert(!bank.decodeSample(firstUid, 1));

    // Cancellation of a replacement bank must make every playback lookup
    // unavailable, including after a previously successful selection.
    std::atomic<bool> cancel{false};
    assert(!bank.load(index, [&](const KstProgress&) { cancel.store(true); }, &cancel));
    assert(bank.status().cancelled); unavailableLookupsFail(bank);
    assert(!bank.load("/missing/replacement.KST")); unavailableLookupsFail(bank);
    std::printf("Working SET bank: %zu original Sound addresses and %zu decoded recordings (%llu frames)\n",
                addresses.size(), decoded, static_cast<unsigned long long>(totalFrames));
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 1 && argc != 2) { std::fputs("Usage: Pa5xSetBankTests [Working.KST]\n", stderr); return 2; }
    invalidAndCancelledSelections();
    if (argc == 2) suppliedWorkingSet(argv[1]);
    else std::puts("Working SET corpus skipped: pass the supplied KST with RAM01.PCM to test its real bank");
    std::puts("Pa5X SET bank: PASS (selection validity, cancellation, UID/address resolution and activation gates)");
    return 0;
}
