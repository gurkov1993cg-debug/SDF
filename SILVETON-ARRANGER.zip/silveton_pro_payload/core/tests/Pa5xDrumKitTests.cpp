#include "silveton/arranger/Pa5xDrumKit.h"
#include "silveton/arranger/Pa5xDrumSampleProgram.h"

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>

using namespace silveton::arranger;
namespace {
void check(bool ok,const char* message) { if (!ok) { std::cerr << "FAIL " << message << '\n'; std::exit(1); } }
void word(std::vector<std::uint8_t>& b,unsigned n) { b.push_back(static_cast<std::uint8_t>(n>>8U)); b.push_back(static_cast<std::uint8_t>(n)); }
void id(std::vector<std::uint8_t>& b,std::uint64_t n) { for (int s=56;s>=0;s-=8) b.push_back(static_cast<std::uint8_t>(n>>static_cast<unsigned>(s))); }
void pad(std::vector<std::uint8_t>& b,std::size_t n) { b.insert(b.end(),n,0); }
constexpr std::uint64_t kDrumId=0x0123456789ABCDEFULL;
std::vector<std::uint8_t> body(int version) {
    if(version>=5) {
        const std::size_t prefix=version<=6?313U:(version==7?448U:450U);
        const std::size_t countOffset=version<=6?288U:423U;
        const std::size_t keyBytes=version<=6?20U:(version==7?22U:29U);
        const std::size_t layerBytes=version<=6?32U:33U;
        std::vector<std::uint8_t>b(prefix,0);b[1]=2;b[2]=2;b[countOffset]=0;b.push_back(0);
        for(int key=0;key<128;++key) {
            std::vector<std::uint8_t>record(keyBytes,0);record[2]=0x7F;record[3]=0xFF;record[4]=2;
            const std::size_t switches=version==8?12U:5U;
            std::fill(record.end()-static_cast<std::ptrdiff_t>(switches+3U),record.end(),127);
            record[keyBytes-switches-3U]=63;b.insert(b.end(),record.begin(),record.end());
        }
        word(b,0x8002);
        for(int layer=0;layer<2;++layer) {
            b.push_back(static_cast<std::uint8_t>(layer));b.push_back(layer==0?0:2);word(b,999);
            pad(b,layerBytes-12U);id(b,layer==0?0:kDrumId);
        }
        return b;
    }
    std::vector<std::uint8_t> b; word(b,2);
    if (version<3) pad(b,16);
    b.push_back(2); pad(b,5); b.push_back(0); b.push_back(127);
    for (int i=0;i<(version>=2?4:2);++i) pad(b,version>=2?67:66);
    pad(b,version>=2?6:3); b.push_back(0); // no common oscillator records
    pad(b,1+6+14); if (version>=1) pad(b,3);
    for (int key=0;key<128;++key) {
        word(b,0); b.push_back(2); pad(b,4); if(version>=2)b.push_back(96);
        pad(b,2); b.insert(b.end(),{63,127,127,127,127,127,127,127});
        if(version<2)b.push_back(0);
    }
    word(b,0x8002);
    for (int layer=0;layer<2;++layer) {
        b.push_back(static_cast<std::uint8_t>(layer)); b.push_back(layer==0?0:2); word(b,999);
        b.insert(b.end(),{0xF9,0xFE,3,0xFC,5,0xFA,7}); pad(b,version>=2?11:1);
        id(b,layer==0?0:kDrumId);
    }
    return b;
}
std::vector<std::uint8_t> encoded(const std::vector<std::uint8_t>& d) {
    check(d.size()<65536,"synthetic literal fits token"); std::vector<std::uint8_t> b{'O','C','3','1'};
    for(unsigned s=0;s<32;s+=8)b.push_back(static_cast<std::uint8_t>(d.size()>>s));
    b.push_back(1);word(b,static_cast<unsigned>(d.size())); b.insert(b.end(),d.begin(),d.end());
    std::uint8_t x=0;for(auto c:d)x^=c;b.push_back(x);return b;
}
Pa5xPcgSound descriptor(const std::vector<std::uint8_t>& b,int version) {
    Pa5xPcgSound s;s.resourceClass=4;s.resourceVersion={static_cast<std::uint8_t>(version),0};
    s.kind=Pa5xPcgSoundKind::DrumKit;s.payloadLength=b.size();return s;
}
std::vector<std::uint8_t> read(const std::string& path) {
    std::ifstream f(path,std::ios::binary|std::ios::ate);check(bool(f),"open corpus PCG");const auto n=f.tellg();check(n>=0,"corpus length");
    std::vector<std::uint8_t>b(static_cast<std::size_t>(n));f.seekg(0);f.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(b.size()));check(bool(f),"read corpus PCG");return b;
}
void uploaded(const std::string& root) {
    const auto kmp=inspectPa5xSampleFile(root+"/MULTISMP/RAM.KMP");check(kmp.valid&&kmp.multisampleMappingDecoded,"typed KMP required");
    std::size_t decoded=0,unsupported=0,layers=0,ram=0,numberMismatch=0;
    for(const auto* name:{"USERDK01.PCG","USERDK02.PCG","USERDK03.PCG"}) {
        const auto path=root+"/SOUND/"+name;const auto index=inspectPa5xPcgFile(path);check(index.valid,"drum PCG indexes");const auto bytes=read(path);
        for(const auto& s:index.sounds) {
            const auto kit=inspectPa5xDrumKitBytes(bytes,s);
            check(!kit.parametersDecoded&&!kit.playable,"drum references do not declare complete synthesis");
            if(s.resourceVersion[0]==4||s.resourceVersion[0]>8) {check(!kit.referenceGraphDecoded&&!kit.error.empty(),"unknown drum versions remain explicit");++unsupported;continue;}
            if(!kit.referenceGraphDecoded)std::cerr<<path<<' '<<static_cast<int>(s.rawProgram)<<' '<<kit.error<<'\n';
            check(kit.referenceGraphDecoded&&kit.error.empty(),"all supported corpus drum bodies consume exactly");
            ++decoded;layers+=kit.layers.size();const auto links=linkPa5xDrumKitSamples(kit,kmp);
            check(links.completeRamReferences&&!links.playable&&!links.parametersDecoded,"all RAM drum UID references link without DSP claim");
            for(const auto& link:links.layers)if(link.ram) {
                ++ram;check(link.resolved&&!link.kmpDrumIndices.empty()&&!link.sampleIds.empty(),"RAM layer has typed ordinary sample dependencies");
                check(!link.stereoPairingKnown&&link.sampleIndices.size()==16,"v8 reference positions stay explicit");
                if(std::find(link.kmpDrumIndices.begin(),link.kmpDrumIndices.end(),kit.layers[link.layer].drumSampleNumber)==link.kmpDrumIndices.end())++numberMismatch;
            }
        }
    }
    check(decoded==154&&unsupported==0&&layers==24555&&ram==12886,"exact uploaded Drum Kit schema coverage");
    check(numberMismatch==202,"raw drum number is not substituted for exact UID matching");
    std::cout<<"Corpus: "<<decoded<<" complete drum reference graphs, "<<layers<<" layers, "<<ram<<" exact RAM UID links, "<<unsupported<<" unsupported kits\n";
}
}
int main(int argc,char** argv) {
    for(int version:{0,1,2,3,5,6,7,8}) {
        const auto raw=body(version), bytes=encoded(raw);auto s=descriptor(bytes,version);
        const auto kit=inspectPa5xDrumKitBytes(bytes,s);
        check(kit.referenceGraphDecoded&&!kit.parametersDecoded&&!kit.playable&&kit.layers.size()==2,"synthetic versioned drum graph");
        check(kit.keys[40].layerCount==2&&kit.keys[40].velocitySwitchesRaw[0]==63,"key layer bounds and raw velocity switches");
        const auto& l=kit.layers[1];check(l.hasDrumSampleId&&l.drumSampleId==kDrumId&&l.drumSampleNumber==999,"layer raw UID/number preserved");
        if(version<=3)check(l.layerParametersIdentified&&l.levelRaw==-7&&l.transposeRaw==-2&&l.tuneRaw==3&&l.attackRaw==-4&&l.decayRaw==5&&l.cutoffRaw==-6&&l.resonanceRaw==7,
            "signed and unsigned original layer parameters preserved without unit conversion");
        else check(!l.layerParametersIdentified&&l.rawRecord.size()==(version<=6?32U:33U),"newer layer parameters stay raw rather than mislabeled as old byte fields");
        for(std::size_t n=0;n<raw.size();++n) {
            const auto b=encoded(std::vector<std::uint8_t>(raw.begin(),raw.begin()+static_cast<std::ptrdiff_t>(n)));
            const auto partial=inspectPa5xDrumKitBytes(b,descriptor(b,version));
            check(!partial.referenceGraphDecoded&&partial.layers.empty(),"all body truncations reject partial drum graph");
        }
        auto changed=raw;changed.push_back(0);auto b=encoded(changed);
        check(!inspectPa5xDrumKitBytes(b,descriptor(b,version)).referenceGraphDecoded,"trailing body data rejected");
        const auto keyOffset=kit.drumTableOffset+(version>=5?1U:0U);
        changed=raw;changed[keyOffset]=255;changed[keyOffset+1]=255;b=encoded(changed);
        check(!inspectPa5xDrumKitBytes(b,descriptor(b,version)).referenceGraphDecoded,"key layer index cannot escape layer table");
        const auto layerWidth=version>=5?(version<=6?32U:33U):(version>=2?30U:20U);
        changed=raw;changed[raw.size()-layerWidth+1U]=4;b=encoded(changed);
        check(!inspectPa5xDrumKitBytes(b,descriptor(b,version)).referenceGraphDecoded,"unknown layer reverse flags rejected");
        changed=raw;changed[version<3?18U:2U]=0;b=encoded(changed);
        check(!inspectPa5xDrumKitBytes(b,descriptor(b,version)).referenceGraphDecoded,"body must declare Drum Kit kind");
        if(version>=5) {
            changed=raw;changed[kit.drumTableOffset]=1;b=encoded(changed);
            check(!inspectPa5xDrumKitBytes(b,descriptor(b,version)).referenceGraphDecoded,"uncalibrated newer table flags rejected");
        }
        s.payloadOffset=std::numeric_limits<std::size_t>::max();check(!inspectPa5xDrumKitBytes(bytes,s).referenceGraphDecoded,"overflowed descriptor rejected");
        s=descriptor(bytes,version);s.kind=Pa5xPcgSoundKind::Sound;check(!inspectPa5xDrumKitBytes(bytes,s).referenceGraphDecoded,"normal descriptor kind rejected");
        s.kind=Pa5xPcgSoundKind::Unknown;check(inspectPa5xDrumKitBytes(bytes,s).referenceGraphDecoded,"unknown address context may still parse proven drum body");
        Pa5xSampleIndex kmp;kmp.valid=kmp.multisampleMappingDecoded=true;kmp.samples.resize(2);kmp.samples[0].resourceId=17;kmp.samples[1].resourceId=18;
        Pa5xKmpDrumSample drum;drum.resourceId=kDrumId;drum.version8ReferencesPresent=true;drum.version8References.fill(-1);drum.version8References[0]=0;drum.version8References[1]=1;
        kmp.drumSamples={drum,drum};auto links=linkPa5xDrumKitSamples(kit,kmp);
        check(!pa5xDrumHasVerifiedStereoPair(links.layers[1]),"v8 references never pretend to have verified left/right roles");
        auto legacy=drum;legacy.version8ReferencesPresent=false;legacy.leftSample=0;legacy.rightSample=1;
        auto legacyKmp=kmp;legacyKmp.drumSamples={legacy};
        const auto legacyLinks=linkPa5xDrumKitSamples(kit,legacyKmp);
        check(legacyLinks.layers[1].resolved&&pa5xDrumHasVerifiedStereoPair(legacyLinks.layers[1]),
              "verified legacy left and right sample IDs retain both channels");
        legacyKmp.drumSamples[0].rightSample=0;
        check(!pa5xDrumHasVerifiedStereoPair(linkPa5xDrumKitSamples(kit,legacyKmp).layers[1]),
              "repeated mono sample never becomes double-amplitude fake stereo");
        check(links.completeRamReferences&&links.layers[1].resolved&&links.layers[1].kmpDrumIndices.size()==2&&links.layers[1].sampleIds.size()==2,
            "identical duplicate UID references resolve without raw-number join");
        kmp.drumSamples[1].version8References[2]=0;links=linkPa5xDrumKitSamples(kit,kmp);
        check(!links.completeRamReferences&&!links.layers[1].resolved,"conflicting duplicate UID reference graphs reject");
        auto disambiguated=kit;disambiguated.layers[1].drumSampleNumber=1;
        links=linkPa5xDrumKitSamples(disambiguated,kmp);
        check(links.completeRamReferences&&links.layers[1].duplicateResolvedByNumber&&links.layers[1].kmpDrumIndices.size()==1,
            "original drum number disambiguates only among exact matching UID candidates");
    }
    const auto bytes=encoded(body(2));
    for(int version:{4,9,255})check(!inspectPa5xDrumKitBytes(bytes,descriptor(bytes,version)).referenceGraphDecoded,"unsupported revision rejects");
    auto s=descriptor(bytes,2);s.resourceVersion[1]=1;check(!inspectPa5xDrumKitBytes(bytes,s).referenceGraphDecoded,"unsupported minor revision rejects");
    if(argc>=2)uploaded(argv[1]);
    if(argc>=3) {
        const auto index=inspectPa5xPcgFile(argv[2]);check(index.valid,"original corpus PCG index");const auto b=read(argv[2]);std::size_t supported=0;
        for(const auto& sound:index.sounds)if(sound.resourceVersion[0]<=3){check(inspectPa5xDrumKitBytes(b,sound).referenceGraphDecoded,"original supported Drum Kit regression");++supported;}
        check(supported>0,"original supported Drum Kits exercised");std::cout<<"Original corpus: "<<supported<<" supported Drum Kits\n";
    }
    std::cout<<"Pa5X Drum Kit: PASS (versioned key/layer grammar, bounds, raw parameters and typed exact UID links)\n";
}
