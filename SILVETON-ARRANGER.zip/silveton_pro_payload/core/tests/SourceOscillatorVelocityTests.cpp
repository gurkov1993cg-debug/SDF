#include "silveton/sampler/SourceAmpEnvelope.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

using namespace silveton::sampler;
namespace {
bool near(float a,float b,float tolerance=.00002F){return std::abs(a-b)<=tolerance;}

SourceOscillatorDsp sourceProfile(){
    SourceOscillatorDsp source;
    source.resourceVersion=2U;source.layoutCorroborated=true;
    source.dspRaw[21]=99U;source.dspRaw[28]=99U;source.dspRaw[78]=127U;
    source.dspRaw[80]=127U;source.dspRaw[81]=99U;
    source.amplitudeEnvelopeRaw[20]=127U;
    source.multisampleLevelRaw=127U;source.multisampleLevelDecoded=true;
    source.scaledVelocityDecoded=true;source.scaledVelocityRaw={{0U,127U}};
    source.velocityZonePresent=true;source.velocityZoneRaw={{10U,20U}};
    return source;
}

void oldBytesAndNewZoneRoundTrip(){
    auto source=sourceProfile();source.velocityZonePresent=false;
    const auto oldBytes=encodeSourceOscillatorDsp(source);
    assert(oldBytes.size()==178U&&oldBytes[0]==1U);
    SourceOscillatorDsp decoded;std::string error;
    assert(decodeSourceOscillatorDsp(oldBytes,decoded,error));
    assert(!decoded.velocityZonePresent&&decoded==source);
    assert(encodeSourceOscillatorDsp(decoded)==oldBytes);
    assert(!sourceScaledVelocitySupported(decoded));
    for(unsigned v=0U;v<=127U;++v)
        assert(sourceScaledVelocity(&decoded,static_cast<std::uint8_t>(v))==static_cast<float>(v));

    source.velocityZonePresent=true;
    const auto newBytes=encodeSourceOscillatorDsp(source);
    assert(newBytes.size()==181U&&newBytes[0]==2U);
    for(unsigned i=1U;i<178U;++i)assert(newBytes[i]==oldBytes[i]);
    assert(newBytes[178]==1U&&newBytes[179]==10U&&newBytes[180]==20U);
    assert(decodeSourceOscillatorDsp(newBytes,decoded,error)&&decoded==source);
    assert(encodeSourceOscillatorDsp(decoded)==newBytes);
    auto other=decoded;other.velocityZoneRaw[0]=11U;
    assert(!decoded.samePlaybackSettings(other));

    const auto original=decoded;
    for(const auto size:{0U,177U,178U,179U,180U,182U}){
        auto bad=newBytes;bad.resize(size);
        assert(!decodeSourceOscillatorDsp(bad,decoded,error)&&decoded==original);
    }
    auto bad=newBytes;bad[178]=2U;
    assert(!decodeSourceOscillatorDsp(bad,decoded,error)&&decoded==original);
    bad=newBytes;bad[178]=0U; // schema2 has an original zone; absence belongs to1
    assert(!decodeSourceOscillatorDsp(bad,decoded,error)&&decoded==original);
    bad=newBytes;bad[0]=3U;
    assert(!decodeSourceOscillatorDsp(bad,decoded,error)&&decoded==original);
}

void documentedZoneMappingAndBoundaries(){
    auto source=sourceProfile();
    assert(sourceScaledVelocitySupported(source)&&sourceOscillatorSupport(source).scaledVelocity);
    assert(sourceScaledVelocity(&source,10U)==0.0F);
    assert(sourceScaledVelocity(&source,20U)==127.0F);
    assert(sourceScaledVelocity(&source,15U)==63.5F);
    assert(near(sourceScaledVelocity(&source,11U),12.7F));
    assert(sourceScaledVelocity(&source,0U)==0.0F);
    assert(sourceScaledVelocity(&source,127U)==127.0F);
    float previous=-1.0F;
    for(unsigned v=0U;v<=127U;++v){
        const float current=sourceScaledVelocity(&source,static_cast<std::uint8_t>(v));
        assert(current>=previous&&current>=0.0F&&current<=127.0F);previous=current;
    }
    // Both High/Low multisample layers must retain the same original OSC
    // domain. Dividing it at15 must not turn both half-ranges into0..127.
    auto low=source;auto high=source;low.highSource=false;high.highSource=true;
    assert(near(sourceScaledVelocity(&low,14U),50.8F));
    assert(sourceScaledVelocity(&high,15U)==63.5F);

    source.velocityZoneRaw={{1U,127U}};source.scaledVelocityRaw={{1U,127U}};
    for(unsigned v=0U;v<=127U;++v)
        assert(sourceScaledVelocity(&source,static_cast<std::uint8_t>(v))==static_cast<float>(v));
    source.scaledVelocityRaw={{0U,127U}};
    assert(sourceScaledVelocity(&source,1U)==0.0F);
    assert(sourceScaledVelocity(&source,127U)==127.0F);
    source.velocityZoneRaw={{0U,127U}};source.scaledVelocityRaw={{1U,127U}};
    assert(sourceScaledVelocity(&source,0U)==1.0F);
    assert(sourceScaledVelocity(&source,127U)==127.0F);

    source.velocityZoneRaw={{64U,64U}};source.scaledVelocityRaw={{96U,96U}};
    assert(sourceScaledVelocitySupported(source)&&sourceScaledVelocity(&source,64U)==96.0F);
    source.scaledVelocityRaw={{0U,0U}};
    assert(sourceScaledVelocitySupported(source)&&sourceScaledVelocity(&source,64U)==0.0F);
    source.scaledVelocityRaw={{32U,96U}};
    assert(!sourceScaledVelocitySupported(source)&&sourceScaledVelocity(&source,64U)==64.0F);
}

void uncertainOrInvalidMappingsStayInactive(){
    const auto profile=sourceProfile();
    for(unsigned kind=0U;kind<8U;++kind){
        auto source=profile;
        if(kind==0U)source.velocityZonePresent=false;
        if(kind==1U)source.scaledVelocityDecoded=false;
        if(kind==2U)source.layoutCorroborated=false;
        if(kind==3U)source.resourceVersion=4U;
        if(kind==4U)source.velocityZoneRaw={{20U,10U}};
        if(kind==5U)source.velocityZoneRaw={{0U,128U}};
        if(kind==6U)source.scaledVelocityRaw={{127U,0U}};
        if(kind==7U)source.scaledVelocityRaw={{0U,128U}};
        assert(!sourceScaledVelocitySupported(source));
        assert(sourceScaledVelocity(&source,15U)==15.0F);
    }
    assert(sourceScaledVelocity(nullptr,15U)==15.0F);
    // Unknown/inverted raw settings still round-trip; they are not repaired
    // into a different saved setting merely to make runtime admission pass.
    auto source=profile;source.scaledVelocityRaw={{127U,0U}};
    SourceOscillatorDsp restored;std::string error;
    assert(decodeSourceOscillatorDsp(encodeSourceOscillatorDsp(source),restored,error));
    assert(restored==source&&!sourceScaledVelocitySupported(restored));
}

void sourceAmplitudeAndAmsUseFractionalPosition(){
    auto source=sourceProfile();SourceSoundEdits edits;
    SourceOscillatorRuntime soft,medium,loud;
    soft.prepare(&source,1U,0.0F);medium.prepare(&source,1U,0.0F);loud.prepare(&source,1U,0.0F);
    assert(soft.support.amplitude&&soft.support.level&&soft.support.multisampleLevel);
    SourceModulationContext low,mid,high;
    low.velocity=10U;mid.velocity=15U;high.velocity=20U;
    low.velocityPosition=sourceScaledVelocity(&source,low.velocity)/127.0F;
    mid.velocityPosition=sourceScaledVelocity(&source,mid.velocity)/127.0F;
    high.velocityPosition=sourceScaledVelocity(&source,high.velocity)/127.0F;
    soft.start(low,edits,48000);medium.start(mid,edits,48000);loud.start(high,edits,48000);
    double mediumEnergy=0.0,loudEnergy=0.0;
    for(unsigned frame=0U;frame<4800U;++frame){
        soft.tick(low,edits,48000,{{0,0}},{{false,false}});
        medium.tick(mid,edits,48000,{{0,0}},{{false,false}});
        loud.tick(high,edits,48000,{{0,0}},{{false,false}});
        const float sample=static_cast<float>(.25*std::sin(2.0*3.14159265358979323846*1000.0*frame/48000.0));
        assert(soft.amplitudeGain==0.0F);
        const double m=sample*medium.amplitudeGain,l=sample*loud.amplitudeGain;
        assert(std::isfinite(m)&&std::isfinite(l));mediumEnergy+=m*m;loudEnergy+=l*l;
    }
    assert(near(static_cast<float>(std::sqrt(mediumEnergy/loudEnergy)),.5F));
    assert(low.velocity==10U&&mid.velocity==15U&&high.velocity==20U);
    const auto values=sourceModulationValues(mid);
    assert(values[15]==.5F&&values[43]==.5F&&values[44]==.25F);
    SourceAmpEnvelope envelope;envelope.present=true;envelope.enabled=true;envelope.modulationEncodingSupported=true;
    envelope.times={{0,0,0,0}};envelope.levels={{0,99,99,99}};
    envelope.amsSources[0]=15U;envelope.amsIntensities[0]=99;envelope.amsDirections[0]=1U;
    const auto indices=sourceAmpNoteIndices(envelope,values);
    assert(indices.times[0]==49.5F); // no rounded64/127 intermediate
    mid.released=true;mid.releaseVelocity=99U;
    const auto released=sourceModulationValues(mid);
    assert(released[15]==.5F&&near(released[43],99.0F/127.0F));
}
}

int main(){
    oldBytesAndNewZoneRoundTrip();documentedZoneMappingAndBoundaries();
    uncertainOrInvalidMappingsStayInactive();sourceAmplitudeAndAmsUseFractionalPosition();
    std::puts("PASS source velocity: SVOD1 byte identity/SVOD2 round-trip; original OSC domain; fractional AMS; bounded/constant maps; unknown gates; rendered source amplitude response");
}
