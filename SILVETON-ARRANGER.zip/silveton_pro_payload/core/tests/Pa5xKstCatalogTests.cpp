#include "silveton/arranger/Pa5xKstCatalog.h"
#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/arranger/KorgStyleImport.h"
#include "silveton/arranger/Pa5xPcgIndex.h"

#include <cstdlib>
#include <iostream>
#include <map>
#include <set>

using namespace silveton::arranger;
namespace {
void check(bool value, const char* message) {
    if (!value) { std::cerr << "FAIL " << message << '\n'; std::exit(1); }
}
struct SilentCallbacks final : RenderCallbacks {
    void render(std::uint32_t, std::uint32_t) noexcept override {}
    void midi(int,int,std::uint8_t,std::uint8_t,std::uint8_t) noexcept override {}
};
}
int main(int argc, char** argv) {
    const auto invalid = buildPa5xKstCatalog(Pa5xKstIndex{});
    check(!invalid.recognized && !invalid.error.empty() && invalid.styles.empty(), "unrecognized root cannot fabricate lists");
    Pa5xKstIndex empty; empty.recognized = true; empty.rootPath = "/unused"; empty.name = "Empty catalog";
    std::atomic<bool> cancel{true};
    const auto cancelled = buildPa5xKstCatalog(empty,{},&cancel);
    check(cancelled.cancelled && cancelled.styles.empty() && cancelled.sounds.empty(), "pre-cancelled catalog performs no resource reads");
    empty.resources.push_back({KstResourceKind::Sound,"../outside.PCG",1,true,false});
    const auto escaped = buildPa5xKstCatalog(empty);
    check(escaped.sounds.empty() && !escaped.warnings.empty(), "relative resource traversal is rejected");
    if (argc >= 2) {
        const auto index = indexPa5xKst(argv[1]);
        check(index.recognized && !index.cancelled, "actual uploaded KST is recognized");
        std::uint64_t finalDone = 0, finalTotal = 0;
        const auto catalog = buildPa5xKstCatalog(index,[&](const KstProgress& p) { finalDone = p.done; finalTotal = p.total; });
        check(catalog.recognized && !catalog.cancelled && catalog.error.empty(), "real resource catalog completes");
        check(finalDone == finalTotal && finalTotal == index.resources.size(), "catalog progress reaches its real resource count");
        check(catalog.styles.size() == 681, "all681 actual Style rows retained");
        std::size_t loadable = 0;
        for (const auto& row : catalog.styles) {
            check(!row.name.empty() && !row.path.empty() && !row.relativePath.empty(), "Style identity/path visible");
            check(row.loadable && row.error.empty() && row.bpm > 0 && row.numerator > 0 && row.denominator > 0,
                "every real Style has loadable graph and original tempo/meter");
            ++loadable;
            const auto imported = importKorgStyleFile(row.path);
            check(bool(imported), "catalog and host importer agree");
            ArrangerEngine engine; SilentCallbacks sink;
            check(engine.installStyle(0,imported.style), "catalog graph accepted by actual host engine contract");
            engine.process(64,48000,sink);
            const auto applied = engine.snapshot(0);
            check(applied.tempoBpm == row.bpm && applied.numerator == row.numerator && applied.denominator == row.denominator,
                "listed original tempo/meter matches published engine state");
        }
        check(catalog.sounds.size() == 962, "all962 actual PCG Sound/Drum Kit rows retained");
        std::size_t graphs = 0, drums = 0;
        std::map<std::string,Pa5xPcgInspection> banks;
        for (const auto& row : catalog.sounds) {
            check(!row.name.empty() && !row.playable && !row.blocker.empty(), "Sound row never invents complete playback");
            check(row.program == row.rawProgram, "program retains raw zero-based address");
            if (row.graphSupported) { ++graphs; check(!row.drumKit, "normal reference graph is not a Drum Kit graph"); }
            if (row.drumKit) ++drums;
            auto found = banks.find(row.path);
            if (found == banks.end()) found = banks.emplace(row.path,inspectPa5xPcgFile(row.path)).first;
            check(found->second.valid, "Sound row source bank remains structurally valid");
            bool matched = false;
            for (const auto& sound : found->second.sounds)
                if (sound.internalBank == row.internalBank && sound.rawProgram == row.rawProgram) {
                    matched = sound.name == row.name && sound.addressKnown == row.addressKnown;
                    if (sound.addressKnown) matched = matched && row.msb == sound.msb && row.lsb == sound.lsb;
                    break;
                }
            check(matched, "catalog Sound name and original address match exact PCG index");
        }
        check(graphs == 808 && drums == 154, "supported graph/Drum Kit counts remain exact");
        check(catalog.keyboardSets.size() == 772, "actual uploaded KSC count retained including Settings KSC");
        for (const auto& row : catalog.keyboardSets)
            check(row.metadataSupported && !row.playable && !row.blocker.empty(), "Keyboard Set metadata does not claim Sound activation");
        if (argc >= 3) {
            check(catalog.samples.size() == 93, "working KST contains all93 actual new PCM samples");
            std::set<std::uint64_t> ids;
            for (const auto& row : catalog.samples) {
                check(ids.insert(row.resourceId).second && row.resourceId != 0, "sample list retains exact unique UIDs");
                check(row.previewable && row.blocker.empty() && !row.pcmPath.empty() && !row.kmpPath.empty() &&
                      row.rate > 0 && row.frames > 0 && row.root >= -1 && row.root <= 127,
                      "sample preview capability uses typed matching KMP metadata");
            }
        } else check(catalog.samples.empty(), "original uploaded KST does not invent missing PCM rows");
        std::cout << "Corpus: " << loadable << " loadable Style graphs, " << catalog.sounds.size()
                  << " Sound rows, " << catalog.keyboardSets.size() << " Keyboard Sets, " << catalog.samples.size() << " PCM samples\n";
    }
    std::cout << "Pa5X KST catalog: PASS (real lists, exact addresses, original timing, blockers and cancellation)\n";
}
