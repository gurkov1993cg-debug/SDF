#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/PaSeriesTrackSettings.h"
#include "fixtures/PaSeriesBankFixtures.h"

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>

using namespace silveton::arranger;
namespace {
using namespace silveton::test::pa_series;

void exactNativeRecall() {
    for(const auto tag:{0x09000008U,0x09010008U,0x09010108U}) {
        File f;f.write(bank(keyboard(tag)));const auto original=readPaKeyboardLocation(f.path+"!/17");
        check(original.valid&&original.parts.size()==4&&original.splitPoint==60,"valid original bank resolves its explicit native slot and split");
        const auto read=readPa5xKeyboardSet(original);
        const auto fromPath=readPa5xKeyboardSet(f.path+"!/17");
        check(read.valid,"recall reader accepts valid native part metadata independently of missing PCM");
        for(std::size_t i=0;i<4;++i) {
            const auto& p=read.parts[i];const auto& raw=original.parts[i].sourceNativeTrack;
            check(fromPath.parts[i].octaveTransposeKnown==p.octaveTransposeKnown&&fromPath.parts[i].octaveTranspose==p.octaveTranspose&&
                  fromPath.parts[i].partTranspositionDeclared==p.partTranspositionDeclared&&fromPath.parts[i].partTranspositionRaw==p.partTranspositionRaw,
                  "path and inspection recall do not apply different legacy octave inference");
            check(raw&&raw==p.sourceNativeTrack&&raw->structurallyValid,"native data and provenance reach the recall path");
            check(raw->tag==tag&&raw->trackIndex==i&&raw->originalRecord==track(tag,static_cast<unsigned>(i)),"complete native record and explicit role retained byte for byte");
            check(p.recallSetupValid&&p.program==static_cast<int>(20U+i)&&p.volumeRaw==static_cast<int>(90U+i),"existing Sound address and level still follow the original part");
            check(p.masterFxSendRaw[0]==(i==0?0:127-static_cast<int>(i))&&p.masterFxSendRaw[1]==(i==3?127:40+static_cast<int>(i)),"both native master sends reach the correct named part including zero");
            check(p.masterFxSendRaw[2]==-1&&p.fineTuneRaw==-1&&p.coarseTuneRaw==-1,"two sends/native cents do not invent a third send or MIDI RPN");
            check(p.pitchBendRangeSemitones==(i==0?0:12),"native zero bend is distinct from an absent range");
            const int cents[]{-64,0,63,-5},octaves[]{-3,0,3,-1};
            check(raw->detuneKnown&&raw->detuneCents==cents[i]&&raw->octaveTransposeKnown&&raw->octaveTranspose==octaves[i],"cents and octave units are exact, including signed extrema and explicit zero");
            check(raw->eqGainKnownMask==7&&raw->eqGainHalfDb==std::array<int,3>{{-36,3,36}},"signed half-dB EQ gains retained exactly");
            check(!raw->semanticsComplete&&raw->dryRaw==static_cast<int>(i&1U),"raw routing and unknown controls do not claim complete synthesis");
        }
        check(!readPaKeyboardLocation(f.path+"!/16").valid,"neighboring physical slot is not guessed");
        auto wrongRole=original;
        wrongRole.parts[0].sourceNativeTrack=wrongRole.parts[1].sourceNativeTrack;
        check(!readPa5xKeyboardSet(wrongRole).parts[0].recallSetupValid,"native source record cannot be moved to a different declared keyboard role");
    }
}

void originalStyleSettings() {
    File file("USER01.STY");file.write(styleBank());auto result=readPaStyleSlot(file.path+"!/17",nullptr);
    check(result.valid&&result.nativeStyle,"synthetic native Style with original STS mixer loads");
    check(result.sourceEffects&&result.sourceEffects->valid()&&result.sourceEffects->scope==KorgSourceFxScope::StyleMaster,
          "accompaniment Master FX retain their true Style scope");
    check(result.sourceEffects->definitions.size()==1&&result.sourceEffects->definitions[0].selector==2&&
          result.sourceEffects->definitions[0].parameters[0]==55,"original Style effect number and parameter bytes are read");
    const Element elements[]{Element::Var1,Element::Var2};
    for(std::size_t i=0;i<2;++i){
        auto e=static_cast<std::size_t>(elements[i]);const auto& native=result.sections[e].tracks[3].sourceNativeTrack;
        check(native&&native->structurallyValid&&native->trackIndex==3&&native->detuneCents==-5,"exact ACC mixer settings retained per present element");
        const auto& setup=result.nativeStyle->sections[e].patterns[3].setupEvents;
        int program=-1,send1=-1,send2=-1,rpnMsb=-1,rpnLsb=-1,bend=-1,cents=-1;
        for(const auto& event:setup){
            check((event.status&15U)==11,"ACC1 setup stays on its native internal channel");
            if((event.status&0xF0U)==0xC0U)program=event.data1;
            if((event.status&0xF0U)!=0xB0U)continue;
            switch(event.data1){
                case 91:send1=event.data2;break;case 93:send2=event.data2;break;
                case 101:rpnMsb=event.data2;break;case 100:rpnLsb=event.data2;break;
                case 6:if(rpnMsb==0&&rpnLsb==0)bend=event.data2;break;
                case 38:if(rpnMsb==0&&rpnLsb==0)cents=event.data2;break;
            }
        }
        check(program==20+static_cast<int>(i),"mixer recall does not overwrite each Variation's original Sound address");
        check(send1==124&&send2==127&&bend==12&&cents==0,"original Style sends and integer bend are applied through setup");
        check(rpnMsb==127&&rpnLsb==127,"translated native bend does not leave a dangling RPN selection");
    }
    check(result.sections[static_cast<std::size_t>(Element::Var1)].tracks[3].sourceNativeTrack==
          result.sections[static_cast<std::size_t>(Element::Var2)].tracks[3].sourceNativeTrack,
          "shared original mixer provenance is retained across native style elements");
    file.write(styleBank(false,true));
    check(readPaStyleSlot(file.path+"!/17",nullptr).sourceEffects!=nullptr,"identical duplicate source mixer records have no conflicting values");
    file.write(styleBank(true));result=readPaStyleSlot(file.path+"!/17",nullptr);
    check(result.valid&&result.nativeStyle&&result.nativeStyle->initialMuteKnownMask==0&&result.sourceEffects==nullptr,
          "conflicting native mixer rejects the complete mixer transaction while retaining the independent Style");
    check(std::any_of(result.warnings.begin(),result.warnings.end(),[](const auto& warning){return warning.find("Conflicting native Pa")!=std::string::npos;}),
          "native mixer conflict remains an explicit diagnostic");
    for(const auto& section:result.nativeStyle->sections)for(const auto& pattern:section.patterns)
        for(const auto& event:pattern.setupEvents)
            check((event.status&0xF0U)!=0xB0U||(event.data1!=7&&event.data1!=10&&event.data1!=91&&event.data1!=93&&event.data1!=101),
                  "a later mixer conflict leaves no earlier partial volume, pan, send or bend changes");
}

void invalidAndUnsupportedStayExplicit() {
    auto b=track(0x09000008U,0);
    b[18]=255;b[19]=1;b[31]=128;b[32]=255;b[35]=2;b[40]=13;b[43]=127;b[44]=128;
    auto value=readPaSeriesTrackSettings(0x09000008U,b.data(),b.size());
    check(value.structurallyValid&&!value.detuneKnown&&!value.octaveTransposeKnown,"invalid field units never become zero or rounded octaves");
    check(value.masterFxSendRaw[0]==-1&&value.masterFxSendRaw[1]==-1&&value.pitchBendRangeSemitones==-1&&value.dryRaw==-1,"out of range sends, bend and routing remain unknown");
    check(value.eqGainKnownMask==4&&value.originalRecord==b,"invalid EQ remains preserved but is not a valid gain");
    auto unsupported=readPaSeriesTrackSettings(0x09020008U,b.data(),b.size());
    check(!unsupported.recognized&&!unsupported.structurallyValid&&!unsupported.detuneKnown&&unsupported.originalRecord==b,"future version is preserved without assuming the old offsets");
    for(std::size_t n:{0U,19U,45U,241U,243U}) {
        Bytes malformed(n,0);auto shortRead=readPaSeriesTrackSettings(0x09000008U,malformed.data(),malformed.size());
        check(!shortRead.structurallyValid&&!shortRead.error.empty()&&shortRead.originalRecord==malformed,"declared old format requires its exact body boundary");
    }
    Bytes huge(kMaximumPaSeriesTrackRecordBytes+1U,0);
    check(readPaSeriesTrackSettings(0x09000008U,huge.data(),huge.size()).originalRecord.empty(),"opaque preservation respects the allocation bound");
    check(!readPaSeriesTrackSettings(0x09000008U,nullptr,242U).structurallyValid,"null source is rejected");
    b=track(0x09000008U,0);b[33]=1;
    check(!readPaSeriesTrackSettings(0x09000008U,b.data(),b.size()).structurallyValid,"unknown reserved-word layout is not decoded");

    File f;f.write(bank(keyboard(0x09010108U,true)));auto bad=readPa5xKeyboardSet(readPaKeyboardLocation(f.path+"!/17"));
    check(!bad.parts[2].recallSetupValid&&bad.parts[2].status==Pa5xKeyboardSetSoundStatus::InvalidSetup,"truncated native part cannot be silently recalled as a complete setup");
    f.write(bank(keyboard(0x09000008U),true));auto locked=readPaKeyboardLocation(f.path+"!/17");
    check(!locked.valid&&locked.error.find("Protected")!=std::string::npos,"protected directory flag blocks decoding without bypass");
}
void factoryModelIsNotInferred(){
    File keyboardFile;keyboardFile.write(bank(keyboard(0x09010108U,false,true)));
    auto read=readPa5xKeyboardSet(keyboardFile.path+"!/17");
    for(const auto& part:read.parts)
        check(part.addressKnown&&part.msb==0&&part.lsb==0&&part.program==0&&
              part.status==Pa5xKeyboardSetSoundStatus::FactorySoundRequired&&part.soundName.empty()&&
              part.soundMessage.find("Pa model")!=std::string::npos,
              "legacy keyboard factory address is preserved without borrowing a Pa5X model-specific Sound name");
    File styleFile("USER01.STY");styleFile.write(styleBank(false,false,true));
    const auto style=readPaStyleSlot(styleFile.path+"!/17",nullptr);
    check(style.valid,"factory-only native Style still reads");
    const auto& change=style.sections[static_cast<std::size_t>(Element::Var1)].tracks[3].setupSoundChanges.front();
    check(change.msb==0&&change.lsb==0&&change.program==0&&change.sound.addressComplete&&
          change.sound.resolution==KstResolution::FactorySoundRequired&&change.sound.name.empty()&&
          change.sound.message.find("Pa model")!=std::string::npos,
          "legacy Style factory address does not inherit an unestablished keyboard-model identity");
}
}

int main() {
    exactNativeRecall();originalStyleSettings();invalidAndUnsupportedStayExplicit();factoryModelIsNotInferred();
    std::cout<<"Native Pa bank/track settings tests passed\n";
}
