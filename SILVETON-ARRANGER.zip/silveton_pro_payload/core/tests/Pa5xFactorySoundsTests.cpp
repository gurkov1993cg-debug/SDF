#include "silveton/arranger/Pa5xFactorySounds.h"

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>

using namespace silveton::arranger;

namespace {

void expect(int msb, int lsb, int program, const char* name,
            Pa5xFactorySoundKind kind, unsigned page, const char* category) {
    const auto* sound = findPa5xFactorySound(msb, lsb, program);
    assert(sound != nullptr && std::strcmp(sound->name, name) == 0);
    assert(sound->kind == kind && sound->printedPage == page);
    assert(std::strcmp(sound->category, category) == 0);
}

void documentedAddresses() {
    // These PC values are printed as0 and1 in the manual, not display values
    // requiring a1-based to0-based conversion.
    expect(121, 20, 0, "Austrian Grand", Pa5xFactorySoundKind::Sound, 1590, "Factory/Piano");
    expect(121, 7, 1, "Japanese Grand", Pa5xFactorySoundKind::Sound, 1590, "Factory/Piano");
    expect(121, 31, 21, "Italian Acc 16’", Pa5xFactorySoundKind::Sound, 1593, "Factory/Accordion");
    expect(121, 2, 1, "Piano Pad 1", Pa5xFactorySoundKind::Sound, 1609, "Legacy/Piano");
    expect(0, 0, 0, "AcousticPiano XG", Pa5xFactorySoundKind::Sound, 1623, "GM/XG/Piano");
    expect(121, 0, 0, "AcousticPiano GM", Pa5xFactorySoundKind::Sound, 1623, "GM/XG/Piano");
    expect(121, 0, 127, "Gun Shot GM", Pa5xFactorySoundKind::Sound, 1637, "GM/XG/SFX");
    expect(120, 0, 100, "Pop Kit 1 RR", Pa5xFactorySoundKind::DrumKit, 1639, "Factory/Drum");
    // The manual classifies this as a Drum Kit despite its MSB121 address.
    expect(121, 4, 118, "Slices A FX", Pa5xFactorySoundKind::DrumKit, 1640, "Factory/Drum");
    expect(120, 0, 7, "Standard Kit 5", Pa5xFactorySoundKind::DrumKit, 1641, "Legacy/Drum & SFX");
    expect(120, 0, 0, "Standard Kit GM", Pa5xFactorySoundKind::DrumKit, 1641, "GM/XG/Drum");
}

void completeCatalogFingerprint() {
    const auto* data = pa5xFactorySounds();
    const auto count = pa5xFactorySoundCount();
    assert(data != nullptr && count == 2413);
    std::uint64_t hash = UINT64_C(14695981039346656037);
    const auto byte = [&](unsigned value) { hash = (hash ^ value) * UINT64_C(1099511628211); };
    const auto string = [&](const char* value) {
        for (const auto* character = value; *character != 0; ++character)
            byte(static_cast<unsigned char>(*character));
        byte(0);
    };
    std::size_t sounds = 0, kits = 0, factory = 0, legacy = 0, gm = 0;
    std::uint32_t previous = 0;
    for (std::size_t index = 0; index < count; ++index) {
        const auto& sound = data[index];
        assert(sound.msb <= 127 && sound.lsb <= 127 && sound.rawProgram <= 127);
        assert(sound.name != nullptr && sound.name[0] != 0);
        assert(sound.category != nullptr && sound.category[0] != 0);
        const auto address = (static_cast<std::uint32_t>(sound.msb) << 14U) |
                             (static_cast<std::uint32_t>(sound.lsb) << 7U) | sound.rawProgram;
        assert(index == 0 || address > previous); // Every address is unique.
        previous = address;
        assert(findPa5xFactorySound(sound.msb, sound.lsb, sound.rawProgram) == &sound);
        if (sound.kind == Pa5xFactorySoundKind::Sound) {
            ++sounds; assert(sound.printedPage >= 1590 && sound.printedPage <= 1637);
        } else {
            assert(sound.kind == Pa5xFactorySoundKind::DrumKit);
            ++kits; assert(sound.printedPage >= 1639 && sound.printedPage <= 1641);
        }
        if (std::strncmp(sound.category, "Factory/", 8) == 0) ++factory;
        else if (std::strncmp(sound.category, "Legacy/", 7) == 0) ++legacy;
        else { assert(std::strncmp(sound.category, "GM/XG/", 6) == 0); ++gm; }
        byte(sound.msb); byte(sound.lsb); byte(sound.rawProgram);
        byte(static_cast<unsigned>(sound.kind)); byte(sound.printedPage >> 8U); byte(sound.printedPage & 255U);
        string(sound.name); string(sound.category);
    }
    // Independent layout-column and PDF-word-coordinate extraction gave these
    // same2413 factual records and this canonical little-byte FNV-1a fingerprint.
    assert(hash == UINT64_C(0xBF64C6F9EBA840BD));
    assert(sounds == 2271 && kits == 142);
    assert(factory == 1046 && legacy == 660 && gm == 707);
}

void provenanceAndUnknowns() {
    const auto& info = pa5xFactorySoundCatalogInfo();
    assert(std::strcmp(info.manualVersion, "1.5") == 0 && std::strcmp(info.manualEdition, "EN13") == 0);
    assert(std::strcmp(info.sourcePdfSha256, "6450ce557f66e25b205e283c29c616b8da58fcba8e94b9d9ef554303676be7f5") == 0);
    assert(info.firstSoundPage == 1590 && info.lastSoundPage == 1637);
    assert(info.firstDrumKitPage == 1639 && info.lastDrumKitPage == 1641);
    assert(info.programsAreZeroBased && info.midiImplementationPage == 1949);
    assert(findPa5xFactorySound(-1, 0, 0) == nullptr);
    assert(findPa5xFactorySound(0, -1, 0) == nullptr);
    assert(findPa5xFactorySound(0, 0, -1) == nullptr);
    assert(findPa5xFactorySound(128, 0, 0) == nullptr);
    assert(findPa5xFactorySound(0, 128, 0) == nullptr);
    assert(findPa5xFactorySound(0, 0, 128) == nullptr);
    assert(findPa5xFactorySound(119, 127, 127) == nullptr);
    assert(findPa5xFactorySound(56, 0, 0) == nullptr); // No undocumented bank fallback.
}

}

int main() {
    documentedAddresses(); completeCatalogFingerprint(); provenanceAndUnknowns();
    std::puts("Pa5X factory catalog: 2413 exact official addresses/names, raw programs and provenance passed");
}
