#include "silveton/arranger/Pa5xStyleRead.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <dirent.h>
#include <iostream>
#include <set>
#include <string>
#include <sys/stat.h>
#include <vector>

using namespace silveton::arranger;
namespace {
using Bytes=std::vector<std::uint8_t>;
void check(bool condition,const char* message){if(!condition){std::cerr<<"FAIL "<<message<<'\n';std::exit(1);}}
void be16(Bytes& bytes,std::size_t value){bytes.push_back(static_cast<std::uint8_t>(value>>8U));bytes.push_back(static_cast<std::uint8_t>(value));}
void be32(Bytes& bytes,std::size_t value){for(int shift=24;shift>=0;shift-=8)bytes.push_back(static_cast<std::uint8_t>(value>>shift));}
void text(Bytes& bytes,const std::string& value){bytes.insert(bytes.end(),value.begin(),value.end());}
void zeroText(Bytes& bytes,const std::string& value){text(bytes,value);bytes.push_back(0);}
void vlq(Bytes& bytes,std::uint32_t value){std::uint8_t chunks[4]{};std::size_t count=0;chunks[count++]=static_cast<std::uint8_t>(value&127U);while((value>>=7U)!=0)chunks[count++]=static_cast<std::uint8_t>((value&127U)|128U);while(count>0)bytes.push_back(chunks[--count]);}
struct Track {
    Bytes bytes;std::uint32_t tick{0};
    void event(std::uint32_t absolute,const Bytes& data){check(absolute>=tick,"fixture events are monotonic");vlq(bytes,absolute-tick);bytes.insert(bytes.end(),data.begin(),data.end());tick=absolute;}
    void meta(std::uint32_t absolute,std::uint8_t type,const Bytes& data){Bytes eventBytes={0xFF,type};vlq(eventBytes,static_cast<std::uint32_t>(data.size()));eventBytes.insert(eventBytes.end(),data.begin(),data.end());event(absolute,eventBytes);}
    void tempo(std::uint32_t absolute,std::uint32_t us){meta(absolute,0x51,{static_cast<std::uint8_t>(us>>16U),static_cast<std::uint8_t>(us>>8U),static_cast<std::uint8_t>(us)});}
    void meter(std::uint32_t absolute,std::uint8_t numerator,std::uint8_t exponent){meta(absolute,0x58,{numerator,exponent,24,8});}
    void end(std::uint32_t absolute){meta(absolute,0x2F,{});}
};
Bytes midi(const std::vector<Track>& tracks){Bytes bytes; text(bytes,"MThd");be32(bytes,6);be16(bytes,1);be16(bytes,tracks.size());be16(bytes,96);for(const auto& track:tracks){text(bytes,"MTrk");be32(bytes,track.bytes.size());bytes.insert(bytes.end(),track.bytes.begin(),track.bytes.end());}return bytes;}
Bytes resource(const char* kind,const std::string& label,const Bytes& data){Bytes bytes;zeroText(bytes,kind);zeroText(bytes,label);be32(bytes,data.size());bytes.insert(bytes.end(),data.begin(),data.end());return bytes;}
Bytes leaf(const std::string& label,const std::string& value){return resource("Leaf",label,Bytes(value.begin(),value.end()));}
void append(Bytes& destination,const Bytes& bytes){destination.insert(destination.end(),bytes.begin(),bytes.end());}
Bytes scene(const std::string& name,int numerator,int denominatorExponent,const Bytes& smf){
    Bytes clip;
    const std::string xml="<CLIP version=\"1\" release=\"0\"><PARAMS><Pattern type=\"Drum\"/><NTT value=\"0\"/><NTR value=\"0\"/><ORIGINAL_CHORD><CV1 root=\"C\" chord=\"Maj\" length=\"1\"/><CV2 root=\"F\" chord=\"Min\" length=\"1\"/></ORIGINAL_CHORD><CHORD_TABLE><Maj cv=\"1\"/><Min cv=\"2\"/></CHORD_TABLE></PARAMS></CLIP>";
    append(clip,leaf("ClipDescription.xml",xml));append(clip,resource("Leaf","Main.mid",smf));
    Bytes children=leaf("SceneDescription.xml","<SCENE><TimeSignature numerator=\""+std::to_string(numerator)+"\" denominator=\""+std::to_string(denominatorExponent)+"\"/></SCENE>");
    append(children,resource("Branch","Drum.pdc",clip));return resource("Branch",name,children);
}
Bytes style(const Bytes& scenes,std::uint32_t globalTempo=400000){
    Bytes contents=leaf("StageDescription.xml","<STAGE><Tempo value=\""+std::to_string(globalTempo)+"\"/></STAGE>");
    append(contents,resource("Branch","Fixture.stc",resource("Branch","Scenes",scenes)));
    Bytes bytes={'R','o','o','t',0,1,0};be32(bytes,contents.size());append(bytes,contents);return bytes;
}
Track setup(std::uint32_t end,std::uint8_t num=4,std::uint8_t exponent=2){Track track;track.tempo(0,600000);track.meter(0,num,exponent);track.event(0,{0xB0,0,121});track.event(0,{0xB0,32,8});track.event(0,{0xC0,2});track.event(0,{0xB4,0,79});track.event(0,{0xB4,32,2});track.event(0,{0xC4,5});track.end(end);return track;}
Bytes twoCvs(std::uint32_t start,std::uint8_t num=4,std::uint8_t exponent=2,bool meterChanges=false){
    auto initial=setup(start,num,exponent);Track first,second;
    first.event(start,{0x90,60,90});first.event(start,{0xC0,10});first.event(start,{0xB0,0,120});first.event(start,{0x90,62,90});first.event(start,{0xC0,11});first.event(start,{0xB0,32,9});first.event(start,{0xC0,12});first.event(start,{0x94,65,90});
    first.event(start+1U,{0x80,60,0});first.event(start+1U,{0x80,62,0});first.event(start+1U,{0x84,65,0});
    first.tempo(start+12U,300000);first.tempo(start+24U,750000);
    if(meterChanges){first.meter(start+32U,3,2);first.meter(start+48U,5,3);}
    first.end(start+96U);
    second.event(start,{0x90,67,90});second.event(start,{0xB0,0,122});second.event(start,{0x90,69,90});second.event(start,{0xC0,3});second.event(start+1U,{0x80,67,0});second.event(start+1U,{0x80,69,0});second.end(start+96U);
    return midi({initial,first,second});
}
const KorgStyleClip& inspectedClip(const Pa5xStyleRead& read,Element element){
    check(read.inspection!=nullptr,"reader retains physical inspection");for(const auto& section:read.inspection->elements)if(section.element==element){check(section.clips.size()==1,"fixture has one logical track");return section.clips.front();}check(false,"fixture element exists");return read.inspection->elements.front().clips.front();
}
const KorgMidiChannelEvent& note(const KorgStyleClip& clip,unsigned physicalTrack,unsigned key){
    const auto found=std::find_if(clip.channelEvents.begin(),clip.channelEvents.end(),[&](const KorgMidiChannelEvent& event){return event.track==physicalTrack&&(event.status&0xF0U)==0x90U&&event.data1==key&&event.data2>0;});check(found!=clip.channelEvents.end(),"physical note exists");return *found;
}
void address(const Pa5xStyleSoundChange* sound,int msb,int lsb,int program,const char* message){check(sound!=nullptr&&sound->msb==msb&&sound->lsb==lsb&&sound->program==program,message);}
void exactCvStateAndOrder(){
    const auto read=readPa5xStyleBytes(style(scene("Var1.scn",4,2,twoCvs(384))),"fixture.stg");
    check(read.valid&&read.name=="Fixture"&&read.originalBpm==150.0&&read.ppq==96,"Stage original tempo is independent of setup FF51 and source filename");
    const auto& section=read.sections[static_cast<std::size_t>(Element::Var1)];check(section.available&&section.meterKnown&&section.numerator==4&&section.denominator==4,"Scene meter is read explicitly");
    const auto& track=section.tracks[0];check(track.present&&track.setupTimingKnown&&track.setupTicks==384,"one original setup measure establishes relative CV timing");
    const auto& first=track.cvs[0];const auto& second=track.cvs[1];check(first.available&&second.available&&first.number==1&&second.number==2&&first.lengthTicks==96&&second.lengthTicks==96,"physical CV identities and lengths remain distinct");
    check(first.sourceRoot=="C"&&first.sourceChord=="Maj"&&second.sourceRoot=="F"&&second.sourceChord=="Min","original chord declarations remain per CV");
    const auto& raw=inspectedClip(read,Element::Var1);const auto& before=note(raw,1,60);const auto& pending=note(raw,1,62);const auto& cv2before=note(raw,2,67);const auto& cv2pending=note(raw,2,69);
    address(first.soundAt(0,0,before.order),121,8,2,"same-tick note before PC retains inherited setup Sound");
    address(first.soundAt(0,0,pending.order),121,8,10,"pending CC0 does not change the active Sound before PC");
    address(first.soundAt(0,0),120,9,12,"last same-tick PC commits both original bank bytes in event order");
    address(second.soundAt(0,0,cv2before.order),121,8,2,"CV2 inherits setup instead of CV1's final PC");
    address(second.soundAt(0,0,cv2pending.order),121,8,2,"CV2's own pending bank stays pending until its PC");
    address(second.soundAt(0,0),122,8,3,"CV2 PC commits its own bank without another CV's state");
    address(first.soundAt(4,0),79,2,5,"multiple original MIDI channels remain independent of sampler lane numbers");
    check(track.setupTempoChanges.size()==1&&track.setupTempoChanges[0].microsecondsPerQuarter==600000&&track.setupTempoChanges[0].originalTick==0,"setup tempo is preserved separately from Stage tempo");
    check(first.tempoChanges.size()==2&&first.tempoChanges[0].tick==12&&first.tempoChanges[0].originalTick==396&&first.tempoChanges[0].microsecondsPerQuarter==300000&&first.tempoChanges[1].tick==24&&first.tempoChanges[1].bpm==80.0,"all physical CV tempo changes retain exact original and relative times");
    check(second.tempoChanges.empty()&&first.timeSignatureChanges.empty(),"setup metadata is not copied into unrelated CV timelines");
    const auto independent=inspectKorgMidiBytes(twoCvs(384),KorgMidiPatchScope::SetupAndIndependentCvs);
    check(independent.valid,"independent CV scope accepts the original physical MIDI layout");
    const auto setupProgram=std::find_if(independent.patches.begin(),independent.patches.end(),[](const KorgMidiPatchSelection& patch){return patch.track==0&&patch.channel==0&&patch.program==2;});
    const auto firstProgram=std::find_if(independent.patches.begin(),independent.patches.end(),[](const KorgMidiPatchSelection& patch){return patch.track==1&&patch.channel==0&&patch.program==10;});
    const auto lastProgram=std::find_if(independent.patches.begin(),independent.patches.end(),[](const KorgMidiPatchSelection& patch){return patch.track==1&&patch.channel==0&&patch.program==12;});
    check(setupProgram!=independent.patches.end()&&setupProgram->usedByNotes&&firstProgram!=independent.patches.end()&&firstProgram->usedByNotes,"independent scope credits inherited setup and each CV's actually used PC");
    check(lastProgram!=independent.patches.end()&&!lastProgram->usedByNotes,"CV2 notes never mark CV1's final Program Change as used");
}
void pendingSetupAndUnknown(){
    auto initial=setup(384);initial.bytes.clear();initial.tick=0;initial.meter(0,4,2);initial.tempo(0,500000);initial.event(0,{0xB0,0,121});initial.event(0,{0xB0,32,14});initial.event(0,{0xC0,90});initial.event(12,{0xB0,32,0});initial.end(384);
    Track first,second;first.event(384,{0x90,60,90});first.event(384,{0xC0,7});first.event(385,{0x80,60,0});first.end(480);second.event(384,{0x90,62,90});second.event(385,{0x80,62,0});second.end(480);
    auto read=readPa5xStyleBytes(style(scene("Var1.scn",4,2,midi({initial,first,second}))));check(read.valid,"pending setup fixture is readable");
    const auto& track=read.sections[static_cast<std::size_t>(Element::Var1)].tracks[0];
    address(track.cvs[1].soundAt(0,0),121,14,90,"late setup bank select does not retroactively change the committed Sound");
    address(track.cvs[0].soundAt(0,0),121,0,7,"a CV PC commits setup's pending bank state");
    const auto raw=inspectKorgMidiBytes(midi({initial,first,second}),KorgMidiPatchScope::SetupAndIndependentCvs);
    const auto committed=std::find_if(raw.patches.begin(),raw.patches.end(),[](const KorgMidiPatchSelection& patch){return patch.track==0&&patch.program==90;});
    check(committed!=raw.patches.end()&&committed->msb==121&&committed->lsb==14&&committed->usedByNotes,"later bank selects cannot rewrite an existing committed patch record");
    Track unknown;unknown.meter(0,4,2);unknown.tempo(0,500000);unknown.event(0,{0xB0,0,121});unknown.end(384);
    read=readPa5xStyleBytes(style(scene("Var1.scn",4,2,midi({unknown,second}))));check(read.valid,"undeclared source fields do not invalidate readable metadata");
    const auto* sound=read.sections[static_cast<std::size_t>(Element::Var1)].tracks[0].cvs[0].soundAt(0,0);
    address(sound,121,-1,-1,"unknown LSB and Program stay minus one instead of GM bank/program zero");check(!sound->sound.addressComplete,"unknown raw address is never presented as a resolved Sound");
}
void mixedMetersAndChanges(){
    Bytes scenes=scene("Var1.scn",4,2,twoCvs(384));append(scenes,scene("Intro1.scn",3,2,twoCvs(288,3,2)));append(scenes,scene("Intro2.scn",8,3,twoCvs(384,8,3)));append(scenes,scene("End1.scn",7,3,twoCvs(336,7,3,true)));
    const auto read=readPa5xStyleBytes(style(scenes));check(read.valid,"mixed-meter metadata remains readable");
    const auto& variation=read.sections[static_cast<std::size_t>(Element::Var1)];const auto& intro=read.sections[static_cast<std::size_t>(Element::Intro1)];const auto& ending=read.sections[static_cast<std::size_t>(Element::Ending1)];
    check(variation.numerator==4&&variation.denominator==4&&intro.numerator==3&&intro.denominator==4&&ending.numerator==7&&ending.denominator==8,"first Variation is not substituted for another selected section's meter");
    const auto& raw=inspectedClip(read,Element::Ending1);
    check(raw.timeSignatures.size()==3&&raw.timeSignatures[0].tick==0&&raw.timeSignatures[0].track==0&&raw.timeSignatures[1].tick==368&&raw.timeSignatures[1].track==1&&raw.timeSignatures[1].numerator==3&&raw.timeSignatures[2].tick==384&&raw.timeSignatures[2].denominator==8,"all physical FF58 changes survive even when runtime CV boundary is unsupported");
    check(ending.meterKnown&&ending.numerator==7&&ending.denominator==8,"MIDI change events do not overwrite the original Scene declaration");
    check(ending.tracks[0].setupTimingKnown&&ending.tracks[0].cvs[0].timeSignatureChanges.size()==2&&ending.tracks[0].cvs[0].timeSignatureChanges[0].tick==32&&ending.tracks[0].cvs[0].timeSignatureChanges[1].tick==48,"metadata CV mapping preserves meter changes independently of constant-meter playback support");
    const auto& equivalent=read.sections[static_cast<std::size_t>(Element::Intro2)];check(equivalent.numerator==8&&equivalent.denominator==8,"8/8 is not simplified to 4/4 when reading the author's meter");
}
void unprovenBoundaryAndInvalidSource(){
    Track initial;initial.meter(0,4,2);initial.tempo(0,500000);initial.event(0,{0xB0,0,121});initial.event(0,{0xB0,32,8});initial.event(0,{0xC0,2});initial.event(0,{0x90,55,90});initial.event(1,{0x80,55,0});initial.end(384);
    Track cv;cv.event(384,{0xC0,10});cv.event(384,{0x90,60,90});cv.tempo(396,300000);cv.meter(408,3,2);cv.event(409,{0x80,60,0});cv.end(480);
    const auto read=readPa5xStyleBytes(style(scene("Var1.scn",4,2,midi({initial,cv}))));check(read.valid,"unproven CV layout does not erase readable original metadata");
    const auto& track=read.sections[static_cast<std::size_t>(Element::Var1)].tracks[0];
    check(!track.setupTimingKnown&&!track.cvs[0].available&&!track.unscopedBankProgramEvents.empty()&&track.unscopedTempoChanges.size()==2&&track.unscopedTimeSignatureChanges.size()==2,"unproven physical mapping retains absolute unscoped events instead of invented CV-relative timing");
    const auto invalid=readPa5xStyleBytes(style(scene("Var1.scn",4,2,twoCvs(384)),0));check(!invalid.valid&&invalid.originalBpm==0,"missing source tempo never becomes an invented 120 BPM");
    const auto fractional=readPa5xStyleBytes(style(scene("Var1.scn",4,2,twoCvs(384)),567891));check(fractional.valid&&std::fabs(fractional.originalBpm-60000000.0/567891.0)<1e-12,"noninteger original tempo is retained without rounding to a display value");
}
void walk(const std::string& directory,std::vector<std::string>& files){DIR* dir=opendir(directory.c_str());check(dir!=nullptr,"corpus directory opens");while(auto* entry=readdir(dir)){const std::string name=entry->d_name;if(name=="."||name=="..")continue;const auto path=directory+"/"+name;struct stat status{};check(stat(path.c_str(),&status)==0,"corpus path stats");if(S_ISDIR(status.st_mode))walk(path,files);else if(name.size()>4&&name.substr(name.size()-4)==".stg")files.push_back(path);}closedir(dir);}
void corpus(const std::string& directory){
    std::vector<std::string> files;walk(directory,files);std::sort(files.begin(),files.end());std::size_t elements=0,clips=0,physicalTracks=0,tempos=0,meters=0,mixed=0;
    for(const auto& path:files){const auto read=readPa5xStyleFile(path);check(read.valid&&read.inspection!=nullptr,"every actual style has readable metadata");const auto& inspected=*read.inspection;check(read.originalBpm==inspected.tempoBpm,"reader preserves exact original Stage tempo");std::set<std::pair<int,int>> signatures;
        for(const auto& element:inspected.elements){++elements;const auto& section=read.sections[static_cast<std::size_t>(element.element)];check(section.available&&section.meterKnown&&section.numerator==element.numerator&&section.denominator==element.denominator,"each actual section preserves its own Scene meter");signatures.emplace(section.numerator,section.denominator);
            for(const auto& clip:element.clips){++clips;physicalTracks+=clip.midiTracks.size();tempos+=clip.tempos.size();meters+=clip.timeSignatures.size();const auto& track=section.tracks[static_cast<std::size_t>(clip.track)];check(track.present&&track.ppq==clip.ppq,"each original logical track and PPQ survives");check(track.setupTempoChanges.size()==1&&track.setupTimeSignatureChanges.size()==1,"actual setup tempo and meter each retain their one physical event");for(const auto& cv:track.cvs)check(cv.tempoChanges.empty()&&cv.timeSignatureChanges.empty(),"actual no-change CVs have no invented tempo or meter events");}
        }mixed+=signatures.size()>1U;
    }
    check(files.size()==681&&elements==8817&&clips==67566&&physicalTracks==140971&&tempos==67566&&meters==67566&&mixed==45,"complete actual corpus metadata counts match independent physical-file audit");
    std::cout<<"Actual Style reads: "<<files.size()<<" files, "<<elements<<" elements, "<<clips<<" clips, "<<mixed<<" mixed-meter styles\n";
}
}
int main(int argc,char** argv){exactCvStateAndOrder();pendingSetupAndUnknown();mixedMetersAndChanges();unprovenBoundaryAndInvalidSource();if(argc==2)corpus(argv[1]);std::puts("Pa5X Style read: PASS (original tempo/meters, per-CV original Sounds, pending banks, ordering and full MIDI metadata)");}
