#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/arranger/Pa5xProgramSnapshot.h"
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SampleStream.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

using namespace silveton::arranger;
using namespace silveton::sampler;
namespace {
using Bytes=std::vector<std::uint8_t>;
void be16(Bytes& b,unsigned value){b.push_back(static_cast<std::uint8_t>(value>>8U));b.push_back(static_cast<std::uint8_t>(value));}
void be32(Bytes& b,std::uint32_t value){for(int shift=24;shift>=0;shift-=8)b.push_back(static_cast<std::uint8_t>(value>>shift));}
void set16(Bytes& b,std::size_t at,unsigned value){b[at]=static_cast<std::uint8_t>(value>>8U);b[at+1U]=static_cast<std::uint8_t>(value);}
void set32(Bytes& b,std::size_t at,std::uint32_t value){for(int shift=24;shift>=0;shift-=8)b[at++]=static_cast<std::uint8_t>(value>>shift);}
void append(Bytes& b,const Bytes& input){b.insert(b.end(),input.begin(),input.end());}
void chunk(Bytes& b,std::uint32_t tag,const Bytes& input){be32(b,tag);be32(b,static_cast<std::uint32_t>(input.size()));append(b,input);}
void property(Bytes& b,unsigned tag,const Bytes& input){be16(b,tag);be16(b,static_cast<unsigned>(input.size()));append(b,input);}

struct Record {unsigned kind,major,bank,slot,uid;std::uint32_t tag;Bytes body;};
Bytes container(const std::vector<Record>& records){
    Bytes table;
    for(const auto& record:records){
        Bytes row;be16(row,record.kind==4U?3U:4U);
        property(row,0U,{static_cast<std::uint8_t>(record.kind),static_cast<std::uint8_t>(record.bank),static_cast<std::uint8_t>(record.slot)});
        property(row,1U,{static_cast<std::uint8_t>(record.major),0U});
        Bytes name{'S','y','n','t','h','e','t','i','c',0};
        if(record.kind==4U)name.resize(28U,0U);
        property(row,2U,name);
        if(record.kind!=4U)property(row,4U,{0,0,0,0,0,0,0,static_cast<std::uint8_t>(record.uid)});
        be32(row,0U);be16(table,static_cast<unsigned>(row.size()));append(table,row);
    }
    Bytes children;chunk(children,0x02000018U,{11,0,0,0,0,0,0,'K','O','R','F',0});
    const auto toc=static_cast<std::uint32_t>(children.size()+8U);chunk(children,0x05010018U,table);
    Bytes refs{'K','B','E','G'};be32(refs,toc);
    for(const auto& record:records){be32(refs,static_cast<std::uint32_t>(children.size()+8U));chunk(children,record.tag,record.body);}
    append(refs,{'K','E','N','D'});be32(refs,static_cast<std::uint32_t>(records.size()+1U));
    chunk(children,0xFE000018U,refs);Bytes root;chunk(root,0x01000114U,children);return root;
}
Bytes literalOc31(const Bytes& decoded){
    assert(decoded.size()<65536U);Bytes encoded{'O','C','3','1'};
    for(unsigned shift=0U;shift<32U;shift+=8U)encoded.push_back(static_cast<std::uint8_t>(decoded.size()>>shift));
    encoded.push_back(1U);be16(encoded,static_cast<unsigned>(decoded.size()));append(encoded,decoded);
    std::uint8_t checksum=0U;for(const auto value:decoded)checksum^=value;encoded.push_back(checksum);return encoded;
}
Bytes soundBank(){
    // Authored version2 Sound: one original OSC, two exact RAM UIDs,
    // input zone10..20, High/Low switch15, Scaled Velocity0..127.
    Bytes body(325U+191U,0U);body[25]=127U;body[300]=1U;
    constexpr std::size_t osc=325U,dsp=osc+67U,amp=osc+159U,eq=osc+181U;
    for(unsigned source=0U;source<2U;++source){
        const auto at=osc+14U*source;body[at+7U]=static_cast<std::uint8_t>(9U+source);
        body[at+10U]=1U;body[at+11U]=127U;
    }
    body[osc+29U]=15U;body[osc+30U]=10U;body[osc+31U]=20U;body[osc+33U]=127U;
    body[dsp+2U]=10U;body[dsp+21U]=99U;body[dsp+28U]=99U;body[dsp+43U]=99U;
    body[dsp+78U]=127U;body[dsp+80U]=127U;body[dsp+81U]=99U;
    body[osc+158U]=127U;
    body[amp+2U]=99U;body[amp+4U]=99U;body[amp+6U]=99U;body[amp+20U]=127U;
    body[eq]=1U;body[eq+1U]=99U;body[eq+2U]=12U;body[eq+3U]=165U;
    body[osc+188U]=64U;
    return container({{4U,2U,9U,7U,0U,0x10020038U,literalOc31(body)}});
}
Bytes multisampleBank(){
    Bytes body(10U+2U*111U+2U*20U+2U*166U,0U);
    set16(body,0U,3U);set16(body,2U,2U);set16(body,6U,2U);set16(body,8U,2U);
    for(unsigned n=0U;n<2U;++n){
        const auto sample=10U+111U*n;set16(body,sample+4U,0x10U);
        body[sample+80U]=static_cast<std::uint8_t>('A'+n);body[sample+103U]=static_cast<std::uint8_t>(1U+n);
        set32(body,sample+106U,48000U);body[sample+110U]=60U;
        const auto zone=232U+20U*n;set16(body,zone,n);body[zone+2U]=1U;body[zone+3U]=127U;body[zone+4U]=60U;
        const auto multi=272U+166U*n;body[multi+2U]=static_cast<std::uint8_t>('H'+n);set16(body,multi+26U,n);
        body[multi+156U]=1U;body[multi+165U]=static_cast<std::uint8_t>(9U+n);
    }
    return container({{5U,5U,0U,1U,30U,0x11050018U,body}});
}
Bytes pcmBank(){
    std::vector<Record> records;
    for(unsigned n=0U;n<2U;++n){
        Bytes body(66U+512U,0U);body[7]=static_cast<std::uint8_t>(1U+n);body[8]=1U;body[9]=16U;
        set32(body,10U,48000U);set32(body,14U,256U);set32(body,50U,1U);set32(body,54U,255U);set32(body,62U,255U);
        // Opposite-sign recordings identify the exact selected PCM UID. The
        // nonconstant tail starts after the streaming fixture's32-frame prefix.
        for(unsigned frame=0U;frame<256U;++frame){
            const auto value=4096U+(frame>=64U?(frame*37U)%512U:0U);
            set16(body,66U+2U*frame,n==0U?value:65536U-value);
        }
        records.push_back({6U,0U,0U,n,1U+n,0x12000018U,std::move(body)});
    }
    return container(records);
}
struct Fixture {
    std::string base,root;
    Fixture(){
        char pattern[]="/tmp/silveton-oscillator-import-XXXXXX";const auto* path=::mkdtemp(pattern);assert(path);
        base=path;root=base+"/Synthetic.KST";
        for(const auto* sub:{"SOUND","MULTISMP","PCM"})std::filesystem::create_directories(root+"/"+sub);
        write("SOUND/USER01.PCG",soundBank());write("MULTISMP/RAM.KMP",multisampleBank());write("PCM/RAM01.PCM",pcmBank());
    }
    ~Fixture(){std::error_code ignored;std::filesystem::remove_all(base,ignored);}
    void write(const std::string& relative,const Bytes& bytes){
        std::ofstream output(root+"/"+relative,std::ios::binary);
        output.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));assert(output);
    }
};

void checkImported(const ProgramPtr& program){
    assert(program&&program->layers.size()==2U);
    bool highSeen=false,lowSeen=false;
    for(const auto& layer:program->layers){
        assert(layer.sourceOscillatorDsp);const auto& source=*layer.sourceOscillatorDsp;
        assert(source.velocityZonePresent&&source.velocityZoneRaw==(std::array<std::uint8_t,2>{{10U,20U}}));
        assert(source.scaledVelocityDecoded&&source.scaledVelocityRaw==(std::array<std::uint8_t,2>{{0U,127U}}));
        assert(sourceScaledVelocitySupported(source)&&source.scaledVelocityRaw!=source.velocityZoneRaw);
        assert(encodeSourceOscillatorDsp(source).size()==181U);
        assert(source.equalizerRaw==(std::array<std::uint8_t,6>{{1U,99U,12U,165U,0U,0U}}));
        assert(sourceOscillatorSupport(source).equalizerComplete);
        assert(layer.sourceAmpEnvelope.enabled&&layer.sourceAmpEnvelope.levels[3]==99U);
        assert(layer.multisample&&layer.multisample->zones.size()==1U);
        const auto& sample=layer.multisample->zones[0].sample;assert(sample&&sample->valid());
        assert(sample->frameCount()==256U&&sample->sampleRate==48000U&&sample->channels==1U);
        assert(sample->rootKey==60U&&sample->loop.enabled&&sample->loop.startFrame==1U&&sample->loop.endFrame==256U);
        for(unsigned frame=0U;frame<256U;++frame){
            float value=0.0F;
            if(frame<sample->preloadedFrameCount())value=sample->interleaved[frame];
            else{assert(sample->stream);value=sample->stream->readFrame(frame,0U);}
            const float expected=static_cast<float>(4096U+(frame>=64U?(frame*37U)%512U:0U))/32768.0F;
            assert(value==(source.highSource?expected:-expected));
        }
        if(source.highSource){highSeen=true;assert(layer.velocityLow==15U&&layer.velocityHigh==20U);assert(sample->interleaved[0]>.1F);}
        else{lowSeen=true;assert(layer.velocityLow==10U&&layer.velocityHigh==14U);assert(sample->interleaved[0]<-.1F);}
    }
    assert(highSeen&&lowSeen);
}
std::vector<float> renderNote(const ProgramPtr& program,std::uint8_t velocity){
    auto settings=std::make_shared<EngineState>();settings->combi.uppers[0].program=program;
    settings->combi.uppers[0].enabled=true;settings->combi.uppers[0].breathEnabled=false;
    settings->global.masterGainDb=0.0F;settings->global.limiterEnabled=false;
    SamplerEngine engine;engine.prepare(48000.0,256U);engine.setState(settings);assert(engine.postNoteOn(0U,60U,velocity));
    std::array<float,512> warm{};for(unsigned i=0U;i<8U;++i)engine.render(warm.data(),256U);
    std::vector<float> result(4096U);
    for(unsigned frame=0U;frame<2048U;frame+=256U)engine.render(result.data()+2U*frame,256U);
    for(const auto value:result)assert(std::isfinite(value));
    return result;
}
double rms(const std::vector<float>& data){double sum=0.0;for(const auto value:data)sum+=static_cast<double>(value)*value;return std::sqrt(sum/data.size());}

class UnavailableStream final : public SampleStream {
public:
    mutable unsigned reads{0U};
    std::uint64_t frameCount() const noexcept override{return 256U;}
    std::uint16_t channels() const noexcept override{return 1U;}
    std::uint32_t sampleRate() const noexcept override{return 48000U;}
    float readFrame(std::uint64_t,std::uint16_t) const noexcept override{++reads;return 0.0F;}
};

class OwnedRawStream final : public SampleStream {
public:
    Bytes bytes;
    std::uint8_t format{RawPcmView::kNone};
    std::uint64_t viewFrames{4U};
    mutable unsigned reads{0U};
    std::uint64_t frameCount() const noexcept override{return 4U;}
    std::uint16_t channels() const noexcept override{return 2U;}
    std::uint32_t sampleRate() const noexcept override{return 48000U;}
    float readFrame(std::uint64_t,std::uint16_t) const noexcept override{++reads;return 0.0F;}
    RawPcmView rawView() const noexcept override{return {bytes.data(),viewFrames,2U,format};}
};

void rawPcmExportVariants(){
    Fixture fixture;
    const std::array<float,8> expected{{-1.0F,-.5F,0.0F,.25F,.5F,.75F,-.25F,.875F}};
    for(const auto format:{RawPcmView::kPcm16,RawPcmView::kPcm24,RawPcmView::kFloat32}){
        auto stream=std::make_shared<OwnedRawStream>();stream->format=format;
        const unsigned sampleBytes=format==RawPcmView::kPcm16?2U:format==RawPcmView::kPcm24?3U:4U;
        for(const float value:expected){
            std::uint32_t bits=0U;
            if(format==RawPcmView::kFloat32)std::memcpy(&bits,&value,sizeof(bits));
            else bits=static_cast<std::uint32_t>(static_cast<std::int32_t>(value*(sampleBytes==2U?32768.0F:8388608.0F)));
            for(unsigned byte=0U;byte<sampleBytes;++byte)stream->bytes.push_back(static_cast<std::uint8_t>(bits>>(8U*byte)));
        }
        auto sample=std::make_shared<SampleData>();sample->name="Authored raw export";
        sample->sourcePath=fixture.base+"/resource.PCM";sample->sourceIdentity="synthetic:raw-view:"+std::to_string(format);
        sample->channels=2U;sample->totalFrames=4U;sample->interleaved.assign(expected.begin(),expected.begin()+2U);
        sample->rootKey=49U;sample->fineTuneCents=13.75F;sample->loop={true,1U,4U,1U};sample->stream=stream;
        SetData source;source.samples.push_back({23U,sample});
        const auto path=fixture.base+"/raw-"+std::to_string(format)+".svset";
        assert(SetPackage::save(path,source).success&&stream->reads==0U);
        const auto restored=SetPackage::load(path);assert(restored.ok()&&restored.data.samples.size()==1U);
        const auto& after=restored.data.samples[0].sample;
        assert(after&&after->frameCount()==4U&&after->channels==2U&&after->sampleRate==48000U);
        assert(after->sourceIdentity==sample->sourceIdentity&&after->name==sample->name);
        assert(after->rootKey==49U&&after->fineTuneCents==13.75F&&after->loop.enabled&&
            after->loop.startFrame==1U&&after->loop.endFrame==4U&&after->loop.crossfadeFrames==1U);
        assert(after->interleaved==std::vector<float>(expected.begin(),expected.end()));

        // A validated standalone exported WAV follows the unchanged copy path.
        const auto copy=fixture.base+"/copy-"+std::to_string(format)+".svset";
        assert(SetPackage::save(copy,restored.data).success);
        const auto copied=SetPackage::load(copy);assert(copied.ok());
        assert(copied.data.samples[0].sample->interleaved==after->interleaved);

        // A short view or unsupported format is rejected before any stream
        // fallback is called, and the already saved complete recording survives.
        stream->viewFrames=3U;assert(!SetPackage::save(path,source).success);
        stream->viewFrames=4U;stream->format=255U;assert(!SetPackage::save(path,source).success);
        assert(stream->reads==0U);
        const auto previous=SetPackage::load(path);assert(previous.ok());
        assert(previous.data.samples[0].sample->interleaved==after->interleaved);
    }
}
void importPersistAndRender(bool streamed){
    Fixture fixture;const auto index=indexPa5xKst(fixture.root);
    assert(index.recognized&&!index.cancelled);
    Pa5xMultisampleBuildOptions options;options.endConvention=Pa5xSampleEndConvention::InclusiveIndex;
    options.allowMemoryFallback=true;
    if(streamed){options.streamCacheDirectory=fixture.base+"/decoded";options.preloadFrames=32U;}
    Pa5xMultisampleCache cache;Pa5xSetBank bank;
    const bool loaded=bank.loadForSamplePlayback(index,{},nullptr,&options,&cache);
    if(!loaded)for(const auto& issue:bank.status().issues)std::fprintf(stderr,"%s: %s\n",issue.code.c_str(),issue.message.c_str());
    assert(loaded&&bank.status().indexed);
    const auto imported=buildPa5xSampleProgram(bank,121,64,7,options,&cache);
    if(!imported)for(const auto& warning:imported.warnings)std::fprintf(stderr,"%s\n",warning.c_str());
    assert(imported&&imported.sourceCount==2U&&imported.loadedSources==2U&&imported.decodedSampleCount==2U);
    checkImported(imported.program);
    for(const auto& layer:imported.program->layers){
        const auto& sample=layer.multisample->zones[0].sample;
        assert(bool(sample->stream)==streamed&&sample->preloadedFrameCount()==(streamed?32U:256U));
    }
    const auto low=renderNote(imported.program,14U),high=renderNote(imported.program,15U),full=renderNote(imported.program,20U);
    assert(low.back()<0.0F&&high.back()>0.0F&&rms(full)>.01);
    assert(std::abs(rms(low)/rms(full)-.4)<.00002&&std::abs(rms(high)/rms(full)-.5)<.00002);

    SetData native;native.name="Synthetic imported source OSC";native.programs.push_back({{121,64,7},imported.program});
    const auto manifest=fixture.base+"/native.svset";
    const auto saved=SetPackage::save(manifest,native);
    if(!saved.success)std::fprintf(stderr,"Native save: %s\n",saved.error.c_str());
    assert(saved.success);
    const auto restored=SetPackage::load(manifest);
    if(!restored.ok())std::fprintf(stderr,"Native reload: %s\n",restored.error.c_str());
    assert(restored.ok()&&restored.data.programs.size()==1U);
    const auto nativeProgram=restored.data.programs[0].program;checkImported(nativeProgram);
    for(std::size_t i=0U;i<nativeProgram->layers.size();++i){
        const auto& before=imported.program->layers[i].multisample->zones[0].sample;
        const auto& after=nativeProgram->layers[i].multisample->zones[0].sample;
        assert(before->sourceIdentity==after->sourceIdentity&&before->name==after->name);
        assert(std::filesystem::path(after->sourcePath).extension()==".wav");
    }
    assert(renderNote(nativeProgram,14U)==low&&renderNote(nativeProgram,15U)==high&&renderNote(nativeProgram,20U)==full);

    if(streamed){
        auto unavailable=std::make_shared<UnavailableStream>();
        auto broken=std::make_shared<Program>(*imported.program);
        auto multi=std::make_shared<Multisample>(*broken->layers[0].multisample);
        auto sample=std::make_shared<SampleData>(*multi->zones[0].sample);sample->stream=unavailable;
        multi->zones[0].sample=sample;broken->layers[0].multisample=multi;
        auto bad=native;bad.programs[0].program=broken;
        const auto rejected=SetPackage::save(manifest,bad);
        assert(!rejected.success&&rejected.error.find("complete synchronous PCM view")!=std::string::npos);
        assert(unavailable->reads==0U); // no silent realtime fallback in an export
        const auto previous=SetPackage::load(manifest);assert(previous.ok());
        checkImported(previous.data.programs[0].program);
        assert(renderNote(previous.data.programs[0].program,15U)==high);
    }

    const auto prepared=fixture.base+"/prepared.bin";
    assert(savePa5xProgramSnapshot(prepared,{{121,64,7,imported.program}},{}));
    // Prove the prepared graph reopens from its own persisted data, without
    // reparsing the original PCG/KMP/PCM fixture for the second render.
    std::filesystem::remove_all(fixture.root);
    std::vector<Pa5xPreparedProgram> preparedPrograms;std::vector<std::string> warnings;
    const auto cacheDirectory=streamed?options.streamCacheDirectory:fixture.base;
    assert(loadPa5xProgramSnapshot(prepared,cacheDirectory,preparedPrograms,warnings));
    assert(preparedPrograms.size()==1U);checkImported(preparedPrograms[0].sound);
    assert(renderNote(preparedPrograms[0].sound,14U)==low&&renderNote(preparedPrograms[0].sound,15U)==high&&
        renderNote(preparedPrograms[0].sound,20U)==full);
}
}

int main(){
    importPersistAndRender(false);importPersistAndRender(true);rawPcmExportVariants();
    std::puts("PASS authored PCG/KMP/PCM bank -> actual importer -> RAM/streamed native+prepared persistence -> complete waveform and identical sampler audio; original OSC zone across High/Low split; complete stereo PCM16/24/float export; missing/short/unknown synchronous streams rejected atomically");
}
