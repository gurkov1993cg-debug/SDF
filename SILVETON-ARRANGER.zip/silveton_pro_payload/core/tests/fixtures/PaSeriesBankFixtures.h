#pragma once
// Authored synthetic KORF fixtures. No factory/user sound or Style bytes.
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>
#include <cstdint>

namespace silveton::test::pa_series {
using Bytes=std::vector<std::uint8_t>;
inline void check(bool value,const char* why) {
    if(!value){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}
}
inline void be16(Bytes& b,unsigned n){b.push_back(static_cast<std::uint8_t>(n>>8U));b.push_back(static_cast<std::uint8_t>(n));}
inline void be32(Bytes& b,std::uint32_t n){for(int s=24;s>=0;s-=8)b.push_back(static_cast<std::uint8_t>(n>>static_cast<unsigned>(s)));}
inline void append(Bytes& b,const Bytes& a){b.insert(b.end(),a.begin(),a.end());}
inline void chunk(Bytes& b,std::uint32_t tag,const Bytes& a){be32(b,tag);be32(b,static_cast<std::uint32_t>(a.size()));append(b,a);}

inline Bytes track(std::uint32_t tag,unsigned index) {
    Bytes b(tag==0x09000008U?242U:382U,0);
    b[3]=static_cast<std::uint8_t>(index);
    b[9]=b[11]=127;b[12]=121;b[13]=64;b[15]=static_cast<std::uint8_t>(20U+index);
    b[16]=static_cast<std::uint8_t>(90U+index);b[17]=64;
    // Four distinct parts exercise zero, both signs and boundary values.
    const std::uint8_t detune[]{0,64,127,59},transpose[]{220,0,36,244};
    b[18]=detune[index];b[19]=transpose[index];
    b[31]=static_cast<std::uint8_t>(index==0?0:127U-index);
    b[32]=static_cast<std::uint8_t>(index==3?127:40U+index);
    b[35]=static_cast<std::uint8_t>(index&1U);b[40]=static_cast<std::uint8_t>(index==0?0:12);
    b[43]=220;b[44]=3;b[45]=36;
    // Unknown native controls and Insert FX data must survive unchanged.
    b[110]=0xF9;b.back()=0xA6;
    return b;
}
inline Bytes keyboard(std::uint32_t tag,bool badSize=false,bool factory=false) {
    Bytes body,id;be32(id,4);id.resize(37,0);const std::string title="Original performance";
    std::copy(title.begin(),title.end(),id.begin()+4);chunk(body,0x0F000008U,id);
    chunk(body,0x22000008U,{0,60});
    for(unsigned i=0;i<4;++i){auto b=track(tag,i);if(factory)b[12]=b[13]=b[15]=0;if(badSize&&i==2)b.pop_back();chunk(body,tag,b);}
    Bytes wrapper;chunk(wrapper,tag==0x09000008U?0x0A000000U:0x0A010000U,body);return wrapper;
}
struct BankObject {std::uint8_t kind;std::uint32_t tag;Bytes bytes;};
inline Bytes nativeBank(const std::vector<BankObject>& objects,bool protectedRecord=false) {
    // Native KORF property directory with original slot17 and bank2. There is
    // no alphabetical or UI-position approximation in this fixture.
    Bytes directory;
    for(const auto& object:objects){
        Bytes row;be16(row,protectedRecord?3:2);
        be16(row,0);be16(row,3);append(row,{object.kind,2,17});
        be16(row,2);be16(row,8);append(row,{'S','a','v','e','d',' ','K','S'});
        if(protectedRecord){be16(row,3);be16(row,1);row.push_back(1);}
        be32(row,0x12345678U);be16(directory,static_cast<unsigned>(row.size()));append(directory,row);
    }
    Bytes b;chunk(b,0x02000018U,{11,0,0,0,0,0,0,'K','O','R','F',0});
    const auto toc=static_cast<std::uint32_t>(b.size()+8U);chunk(b,0x05010118U,directory);
    Bytes refs;be32(refs,0x4B424547U);be32(refs,toc);
    for(const auto& object:objects){be32(refs,static_cast<std::uint32_t>(b.size()+8U));chunk(b,object.tag,object.bytes);}
    be32(refs,0x4B454E44U);be32(refs,static_cast<std::uint32_t>(objects.size()+1U));
    chunk(b,0xFE000018U,refs);Bytes root;chunk(root,0x01000114U,b);return root;
}
inline Bytes bank(const Bytes& resource,bool protectedRecord=false){return nativeBank({{1,0x09000008U,resource}},protectedRecord);}

inline Bytes phraseBytes(const Bytes& midi,const Bytes& tail) {
    Bytes b(6,0);be16(b,static_cast<unsigned>(midi.size()));append(b,midi);append(b,tail);return b;
}
inline Bytes styleBank(bool conflictingMixer=false,bool identicalDuplicate=false,bool factory=false) {
    Bytes pool;chunk(pool,0x01000008U,{0,0,0,2,0,1,0,1});
    chunk(pool,0x04000008U,phraseBytes({1,60,228,0x83,0x80,0,60,128,9,47,0,0},{0,0}));
    Bytes style;chunk(style,0x01000008U,{1,'A',0,0,0,0,3});chunk(style,0x02000000U,pool);
    for(unsigned index=0;index<2;++index){
        Bytes section,table{1,34,24};table.resize(27,0);chunk(section,0x01010108U,table);
        Bytes parts(80,0);
        for(unsigned t=0;t<8;++t){parts[6*t]=100;parts[6*t+1]=121;parts[6*t+2]=64;parts[6*t+3]=static_cast<std::uint8_t>(20U+index);parts[6*t+5]=127;}
        if(factory)for(unsigned t=0;t<8;++t)parts[6*t+1]=parts[6*t+2]=parts[6*t+3]=0;
        chunk(section,0x02000308U,parts);
        chunk(section,0x03000008U,phraseBytes({9,126,0,2,3,0,0x83,0x80,9,47,0,0},{1,0,3}));
        chunk(style,0x03000000U,section);
    }
    Bytes payload;chunk(payload,0x01040000U,style);
    Bytes mixer;chunk(mixer,0x09010108U,track(0x09010108U,3));
    if(conflictingMixer||identicalDuplicate){
        auto duplicate=track(0x09010108U,3);
        if(conflictingMixer)duplicate[31]=5;
        chunk(mixer,0x09010108U,duplicate);
    }
    Bytes effect(73,0);effect[4]=1;effect[6]=2;effect[7]=55;effect[72]=127;
    chunk(mixer,0x1D000008U,effect);
    Bytes settings;chunk(settings,0x04000108U,{0,0,0,15,0,0,0,120});chunk(settings,0x05010000U,mixer);
    Bytes performance;chunk(performance,0x01000000U,settings);
    return nativeBank({{2,0x06000008U,payload},{7,0x09000008U,performance}});
}
class File {
    std::string base_;
public:
    std::string path;
    explicit File(const std::string& name="USER02.PRF") {
        char base[]="/tmp/silveton-pa-series-XXXXXX";auto* result=::mkdtemp(base);
        check(result!=nullptr,"temporary directory");base_=result;path=base_+"/"+name;
    }
    ~File(){::unlink(path.c_str());::rmdir(base_.c_str());}
    void write(const Bytes& b){std::ofstream f(path,std::ios::binary);f.write(reinterpret_cast<const char*>(b.data()),static_cast<std::streamsize>(b.size()));check(bool(f),"fixture write");}
};

} // namespace silveton::test::pa_series
