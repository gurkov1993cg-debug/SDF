#include "silveton/arranger/Pa5xSampleIndex.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

using namespace silveton::arranger;

namespace {
using Bytes = std::vector<std::uint8_t>;
constexpr std::uint64_t fixtureId = 0x0102030405060708ULL;
constexpr std::array<int, 7> fixtureFrames{{-32768, -1024, -1, 0, 1, 1024, 32767}};

void u16(Bytes& out, std::size_t value) {
    out.push_back(static_cast<std::uint8_t>(value >> 8U)); out.push_back(static_cast<std::uint8_t>(value));
}
void u32(Bytes& out, std::size_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) out.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
void set32(Bytes& out, std::size_t offset, std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) out[offset++] = static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift));
}
std::uint32_t get32(const Bytes& bytes, std::size_t offset) {
    assert(offset <= bytes.size() && bytes.size() - offset >= 4);
    std::uint32_t value = 0; for (unsigned i = 0; i < 4; ++i) value = (value << 8U) | bytes[offset + i]; return value;
}
std::uint64_t get64(const Bytes& bytes, std::size_t offset) {
    assert(offset <= bytes.size() && bytes.size() - offset >= 8);
    std::uint64_t value = 0; for (unsigned i = 0; i < 8; ++i) value = (value << 8U) | bytes[offset + i]; return value;
}
void append(Bytes& out, const Bytes& bytes) { out.insert(out.end(), bytes.begin(), bytes.end()); }
void chunk(Bytes& out, std::uint32_t tag, const Bytes& body) {
    u32(out, tag); u32(out, body.size()); append(out, body);
}
void property(Bytes& out, unsigned tag, const Bytes& body) { u16(out, tag); u16(out, body.size()); append(out, body); }

Bytes fixture(bool nested) {
    Bytes properties; u16(properties, 4);
    property(properties, 0, {6, 0, 0}); property(properties, 1, {static_cast<std::uint8_t>(nested ? 2 : 0), 0});
    property(properties, 2, {'L', 'i', 'n', 'e', 'a', 'r', 0}); property(properties, 4, {1, 2, 3, 4, 5, 6, 7, 8}); u32(properties, 0);
    Bytes toc; u16(toc, properties.size()); append(toc, properties);
    Bytes bytes; u32(bytes, 0x01000114U); u32(bytes, 0);
    chunk(bytes, 0x02000018U, {0x0B, 0, 0, 0, 0, 0, 0, 'K', 'O', 'R', 'F', 0});
    chunk(bytes, 0x05010018U, toc);
    Bytes metadata(66, 0); const Bytes id{1, 2, 3, 4, 5, 6, 7, 8}; std::copy(id.begin(), id.end(), metadata.begin());
    metadata[8] = 1; metadata[9] = 16; set32(metadata, 10, 44115); set32(metadata, 14, fixtureFrames.size());
    set32(metadata, 50, 2); set32(metadata, 54, fixtureFrames.size()); set32(metadata, 62, fixtureFrames.size());
    Bytes audio;
    for (const int value : fixtureFrames) {
        const auto encoded = static_cast<std::uint16_t>(value);
        if (nested) { audio.push_back(static_cast<std::uint8_t>(encoded)); audio.push_back(static_cast<std::uint8_t>(encoded >> 8U)); }
        else u16(audio, encoded);
    }
    Bytes payload;
    if (nested) { chunk(payload, 0x00000008U, metadata); chunk(payload, 0x01000008U, audio); }
    else { append(payload, metadata); append(payload, audio); }
    const auto objectAt = bytes.size(); chunk(bytes, nested ? 0x12020010U : 0x12000018U, payload);
    Bytes xref{'K', 'B', 'E', 'G'}; u32(xref, 28); u32(xref, objectAt);
    append(xref, {'K', 'E', 'N', 'D'}); u32(xref, 2); chunk(bytes, 0xFE000018U, xref);
    set32(bytes, 4, static_cast<std::uint32_t>(bytes.size() - 8)); return bytes;
}

void exactSyntheticAudio() {
    for (const bool nested : {false, true}) {
        const auto bytes = fixture(nested); const auto indexed = inspectPa5xSampleBytes(bytes);
        assert(indexed.valid && indexed.objects.size() == 1);
        const auto& object = indexed.objects[0];
        assert(object.audioMetadataDecoded && object.hasId && object.resourceId == fixtureId);
        assert(object.channelTag == 1 && object.sampleFormat == 16 && object.sampleRate == 44115);
        assert(object.encodedSampleCount == fixtureFrames.size() && object.loopStart == 2);
        assert(object.rawAudioHeaderWords[8] == 2 && object.rawAudioHeaderWords[9] == fixtureFrames.size());
        assert(object.endPositionRaw == fixtureFrames.size() && object.secondaryEndPositionRaw == fixtureFrames.size());
        assert(object.audioDataOffset == object.payloadOffset + (nested ? 82U : 66U));
        assert(object.audioDataBytes == fixtureFrames.size() * 2U);
        assert(object.pcmByteOrder == (nested ? Pa5xPcmByteOrder::LittleEndian : Pa5xPcmByteOrder::BigEndian));
        const auto audio = decodePa5xLinearPcm(bytes, object);
        assert(audio && audio.sampleRate == 44115 && audio.mono.size() == fixtureFrames.size());
        for (std::size_t i = 0; i < fixtureFrames.size(); ++i)
            assert(audio.mono[i] == static_cast<float>(fixtureFrames[i]) / 32768.0F);
        auto invalid = object; invalid.audioDataOffset = bytes.size() - 1;
        assert(!decodePa5xLinearPcm(bytes, invalid));
        invalid = object; invalid.pcmByteOrder = Pa5xPcmByteOrder::Unknown;
        assert(!decodePa5xLinearPcm(bytes, invalid));
    }
}

void nestedBoundsAndRevisionGates() {
    const auto bytes = fixture(true); const auto indexed = inspectPa5xSampleBytes(bytes); assert(indexed.valid);
    const auto at = indexed.objects[0].payloadOffset;
    auto bad = bytes; set32(bad, at, 0x01000008U); assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; set32(bad, at + 4, 65); assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; set32(bad, at + 74, 0x00000008U); assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; set32(bad, at + 78, 2); assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; set32(bad, at + 22, 0xFFFFFFFFU); assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; set32(bad, at + 18, 7999); assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; bad[at + 16] = 2; assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; bad[at + 17] = 64; assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; bad[at + 8] ^= 1U; assert(!inspectPa5xSampleBytes(bad).valid);
    bad = bytes; bad[at - 5] = 0x18; assert(!inspectPa5xSampleBytes(bad).valid);
}

Bytes read(const char* path) {
    std::ifstream input(path, std::ios::binary | std::ios::ate); assert(input);
    const auto length = input.tellg(); assert(length > 0);
    Bytes bytes(static_cast<std::size_t>(length)); input.seekg(0);
    input.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size())); assert(input); return bytes;
}

void uploadedCorpus(const char* pcmPath, const char* kmpPath) {
    const auto bytes = read(pcmPath); const auto index = inspectPa5xSampleBytes(bytes);
    const auto kmp = inspectPa5xSampleFile(kmpPath);
    assert(index.valid && index.objects.size() == 93 && kmp.valid && kmp.multisampleMappingDecoded);
    std::size_t linear = 0, predictive = 0, exclusiveEnds = 0; std::uint64_t audioBytes = 0;
    for (const auto& object : index.objects) {
        assert(object.versionMajor == 2 && object.versionMinor == 0 && object.payloadFlags == 0x10);
        assert(object.audioMetadataDecoded && object.channelTag == 1 && object.hasId && !object.encrypted);
        const auto at = object.payloadOffset;
        assert(get32(bytes, at) == 8 && get32(bytes, at + 4) == 66 && get32(bytes, at + 74) == 0x01000008U);
        assert(get64(bytes, at + 8) == object.resourceId);
        assert(object.audioDataOffset == at + 82 && object.audioDataBytes == object.payloadBytes - 82);
        assert(get32(bytes, at + 78) == object.audioDataBytes);
        assert(get32(bytes, at + 18) == object.sampleRate && get32(bytes, at + 22) == object.encodedSampleCount);
        const auto end = get32(bytes, at + 62);
        assert(object.loopStart < object.encodedSampleCount && object.loopStart <= end && end <= object.encodedSampleCount);
        assert(get32(bytes, at + 70) == end); exclusiveEnds += end == object.encodedSampleCount ? 1U : 0U;
        const auto match = std::find_if(kmp.samples.begin(), kmp.samples.end(), [&](const Pa5xKmpSample& sample) { return sample.resourceId == object.resourceId; });
        assert(match != kmp.samples.end() && match->sampleRate == object.sampleRate && match->name == object.name);
        audioBytes += object.audioDataBytes;
        if (object.sampleFormat == 16) {
            ++linear; assert(object.pcmByteOrder == Pa5xPcmByteOrder::LittleEndian);
            const auto decoded = decodePa5xLinearPcm(bytes, object);
            assert(decoded && decoded.sampleRate == object.sampleRate && decoded.mono.size() == object.encodedSampleCount);
            assert(object.audioDataBytes == decoded.mono.size() * 2U);
            for (std::size_t frame = 0; frame < decoded.mono.size(); ++frame) {
                const auto offset = object.audioDataOffset + frame * 2U;
                int value = static_cast<int>(bytes[offset]) | (static_cast<int>(bytes[offset + 1U]) << 8);
                if (value >= 32768) value -= 65536;
                assert(decoded.mono[frame] == static_cast<float>(value) / 32768.0F);
            }
        } else { assert(object.sampleFormat == 128); ++predictive; assert(object.audioDataBytes == object.encodedSampleCount); }
    }
    assert(linear == 36 && predictive == 57 && exclusiveEnds == 8 && audioBytes == 8659478);
    assert(index.objects.front().name == "Musi 1" && index.objects.front().resourceId == 0x4546550B84036E8CULL);
    std::puts("Uploaded PCM2: 93 exact KMP links, 36 complete linear waveforms verified against original little-endian bytes");
}
} // namespace

int main(int argc, char** argv) {
    exactSyntheticAudio(); nestedBoundsAndRevisionGates();
    if (argc == 3) uploadedCorpus(argv[1], argv[2]);
    std::puts("Pa5X PCM2 audio: PASS (nested bounds, original rates/UIDs, S16LE and legacy S16BE)");
    return 0;
}
