#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include <cassert>
#include <dirent.h>
#include <iostream>
#include <map>
#include <set>
#include <tuple>

using namespace silveton::arranger;
namespace {
KorgMidiChannelEvent cc(std::uint32_t tick,int number,int value,int channel=0) {return {tick,0,static_cast<std::uint8_t>(0xB0|channel),static_cast<std::uint8_t>(number),static_cast<std::uint8_t>(value),0};}
KorgMidiChannelEvent pc(std::uint32_t tick,int program,int channel=0) {return {tick,0,static_cast<std::uint8_t>(0xC0|channel),static_cast<std::uint8_t>(program),0,0};}
Pa5xPerformanceInspection fixture() {
    Pa5xPerformanceInspection result;result.recognized=true;result.valid=true;result.kind=Pa5xPerformanceKind::KeyboardSet;
    result.displayName="Real four parts";result.sourcePath="/SET/KEYBOARDSET/4.Blend.ksc";result.splitPoint=57;result.useGlobalSplit=0;
    result.upperOctaveDeclared=true;result.upperOctaveTransposeRaw=-1;
    for(int role=1;role<=4;++role){Pa5xPerformancePart part;part.track=role;part.present=true;part.mute=role==1?1:0;part.keyLow=21;part.keyHigh=108;part.velocityLow=1;part.velocityHigh=127;
        part.channelEvents={cc(24,0,0),cc(24,32,0),pc(24,0),cc(24,7,93),cc(24,10,72),cc(24,11,112)};result.parts.push_back(part);}
    return result;
}
void corpus(const std::string& path,const Pa5xSetBank& bank,std::size_t& count,std::map<Pa5xKeyboardSetSoundStatus,std::size_t>& statuses) {
    static std::set<std::tuple<int,int,int>> reported;
    DIR* directory=::opendir(path.c_str());assert(directory!=nullptr);
    while(auto* item=::readdir(directory)){const std::string name=item->d_name;if(name=="."||name=="..")continue;const auto file=path+'/'+name;
        if(item->d_type==DT_DIR){corpus(file,bank,count,statuses);continue;}
        if(name.size()<4||name.substr(name.size()-4)!=".ksc")continue;
        const auto original=inspectPa5xPerformanceFile(file);if(!original.valid||original.kind!=Pa5xPerformanceKind::KeyboardSet)continue;
        const auto read=readPa5xKeyboardSet(original,&bank);assert(read.valid&&!read.soundActivationSupported);++count;
        for(std::size_t role=0;role<4;++role){const auto& part=read.parts[role];assert(part.role==static_cast<int>(role+1)&&part.present&&part.recallSetupValid&&part.addressKnown);
            assert(part.channel==0);assert(original.parts[role].patches.size()==1);const auto& patch=original.parts[role].patches[0];
            assert(part.msb==patch.msb&&part.lsb==patch.lsb&&part.program==patch.program);
            const auto expected=bank.resolveSoundAddress(part.msb,part.lsb,part.program);
            assert(part.soundName==expected.name&&part.soundPath==expected.path);++statuses[part.status];
            if(part.status==Pa5xKeyboardSetSoundStatus::ExactUserSound)assert(!part.soundName.empty());
            if(part.status!=Pa5xKeyboardSetSoundStatus::ExactUserSound&&part.status!=Pa5xKeyboardSetSoundStatus::FactorySoundRequired&&reported.emplace(part.msb,part.lsb,part.program).second)
                std::cout<<"Unresolved "<<part.msb<<'/'<<part.lsb<<'/'<<part.program<<": "<<part.soundMessage<<'\n';
        }
    }
    ::closedir(directory);
}
}
int main(int argc,char** argv) {
    auto source=fixture();auto read=readPa5xKeyboardSet(source);
    assert(read.valid&&read.readComplete&&!read.soundActivationSupported&&read.name==source.displayName);
    assert(read.splitPoint==57&&read.useGlobalSplit==0&&read.upperOctaveTransposeKnown&&read.upperOctaveTranspose==-1);
    for(std::size_t i=0;i<4;++i){const auto& part=read.parts[i];assert(part.role==static_cast<int>(i+1)&&part.channel==0&&part.setupLastTick==24&&part.addressKnown&&part.recallSetupValid);
        assert(part.status==Pa5xKeyboardSetSoundStatus::FactorySoundRequired&&!part.soundName.empty());
        assert(part.volumeRaw==93&&part.panRaw==72&&part.expressionRaw==112&&part.keyLow==21&&part.keyHigh==108);
        assert(part.octaveTransposeKnown&&part.octaveTranspose==(i==0?0:-1));}
    source.parts[0].channelEvents.push_back(cc(48,0,121));source.parts[0].channelEvents.push_back(cc(48,32,66));
    read=readPa5xKeyboardSet(source);assert(read.parts[0].msb==0&&read.parts[0].lsb==0&&read.parts[0].program==0); // pending bank does not change selected program
    source.parts[0].channelEvents.push_back(pc(48,20));read=readPa5xKeyboardSet(source);
    assert(read.valid&&!read.readComplete&&read.parts[0].status==Pa5xKeyboardSetSoundStatus::InvalidSetup&&!read.parts[0].recallSetupValid);
    source=fixture();source.parts[0].channelEvents.push_back(pc(48,0));read=readPa5xKeyboardSet(source);assert(read.parts[0].recallSetupValid); // repeated identical selection is safe
    source=fixture();source.parts[0].channelEvents.push_back(cc(24,7,50,1));read=readPa5xKeyboardSet(source);assert(read.parts[0].status==Pa5xKeyboardSetSoundStatus::InvalidSetup&&!read.parts[0].addressKnown);
    source=fixture();source.parts[0].channelEvents.push_back({24,0,0x90,60,100,0});read=readPa5xKeyboardSet(source);assert(read.parts[0].status==Pa5xKeyboardSetSoundStatus::InvalidSetup);
    source=fixture();source.parts[0].channelEvents={pc(0,10),cc(24,0,121),cc(24,32,66)};read=readPa5xKeyboardSet(source);assert(!read.parts[0].addressKnown&&read.parts[0].status==Pa5xKeyboardSetSoundStatus::IncompleteAddress);
    source=fixture();source.parts[0].channelEvents.clear();read=readPa5xKeyboardSet(source);assert(read.parts[0].channel==-1&&!read.parts[0].addressKnown);
    source=fixture();source.parts[0].channelEvents={cc(24,0,0),cc(24,32,0),pc(24,0)};read=readPa5xKeyboardSet(source);assert(read.parts[0].volumeRaw==-1&&read.parts[0].panRaw==-1&&read.parts[0].expressionRaw==-1);
    source=fixture();source.parts[0].channelEvents.push_back(cc(48,121,0));read=readPa5xKeyboardSet(source);assert(read.parts[0].expressionRaw==-1);
    source=fixture();source.parts[0].channelEvents[0].data2=128;read=readPa5xKeyboardSet(source);assert(read.parts[0].status==Pa5xKeyboardSetSoundStatus::InvalidSetup);
    source=fixture();source.parts[0].keyLow=109;read=readPa5xKeyboardSet(source);assert(read.parts[0].status==Pa5xKeyboardSetSoundStatus::InvalidSetup);
    source=fixture();source.parts[0].track=2;assert(!readPa5xKeyboardSet(source).valid);
    // All four parts use input channel0, but their saved Sound edits differ.
    // A recall must never collapse these controls into one channel's defaults.
    source=fixture();
    for(std::size_t i=0;i<source.parts.size();++i){
        auto& events=source.parts[i].channelEvents;
        events.push_back(cc(25,73,32+static_cast<int>(i)*20));
        events.push_back(cc(25,72,100-static_cast<int>(i)*10));
        events.push_back(cc(25,5,10+static_cast<int>(i)));
        events.push_back(cc(25,65,i%2?127:0));
    }
    read=readPa5xKeyboardSet(source);
    for(std::size_t i=0;i<read.parts.size();++i){
        const auto& edits=read.parts[i].sourceSoundEdits;
        assert(edits.valid()&&edits.controller(73)==32+static_cast<int>(i)*20);
        assert(edits.controller(72)==100-static_cast<int>(i)*10);
        assert(edits.controller(5)==10+static_cast<int>(i)&&edits.controller(65)==(i%2?127:0));
        assert(edits.controller(74)==-1); // absent is not an invented centre
    }
    auto& editsEvents=source.parts[0].channelEvents;
    editsEvents.push_back(cc(26,99,1));editsEvents.push_back(cc(26,98,99));
    editsEvents.push_back(cc(26,6,91)); // NRPN1/99 Attack
    editsEvents.push_back(cc(27,101,0));editsEvents.push_back(cc(27,100,2));
    editsEvents.push_back(cc(27,6,76)); // RPN2 must not become an Attack edit
    editsEvents.push_back(cc(28,98,102));editsEvents.push_back(cc(28,6,12)); // missing NRPN MSB
    read=readPa5xKeyboardSet(source);
    assert(read.parts[0].sourceSoundEdits.controller(73)==91);
    assert(read.parts[0].sourceSoundEdits.controller(72)==100);
    assert(read.parts[0].coarseTuneRaw==76);
    editsEvents.push_back(cc(29,99,1));editsEvents.push_back(cc(29,6,12));
    editsEvents.push_back(cc(30,121,0)); // preserve Sound edits, reset selection and porta switch
    editsEvents.push_back(cc(31,6,88)); // no selection after reset
    read=readPa5xKeyboardSet(source);
    assert(read.parts[0].sourceSoundEdits.controller(73)==91&&read.parts[0].sourceSoundEdits.controller(72)==12);
    assert(read.parts[0].sourceSoundEdits.controller(65)==0);
    editsEvents.push_back(cc(32,99,1));editsEvents.push_back(cc(32,98,99));
    editsEvents.push_back(cc(32,96,0));
    read=readPa5xKeyboardSet(source);assert(read.parts[0].sourceSoundEdits.controller(73)==-1);
    editsEvents.push_back(cc(33,73,0));
    read=readPa5xKeyboardSet(source);assert(read.parts[0].sourceSoundEdits.controller(73)==0);
    assert(!readPa5xKeyboardSetBytes({}).valid);
    if(argc==2){Pa5xSetBank bank;(void)bank.load(argv[1]);assert(bank.status().recognized);std::size_t count=0;std::map<Pa5xKeyboardSetSoundStatus,std::size_t> statuses;corpus(argv[1],bank,count,statuses);assert(count==772);
        std::cout<<"Corpus: "<<count<<" Keyboard Sets /3088 exact original part selections";for(const auto& item:statuses)std::cout<<"; "<<pa5xKeyboardSetSoundStatusName(item.first)<<'='<<item.second;std::cout<<'\n';}
    std::cout<<"PASS Keyboard Set note-free recall, original CC/PC commits, four roles, controls, conflicts and exact Sound resolution\n";
}
