#include "silveton/arranger/Pa5xProgramImport.h"
#include <cassert>
#include <iostream>
using namespace silveton::arranger;
int main() {
    Pa5xPcgSound sound;
    sound.name="Addressed Sound";sound.addressKnown=true;sound.resourceClass=4;
    sound.kind=Pa5xPcgSoundKind::Sound;sound.msb=121;sound.lsb=64;sound.rawProgram=7;sound.resourceVersion={2,0};
    Pa5xSoundReferenceGraph graph;graph.referenceGraphDecoded=true;graph.resourceVersion={2,0};
    Pa5xOscillatorReferences oscillator;oscillator.high.source=Pa5xMultisampleSource::Ram;oscillator.high.multisampleId=100;
    oscillator.keyLow=60;oscillator.keyHigh=60; // Other keys must not be hidden by unresolved tuning semantics.
    graph.oscillators.push_back(oscillator);
    Pa5xSampleIndex kmp;kmp.valid=true;kmp.kind=Pa5xSampleContainerKind::Multisamples;kmp.multisampleMappingDecoded=true;
    Pa5xKmpSample a;a.name="A";a.resourceId=11;a.sampleRate=44100;
    Pa5xKmpSample b=a;b.name="B";b.resourceId=22;kmp.samples={a,b};
    Pa5xKmpKeyZone za;za.sampleIndex=0;Pa5xKmpKeyZone zb;zb.sampleIndex=1;kmp.keyZones={za,zb};
    Pa5xKmpMultisample multi;multi.name="M";multi.resourceId=100;multi.zoneCount=2;multi.zoneIndices.fill(0);multi.zoneIndices[127]=1;
    kmp.multisamples.push_back(multi);
    Pa5xSampleIndex pcm;pcm.valid=true;pcm.kind=Pa5xSampleContainerKind::PcmSamples;
    Pa5xSampleObject oa;oa.hasId=true;oa.resourceId=11;oa.audioMetadataDecoded=true;oa.sampleRate=44100;oa.sampleFormat=16;
    auto ob=oa;ob.resourceId=22;pcm.objects={oa,ob};
    std::vector<Pa5xPcmInventory> inventory{{"RAM01.PCM",&pcm}};
    auto result=inspectPa5xProgramCandidate(sound,graph,kmp,inventory);
    assert(result.found&&result.referenceGraphDecoded&&result.msb==121&&result.lsb==64&&result.program==7);
    assert(result.ramDependenciesComplete&&result.allSampleHeadersDecoded&&result.samples.size()==2);
    assert(result.multisamples.size()==1&&result.multisamples[0].mappedKeys==128&&result.hasRomDependencies);
    assert(!result.programActivationSupported&&!result.parametersDecoded&&!result.blockers.empty());
    assert(result.samples[0].pcmSourcePath=="RAM01.PCM"&&result.samples[0].pcmObjectIndex==0);
    auto switched=graph;switched.oscillators[0].velocitySwitch=1;
    switched.oscillators[0].low.source=Pa5xMultisampleSource::Ram;switched.oscillators[0].low.multisampleId=99999;
    const auto highOnly=inspectPa5xProgramCandidate(sound,switched,kmp,inventory);
    assert(highOnly.ramDependenciesComplete&&highOnly.velocityDisabledSources==1&&!highOnly.hasRomDependencies);
    switched.oscillators[0].velocitySwitch=64;switched.oscillators[0].velocityLow=64;
    assert(inspectPa5xProgramCandidate(sound,switched,kmp,inventory).ramDependenciesComplete);
    switched.oscillators[0].velocityLow=1;
    assert(!inspectPa5xProgramCandidate(sound,switched,kmp,inventory).ramDependenciesComplete);
    assert(!inspectPa5xProgramCandidate(sound,graph,kmp,{{"missing",nullptr}}).ramDependenciesComplete);
    auto wrongKmp=kmp;wrongKmp.multisampleMappingDecoded=false;
    assert(!inspectPa5xProgramCandidate(sound,graph,wrongKmp,inventory).ramDependenciesComplete);
    pcm.objects.pop_back();result=inspectPa5xProgramCandidate(sound,graph,kmp,inventory);
    assert(!result.ramDependenciesComplete&&result.samples.size()==2&&!result.samples[1].pcmPresent);
    pcm.objects={oa,ob,oa};result=inspectPa5xProgramCandidate(sound,graph,kmp,inventory);
    assert(!result.ramDependenciesComplete&&result.samples[0].ambiguous);
    pcm.objects={oa,ob};pcm.objects[0].encrypted=true;result=inspectPa5xProgramCandidate(sound,graph,kmp,inventory);
    assert(result.ramDependenciesComplete&&!result.allSampleHeadersDecoded&&!result.programActivationSupported);
    pcm.objects={oa,ob};pcm.objects[0].sampleRate=48000;assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).ramDependenciesComplete);
    pcm.objects={oa,ob};kmp.multisamples.push_back(multi);assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).ramDependenciesComplete);
    kmp.multisamples.resize(1);kmp.samples.push_back(a);assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).ramDependenciesComplete);
    kmp.samples.resize(2);kmp.multisamples[0].zoneIndices[0]=2;assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).ramDependenciesComplete);
    kmp.multisamples[0].zoneIndices[0]=0;kmp.keyZones[0].sampleIndex=9;assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).ramDependenciesComplete);
    kmp.keyZones[0].sampleIndex=0;graph.referenceGraphDecoded=false;assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).referenceGraphDecoded);
    graph.referenceGraphDecoded=true;sound.kind=Pa5xPcgSoundKind::DrumKit;assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).referenceGraphDecoded);
    sound.kind=Pa5xPcgSoundKind::Sound;sound.addressKnown=false;assert(!inspectPa5xProgramCandidate(sound,graph,kmp,inventory).found);
    const auto absent=inspectPa5xProgramCandidate({},Pa5xPcgInspection{},121,64,7,kmp,inventory);
    assert(!absent.found&&!absent.programActivationSupported&&absent.program==7);
    std::cout<<"PASS exact-address Program candidate UID dependencies, whole-key-map coverage, ambiguity/missing gates and unsupported DSP\n";
}
