#include "silveton/arranger/Pa5xProgramSnapshot.h"
#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/sampler/ProgramEditor.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SourceOscillatorDsp.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"

#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <iterator>
#include <memory>
#include <string>
#include <vector>

using namespace silveton::sampler;
namespace {
struct TemporaryDirectory {
    std::string path;
    TemporaryDirectory(){char pattern[]="/tmp/silveton-source-persistence-XXXXXX";const auto* value=::mkdtemp(pattern);assert(value);path=value;}
    ~TemporaryDirectory(){std::error_code ignored;std::filesystem::remove_all(path,ignored);}
};
std::string readBytes(const std::string& path){std::ifstream file(path,std::ios::binary);assert(file);return {std::istreambuf_iterator<char>(file),{}};}
void writeBytes(const std::string& path,const std::string& bytes){std::ofstream file(path,std::ios::binary);file.write(bytes.data(),static_cast<std::streamsize>(bytes.size()));assert(file);}
std::shared_ptr<SourceOscillatorDsp> oscillator(std::uint8_t revision,std::uint8_t index){
    auto source=std::make_shared<SourceOscillatorDsp>();source->resourceVersion=revision;source->oscillatorIndex=index;
    source->highSource=index==0U;source->layoutCorroborated=true;source->additionalDspBytes=revision>=6U?5U:revision==5U?3U:0U;
    for(std::size_t i=0;i<source->dspRaw.size();++i)source->dspRaw[i]=static_cast<std::uint8_t>((i*37U+index)%256U);
    for(std::size_t i=0;i<source->lfoRaw.size();++i)source->lfoRaw[i]=static_cast<std::uint8_t>(i*11U);
    source->pitchEnvelopePresent=true;source->pitchEnvelopeRaw={{8,3,4,55,19,20,1,2,3,4,5,6,7,8}};
    source->amplitudeEnvelopeRaw[7]=99U;source->additionalDspRaw[4]=91U;
    source->outputRawPresent=true;source->outputRaw={{9,8,7,6}};
    source->equalizerPresent=true;source->equalizerRaw={{1,2,3,4,5,6}};
    source->multisampleLevelDecoded=true;source->multisampleLevelRaw=91U;source->delayRaw=31U;
    source->scaledVelocityDecoded=true;source->scaledVelocityRaw={{12,119}};
    if(index==0U){source->velocityZonePresent=true;source->velocityZoneRaw={{10U,127U}};}
    source->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Lfo2);
    assert(source->framingValid());return source;
}
std::shared_ptr<Program> program(){
    auto sound=std::make_shared<Program>();sound->name="Synthetic source persistence fixture";sound->layers.resize(3);
    sound->layers[0].sourceOscillatorDsp=oscillator(8U,0U);
    sound->layers[1].sourceOscillatorDsp=oscillator(2U,1U);
    auto& voice=sound->sourceVoiceAssignment;voice.present=true;voice.resourceVersion=8U;voice.flagsRaw=12U;
    voice.legatoModePresent=true;voice.legatoModeRaw=1U;
    auto& porta=sound->layers[0].sourcePortamento;porta.present=true;porta.encodingSupported=true;
    porta.resourceVersion=2U;porta.flagsRaw=3U;porta.timeRaw=77U;
    auto& amp=sound->layers[0].sourceAmpEnvelope;amp.present=true;amp.enabled=true;
    amp.levels={{0,99,54,71}};amp.times={{4,52,73,41}};
    return sound;
}
void exactLegacyProfileProjection(){
    auto pcm=std::make_shared<SampleData>();pcm->sourceIdentity="Synthetic exact profile UID";
    pcm->sampleRate=48000U;pcm->channels=1;pcm->interleaved.assign(16U,.1F);
    auto multisample=std::make_shared<Multisample>();SampleZone zone;zone.sample=pcm;
    multisample->zones.push_back(zone);
    auto current=std::make_shared<Program>();current->sourceVoiceAssignment.present=true;
    current->sourceVoiceAssignment.resourceVersion=2U;
    const float headroom=-10.0F*std::log10(2.0F);
    for(unsigned i=0U;i<2U;++i){
        ProgramLayer layer;layer.multisample=multisample;layer.velocityLow=64U;layer.velocityHigh=127U;
        layer.sourcePortamento.present=true;layer.sourcePortamento.resourceVersion=2U;
        layer.sourceAmpEnvelope.present=true;layer.ampEnvelope={.001F,0.0F,1.0F,.015F};
        auto profile=std::make_shared<SourceOscillatorDsp>();profile->resourceVersion=2U;
        profile->layoutCorroborated=true;profile->oscillatorIndex=static_cast<std::uint8_t>(i);
        profile->velocityZonePresent=true;profile->velocityZoneRaw={{static_cast<std::uint8_t>(10U+10U*i),127U}};
        profile->scaledVelocityDecoded=true;profile->scaledVelocityRaw={{0U,127U}};
        layer.sourceOscillatorDsp=profile;layer.levelDb=headroom;current->layers.push_back(layer);
    }
    const auto old=silveton::arranger::projectPa5xSampleProgramLegacyOscillator1(current);
    assert(old&&old->layers.size()==2U);
    for(unsigned i=0U;i<2U;++i){
        assert(old->layers[i].multisample==multisample&&old->layers[i].velocityLow==64U);
        assert(!old->layers[i].sourceOscillatorDsp->velocityZonePresent);
        assert(encodeSourceOscillatorDsp(*old->layers[i].sourceOscillatorDsp).size()==178U);
        assert(old->layers[i].levelDb==headroom-10.0F*std::log10(2.0F));
        assert(current->layers[i].sourceOscillatorDsp->velocityZonePresent&&current->layers[i].levelDb==headroom);
    }
    for(auto& layer:current->layers)layer.levelDb=0.0F;
    const auto neutral=silveton::arranger::projectPa5xSampleProgramLegacyOscillator1(current);
    assert(neutral&&neutral->layers[0].levelDb==old->layers[0].levelDb);
    current->layers[0].levelDb=headroom;
    assert(!silveton::arranger::projectPa5xSampleProgramLegacyOscillator1(current));
    for(auto& layer:current->layers)layer.levelDb=headroom;
    current->layers[0].levelDb+=.1F;
    assert(!silveton::arranger::projectPa5xSampleProgramLegacyOscillator1(current));
    current->layers[0].levelDb=headroom;
    auto manual=std::make_shared<SourceOscillatorDsp>(*current->layers[0].sourceOscillatorDsp);
    manual->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Equalizer);
    current->layers[0].sourceOscillatorDsp=manual;
    assert(!silveton::arranger::projectPa5xSampleProgramLegacyOscillator1(current));
    assert(!silveton::arranger::projectPa5xSampleProgramLegacyOscillator1(old));
}
void checkProgram(const ProgramPtr& expected,const ProgramPtr& actual){
    assert(actual&&actual->layers.size()==expected->layers.size());
    assert(actual->sourceVoiceAssignment.legatoModePresent&&actual->sourceVoiceAssignment.legatoModeRaw==1U);
    assert(actual->sourceVoiceAssignment.legatoExtensionRaw==0U&&actual->sourceVoiceAssignment.legato());
    for(std::size_t i=0;i<actual->layers.size();++i){const auto& a=actual->layers[i];const auto& e=expected->layers[i];
        assert(bool(a.sourceOscillatorDsp)==bool(e.sourceOscillatorDsp));
        if(e.sourceOscillatorDsp)assert(*a.sourceOscillatorDsp==*e.sourceOscillatorDsp);
        assert(a.sourcePortamento==e.sourcePortamento);
        assert(a.sourceAmpEnvelope.present==e.sourceAmpEnvelope.present);
        assert(a.sourceAmpEnvelope.levels==e.sourceAmpEnvelope.levels&&a.sourceAmpEnvelope.times==e.sourceAmpEnvelope.times);
    }
}
void checkCombi(const Combi& expected,const Combi& actual){
    for(int part=0;part<kPartCount;++part){
        assert(expected.part(part).sourceSoundEdits==actual.part(part).sourceSoundEdits);
        assert(expected.part(part).sourceVoiceInherit==actual.part(part).sourceVoiceInherit);
        assert(expected.part(part).sourcePortamentoInherit==actual.part(part).sourcePortamentoInherit);
    }
}
}
int main(){
    exactLegacyProfileProjection();
    // A neutral performance declaration must not clip an existing native
    // +/-24-semitone LFO to the original helper's12-semitone limit.
    for(const int raw:{-1,64}){
        assert(sourceSoundEditDepthCents(2000.0F,raw)==2000.0F);
        assert(sourceSoundEditDepthCents(-2000.0F,raw)==-2000.0F);
    }
    assert(sourceSoundEditDepthCents(2399.0F,127)==2400.0F);
    assert(sourceSoundEditDepthCents(std::numeric_limits<float>::quiet_NaN(),64)==0.0F);
    TemporaryDirectory temporary;const auto sound=program();
    SetData source;source.name="Exact retained source controls";
    source.programs.push_back({{1,2,3},sound});source.programs.push_back({{1,2,4},sound});
    CombiSlot stored;stored.address={3,2,1};
    for(int part=0;part<kPartCount;++part){auto& upper=stored.combi.part(part);upper.program=sound;
        upper.sourceVoiceInherit=true;upper.sourcePortamentoInherit=(part%2)==0;
        auto& edits=upper.sourceSoundEdits;
        assert(edits.setController(73,(part*7)%128));assert(edits.setController(72,part==0?0:127-part));
        assert(edits.setController(71,64));assert(edits.setController(5,part));assert(edits.setController(65,part%2?127:0));
    }
    source.combis.push_back(stored);
    source.performance=PerformanceSnapshot{};source.performance->combi=stored.combi;source.performance->edited=true;
    assert(source.performance->combi.part(0).sourceSoundEdits.setController(73,127));
    const auto manifest=temporary.path+"/source.svset";
    assert(SetPackage::save(manifest,source).success);
    const auto loaded=SetPackage::load(manifest);if(!loaded.ok())std::cerr<<loaded.error<<'\n';assert(loaded.ok());
    assert(loaded.data.programs.size()==2U&&loaded.data.combis.size()==1U&&loaded.data.performance);
    assert(loaded.data.programs[0].program==loaded.data.programs[1].program);
    checkProgram(sound,loaded.data.programs[0].program);checkCombi(stored.combi,loaded.data.combis[0].combi);
    checkCombi(source.performance->combi,loaded.data.performance->combi);
    const auto before=SetPackage::combiMetadataBytes(stored.combi);assert(before);
    auto changed=stored.combi;assert(changed.part(14).sourceSoundEdits.setController(73,110));
    assert(before!=SetPackage::combiMetadataBytes(changed));
    // Duplicate owners and truncated payloads must not be accepted as a SET.
    const auto bytes=readBytes(manifest);const auto mark=bytes.find("SVOD");assert(mark!=std::string::npos);
    const std::size_t payload=encodeSourceOscillatorDsp(*sound->layers[0].sourceOscillatorDsp).size();
    const auto block=bytes.substr(mark,16U+2U*(12U+payload));
    const auto malformed=temporary.path+"/malformed.svset";
    writeBytes(malformed,bytes+block);assert(!SetPackage::load(malformed).ok());
    writeBytes(malformed,bytes.substr(0,mark+28U+payload-1U));assert(!SetPackage::load(malformed).ok());
    auto invalid=stored.combi;invalid.part(14).sourceSoundEdits.raw[0]=128;
    assert(!SetPackage::combiMetadataBytes(invalid));
    // Prepared cache must preserve the same raw oscillator/voice profile and
    // graph sharing without consulting the original SET or decoding PCM.
    const auto prepared=temporary.path+"/prepared.bin";
    std::vector<silveton::arranger::Pa5xPreparedProgram> assignments{{121,64,1,sound},{121,64,2,sound}},restored;
    std::vector<std::string> warnings;
    assert(silveton::arranger::savePa5xProgramSnapshot(prepared,assignments,{"fixture warning"}));
    assert(silveton::arranger::loadPa5xProgramSnapshot(prepared,temporary.path,restored,warnings));
    assert(restored.size()==2U&&restored[0].sound==restored[1].sound&&warnings==std::vector<std::string>{"fixture warning"});
    checkProgram(sound,restored[0].sound);
    // The 0.1.69 identity projection may remove the newly imported delay only
    // while it still equals the exact source-owned value. An edited delay or
    // module mask cannot acquire an unedited legacy identity.
    auto legacy=std::make_shared<Program>();legacy->sourceVoiceAssignment.present=true;
    legacy->sourceVoiceAssignment.resourceVersion=2U;legacy->layers.resize(1U);
    auto& legacyLayer=legacy->layers[0];legacyLayer.multisample=std::make_shared<Multisample>();
    legacyLayer.sourcePortamento.present=true;legacyLayer.sourcePortamento.resourceVersion=2U;
    legacyLayer.sourceAmpEnvelope.present=true;legacyLayer.ampEnvelope={.001F,0,1,.015F};
    auto legacyDsp=std::make_shared<SourceOscillatorDsp>();legacyDsp->resourceVersion=2U;legacyDsp->delayRaw=31U;
    legacyLayer.sourceOscillatorDsp=legacyDsp;legacyLayer.delaySec=sourceDelaySeconds(31U);
    const auto projected=silveton::arranger::projectPa5xSampleProgramLegacy69(legacy);
    assert(projected&&projected->layers[0].delaySec==0.0F&&!projected->layers[0].sourceOscillatorDsp);
    legacyLayer.delaySec+=.001F;assert(!silveton::arranger::projectPa5xSampleProgramLegacy69(legacy));
    legacyLayer.delaySec=sourceDelaySeconds(31U);legacyDsp->manualOverrideMask=static_cast<std::uint16_t>(SourceOscillatorModule::Pitch);
    assert(!silveton::arranger::projectPa5xSampleProgramLegacy69(legacy));
    // A native Filter edit disables just source Filter/FilterEG. Pitch/LFO and
    // raw values stay attached to the edited clone; the original is immutable.
    FilterParams filter;filter.cutoffHz=3200;EnvelopeParams envelope;
    const auto edited=ProgramEditor::updateLayerFilter(sound,0,filter,envelope);assert(edited.ok());
    const auto& editedSource=*edited.program->layers[0].sourceOscillatorDsp;
    assert(editedSource.overridden(SourceOscillatorModule::Filter)&&editedSource.overridden(SourceOscillatorModule::FilterEnvelope));
    assert(!editedSource.overridden(SourceOscillatorModule::Pitch)&&!editedSource.overridden(SourceOscillatorModule::Lfo1));
    assert(!sound->layers[0].sourceOscillatorDsp->overridden(SourceOscillatorModule::Filter));
    assert(editedSource.dspRaw==sound->layers[0].sourceOscillatorDsp->dspRaw);
    auto raw=encodeSourceOscillatorDsp(editedSource);SourceOscillatorDsp decoded;std::string error;
    assert(decodeSourceOscillatorDsp(raw,decoded,error)&&decoded==editedSource);
    raw[3]=2U;assert(!decodeSourceOscillatorDsp(raw,decoded,error)); // invalid bool
    raw=encodeSourceOscillatorDsp(editedSource);raw[177U]=255U;assert(!decodeSourceOscillatorDsp(raw,decoded,error)); // unknown override bits in either schema
    std::cout<<"PASS native/prepared source persistence, 15 independent parts, explicit zero/absence, shared ownership, malformed trailers and manual override isolation\n";
}
