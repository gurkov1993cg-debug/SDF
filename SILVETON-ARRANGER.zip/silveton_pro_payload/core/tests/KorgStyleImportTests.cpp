#include "silveton/arranger/KorgStyleImport.h"

#include <cstdlib>
#include <iostream>

using namespace silveton::arranger;
namespace {
void check(bool value,const char* label){if(!value){std::cerr<<"FAIL "<<label<<'\n';std::exit(1);}}
using Bytes=std::vector<std::uint8_t>;
void append32(Bytes& bytes,std::uint32_t value){for(int shift=24;shift>=0;shift-=8)bytes.push_back(static_cast<std::uint8_t>(value>>static_cast<unsigned>(shift)));}
void appendVariable(Bytes& bytes,std::uint32_t value){std::uint8_t buffer[4]{};unsigned size=0;do{buffer[size++]=static_cast<std::uint8_t>(value&127U);value>>=7U;}while(value);while(size){--size;bytes.push_back(static_cast<std::uint8_t>(buffer[size]|(size?128U:0U)));}}
void append(Bytes& target,const Bytes& source){target.insert(target.end(),source.begin(),source.end());}
Bytes resource(const std::string& type,const std::string& name,const Bytes& payload){Bytes bytes(type.begin(),type.end());bytes.push_back(0);bytes.insert(bytes.end(),name.begin(),name.end());bytes.push_back(0);append32(bytes,static_cast<std::uint32_t>(payload.size()));append(bytes,payload);return bytes;}
Bytes textResource(const std::string& name,const std::string& xml){return resource("Leaf",name,Bytes(xml.begin(),xml.end()));}
Bytes testMidi(const Bytes& track){Bytes midi{'M','T','h','d',0,0,0,6,0,0,0,1,1,128,'M','T','r','k'};append32(midi,static_cast<std::uint32_t>(track.size()));append(midi,track);return midi;}
Bytes testStyle(bool setupHasNotes=false){
    Bytes setup{0,0xFF,0x58,4,4,2,24,8};
    if(setupHasNotes)append(setup,{0,0x90,60,100});
    appendVariable(setup,1536);append(setup,{0xFF,0x2F,0});
    Bytes notes;appendVariable(notes,1824);append(notes,{0x90,60,100,96,0x80,60,0});appendVariable(notes,5760);append(notes,{0xFF,0x2F,0});
    Bytes midi{'M','T','h','d',0,0,0,6,0,1,0,2,1,128};
    for(const auto& track:{setup,notes}){append(midi,{'M','T','r','k'});append32(midi,static_cast<std::uint32_t>(track.size()));append(midi,track);}
    const std::string clip="<CLIP type=\"PadClip\"><PARAMS><Pattern type=\"Accompaniment\"/><AppearingTimeSignature numerator=\"4\" denominator=\"2\"/><Loop length=\"-1\" number=\"-1\"/><NTT value=\"1\"/><NTR value=\"0\"/><ReTrigger mode=\"2\"/><KeyRange enabled=\"true\"/><KeyLow value=\"0\"/><KeyHigh value=\"108\"/><WrapAroundDegree value=\"8\"/><ORIGINAL_CHORD><CV1 root=\"G\" chord=\"Min7\"/><CV2 root=\"D\" chord=\"Min\"/><CV6 root=\"F\" chord=\"Maj\" length=\"12\" numerator=\"7\" denominator=\"3\"/></ORIGINAL_CHORD><CHORD_TABLE><Maj cv=\"6\"/></CHORD_TABLE></PARAMS></CLIP>";
    Bytes pad=resource("Leaf","Main.mid",midi);append(pad,textResource("ClipDescription.xml",clip));
    Bytes scene=resource("Branch","Bass.pdc",pad);append(scene,textResource("SceneDescription.xml","<SCENE><PARAMS><TimeSignature numerator=\"4\" denominator=\"2\"/></PARAMS></SCENE>"));
    Bytes payload=resource("Branch","Example.stc",resource("Branch","Main.ssn",resource("Branch","Var1.scn",scene)));
    append(payload,textResource("StageDescription.xml","<STAGE><PARAMS><Tempo value=\"625000\"/></PARAMS></STAGE>"));
    Bytes root{'R','o','o','t',0,1,0};append32(root,static_cast<std::uint32_t>(payload.size()));append(root,payload);return root;
}
}
int main(int argc,char** argv) {
    const auto changing=testMidi({0,0xB0,0,121,0,0xB0,32,66,0,0xC0,20,0,0x90,60,100,
        48,0xB0,0,120,0,0x90,62,100,48,0xB0,32,64,0,0xC0,121,0,0x90,64,100,0,0xFF,0x2F,0});
    const auto changed=inspectKorgMidiBytes(changing);
    check(changed.valid&&changed.patches.size()==2,"timed program changes are indexed after notes begin");
    check(changed.patches[0].tick==0&&changed.patches[0].msb==121&&changed.patches[0].lsb==66&&changed.patches[0].program==20&&changed.patches[0].usedByNotes,"original patch state is retained while pending bank select changes");
    check(changed.patches[1].tick==96&&changed.patches[1].msb==120&&changed.patches[1].lsb==64&&changed.patches[1].program==121&&changed.patches[1].usedByNotes,"bank select commits with the corresponding Program Change");
    const auto controllerOnly=inspectKorgMidiBytes(testMidi({0,0xFF,0x51,3,7,0xA1,0x20,0,0xB0,7,99,0,0xB0,10,44,96,0xFF,0x51,3,6,0x1A,0x80,0,0xFF,0x2F,0}));
    check(controllerOnly.valid&&controllerOnly.tempos.size()==2&&controllerOnly.channelEvents.size()==2&&controllerOnly.patches.empty()&&!controllerOnly.tracks[0].notes,"controller-only Korg streams and tempo changes are preserved without fabricated sounds");
    const auto noPatch=inspectKorgMidiBytes(testMidi({0,0x90,60,100,96,0x80,60,0,0,0xFF,0x2F,0}));
    check(noPatch.valid&&noPatch.patches.size()==1&&noPatch.patches[0].msb==-1&&noPatch.patches[0].lsb==-1&&noPatch.patches[0].program==-1,"undeclared bank and program values remain unknown");
    const auto emptyMidi=inspectKorgMidiBytes(testMidi({0,0xFF,0x2F,0}));
    check(emptyMidi.valid&&emptyMidi.channelEvents.empty()&&emptyMidi.patches.empty(),"empty note stream remains a valid metadata stream");
    for(std::size_t cut=0;cut<changing.size();++cut)check(!inspectKorgMidiBytes(Bytes(changing.begin(),changing.begin()+static_cast<std::ptrdiff_t>(cut))).valid,"every truncation of MIDI fixture is rejected");
    check(!inspectKorgMidiBytes(testMidi({0,0x90,60,128,0,0xFF,0x2F,0})).valid,"invalid MIDI data byte rejected");
    check(!inspectKorgMidiBytes(testMidi({0,0xF0,9,1,2,0,0xFF,0x2F,0})).valid,"truncated SysEx rejected");
    check(!inspectKorgStyleBytes({}).recognized,"empty bytes are not STG");
    std::vector<std::uint8_t> root{'R','o','o','t',0,1,0,0,0,0,0};
    auto result=inspectKorgStyleBytes(root);
    check(result.recognized&&!result.valid,"empty valid container is not a style");
    root.back()=1;
    result=inspectKorgStyleBytes(root);
    check(!result.valid&&result.error.find("length")!=std::string::npos,"root length is bounded");
    root.back()=3;root.insert(root.end(),{'X','Y','Z'});
    check(!inspectKorgStyleBytes(root).valid,"unterminated child rejected");
    result=inspectKorgStyleBytes(testStyle());
    check(result.valid&&result.elements.size()==1&&result.elements[0].clips.size()==1,"synthetic Pa5X container indexes");
    const auto& testClip=result.elements[0].clips[0];
    check(testClip.cvSources.size()==3&&testClip.cvSources[1].number==2&&testClip.cvSources[2].number==6,"CV2 and CV6 sources preserved separately");
    check(testClip.cvSources[2].declaredLengthRaw==12&&testClip.cvSources[2].numerator==7&&testClip.cvSources[2].denominatorExponent==3,"undeclared CV timing units remain raw metadata");
    check(testClip.setupTimingKnown&&testClip.setupTicks==1536&&testClip.performanceTicks==6144,"setup boundary preserves leading musical rest");
    check(testClip.patches.empty()&&testClip.patchSelections.size()==1&&testClip.patchSelections[0].program==-1,"style metadata never substitutes an undeclared program with GM0");
    result=inspectKorgStyleBytes(testStyle(true));
    check(result.valid&&!result.elements[0].clips[0].setupTimingKnown,"a track containing notes is not silently treated as setup");
    if(argc==2) {
        result=inspectKorgStyleFile(argv[1]);
        check(result.valid,"real reference indexes structurally");
        check(result.tempoBpm==96.0,"tempo read from StageDescription");
        check(result.elements.size()==15,"all fifteen elements preserved");
        bool drum=false,acc=false,breakMeter=false,varBass=false,varAccDrum=false,breakTiming=false;
        for(const auto& element:result.elements) {
            if(element.element==Element::Break)breakMeter=element.numerator==2&&element.denominator==4;
            for(const auto& clip:element.clips) {
                check(clip.ppq==384,"embedded MIDI PPQ read from header");
                if(element.element==Element::Var1&&clip.track==2) {
                    check(clip.originalRoot=="G"&&clip.originalChord=="Min7","Var1 Bass preserves its own G Min7 source");
                    check(clip.cvSources.size()==1&&clip.cvSources[0].number==1&&clip.cvSources[0].root=="G"&&clip.cvSources[0].chord=="Min7","per-track CV1 source metadata preserved");
                    check(clip.retriggerMode==2&&clip.ntt==1&&clip.ntr==0,"raw Pa5X trigger and NTT codes preserved without guessed mappings");
                    check(clip.keyRangeDeclared&&clip.keyRangeEnabled&&clip.keyLow==0&&clip.keyHigh==108&&clip.wrapAroundDegree==8,"key range and wrap declarations preserved");
                    check(clip.appearingNumerator==4&&clip.appearingDenominator==4&&clip.declaredLoopLength==-1,"declared meter and sentinel loop length preserved");
                    check(clip.setupTimingKnown&&clip.setupTicks==1536&&clip.performanceTicks==6144&&clip.midiSpanTicks==7680,"Var1 setup removed from performance span without trimming its leading rest");
                    varBass=true;
                }
                if(element.element==Element::Var1&&clip.track==3) {
                    check(clip.patternType=="Drum","ACC1 lane's actual Drum pattern type is preserved");
                    varAccDrum=true;
                }
                if(element.element==Element::Break&&clip.track==2) {
                    check(clip.setupTimingKnown&&clip.setupTicks==768&&clip.performanceTicks==768,"Break setup uses its own 2/4 meter");
                    breakTiming=true;
                }
                for(const auto& patch:clip.patches) {
                    if(element.element==Element::Intro1&&clip.track==0&&patch.msb==120&&patch.lsb==64&&patch.program==121)drum=true;
                    if(element.element==Element::Var1&&clip.track==3&&patch.msb==121&&patch.lsb==66&&patch.program==20)acc=true;
                }
            }
        }
        check(drum&&acc,"original sound addresses preserved without remapping");
        check(breakMeter,"per-element meter read instead of style name");
        check(varBass&&varAccDrum&&breakTiming,"reference timing and track-type checks were exercised");
        check(!result.playbackBlockers.empty(),"unsupported NTT/CV/resource semantics explicit");
        const auto imported=importKorgStyleFile(argv[1]);
        check(imported&&imported.style->nativeKorg,"reference publishes the dedicated native per-track/CV graph");
        check(!imported.warnings.empty()&&!imported.style->playbackWarnings.empty(),"partial Korg playback capabilities remain explicit");
        check(imported.style->sections[static_cast<std::size_t>(Element::Var1)].events.empty(),"native CV events are not flattened into the generic section stream");
    }
    std::cout<<"PASS Korg structural index and native playback capability gates\n";
}
