#include "silveton/arranger/Pa5xMultisampleImport.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include <unistd.h>

using namespace silveton::arranger;
namespace {
void check(bool condition,const char* message){if(!condition){std::cerr<<"FAIL "<<message<<'\n';std::exit(1);}}
bool has(const Pa5xMultisampleImport& result,const char* code){return std::any_of(result.blockers.begin(),result.blockers.end(),[&](const Pa5xMultisampleBlocker& item){return item.code==code;});}
void set16(std::array<std::uint8_t,16>& bytes,std::size_t offset,std::uint16_t value){bytes[offset]=static_cast<std::uint8_t>(value>>8U);bytes[offset+1]=static_cast<std::uint8_t>(value);}
Pa5xSampleIndex fixtureKmp(){
    Pa5xSampleIndex kmp;kmp.valid=true;kmp.recognized=true;kmp.kind=Pa5xSampleContainerKind::Multisamples;kmp.multisampleMappingDecoded=true;
    Pa5xKmpSample first;first.resourceId=1;first.name="First";first.sampleRate=48000;first.originalNote=128;first.packedData=0x10;
    auto second=first;second.resourceId=2;second.name="Second";second.sampleRate=44100;second.originalNote=72;second.packedData=0x610;
    kmp.samples={first,second};
    Pa5xKmpKeyZone low;low.sampleIndex=0;low.highNote=127;low.originalNote=0;low.pitch=-12;low.level=0;low.version5Record[2]=1;
    auto high=low;high.sampleIndex=1;high.highNote=95;high.originalNote=67;high.pitch=23;
    kmp.keyZones={low,high};
    Pa5xKmpMultisample multi;multi.name="Exact map";multi.resourceId=99;multi.zoneCount=2;multi.zoneIndices.fill(255);
    for(std::size_t key=0;key<32;++key)multi.zoneIndices[key]=0;
    for(std::size_t key=64;key<96;++key)multi.zoneIndices[key]=1;
    for(std::size_t key=96;key<128;++key)multi.zoneIndices[key]=0;
    kmp.multisamples.push_back(multi);return kmp;
}
Pa5xSampleIndex fixturePcm(){
    Pa5xSampleIndex pcm;pcm.valid=true;pcm.recognized=true;pcm.kind=Pa5xSampleContainerKind::PcmSamples;
    Pa5xSampleObject first;first.hasId=true;first.resourceId=1;first.audioMetadataDecoded=true;first.sampleFormat=16;first.channelTag=1;first.sampleRate=48000;first.encodedSampleCount=4;first.audioDataBytes=8;first.pcmByteOrder=Pa5xPcmByteOrder::BigEndian;first.loopStart=1;first.endPositionRaw=3;first.secondaryEndPositionRaw=3;
    auto second=first;second.resourceId=2;second.sampleRate=44100;second.encodedSampleCount=8;second.audioDataBytes=16;second.loopStart=0;second.endPositionRaw=5;second.secondaryEndPositionRaw=5;
    pcm.objects={first,second};return pcm;
}
Pa5xMultisampleBuildOptions inclusive(){Pa5xMultisampleBuildOptions options;options.endConvention=Pa5xSampleEndConvention::InclusiveIndex;return options;}
Pa5xSampleAudio fakeAudio(const Pa5xPcmInventory& source,std::size_t objectIndex,const Pa5xKmpSample& sample){
    Pa5xSampleAudio audio;audio.sampleRate=sample.sampleRate;audio.mono.resize(source.index->objects[objectIndex].encodedSampleCount);
    for(std::size_t i=0;i<audio.mono.size();++i)audio.mono[i]=static_cast<float>(i+1U)*0.1F;
    return audio;
}
void exactMapAndCache(){
    const auto kmp=fixtureKmp(),pcm=fixturePcm();const std::vector<Pa5xPcmInventory> sources{{"fixture.pcm",&pcm}};
    int calls=0;auto load=[&](const Pa5xPcmInventory& source,std::size_t object,const Pa5xKmpSample& sample){++calls;return fakeAudio(source,object,sample);};
    Pa5xMultisampleCache cache;const auto built=buildPa5xMultisample(kmp,0,sources,load,&cache,inclusive());
    check(bool(built)&&built.parametersDecoded&&built.samplesDecoded,"complete exact map publishes a native multisample");
    check(built.mappedKeys==96&&built.silentKeys==32&&built.decodedSampleCount==2&&calls==2,"only exact used samples are decoded once");
    const auto& zones=built.multisample->zones;check(zones.size()==3,"disjoint uses of one zone remain disjoint native key ranges");
    check(zones[0].keyLow==0&&zones[0].keyHigh==31&&zones[1].keyLow==64&&zones[1].keyHigh==95&&zones[2].keyLow==96&&zones[2].keyHigh==127,"all original silent gaps and mapped keys are preserved");
    check(zones[0].rootKey==0&&zones[0].sample->rootKey==128&&zones[0].tuneCents==-12,"MIDI root zero is valid; the zone overrides an unknown descriptive sample root");
    check(zones[1].rootKey==67&&zones[1].tuneCents==23&&zones[1].gainDb==12,"authoritative root, signed cents and documented 12dB boost are retained");
    check(zones[0].sample==zones[2].sample&&zones[0].sample->loop.enabled&&zones[0].sample->loop.startFrame==1&&zones[0].sample->loop.endFrame==4,"one UID reuses one sample with normalized exact loop bounds");
    check(zones[1].sample->frameCount()==6&&!zones[1].sample->loop.enabled&&!zones[1].oneShot,"logical end trims encoded padding; loop-off does not force ignore-note-off");
    const auto repeated=buildPa5xMultisample(kmp,0,sources,load,&cache,inclusive());
    check(bool(repeated)&&calls==2&&repeated.multisample->zones[0].sample==zones[0].sample,"scoped cache reuses validated waveforms");
    auto exclusive=inclusive();exclusive.endConvention=Pa5xSampleEndConvention::ExclusiveBoundary;
    const auto otherPolicy=buildPa5xMultisample(kmp,0,sources,load,&cache,exclusive);
    check(bool(otherPolicy)&&calls==4&&otherPolicy.multisample->zones[0].sample->frameCount()==3,"cache cannot silently reuse a different endpoint policy");
    auto corrupted=std::make_shared<silveton::sampler::SampleData>(*cache.samples.begin()->second);corrupted->loop.enabled=!corrupted->loop.enabled;
    cache.samples.begin()->second=corrupted;
    const auto refused=buildPa5xMultisample(kmp,0,sources,load,&cache,inclusive());
    check(!refused&&has(refused,"SAMPLE_CACHE_INVALID"),"inconsistent cached playback metadata never substitutes for the source");
}
void failClosed(){
    auto kmp=fixtureKmp(),pcm=fixturePcm();std::vector<Pa5xPcmInventory> sources{{"fixture.pcm",&pcm}};int calls=0;
    auto load=[&](const Pa5xPcmInventory& source,std::size_t object,const Pa5xKmpSample& sample){++calls;return fakeAudio(source,object,sample);};
    auto built=buildPa5xMultisample(kmp,0,sources,load);check(!built&&has(built,"SAMPLE_PLAYBACK_UNSUPPORTED")&&calls==0,"endpoint convention is never silently invented");
    pcm.objects.pop_back();built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"PCM_SAMPLE_MISSING")&&built.missingSampleIds==std::vector<std::uint64_t>{2}&&calls==0,"missing UID blocks the whole multisample before audio decoding");
    pcm=fixturePcm();sources.push_back({"duplicate.pcm",&pcm});built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"PCM_SAMPLE_AMBIGUOUS")&&calls==0,"duplicate PCM identifiers are never resolved by filename or order");sources.resize(1);
    kmp.keyZones[0].level=-2;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"ZONE_LEVEL_TRANSFER_UNKNOWN")&&calls==0,"nonzero legacy level never becomes a fake unity native zone");kmp=fixtureKmp();
    kmp.keyZones[0].originalNote=128;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"ZONE_ROOT_UNKNOWN")&&calls==0,"invalid zone roots have no C4 fallback");kmp=fixtureKmp();
    kmp.keyZones[0].version5Record[10]=1;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"ZONE_PARAMETERS_UNSUPPORTED")&&calls==0,"non-neutral opaque legacy parameters block conversion");kmp=fixtureKmp();
    kmp.multisamples[0].zoneIndices[0]=2;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"ZONE_MAP_INVALID")&&calls==0,"out-of-span key-map indices reject before decoding");kmp=fixtureKmp();
    kmp.keyZones[0].sampleIndex=-2;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"SAMPLE_REFERENCE_INVALID")&&calls==0,"unknown negative sample sentinels are not treated as silence");kmp=fixtureKmp();
    kmp.multisamples[0].firstZone=std::numeric_limits<std::uint32_t>::max();built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"ZONE_MAP_INVALID")&&calls==0,"large zone-span arithmetic remains bounded");kmp=fixtureKmp();
    kmp.samples[0].packedData|=0x100U;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"SAMPLE_LOOP_PITCH_UNSUPPORTED")&&calls==0,"unknown loop-pitch correction is not treated as zero");kmp=fixtureKmp();
    pcm.objects[0].secondaryEndPositionRaw=2;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,inclusive());
    check(!built&&has(built,"SAMPLE_END_ROLE_UNKNOWN")&&calls==0,"conflicting end-like fields stay unsupported");pcm=fixturePcm();
    auto budget=inclusive();budget.maximumTotalFrames=4;built=buildPa5xMultisample(kmp,0,sources,load,nullptr,budget);
    check(!built&&has(built,"DECODE_BUDGET_EXCEEDED")&&calls==0,"all decoding budgets are checked before allocation");
    auto wrong=[](const Pa5xPcmInventory&,std::size_t,const Pa5xKmpSample& sample){Pa5xSampleAudio a;a.sampleRate=sample.sampleRate;a.mono={0.0F};return a;};
    Pa5xMultisampleCache emptyCache;built=buildPa5xMultisample(kmp,0,sources,wrong,&emptyCache,inclusive());
    check(!built&&built.multisample==nullptr&&has(built,"SAMPLE_DECODE_MISMATCH")&&emptyCache.samples.empty(),"failed waveform conversion publishes neither partial multisample nor cache entries");
}
void version8AndSilentMap(){
    auto kmp=fixtureKmp();const auto pcm=fixturePcm();const std::vector<Pa5xPcmInventory> sources{{"fixture.pcm",&pcm}};
    for(auto& zone:kmp.keyZones){zone.pitchLevelDecoded=false;set16(zone.version8Record,4,static_cast<std::uint16_t>(-37));set16(zone.version8Record,6,32768);set16(zone.version8Record,8,32768);}
    auto built=buildPa5xMultisample(kmp,0,sources,fakeAudio,nullptr,inclusive());
    check(bool(built)&&built.usesDerivedMetadata&&built.multisample->zones[0].tuneCents==-37,"version8 signed cents and neutral levels retain derived provenance");
    set16(kmp.keyZones[0].version8Record,6,32438);set16(kmp.keyZones[0].version8Record,8,32438);
    built=buildPa5xMultisample(kmp,0,sources,fakeAudio,nullptr,inclusive());check(!built&&has(built,"ZONE_LEVEL_TRANSFER_UNKNOWN"),"nonneutral v8 gain is not guessed from its numerical encoding");
    kmp=fixtureKmp();kmp.multisamples[0].zoneIndices.fill(255);built=buildPa5xMultisample(kmp,0,{},fakeAudio);
    check(bool(built)&&built.silentKeys==128&&built.decodedSampleCount==0&&built.multisample->zones.empty(),"an explicitly silent exact key map stays silent without substituting samples");
}
void actualIncomplete(const char* pcmPath,const char* kmpPath){
    const auto pcm=inspectPa5xSampleFile(pcmPath),kmp=inspectPa5xSampleFile(kmpPath);check(pcm.valid&&kmp.valid,"real source metadata validates");
    int calls=0;auto load=[&](const Pa5xPcmInventory&,std::size_t,const Pa5xKmpSample&){++calls;return Pa5xSampleAudio{};};
    const auto result=buildPa5xMultisample(kmp,0,{{pcmPath,&pcm}},load,nullptr,inclusive());
    check(result.found&&!result&&has(result,"PCM_SAMPLE_MISSING")&&result.missingSampleIds.size()==14&&calls==0,"real Musi 1 requires14 further exact samples; no partial activation or decoding occurs");
}
using Bytes=std::vector<std::uint8_t>;
void append16(Bytes& bytes,std::size_t value){bytes.push_back(static_cast<std::uint8_t>(value>>8U));bytes.push_back(static_cast<std::uint8_t>(value));}
void append32(Bytes& bytes,std::size_t value){for(int shift=24;shift>=0;shift-=8)bytes.push_back(static_cast<std::uint8_t>(value>>shift));}
void put32(Bytes& bytes,std::size_t offset,std::uint32_t value){for(int shift=24;shift>=0;shift-=8)bytes[offset++]=static_cast<std::uint8_t>(value>>shift);}
void chunk(Bytes& bytes,std::uint32_t tag,const Bytes& data){append32(bytes,tag);append32(bytes,data.size());bytes.insert(bytes.end(),data.begin(),data.end());}
void property(Bytes& bytes,std::size_t tag,const Bytes& data){append16(bytes,tag);append16(bytes,data.size());bytes.insert(bytes.end(),data.begin(),data.end());}
Bytes completePcm(std::uint8_t uid){
    Bytes record;append16(record,4);property(record,0,{6,0,1});property(record,1,{0,0});property(record,2,{'A',0});property(record,4,{0,0,0,0,0,0,0,uid});append32(record,0);
    Bytes toc;append16(toc,record.size());toc.insert(toc.end(),record.begin(),record.end());
    Bytes bytes;append32(bytes,0x01000114U);append32(bytes,0);chunk(bytes,0x02000018U,{0x0B,0,0,0,0,0,0,'K','O','R','F',0});chunk(bytes,0x05010018U,toc);
    const auto at=bytes.size();Bytes payload(74,0);payload[7]=uid;payload[8]=1;payload[9]=16;put32(payload,10,48000);put32(payload,14,4);put32(payload,50,1);put32(payload,54,3);put32(payload,62,3);
    payload[66]=0x80;payload[70]=0x40;payload[72]=0x7F;payload[73]=0xFF;chunk(bytes,0x12000018U,payload);
    Bytes xref={'K','B','E','G'};append32(xref,28);append32(xref,at);xref.insert(xref.end(),{'K','E','N','D'});append32(xref,2);chunk(bytes,0xFE000018U,xref);put32(bytes,4,static_cast<std::uint32_t>(bytes.size()-8));return bytes;
}
void defaultFileLoader(){
    char pattern[]="/tmp/silveton-ms-import-XXXXXX";const int descriptor=::mkstemp(pattern);check(descriptor>=0,"temporary PCM source opens");::close(descriptor);
    const std::string path=pattern;const auto bytes=completePcm(1);
    {std::ofstream out(path,std::ios::binary|std::ios::trunc);out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));check(bool(out),"temporary PCM source writes");}
    auto pcm=inspectPa5xSampleBytes(bytes);check(pcm.valid,"real synthetic container validates before import");
    auto kmp=fixtureKmp();kmp.samples.resize(1);kmp.keyZones.resize(1);kmp.multisamples[0].zoneCount=1;kmp.multisamples[0].zoneIndices.fill(0);
    const auto built=buildPa5xMultisample(kmp,0,{{path,&pcm}},{},nullptr,inclusive());
    check(bool(built)&&built.multisample->zones[0].sample->interleaved==std::vector<float>{-1.0F,0.0F,0.5F,32767.0F/32768.0F},"default file loader revalidates the container and decodes original samples");
    const auto changed=completePcm(2);{std::ofstream out(path,std::ios::binary|std::ios::trunc);out.write(reinterpret_cast<const char*>(changed.data()),static_cast<std::streamsize>(changed.size()));}
    const auto refused=buildPa5xMultisample(kmp,0,{{path,&pcm}},{},nullptr,inclusive());
    check(!refused&&has(refused,"SAMPLE_DECODE_FAILED")&&refused.multisample==nullptr,"a changed resource cannot decode using stale inventory offsets or UID");
    std::remove(path.c_str());
}
}
int main(int argc,char** argv){
    exactMapAndCache();failClosed();version8AndSilentMap();defaultFileLoader();if(argc==3)actualIncomplete(argv[1],argv[2]);
    std::puts("Pa5X multisample import: PASS (exact maps, roots, tuning, explicit loops, cache and strict unsupported/missing-data gates)");
}
