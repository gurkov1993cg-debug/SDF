#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/sampler/SourcePerformanceControls.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <vector>

using namespace silveton::arranger;
namespace {
struct Capture final:RenderCallbacks {
    struct Span {std::uint64_t begin;std::uint32_t frames;std::array<double,2> tempo;std::array<bool,2> playing;};
    struct Pressure {int player,track,key,value;};
    std::vector<Span> spans;
    std::vector<Pressure> pressures;
    std::vector<Pressure> releases;
    std::array<double,2> tempo{};
    std::array<bool,2> playing{};
    std::array<std::array<silveton::sampler::SourceSoundEdits,8>,2> edits{};
    std::array<std::array<silveton::sampler::SourceSoundEditReader,8>,2> readers{};
    std::uint64_t base{};std::uint32_t cursor{};unsigned tempoMask{};unsigned noteOns{};
    void sourceTempo(int player,double bpm,bool active) noexcept override {
        assert(player>=0&&player<2);const auto i=static_cast<std::size_t>(player);
        tempo[i]=bpm;playing[i]=active;tempoMask|=1U<<i;
    }
    void render(std::uint32_t offset,std::uint32_t frames) noexcept override {
        assert(offset==cursor&&tempoMask==3U);spans.push_back({base+offset,frames,tempo,playing});
        tempoMask=0U;cursor+=frames;
    }
    void midi(int player,int track,std::uint8_t status,std::uint8_t a,std::uint8_t b) noexcept override {
        if((status&0xF0U)==0xB0U){
            const auto p=static_cast<std::size_t>(player),t=static_cast<std::size_t>(track);
            (void)readers[p][t].controller(edits[p][t],a,b);
        }else if((status&0xF0U)==0x90U&&b>0U)++noteOns;
        else if((status&0xF0U)==0xA0U)pressures.push_back({player,track,a,b});
        else if((status&0xF0U)==0x80U)releases.push_back({player,track,a,b});
    }
    void run(ArrangerEngine& engine,std::uint32_t frames){cursor=0;engine.process(frames,48000.0,*this);assert(cursor==frames);base+=frames;}
};
std::shared_ptr<Style> fixture(double bpm,bool changeTempo){
    auto style=std::make_shared<Style>();style->name="Source tempo/recall fixture";style->nativeKorg=true;
    style->ppq=384;style->tempoBpm=bpm;style->tracks[0].used=true;style->tracks[0].role=TrackRole::Drums;
    auto& section=style->sections[static_cast<std::size_t>(Element::Var1)];
    section.available=true;section.nativePatterns=true;section.lengthTicks=1536;
    auto& pattern=section.patterns[0];pattern.present=true;pattern.mode=NativePatternMode::Drum;pattern.chordCv.fill(1U);
    auto& cv=pattern.cvs[0];cv.available=true;cv.lengthTicks=1536;cv.sourceChord=ChordType::Major;
    if(changeTempo)cv.tempoEvents={{384,120.0}};
    return style;
}
void tempoFollowsActualBoundary(){
    ArrangerEngine engine;Capture capture;
    assert(engine.installStyle(0,fixture(60.0,true)));assert(engine.installStyle(1,fixture(90.0,false)));
    assert(engine.post({CommandType::Play,0}));assert(engine.post({CommandType::Play,1}));
    capture.run(engine,48001);
    assert(capture.spans.front().begin==0U&&capture.spans.front().tempo[0]==60.0&&capture.spans.front().tempo[1]==90.0);
    const auto change=std::find_if(capture.spans.begin(),capture.spans.end(),[](const auto& span){return span.tempo[0]==120.0;});
    assert(change!=capture.spans.end()&&change->begin==48000U&&change->tempo[1]==90.0);
    assert(change->playing[0]&&change->playing[1]);
    assert(engine.post({CommandType::SetTempoLock,1,0,1.0}));capture.run(engine,1);
    assert(capture.spans.back().tempo[0]==90.0&&capture.spans.back().tempo[1]==90.0);
    assert(engine.post({CommandType::SetTempo,0,0,150.0}));capture.run(engine,1);
    assert(capture.spans.back().tempo[0]==150.0&&capture.spans.back().tempo[1]==150.0);
    assert(engine.post({CommandType::Stop,0}));capture.run(engine,1);
    assert(!capture.spans.back().playing[0]&&capture.spans.back().playing[1]);
}
void phasePreservingCvRestoresSoundEdits(){
    auto style=fixture(60.0,false);
    auto& pattern=style->sections[static_cast<std::size_t>(Element::Var1)].patterns[0];
    auto& first=pattern.cvs[0];first.events={{0,0,0xB0,73,90},{0,0,0xB0,72,77}};
    auto& second=pattern.cvs[1];second.available=true;second.lengthTicks=1536;second.sourceChord=ChordType::Minor;
    second.tempoEvents={{0,120.0}};
    second.events={{0,0,0xB0,99,1},{0,0,0xB0,98,99},{0,0,0xB0,6,21},
        {0,0,0xB0,72,40},{0,0,0xB0,74,100},{0,0,0xB0,5,50},{0,0,0xB0,65,127},
        {0,0,0x90,36,100},{1,0,0x80,36,0}};
    pattern.chordCv[static_cast<std::size_t>(ChordType::Minor)]=2U;
    ArrangerEngine engine;Capture capture;assert(engine.installStyle(0,style));
    assert(engine.postChordControls(static_cast<int>(ChordRecognitionMode::FingeredThreeNotes),3,true,false,false,60,true));
    for(const auto key:{48,52,55})assert(engine.postMidi(0x90,key,100));
    assert(engine.post({CommandType::Play,0}));capture.run(engine,24000);
    assert(capture.edits[0][0].controller(73)==90&&capture.edits[0][0].controller(72)==77);
    assert(engine.postMidi(0x80,52,0));assert(engine.postMidi(0x90,51,100));capture.run(engine,1);
    assert(engine.snapshot(0).selectedCvs[0]==2);
    assert(engine.snapshot(0).tempoBpm==120.0&&capture.spans.back().tempo[0]==120.0);
    const auto& edits=capture.edits[0][0];
    assert(edits.controller(73)==21&&edits.controller(72)==40&&edits.controller(74)==100);
    assert(edits.controller(5)==50&&edits.controller(65)==127);
    assert(capture.noteOns==0U); // restoring state must never retrigger skipped notes
}
void pressureUsesCurrentlyMappedPitch(){
    for(const bool native:{false,true})for(const bool noteOnZero:{false,true}){
        auto style=fixture(60.0,false);style->nativeKorg=native;
        style->tracks[0].role=TrackRole::Accompaniment;
        auto& section=style->sections[static_cast<std::size_t>(Element::Var1)];section.nativePatterns=native;
        const std::vector<MidiEvent> events{{0,0,0x90,60,100},{1,0,0xA0,60,95},
            {2,0,static_cast<std::uint8_t>(noteOnZero?0x90:0x80),60,0},{3,0,0xA0,60,12}};
        if(native){auto& pattern=section.patterns[0];pattern.mode=NativePatternMode::RecordedSourceOnly;
            pattern.cvs[0].events=events;pattern.cvs[0].sourceRootKnown=true;
        }else section.events=events;
        ArrangerEngine engine;Capture capture;assert(engine.installStyle(0,style));
        assert(engine.postChordControls(static_cast<int>(ChordRecognitionMode::FingeredThreeNotes),3,true,false,false,60,true));
        if(native)assert(engine.post({CommandType::SetSamplePlaybackMode,0,0,1.0,0,style.get()}));
        for(const auto key:{50,54,57})assert(engine.postMidi(0x90,key,100));
        assert(engine.post({CommandType::Play,0}));capture.run(engine,501);
        if(capture.noteOns!=1U||capture.pressures.size()!=1U)
            std::fprintf(stderr,"pressure fixture native=%d notes=%u pressures=%zu chord=%d/%d\n",
                native?1:0,capture.noteOns,capture.pressures.size(),engine.snapshot(0).chord.root,
                static_cast<int>(engine.snapshot(0).chord.type));
        assert(capture.noteOns==1U&&capture.pressures.size()==1U);
        const auto& pressure=capture.pressures.front();
        assert(pressure.player==0&&pressure.track==0&&pressure.key==62&&pressure.value==95);
        assert(capture.releases.size()==1U&&capture.releases[0].key==62);
        assert(capture.releases[0].value==(noteOnZero?64:0));
    }
}
}
int main(){tempoFollowsActualBoundary();phasePreservingCvRestoresSoundEdits();pressureUsesCurrentlyMappedPitch();
    std::puts("PASS source tempo at actual subspan/CV boundary, independent players/lock, phase-preserving source edit restoration and mapped polyphonic pressure");}
