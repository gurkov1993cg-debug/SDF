#include "silveton/arranger/ChordRecognition.h"

#include <array>
#include <cassert>
#include <cstdio>
#include <initializer_list>

using namespace silveton::arranger;

namespace {
using Held = std::array<bool, 128>;

Held keys(std::initializer_list<int> notes) {
    Held held{};
    for (const int note : notes) {
        assert(note >= 0 && note < 128);
        held[static_cast<std::size_t>(note)] = true;
    }
    return held;
}

void expect(const Held& held, ChordRecognitionMode mode, int root, ChordType type,
            bool simplified = true) {
    const auto chord = recognizeChord(held, mode, simplified);
    assert(chord.valid());
    assert(chord.root == root && chord.type == type);
}

bool whiteKey(int key) {
    const int pitch = key % 12;
    return pitch == 0 || pitch == 2 || pitch == 4 || pitch == 5 ||
           pitch == 7 || pitch == 9 || pitch == 11;
}

int lowerKey(int root, bool white) {
    int key = root - 1;
    while (whiteKey(key) != white) --key;
    return key;
}

void compatibility() {
    static_assert(static_cast<int>(ChordType::Major) == 0, "stored chord values");
    static_assert(static_cast<int>(ChordType::Sus4) == 8, "stored chord values");
    static_assert(static_cast<int>(ChordType::None) == 9, "stored chord values");
    const auto c = detectChord(keys({52, 55, 60}));
    assert(c.root == 0 && c.type == ChordType::Major && c.bass == 4);
    assert(chordName(c) == "C/E");
    assert(!detectChord(Held{}).valid());
}

void oneFinger() {
    // Pa5X User Manual p.178: octave labels differ across MIDI tools; these
    // are C/B/Bb in adjacent octaves, and only their relative keys matter.
    expect(keys({48}), ChordRecognitionMode::OneFinger, 0, ChordType::Major);
    expect(keys({48, 47}), ChordRecognitionMode::OneFinger, 0, ChordType::Seventh);
    expect(keys({48, 46}), ChordRecognitionMode::OneFinger, 0, ChordType::Minor);
    expect(keys({48, 47, 46}), ChordRecognitionMode::OneFinger, 0, ChordType::Minor7);
    // The manual explicitly permits farther additional white/black keys.
    expect(keys({60, 47}), ChordRecognitionMode::OneFinger, 0, ChordType::Seventh);
    expect(keys({60, 46}), ChordRecognitionMode::OneFinger, 0, ChordType::Minor);
    expect(keys({60, 47, 46}), ChordRecognitionMode::OneFinger, 0, ChordType::Minor7);

    for (int pitch = 0; pitch < 12; ++pitch) {
        const int root = 60 + pitch;
        const int white = lowerKey(root, true), black = lowerKey(root, false);
        // Key color belongs to the physical keyboard, so shifting the C
        // example by a semitone is not a valid transposition of its shortcut.
        expect(keys({root}), ChordRecognitionMode::OneFinger, pitch, ChordType::Major);
        expect(keys({root, white}), ChordRecognitionMode::OneFinger, pitch, ChordType::Seventh);
        expect(keys({root, black}), ChordRecognitionMode::OneFinger, pitch, ChordType::Minor);
        expect(keys({root, white, black}), ChordRecognitionMode::OneFinger, pitch, ChordType::Minor7);
    }
}

void oneFingerPlus() {
    expect(keys({48}), ChordRecognitionMode::OneFingerPlus, 0, ChordType::Major);
    expect(keys({48, 47}), ChordRecognitionMode::OneFingerPlus, 0, ChordType::Seventh);
    expect(keys({48, 46}), ChordRecognitionMode::OneFingerPlus, 0, ChordType::Minor);
    expect(keys({48, 47, 46}), ChordRecognitionMode::OneFingerPlus, 0, ChordType::Minor7);
    assert(!recognizeChord(keys({60, 47}), ChordRecognitionMode::OneFingerPlus).valid());
    assert(!recognizeChord(keys({60, 46}), ChordRecognitionMode::OneFingerPlus).valid());
    // Full chord shapes take precedence over the simplified-key shortcut.
    for (int pitch = 0; pitch < 12; ++pitch) {
        const int root = 48 + pitch;
        expect(keys({root, root + 4, root + 7}), ChordRecognitionMode::OneFingerPlus,
               pitch, ChordType::Major);
        expect(keys({root, root + 3, root + 7}), ChordRecognitionMode::OneFingerPlus,
               pitch, ChordType::Minor);
    }
    expect(keys({50, 53, 57, 60}), ChordRecognitionMode::OneFingerPlus, 2, ChordType::Minor7);
    // The Fingered (3 Notes) chart explicitly includes seventh chords with
    // their fifth omitted, and two-pitch shapes can use an octave doubling.
    expect(keys({48, 52, 58}), ChordRecognitionMode::OneFingerPlus, 0, ChordType::Seventh);
    expect(keys({48, 52, 60}), ChordRecognitionMode::OneFingerPlus, 0, ChordType::Major);
}

void fingeredAndAdvanced() {
    for (int pitch = 0; pitch < 12; ++pitch) {
        const int root = 48 + pitch;
        expect(keys({root}), ChordRecognitionMode::FingeredOneNote, pitch, ChordType::Major);
        assert(!recognizeChord(keys({root}), ChordRecognitionMode::FingeredThreeNotes).valid());
        assert(!recognizeChord(keys({root, root + 12}), ChordRecognitionMode::FingeredThreeNotes).valid());
        expect(keys({root, root + 4, root + 7}), ChordRecognitionMode::FingeredThreeNotes,
               pitch, ChordType::Major);
        expect(keys({root, root + 3, root + 7}), ChordRecognitionMode::FingeredThreeNotes,
               pitch, ChordType::Minor);
        expect(keys({root, root + 4, root + 7, root + 10}), ChordRecognitionMode::FingeredThreeNotes,
               pitch, ChordType::Seventh);
        expect(keys({root}), ChordRecognitionMode::Advanced, pitch, ChordType::RootOctave);
        expect(keys({root, root + 7}), ChordRecognitionMode::Advanced, pitch, ChordType::RootFifth);
    }
    expect(keys({52, 55, 60}), ChordRecognitionMode::FingeredThreeNotes, 0, ChordType::Major);
    const auto inversion = recognizeChord(keys({52, 55, 60}), ChordRecognitionMode::FingeredThreeNotes, true, true);
    assert(inversion.root == 0 && inversion.type == ChordType::Major && inversion.bass == 4);
    assert(chordName(inversion) == "C/E");
    const auto normalBass = recognizeChord(keys({52, 55, 60}), ChordRecognitionMode::FingeredThreeNotes);
    assert(normalBass.root == 0 && normalBass.bass == 0);
    // Upper/full keyboard and split-off operation always require >=3 keys.
    for (int mode = 0; mode <= 4; ++mode) {
        const auto selected = static_cast<ChordRecognitionMode>(mode);
        assert(!recognizeChord(keys({48}), selected, false).valid());
        assert(!recognizeChord(keys({48, 55}), selected, false).valid());
        assert(!recognizeChord(Held{}, selected).valid());
    }
    // An unsupported dense voicing must not become an arbitrary guessed root.
    assert(!recognizeChord(keys({48, 49, 50, 51, 52, 53}), ChordRecognitionMode::Advanced).valid());
}

void masks() {
    struct Case { ChordType type; std::initializer_list<int> intervals; };
    const Case cases[]{
        {ChordType::Major, {0, 4, 7}}, {ChordType::Minor, {0, 3, 7}},
        {ChordType::Seventh, {0, 4, 7, 10}}, {ChordType::Major7, {0, 4, 7, 11}},
        {ChordType::Minor7, {0, 3, 7, 10}}, {ChordType::Diminished, {0, 3, 6}},
        {ChordType::Augmented, {0, 4, 8}}, {ChordType::Sus2, {0, 2, 7}},
        {ChordType::Sus4, {0, 5, 7}}, {ChordType::Major6, {0, 4, 7, 9}},
        {ChordType::Minor6, {0, 3, 7, 9}}, {ChordType::SeventhSus4, {0, 5, 7, 10}},
        {ChordType::MajorFlat5, {0, 4, 6}}, {ChordType::SeventhFlat5, {0, 4, 6, 10}},
        {ChordType::Major7Flat5, {0, 4, 6, 11}}, {ChordType::Major7Sus4, {0, 5, 7, 11}},
        {ChordType::MinorMajor7, {0, 3, 7, 11}}, {ChordType::Diminished7, {0, 3, 6, 9}},
        {ChordType::DiminishedMajor7, {0, 3, 6, 11}}, {ChordType::Minor7Flat5, {0, 3, 6, 10}},
        {ChordType::Augmented7, {0, 4, 8, 10}}, {ChordType::AugmentedMajor7, {0, 4, 8, 11}},
        {ChordType::RootOctave, {0}}, {ChordType::RootFifth, {0, 7}}
    };
    for (const auto& fixture : cases) {
        unsigned expected = 0;
        for (const int degree : fixture.intervals) expected |= 1U << degree;
        assert(chordPitchClassMask(fixture.type) == expected);
        if (fixture.type == ChordType::RootOctave || fixture.type == ChordType::RootFifth) continue;
        for (int pitch = 0; pitch < 12; ++pitch) {
            Held held{};
            for (const int degree : fixture.intervals)
                held[static_cast<std::size_t>(48 + pitch + degree)] = true;
            expect(held, ChordRecognitionMode::FingeredThreeNotes, pitch, fixture.type);
        }
    }
    assert(chordPitchClassMask(ChordType::None) == 0);
    assert(chordPitchClassMask(static_cast<ChordType>(255)) == 0);
}
} // namespace

int main() {
    compatibility(); oneFinger(); oneFingerPlus(); fingeredAndAdvanced(); masks();
    std::puts("Chord recognition: PASS (manual shortcuts, five modes, 12 roots, inversions, constituent masks)");
}
