#include "silveton/arranger/Pa5xSoundGraph.h"
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>

using namespace silveton::arranger;
namespace {
void check(bool value, const char* message) {
    if (!value) { std::cerr << "FAIL " << message << '\n'; std::exit(1); }
}
void be16(std::vector<std::uint8_t>& bytes, unsigned value) {
    bytes.push_back(static_cast<std::uint8_t>(value >> 8U));
    bytes.push_back(static_cast<std::uint8_t>(value));
}
void be64(std::vector<std::uint8_t>& bytes, std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8)
        bytes.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
void zeroes(std::vector<std::uint8_t>& bytes, std::size_t count) { bytes.insert(bytes.end(), count, 0); }
constexpr std::uint64_t kHighId = 0x0123456789ABCDEFULL;
constexpr std::uint64_t kDecoyId = 0x0FEDCBA987654321ULL;
void source(std::vector<std::uint8_t>& bytes, int version, bool high) {
    be64(bytes, high ? kHighId : 0);
    be16(bytes, high ? (version < 2 ? 0xC123 : 0x0123) : 18);
    bytes.push_back(high ? 1 : 0); bytes.push_back(high ? 100 : 0);
    if (version >= 2) { bytes.push_back(high ? 1 : 0); bytes.push_back(high ? 6 : 0); }
}
std::vector<std::uint8_t> body(int version) {
    std::vector<std::uint8_t> bytes;
    be16(bytes, 0x1234);
    if (version < 3) {
        const std::string name = "Graph fixture";
        bytes.insert(bytes.end(), name.begin(), name.end()); zeroes(bytes, 16 - name.size());
    }
    bytes.push_back(0); zeroes(bytes, 5); bytes.push_back(0); bytes.push_back(127);
    for (int fx = 0; fx < (version >= 2 ? 4 : 2); ++fx) zeroes(bytes, version >= 2 ? 67 : 66);
    zeroes(bytes, version >= 2 ? 6 : 3);
    bytes.push_back(0x81); // one oscillator plus raw policy flags
    zeroes(bytes, 1 + 6 + 14); if (version >= 1) zeroes(bytes, 3);
    source(bytes, version, true); source(bytes, version, false);
    bytes.insert(bytes.end(), {17, 64, 1, 127, 21, 108}); zeroes(bytes, 1);
    if (version >= 1) bytes.insert(bytes.end(), {3, 5});
    if (version >= 2) zeroes(bytes, 2);
    zeroes(bytes, 4 + 20);
    bytes.insert(bytes.end(), {0xFE, 7}); be16(bytes, 0xFF88);
    // A plausible UID in opaque DSP is deliberately not a source reference.
    be64(bytes, kDecoyId); zeroes(bytes, 90 - 8);
    bytes.insert(bytes.end(), {4, 111}); zeroes(bytes, 22);
    if (version >= 2) zeroes(bytes, 6);
    zeroes(bytes, 4); return bytes;
}
std::vector<std::uint8_t> oc31(const std::vector<std::uint8_t>& decoded) {
    check(decoded.size() < 65536, "test literal length fits OC31 token");
    std::vector<std::uint8_t> bytes{'O','C','3','1'};
    for (unsigned shift = 0; shift < 32; shift += 8)
        bytes.push_back(static_cast<std::uint8_t>(decoded.size() >> shift));
    bytes.push_back(1); be16(bytes, static_cast<unsigned>(decoded.size()));
    bytes.insert(bytes.end(), decoded.begin(), decoded.end());
    std::uint8_t checksum = 0; for (auto byte : decoded) checksum ^= byte;
    bytes.push_back(checksum); return bytes;
}
Pa5xPcgSound descriptor(const std::vector<std::uint8_t>& bytes, int version) {
    Pa5xPcgSound sound;
    sound.resourceClass = 4; sound.kind = Pa5xPcgSoundKind::Sound;
    sound.resourceVersion = {static_cast<std::uint8_t>(version), 0};
    sound.payloadLength = bytes.size(); return sound;
}
std::vector<std::uint8_t> newBody(int version) {
    const std::size_t prefix=version<7?313U:(version==7?448U:450U);
    const std::size_t stride=version==5?198U:(version==6?200U:202U);
    const std::size_t countOffset=version<7?288U:423U;
    std::vector<std::uint8_t> bytes(prefix,0);bytes[countOffset]=0x81;
    for(int layer=0;layer<2;++layer){be64(bytes,layer==0?kHighId:0);be16(bytes,layer==0?0x123:18);bytes.push_back(layer==0?1:0);bytes.push_back(layer==0?200:0);zeroes(bytes,version<7?3U:4U);}
    bytes.insert(bytes.end(),{17,64,1,127,21,108});bytes.resize(prefix+stride,0);
    // Authored nonzero fields at the corroborated per-version positions in
    // docs/PA5X_SOUND_DSP_LAYOUT.md. Unknown inserted bytes remain distinct.
    constexpr std::size_t pitchOffsets[]{67U,67U,69U,69U};
    constexpr std::size_t scaledOffsets[]{164U,166U,168U,168U};
    const auto pitch=prefix+pitchOffsets[version-5];
    bytes[pitch]=0xFFU;bytes[pitch+1U]=3U;bytes[pitch+2U]=0xFFU;bytes[pitch+3U]=0xDBU;
    const auto scaled=prefix+scaledOffsets[version-5];
    bytes[scaled]=4U;bytes[scaled+1U]=111U;
    const std::uint8_t amp[]{10U,11U,99U,13U,80U,15U,60U,17U};
    std::copy(std::begin(amp),std::end(amp),bytes.begin()+static_cast<std::ptrdiff_t>(scaled+2U));
    const std::vector<std::size_t> inserted=version==5?std::vector<std::size_t>{152U,156U,157U}:
        version==6?std::vector<std::size_t>{81U,82U,154U,158U,159U}:
                   std::vector<std::size_t>{83U,84U,156U,160U,161U};
    for(std::size_t i=0;i<inserted.size();++i)bytes[prefix+inserted[i]]=static_cast<std::uint8_t>(0xA0U+i);
    return bytes;
}
std::vector<std::uint8_t> read(const std::string& path) {
    std::ifstream file(path, std::ios::binary | std::ios::ate); check(bool(file), "open real PCG");
    const auto length = file.tellg(); check(length >= 0, "real PCG length");
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length)); file.seekg(0);
    file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    check(bool(file), "read real PCG"); return bytes;
}
void uploadedCorpus(const std::string& directory) {
    std::size_t graphs = 0, unsupported = 0, oscillatorCount = 0;
    std::map<unsigned, std::size_t> versions;
    const char* banks[]{"USER01.PCG", "USER02.PCG", "USER03.PCG", "USER04.PCG", "USER05.PCG",
        "USER06.PCG", "USER07.PCG", "USER08.PCG", "USERDK01.PCG", "USERDK02.PCG", "USERDK03.PCG"};
    for (const auto* bank : banks) {
        const auto path = directory + "/" + bank; const auto index = inspectPa5xPcgFile(path);
        check(index.valid, "real PCG index valid before graph inspection");
        const auto bytes = read(path);
        for (const auto& sound : index.sounds) {
            const auto graph = inspectPa5xSoundGraph(bytes, sound);
            check(!graph.parametersDecoded, "reference graph never declares complete synthesis");
            const bool supported = sound.resourceVersion[0] != 4 && sound.resourceVersion[0] <= 8 && sound.resourceVersion[1] == 0 &&
                sound.kind != Pa5xPcgSoundKind::DrumKit;
            if (supported) {
                if (!graph.referenceGraphDecoded) std::cerr << path << ": " << graph.error << '\n';
                check(graph.referenceGraphDecoded && graph.error.empty(), "all supported normal corpus graphs consume complete bodies");
                ++graphs; ++versions[sound.resourceVersion[0]]; oscillatorCount += graph.oscillators.size();
            } else {
                check(!graph.referenceGraphDecoded && !graph.error.empty() && graph.oscillators.empty(),
                    "unsupported versions and Drum Kits do not expose partial references");
                ++unsupported;
            }
        }
    }
    check(graphs == 808 && unsupported == 154 && oscillatorCount==3978, "complete uploaded 962-record graph coverage");
    check(versions[0] == 4 && versions[1] == 2 && versions[2] == 341 && versions[3] == 11,
        "version-specific normal graph counts");
    check(versions[5]==17&&versions[6]==175&&versions[7]==46&&versions[8]==212,"all newer normal reference layouts validated");
    std::cout << "Corpus: " << graphs << " complete normal reference graphs, " << oscillatorCount
              << " oscillators, " << unsupported << " explicitly unsupported resources\n";
}
void originalCorpus(const std::string& path) {
    const auto index = inspectPa5xPcgFile(path); check(index.valid, "original PCG index valid");
    const auto bytes = read(path);
    const Pa5xPcgSound* selected = nullptr;
    for (const auto& sound : index.sounds) if (sound.internalBank == 12 && sound.rawProgram == 20) selected = &sound;
    check(selected != nullptr, "original accordion exact raw bank/program exists");
    const auto graph = inspectPa5xSoundGraph(bytes, *selected);
    check(graph.referenceGraphDecoded && !graph.parametersDecoded && graph.decodedBodyBytes == 707 &&
          graph.oscillators.size() == 2, "original accordion is complete two-oscillator v2 reference graph");
    check(graph.oscillators[0].high.multisampleId == 0x012E4E660A058D08ULL &&
          graph.oscillators[1].high.multisampleId == 0x012EC0746F2641EEULL,
          "original RAM references come from structured oscillator fields");
    const auto selectedFile = inspectPa5xSoundGraphFile(path, 12, 20);
    check(selectedFile.referenceGraphDecoded && selectedFile.oscillators.size() == 2, "raw-address file convenience wrapper");
    check(!inspectPa5xSoundGraphFile(path, 12, 128).referenceGraphDecoded, "missing raw program does not substitute another Sound");
}
}

int main(int argc, char** argv) {
    constexpr std::size_t prefixes[]{183, 186, 325, 309};
    constexpr std::size_t strides[]{177, 179, 191, 191};
    for (int version = 0; version <= 3; ++version) {
        const auto decoded = body(version); const auto bytes = oc31(decoded);
        auto sound = descriptor(bytes, version); const auto graph = inspectPa5xSoundGraph(bytes, sound);
        check(graph.recognized && graph.referenceGraphDecoded && graph.error.empty() && !graph.parametersDecoded,
            "supported normal layout decodes references without declaring synthesis");
        check(graph.decodedBodyBytes == prefixes[version] + strides[version] && graph.oscillators.size() == 1 &&
              graph.oscillators[0].decodedBodyOffset == prefixes[version], "version layout consumes exact common and oscillator fields");
        const auto& osc = graph.oscillators[0];
        check(osc.high.multisampleId == kHighId && osc.high.multisampleNumber == 0x123 &&
              osc.high.source == Pa5xMultisampleSource::Ram && osc.low.source == Pa5xMultisampleSource::Rom,
              "typed source fields preserve RAM UID and ROM source separately");
        check(osc.high.reversed && osc.high.offsetRaw == (version < 2 ? 8 : 6) &&
              osc.high.numberFlagsRaw == (version < 2 ? 0xC123 : 0x123), "versioned number flags and offsets preserved");
        check(osc.keyLow == 21 && osc.keyHigh == 108 && osc.velocityLow == 1 && osc.velocityHigh == 127 &&
              osc.octaveRaw == -2 && osc.transposeRaw == 7 && osc.tuneRaw == -120, "key velocity and pitch values retained");
        check(osc.staticPitchDecoded&&osc.transposeSemitones==7&&osc.staticPitchOffsetCents==-1820,
              "documented octave/semitone/cent units expose static pitch without a guessed envelope");
        check(pa5xVelocityLayer(osc,60,63)==Pa5xVelocityLayer::Low&&pa5xVelocityLayer(osc,60,64)==Pa5xVelocityLayer::High&&
              pa5xVelocityLayer(osc,20,64)==Pa5xVelocityLayer::None&&pa5xVelocityLayer(osc,60,0)==Pa5xVelocityLayer::None,
              "documented inclusive velocity switch selects the high layer without making trigger claims");
        check(osc.equalizer.present==(version>=2),"per-oscillator EQ is version-specific");
        check(osc.scaledVelocityLow == 4 && osc.scaledVelocityHigh == 111 && osc.opaqueDsp[0] == 0x0F &&
              osc.high.multisampleId != kDecoyId, "opaque DSP bytes do not become UID-search references");
        for (std::size_t length = 0; length < decoded.size(); ++length) {
            const auto truncated = oc31({decoded.begin(), decoded.begin() + static_cast<std::ptrdiff_t>(length)});
            const auto partial = inspectPa5xSoundGraph(truncated, descriptor(truncated, version));
            check(!partial.referenceGraphDecoded && partial.oscillators.empty(), "every decoded-body truncation fails closed");
        }
        auto extra = decoded; extra.push_back(0);
        const auto padded = oc31(extra);
        check(!inspectPa5xSoundGraph(padded, descriptor(padded, version)).referenceGraphDecoded, "unconsumed body tail rejected");
        auto broken = decoded; broken[prefixes[version] + 10] = 2;
        const auto badSource = oc31(broken);
        check(!inspectPa5xSoundGraph(badSource, descriptor(badSource, version)).referenceGraphDecoded, "unknown source enum rejected");
        if (version >= 2) {
            broken = decoded; broken[prefixes[version] + 12] = 2;
            const auto badReverse = oc31(broken);
            check(!inspectPa5xSoundGraph(badReverse, descriptor(badReverse, version)).referenceGraphDecoded,
                "non-boolean reverse field rejected");
        }
        broken = decoded;
        broken[prefixes[version] + (version >= 2 ? 28 : 24) + 2] = 128;
        const auto badVelocity = oc31(broken);
        check(!inspectPa5xSoundGraph(badVelocity, descriptor(badVelocity, version)).referenceGraphDecoded,
            "out-of-range oscillator velocity rejected");
        for (std::size_t length = 0; length < bytes.size(); ++length) {
            const std::vector<std::uint8_t> partial(bytes.begin(), bytes.begin() + static_cast<std::ptrdiff_t>(length));
            check(!inspectPa5xSoundGraph(partial, descriptor(partial, version)).referenceGraphDecoded, "every OC31 envelope truncation rejected");
        }
        auto corruptChecksum = bytes; corruptChecksum.back() ^= 1;
        check(!inspectPa5xSoundGraph(corruptChecksum, sound).referenceGraphDecoded, "checksum failure prevents graph publication");
        sound.kind = Pa5xPcgSoundKind::DrumKit;
        check(!inspectPa5xSoundGraph(bytes, sound).referenceGraphDecoded, "Drum Kit kind gate precedes normal body layout");
        sound.kind = Pa5xPcgSoundKind::Sound; sound.payloadOffset = std::numeric_limits<std::size_t>::max();
        check(!inspectPa5xSoundGraph(bytes, sound).referenceGraphDecoded, "overflowing payload bounds rejected");
        sound.payloadOffset = 0; sound.payloadLength = std::numeric_limits<std::size_t>::max();
        check(!inspectPa5xSoundGraph(bytes, sound).referenceGraphDecoded, "overflowing payload length rejected");
        sound.payloadLength = bytes.size(); sound.kind = Pa5xPcgSoundKind::Unknown;
        check(inspectPa5xSoundGraph(bytes, sound).referenceGraphDecoded,
            "unknown external address does not block a proven normal body layout");
    }
    for(int version=5;version<=8;++version){
        const auto raw=newBody(version),packed=oc31(raw);const auto graph=inspectPa5xSoundGraph(packed,descriptor(packed,version));
        check(graph.referenceGraphDecoded&&graph.corpusDerivedReferenceLayout&&graph.oscillators.size()==1&&!graph.parametersDecoded,
              "newer exact source grammar exposes references without inventing synthesis");
        const auto& osc=graph.oscillators[0];
        check(osc.high.multisampleId==kHighId&&osc.high.levelRaw==200&&!osc.high.levelDecoded&&!osc.high.reverseDecoded&&!osc.high.offsetDecoded,
              "new packed source-level flags stay raw and do not become old level/reverse/offset values");
        check(osc.staticPitchDecoded&&osc.octaveRaw==-1&&osc.transposeSemitones==3&&osc.tuneRaw==-37&&
              osc.staticPitchOffsetCents==-937,"corroborated newer static pitch retains exact signed units");
        check(osc.scaledVelocityDecoded&&osc.scaledVelocityLow==4&&osc.scaledVelocityHigh==111,
              "corroborated newer scaled velocity is decoded independently of the original OSC input zone");
        check(osc.dsp.fieldLayoutDecoded&&osc.dsp.newerPaLayoutCorroborated&&!osc.dsp.legacyTritonLayoutCorroborated&&
              osc.dsp.amplitudeEnvelope.startLevel==10&&osc.dsp.amplitudeEnvelope.attackTime==11&&
              osc.dsp.amplitudeEnvelope.attackLevel==99&&osc.dsp.amplitudeEnvelope.releaseTime==17,
              "newer parameter blocks retain their corroborated versioned field layout");
        check(!osc.triggerFieldsDecoded&&!osc.dsp.timeGainLawsDecoded&&!osc.dsp.amsSourceMappingDecoded&&
              !osc.dsp.amplitudeLevelEncodingDecoded&&!osc.dsp.portamentoEncodingDecoded,
              "unknown newer trigger, transfer laws, AMS and extended encodings remain explicit");
        check(osc.additionalDspBytes==(version==5?3U:5U),"all newer unassigned inserted fields are retained");
        for(std::size_t i=0;i<osc.additionalDspBytes;++i)
            check(osc.additionalDspRaw[i]==0xA0U+i,"newer inserted bytes remain exact without an invented meaning");
        const std::size_t prefix=graph.commonRaw.size();const auto width=static_cast<std::size_t>(12+osc.high.extensionBytes);
        check(std::equal(raw.begin()+static_cast<std::ptrdiff_t>(prefix+2U*width+6U),raw.end(),
                         osc.undecodedTail.begin(),osc.undecodedTail.end()),
              "complete original newer tail remains byte-exact after partial field decoding");
        constexpr std::size_t pitchOffsets[]{67U,67U,69U,69U},scaledOffsets[]{164U,166U,168U,168U};
        auto unknownPitch=raw;unknownPitch[prefix+pitchOffsets[version-5]]=2U;
        auto unknownPacked=oc31(unknownPitch);auto unknown=inspectPa5xSoundGraph(unknownPacked,descriptor(unknownPacked,version));
        check(unknown.referenceGraphDecoded&&!unknown.oscillators[0].staticPitchDecoded&&unknown.oscillators[0].octaveRaw==2,
              "unsupported newer octave remains raw without claiming pitch units");
        auto unknownScaled=raw;unknownScaled[prefix+scaledOffsets[version-5]]=112U;
        unknownPacked=oc31(unknownScaled);unknown=inspectPa5xSoundGraph(unknownPacked,descriptor(unknownPacked,version));
        check(unknown.referenceGraphDecoded&&!unknown.oscillators[0].scaledVelocityDecoded&&
              unknown.oscillators[0].scaledVelocityLow==112U&&unknown.oscillators[0].scaledVelocityHigh==111U,
              "reversed newer scaled-velocity ranges remain retained but unsupported");
        for(std::size_t n=0;n<raw.size();++n){const auto cut=oc31({raw.begin(),raw.begin()+static_cast<std::ptrdiff_t>(n)});check(!inspectPa5xSoundGraph(cut,descriptor(cut,version)).referenceGraphDecoded,"newer body truncation fails closed");}
        auto bad=raw;bad[prefix+10]=2;auto bytesBad=oc31(bad);check(!inspectPa5xSoundGraph(bytesBad,descriptor(bytesBad,version)).referenceGraphDecoded,"newer source enum is bounded");
        bad=raw;bad[prefix+2*width+4]=127;bad[prefix+2*width+5]=1;bytesBad=oc31(bad);check(!inspectPa5xSoundGraph(bytesBad,descriptor(bytesBad,version)).referenceGraphDecoded,"newer key-zone ordering is bounded");
        bad=raw;bad.push_back(0);bytesBad=oc31(bad);check(!inspectPa5xSoundGraph(bytesBad,descriptor(bytesBad,version)).referenceGraphDecoded,"newer trailing bytes are not ignored");
    }
    auto decoded = body(2); decoded[18] = 2;
    auto bytes = oc31(decoded);
    check(!inspectPa5xSoundGraph(bytes, descriptor(bytes, 2)).referenceGraphDecoded, "body Drum Kit flag gate cannot be bypassed by normal metadata");
    bytes = oc31(body(2));
    for (const int version : {4,5,6,7,8,255})
        check(!inspectPa5xSoundGraph(bytes, descriptor(bytes, version)).referenceGraphDecoded, "new version is not guessed from an older layout");
    auto minor = descriptor(bytes, 2); minor.resourceVersion[1] = 1;
    check(!inspectPa5xSoundGraph(bytes, minor).referenceGraphDecoded, "unknown minor version rejected");
    if (argc >= 2) uploadedCorpus(argv[1]);
    if (argc >= 3) originalCorpus(argv[2]);
    std::cout << "Pa5X Sound reference graph: PASS (versioned structure, exact bounds, typed sources, unsupported-body status)\n";
}
