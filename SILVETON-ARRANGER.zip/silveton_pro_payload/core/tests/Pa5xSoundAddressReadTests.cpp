#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xFactorySounds.h"

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <set>
#include <string>
#include <sys/stat.h>
#include <tuple>
#include <unistd.h>
#include <utility>
#include <vector>

using namespace silveton::arranger;

namespace {
using Bytes = std::vector<std::uint8_t>;
using Definition = std::pair<std::uint8_t, std::string>;

void check(bool value, const char* message) {
    if (!value) { std::cerr << "FAIL " << message << '\n'; std::exit(1); }
}
void be16(Bytes& bytes, std::size_t value) {
    bytes.push_back(static_cast<std::uint8_t>(value >> 8U));
    bytes.push_back(static_cast<std::uint8_t>(value));
}
void be32(Bytes& bytes, std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8)
        bytes.push_back(static_cast<std::uint8_t>(value >> static_cast<unsigned>(shift)));
}
void append(Bytes& target, const Bytes& source) { target.insert(target.end(), source.begin(), source.end()); }
void chunk(Bytes& target, std::uint32_t tag, const Bytes& payload) {
    be32(target, tag); be32(target, static_cast<std::uint32_t>(payload.size())); append(target, payload);
}
void property(Bytes& target, unsigned type, const Bytes& payload) {
    be16(target, type); be16(target, payload.size()); append(target, payload);
}

Bytes pcg(std::uint8_t rawBank, const std::vector<Definition>& definitions) {
    // Real KORF directory/XREF boundaries and original raw addresses. Bodies
    // deliberately contain only OC31 magic: metadata is readable, synthesis
    // is not. No resolver or native-slot implementation is reproduced here.
    Bytes directory;
    for (const auto& definition : definitions) {
        check(definition.second.size() <= 28, "fixture name fits the stored directory field");
        Bytes fields; be16(fields, 3);
        Bytes name(definition.second.begin(), definition.second.end()); name.resize(28, 0);
        property(fields, 2, name);
        property(fields, 0, {4, rawBank, definition.first});
        property(fields, 1, {2, 0});
        be32(fields, 0x12345678U);
        be16(directory, fields.size()); append(directory, fields);
    }
    Bytes children;
    chunk(children, 0x02000018U, {11, 0, 0, 0, 0, 0, 0, 'K', 'O', 'R', 'F', 0});
    const auto directoryAt = static_cast<std::uint32_t>(children.size() + 8U);
    chunk(children, 0x05010018U, directory);
    std::vector<std::uint32_t> offsets;
    for (std::size_t index = 0; index < definitions.size(); ++index) {
        offsets.push_back(static_cast<std::uint32_t>(children.size() + 8U));
        chunk(children, 0x10020038U, {'O', 'C', '3', '1'});
    }
    Bytes xref{'K', 'B', 'E', 'G'}; be32(xref, directoryAt);
    for (const auto offset : offsets) be32(xref, offset);
    append(xref, {'K', 'E', 'N', 'D'});
    be32(xref, static_cast<std::uint32_t>(offsets.size() + 1U));
    chunk(children, 0xFE000018U, xref);
    Bytes result; chunk(result, 0x01000114U, children); return result;
}

class TemporarySet {
public:
    TemporarySet() {
        char pattern[] = "/tmp/silveton-address-read-XXXXXX";
        const auto* created = ::mkdtemp(pattern); check(created != nullptr, "temporary directory created");
        parent_ = created; root = parent_ + "/Fixture.KST";
        makeDirectory(root); makeDirectory(root + "/SOUND"); makeDirectory(root + "/PCM");
    }
    ~TemporarySet() {
        for (auto it = files_.rbegin(); it != files_.rend(); ++it) (void)::unlink(it->c_str());
        for (auto it = directories_.rbegin(); it != directories_.rend(); ++it) (void)::rmdir(it->c_str());
        (void)::rmdir(parent_.c_str());
    }
    void makeDirectory(const std::string& path) {
        check(::mkdir(path.c_str(), 0700) == 0, "fixture directory created"); directories_.push_back(path);
    }
    void write(const std::string& relative, const Bytes& bytes) {
        const auto path = root + "/" + relative;
        std::ofstream stream(path, std::ios::binary);
        stream.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        check(bool(stream), "fixture file written");
        if (std::find(files_.begin(), files_.end(), path) == files_.end()) files_.push_back(path);
    }
    Pa5xKstIndex index() const {
        Pa5xKstIndex result; result.rootPath = root; result.name = "Fixture.KST";
        result.recognized = true;
        // A supplied structural scan may fail on PCM without invalidating its
        // already discovered canonical PCG directory and original Sound names.
        result.structurallyValid = false;
        result.diagnostics.push_back({KstSeverity::Blocking, "SAMPLE_CONTAINER_UNSUPPORTED", "PCM/RAM01.PCM", "Broken PCM fixture"});
        return result;
    }
    void add(Pa5xKstIndex& index, KstResourceKind kind, const std::string& relative, bool readable = true) const {
        struct stat info{};
        const auto path = root + "/" + relative;
        const bool exists = ::stat(path.c_str(), &info) == 0;
        const auto size = exists && info.st_size > 0 ? static_cast<std::uint64_t>(info.st_size) : 0U;
        index.resources.push_back({kind, relative, size, readable, false});
        ++index.counts[static_cast<std::size_t>(kind)]; index.totalBytes += size;
    }
    std::string root;
private:
    std::string parent_;
    std::vector<std::string> files_, directories_;
};

void expectUser(const Pa5xSetBank& bank, int msb, int lsb, int program,
                const std::string& name, Pa5xPcgSoundKind kind = Pa5xPcgSoundKind::Sound) {
    const auto result = bank.resolveSoundAddress(msb, lsb, program);
    check(result.addressComplete && result.resolution == KstResolution::ExactUserSound && result.name == name,
          "exact original User address resolves its stored PCG name");
    check(result.msb == msb && result.lsb == lsb && result.program == program && result.soundKind == kind,
          "original raw bank/program and Sound namespace survive directory reading");
    check(!result.path.empty() && !result.parametersDecoded && !result.audioDataAvailable,
          "metadata address publication does not claim decoded synthesis or audio");
}

void directoryDoesNotActivateAudio(const Pa5xSetBank& bank) {
    check(!bank.status().indexed, "Sound-name directory is not a fully indexed audio bank");
    check(bank.findSound(121, 66, 20) == nullptr, "audio Sound lookup remains unavailable");
    check(!bank.decodeSample(0x0102030405060708ULL), "read-only Sound directory cannot decode sample audio");
    check(bank.pcmInventories().empty(), "read-only Sound directory publishes no PCM inventories");
}

void factoryAndInvalidAddresses(const Pa5xSetBank& bank) {
    const auto* catalog = pa5xFactorySounds();
    check(pa5xFactorySoundCount() == 2413, "complete official factual Factory catalog is available");
    for (std::size_t index = 0; index < pa5xFactorySoundCount(); ++index) {
        const auto& expected = catalog[index];
        const auto result = bank.resolveSoundAddress(expected.msb, expected.lsb, expected.rawProgram);
        check(result.addressComplete && result.resolution == KstResolution::FactorySoundRequired && result.name == expected.name,
              "every official Factory/Legacy/GM address resolves its exact documented name");
        const auto kind = expected.kind == Pa5xFactorySoundKind::DrumKit ? Pa5xPcgSoundKind::DrumKit : Pa5xPcgSoundKind::Sound;
        check(result.soundKind == kind && result.path.empty() && !result.parametersDecoded && !result.audioDataAvailable,
              "Factory names and Drum Kit kind do not imply bundled ROM programs or audio");
    }
    for (const auto& address : std::vector<std::tuple<int, int, int>>{
            {-1, 0, 0}, {0, -1, 0}, {0, 0, -1}, {128, 0, 0}, {0, 128, 0}, {0, 0, 128}, {0, 0, 500}}) {
        const auto result = bank.resolveSoundAddress(std::get<0>(address), std::get<1>(address), std::get<2>(address));
        check(!result.addressComplete && result.name.empty() && result.resolution == KstResolution::UnsupportedSoundAddress,
              "incomplete or non-MIDI values never become native-slot or display-program guesses");
    }
}

void brokenPcmStillReadsOriginalNames() {
    TemporarySet files;
    const auto user = pcg(0x0C, {{20, "Z named sound"}, {0, "Raw program zero"}, {127, "Raw program 127"}, {2, "A named sound"}});
    files.write("SOUND/USER03.PCG", user);
    files.write("SOUND/USERDK01.PCG", pcg(0x0B, {{121, "Original Drum Kit"}}));
    files.write("PCM/RAM01.PCM", {'b', 'r', 'o', 'k', 'e', 'n'});
    auto index = files.index();
    files.add(index, KstResourceKind::Sound, "SOUND/USER03.PCG");
    files.add(index, KstResourceKind::Sample, "PCM/RAM01.PCM");
    files.add(index, KstResourceKind::Sound, "SOUND/USERDK01.PCG");
    check(!inspectPa5xSampleFile(files.root + "/PCM/RAM01.PCM").valid && !index.structurallyValid,
          "unrelated actual PCM bytes really are invalid");
    Pa5xSetBank bank;
    check(bank.loadSoundDirectory(index), "valid original PCG directory survives broken PCM and false structural flag");
    check(bank.status().recognized && bank.status().soundDirectoryComplete && bank.status().sounds == 5,
          "Sound-directory status is separate from full-bank validity");
    expectUser(bank, 121, 66, 20, "Z named sound");
    expectUser(bank, 121, 66, 0, "Raw program zero");
    expectUser(bank, 121, 66, 127, "Raw program 127");
    expectUser(bank, 121, 66, 2, "A named sound");
    expectUser(bank, 120, 64, 121, "Original Drum Kit", Pa5xPcgSoundKind::DrumKit);
    const auto missing = bank.resolveSoundAddress(121, 66, 21);
    check(missing.resolution == KstResolution::MissingUserSound && missing.name.empty(),
          "raw program20 never resolves through display+1, alphabetical order or filename ordinal");
    check(bank.resolveSoundAddress(121, 64, 121).resolution == KstResolution::MissingUserSound,
          "Drum Kit and normal User Sound namespaces never collide");
    for (const auto& sound : bank.sounds())
        check(!sound.descriptor.parametersDecoded, "unsupported OC31 object bodies never become playable programs");
    directoryDoesNotActivateAudio(bank); factoryAndInvalidAddresses(bank);

    // Missing definitions can only be declared missing when the SOUND discovery
    // pass was complete. An unrelated unreadable PCM directory is harmless.
    auto incomplete = index;
    incomplete.diagnostics.push_back({KstSeverity::Blocking, "FOLDER_UNREADABLE", "SOUND/Lost", "Unreadable Sound folder"});
    check(!bank.loadSoundDirectory(incomplete), "unreadable Sound scope makes missing-address conclusions unavailable");
    expectUser(bank, 121, 66, 20, "Z named sound");
    check(bank.resolveSoundAddress(121, 66, 21).resolution == KstResolution::UnsupportedSoundAddress,
          "incomplete Sound discovery is distinct from a proven missing User Sound");
    incomplete = index;
    incomplete.diagnostics.push_back({KstSeverity::Blocking, "FOLDER_UNREADABLE", "PCM/Lost", "Unreadable PCM folder"});
    check(bank.loadSoundDirectory(incomplete), "PCM discovery errors do not erase a complete Sound-name directory");
    expectUser(bank, 121, 66, 20, "Z named sound");
}

void ambiguousUnknownAndCancelledDirectories() {
    TemporarySet files;
    files.makeDirectory(files.root + "/SOUND/Copy");
    files.write("SOUND/USER03.PCG", pcg(0x0C, {{20, "First original name"}}));
    files.write("SOUND/Copy/USER03.PCG", pcg(0x0C, {{20, "Second original name"}}));
    auto index = files.index(); files.add(index, KstResourceKind::Sound, "SOUND/USER03.PCG");
    files.add(index, KstResourceKind::Sound, "SOUND/Copy/USER03.PCG");
    Pa5xSetBank bank; (void)bank.loadSoundDirectory(index);
    const auto ambiguous = bank.resolveSoundAddress(121, 66, 20);
    check(ambiguous.addressComplete && ambiguous.resolution == KstResolution::AmbiguousSound && ambiguous.name.empty(),
          "duplicate original addresses are reported without choosing a filename or first record");
    directoryDoesNotActivateAudio(bank);

    // A renamed file retains its raw name but is not assigned a guessed bank.
    files.write("SOUND/Export.PCG", pcg(0x0C, {{20, "Unmapped bank name"}}));
    auto unknown = files.index(); files.add(unknown, KstResourceKind::Sound, "SOUND/Export.PCG");
    check(!bank.loadSoundDirectory(unknown), "unknown canonical bank context remains unresolved");
    const auto unresolved = bank.resolveSoundAddress(121, 66, 20);
    check(unresolved.resolution == KstResolution::UnsupportedSoundAddress && unresolved.name.empty(),
          "raw internal bank or record position cannot replace an original external address");

    index.resources.resize(1);
    check(bank.loadSoundDirectory(index), "a fresh complete directory replaces ambiguous prior definitions");
    expectUser(bank, 121, 66, 20, "First original name");
    std::atomic<bool> cancelled{true};
    check(!bank.loadSoundDirectory(index, {}, &cancelled) && bank.status().cancelled,
          "initial cancellation rejects a replacement directory");
    check(bank.resolveSoundAddress(121, 66, 20).name.empty(), "cancelled replacement exposes no previous User name");

    cancelled.store(false); files.add(index, KstResourceKind::Sound, "SOUND/Copy/USER03.PCG");
    check(!bank.loadSoundDirectory(index, [&](const KstProgress& progress) {
        if (progress.phase == "Reading original Sound definitions") cancelled.store(true);
    }, &cancelled), "cancellation during metadata reading rejects a partial candidate");
    check(bank.status().cancelled && bank.resolveSoundAddress(121, 66, 20).name.empty(),
          "partially parsed cancelled definitions never leak as resolved User names");
    directoryDoesNotActivateAudio(bank);
    factoryAndInvalidAddresses(bank); // Built-in factual names remain independent.
}

void moreThanFiveHundredOriginalDefinitions() {
    TemporarySet files; auto index = files.index();
    const std::array<std::uint8_t, 6> rawBanks{{0x09, 0x0A, 0x0C, 0x0D, 0x18, 0x19}};
    for (std::size_t bank = 0; bank < rawBanks.size(); ++bank) {
        std::vector<Definition> entries;
        // Deliberately descending storage order: the original program byte,
        // rather than directory order, must determine the result.
        for (int program = 127; program >= 0; --program)
            entries.emplace_back(static_cast<std::uint8_t>(program), "Bank" + std::to_string(bank + 1U) + " raw" + std::to_string(program));
        const auto path = "SOUND/USER0" + std::to_string(bank + 1U) + ".PCG";
        files.write(path, pcg(rawBanks[bank], entries)); files.add(index, KstResourceKind::Sound, path);
    }
    Pa5xSetBank bank; check(bank.loadSoundDirectory(index), "all six complete original User directories load");
    check(bank.sounds().size() == 768, "metadata has no fixed500-sampler-slot truncation");
    for (std::size_t ordinal = 0; ordinal < rawBanks.size(); ++ordinal)
        for (int program = 0; program < 128; ++program)
            expectUser(bank, 121, 64 + static_cast<int>(ordinal), program,
                       "Bank" + std::to_string(ordinal + 1U) + " raw" + std::to_string(program));
    directoryDoesNotActivateAudio(bank);
}

void suppliedSoundDirectory(const std::string& root) {
    struct Bank { const char* name; std::size_t count; };
    const std::array<Bank, 11> banks{{
        {"USER01.PCG",128}, {"USER02.PCG",128}, {"USER03.PCG",128}, {"USER04.PCG",128},
        {"USER05.PCG",77}, {"USER06.PCG",106}, {"USER07.PCG",43}, {"USER08.PCG",70},
        {"USERDK01.PCG",128}, {"USERDK02.PCG",5}, {"USERDK03.PCG",21}}};
    Pa5xKstIndex index; index.rootPath = root; index.recognized = true; index.structurallyValid = false;
    index.diagnostics.push_back({KstSeverity::Blocking, "SAMPLE_CONTAINER_UNSUPPORTED", "PCM/RAM01.PCM", "Audio unavailable during metadata-only read"});
    std::vector<Pa5xPcgSound> expected;
    for (const auto& bank : banks) {
        const auto path = root + "/SOUND/" + bank.name;
        const auto parsed = inspectPa5xPcgFile(path); check(parsed.valid && parsed.sounds.size() == bank.count, "supplied PCG directory remains complete");
        index.resources.push_back({KstResourceKind::Sound, std::string("SOUND/") + bank.name, parsed.fileSize, true, true});
        expected.insert(expected.end(), parsed.sounds.begin(), parsed.sounds.end());
    }
    Pa5xSetBank bank; check(bank.loadSoundDirectory(index), "supplied Sound names read independently of unavailable PCM");
    check(expected.size() == 962 && bank.sounds().size() == 962, "all962 uploaded original definitions survive");
    std::set<std::tuple<int,int,int>> unique;
    for (const auto& sound : expected) {
        check(sound.addressKnown && unique.emplace(sound.msb, sound.lsb, sound.rawProgram).second,
              "supplied original addresses remain exact and unique");
        expectUser(bank, sound.msb, sound.lsb, sound.rawProgram, sound.name, sound.kind);
    }
    expectUser(bank, 121, 71, 7, "Yayli Tavir C");
    directoryDoesNotActivateAudio(bank);
    std::puts("Supplied Sound directory: all962 original names/addresses read with full-bank audio unavailable");
}

}

int main(int argc, char** argv) {
    if (argc != 1 && argc != 2) { std::fputs("Usage: Pa5xSoundAddressReadTests [Uploaded.KST]\n", stderr); return 2; }
    Pa5xSetBank empty; factoryAndInvalidAddresses(empty);
    const auto unavailable = empty.resolveSoundAddress(121, 66, 20);
    check(unavailable.addressComplete && unavailable.resolution == KstResolution::UnsupportedSoundAddress && unavailable.name.empty(),
          "an unavailable Sound directory is distinct from a proven missing User Sound");
    brokenPcmStillReadsOriginalNames(); ambiguousUnknownAndCancelledDirectories(); moreThanFiveHundredOriginalDefinitions();
    if (argc == 2) suppliedSoundDirectory(argv[1]);
    std::puts("Pa5X Sound address metadata: exact User/Factory names, missing/ambiguous/incomplete states and cancellation passed");
}
