#include "silveton/arranger/ArrangerEngine.h"
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <initializer_list>
#include <limits>
#include <tuple>
#include <vector>
using namespace silveton::arranger;

struct Capture final:RenderCallbacks {
    struct Event {std::uint64_t sample;int player,track,status,key,velocity;};
    std::vector<Event> events;
    std::uint64_t base{0};std::uint32_t cursor{0};
    void render(std::uint32_t offset,std::uint32_t frames) noexcept override {assert(offset==cursor);cursor+=frames;}
    void midi(int p,int t,std::uint8_t s,std::uint8_t a,std::uint8_t b) noexcept override {events.push_back({base+cursor,p,t,s,a,b});}
    void run(ArrangerEngine& engine,std::uint32_t frames,double rate=48000){cursor=0;engine.process(frames,rate,*this);assert(cursor==frames);base+=frames;}
    std::vector<Event> notes()const{std::vector<Event> out;for(auto e:events)if(e.status==0x90||e.status==0x80)out.push_back(e);return out;}
};
static std::shared_ptr<Style> makeStyle(bool fill=false){
    auto s=std::make_shared<Style>();s->name="Timing fixture";s->tempoBpm=60;
    s->tracks[0].used=true;s->tracks[0].role=TrackRole::Accompaniment;
    auto& one=s->sections[static_cast<std::size_t>(Element::Var1)];one.available=true;one.lengthTicks=7680;one.events={{0,0,0x90,60,100},{7000,0,0x80,60,0}};
    auto& two=s->sections[static_cast<std::size_t>(Element::Var2)];two.available=true;two.lengthTicks=1920;two.events={{0,0,0x90,64,100},{480,0,0x80,64,0}};
    if(fill){auto& f=s->sections[static_cast<std::size_t>(Element::Fill2)];f.available=true;f.lengthTicks=1920;f.events={{0,0,0x90,72,100},{240,0,0x80,72,0},{480,0,0x90,74,100},{720,0,0x80,74,0}};}
    return s;
}
static void seed(ArrangerEngine& e,const std::shared_ptr<Style>& s,int p=0){assert(e.installStyle(p,s));assert(e.postMidi(0x90,48,100));assert(e.post({CommandType::Play,p}));}
static void chordTests(){
    std::array<bool,128> h{};h[52]=h[55]=h[60]=true;auto c=detectChord(h);assert(c.root==0&&c.type==ChordType::Major&&c.bass==4);assert(chordName(c)=="C/E");
    h={};h[45]=h[48]=h[52]=h[55]=true;c=detectChord(h);assert(c.root==9&&c.type==ChordType::Minor7);
    h={};h[48]=h[51]=h[54]=true;c=detectChord(h);assert(c.root==0&&c.type==ChordType::Diminished);
    h={};assert(!detectChord(h).valid());
}
static void transportTests(){
    ArrangerEngine e;Capture c;seed(e,makeStyle(true));c.run(e,48000);assert(e.snapshot(0).playing);
    assert(e.post({CommandType::SelectElement,0,static_cast<int>(Element::Var2)}));
    c.run(e,1);assert(e.snapshot(0).element==Element::Fill2);
    // Fill starts at the current beat. Tick zero is already past.
    auto n=c.notes();
    assert(std::none_of(n.begin(),n.end(),[](auto v){return v.status==0x90&&v.key==72;}));
    auto fill=std::find_if(n.begin(),n.end(),[](auto v){return v.status==0x90&&v.key==74;});
    assert(fill!=n.end()&&fill->sample==48000);
    c.run(e,143999);c.run(e,1);assert(e.snapshot(0).element==Element::Var2);
    n=c.notes();auto var=std::find_if(n.begin(),n.end(),[](auto v){return v.status==0x90&&v.key==64;});
    assert(var!=n.end()&&var->sample==192000);
    assert(e.post({CommandType::Stop,0}));c.run(e,1);assert(!e.snapshot(0).playing);
    assert(e.installStyle(0,nullptr));c.run(e,1);assert(e.snapshot(0).style==nullptr);
}
static void revoiceTests(){
    ArrangerEngine e;Capture c;seed(e,makeStyle());c.run(e,100);auto n=c.notes();assert(n.back().status==0x90&&n.back().key==60);
    assert(e.postMidi(0x80,48,0));assert(e.postMidi(0x90,50,100));c.run(e,1);n=c.notes();assert(n.back().status==0x90&&n.back().key==62&&n.back().sample==100);
    assert(e.postMidi(0x80,50,0));c.run(e,1);assert(e.snapshot(0).chord.valid());
    assert(e.post({CommandType::SetMemory,0,0,0}));c.run(e,1);assert(!e.snapshot(0).chord.valid());n=c.notes();assert(n.back().status==0x80&&n.back().key==62);
    assert(e.postMidi(0x90,48,100));c.run(e,1);assert(e.snapshot(0).chord.valid());
    assert(e.post({CommandType::SetSplit,0,0,45}));c.run(e,1);assert(!e.snapshot(0).chord.valid());
}
static void dualAndClockTests(){
    auto s=makeStyle();s->tempoBpm=123.0;auto& sec=s->sections[static_cast<std::size_t>(Element::Var1)];sec.lengthTicks=1920;sec.events={{0,0,0x90,60,100},{480,0,0x80,60,0}};
    auto collect=[&](unsigned block){ArrangerEngine e;Capture c;seed(e,s);seed(e,s,1);e.post({CommandType::SetTempo,1,0,60});for(unsigned remaining=250000;remaining;){const unsigned step=std::min(remaining,block);c.run(e,step);remaining-=step;}return c.notes();};
    const auto a=collect(97),b=collect(2048);assert(a.size()==b.size());for(std::size_t i=0;i<a.size();++i)assert(std::tie(a[i].sample,a[i].player,a[i].status,a[i].key)==std::tie(b[i].sample,b[i].player,b[i].status,b[i].key));
    ArrangerEngine e;Capture c;seed(e,s);c.run(e,1);
    const auto firstCount=c.events.size();
    e.post({CommandType::ToggleSyncStart,0,0,1});c.run(e,1);
    assert(e.snapshot(0).playing&&e.snapshot(0).syncStart&&c.events.size()==firstCount);
    e.post({CommandType::SetSyncStart,0,0,1});c.run(e,1);
    assert(e.snapshot(0).playing&&c.events.size()==firstCount);
    e.post({CommandType::Stop,0});c.run(e,1);
    e.post({CommandType::SetSyncStart,0,0,1});c.run(e,1);
    assert(!e.snapshot(0).playing&&e.snapshot(0).syncStart);
    e.postMidi(0x90,52,100);e.postMidi(0x90,55,100);c.run(e,1);assert(e.snapshot(0).playing);
}
static std::vector<std::uint8_t> midi(){return {'M','T','h','d',0,0,0,6,0,0,0,1,1,0xE0,'M','T','r','k',0,0,0,20,0,0xFF,0x51,3,7,0xA1,0x20,0,0x90,60,100,0x83,0x60,0x80,60,0,0,0xFF,0x2F,0};}
static void importerTests(){
    auto bytes=midi();auto result=importMidiBytes(bytes,"Real MIDI fixture");assert(result);assert(result.style->tempoBpm==120.0);const auto& sec=result.style->sections[static_cast<std::size_t>(Element::Var1)];assert(sec.lengthTicks==1920&&sec.events.size()==2&&sec.events.back().tick==480&&sec.events.back().status==0x80);
    for(std::size_t i=0;i<bytes.size();++i){auto broken=bytes;broken.resize(i);assert(!importMidiBytes(broken,"truncated"));}
    bytes[12]=0x80;assert(!importMidiBytes(bytes,"SMPTE"));
    ArrangerEngine e;assert(!e.installStyle(-1,makeStyle()));auto invalid=makeStyle();invalid->ppq=0;assert(!e.installStyle(0,invalid));
}

static void setting(ArrangerEngine& e,Capture& c,CommandType type,double value){
    assert(e.post({type,0,0,value}));c.run(e,1);
}
static void heldNotes(ArrangerEngine& e,Capture& c,std::initializer_list<int> notes,bool down){
    for(const int note:notes)assert(e.postMidi(down?0x90:0x80,note,down?100:0));
    c.run(e,1);
}
static void expectChord(const ArrangerEngine& e,int root,ChordType type){
    const auto chord=e.snapshot(0).chord;assert(chord.valid()&&chord.root==root&&chord.type==type);
}
static std::shared_ptr<Style> gatedTracks(std::uint32_t gate=7000){
    auto style=std::make_shared<Style>();style->name="Four source gates";style->tempoBpm=60;
    const std::array<TrackRole,4> roles{{TrackRole::Drums,TrackRole::Percussion,TrackRole::Bass,TrackRole::Accompaniment}};
    const std::array<std::uint8_t,4> notes{{36,42,48,60}};
    auto& section=style->sections[static_cast<std::size_t>(Element::Var1)];section.available=true;section.lengthTicks=7680;
    for(std::size_t i=0;i<roles.size();++i){
        style->tracks[i].used=true;style->tracks[i].role=roles[i];
        section.events.push_back({0,static_cast<std::uint8_t>(i),0x90,notes[i],100});
    }
    for(std::size_t i=0;i<roles.size();++i)
        section.events.push_back({gate,static_cast<std::uint8_t>(i),0x80,notes[i],0});
    return style;
}

static void recognitionAreas(){
    // Manual pp.176-179: Lower permits shortcuts; Upper/Full always need 3
    // physical notes. User contract: C4/key60 is included in Lower; Upper
    // begins at61, so key60 cannot contribute to its three-note threshold.
    ArrangerEngine e;Capture c;
    assert(e.recognitionMode()==static_cast<int>(ChordRecognitionMode::FingeredOneNote));
    assert(e.chordScanArea()==1&&e.splitEnabled()&&!e.bassInversion()&&!e.damperLatch());
    setting(e,c,CommandType::SetMemory,0);
    heldNotes(e,c,{59},true);expectChord(e,11,ChordType::Major);
    heldNotes(e,c,{59},false);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{60},true);expectChord(e,0,ChordType::Major);
    heldNotes(e,c,{60},false);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{48,52,55},true);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::SetChordScanArea,2);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{60},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{64},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{67},true);assert(!e.snapshot(0).chord.valid()); // only64/67 are Upper
    heldNotes(e,c,{60,64,67},false);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{61},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{65},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{68},true);expectChord(e,1,ChordType::Major);
    heldNotes(e,c,{61,65,68},false);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{48,52,55},false);
    setting(e,c,CommandType::SetChordScanArea,3);
    heldNotes(e,c,{48,64},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{67},true);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::SetMemory,1);
    setting(e,c,CommandType::SetChordScanArea,0);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{50,54,57},true);assert(!e.snapshot(0).chord.valid());
    // The compatibility boolean restores the previous active scan area.
    setting(e,c,CommandType::SetChordScan,1);assert(e.chordScanArea()==3);
    setting(e,c,CommandType::SetChordScan,0);assert(e.chordScanArea()==0&&!e.snapshot(0).chord.valid());

    ArrangerEngine split;Capture d;
    setting(split,d,CommandType::SetMemory,0);
    setting(split,d,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::OneFinger));
    heldNotes(split,d,{48},true);expectChord(split,0,ChordType::Major);
    setting(split,d,CommandType::SetSplitEnabled,0);
    assert(!split.splitEnabled());
    assert(split.recognitionMode()==static_cast<int>(ChordRecognitionMode::FingeredThreeNotes));
    assert(!split.snapshot(0).chord.valid());
    heldNotes(split,d,{64,67},true);expectChord(split,0,ChordType::Major);
}

static void fingeredThreeAndMemory(){
    ArrangerEngine e;Capture c;
    setting(e,c,CommandType::SetMemory,0);
    setting(e,c,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::FingeredThreeNotes));
    heldNotes(e,c,{48},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{52},true);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{55},true);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::SetMemory,1);
    heldNotes(e,c,{48,52,55},false);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::SetMemory,0);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{50,54,57},true);expectChord(e,2,ChordType::Major);
    // Turning Memory off while keys remain down must keep that played chord.
    setting(e,c,CommandType::SetMemory,1);setting(e,c,CommandType::SetMemory,0);
    expectChord(e,2,ChordType::Major);
    heldNotes(e,c,{50,54,57},false);assert(!e.snapshot(0).chord.valid());
    setting(e,c,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::Advanced));
    heldNotes(e,c,{48},true);expectChord(e,0,ChordType::RootOctave);
    heldNotes(e,c,{55},true);expectChord(e,0,ChordType::RootFifth);
}

static void rememberedChordSurvivesStaggeredRelease(){
    for(auto mode:{ChordRecognitionMode::OneFinger,ChordRecognitionMode::OneFingerPlus,
                   ChordRecognitionMode::FingeredOneNote,ChordRecognitionMode::FingeredThreeNotes,
                   ChordRecognitionMode::Advanced}){
        ArrangerEngine e;Capture c;assert(e.installStyle(0,makeStyle()));
        setting(e,c,CommandType::SetChordRecognition,static_cast<int>(mode));
        setting(e,c,CommandType::SetMemory,1);
        if(mode==ChordRecognitionMode::OneFinger || mode==ChordRecognitionMode::OneFingerPlus){
            heldNotes(e,c,{47,46,48},true);
            expectChord(e,0,ChordType::Minor7);
            heldNotes(e,c,{46},false);
            expectChord(e,0,ChordType::Minor7);
            heldNotes(e,c,{47,48},false);
            expectChord(e,0,ChordType::Minor7);
        }else{
            heldNotes(e,c,{48,52,55,59},true);
            expectChord(e,0,ChordType::Major7);
            setting(e,c,CommandType::SetSyncStart,1);
            heldNotes(e,c,{59},false);
            expectChord(e,0,ChordType::Major7);
            assert(e.postMidi(0xB0,64,127));c.run(e,1);
            assert(e.postMidi(0xB0,121,0));c.run(e,1);
            expectChord(e,0,ChordType::Major7);
            assert(!e.snapshot(0).playing);
            heldNotes(e,c,{48,52,55},false);
            expectChord(e,0,ChordType::Major7);
            heldNotes(e,c,{50,53,57},true);
            expectChord(e,2,ChordType::Minor);
            assert(e.snapshot(0).playing);
        }
    }
}

static void damperLatch(){
    // Manual p.180: notes may change while the style keeps the latched chord;
    // the pedal release must re-evaluate the physically held keys immediately.
    ArrangerEngine e;Capture c;
    setting(e,c,CommandType::SetMemory,0);
    setting(e,c,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::FingeredThreeNotes));
    setting(e,c,CommandType::SetChordScanArea,3);
    setting(e,c,CommandType::SetDamperLatch,1);assert(e.damperLatch());
    heldNotes(e,c,{48,52,55},true);expectChord(e,0,ChordType::Major);
    assert(e.postMidi(0xB0,64,127));c.run(e,1);
    heldNotes(e,c,{48,52,55},false);expectChord(e,0,ChordType::Major);
    heldNotes(e,c,{50,54,57},true);expectChord(e,0,ChordType::Major);
    assert(e.postMidi(0xB0,64,0));c.run(e,1);expectChord(e,2,ChordType::Major);
    heldNotes(e,c,{50,54,57},false);assert(!e.snapshot(0).chord.valid());
    // A pedal down before a valid chord must not prevent first recognition.
    assert(e.postMidi(0xB0,64,127));c.run(e,1);
    heldNotes(e,c,{48,52,55},true);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::Panic,0);assert(!e.snapshot(0).chord.valid());
    heldNotes(e,c,{50,54,57},true);expectChord(e,2,ChordType::Major);
    // Disabling the option makes ordinary CC64 unable to freeze recognition.
    setting(e,c,CommandType::SetDamperLatch,0);
    assert(e.postMidi(0xB0,64,127));c.run(e,1);
    heldNotes(e,c,{50,54,57},false);assert(!e.snapshot(0).chord.valid());
}

static void bassInversionRevoicesOnlyBass(){
    ArrangerEngine e;Capture c;assert(e.installStyle(0,gatedTracks()));
    setting(e,c,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::FingeredThreeNotes));
    setting(e,c,CommandType::SetChordScanArea,3);
    setting(e,c,CommandType::SetBassInversion,1);assert(e.bassInversion());
    heldNotes(e,c,{48,52,55},true);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::Play,0);c.run(e,100);
    c.events.clear();
    assert(e.postMidi(0x80,48,0));assert(e.postMidi(0x90,60,100));c.run(e,1);
    const auto chord=e.snapshot(0).chord;
    assert(chord.root==0&&chord.type==ChordType::Major&&chord.bass==4);
    const auto notes=c.notes();assert(notes.size()==2);
    assert(notes[0].track==2&&notes[0].status==0x80&&notes[0].key==48);
    assert(notes[1].track==2&&notes[1].status==0x90&&notes[1].key==52);
    c.events.clear();setting(e,c,CommandType::SetBassInversion,0);
    const auto restored=c.notes();assert(restored.size()==2);
    assert(restored[0].track==2&&restored[0].status==0x80&&restored[0].key==52);
    assert(restored[1].track==2&&restored[1].status==0x90&&restored[1].key==48);
}

static void noChordGatesAndDrums(){
    ArrangerEngine e;Capture c;assert(e.installStyle(0,gatedTracks(480)));
    setting(e,c,CommandType::SetMemory,0);
    setting(e,c,CommandType::SetChordScanArea,0);
    setting(e,c,CommandType::Play,0);c.run(e,100);
    auto notes=c.notes();assert(notes.size()==2);
    assert(notes[0].track==0&&notes[0].key==36&&notes[1].track==1&&notes[1].key==42);
    c.events.clear();
    heldNotes(e,c,{48,52,55},true);assert(!e.snapshot(0).chord.valid()&&c.notes().empty());
    setting(e,c,CommandType::SetChordScanArea,1);expectChord(e,0,ChordType::Major);
    notes=c.notes();assert(notes.size()==2&&notes[0].track==2&&notes[1].track==3);
    c.events.clear();
    setting(e,c,CommandType::SetMemory,1);
    setting(e,c,CommandType::SetChordScanArea,0);assert(!e.snapshot(0).chord.valid());
    notes=c.notes();assert(notes.size()==2);
    assert(notes[0].status==0x80&&notes[0].track==2&&notes[1].status==0x80&&notes[1].track==3);
    // Source gates stay live while recognition is off, and their later NoteOff
    // must clear the remembered velocities even if no pitched note is sounding.
    c.run(e,48000);c.events.clear();
    setting(e,c,CommandType::SetChordScanArea,1);expectChord(e,0,ChordType::Major);
    assert(c.notes().empty());
}

static void advancedAudibleConstituents(){
    // The manual's root+octave/root+fifth choices must affect the emitted style
    // notes, not only the chord label. Do not prescribe an arbitrary octave
    // voicing when several allowed target notes are equally near the source.
    auto style=std::make_shared<Style>();style->name="Held major triad";style->tempoBpm=60;
    style->tracks[0].used=true;style->tracks[0].role=TrackRole::Accompaniment;
    auto& section=style->sections[static_cast<std::size_t>(Element::Var1)];
    section.available=true;section.lengthTicks=7680;
    section.events={{0,0,0x90,60,100},{0,0,0x90,64,100},{0,0,0x90,67,100},
                    {7000,0,0x80,60,0},{7000,0,0x80,64,0},{7000,0,0x80,67,0}};
    ArrangerEngine e;Capture c;assert(e.installStyle(0,style));
    setting(e,c,CommandType::SetMemory,0); // intentional revoicing on key release
    setting(e,c,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::Advanced));
    heldNotes(e,c,{48},true);expectChord(e,0,ChordType::RootOctave);
    setting(e,c,CommandType::Play,0);c.run(e,100);
    auto notes=c.notes();
    assert(notes.size()==2 && notes[0].key==60 && notes[1].key==72);
    c.events.clear();heldNotes(e,c,{55},true);expectChord(e,0,ChordType::RootFifth);
    notes=c.notes();
    assert(notes.size()==2 && notes[0].status==0x80 && notes[0].key==72);
    assert(notes[1].status==0x90 && notes[1].key==67);
    c.events.clear();heldNotes(e,c,{55},false);expectChord(e,0,ChordType::RootOctave);
    notes=c.notes();
    assert(notes.size()==2 && notes[0].status==0x80 && notes[0].key==67);
    assert(notes[1].status==0x90 && notes[1].key==72);
}

static void majorSeventhKeepsSourceTonic(){
    auto style=makeStyle();
    style->sections[static_cast<std::size_t>(Element::Var1)].events={
        {0,0,0x90,60,100},{0,0,0x90,64,100},{0,0,0x90,67,100},
        {7000,0,0x80,60,0},{7000,0,0x80,64,0},{7000,0,0x80,67,0}};
    ArrangerEngine e;Capture c;assert(e.installStyle(0,style));
    setting(e,c,CommandType::SetChordRecognition,static_cast<int>(ChordRecognitionMode::FingeredThreeNotes));
    heldNotes(e,c,{48,52,55},true);expectChord(e,0,ChordType::Major);
    setting(e,c,CommandType::Play,0);c.run(e,100);c.events.clear();
    heldNotes(e,c,{59},true);expectChord(e,0,ChordType::Major7);
    // All three sounding pitches are shared by the two harmonies.
    assert(c.notes().empty());
}

static void velocityControlTests(){
    ArrangerEngine e;Capture c;auto s=makeStyle();
    auto& br=s->sections[static_cast<std::size_t>(Element::Break)];br.available=true;br.lengthTicks=1920;
    br.events={{0,0,0x90,72,100},{480,0,0x80,72,0}};
    assert(e.installStyle(0,s));assert(e.installStyle(1,s));c.run(e,1);
    auto set=[&](int mode,int player=0,int value=95){assert(e.post({CommandType::SetVelocityControl,player,mode,static_cast<double>(value)}));c.run(e,1);};
    auto note=[&](int key,int vel,int ch=0){assert(e.postMidi(0x90|ch,key,vel));};
    auto release=[&](int key,int ch=0){assert(e.postMidi(0x80|ch,key,0));};
    set(2,1);assert(e.velocityControl()==2&&e.velocityPlayer()==1&&e.velocityThreshold()==95);
    note(48,95);c.run(e,1);assert(!e.snapshot(1).playing);release(48);c.run(e,1);
    note(64,127);c.run(e,1);assert(!e.snapshot(1).playing);release(64);c.run(e,1);
    note(48,100);note(52,120);note(55,110);c.run(e,1);assert(e.snapshot(1).playing&&!e.snapshot(0).playing);
    note(57,127);c.run(e,1);assert(e.snapshot(1).playing);
    release(48);release(52);release(55);release(57);c.run(e,1);
    note(60,96);c.run(e,1);assert(!e.snapshot(1).playing);release(60);c.run(e,1);
    set(3);assert(!e.bassInversion());note(48,100);note(52,110);note(55,120);c.run(e,1);assert(e.bassInversion());
    release(48);release(52);release(55);c.run(e,1);
    note(48,100);c.run(e,1);assert(!e.bassInversion());release(48);c.run(e,1);
    set(4);assert(e.memory());note(48,100);c.run(e,1);assert(!e.memory());release(48);c.run(e,1);
    set(1);assert(e.post({CommandType::Play,0}));c.run(e,1);note(48,120);c.run(e,1);
    assert(e.snapshot(0).queued==Element::Break||e.snapshot(0).element==Element::Break);release(48);c.run(e,1);
    set(2);assert(e.post({CommandType::SetKeyboardSplit,0,0,60}));c.run(e,1);
    const bool before=e.snapshot(0).playing;note(48,127);c.run(e,1);assert(e.snapshot(0).playing==before);release(48);c.run(e,1);
    set(0);assert(e.velocityControl()==0);
}
static void manualBassTests(){
    ArrangerEngine e;Capture c;auto style=gatedTracks(480);auto& sec=style->sections[static_cast<std::size_t>(Element::Var1)];sec.lengthTicks=960;
    assert(e.installStyle(0,style));assert(e.installStyle(1,style));c.run(e,1);
    auto command=[&](CommandType type,int player=0){assert(e.post({type,player}));c.run(e,1);};
    auto note=[&](int key,int vel){assert(e.postMidi(0x90,key,vel));c.run(e,1);};
    auto up=[&](int key){assert(e.postMidi(0x80,key,0));c.run(e,1);};
    command(CommandType::ToggleManualBass);assert(e.snapshot(0).manualBass&&e.manualBassConsumesKey(60)&&!e.manualBassConsumesKey(61));
    c.events.clear();note(52,99);auto n=c.notes();assert(n.size()==1&&n[0].track==2&&n[0].key==52&&n[0].velocity==99);
    note(48,101);n=c.notes();assert(n[n.size()-2].status==0x80&&n[n.size()-2].key==52&&n.back().status==0x90&&n.back().key==48);
    const auto count=n.size();note(64,127);assert(c.notes().size()==count);up(64);
    command(CommandType::Play);c.events.clear();c.run(e,100000);n=c.notes();
    assert(std::any_of(n.begin(),n.end(),[](auto v){return v.track==0&&v.status==0x90;}));
    assert(std::any_of(n.begin(),n.end(),[](auto v){return v.track==1&&v.status==0x90;}));
    assert(std::none_of(n.begin(),n.end(),[](auto v){return v.track>=2;})); // no auto bass/ACC or held Bass cut at loops
    command(CommandType::Stop);c.events.clear();up(48);n=c.notes();assert(n.size()==2&&n[0].status==0x80&&n[0].key==48&&n[1].status==0x90&&n[1].key==52);
    command(CommandType::ToggleManualBass,1);assert(!e.snapshot(0).manualBass&&e.snapshot(1).manualBass);n=c.notes();assert(n.back().player==1&&n.back().track==2&&n.back().key==52);
    c.events.clear();assert(e.postMidi(0xB0,123,0));c.run(e,1);n=c.notes();assert(n.size()==1&&n[0].status==0x80&&n[0].key==52);
    note(60,100);assert(e.snapshot(1).manualBass);assert(e.post({CommandType::SetKeyboardSplit,0,0,60}));c.run(e,1);assert(!e.manualBassActive());
    assert(e.post({CommandType::SetKeyboardSplit,0,1,60}));c.run(e,1);command(CommandType::ToggleManualBass);command(CommandType::Panic);assert(!e.manualBassActive());
}
static void chordSequenceTests(){
    ArrangerEngine e;Capture c;auto style=makeStyle();assert(e.installStyle(0,style));c.run(e,0);
    assert(e.post({CommandType::ToggleSequenceRecord,0}));c.run(e,0);assert(e.chordSequence().mode==ChordSequenceMode::RecordArmed);
    assert(e.postMidi(0x90,48,100));assert(e.post({CommandType::Play,0}));c.run(e,48000);
    assert(e.chordSequence().mode==ChordSequenceMode::Recording);assert(e.chordSequence().data.count==1);
    assert(e.postMidi(0x80,48,0));assert(e.postMidi(0x90,55,100));c.run(e,48000);
    assert(e.postMidi(0x80,55,0));assert(e.postMidi(0x90,57,100));c.run(e,96000);
    assert(e.post({CommandType::Stop,0}));c.run(e,0);auto seq=e.chordSequence();
    assert(seq.mode==ChordSequenceMode::Idle&&seq.data.count==3&&seq.data.lengthTicks==1920);
    assert(seq.data.events[0].tick==0&&seq.data.events[1].tick==480&&seq.data.events[2].tick==960);
    assert(seq.data.events[0].chord.root==0&&seq.data.events[1].chord.root==7&&seq.data.events[2].chord.root==9);
    ChordSequenceData restored;auto encoded=encodeChordSequence(seq.data);assert(decodeChordSequence(encoded,restored));assert(encodeChordSequence(restored)==encoded);
    assert(!decodeChordSequence(encoded+" garbage",restored));auto invalid=restored;invalid.events[1].tick=0;assert(!e.loadChordSequence(invalid,0));
    assert(e.loadChordSequence(restored,0));c.run(e,0);assert(e.post({CommandType::ToggleSequencePlay,0}));c.run(e,0);assert(e.chordSequence().mode==ChordSequenceMode::PlayArmed);
    assert(e.post({CommandType::Play,0}));c.events.clear();c.run(e,48000);expectChord(e,0,ChordType::Major);
    assert(e.postMidi(0x80,57,0));assert(e.postMidi(0x90,50,100));c.run(e,48000);expectChord(e,7,ChordType::Major);
    c.run(e,96000);expectChord(e,9,ChordType::Major);c.run(e,1);expectChord(e,0,ChordType::Major);
    assert(e.chordSequence().current==0);auto notes=c.notes();assert(std::any_of(notes.begin(),notes.end(),[](auto n){return n.status==0x90&&n.key==55;}));
    assert(e.post({CommandType::ToggleSequencePlay,0}));c.run(e,1);expectChord(e,2,ChordType::Major);
    assert(e.post({CommandType::ToggleSequenceLock,0}));c.run(e,0);assert(e.installStyle(0,makeStyle()));c.run(e,0);assert(e.chordSequence().data.count==3);
    assert(e.post({CommandType::ToggleSequenceLock,0}));c.run(e,0);assert(e.installStyle(0,makeStyle()));c.run(e,0);assert(e.chordSequence().data.count==0);
    // Tempo conversion and block-size independent loop attacks, shared with existing engine.
    auto collect=[&](unsigned block){ArrangerEngine player;Capture capture;assert(player.installStyle(0,style));capture.run(player,0);
        assert(player.loadChordSequence(restored,0));capture.run(player,0);assert(player.post({CommandType::ToggleSequencePlay,0}));assert(player.post({CommandType::SetTempo,0,0,120}));assert(player.post({CommandType::Play,0}));
        for(unsigned left=200000;left;){const auto count=std::min(block,left);capture.run(player,count);left-=count;}return capture.notes();};
    auto a=collect(97),b=collect(2048);assert(a.size()==b.size());for(std::size_t i=0;i<a.size();++i)assert(std::tie(a[i].sample,a[i].status,a[i].key)==std::tie(b[i].sample,b[i].status,b[i].key));
    // While a Style plays, START SEQ waits for the next measure. Changing
    // the variation afterwards does not reset the sequence's independent clock.
    ArrangerEngine live;Capture l;seed(live,makeStyle(true));l.run(live,24000);
    assert(live.loadChordSequence(restored,0));l.run(live,0);
    assert(live.post({CommandType::ToggleSequencePlay,0}));l.run(live,167999);
    assert(live.chordSequence().mode==ChordSequenceMode::PlayArmed);
    l.run(live,1);l.run(live,1);assert(live.chordSequence().mode==ChordSequenceMode::Playing);
    assert(live.post({CommandType::SelectElement,0,static_cast<int>(Element::Var2)}));l.run(live,48000);
    expectChord(live,7,ChordType::Major);assert(live.chordSequence().current==1);
    assert(live.post({CommandType::Stop,0}));l.run(live,0);assert(live.chordSequence().mode==ChordSequenceMode::PlayArmed);
    assert(live.post({CommandType::Play,0}));l.run(live,1);expectChord(live,0,ChordType::Major);
    // Recording can also start from the original Synchro Start input gesture.
    ArrangerEngine sync;Capture sc;assert(sync.installStyle(1,makeStyle()));sc.run(sync,0);
    assert(sync.post({CommandType::ToggleSequenceRecord,1}));assert(sync.post({CommandType::SetSyncStart,1,0,1}));sc.run(sync,0);
    assert(sync.postMidi(0x90,50,100));sc.run(sync,48000);assert(sync.snapshot(1).playing&&sync.chordSequence().mode==ChordSequenceMode::Recording&&sync.chordSequence().player==1);
    assert(sync.post({CommandType::Stop,1}));sc.run(sync,0);assert(sync.chordSequence().data.events[0].chord.root==2);
}
int main(){
    chordSequenceTests();manualBassTests();velocityControlTests();
    chordTests();transportTests();revoiceTests();dualAndClockTests();importerTests();
    recognitionAreas();fingeredThreeAndMemory();rememberedChordSurvivesStaggeredRelease();damperLatch();bassInversionRevoicesOnlyBass();noChordGatesAndDrums();advancedAudibleConstituents();majorSeventhKeepsSourceTonic();
    std::puts("Arranger core: PASS (Chord Sequence record/play/edit codec, recognition areas/modes, bass gates, latch/memory, drums, sample clock, transitions, importer bounds)");
    return 0;
}
