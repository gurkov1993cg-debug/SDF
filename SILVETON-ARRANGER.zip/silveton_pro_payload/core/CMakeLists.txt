cmake_minimum_required(VERSION 3.16)
project(SilvetonLiveMidiCore LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(SILVETON_LIVE_BUILD_TESTS "Build core tests" OFF)
option(SILVETON_LIVE_ENABLE_SANITIZERS "Enable ASan and UBSan" OFF)
option(SILVETON_WERROR "Treat compiler warnings as errors" OFF)
set(SILVETON_WERROR_FLAG "$<$<BOOL:${SILVETON_WERROR}>:-Werror>")

add_library(silveton_live_core STATIC
    src/arranger/ArrangerEngine.cpp
    src/arranger/GuitarMode.cpp
    src/arranger/ChordRecognition.cpp
    src/arranger/MidiStyleImporter.cpp
    src/arranger/KorgStyleImport.cpp
    src/arranger/KorgSourceEffects.cpp
    src/arranger/Pa5xEffectCatalog.cpp
    src/arranger/Pa5xKstIndex.cpp
    src/arranger/Pa5xPcgIndex.cpp
    src/arranger/Pa5xPerformanceIndex.cpp
    src/arranger/Pa5xSoundGraph.cpp
    src/arranger/Pa5xProgramImport.cpp
    src/arranger/Pa5xSampleProgram.cpp
    src/arranger/Pa5xSampleDiskCache.cpp
    src/arranger/Pa5xPcmMetadataCache.cpp
    src/arranger/Pa5xCatalogSnapshot.cpp
    src/arranger/Pa5xProgramSnapshot.cpp
    src/arranger/Pa5xPreparedSetSnapshot.cpp
    src/arranger/Pa5xDrumSampleProgram.cpp
    src/arranger/Pa5xSetBank.cpp
    src/arranger/PaStyleBank.cpp
    src/arranger/PaSeriesTrackSettings.cpp
    src/arranger/Pa5xStyleRead.cpp
    src/arranger/Pa5xStyleSourceSettings.cpp
    src/arranger/Pa5xKeyboardSetRead.cpp
    src/arranger/Pa5xFactorySounds.cpp
    src/arranger/Pa5xMultisampleImport.cpp
    src/arranger/Pa5xDrumKit.cpp
    src/arranger/Pa5xKstCatalog.cpp
    src/arranger/Pa5xSampleIndex.cpp
    src/arranger/Pa5xPredictiveDecoder.cpp
    src/arranger/Pa5xOc31.cpp
    src/Portamento.cpp
    src/PitchCoordinator.cpp
    src/ThirdModule.cpp
    src/Ribbon.cpp
    src/MidiRouter.cpp
    src/sampler/SincInterpolator.cpp
    src/sampler/SampleStream.cpp
    src/sampler/SampleStreamPrefetcher.cpp
    src/sampler/SvBankFormat.cpp
    src/sampler/SvBankRuntime.cpp
    src/sampler/SampleEditor.cpp
    src/sampler/AudioFileLoader.cpp
    src/sampler/SamplerEngine.cpp
    src/sampler/SourceEffects.cpp
    src/sampler/NumberedFx.cpp
    src/sampler/NumberedFxRuntime.cpp
    src/sampler/NumberedDynamics.cpp
    src/sampler/NumberedCombinedFx.cpp
    src/sampler/NumberedModFx.cpp
    src/sampler/NumberedTimeFx.cpp
    src/sampler/NumberedToneFx.cpp
    src/sampler/channelstrip/SslDynamicsCircuit.cpp
    src/sampler/EngineDefs.cpp
    
    src/sampler/SoloDefs.cpp
    src/sampler/SoloVoice.cpp 
    src/sampler/ModelBank.cpp
    
    
    src/sampler/KorgImporter.cpp
    src/sampler/SetPackage.cpp
    src/sampler/WaveTable.cpp
    src/sampler/UserWaves.cpp
    src/sampler/SamplerLibrary.cpp
    src/sampler/ProgramEditor.cpp
    src/sampler/MultisampleEditor.cpp
    src/sampler/SampleRecorder.cpp
)
set_target_properties(silveton_live_core PROPERTIES POSITION_INDEPENDENT_CODE ON)
target_include_directories(silveton_live_core PUBLIC include)
target_include_directories(silveton_live_core PRIVATE src/sampler)


if(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
 target_compile_options(silveton_live_core PRIVATE -Wall -Wextra -Wpedantic -Wconversion -Wshadow ${SILVETON_WERROR_FLAG})
endif()
if(SILVETON_LIVE_ENABLE_SANITIZERS AND CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
 target_compile_options(silveton_live_core PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)
 target_link_options(silveton_live_core PUBLIC -fsanitize=address,undefined)
endif()
add_library(silveton_test_models STATIC EXCLUDE_FROM_ALL tests/fixtures/ModelFixtures.cpp)
target_link_libraries(silveton_test_models PUBLIC silveton_live_core)
target_include_directories(silveton_test_models PUBLIC tests/fixtures)
if(NOT ANDROID)
 add_executable(silveton_pa5x_kst_inspect EXCLUDE_FROM_ALL tools/Pa5xKstInspect.cpp)
 target_link_libraries(silveton_pa5x_kst_inspect PRIVATE silveton_live_core)
 add_executable(silveton_pa5x_sound_inspect EXCLUDE_FROM_ALL tools/Pa5xSoundInspect.cpp)
 target_link_libraries(silveton_pa5x_sound_inspect PRIVATE silveton_live_core)
 add_executable(silveton_pa5x_performance_inspect EXCLUDE_FROM_ALL tools/Pa5xPerformanceInspect.cpp)
 target_link_libraries(silveton_pa5x_performance_inspect PRIVATE silveton_live_core)
 add_executable(silveton_personal_solo_render EXCLUDE_FROM_ALL tools/PersonalSoloRender.cpp)
 target_link_libraries(silveton_personal_solo_render PRIVATE silveton_live_core)
endif()
if(SILVETON_LIVE_BUILD_TESTS)
 add_executable(silveton_source_oscillator_import_tests tests/SourceOscillatorImportTests.cpp)
 target_link_libraries(silveton_source_oscillator_import_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_oscillator_import_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_oscillator_import_tests COMMAND silveton_source_oscillator_import_tests)
    add_executable(silveton_pa_series_catalog_snapshot_tests tests/PaSeriesCatalogSnapshotTests.cpp)
    target_link_libraries(silveton_pa_series_catalog_snapshot_tests PRIVATE silveton_live_core)
    target_compile_options(silveton_pa_series_catalog_snapshot_tests PRIVATE -UNDEBUG)
    add_test(NAME silveton_pa_series_catalog_snapshot_tests COMMAND silveton_pa_series_catalog_snapshot_tests)
 add_executable(silveton_source_oscillator_equalizer_tests tests/SourceOscillatorEqualizerTests.cpp)
 target_link_libraries(silveton_source_oscillator_equalizer_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_oscillator_equalizer_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_oscillator_equalizer_tests COMMAND silveton_source_oscillator_equalizer_tests)
 add_executable(silveton_pa_series_bank_read_tests tests/PaSeriesBankReadTests.cpp)
 target_link_libraries(silveton_pa_series_bank_read_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa_series_bank_read_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa_series_bank_read_tests COMMAND silveton_pa_series_bank_read_tests)
 add_executable(silveton_source_oscillator_velocity_tests tests/SourceOscillatorVelocityTests.cpp)
 target_link_libraries(silveton_source_oscillator_velocity_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_oscillator_velocity_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_oscillator_velocity_tests COMMAND silveton_source_oscillator_velocity_tests)
 add_executable(silveton_source_fx_note_tests tests/SourceFxNoteTests.cpp)
 target_link_libraries(silveton_source_fx_note_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_fx_note_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_fx_note_tests COMMAND silveton_source_fx_note_tests)
 add_executable(silveton_source_engine_integration_tests tests/SourceEngineIntegrationTests.cpp)
 target_link_libraries(silveton_source_engine_integration_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_engine_integration_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_engine_integration_tests COMMAND silveton_source_engine_integration_tests)
 add_executable(silveton_source_oscillator_helper_tests tests/SourceOscillatorHelperTests.cpp)
 target_link_libraries(silveton_source_oscillator_helper_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_oscillator_helper_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_oscillator_helper_tests COMMAND silveton_source_oscillator_helper_tests)
 add_executable(silveton_source_tempo_tests tests/SourceTempoTests.cpp)
 target_link_libraries(silveton_source_tempo_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_tempo_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_tempo_tests COMMAND silveton_source_tempo_tests)
 add_executable(silveton_source_persistence_tests tests/SourcePersistenceTests.cpp)
 target_link_libraries(silveton_source_persistence_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_source_persistence_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_source_persistence_tests COMMAND silveton_source_persistence_tests)
 add_executable(silveton_pa5x_sound_address_read_tests tests/Pa5xSoundAddressReadTests.cpp)
 target_link_libraries(silveton_pa5x_sound_address_read_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_sound_address_read_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_sound_address_read_tests COMMAND silveton_pa5x_sound_address_read_tests)
 add_executable(silveton_pa5x_style_read_tests tests/Pa5xStyleReadTests.cpp)
 target_link_libraries(silveton_pa5x_style_read_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_style_read_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_style_read_tests COMMAND silveton_pa5x_style_read_tests)
 add_executable(silveton_pa5x_keyboard_set_read_tests tests/Pa5xKeyboardSetReadTests.cpp)
 target_link_libraries(silveton_pa5x_keyboard_set_read_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_keyboard_set_read_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_keyboard_set_read_tests COMMAND silveton_pa5x_keyboard_set_read_tests)
 add_executable(silveton_pa5x_factory_sounds_tests tests/Pa5xFactorySoundsTests.cpp)
 target_link_libraries(silveton_pa5x_factory_sounds_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_factory_sounds_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_factory_sounds_tests COMMAND silveton_pa5x_factory_sounds_tests)
 add_executable(silveton_pa5x_set_bank_tests tests/Pa5xSetBankTests.cpp)
 target_link_libraries(silveton_pa5x_set_bank_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_set_bank_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_set_bank_tests COMMAND silveton_pa5x_set_bank_tests)
 add_executable(silveton_pa5x_multisample_tests tests/Pa5xMultisampleImportTests.cpp)
 target_link_libraries(silveton_pa5x_multisample_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_multisample_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_multisample_tests COMMAND silveton_pa5x_multisample_tests)
 add_executable(silveton_pa5x_drumkit_tests tests/Pa5xDrumKitTests.cpp)
 target_link_libraries(silveton_pa5x_drumkit_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_drumkit_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_drumkit_tests COMMAND silveton_pa5x_drumkit_tests)
 add_executable(silveton_pa5x_sample_playback_tests tests/Pa5xSamplePlaybackTests.cpp)
 target_link_libraries(silveton_pa5x_sample_playback_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_sample_playback_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_sample_playback_tests COMMAND silveton_pa5x_sample_playback_tests)
 add_executable(silveton_pa5x_catalog_tests tests/Pa5xKstCatalogTests.cpp)
 target_link_libraries(silveton_pa5x_catalog_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_catalog_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_catalog_tests COMMAND silveton_pa5x_catalog_tests)
 add_executable(silveton_pa5x_predictive_tests tests/Pa5xPredictiveDecoderTests.cpp)
 target_link_libraries(silveton_pa5x_predictive_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_predictive_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_predictive_tests COMMAND silveton_pa5x_predictive_tests)
 add_executable(silveton_pa5x_program_tests tests/Pa5xProgramImportTests.cpp)
 target_link_libraries(silveton_pa5x_program_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_program_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_program_tests COMMAND silveton_pa5x_program_tests)
 add_executable(silveton_pa5x_pcm2_tests tests/Pa5xPcm2AudioTests.cpp)
 target_link_libraries(silveton_pa5x_pcm2_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_pcm2_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_pcm2_tests COMMAND silveton_pa5x_pcm2_tests)
 add_executable(silveton_korg_style_playback_tests tests/KorgStylePlaybackTests.cpp)
 target_link_libraries(silveton_korg_style_playback_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_korg_style_playback_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_korg_style_playback_tests COMMAND silveton_korg_style_playback_tests)
 add_test(NAME silveton_korg_style_audio_fixture COMMAND silveton_korg_style_playback_tests --write-fixture ${CMAKE_BINARY_DIR}/native-style-fixture.stg)
 set_tests_properties(silveton_korg_style_audio_fixture PROPERTIES FIXTURES_SETUP native_stg_audio)
 add_executable(silveton_chord_recognition_tests tests/ChordRecognitionTests.cpp)
 target_link_libraries(silveton_chord_recognition_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_chord_recognition_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_chord_recognition_tests COMMAND silveton_chord_recognition_tests)
 add_executable(silveton_pa5x_performance_tests tests/Pa5xPerformanceIndexTests.cpp)
 target_link_libraries(silveton_pa5x_performance_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_performance_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_performance_tests COMMAND silveton_pa5x_performance_tests)
 add_executable(silveton_pa5x_sound_graph_tests tests/Pa5xSoundGraphTests.cpp)
 target_link_libraries(silveton_pa5x_sound_graph_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_sound_graph_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_sound_graph_tests COMMAND silveton_pa5x_sound_graph_tests)
 add_executable(silveton_pa5x_pcg_tests tests/Pa5xPcgIndexTests.cpp)
 target_link_libraries(silveton_pa5x_pcg_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_pcg_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_pcg_tests COMMAND silveton_pa5x_pcg_tests)
 add_executable(silveton_pa5x_sample_tests tests/Pa5xSampleIndexTests.cpp)
 target_link_libraries(silveton_pa5x_sample_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_sample_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_sample_tests COMMAND silveton_pa5x_sample_tests)
 add_executable(silveton_pa5x_kst_tests tests/Pa5xKstIndexTests.cpp)
 target_link_libraries(silveton_pa5x_kst_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pa5x_kst_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pa5x_kst_tests COMMAND silveton_pa5x_kst_tests)
 add_executable(silveton_korg_style_index_tests tests/KorgStyleImportTests.cpp)
 target_link_libraries(silveton_korg_style_index_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_korg_style_index_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_korg_style_index_tests COMMAND silveton_korg_style_index_tests)
 add_executable(silveton_arranger_tests tests/ArrangerTests.cpp)
 target_link_libraries(silveton_arranger_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_arranger_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_arranger_tests COMMAND silveton_arranger_tests)
 add_executable(silveton_solo_model_tests tests/SoloModelTests.cpp)
 target_link_libraries(silveton_solo_model_tests PRIVATE silveton_live_core)
 target_include_directories(silveton_solo_model_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_model_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_model_tests COMMAND silveton_solo_model_tests)
 enable_testing()
 add_executable(silveton_solo_tuning_tests tests/SoloTuningTests.cpp)
 target_link_libraries(silveton_solo_tuning_tests PRIVATE silveton_live_core)
 target_include_directories(silveton_solo_tuning_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_tuning_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_tuning_tests COMMAND silveton_solo_tuning_tests)
 add_executable(silveton_pitch_mapping_tests tests/PitchMappingTests.cpp)
 target_link_libraries(silveton_pitch_mapping_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pitch_mapping_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pitch_mapping_tests COMMAND silveton_pitch_mapping_tests)
 add_executable(silveton_combi_independent_tests tests/CombiIndependentSmoke.cpp)
 target_link_libraries(silveton_combi_independent_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_combi_independent_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_combi_independent_tests COMMAND silveton_combi_independent_tests)
 add_executable(silveton_velocity_shape_tests tests/VelocityShapeSmoke.cpp)
 target_link_libraries(silveton_velocity_shape_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_velocity_shape_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_velocity_shape_tests COMMAND silveton_velocity_shape_tests)
 add_executable(silveton_solo_source_tests tests/SoloSourceTests.cpp)
 target_link_libraries(silveton_solo_source_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_solo_source_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_source_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_source_tests COMMAND silveton_solo_source_tests)
 add_executable(silveton_solo_bend_transitions_tests tests/SoloBendTransitionsTests.cpp)
 target_link_libraries(silveton_solo_bend_transitions_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_solo_bend_transitions_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_bend_transitions_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_bend_transitions_tests COMMAND silveton_solo_bend_transitions_tests)
 add_executable(silveton_solo_compatibility_tests tests/SoloCompatibilityTests.cpp)
 target_link_libraries(silveton_solo_compatibility_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_solo_compatibility_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_compatibility_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_compatibility_tests COMMAND silveton_solo_compatibility_tests)
 add_executable(silveton_core_audio_fix_tests tests/CoreAudioFixTests.cpp)
 target_link_libraries(silveton_core_audio_fix_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_core_audio_fix_tests PRIVATE src/sampler)
 target_compile_options(silveton_core_audio_fix_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_core_audio_fix_tests COMMAND silveton_core_audio_fix_tests)
 add_executable(silveton_realtime_safety_tests tests/RealtimeSafetyTests.cpp)
 target_link_libraries(silveton_realtime_safety_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_realtime_safety_tests PRIVATE src/sampler)
 target_compile_options(silveton_realtime_safety_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_realtime_safety_tests COMMAND silveton_realtime_safety_tests)
 add_executable(silveton_portamento_regression_tests tests/PortamentoRegressionTests.cpp)
 target_link_libraries(silveton_portamento_regression_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_portamento_regression_tests PRIVATE src/sampler)
 target_compile_options(silveton_portamento_regression_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_portamento_regression_tests COMMAND silveton_portamento_regression_tests)
 add_executable(silveton_live_core_tests tests/CoreTests.cpp)
 target_link_libraries(silveton_live_core_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_live_core_tests PRIVATE src/sampler)
 target_compile_options(silveton_live_core_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_live_core_tests COMMAND silveton_live_core_tests)
 add_executable(silveton_live_fuzz_tests tests/FuzzTests.cpp)
 target_link_libraries(silveton_live_fuzz_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_live_fuzz_tests PRIVATE src/sampler)
 target_compile_options(silveton_live_fuzz_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_live_fuzz_tests COMMAND silveton_live_fuzz_tests)
 add_executable(silveton_sampler_tests tests/SamplerTests.cpp)
 target_link_libraries(silveton_sampler_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_sampler_tests PRIVATE src/sampler)
 target_compile_options(silveton_sampler_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_sampler_tests COMMAND silveton_sampler_tests)
 add_executable(silveton_layered_polyphony_tests tests/LayeredPolyphonyTests.cpp)
 target_link_libraries(silveton_layered_polyphony_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_layered_polyphony_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_layered_polyphony_tests COMMAND silveton_layered_polyphony_tests)
 add_executable(silveton_fsx_tests tests/FsCompatTests.cpp)
 target_link_libraries(silveton_fsx_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_fsx_tests PRIVATE src/sampler)
 target_compile_options(silveton_fsx_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_fsx_tests COMMAND silveton_fsx_tests)
endif()
