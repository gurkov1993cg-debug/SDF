// A native COMBI slot owns its sampler settings. This exact-revision auxiliary
// pointer adds arranger-only Split/scan/range ownership without changing SET v19.
namespace {
std::string nativeKeyboardOverwriteOwner(int slot,const std::string& bankIdentity){
    std::ostringstream out;out<<"SILVETON_NATIVE_COMBI 1\nBANK "<<std::quoted(bankIdentity)<<"\nSLOT "<<slot<<'\n';return out.str();
}
std::string nativeKeyboardOverwriteName(const std::string& owner,unsigned collision){
    return "ARRANGER_NATIVE_KBD_"+keyboardFxHex(keyboardMetadataHash(owner))+
        (collision==0U?std::string{}:"_"+std::to_string(collision))+".ref";
}
std::set<std::string> nativeKeyboardOverwriteFiles(const std::string& parent,const std::string& owner){
    std::set<std::string> result;
    const auto prefix="ARRANGER_NATIVE_KBD_"+keyboardFxHex(keyboardMetadataHash(owner));
    for(const auto& name:files::listNames(parent))if(startsWith(name,prefix)&&endsWith(name,".ref"))result.insert(name);
    return result;
}
bool nativeKeyboardOverwriteIdentity(const std::string& owner,const sampler::Combi& combi,std::string& identity){
    const auto bytes=sampler::SetPackage::combiMetadataBytes(combi);if(!bytes)return false;
    identity=owner+"BYTES "+std::to_string(bytes->size())+"\nREVISION "+keyboardFxHex(keyboardMetadataHash(*bytes))+"\n";return true;
}
}

bool ArrangerView::prepareNativeKeyboardOverwrite(int slot,const std::string& bankIdentity,
        const sampler::Combi& stored,KeyboardWorkingSet& state,bool& applied,std::string& error){
    applied=false;error.clear();
    if(slot<1||slot>500||bankIdentity.empty()||persistentSessionPath_.empty())return true;
    const auto owner=nativeKeyboardOverwriteOwner(slot,bankIdentity);
    const auto parent=files::parentOf(persistentSessionPath_);
    const auto primary=files::join(parent,nativeKeyboardOverwriteName(owner,0U));
    if(!files::exists(primary))return true;
    SavedKeyboardEntry entry;
    if(!readSavedKeyboardEntry(primary,entry,error))return false;
    std::string profile=primary;
    if(!startsWith(entry.identity,owner)){
        profile.clear();const auto profiles=nativeKeyboardOverwriteFiles(parent,owner);
        for(unsigned collision=1;collision<1000U;++collision){
            const auto filename=nativeKeyboardOverwriteName(owner,collision);
            if(profiles.find(filename)==profiles.end())continue;
            const auto path=files::join(parent,filename);SavedKeyboardEntry candidate;
            if(!readSavedKeyboardEntry(path,candidate,error))return false;
            if(startsWith(candidate.identity,owner)){entry=std::move(candidate);profile=path;break;}
        }
        if(profile.empty())return true;
    }
    std::string identity;
    if(!nativeKeyboardOverwriteIdentity(owner,stored,identity)){
        error="The COMBI settings are too large to verify; current sounds were kept";return false;
    }
    if(!entry.sourcePath.empty()||entry.identity!=identity){
        error="The stored COMBI changed; earlier arranger settings were kept and not applied";return true;
    }
    // Resolve through the established full-performance path after verifying
    // the additional native owner/revision. It is not a Library selection.
    auto assembled=entry;assembled.identity="SILVETON_ASSEMBLED_KEYBOARD_SET 1\nREVISION "+entry.metadataFile;
    host::ArrangerKeyboardSet prepared;SavedKeyboardRecall recall;
    if(!prepareSavedKeyboardEntry(assembled,prepared,recall,error))return false;
    sampler::SetLoadResult loaded;StoredKeyboardMetadata metadata;
    if(!loadKeyboardMetadataPackage(keyboardPerformancePath(persistentSessionPath_,entry.metadataFile),loaded,metadata,error))return false;
    state.combi=std::make_shared<const sampler::Combi>(std::move(prepared.combi));state.read.reset();state.recall=std::move(recall);
    state.sourcePath.clear();state.entryPath.clear();state.sourceIdentity.clear();
    state.metadataFile=entry.metadataFile;state.metadataBindings=loaded.data.extra;
    state.nativeSlot=slot;state.nativeBankIdentity=bankIdentity;applied=true;return true;
}

bool ArrangerView::commitNativeKeyboardOverwrite(int slot,const std::string& bankIdentity,const std::string& name){
    if(slot<1||slot>500||bankIdentity.empty()||bankIdentity!=keyboardSamplerBankIdentity(ctrl_.currentBankFile())||
       !ctrl_.engine.nativeCombiSlotOccupied(0,0,slot)||currentKeyboardCombiSlot_!=slot||currentKeyboardCombiBankIdentity_!=bankIdentity||
       !activeNativeKeyboardSetPath_.empty()||!activeSavedKeyboardEntryPath_.empty()||selectedKeyboardSet_>=0){
        showToast("The current COMBI destination changed; select it again or use Save As",6000);return false;
    }
    if(styleKeyboardCue_.serial!=0||host::arrangerHost().keyboardStyleSelection(selectedPlayer_).pending){
        showToast("Wait for the Style change to finish before saving",5000);return false;
    }
    const auto finalName=trimmed(name);
    if(finalName.empty()||finalName.size()>256U||finalName.find_first_of("\r\n")!=std::string::npos){
        showToast("Choose a valid Keyboard Set name",5000);return false;
    }
    if(persistentSessionPath_.empty()||!ctrl_.engine.nativeKeyboardCombi()){
        showToast("COMBI settings storage is unavailable",6000);return false;
    }
    const auto owner=nativeKeyboardOverwriteOwner(slot,bankIdentity);
    const auto parent=files::parentOf(persistentSessionPath_);
    const auto primary=files::join(parent,nativeKeyboardOverwriteName(owner,0U));
    std::string destination;
    if(!files::exists(primary))destination=primary;
    else{
        SavedKeyboardEntry first;std::string error;
        if(!readSavedKeyboardEntry(primary,first,error)){showToast(error,6500);return false;}
        if(startsWith(first.identity,owner))destination=primary;
        else{
            const auto profiles=nativeKeyboardOverwriteFiles(parent,owner);std::string firstEmpty;
            for(unsigned collision=1;collision<1000U;++collision){
                const auto filename=nativeKeyboardOverwriteName(owner,collision);const auto path=files::join(parent,filename);
                if(profiles.find(filename)==profiles.end()){if(firstEmpty.empty())firstEmpty=path;continue;}
                SavedKeyboardEntry candidate;if(!readSavedKeyboardEntry(path,candidate,error)){showToast(error,6500);return false;}
                if(startsWith(candidate.identity,owner)){destination=path;break;}
            }
            if(destination.empty())destination=firstEmpty;
        }
    }
    if(destination.empty()){showToast("A COMBI settings destination could not be allocated",6500);return false;}
    // First freeze all arranger-only ownership. A failed write has not touched
    // the stored COMBI or its previous auxiliary pointer at this stage.
    auto state=captureKeyboardWorkingSet();std::string frozenPath,error;
    if(!freezeKeyboardWorkingSet(state,owner,0,finalName,frozenPath,error)){showToast(error,6500);return false;}
    const auto checkpoint=ctrl_.engine.nativePerformanceCheckpoint();const auto settings=ctrl_.setSettingsSnapshot();
    if(!checkpoint){showToast("The previous COMBI could not be retained",6500);return false;}
    const auto rollback=[this,&checkpoint,&settings](const std::string& reason){
        const bool engineOkay=ctrl_.engine.nativeRestorePerformanceCheckpoint(checkpoint);
        const bool storageOkay=ctrl_.restoreSetSettingsSnapshot(settings);
        refresh();showToast(reason+(engineOkay&&storageOkay?" — previous COMBI kept":" — previous COMBI could not be fully restored"),8000);
        return false;
    };
    if(!ctrl_.writeCombiSlot(slot,finalName))return rollback(ctrl_.lastFailure());
    const auto stored=ctrl_.engine.nativeStoredCombi(0,0,slot);std::string identity;
    if(!stored||bankIdentity!=keyboardSamplerBankIdentity(ctrl_.currentBankFile())||!nativeKeyboardOverwriteIdentity(owner,*stored,identity))
        return rollback("The saved COMBI settings could not be verified");
    std::ostringstream record;record<<"SILVETON_USER_KEYBOARD_SET 1\n0 1\n"<<std::quoted(stored->name)<<'\n'<<std::quoted(std::string{})<<'\n'
        <<std::quoted(identity)<<'\n'<<std::quoted(state.metadataFile)<<'\n';
    const auto pending=destination+".pending";
    if(!files::writeText(pending,record.str())||std::rename(pending.c_str(),destination.c_str())!=0){
        (void)files::removeRecursively(pending);return rollback("The COMBI arranger settings were not saved");
    }
    keyboardMetadataFile_=state.metadataFile;keyboardMetadataSavedBindings_=state.metadataBindings;
    keyboardMetadataSavedState_=ctrl_.engine.nativeKeyboardCombi();
    currentKeyboardCombiSlot_=slot;currentKeyboardCombiBankIdentity_=bankIdentity;
    persistentSaveAllowed_=true;persistentRecordProtected_=false;
    refresh();markPersistentStateChanged();flushPersistentState();showToast("Current COMBI and arranger settings saved",4500);return true;
}
