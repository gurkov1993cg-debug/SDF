// Style-driven recall is prepared on control. Publication still follows the
// bounded UI poll; it is not a sample-accurate cross-engine transaction.
void ArrangerView::clearStyleKeyboardCue(bool restorePrevious){
    auto previous=std::move(styleKeyboardCue_);styleKeyboardCue_={};
    if(restorePrevious&&previous.preview&&previous.previous.combi){
        const int position=selectedStyleKey_==previous.previousOwner?previous.previousPosition:-1;
        if(!applyWorkingKeyboardSet(previous.previous,position,false))
            showToast("The previous keyboard setup could not be restored",6500);
    }
}
void ArrangerView::overrideStyleKeyboardCue(){
    if(styleKeyboardCue_.serial==0)return;
    // A full manual recall overrides the pending automatic choice. Keep its
    // cue only to consume the later Style commit without another recall.
    styleKeyboardCue_.preview=false;styleKeyboardCue_.manualOverride=true;styleKeyboardCue_.prepared={};
}

void ArrangerView::styleKeyboardSelectionAccepted(int player){
    if(player!=selectedPlayer_)return;
    auto source=host::arrangerHost().keyboardStyleSelection(player);
    if(source.serial==0)return;
    refresh(false);
    if(styleKeyboardCue_.serial!=0&&styleKeyboardCue_.serial!=source.serial){
        const auto active=arrangerStyleSelectionKey(host::arrangerHost().snapshot(player));
        if(styleKeyboardCue_.preview&&active==styleKeyboardCue_.key&&selectedStyleKey_==active){
            const auto index=static_cast<std::size_t>(styleKeyboardCue_.position);
            keyboardWorkingSets_[index]=captureKeyboardWorkingSet();selectedKeyboardSet_=styleKeyboardCue_.position;
            clearStyleKeyboardCue(false);
        }else clearStyleKeyboardCue(true);
    }
    if(styleToKeyboardSet_==0)return;
    StyleKeyboardCue cue;cue.serial=source.serial;cue.player=player;cue.key=source.key;
    // The optional Style link recalls slot 1 only. A Variation is never a
    // Keyboard Set selector, including while a new Style waits for handoff.
    cue.position=0;
    cue.previous=captureKeyboardWorkingSet();cue.previousPosition=selectedKeyboardSet_;cue.previousOwner=selectedStyleKey_;
    if(styleKeyboardCue_.serial==source.serial){
        cue.previous=styleKeyboardCue_.previous;cue.previousPosition=styleKeyboardCue_.previousPosition;cue.previousOwner=styleKeyboardCue_.previousOwner;
    }
    std::array<int,4> slots{};std::array<std::string,4> paths;
    if(source.read&&source.read->keyboardSetMappingKnown)for(std::size_t i=0;i<4;++i){
        const auto& entry=source.read->keyboardSets[i];
        if(entry.available&&entry.keyboardSet)paths[i]=entry.keyboardSet->sourcePath;
    }
    const auto legacy=keyboardSetLinks_.find(source.key);
    if(legacy!=keyboardSetLinks_.end())for(std::size_t i=0;i<4;++i)if(legacy->second[i].first>0){slots[i]=legacy->second[i].first;paths[i].clear();}
    const auto native=nativeKeyboardSetLinks_.find(source.key);
    if(native!=nativeKeyboardSetLinks_.end())for(std::size_t i=0;i<4;++i)if(!native->second[i].first.empty()){slots[i]=0;paths[i]=native->second[i].first;}
    if(std::any_of(source.savedLinks.begin(),source.savedLinks.end(),[](const auto& link){return !link.first.empty();}))
        for(std::size_t i=0;i<4;++i){slots[i]=0;paths[i]=source.savedLinks[i].first;}
    const auto index=static_cast<std::size_t>(cue.position);cue.path=paths[index];cue.slot=slots[index];
    std::string error;
    if((!cue.path.empty()||cue.slot>0)&&!prepareWorkingKeyboardSet(cue.path,cue.slot,cue.prepared,error))
        showToast(error.empty()?"The Style's Keyboard Set is unavailable; current sounds were kept":error,6500);
    styleKeyboardCue_=std::move(cue);
    if(styleKeyboardCue_.prepared.combi&&(!keyboardSetNextMeasure_||!source.playing||!source.pending)){
        // The active Style's four edit buffers remain its own until handoff.
        // Position -1 prevents pending sounds from being captured into them.
        styleKeyboardCue_.preview=applyWorkingKeyboardSet(styleKeyboardCue_.prepared,-1,false);
        if(!styleKeyboardCue_.preview)showToast("The Style's Keyboard Set is unavailable; current sounds were kept",6500);
    }
    if(!source.pending)pollKeyboardSetRecall();
    dirty_=true;
}
