// Native Keyboard Set recall uses the existing SILVETON keyboard engine.
// File lookup and immutable state construction stay on the UI/control thread.
bool ArrangerView::activateNativeKeyboardSet(const std::string& path,int position,bool notify){
    if(applyingKeyboardSet_||kstJob_)return false;
    if(storageAccessRequest_&&!storageAccessRequest_())return false;
    KeyboardWorkingSet state;std::string error;
    if(!prepareWorkingKeyboardSet(path,0,state,error)){if(notify)showToast(error,7000);return false;}
    if(!keyboardSetTargetValid(position))return false;
    const auto previousPicker=picker_;const auto previousTab=tab_;
    const bool keepSelector=previousPicker==Picker::SavedKeyboardLibrary||(previousPicker==Picker::KstCatalog&&kstCatalogTab_==2);
    applyingKeyboardSet_=true;
    const bool accepted=applyWorkingKeyboardSet(state,position,notify);
    if(!accepted){applyingKeyboardSet_=false;return false;}
    overrideStyleKeyboardCue();
    if(position>=0&&position<4){const auto i=static_cast<std::size_t>(position);
        keyboardWorkingSets_[i]=state;keyboardSetPaths_[i]=path;keyboardSets_[i]=0;keyboardSetNames_[i]=state.combi->name;
    }
    if(persistentRestorePending_&&!persistentRestoreActive_)abandonPersistentRestore();
    targetKbdSet_=keepSelector&&position>=0&&position<4?position:-1;
    picker_=keepSelector?previousPicker:Picker::None;editor_=false;tab_=keepSelector||(liveView_&&previousPicker==Picker::None&&previousTab==Tab::Main)?previousTab:Tab::Keys;
    applyingKeyboardSet_=false;dirty_=true;
    if(notify)showToast(state.combi->name,3500);
    return true;
}
bool ArrangerView::recallKeyboardSet(int position,bool notify,bool manual){
    if(position<0||position>3)return false;
    // Capture the active slot before reading the target. Reselecting that slot
    // must use its latest edits rather than the previous stored working copy.
    rememberStyleKeyboardSet();
    const auto index=static_cast<std::size_t>(position);KeyboardWorkingSet state=keyboardWorkingSets_[index];std::string error;
    if(!state.combi&&!prepareWorkingKeyboardSet(keyboardSetPaths_[index],keyboardSets_[index],state,error)){
        if(notify)showToast(error.empty()?"Assign a Keyboard Set to this position":error,6500);
        return false;
    }
    if(!applyWorkingKeyboardSet(state,position,notify))return false;
    if(manual)overrideStyleKeyboardCue();
    keyboardWorkingSets_[index]=std::move(state);return true;
}

void ArrangerView::pollKeyboardSetRecall(){
    if(applyingKeyboardSet_||persistentRestorePending_||persistentRestoreActive_||kstJob_)return;
    auto player=players_[static_cast<std::size_t>(selectedPlayer_)];
    auto styleIdentity=arrangerStyleSelectionKey(player);
    if(styleKeyboardCue_.serial!=0){
        if(styleKeyboardCue_.player!=selectedPlayer_){clearStyleKeyboardCue(styleToKeyboardSet_==0);}
        else{
            const auto source=host::arrangerHost().keyboardStyleSelection(selectedPlayer_);
            if(source.serial==styleKeyboardCue_.serial){
                if(source.pending)return;
                // The audio handoff can occur between the outer snapshot and
                // this query. Align the four-buffer owner before adoption.
                refresh(false);player=players_[static_cast<std::size_t>(selectedPlayer_)];styleIdentity=arrangerStyleSelectionKey(player);
                if(styleIdentity!=styleKeyboardCue_.key)return;
                const int position=styleKeyboardCue_.position;const auto index=static_cast<std::size_t>(position);
                bool accepted=false;
                if(styleKeyboardCue_.manualOverride){
                    // The player's full manual recall wins over its queued
                    // automatic Style choice; four new Style buffers stay intact.
                }else if(styleKeyboardCue_.preview){
                    keyboardWorkingSets_[index]=captureKeyboardWorkingSet();selectedKeyboardSet_=position;accepted=true;
                }else if(styleKeyboardCue_.prepared.combi){
                    accepted=applyWorkingKeyboardSet(styleKeyboardCue_.prepared,position,false);
                    if(accepted)keyboardWorkingSets_[index]=styleKeyboardCue_.prepared;
                }
                if(accepted){
                    keyboardSetPaths_[index]=styleKeyboardCue_.path;keyboardSets_[index]=styleKeyboardCue_.slot;
                    if(keyboardWorkingSets_[index].combi)keyboardSetNames_[index]=keyboardWorkingSets_[index].combi->name;
                    markPersistentStateChanged();dirty_=true;
                }
                keyboardRecallStyle_=styleIdentity;keyboardRecallElement_=player.element;
                clearStyleKeyboardCue(false);return;
            }
            clearStyleKeyboardCue(styleIdentity!=styleKeyboardCue_.key);
        }
    }
    const bool changedStyle=keyboardRecallStyle_!=styleIdentity;
    if(changedStyle)pendingKeyboardSet_=-1;
    keyboardRecallStyle_=styleIdentity;keyboardRecallElement_=player.element;
    if(pendingKeyboardSet_>=0&&(!player.playing||player.transportMeasure!=pendingKeyboardSetMeasure_)){
        const int position=pendingKeyboardSet_;pendingKeyboardSet_=-1;
        if(!recallKeyboardSet(position,false,false))showToast("The linked Keyboard Set is unavailable; current sounds were kept",6500);
        return;
    }
    // Section changes, including Fill/Intro returns, never recall keyboard
    // sounds. Only a newly selected Style may use the optional Style link.
    if(!changedStyle||styleToKeyboardSet_==0||player.sourcePath.empty())return;
    constexpr int position=0;
    const auto index=static_cast<std::size_t>(position);
    if(keyboardSets_[index]<=0&&keyboardSetPaths_[index].empty())return;
    // A committed Style has already crossed its cue boundary. Direct
    // Keyboard Set presses are always immediate; this mode belongs to Styles.
    if(!recallKeyboardSet(position,false,false))showToast("The linked Keyboard Set is unavailable; current sounds were kept",6500);
}

void ArrangerView::setKeyboardSplit(bool enabled){
    auto& arranger=host::arrangerHost();const auto player=arranger.snapshot(selectedPlayer_);
    if(enabled==keyboardSplitEnabled_&&enabled==player.splitEnabled)return;
    const int split=std::clamp(player.split,1,127);
    const auto current=ctrl_.engine.nativeKeyboardCombi();auto suppressed=keyboardSplitSuppressed_;
    bool lowerMute=keyboardLowerMuteBeforeFull_;
    if(current){
        auto next=*current;
        if(!enabled)lowerMute=next.part(6).mute;
        next.part(6).mute=enabled?lowerMute:true;
        for(int part=0;part<7;++part){
            const auto index=static_cast<std::size_t>(part);auto& upper=next.part(part);
            upper.keyLow=static_cast<std::uint8_t>(keyboardRangeLow_[index]);upper.keyHigh=static_cast<std::uint8_t>(keyboardRangeHigh_[index]);
            upper.performanceKeyLow=static_cast<std::uint8_t>(enabled&&part!=6?split+1:0);
            upper.performanceKeyHigh=static_cast<std::uint8_t>(enabled&&part==6?split:127);
            if(suppressed[index])upper.enabled=true;
            suppressed[index]=false;
        }
        if(!ctrl_.engine.nativeApplyKeyboardCombi(next,true)){showToast(ctrl_.engine.nativeLastTextError(),6000);return;}
    }
    // The chord engine must receive this even when no keyboard Sounds are
    // available. Its SPLIT state determines simplified versus full recognition.
    if(!arranger.setKeyboardSplit(split,enabled)){
        if(current)(void)ctrl_.engine.nativeApplyKeyboardCombi(*current,true);
        showToast(arranger.lastError(),6000);return;
    }
    keyboardSplitEnabled_=enabled;keyboardLowerMuteBeforeFull_=lowerMute;keyboardSplitSuppressed_=suppressed;
    controlFeedbackUntil_=nowMs()+150;markPersistentStateChanged();refresh();dirty_=true;
}
