// All sound parameters edit the same selected part on a single page.
const int part=focused,player=trackEditPlayer_;
const auto& u=focusedPart;
for(int i=0;i<4;++i){
    const float x=12+i*174.0F;const int id=parts[i];
    const auto& partSound=snapshot->part(id);
    const auto name=styleTarget?players_[player].tracks[id].soundName:partSound.name;
    button(c,{x,42,x+166,86},partName(id)+(name.empty()?"":" · "+name),green,id==part,true,[this,id,styleTarget]{
        (styleTarget?styleEditTrack_:keyboardEditPart_)=id;dirty_=true;
    },14);
}
if(styleTarget&&player==selectedPlayer_)updateStyleActivity(players_[player]);
drawPartSoundDials(c,false,player,part,selection,snapshot,styleTarget&&players_[player].tracks[part].soundSettings.trigger==1);
const auto actionRect=[](int index){
    const float x=12+index*174.0F;
    return RectF{x,362,x+166,409};
};
const auto reset=[styleTarget](auto& d){resetPartSoundControls(d,!styleTarget);};
button(c,actionRect(0),"Use Sound values",green,false,true,[edit,part,reset]{edit(part,reset);},14);
button(c,actionRect(1),styleTarget?"Reset Style Tracks":"Reset Kbd Tracks",green,false,true,[mutate,styleTarget,reset]{
    mutate([=](Combi& combi){for(int i=0;i<(styleTarget?8:7);++i)reset(combi.part(i));});
},14);
if(styleTarget){
    const bool mute=players_[player].tracks[part].mute;
    const auto current=[=]{const auto state=host::arrangerHost().snapshot(player);return !state.styleSwitchPending&&state.styleSelectionSerial==selection;};
    toggle(actionRect(2),"Mute",mute,[this,current,player,part,selection]{if(current())togglePartMute(player,part,selection);},true);
    toggle(actionRect(3),"Solo",partSolo(player,part),[this,current,player,part]{if(current()){setPlayerFocus(player,false);solo(part);}},true);
}else{
    button(c,actionRect(2),"Mute",green,u.mute,part!=6||keyboardSplitEnabled_,[this,part]{togglePartMute(-1,part);},14,true);
    toggle(actionRect(3),"Solo",partSolo(-1,part),[this,part]{listenPart(-1,part);},true);
}

button(c,{715,304,797,352},styleTarget?"Save Style":"Save Set",green,false,true,[this,styleTarget,player,selection]{
    if(styleTarget){
        const auto state=host::arrangerHost().snapshot(player);
        if(state.styleSwitchPending||state.styleSelectionSerial!=selection)return;
        setPlayerFocus(player,false);
    }
    openResourceSave(styleTarget);
},13);
