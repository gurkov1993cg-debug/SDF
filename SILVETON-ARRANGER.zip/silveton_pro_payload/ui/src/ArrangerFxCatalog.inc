// Browsing the official Pa5X identities never edits an owner or its FX rack.
// Assignment/value changes require an explicit, current manual slot target.
// Catalog indices must not be cast to the unrelated sampler::EffectType enum.
namespace {
constexpr int kPa5xFxCatalogPageSize=10;
unsigned sourceFxKnownParameterCount(const sampler::SourceFxSlotStatus& slot){
    if(!slot.selectorKnown||slot.decoded.origin!=sampler::NumberedFxOrigin::Decoded||slot.decoded.index!=slot.selector)return 0;
    unsigned count=0;
    for(std::size_t row=0;row<sampler::kNumberedFxValueCount;++row)if(slot.decoded.known(row))++count;
    return count;
}
std::string sourceFxParameterStatus(const sampler::SourceFxSlotStatus& slot){
    if(!slot.selectorKnown)return "Параметри: неразчетен номер";
    if(slot.selector==0)return "Без параметри";
    if(!slot.parameterLayoutKnown)return "Параметри: неразчетени";
    if(!slot.parameterBlockValid)return "Параметри: непълен / невалиден запис";
    return slot.parametersComplete?"Параметри: разчетени":"Параметри: частично разчетени";
}
const char* sourceFxPlaybackStatus(const sampler::SourceFxSlotStatus& slot){
    return slot.status==sampler::SourceFxStatus::Applied?"Звук: работи":
        slot.status==sampler::SourceFxStatus::Off?"Звук: изключен":"Звук: не се прилага";
}
std::string sourceFxInspectionDetails(const sampler::SourceFxSlotStatus& slot,const std::string& context){
    std::string text=context+"\n\n"+sourceFxParameterStatus(slot);
    text+=" · известни стойности: "+std::to_string(sourceFxKnownParameterCount(slot));
    text+="\n"+std::string(sourceFxPlaybackStatus(slot));
    if(!slot.parameterDetail.empty())text+="\n\nРазчитане на настройките:\n"+slot.parameterDetail;
    if(!slot.detail.empty())text+="\n\nПрилагане към звука:\n"+slot.detail;
    text+="\n\nПоказани са запазените SET стойности към момента на отваряне. Неразчетените настройки остават неизвестни.";
    if(slot.status==sampler::SourceFxStatus::Unsupported)
        text+="\nРазчетен параметър може да се вижда и когато ефектът още не се прилага към звука.";
    if(slot.status==sampler::SourceFxStatus::Applied)
        text+="\nЗвуковата обработка използва собствената SILVETON реализация на този номер ефект.";
    text+="\nТози преглед не редактира, не назначава и не заменя оригиналните настройки.";
    return text;
}
enum class FxMenuGroup { All,Dynamics,Filter,Amp,Modulation,PitchSpecial,Delay,Reverb,Combined,Bypass };
struct FxMenuGroupLabel { const char* label; const char* description; };
constexpr FxMenuGroupLabel kPa5xFxGroups[]{
    {"Всички групи","Всички групи"},{"Динамика","Компресори, лимитери и Gate"},
    {"EQ / Филтри","Еквалайзери и филтри"},{"Усилватели","Усилватели и кабинети"},
    {"Модулация","Chorus, Flanger, Phaser, Tremolo и Rotary"},
    {"Pitch / Спец.","Pitch, честотна обработка и специални ефекти"},
    {"Delay","Закъснения и Echo"},{"Reverb","Реверберация"},
    {"Комбинирани","Две обработки в един ефект"},{"Без ефект","Bypass / изключен слот"}
};
// Musical browsing groups are independent of the official metadata category.
// The latter mixes several unrelated functions and scatters combined chains.
FxMenuGroup pa5xFxMenuGroup(const arranger::Pa5xEffectInfo& fx){
    if(fx.index==0)return FxMenuGroup::Bypass;
    if((fx.index>=77&&fx.index<=108)||fx.index==209)return FxMenuGroup::Combined;
    if(fx.index==62)return FxMenuGroup::Delay;
    if(fx.index==161)return FxMenuGroup::Modulation;
    if(fx.index==16||fx.index==17||fx.index==41||fx.index==42||fx.index==155)return FxMenuGroup::PitchSpecial;
    const auto category=fx.category?fx.category:"";
    if(std::strcmp(category,"Dynamics")==0)return FxMenuGroup::Dynamics;
    if(std::strcmp(category,"Filter")==0)return FxMenuGroup::Filter;
    if(std::strcmp(category,"Amplifier")==0)return FxMenuGroup::Amp;
    if(std::strcmp(category,"Modulator")==0)return FxMenuGroup::Modulation;
    if(std::strcmp(category,"Delay")==0)return FxMenuGroup::Delay;
    if(std::strcmp(category,"Reverb")==0)return FxMenuGroup::Reverb;
    return FxMenuGroup::PitchSpecial;
}
const char* pa5xFxMenuSlotLabel(arranger::Pa5xFxSlotRule rule){
    switch(rule){
        case arranger::Pa5xFxSlotRule::Any:return "IFX / MFX";
        case arranger::Pa5xFxSlotRule::InsertOnly:return "Само IFX";
        case arranger::Pa5xFxSlotRule::MasterOneOnly:return "Само MFX 1";
        case arranger::Pa5xFxSlotRule::MasterTwoThreeOnly:return "MFX 2 / MFX 3";
    }
    return "Неизвестен слот";
}
bool numberedFxHasLiveSource(std::uint16_t index){return index==34||index==37||index==42;}
std::string numberedFxModulatingPartName(int part,bool style){
    if(part<0)return "Off";
    if(style){
        constexpr const char* names[]{"Drums","Perc","Bass","ACC 1","ACC 2","ACC 3","ACC 4","ACC 5"};
        return part<8?names[part]:"Недостъпна партия";
    }
    return part<7?arrangerKeyboardPartName(part):"Недостъпна партия";
}
bool pa5xFxMenuMatches(const arranger::Pa5xEffectInfo& fx,int group,int filter,
                      bool hasTarget,bool insert,int slot){
    if(group&&static_cast<int>(pa5xFxMenuGroup(fx))!=group)return false;
    const bool implemented=sampler::numberedFxSupport(fx.index).selectable;
    if(filter==1)return !implemented;
    if(filter==2)return true;
    return implemented&&(!hasTarget||arranger::pa5xEffectAllowed(fx,!insert,slot));
}
}

void ArrangerView::focusPa5xFxCatalog(int index,bool chooseGroup){
    if(index<0||index>65535)return;
    const auto* effect=arranger::findPa5xEffect(static_cast<std::uint16_t>(index));
    if(!effect){showPa5xFxDetail(index);return;}
    fxCatalogSelected_=index;
    if(chooseGroup|| (fxCatalogCategory_&&fxCatalogCategory_!=static_cast<int>(pa5xFxMenuGroup(*effect))))
        fxCatalogCategory_=index?static_cast<int>(pa5xFxMenuGroup(*effect)):0;
    const bool implemented=sampler::numberedFxSupport(effect->index).selectable;
    const bool allowed=!numberedFxTarget_.active||arranger::pa5xEffectAllowed(*effect,!numberedFxTarget_.insert,numberedFxTarget_.slot);
    // Explicit current/source focus remains visible. A wrong-slot effect is
    // still implemented and must never be relabelled as unfinished.
    if(!pa5xFxMenuMatches(*effect,0,fxCatalogFilter_,numberedFxTarget_.active,numberedFxTarget_.insert,numberedFxTarget_.slot))
        fxCatalogFilter_=!implemented?1:allowed?0:2;
    std::size_t count=0;const auto* catalog=arranger::pa5xEffectCatalog(count);
    int position=0;fxCatalogPage_=0;
    for(std::size_t i=0;i<count;++i){
        if(!pa5xFxMenuMatches(catalog[i],fxCatalogCategory_,fxCatalogFilter_,numberedFxTarget_.active,numberedFxTarget_.insert,numberedFxTarget_.slot))continue;
        if(catalog[i].index==effect->index){fxCatalogPage_=position/kPa5xFxCatalogPageSize;break;}
        ++position;
    }
}

void ArrangerView::openPa5xFxCatalog(int focusIndex,std::string sourceContext,bool preserveTarget){
    numberedFxSourcePreview_.reset();
    if(preserveTarget&&picker_==Picker::NumberedFxEdit&&!navigationHistory_.empty()&&
       navigationHistory_.back().picker==Picker::Pa5xFxCatalog)(void)restoreNavigation();
    if(picker_!=Picker::Pa5xFxCatalog)rememberNavigation();
    if(!preserveTarget){
        numberedFxTarget_={};
        if(fxCatalogFilter_!=0)fxCatalogPage_=0;
        fxCatalogFilter_=0;
    }
    fxCatalogSourceIndex_=sourceContext.empty()?-1:focusIndex;
    fxCatalogSourceContext_=std::move(sourceContext);
    editor_=false;picker_=Picker::Pa5xFxCatalog;held_={};dragging_=false;
    if(focusIndex>=0)focusPa5xFxCatalog(focusIndex,!preserveTarget);
    dirty_=true;
}

void ArrangerView::showPa5xFxDetail(int index){
    const auto* effect=index>=0&&index<=65535?
        arranger::findPa5xEffect(static_cast<std::uint16_t>(index)):nullptr;
    const std::string heading="Pa5X FX "+std::to_string(index)+(effect?" · "+std::string(effect->firmwareName):"");
    std::string text;
    if(effect){
        fxCatalogSelected_=index;
        text="Официален FX номер: "+std::to_string(effect->index)+"\n";
        text+="Категория: "+std::string(kPa5xFxGroups[static_cast<int>(pa5xFxMenuGroup(*effect))].description)+"\n\n";
        text+=effect->functionBg;
        text+="\n\nНазначение в Pa5X: ";
        text+=arranger::pa5xEffectSlotRuleText(effect->slotRule);
        if(effect->slotDocumentationConflict)
            text+="\nСистемният каталог и ръководството се различават. Запазено е по-строгото ограничение от ръководството.";
        if(effect->firstManualPage){
            text+="\n\nPa5X User Manual v1.5 · стр. "+std::to_string(effect->firstManualPage);
            if(effect->lastManualPage!=effect->firstManualPage)
                text+="–"+std::to_string(effect->lastManualPage);
        }
        if(index!=0&&!effect->manualIdentityConfirmed)
            text+="\n\nИмето и номерът са от официалния каталог. Контролите за нашия модел са проектирани отделно; не се приема непотвърдена връзка с друг ефект от ръководството.";
        text+="\n\nНомер и име: официалният каталог на Pa5X OS 1.5.0.";
        const auto support=sampler::numberedFxSupport(effect->index);
        if(support.selectable&&index!=0){
            text+="\n\nSILVETON own-code DSP: налична е изрична ръчна звукова реализация. ";
            text+=support.limitation;
            text+="\nРъчните стойности и оригиналният 64-байтов SET блок са отделни.";
        }else if(index>=70&&index<=75)
            text+="\n\nЗвукова поддръжка: ограничен SILVETON превод на определени оригинални MFX настройки. Конкретният профил може да е Unsupported; това не е идентичният Korg DSP.";
        else if(index!=0)
            text+="\n\nЗвукова реализация за този номер още не е достъпна. Оригиналните настройки се запазват при импорт.";
    }else{
        text="Този оригинален номер не е в производствения Pa5X каталог с 153 ефекта и Bypass. Не е заменен с друг ефект.";
    }
    if(index==fxCatalogSourceIndex_&&!fxCatalogSourceContext_.empty())
        text+="\n\nКонтекст при отваряне на каталога (не се обновява на живо):\n"+fxCatalogSourceContext_;
    if(numberedFxSourcePreview_&&numberedFxSourcePreview_->slot.selector==index)
        text+=std::string(numberedFxSourcePreview_->slot.soundRecord?"\n\nОригинален Sound FX запис:\n":"\n\nОригинален SET слот:\n")+
            sourceFxInspectionDetails(numberedFxSourcePreview_->slot,numberedFxSourcePreview_->context);
    text+="\n\nТова е преглед. Отварянето на запис не включва ефект и не променя текущите настройки.";
    showStyleInfo(heading,text);
}

void ArrangerView::drawPa5xFxCatalog(Canvas& c){
    box(c,{0,0,800,480},bg);
    button(c,{3,3,96,38},"‹ Назад",orange,false,true,[this]{panelExit();},14);
    label(c,"Pa5X FX · по групи",112,27,20,green,true,480);
    std::size_t count=0;const auto* catalog=arranger::pa5xEffectCatalog(count);
    label(c,std::to_string(count?count-1:0)+" FX + Bypass",788,26,13,dim,false,178,Align::Right);
    constexpr int groupCount=static_cast<int>(std::size(kPa5xFxGroups));
    fxCatalogCategory_=std::clamp(fxCatalogCategory_,0,groupCount-1);
    fxCatalogFilter_=std::clamp(fxCatalogFilter_,0,2);
    std::array<int,groupCount> groupCounts{};
    std::array<int,3> filterCounts{};
    std::vector<const arranger::Pa5xEffectInfo*> visible;visible.reserve(count);
    for(std::size_t i=0;i<count;++i){
        const auto& item=catalog[i];
        for(int filter=0;filter<3;++filter)
            if(pa5xFxMenuMatches(item,0,filter,numberedFxTarget_.active,numberedFxTarget_.insert,numberedFxTarget_.slot))++filterCounts[filter];
        if(!pa5xFxMenuMatches(item,0,fxCatalogFilter_,numberedFxTarget_.active,numberedFxTarget_.insert,numberedFxTarget_.slot))continue;
        ++groupCounts[0];++groupCounts[static_cast<int>(pa5xFxMenuGroup(item))];
        if(!fxCatalogCategory_||fxCatalogCategory_==static_cast<int>(pa5xFxMenuGroup(item)))visible.push_back(&item);
    }
    constexpr const char* filters[]{"Достъпни","Недовършени","Всички"};
    for(int i=0;i<3;++i){
        const float x=194.0F+i*200.0F;
        button(c,{x,48,x+194,82},std::string(filters[i])+" · "+std::to_string(filterCounts[i]),i==1?orange:green,fxCatalogFilter_==i,true,[this,i]{
            if(fxCatalogFilter_==i)return;
            fxCatalogFilter_=i;fxCatalogPage_=0;
            std::size_t n=0;const auto* items=arranger::pa5xEffectCatalog(n);bool hasGroup=false;
            for(std::size_t at=0;at<n&&!hasGroup;++at)
                hasGroup=pa5xFxMenuMatches(items[at],fxCatalogCategory_,i,numberedFxTarget_.active,numberedFxTarget_.insert,numberedFxTarget_.slot);
            if(!hasGroup)fxCatalogCategory_=0;
            dirty_=true;
        },12);
    }
    label(c,"ГРУПИ",17,71,12,dim,true,160);
    for(int i=0;i<groupCount;++i){
        const float y=88.0F+i*34.0F;const bool selected=fxCatalogCategory_==i;
        box(c,{10,y,183,y+31},selected?0xFF203D35U:panel,selected?green:kBorder);
        label(c,kPa5xFxGroups[i].label,18,y+21,12,groupCounts[i]?white:dim,selected,132);
        label(c,std::to_string(groupCounts[i]),175,y+21,11,selected?green:dim,true,27,Align::Right);
        if(groupCounts[i]||selected)hit({10,y,183,y+31},[this,i]{fxCatalogCategory_=i;fxCatalogPage_=0;dirty_=true;});
    }
    const auto owner=numberedFxOwner();
    const auto* assigned=owner?&(numberedFxTarget_.insert?owner->insertOf(numberedFxTarget_.part):owner->fx[static_cast<std::size_t>(numberedFxTarget_.slot)]):nullptr;
    std::string heading=kPa5xFxGroups[fxCatalogCategory_].description;
    if(numberedFxTarget_.active)heading+=" · "+(numberedFxTarget_.insert?std::string("IFX"):"MFX "+std::to_string(numberedFxTarget_.slot+1));
    label(c,heading,195,104,12,white,true,590);
    const int total=static_cast<int>(visible.size());
    const int pages=std::max(1,(total+kPa5xFxCatalogPageSize-1)/kPa5xFxCatalogPageSize);
    fxCatalogPage_=std::clamp(fxCatalogPage_,0,pages-1);
    const int first=fxCatalogPage_*kPa5xFxCatalogPageSize;
    for(int cell=0;cell<kPa5xFxCatalogPageSize;++cell){
        const int position=first+cell;if(position>=total)break;
        const auto& item=*visible[static_cast<std::size_t>(position)];
        const float x=194.0F+(cell%2)*300.0F,y=114.0F+(cell/2)*62.0F;
        const RectF rect{x,y,x+294,y+58};
        const bool selected=fxCatalogSelected_==static_cast<int>(item.index);
        const bool implemented=sampler::numberedFxSupport(item.index).selectable;
        const bool allowed=!numberedFxTarget_.active||arranger::pa5xEffectAllowed(item,!numberedFxTarget_.insert,numberedFxTarget_.slot);
        const bool current=assigned&&assigned->numbered.index==item.index&&(item.index||assigned->type==sampler::EffectType::Off);
        const bool needsModPart=current&&!numberedFxTarget_.insert&&numberedFxHasLiveSource(item.index)&&assigned->numberedModulatingPart<0;
        const ColorInt statusColor=!implemented||!allowed||needsModPart?orange:item.index?green:dim;
        box(c,rect,selected?0xFF203D35U:panel,selected?green:kBorder,2);
        label(c,std::to_string(item.index),x+9,y+24,17,selected?green:orange,true,35);
        label(c,item.firmwareName,x+48,y+22,12,implemented?white:dim,true,238);
        std::string status;
        if(!implemented)status="Недовършен · само преглед";
        else if(!allowed)status="Друг слот · "+std::string(pa5xFxMenuSlotLabel(item.slotRule));
        else if(needsModPart)status="Назначен · избери Mod. Track";
        else if(!item.index)status=current?"Текущ · без ефект":"Bypass · без ефект";
        else status=(current?std::string("Назначен · "):"Основен режим · ")+pa5xFxMenuSlotLabel(item.slotRule);
        label(c,status,x+9,y+46,10,statusColor,false,276);
        hit(rect,[this,index=static_cast<int>(item.index)]{openNumberedFxEditor(index);});
    }
    if(!total){
        label(c,"Няма ефекти в тази група",492,192,18,white,true,550,Align::Center);
        label(c,"Избери друга група или смени изгледа отгоре.",492,223,12,dim,false,550,Align::Center);
        button(c,{342,253,642,293},"Всички групи",green,false,true,[this]{fxCatalogCategory_=0;fxCatalogPage_=0;dirty_=true;},14);
    }
    const char* tip=numberedFxTarget_.active&&!owner?"Собственикът е сменен. Отвори отново неговия FX слот.":
        fxCatalogFilter_==1?"Недовършените ефекти са само за преглед и не могат да се назначават.":
        numberedFxTarget_.active?"Достъпни = основен режим за този слот. Назначаването е отделен бутон.":
        "Достъпни = собствен основен режим. Разглеждането не променя звука.";
    label(c,tip,14,439,10,dim,false,774);
    button(c,{12,447,83,478},"Начало",green,false,fxCatalogPage_>0,[this]{fxCatalogPage_=0;dirty_=true;},11);
    button(c,{91,447,145,478},"‹",green,false,fxCatalogPage_>0,[this]{--fxCatalogPage_;dirty_=true;},20);
    const std::string pageText=(total?std::to_string(first+1):"0")+"–"+std::to_string(std::min(first+kPa5xFxCatalogPageSize,total))+" / "+std::to_string(total)+
        " · Страница "+std::to_string(fxCatalogPage_+1)+" / "+std::to_string(pages);
    label(c,pageText,405,468,12,white,true,460,Align::Center);
    button(c,{660,447,714,478},"›",green,false,fxCatalogPage_+1<pages,[this]{++fxCatalogPage_;dirty_=true;},20);
    button(c,{722,447,788,478},"Край",green,false,fxCatalogPage_+1<pages,[this,pages]{fxCatalogPage_=pages-1;dirty_=true;},11);
}

std::shared_ptr<const sampler::Combi> ArrangerView::numberedFxOwner(){
    if(numberedFxSourcePreview_)return {};
    const auto& target=numberedFxTarget_;
    if(!target.active||target.part<0||target.part>7||target.slot<0||target.slot>2)return {};
    if(target.player>=0){
        if(target.player>1)return {};
        const auto live=host::arrangerHost().snapshot(target.player);
        if(!live.loaded||live.styleSwitchPending||live.styleSelectionSerial!=target.styleSerial)return {};
        std::uint64_t serial=0;
        auto owner=host::arrangerHost().styleTrackCombi(target.player,serial);
        return owner&&serial==target.styleSerial&&!owner->sourceEffects?owner:nullptr;
    }
    if(target.part>6)return {};
    const auto owner=ctrl_.engine.nativeKeyboardCombi();
    const auto expected=target.keyboardOwner.lock();
    return owner&&expected&&owner.get()==expected.get()&&!owner->sourceEffects?owner:nullptr;
}

void ArrangerView::openNumberedFxSelector(bool insert,int part,int slot,std::uint64_t selection){
    // The fourth native MFX is an extension, not an original Pa5X processor.
    if(!insert&&(slot<0||slot>2)){
        openPa5xFxCatalog();showToast("Pa5X има MFX 1–3. MFX 4 остава SILVETON разширение.",5000);return;
    }
    NumberedFxTarget target;
    target.active=true;target.insert=insert;target.player=trackEditPlayer_;
    target.part=part;target.slot=insert?0:slot;target.styleSerial=selection;
    auto owner=trackEditPlayer_>=0?host::arrangerHost().styleTrackCombi(trackEditPlayer_,selection):ctrl_.engine.nativeKeyboardCombi();
    if(!owner||owner->sourceEffects){showToast("Първо избери ръчния SILVETON FX режим.",4500);return;}
    if(trackEditPlayer_<0)target.keyboardOwner=owner;
    const auto& effect=insert?owner->insertOf(part):owner->fx[static_cast<std::size_t>(slot)];
    openPa5xFxCatalog();
    numberedFxTarget_=std::move(target);
    focusPa5xFxCatalog(effect.numbered.index,true);
    if(!numberedFxOwner())numberedFxTarget_.active=false;
    dirty_=true;
}

bool ArrangerView::editNumberedFxSlot(const std::function<bool(sampler::EffectSlot&)>& change){
    if(numberedFxSourcePreview_){showToast("Оригиналните SET стойности са отворени само за преглед.",4500);return false;}
    const auto owner=numberedFxOwner();
    if(!owner){showToast("Собственикът на FX е променен. Отвори отново неговия MFX/IFX слот.",5000);return false;}
    const auto target=numberedFxTarget_;
    auto replacement=target.insert?owner->insertOf(target.part):owner->fx[static_cast<std::size_t>(target.slot)];
    if(!change(replacement)){
        showToast("Промяната не е приложена. Виж „Описание / ограничения“ за поддържаните режими и диапазони.",6000);
        return false;
    }
    if(target.player>=0){
        if(!host::arrangerHost().editStyleCombi(target.player,target.styleSerial,[target,replacement](sampler::Combi& combi){
            (target.insert?combi.insertOf(target.part):combi.fx[static_cast<std::size_t>(target.slot)])=replacement;
        },owner.get())){showToast(host::arrangerHost().lastError(),5000);return false;}
    }else{
        sampler::Combi edited=*owner;
        (target.insert?edited.insertOf(target.part):edited.fx[static_cast<std::size_t>(target.slot)])=replacement;
        if(!keyboardSplitEnabled_)edited.part(6).mute=true;
        if(!ctrl_.engine.nativeApplyKeyboardCombi(edited,true)){showToast(ctrl_.engine.nativeLastTextError(),5000);return false;}
        captureKeyboardFxOverride(*owner,edited);
        // Own successive slider changes use the newly published immutable
        // owner. A different recall/mixer publication still invalidates it.
        numberedFxTarget_.keyboardOwner=ctrl_.engine.nativeKeyboardCombi();
    }
    markPersistentStateChanged();refresh();dirty_=true;return true;
}

void ArrangerView::openNumberedFxEditor(int index){
    numberedFxSourcePreview_.reset();
    if(index<0||index>65535||!sampler::findNumberedFx(static_cast<std::uint16_t>(index))){showPa5xFxDetail(index);return;}
    if(picker_!=Picker::NumberedFxEdit)rememberNavigation();
    fxCatalogSelected_=index;numberedFxIndex_=index;numberedFxPage_=0;numberedFxRow_=-1;
    numberedFxChoicePage_=0;numberedFxSection_=0;numberedFxZoom_=false;
    picker_=Picker::NumberedFxEdit;editor_=false;held_={};dragging_=false;dirty_=true;
}

void ArrangerView::openOriginalSourceFxEditor(const sampler::SourceFxSlotStatus& slot,
                                             const std::string& context,bool style){
    if(!slot.selectorKnown){showStyleInfo(context,sourceFxInspectionDetails(slot,context));return;}
    // Copy the selected immutable record before changing pages. No owner lookup
    // or manual initializer is allowed to replace these saved source values.
    NumberedFxSourcePreview preview{slot,context,style};
    numberedFxTarget_={};
    fxCatalogSourceIndex_=-1;fxCatalogSourceContext_.clear();
    if(!sampler::findNumberedFx(slot.selector)){
        numberedFxSourcePreview_=std::move(preview);
        showPa5xFxDetail(slot.selector);return;
    }
    openNumberedFxEditor(slot.selector);
    numberedFxSourcePreview_=std::move(preview);
    dirty_=true;
}

void ArrangerView::openNumberedFxValue(int row){
    const auto* effect=sampler::findNumberedFx(static_cast<std::uint16_t>(numberedFxIndex_));
    if(!effect||row<0||row>=effect->parameterCount)return;
    rememberNavigation();numberedFxRow_=row;numberedFxChoicePage_=0;
    picker_=Picker::NumberedFxValue;held_={};dragging_=false;dirty_=true;
}

void ArrangerView::drawNumberedFxEditor(Canvas& c){
    using namespace sampler;
    constexpr ColorInt surface=0xFF090B0CU,border=0xFF525C26U;
    const auto* effect=findNumberedFx(static_cast<std::uint16_t>(numberedFxIndex_));
    if(!effect){panelExit();return;}
    const auto* identity=arranger::findPa5xEffect(effect->index);
    const auto support=numberedFxSupport(effect->index);
    const auto* sourcePreview=numberedFxSourcePreview_&&numberedFxSourcePreview_->slot.selector==effect->index?
        &*numberedFxSourcePreview_:nullptr;
    const auto owner=numberedFxOwner();
    const auto* slot=owner?&(numberedFxTarget_.insert?owner->insertOf(numberedFxTarget_.part):owner->fx[static_cast<std::size_t>(numberedFxTarget_.slot)]):nullptr;
    const bool assigned=slot&&effect->index!=0&&slot->numbered.index==effect->index;
    NumberedFxState state;state.index=effect->index;
    if(assigned)state=slot->numbered;
    if(sourcePreview&&sourcePreview->slot.decoded.origin==NumberedFxOrigin::Decoded&&sourcePreview->slot.decoded.index==effect->index)
        state=sourcePreview->slot.decoded;
    const bool allowed=owner&&identity&&arranger::pa5xEffectAllowed(*identity,!numberedFxTarget_.insert,numberedFxTarget_.slot);
    const bool editable=!sourcePreview&&assigned&&allowed&&numberedFxCanRender(state);
    box(c,{0,0,800,480},surface);
    box(c,{1,1,799,41},surface,border);
    button(c,{3,3,84,38},"‹ Exit",orange,false,true,[this]{panelExit();},14);
    const std::string processor=sourcePreview?(sourcePreview->slot.soundRecord?"SND ":sourcePreview->slot.master?"MFX ":"IFX ")+std::to_string(sourcePreview->slot.slot+1):
        numberedFxTarget_.active?(numberedFxTarget_.insert?"IFX":"MFX "+std::to_string(numberedFxTarget_.slot+1)):"FX";
    box(c,{91,5,152,36},panel,border);label(c,processor,121,27,13,white,true,57,Align::Center);
    box(c,{158,5,187,36},panel,border);label(c,sourcePreview?(sourcePreview->slot.soundRecord?"—":sourcePreview->style?"A":"B"):
        numberedFxTarget_.active?(numberedFxTarget_.player>=0?"A":"B"):"—",172,27,14,dim,true,25,Align::Center);
    button(c,{195,5,580,36},std::to_string(effect->index)+" · "+effect->name,green,false,true,[this]{
        if(numberedFxSourcePreview_)showPa5xFxDetail(numberedFxIndex_);
        else openPa5xFxCatalog(numberedFxIndex_,{},true);
    },14);
    button(c,{588,5,644,36},"Info",green,false,true,[this]{showPa5xFxDetail(numberedFxIndex_);},12);
    button(c,{652,5,796,36},numberedFxZoom_?"Zoom out · Main":"Zoom in · Detail",green,numberedFxZoom_,true,[this]{numberedFxZoom_=!numberedFxZoom_;numberedFxPage_=0;dirty_=true;},12);
    std::string ownerText="Каталог · няма избран SET запис или ръчен FX слот";
    if(sourcePreview){
        ownerText="SET · при отваряне · "+sourcePreview->context;
    }else if(owner){
        ownerText=(numberedFxTarget_.player>=0?"Player "+std::to_string(numberedFxTarget_.player+1)+" · ":"Keyboard Set · ")+owner->name;
        if(numberedFxTarget_.insert)ownerText+=" · "+(numberedFxTarget_.player>=0?std::string("Track ")+std::to_string(numberedFxTarget_.part+1):arrangerKeyboardPartName(numberedFxTarget_.part));
        ownerText+=assigned?" · "+std::string(numberedFxOriginName(state.origin)):" · още не е назначен";
    }else if(numberedFxTarget_.active)ownerText="FX собственикът е сменен · редактирането е заключено";
    const bool liveSource=numberedFxHasLiveSource(effect->index);
    label(c,ownerText,12,62,12,assigned||sourcePreview?green:dim,false,liveSource&&!sourcePreview?540:776);
    if(liveSource&&!sourcePreview){
        if(numberedFxTarget_.active&&numberedFxTarget_.insert){
            label(c,"Управление: "+numberedFxModulatingPartName(numberedFxTarget_.part,numberedFxTarget_.player>=0),788,62,11,dim,false,224,Align::Right);
        }else{
            const int part=assigned?slot->numberedModulatingPart:-1;
            button(c,{564,44,788,65},"Mod. Track: "+numberedFxModulatingPartName(part,numberedFxTarget_.player>=0),part<0?orange:green,false,editable,[this]{
                rememberNavigation();picker_=Picker::NumberedFxTrack;held_={};dragging_=false;dirty_=true;
            },11);
        }
    }
    std::string limitation=effect->limitation;
    if(!limitation.empty())limitation+=" ";
    limitation+=support.limitation;
    if(sourcePreview)limitation=sourceFxParameterStatus(sourcePreview->slot)+" · "+sourceFxPlaybackStatus(sourcePreview->slot);
    if(liveSource&&assigned&&!numberedFxTarget_.insert&&slot->numberedModulatingPart<0)
        limitation="Избери Mod. Track за управляващия MIDI сигнал. "+limitation;
    if(owner&&!allowed)limitation="Официалното ограничение не разрешава този FX в избрания слот. "+limitation;
    std::vector<std::string> sections;
    for(std::size_t i=0;i<effect->parameterCount;++i){
        const auto* section=effect->parameters[i].section;
        if(*section&&std::find(sections.begin(),sections.end(),section)==sections.end())sections.emplace_back(section);
    }
    numberedFxSection_=std::clamp(numberedFxSection_,0,static_cast<int>(sections.size()));
    if(!sections.empty()){
        const int sectionCount=static_cast<int>(sections.size())+1;
        button(c,{12,68,45,94},"‹",green,false,true,[this,sectionCount]{numberedFxSection_=(numberedFxSection_+sectionCount-1)%sectionCount;numberedFxPage_=0;dirty_=true;},17);
        label(c,numberedFxSection_?sections[static_cast<std::size_t>(numberedFxSection_-1)]:"Всички секции",174,86,12,white,true,247,Align::Center);
        button(c,{307,68,340,94},"›",green,false,true,[this,sectionCount]{numberedFxSection_=(numberedFxSection_+1)%sectionCount;numberedFxPage_=0;dirty_=true;},17);
    }
    const float limitationX=sections.empty()?12.0F:352.0F;
    label(c,limitation,limitationX,83,11,dim,false,788-limitationX);
    const auto limitationDetails=sourcePreview?sourceFxInspectionDetails(sourcePreview->slot,sourcePreview->context):limitation;
    hit({limitationX-2,66,790,94},[this,limitationDetails]{showStyleInfo("FX · разчитане и звук",limitationDetails);});

    const int wetRow=numberedFxPrimaryWetRow(effect->index);
    std::vector<int> body;
    std::vector<int> mix;
    for(std::size_t i=0;i<effect->parameterCount;++i){
        const auto& p=effect->parameters[i];
        const bool inMix=wetRow>=0&&std::strcmp(p.group,effect->parameters[wetRow].group)==0;
        if(inMix)mix.push_back(static_cast<int>(i));
        else if((!numberedFxSection_||sections[static_cast<std::size_t>(numberedFxSection_-1)]==p.section)&&
                (numberedFxZoom_||p.role==NumberedFxParamRole::Parameter||
                 (liveSource&&p.role==NumberedFxParamRole::ModulationSource&&
                  (support.editableMask&(std::uint64_t{1}<<i)))))body.push_back(static_cast<int>(i));
    }
    const int perPage=numberedFxZoom_?10:6;
    const int pages=std::max(1,(static_cast<int>(body.size())+perPage-1)/perPage);
    numberedFxPage_=std::clamp(numberedFxPage_,0,pages-1);
    const auto control=[&](const RectF& r,int row,bool compact){
        const auto& p=effect->parameters[row];
        const bool enabled=editable&&(support.editableMask&(std::uint64_t{1}<<row))&&p.domainComplete;
        const bool known=state.known(static_cast<std::size_t>(row));
        const bool readable=enabled||(sourcePreview&&known);
        box(c,r,surface,0xFF30353AU);
        const std::string title=std::string(p.group)+" · "+p.label;
        label(c,title,r.left+8,r.top+(compact?13.0F:16.0F),compact?11:12,readable?white:dim,true,r.width()-16);
        if(compact){
            label(c,formatNumberedFxValue(state,static_cast<std::size_t>(row)),r.right-8,r.bottom-6,16,enabled?orange:readable?green:dim,true,r.width()*.42F,Align::Right);
            label(c,p.printedRange,r.left+8,r.bottom-6,10,dim,false,r.width()*.55F);
        }else{
            const bool knob=p.rangeKnown&&p.kind!=NumberedFxValueKind::Enumeration;
            if(knob){
                const float cx=r.left+44,cy=r.top+59,rad=23;
                Paint paint;paint.color=0xFF6D7477U;c.drawCircle(cx,cy,rad,paint);
                paint.color=0xFF20282CU;c.drawCircle(cx,cy,rad-3,paint);
                if(known&&state.values[static_cast<std::size_t>(row)]>=p.minimum&&state.values[static_cast<std::size_t>(row)]<=p.maximum&&p.maximum>p.minimum){
                    const double n=(state.values[static_cast<std::size_t>(row)]-p.minimum)/(p.maximum-p.minimum);
                    const double a=(135.0+270.0*n)*.017453292519943295;
                    paint.color=enabled?orange:readable?green:dim;paint.strokeWidth=3;
                    c.drawLine(cx+static_cast<float>(std::cos(a))*8,cy+static_cast<float>(std::sin(a))*8,
                        cx+static_cast<float>(std::cos(a))*20,cy+static_cast<float>(std::sin(a))*20,paint);
                }
                label(c,formatNumberedFxValue(state,static_cast<std::size_t>(row)),r.left+84,r.top+63,20,readable?white:dim,true,r.width()-92);
            }else label(c,formatNumberedFxValue(state,static_cast<std::size_t>(row)),r.centerX(),r.top+64,18,enabled?orange:readable?green:dim,true,r.width()-16,Align::Center);
            label(c,p.printedRange,r.left+8,r.bottom-12,10,dim,false,r.width()-16);
        }
        // A disabled value can open its factual description, but it never
        // receives a parameter-change callback or displays invented defaults.
        hit(r,[this,row]{openNumberedFxValue(row);});
        if(!compact&&enabled&&p.rangeKnown&&known&&p.maximum>p.minimum){
            const RectF knob{r.left+16,r.top+30,r.left+73,r.top+87};
            const double step=p.stepKnown?p.step:std::pow(10.0,-static_cast<int>(p.displayDecimals));
            hit(knob,{},[this,row,index=effect->index,p,step,base=state.values[static_cast<std::size_t>(row)],start=std::numeric_limits<float>::quiet_NaN()](float,float y) mutable {
                if(!std::isfinite(start)){start=y;return;}
                const double current=std::clamp(base,p.minimum,p.maximum);
                const double raw=current+static_cast<double>(start-y)*(p.maximum-p.minimum)/180.0;
                const double value=std::clamp(std::round(raw/step)*step,p.minimum,p.maximum);
                editNumberedFxSlot([row,index,value](EffectSlot& fx){return fx.numbered.index==index&&setNumberedFxValue(fx.numbered,static_cast<std::size_t>(row),value);});
            });
        }
    };
    for(int cell=0;cell<perPage;++cell){
        const int at=numberedFxPage_*perPage+cell;
        if(at>=static_cast<int>(body.size()))break;
        const int columns=numberedFxZoom_?2:3;
        const float width=numberedFxZoom_?388.0F:256.0F;
        const float height=numberedFxZoom_?46.0F:114.0F;
        const float x=12+(width+8)*(cell%columns),y=98+(height+4)*(cell/columns);
        control({x,y,x+width,y+height},body[static_cast<std::size_t>(at)],numberedFxZoom_);
    }
    if(body.empty()){
        const auto lines=wrappedKstText(effect->limitation[0]?effect->limitation:effect->functionBg,730,15);
        for(std::size_t i=0;i<std::min<std::size_t>(lines.size(),7);++i)label(c,lines[i],30,148+25.0F*i,15,dim,false,730);
    }
    button(c,{12,350,80,379},"‹",green,false,numberedFxPage_>0,[this]{--numberedFxPage_;dirty_=true;},18);
    label(c,(numberedFxZoom_?"Zoom · ":"Main · ")+std::to_string(numberedFxPage_+1)+" / "+std::to_string(pages)+" · докосни параметър",400,371,12,dim,false,600,Align::Center);
    button(c,{720,350,788,379},"›",green,false,numberedFxPage_+1<pages,[this]{++numberedFxPage_;dirty_=true;},18);
    box(c,{1,385,799,432},surface,border);
    if(!mix.empty()){
        const int count=std::min(3,static_cast<int>(mix.size()));
        for(int i=0;i<count;++i){const float x=8+i*264.0F;control({x,389,x+256,428},mix[static_cast<std::size_t>(i)],true);}
    }else label(c,"Няма отделен Wet/Dry ред в тази потвърдена таблица.",14,414,12,dim,false,770);
    const bool assignable=!sourcePreview&&owner&&allowed&&support.selectable&&!assigned;
    if(assignable)button(c,{12,440,330,477},effect->index==0?"Изключи избрания слот":"Назначи · "+std::to_string(effect->index)+" · SILVETON",orange,false,true,[this,index=effect->index]{
        const auto* identity=arranger::findPa5xEffect(index);
        if(!identity||!arranger::pa5xEffectAllowed(*identity,!numberedFxTarget_.insert,numberedFxTarget_.slot))return;
        editNumberedFxSlot([this,index](EffectSlot& fx){
            NumberedFxState initialized;if(!initializeNumberedFx(index,initialized))return false;
            const auto modulatingPart=fx.numbered.index?fx.numberedModulatingPart:static_cast<std::int8_t>(-1);
            fx=EffectSlot{};fx.numbered=initialized;
            if(index&&!numberedFxTarget_.insert)fx.numberedModulatingPart=modulatingPart;
            fx.wet=index?(numberedFxTarget_.insert?1.0F:.3F):0.0F;return true;
        });
    },12);
    else label(c,sourcePreview?"Записани SET стойности · само преглед":assigned?"Ръчни стойности · Save пази този FX":"Преглед · без промяна на звука",14,463,12,assigned||sourcePreview?green:dim,false,465);
    label(c,sourcePreview?sourceFxPlaybackStatus(sourcePreview->slot):assigned&&!numberedFxTarget_.insert?"MFX Return: "+fmtFixed(slot->wet*100,0)+"% · отделно от Wet/Dry":
        effect->completeness==NumberedFxCompleteness::OwnDesign?"SILVETON · собствени настройки":
        "Pa5X Manual v1.5 · "+(effect->firstManualPage?std::to_string(effect->firstManualPage):std::string("няма потвърдена таблица")),788,463,11,dim,false,440,Align::Right);
}

void ArrangerView::drawNumberedFxTrack(Canvas& c){
    const auto owner=numberedFxOwner();
    const auto* slot=owner&&!numberedFxTarget_.insert?&owner->fx[static_cast<std::size_t>(numberedFxTarget_.slot)]:nullptr;
    const auto* identity=arranger::findPa5xEffect(static_cast<std::uint16_t>(numberedFxIndex_));
    const bool enabled=slot&&slot->numbered.index==numberedFxIndex_&&numberedFxHasLiveSource(slot->numbered.index)&&
        sampler::numberedFxCanRender(slot->numbered)&&identity&&arranger::pa5xEffectAllowed(*identity,true,numberedFxTarget_.slot);
    box(c,{0,0,800,480},bg);
    button(c,{8,5,108,42},"‹ Назад",orange,false,true,[this]{panelExit();},14);
    label(c,"MFX · управляваща партия",125,31,20,green,true,660);
    label(c,owner?owner->name:"Собственикът е сменен — отвори отново FX слота.",16,67,13,enabled?white:orange,true,770);
    label(c,"Избраната партия подава MIDI контролите. Маршрутът на звука остава същият.",16,92,12,dim,false,770);
    const bool style=numberedFxTarget_.player>=0;const int parts=style?8:7;
    for(int part=-1;part<parts;++part){
        const int cell=part+1;const float x=14.0F+(cell%3)*262.0F,y=119.0F+(cell/3)*82.0F;
        const bool selected=slot&&slot->numberedModulatingPart==part;
        button(c,{x,y,x+250,y+64},numberedFxModulatingPartName(part,style),part<0?orange:green,selected,enabled,[this,part,index=numberedFxIndex_]{
            if(editNumberedFxSlot([this,part,index](sampler::EffectSlot& fx){
                if(numberedFxTarget_.insert||fx.numbered.index!=index||!numberedFxHasLiveSource(fx.numbered.index)||
                   part< -1||part>=(numberedFxTarget_.player>=0?8:7))return false;
                fx.numberedModulatingPart=static_cast<std::int8_t>(part);return true;
            }))panelExit();
        },18);
    }
    label(c,"Off изключва този управляван MFX. При IFX се използва собствената му партия.",16,401,12,dim,false,770);
    label(c,"Save Style / Save Keyboard Set запазва избора към този MFX слот.",16,428,12,dim,false,770);
}

void ArrangerView::drawNumberedFxValue(Canvas& c){
    using namespace sampler;
    constexpr ColorInt surface=0xFF090B0CU;
    const auto* effect=findNumberedFx(static_cast<std::uint16_t>(numberedFxIndex_));
    if(!effect||numberedFxRow_<0||numberedFxRow_>=effect->parameterCount){panelExit();return;}
    const int row=numberedFxRow_;const auto& p=effect->parameters[row];
    const auto support=numberedFxSupport(effect->index);
    const auto* sourcePreview=numberedFxSourcePreview_&&numberedFxSourcePreview_->slot.selector==effect->index?
        &*numberedFxSourcePreview_:nullptr;
    const auto owner=numberedFxOwner();
    const auto* slot=owner?&(numberedFxTarget_.insert?owner->insertOf(numberedFxTarget_.part):owner->fx[static_cast<std::size_t>(numberedFxTarget_.slot)]):nullptr;
    NumberedFxState state;state.index=effect->index;
    if(slot&&slot->numbered.index==effect->index)state=slot->numbered;
    if(sourcePreview&&sourcePreview->slot.decoded.origin==NumberedFxOrigin::Decoded&&sourcePreview->slot.decoded.index==effect->index)
        state=sourcePreview->slot.decoded;
    const auto* identity=arranger::findPa5xEffect(effect->index);
    const bool enabled=!sourcePreview&&owner&&identity&&arranger::pa5xEffectAllowed(*identity,!numberedFxTarget_.insert,numberedFxTarget_.slot)&&
        slot->numbered.index==effect->index&&numberedFxCanRender(state)&&p.domainComplete&&(support.editableMask&(std::uint64_t{1}<<row));
    const auto change=[this,row,index=effect->index](double value){
        editNumberedFxSlot([row,index,value](EffectSlot& fx){return fx.numbered.index==index&&setNumberedFxValue(fx.numbered,static_cast<std::size_t>(row),value);});
    };
    const auto canChoose=[enabled,state,row](double value){
        if(!enabled)return false;
        auto candidate=state;
        return setNumberedFxValue(candidate,static_cast<std::size_t>(row),value);
    };
    box(c,{0,0,800,480},surface);
    button(c,{3,3,94,39},"‹ Back",orange,false,true,[this]{panelExit();},14);
    label(c,std::to_string(effect->index)+" · "+effect->name,110,27,17,green,true,676);
    label(c,std::string(p.group)+" · "+p.label,16,65,21,white,true,770);
    const auto explanation=wrappedKstText(p.description,764,13);
    for(std::size_t i=0;i<std::min<std::size_t>(explanation.size(),2);++i)label(c,explanation[i],17,87+17.0F*i,13,dim,false,764);
    label(c,"Диапазон: "+std::string(p.printedRange),17,126,12,dim,false,765);
    label(c,formatNumberedFxValue(state,static_cast<std::size_t>(row)),400,169,29,enabled?orange:sourcePreview&&state.known(row)?green:dim,true,760,Align::Center);
    if(p.kind==NumberedFxValueKind::Enumeration){
        constexpr int perPage=12;const int pages=std::max(1,(static_cast<int>(p.choiceCount)+perPage-1)/perPage);
        numberedFxChoicePage_=std::clamp(numberedFxChoicePage_,0,pages-1);
        for(int cell=0;cell<perPage;++cell){const int at=numberedFxChoicePage_*perPage+cell;if(at>=p.choiceCount)break;
            const auto choice=p.choices[at];const float x=12+(cell%3)*261.0F,y=184+(cell/3)*47.0F;
            button(c,{x,y,x+253,y+41},choice.label,green,state.known(row)&&state.values[static_cast<std::size_t>(row)]==choice.value,canChoose(choice.value),[change,choice]{change(choice.value);},12);
        }
        button(c,{12,376,80,408},"‹",green,false,numberedFxChoicePage_>0,[this]{--numberedFxChoicePage_;dirty_=true;},18);
        label(c,std::to_string(numberedFxChoicePage_+1)+" / "+std::to_string(pages),400,399,12,dim,false,500,Align::Center);
        button(c,{720,376,788,408},"›",green,false,numberedFxChoicePage_+1<pages,[this]{++numberedFxChoicePage_;dirty_=true;},18);
    }else if(p.rangeKnown){
        const RectF slider{40,190,760,245};box(c,slider,panel,enabled?green:kBorder,2);
        const bool inRange=state.known(row)&&state.values[static_cast<std::size_t>(row)]>=p.minimum&&state.values[static_cast<std::size_t>(row)]<=p.maximum;
        if(inRange&&p.maximum>p.minimum){
            const float n=static_cast<float>((state.values[static_cast<std::size_t>(row)]-p.minimum)/(p.maximum-p.minimum));
            const float x=slider.left+12+n*(slider.width()-24);box(c,{x-4,slider.top+6,x+4,slider.bottom-6},enabled?orange:sourcePreview?green:dim);
        }
        label(c,formatNumberedFxValue(p,p.minimum),42,264,12,dim,false,310);
        label(c,formatNumberedFxValue(p,p.maximum),758,264,12,dim,false,310,Align::Right);
        const double step=p.stepKnown?p.step:std::pow(10.0,-static_cast<int>(p.displayDecimals));
        if(enabled)hit(slider,{},[p,slider,step,change](float x,float){
            const double n=std::clamp(static_cast<double>((x-slider.left-12)/(slider.width()-24)),0.0,1.0);
            const double value=p.minimum+n*(p.maximum-p.minimum);
            change(std::clamp(std::round(value/step)*step,p.minimum,p.maximum));
        });
        const double current=inRange?state.values[static_cast<std::size_t>(row)]:p.minimum;
        button(c,{40,280,151,324},"−",green,false,enabled,[change,current,step,p]{change(std::clamp(current-step,p.minimum,p.maximum));},24);
        label(c,"Стъпка "+fmtFixed(step,p.displayDecimals),400,307,12,dim,false,470,Align::Center);
        button(c,{649,280,760,324},"+",green,false,enabled,[change,current,step,p]{change(std::clamp(current+step,p.minimum,p.maximum));},24);
        for(std::size_t i=0;i<std::min<std::size_t>(p.choiceCount,3);++i){const auto choice=p.choices[i];const float x=40+static_cast<float>(i)*244;
            button(c,{x,338,x+232,379},choice.label,green,state.known(row)&&state.values[static_cast<std::size_t>(row)]==choice.value,canChoose(choice.value),[change,choice]{change(choice.value);},13);
        }
    }else{
        const auto lines=wrappedKstText("Мануалът показва: "+std::string(p.printedRange)+". Пълните междинни избори не са публикувани в тази клетка; няма измислен контрол или enum.",728,16);
        for(std::size_t i=0;i<std::min<std::size_t>(lines.size(),7);++i)label(c,lines[i],36,220+24.0F*i,16,dim,false,728);
    }
    const std::string status=sourcePreview?(state.known(row)?"Записана SET стойност · само преглед · ":"Неразчетена SET стойност · ")+std::string(sourceFxPlaybackStatus(sourcePreview->slot)):
        enabled?"Променя само текущия ръчен FX · "+std::string(numberedFxOriginName(state.origin)):
        !owner?"Преглед · не е избран текущ ръчен слот":!p.domainComplete?"Непълно документирано меню · само справка":
        !support.selectable?"Този DSP още не е реализиран":slot&&slot->numbered.index!=effect->index?"Първо назначи ефекта от Main / Zoom":"Този контрол няма активна DSP връзка; фиксираната стойност е запазена";
    label(c,status,14,433,12,enabled||sourcePreview?green:dim,false,774);
    const auto sourceDetails=sourcePreview?sourceFxInspectionDetails(sourcePreview->slot,sourcePreview->context):std::string{};
    button(c,{12,443,400,477},"Описание / ограничения",green,false,true,[this,parameter=&p,support,sourceDetails]{
        std::string details=parameter->description;
        details+=(parameter->manualPage?"\n\nДиапазон от ръководството: ":"\n\nСобствен SILVETON диапазон: ")+std::string(parameter->printedRange);
        if(parameter->manualPage)details+="\nPa5X User Manual v1.5 · стр. "+std::to_string(parameter->manualPage);
        else details+="\nСобствено проектирана настройка; няма твърдение за оригинален Korg диапазон.";
        details+="\n\n"+std::string(support.limitation);
        details+="\n\nРед "+std::string(parameter->rowId)+" е идентификатор на настройката, не адрес в оригиналния SET.";
        if(!sourceDetails.empty())details+="\n\n"+sourceDetails;
        showStyleInfo(parameter->label,details);
    },12);
    label(c,(p.manualPage?"Manual v1.5 · стр. "+std::to_string(p.manualPage):"SILVETON · собствен диапазон")+" · "+p.rowId,788,465,12,dim,false,370,Align::Right);
}
