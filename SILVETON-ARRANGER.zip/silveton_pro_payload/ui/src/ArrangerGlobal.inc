// App-wide GLOBAL preferences have their own small record. They never depend
// on a loaded SET, its PCM, or the keyboard performance metadata.
namespace {
constexpr std::size_t kArrangerGlobalMaximumBytes=4096U;

bool validArrangerGlobalSettings(const SamplerAppController::GlobalUiState& state,
                                const SamplerAppController::GlobalAdvanced& midi){
    const auto inRange=[](float value,float minimum,float maximum){
        return std::isfinite(value)&&value>=minimum&&value<=maximum;
    };
    return inRange(state.masterTuneHz,400.0F,480.0F)&&state.transpose>=-12&&state.transpose<=12&&
        inRange(state.masterGainDb,-60.0F,18.0F)&&inRange(state.eqLowDb,-18.0F,18.0F)&&
        inRange(state.eqMidDb,-18.0F,18.0F)&&inRange(state.eqHighDb,-18.0F,18.0F)&&
        inRange(state.limiterCeilingDb,-12.0F,0.0F)&&state.velocityCurve>=0&&state.velocityCurve<=4&&
        state.breathCc>=0&&state.breathCc<=127&&state.expressionCc>=0&&state.expressionCc<=127&&
        state.damperCc>=0&&state.damperCc<=127&&midi.midiInMask>=0&&midi.midiInMask<=0xFFFF&&
        inRange(midi.breathMin,0.0F,0.9999F)&&inRange(midi.breathMax,midi.breathMin+0.0001F,1.0F)&&
        inRange(midi.breathCurve,0.1F,8.0F)&&inRange(midi.expressionMin,0.0F,0.9999F)&&
        inRange(midi.expressionMax,midi.expressionMin+0.0001F,1.0F)&&
        inRange(midi.expressionCurve,0.1F,8.0F);
}

bool readArrangerGlobalFlag(std::istream& input,bool& value){
    int flag=-1;
    if(!(input>>flag)||(flag!=0&&flag!=1))return false;
    value=flag!=0;return true;
}

bool parseArrangerGlobalSettings(const std::string& text,
                                SamplerAppController::GlobalUiState& state,
                                SamplerAppController::GlobalAdvanced& midi){
    if(text.empty()||text.size()>kArrangerGlobalMaximumBytes)return false;
    std::istringstream input(text);input.imbue(std::locale::classic());
    const auto tag=[&input](const char* expected){std::string actual;return static_cast<bool>(input>>actual)&&actual==expected;};
    int version=0;
    if(!tag("SILVETON_ARRANGER_GLOBAL")||!(input>>version)||version!=1||!tag("TUNING")||
       !(input>>state.masterTuneHz>>state.transpose>>state.masterGainDb>>state.eqLowDb>>state.eqMidDb>>state.eqHighDb)||
       !tag("LIMITER")||!readArrangerGlobalFlag(input,state.limiterEnabled)||!(input>>state.limiterCeilingDb)||
       !tag("CONTROLLERS")||!(input>>state.velocityCurve>>state.breathCc>>state.expressionCc>>state.damperCc)||
       !readArrangerGlobalFlag(input,state.pitchBendEnabled)||!readArrangerGlobalFlag(input,state.aftertouchEnabled)||
       !tag("MIDI")||!(input>>midi.midiInMask)||!readArrangerGlobalFlag(input,midi.filterNotes)||
       !readArrangerGlobalFlag(input,midi.filterCc)||!readArrangerGlobalFlag(input,midi.filterBend)||
       !readArrangerGlobalFlag(input,midi.filterAftertouch)||!tag("BREATH")||
       !(input>>midi.breathMin>>midi.breathMax>>midi.breathCurve)||!tag("EXPRESSION")||
       !(input>>midi.expressionMin>>midi.expressionMax>>midi.expressionCurve)||!tag("DAMPER")||
       !readArrangerGlobalFlag(input,midi.damperReversed)||!tag("END"))return false;
    input>>std::ws;
    return input.eof()&&validArrangerGlobalSettings(state,midi);
}

std::string arrangerGlobalSettingsText(const SamplerAppController::GlobalUiState& state,
                                      const SamplerAppController::GlobalAdvanced& midi){
    std::ostringstream text;text.imbue(std::locale::classic());text<<std::setprecision(9);
    text<<"SILVETON_ARRANGER_GLOBAL 1\nTUNING "<<state.masterTuneHz<<' '<<state.transpose<<' '<<state.masterGainDb<<' '
        <<state.eqLowDb<<' '<<state.eqMidDb<<' '<<state.eqHighDb<<"\nLIMITER "<<state.limiterEnabled<<' '<<state.limiterCeilingDb
        <<"\nCONTROLLERS "<<state.velocityCurve<<' '<<state.breathCc<<' '<<state.expressionCc<<' '<<state.damperCc<<' '
        <<state.pitchBendEnabled<<' '<<state.aftertouchEnabled<<"\nMIDI "<<midi.midiInMask<<' '<<midi.filterNotes<<' '
        <<midi.filterCc<<' '<<midi.filterBend<<' '<<midi.filterAftertouch<<"\nBREATH "<<midi.breathMin<<' '
        <<midi.breathMax<<' '<<midi.breathCurve<<"\nEXPRESSION "<<midi.expressionMin<<' '<<midi.expressionMax<<' '
        <<midi.expressionCurve<<"\nDAMPER "<<midi.damperReversed<<"\nEND\n";
    return text.str();
}

void copyArrangerGlobalMidiSettings(const SamplerAppController::GlobalAdvanced& source,
                                   SamplerAppController::GlobalAdvanced& target){
    // Scale belongs to the current performance. Never restore it from GLOBAL.
    target.midiInMask=source.midiInMask;target.filterNotes=source.filterNotes;
    target.filterCc=source.filterCc;target.filterBend=source.filterBend;target.filterAftertouch=source.filterAftertouch;
    target.breathMin=source.breathMin;target.breathMax=source.breathMax;target.breathCurve=source.breathCurve;
    target.expressionMin=source.expressionMin;target.expressionMax=source.expressionMax;target.expressionCurve=source.expressionCurve;
    target.damperReversed=source.damperReversed;
}
} // namespace

void ArrangerView::configureGlobalSettings(const std::string& directory){
    const auto path=directory.empty()?std::string():files::join(directory,"ARRANGER_GLOBAL.txt");
    if(path==globalSettingsPath_)return;
    flushGlobalSettings();
    globalSettingsPath_=path;globalSettingsRecord_.reset();globalSettingsRestorePending_=false;
    globalSettingsDirty_=false;globalSettingsSaveFailed_=false;globalSettingsSaveDue_=0;
    globalSettingsRecordProtected_=false;globalSettingsRestoreFailed_=false;globalSettingsRestoreDue_=0;
    if(path.empty()||!files::exists(path))return;
    std::ifstream input(path,std::ios::binary);
    std::string text(kArrangerGlobalMaximumBytes+1U,'\0');
    if(input)input.read(text.data(),static_cast<std::streamsize>(text.size()));
    const auto bytes=input.gcount();
    if(bytes>=0)text.resize(static_cast<std::size_t>(bytes));
    GlobalSettingsRecord record;
    if(input.bad()||bytes<=0||static_cast<std::size_t>(bytes)>kArrangerGlobalMaximumBytes||
       !parseArrangerGlobalSettings(text,record.state,record.midi)){
        globalSettingsRecordProtected_=true;
        showToast("Saved GLOBAL settings could not be read; the file was kept",6500);return;
    }
    globalSettingsRecord_=std::move(record);globalSettingsRestorePending_=true;
}

void ArrangerView::rememberCurrentGlobalSettings(bool intentional){
    // Startup/native refresh notifications cannot replace an unreadable file.
    // An explicit control edit or Save Global is the user's replacement intent.
    if(globalSettingsRecordProtected_&&!intentional)return;
    const auto state=ctrl_.globalUiState();const auto midi=ctrl_.globalAdvanced();
    if(!state||!midi||!validArrangerGlobalSettings(*state,*midi)){
        if(!globalSettingsSaveFailed_)showToast("Current GLOBAL settings could not be saved",6500);
        globalSettingsSaveFailed_=true;return;
    }
    globalSettingsRecord_=GlobalSettingsRecord{*state,*midi};
    globalSettingsRestorePending_=false;globalSettingsDirty_=true;globalSettingsSaveFailed_=false;
    globalSettingsRecordProtected_=false;globalSettingsRestoreFailed_=false;globalSettingsRestoreDue_=0;
    globalSettingsSaveDue_=nowMs()+250;
}

void ArrangerView::restoreSavedGlobalSettings(){
    if(!globalSettingsRecord_){globalSettingsRestorePending_=false;return;}
    globalSettingsRestorePending_=true;
    if(nowMs()<globalSettingsRestoreDue_)return;
    const auto failed=[this](const std::string& message){
        if(!globalSettingsRestoreFailed_)showToast(message,6500);
        globalSettingsRestoreFailed_=true;globalSettingsRestoreDue_=nowMs()+5000;dirty_=true;
    };
    const auto previousState=ctrl_.globalUiState();const auto previousMidi=ctrl_.globalAdvanced();
    if(!previousState||!previousMidi){failed("Saved GLOBAL settings could not be restored; retrying");return;}
    auto nextMidi=*previousMidi;copyArrangerGlobalMidiSettings(globalSettingsRecord_->midi,nextMidi);
    if(!ctrl_.updateGlobalUi(globalSettingsRecord_->state)){
        failed("Saved GLOBAL settings could not be restored; retrying");return;
    }
    if(!ctrl_.updateGlobalAdvanced(nextMidi)){
        const bool midiRestored=ctrl_.updateGlobalAdvanced(*previousMidi);
        const bool stateRestored=ctrl_.updateGlobalUi(*previousState);
        failed(midiRestored&&stateRestored?"GLOBAL restore failed; previous settings restored; retrying":
            "GLOBAL restore failed; check the current settings; retrying");
        globalUi_=ctrl_.globalUiState();dirty_=true;return;
    }
    globalSettingsRestorePending_=false;globalSettingsRestoreFailed_=false;globalSettingsRestoreDue_=0;
    globalUi_=ctrl_.globalUiState();SilvetonSamplerView::globalChangedOutside();dirty_=true;
}

void ArrangerView::flushGlobalSettings(){
    if(!globalSettingsDirty_||!globalSettingsRecord_)return;
    const auto failure=[this]{
        if(!globalSettingsSaveFailed_)showToast("GLOBAL settings could not be saved; previous file kept",6500);
        globalSettingsSaveFailed_=true;globalSettingsSaveDue_=nowMs()+5000;dirty_=true;
    };
    if(globalSettingsPath_.empty()||!validArrangerGlobalSettings(globalSettingsRecord_->state,globalSettingsRecord_->midi)){
        failure();return;
    }
    const auto text=arrangerGlobalSettingsText(globalSettingsRecord_->state,globalSettingsRecord_->midi);
    const auto directory=files::parentOf(globalSettingsPath_),pending=globalSettingsPath_+".pending";
    if((!directory.empty()&&!files::makeDirectories(directory))||text.size()>kArrangerGlobalMaximumBytes||
       !files::writeText(pending,text)||std::rename(pending.c_str(),globalSettingsPath_.c_str())!=0){
        (void)std::remove(pending.c_str());failure();return;
    }
    globalSettingsDirty_=false;globalSettingsSaveFailed_=false;globalSettingsSaveDue_=0;dirty_=true;
}

void ArrangerView::pollGlobalSettings(std::int64_t now){
    if(ctrl_.audioRunning()&&!globalAudioBaselineSeen_){
        globalAudioBaselineSeen_=true;
        // Android's first successful audio preparation establishes its master
        // gain baseline. Reapply the latest cached preferences after that point,
        // including a delayed first-open retry following an earlier failure.
        if(globalSettingsRecord_)globalSettingsRestorePending_=true;
    }
    if(globalSettingsRestorePending_&&ctrl_.initialBankLoadFinished()&&!persistentRestoreActive_&&!kstJob_)
        restoreSavedGlobalSettings();
    if(globalSettingsDirty_&&!pointerActive_&&now>=globalSettingsSaveDue_)flushGlobalSettings();
}
