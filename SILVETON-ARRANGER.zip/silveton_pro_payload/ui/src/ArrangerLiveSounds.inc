// Direct destinations from the Live panel. The selected player and Style own all Style edits.
void ArrangerView::openTargetSound(int part,int track){
    if(track>=0){
        const auto current=host::arrangerHost().snapshot(selectedPlayer_);
        if(!current.loaded||current.styleSwitchPending||
           (picker_==Picker::StyleSounds&&soundSerial_!=current.styleSelectionSerial)){
            showToast("Select the active Style again",4500);return;
        }
        soundPlayer_=selectedPlayer_;soundSerial_=current.styleSelectionSerial;
    }
    targetPart_=part;targetTrack_=track;openPicker(Picker::Sound);
    if(homeSoundEdit_&&(picker_==Picker::Sound||(picker_==Picker::KstCatalog&&kstCatalogTab_==1))){
        stopEqTap();
        homeSoundEdit_=false;
    }
}
void ArrangerView::finishSoundSelection(){
    const bool keyboardSelection=targetTrack_<0;
    // USER may have been opened from a SET tile picker. Return to the track/part that opened it.
    do {
        if(!restoreNavigation()){picker_=Picker::None;break;}
    }while(!homeSoundEdit_&&(picker_==Picker::Sound||(picker_==Picker::KstCatalog&&kstCatalogTab_==1)));
    if(keyboardSelection)overrideStyleKeyboardCue();
    targetTrack_=-1;targetPart_=0;
    markPersistentStateChanged();refresh(true);dirty_=true;
}
void ArrangerView::updateStyleActivity(const host::ArrangerPlayerView& p){
    std::array<int,8> cvs{};
    for(int i=0;i<8;++i)cvs[i]=p.tracks[i].selectedCv;
    const int blocked=p.playing?p.blockedTrackMask:0;
    if(selectedPlayer_==activityPlayer_&&activitySerial_==p.styleSelectionSerial&&activityRevision_==p.soundRevision&&
       activityElement_==p.element&&activityBlocked_==blocked&&activityCvs_==cvs)return;
    activity_=host::arrangerHost().styleActivity(selectedPlayer_,p);
    activityPlayer_=selectedPlayer_;activitySerial_=p.styleSelectionSerial;activityRevision_=p.soundRevision;
    activityElement_=p.element;activityBlocked_=blocked;activityCvs_=cvs;
    if(drumNote_>=0&&soundPlayer_==selectedPlayer_&&soundSerial_==p.styleSelectionSerial){
        for(const auto& item:activity_.drums)if(item.track==drumTrack_&&item.note==drumNote_){editedDrum_=item;break;}
    }
    drumPage_=std::clamp(drumPage_,0,std::max(0,(static_cast<int>(activity_.drums.size())-1)/4));
}
void ArrangerView::drawActivitySwitch(Canvas& c,const RectF& rect,bool playing){
    const bool recent=playing&&recentPartsOnly_;
    button(c,rect,recent?"Last 2 s":"Section",orange,recent,playing,[this]{
        recentPartsOnly_=!recentPartsOnly_;drumPage_=0;refresh(false);dirty_=true;
    },15);
}
void ArrangerView::openLiveSoundPage(Picker page){
    const auto p=host::arrangerHost().snapshot(selectedPlayer_);
    if(page!=Picker::KeyboardParts&&(!p.loaded||p.styleSwitchPending)){showToast("Select the active Style first",4000);return;}
    rememberNavigation();
    soundPlayer_=selectedPlayer_;soundSerial_=p.styleSelectionSerial;
    picker_=page;editor_=false;
    drumPage_=0;drumNote_=-1;drumParameter_.reset();editedDrum_.reset();
    refresh(false);dirty_=true;
}
void ArrangerView::editStyleDrum(int track,int note,DrumParameter parameter,int value){
    if(picker_!=Picker::StyleDrums||soundPlayer_!=selectedPlayer_)return;
    auto& arranger=host::arrangerHost();
    const auto p=arranger.snapshot(soundPlayer_);
    if(p.styleSwitchPending||p.styleSelectionSerial!=soundSerial_)return;
    updateStyleActivity(p);
    if(!(editedDrum_&&drumNote_==note&&drumTrack_==track)&&std::none_of(activity_.drums.begin(),activity_.drums.end(),[&](const auto& item){
        return item.track==track&&item.note==note;
    }))return;
    const auto& settings=p.tracks[track].soundSettings;
    int db=settings.keyDb[note];
    host::StyleDrumTone tone;
    if(settings.tones){const auto it=settings.tones->find(note);if(it!=settings.tones->end())tone=it->second;}
    switch(parameter){
        case DrumParameter::Attack:tone.attack=value;break;
        case DrumParameter::Decay:tone.decay=value;break;
        case DrumParameter::Sustain:tone.sustain=value;break;
        case DrumParameter::Release:tone.release=value;break;
        case DrumParameter::Level:db=value;break;
        case DrumParameter::Pan:tone.pan=value;break;
        case DrumParameter::Tune:tone.tune=value;break;
        case DrumParameter::Gate:tone.gate=value;break;
    }
    if(!arranger.setStyleDrum(soundPlayer_,track,soundSerial_,note,db,tone)){showToast(arranger.lastError(),4500);return;}
    refresh(false);markPersistentStateChanged();dirty_=true;
}
void ArrangerView::openStyleDrumGroups(const host::StyleActivity::Drum& drum){
    if(!kstCatalog_||!drum.auditionSource||drum.note<0||drum.note>127||drum.track<0||drum.track>=8)return;
    auto& arranger=host::arrangerHost();
    const auto player=arranger.snapshot(soundPlayer_);
    if(soundPlayer_!=selectedPlayer_||player.styleSwitchPending||player.styleSelectionSerial!=soundSerial_){
        showToast("Select the active Style again",4500);return;
    }
    // Match the actual prepared Program that produced this key. A MIDI note,
    // kit name, or a GM convention cannot identify the editable SET resource.
    std::vector<std::size_t> matches;
    for(std::size_t i=0;i<kstCatalog_->sounds.size();++i){
        const auto& sound=kstCatalog_->sounds[i];
        if(sound.drumKit&&arranger.preparedKeyboardSound(sound.msb,sound.lsb,sound.program,kstCatalog_->rootPath)==drum.auditionSource)
            matches.push_back(i);
    }
    if(matches.size()>1){
        const auto& track=player.tracks[drum.track];
        const int assigned=track.soundSettings.setAddress;
        if(assigned>=0)matches.erase(std::remove_if(matches.begin(),matches.end(),[&](std::size_t index){
            const auto& sound=kstCatalog_->sounds[index];return assigned!=((sound.msb<<16)|(sound.lsb<<8)|sound.program);
        }),matches.end());
    }
    if(matches.size()!=1){
        showToast(matches.empty()?"Load the SET containing this kit to edit its groups":"Select this kit from SET Sounds to edit its groups",6000);return;
    }
    const auto index=matches.front();const auto& source=kstCatalog_->sounds[index];
    auto draft=std::make_shared<host::DrumKitDraft>();
    if(!arranger.openDrumKit(kstCatalog_->rootPath,source.msb,source.lsb,source.program,*draft)){
        showToast(arranger.lastError(),5500);return;
    }
    const auto current=arranger.snapshot(soundPlayer_);
    if(current.styleSelectionSerial!=soundSerial_||current.styleSwitchPending){showToast("Select the active Style again",4500);return;}
    arranger.stopPcmPreview();previewDrumNote_=-1;
    inspectSetSound(index);drumDraft_=std::move(draft);drumKey_=drum.note;drumZone_=0;
    drumTab_=2;drumGroupEdit_=-1;drumExitPrompt_=false;drumMidiLearn_=false;
    openInspector(Picker::DrumKitEdit);
}
void ArrangerView::drawDrumEnvelope(Canvas& c,const host::StyleActivity::Drum& drum,const host::ArrangerTrackView& track){
    using Param=DrumParameter;
    const auto transport=[&](float top,float bottom){
        const auto& state=players_[soundPlayer_];
        button(c,{546,top,788,bottom},state.playing?"Stop":"Start",green,state.playing,
            state.playing||(state.loaded&&state.soundAssignmentsReady),
            [this,player=soundPlayer_]{startStopPlayer(player);},18,true);
    };
    static const char* names[]{"Attack","Decay","Sustain","Release","Level","Pan","Tune","Trigger"};
    const auto& settings=track.soundSettings;
    host::StyleDrumTone tone;
    if(settings.tones){const auto it=settings.tones->find(drum.note);if(it!=settings.tones->end())tone=it->second;}
    const std::array<int,8> values{{tone.attack,tone.decay,tone.sustain,tone.release,settings.keyDb[drum.note],tone.pan,tone.tune,tone.gate}};
    const std::array<int,8> low{{0,0,0,0,-60,-100,-2400,-1}},high{{10000,10000,100,10000,12,100,2400,1}};
    const auto format=[](Param param,int n)->std::string{
        if(param==Param::Gate)return n<0?"Kit":n?"One Shot":"Gate";
        if(param==Param::Sustain)return std::to_string(n)+"%";
        if(param==Param::Level)return std::to_string(n)+" dB";
        if(param==Param::Pan)return n==0?"Center":std::string(n<0?"L ":"R ")+std::to_string(std::abs(n));
        if(param==Param::Tune)return std::to_string(n)+" ct";
        return std::to_string(n)+" ms";
    };
    std::uint64_t selection=0;
    const auto channel=host::arrangerHost().styleTrackCombi(soundPlayer_,selection);
    std::array<float,4> inherited{{-1,-1,-1,-1}};
    if(channel&&selection==soundSerial_){
        const auto& u=channel->part(drum.track);
        inherited={u.toneAttackMs,u.toneDecayMs,u.toneSustain<0?-1:u.toneSustain*100,u.toneReleaseMs};
    }
    const int gate=tone.gate>=0?tone.gate:track.soundSettings.trigger;
    const bool oneShot=gate>=0?gate==1:drum.hasOneShotZone&&!drum.hasGatedZone;
    const auto reference=[&](int i){return std::clamp(inherited[i]>=0?int(std::lround(inherited[i])):drum.sourceEnvelope[i],low[i],high[i]);};
    const auto offsetText=[](int i,int n){return (n>0?"+":std::string{})+std::to_string(n)+(i==2?" %":" ms");};
    const auto shown=[&](int i){
        const auto param=static_cast<Param>(i);
        if(i==1||i==2)return offsetText(i,values[i]<0?0:values[i]-reference(i));
        if(i<4&&values[i]<0&&inherited[i]>=0)return std::string("Track · ")+format(param,static_cast<int>(std::lround(inherited[i])));
        if(i<4&&values[i]<0)return drum.mixedEnvelope&(1U<<i)?std::string("Kit · varies"):std::string("Kit · ")+format(param,drum.sourceEnvelope[i]);
        if(param==Param::Gate&&tone.gate<0&&track.soundSettings.trigger>=0)return std::string("Track · ")+format(param,track.soundSettings.trigger);
        if(param==Param::Gate&&tone.gate<0){
            if(drum.hasGatedZone&&drum.hasOneShotZone)return std::string("Kit · mixed");
            return std::string(oneShot?"Kit · One Shot":"Kit · Gate");
        }
        return format(param,values[i]);
    };
    const auto apply=[this,trackId=drum.track,note=drum.note](Param param,int value){editStyleDrum(trackId,note,param,value);};
    const bool soloKey=host::arrangerHost().listenSolo().matches(soundPlayer_,drum.track,drum.note);
    button(c,{424,52,599,88},"Solo key",orange,soloKey,true,[this,drum,serial=soundSerial_]{
        if(host::arrangerHost().snapshot(soundPlayer_).styleSelectionSerial==serial)listenPart(soundPlayer_,drum.track,drum.note);
    },16,true);
    button(c,{606,52,788,88},"Hold to hear",green,previewDrumNote_==drum.note,true,[this,drum,owner=soundSerial_,rev=activityRevision_]{
        if(host::arrangerHost().auditionStyleDrum(soundPlayer_,owner,rev,drum)){
            previewDrumNote_=drum.note;previewDrumDeadline_=nowMs()+10000;dirty_=true;
        }
    },16,true);
    if(drumParameter_){
        const Param param=*drumParameter_;const int i=static_cast<int>(param);
        label(c,names[i],16,120,23,orange,true,290);
        const bool relative=i==1||i==2;
        const int base=relative?reference(i):0;
        const auto display=relative?shown(i)+"   ·   "+format(param,base)+" → "+format(param,values[i]<0?base:values[i]):shown(i);
        label(c,display,783,120,22,white,true,455,Align::Right);
        const int current=values[i]<0&&i<4?(inherited[i]>=0?int(std::lround(inherited[i])):drum.sourceEnvelope[i]):values[i];
        static const std::vector<int> times{0,1,2,5,10,20,40,60,100,150,250,400,600,1000,1500,2500,5000,10000};
        static const std::vector<int> percents{0,5,10,20,30,40,50,60,70,80,90,100};
        static const std::vector<int> levels{-60,-48,-36,-24,-18,-12,-9,-6,-3,0,3,6,9,12};
        static const std::vector<int> pans{-100,-75,-50,-25,-10,0,10,25,50,75,100};
        static const std::vector<int> cents{-2400,-1200,-700,-500,-200,-100,-50,-10,0,10,50,100,200,500,700,1200,2400};
        static const std::vector<int> trigger{-1,0,1};
        std::vector<int> offsets;
        if(relative){
            const std::vector<int> deltas=i==2?std::vector<int>{-100,-75,-50,-25,-10,-5,0,5,10,25,50,75,100}:
                std::vector<int>{-10000,-2500,-1000,-500,-250,-100,-50,-10,0,10,50,100,250,500,1000,2500,10000};
            for(int d:deltas){
                const int value=std::clamp(base+d,low[i],high[i]);
                if(offsets.empty()||offsets.back()!=value)offsets.push_back(value);
            }
        }
        const auto& choices=relative?offsets:param==Param::Gate?trigger:param==Param::Sustain?percents:
            param==Param::Level?levels:param==Param::Pan?pans:param==Param::Tune?cents:times;
        for(std::size_t j=0;j<choices.size();++j){
            const float x=param==Param::Gate?12+(j%3)*262.0F:238+(j%6)*92.0F,y=136+(j/6)*64.0F;const int v=choices[j];
            button(c,{x,y,x+(param==Param::Gate?251:87),y+57},relative?offsetText(i,v-base):format(param,v),orange,relative?current==v:values[i]==v,true,
                   [apply,param,v,base,relative]{apply(param,relative&&v==base?-1:v);},16);
        }
        if(param!=Param::Gate){
            const int lo=low[i],hi=high[i];
            const bool time=i==0||i==1||i==3;
            const auto unit=[time](int value,int range){return range<=0?0.0F:time?
                float(std::log1p(float(value))/std::log1p(float(range))):float(value)/range;};
            const auto denorm=[time](float position,int range){return time?int(std::lround(std::expm1(position*std::log1p(float(range))))):
                int(std::lround(position*range));};
            const float pos=relative?.5F+.5F*(current<base?-unit(base-current,base-lo):unit(current-base,hi-base)):unit(current-lo,hi-lo);
            const float angle=135+270*pos,rad=66,cx=118,cy=231;
            Paint ink;ink.color=liveKey;c.drawCircle(cx,cy,rad,ink);ink.style=Style::Stroke;ink.strokeCap=Cap::Round;ink.strokeWidth=5;
            const RectF arc{cx-rad-5,cy-rad-5,cx+rad+5,cy+rad+5};ink.color=liveLine;c.drawArc(arc,135,270,false,ink);
            ink.color=orange;const float start=relative?270:135;
            if(std::abs(angle-start)>.1F)c.drawArc(arc,std::min(angle,start),std::abs(angle-start),false,ink);
            const float a=angle*.01745329252F;c.drawLine(cx+std::cos(a)*rad*.32F,cy+std::sin(a)*rad*.32F,cx+std::cos(a)*rad*.86F,cy+std::sin(a)*rad*.86F,ink);
            const auto slide=[=](float,float y){
                if(toneDialPreview_!=i){
                    toneDialGrabY_=y;toneDialPreview_=i;toneGestureLast_=current;return;
                }
                const float n=std::clamp(pos+(toneDialGrabY_-y)/182.0F,0.0F,1.0F);
                const int value=std::clamp(relative?(n<.5F?base-denorm(1-2*n,base-lo):base+denorm(2*n-1,hi-base)):lo+denorm(n,hi-lo),lo,hi);
                if(value!=int(toneGestureLast_)){apply(param,relative&&value==base?-1:value);toneGestureLast_=value;}
            };
            hit({12,132,222,326},{},slide,false,slide);
            auto& control=hits_.back();
            control.resetTarget={ResetSurface::TrackTone,soundPlayer_,drum.track*128+drum.note,names[i],soundSerial_,activityRevision_,{}};
            control.reset=[apply,param,i]{apply(param,i<4?-1:0);};
            const int step=1;
            button(c,{12,337,179,398},"−",orange,false,current>low[i],[apply,param,base,relative,v=std::clamp(current-step,low[i],high[i])]{apply(param,relative&&v==base?-1:v);},24);
            button(c,{189,337,357,398},"+",orange,false,current<high[i],[apply,param,base,relative,v=std::clamp(current+step,low[i],high[i])]{apply(param,relative&&v==base?-1:v);},24);
            button(c,{397,337,787,398},i<4?"Use kit envelope":"Reset",green,false,true,[apply,param,i]{apply(param,i<4?-1:0);},18);
        }
        transport(418,474);
        button(c,{12,418,535,474},"‹ Drum edit",green,false,true,[this]{drumParameter_.reset();dirty_=true;},19);
        return;
    }
    for(int i=0;i<8;++i){
        const float x=12+(i%2)*393,y=97+(i/2)*78;
        const auto param=static_cast<Param>(i);const bool enabled=param!=Param::Release||!oneShot;
        const RectF r{x,y,x+383,y+70};box(c,r,panel,kBorder,5);
        label(c,names[i],x+14,y+26,17,enabled?orange:dim,true,178);
        label(c,enabled?shown(i):"One Shot · select Gate",x+14,y+55,21,enabled?white:dim,true,326);
        label(c,"›",r.right-15,y+46,24,orange,true,20,Align::Right);
        hit(r,[this,param,enabled]{drumParameter_=enabled?param:Param::Gate;dirty_=true;});
    }
    label(c,"Release follows note-off. One Shot plays to the end of the sample.",16,434,14,dim,false,765);
    transport(443,477);
    button(c,{12,443,279,477},"‹ Active drums",green,false,true,[this]{drumNote_=-1;dirty_=true;},15);
    button(c,{289,443,535,477},"Kit groups",orange,false,kstCatalog_&&drum.auditionSource,
           [this,drum]{openStyleDrumGroups(drum);},16);
}
void ArrangerView::drawLiveSoundPage(Canvas& c){
    const bool keyboard=picker_==Picker::KeyboardParts;
    const bool drums=picker_==Picker::StyleDrums;
    const auto& player=players_[selectedPlayer_];
    const bool current=keyboard||(player.loaded&&!player.styleSwitchPending&&selectedPlayer_==soundPlayer_&&
                            soundSerial_==player.styleSelectionSerial);
    const auto accent=keyboard?green:orange;
    button(c,{8,7,91,49},"‹ Back",accent,false,true,[this]{panelExit();},16);
    label(c,keyboard?"Keyboard Sounds":drums?"Drum Editor / Drum Edit":"Style Sounds",108,36,24,white,true,440);
    button(c,{603,7,791,49},keyboard?"Save Keyboard Set":"Save Style",accent,false,current,[this,keyboard]{openResourceSave(!keyboard);},16);
    if(!current){label(c,"The Style changed. Return to Live to edit the active Style.",24,172,21,dim,false,750);return;}
    if(!keyboard)updateStyleActivity(player);
    if(drums&&drumNote_>=0){
        const auto* it=editedDrum_?&*editedDrum_:nullptr;
        if(it&&it->track==drumTrack_&&it->note==drumNote_){
            label(c,player.elementName+"   /   "+(it->track?"Perc":"Drum")+"   "+std::to_string(it->note)+"   "+it->name,16,79,18,orange,true,575);
            drawDrumEnvelope(c,*it,player.tracks[it->track]);return;
        }
    }
    label(c,keyboard?combiName_:(player.elementName+"   /   Player "+std::to_string(selectedPlayer_+1)+"   /   "+player.name),16,80,18,accent,true,keyboard||drums?760:410);
    if(!drums){
        for(int i=0;i<(keyboard?7:8);++i){
            const float x=12+(i%2)*392,y=98+(i/2)*91;
            const RectF rect{x,y,x+384,y+79};
            const auto& track=player.tracks[i];
            const std::string name=keyboard?(uppers_[i]?uppers_[i]->soundName:""):styleSoundName(i);
            box(c,rect,panel,kBorder,6);
            const bool muted=keyboard?(!uppers_[i]||!uppers_[i]->enabled||uppers_[i]->mute):track.mute;
            label(c,keyboard?arrangerKeyboardPartName(i):track.name,x+15,y+27,17,accent,true,245);
            if(muted)label(c,"MUTE",rect.right-16,y+27,14,dim,true,76,Align::Right);
            label(c,name.empty()?"Select Sound":name,x+15,y+60,21,white,true,325);
            label(c,"›",rect.right-21,y+48,26,accent,true,28,Align::Center);
            hit(rect,[this,i,keyboard]{openTargetSound(keyboard?i:0,keyboard?-1:i);});
        }
        return;
    }
    std::vector<const host::StyleActivity::Drum*> visible;
    for(const auto& item:activity_.drums)
        if(!player.playing||!recentPartsOnly_||recentHits_.drums[item.track].test(item.note))visible.push_back(&item);
    label(c,"ACTIVE DRUMS",16,120,18,accent,true,315);
    if(kstCatalog_)button(c,{245,90,454,128},"Edit SET Drum Kit",green,false,true,[this]{openInspector(Picker::SetSounds);filterSetSounds(2);},14);
    drawActivitySwitch(c,{474,90,638,128},player.playing);
    label(c,std::to_string(visible.size())+" keys",784,120,16,dim,false,275,Align::Right);
    const int pages=std::max(1,static_cast<int>((visible.size()+3)/4));
    drumPage_=std::clamp(drumPage_,0,pages-1);
    for(int row=0;row<4;++row){
        const int index=drumPage_*4+row;
        if(index>=static_cast<int>(visible.size()))break;
        const auto& item=*visible[index];const int note=item.note,track=item.track;
        const auto& settings=player.tracks[track].soundSettings;
        const int db=settings.keyDb[note];
        const float y=135+row*70.0F;
        const RectF rect{12,y,788,y+64};box(c,rect,panel,kBorder,5);
        label(c,item.name.empty()?arrangerNoteName(note):item.name,24,y+26,19,white,true,348);
        std::string detail=std::string(track?"Perc":"Drum")+"   MIDI "+std::to_string(note);
        if(item.name.empty()&&(note==35||note==36))detail+="   ·   GM map: Kick";
        label(c,detail,24,y+53,14,dim,false,340);
        const auto edit=[this,track,note,item]{editedDrum_=item;drumTrack_=track;drumNote_=note;drumParameter_.reset();dirty_=true;};
        hit({12,y,366,y+64},edit);
        button(c,{370,y+4,460,y+60},"Edit",accent,false,true,edit,17);
        button(c,{469,y+4,541,y+60},"−",accent,false,db> -60,[this,track,note,db]{editStyleDrum(track,note,DrumParameter::Level,db-1);},24);
        label(c,std::to_string(db)+" dB",596,y+39,19,white,true,102,Align::Center);
        button(c,{650,y+4,716,y+60},"+",accent,false,db<12,[this,track,note,db]{editStyleDrum(track,note,DrumParameter::Level,db+1);},22);
        button(c,{722,y+4,783,y+60},"Reset",accent,false,db!=0,[this,track,note]{editStyleDrum(track,note,DrumParameter::Level,0);},14);
    }
    if(visible.empty())label(c,recentPartsOnly_&&player.playing?"Waiting for Drum / Perc hits…":"No playable Drum or Perc hits in this section.",400,241,20,dim,false,758,Align::Center);
    button(c,{12,423,108,473},"‹",accent,false,drumPage_>0,[this]{--drumPage_;dirty_=true;},26);
    label(c,std::to_string(drumPage_+1)+" / "+std::to_string(pages),400,457,18,dim,false,245,Align::Center);
    button(c,{692,423,788,473},"›",accent,false,drumPage_+1<pages,[this]{++drumPage_;dirty_=true;},26);
}
