// Direct destinations from the Live panel. The selected player and Style own all Style edits.
void ArrangerView::openTargetSound(int part,int track){
    if(track>=0){
        const auto current=host::arrangerHost().snapshot(selectedPlayer_);
        if(!current.loaded||current.styleSwitchPending||
           (picker_==Picker::StyleSounds&&soundSerial_!=current.styleSelectionSerial)){
            showToast("Select the active Style again",4500);return;
        }
        soundPlayer_=selectedPlayer_;soundSerial_=current.styleSelectionSerial;
    }
    targetPart_=part;targetTrack_=track;openPicker(Picker::Sound);
    if(homeSoundEdit_&&(picker_==Picker::Sound||(picker_==Picker::KstCatalog&&kstCatalogTab_==1))){
        stopEqTap();
        homeSoundEdit_=false;
    }
}
void ArrangerView::finishSoundSelection(){
    const bool keyboardSelection=targetTrack_<0;
    // USER may have been opened from a SET tile picker. Return to the track/part that opened it.
    do {
        if(!restoreNavigation()){picker_=Picker::None;break;}
    }while(!homeSoundEdit_&&(picker_==Picker::Sound||(picker_==Picker::KstCatalog&&kstCatalogTab_==1)));
    if(keyboardSelection)overrideStyleKeyboardCue();
    targetTrack_=-1;targetPart_=0;
    markPersistentStateChanged();refresh(true);dirty_=true;
}
void ArrangerView::updateStyleActivity(const host::ArrangerPlayerView& p){
    std::array<int,8> cvs{};
    for(int i=0;i<8;++i)cvs[i]=p.tracks[i].selectedCv;
    const int blocked=p.playing?p.blockedTrackMask:0;
    if(selectedPlayer_==activityPlayer_&&activitySerial_==p.styleSelectionSerial&&activityRevision_==p.soundRevision&&
       activityElement_==p.element&&activityBlocked_==blocked&&activityCvs_==cvs)return;
    activity_=host::arrangerHost().styleActivity(selectedPlayer_,p);
    activityPlayer_=selectedPlayer_;activitySerial_=p.styleSelectionSerial;activityRevision_=p.soundRevision;
    activityElement_=p.element;activityBlocked_=blocked;activityCvs_=cvs;
    if(drumNote_>=0&&soundPlayer_==selectedPlayer_&&soundSerial_==p.styleSelectionSerial){
        for(const auto& item:activity_.drums)if(item.track==drumTrack_&&item.note==drumNote_){editedDrum_=item;break;}
    }
    drumPage_=std::clamp(drumPage_,0,std::max(0,(static_cast<int>(activity_.drums.size())-1)/4));
}
void ArrangerView::drawActivitySwitch(Canvas& c,const RectF& rect,bool playing){
    const bool recent=playing&&recentPartsOnly_;
    button(c,rect,recent?"Last 2 s":"Section",orange,recent,playing,[this]{
        recentPartsOnly_=!recentPartsOnly_;drumPage_=0;refresh(false);dirty_=true;
    },15);
}
void ArrangerView::openLiveSoundPage(Picker page){
    const auto p=host::arrangerHost().snapshot(selectedPlayer_);
    if(page!=Picker::KeyboardParts&&(!p.loaded||p.styleSwitchPending)){showToast("Select the active Style first",4000);return;}
    rememberNavigation();
    soundPlayer_=selectedPlayer_;soundSerial_=p.styleSelectionSerial;
    picker_=page;editor_=false;
    drumPage_=0;drumNote_=-1;drumParameter_.reset();editedDrum_.reset();
    if(page==Picker::DrumFamilyEdit){drumTrack_=0;drumFamily_=0;drumFamilyParam_=0;drumFamilyMapTrack_=-1;
        drumStyleNotes_=false;styleNoteKey_=-1;styleNotePage_=0;styleNoteLamps_={};}
    refresh(false);dirty_=true;
}
void ArrangerView::editStyleDrum(int track,int note,DrumParameter parameter,int value){
    if(picker_!=Picker::StyleDrums||soundPlayer_!=selectedPlayer_)return;
    auto& arranger=host::arrangerHost();
    const auto p=arranger.snapshot(soundPlayer_);
    if(p.styleSwitchPending||p.styleSelectionSerial!=soundSerial_)return;
    updateStyleActivity(p);
    if(!(editedDrum_&&drumNote_==note&&drumTrack_==track)&&std::none_of(activity_.drums.begin(),activity_.drums.end(),[&](const auto& item){
        return item.track==track&&item.note==note;
    }))return;
    const auto& settings=p.tracks[track].soundSettings;
    int db=settings.keyDb[note];
    host::StyleDrumTone tone;
    if(settings.tones){const auto it=settings.tones->find(note);if(it!=settings.tones->end())tone=it->second;}
    switch(parameter){
        case DrumParameter::Attack:tone.attack=value;break;
        case DrumParameter::Decay:tone.decay=value;break;
        case DrumParameter::Sustain:tone.sustain=value;break;
        case DrumParameter::Release:tone.release=value;break;
        case DrumParameter::Level:db=value;break;
        case DrumParameter::Pan:tone.pan=value;break;
        case DrumParameter::Tune:tone.tune=value;break;
        case DrumParameter::Gate:tone.gate=value;break;
    }
    if(!arranger.setStyleDrum(soundPlayer_,track,soundSerial_,note,db,tone)){showToast(arranger.lastError(),4500);return;}
    refresh(false);markPersistentStateChanged();dirty_=true;
}
void ArrangerView::openStyleDrumGroups(const host::StyleActivity::Drum& drum){
    if(!kstCatalog_||!drum.auditionSource||drum.note<0||drum.note>127||drum.track<0||drum.track>=8)return;
    auto& arranger=host::arrangerHost();
    const auto player=arranger.snapshot(soundPlayer_);
    if(soundPlayer_!=selectedPlayer_||player.styleSwitchPending||player.styleSelectionSerial!=soundSerial_){
        showToast("Select the active Style again",4500);return;
    }
    // Match the actual prepared Program that produced this key. A MIDI note,
    // kit name, or a GM convention cannot identify the editable SET resource.
    std::vector<std::size_t> matches;
    for(std::size_t i=0;i<kstCatalog_->sounds.size();++i){
        const auto& sound=kstCatalog_->sounds[i];
        if(sound.drumKit&&arranger.preparedKeyboardSound(sound.msb,sound.lsb,sound.program,kstCatalog_->rootPath)==drum.auditionSource)
            matches.push_back(i);
    }
    if(matches.size()>1){
        const auto& track=player.tracks[drum.track];
        const int assigned=track.soundSettings.setAddress;
        if(assigned>=0)matches.erase(std::remove_if(matches.begin(),matches.end(),[&](std::size_t index){
            const auto& sound=kstCatalog_->sounds[index];return assigned!=((sound.msb<<16)|(sound.lsb<<8)|sound.program);
        }),matches.end());
    }
    if(matches.size()!=1){
        showToast(matches.empty()?"Load the SET containing this kit to edit its groups":"Select this kit from SET Sounds to edit its groups",6000);return;
    }
    const auto index=matches.front();const auto& source=kstCatalog_->sounds[index];
    auto draft=std::make_shared<host::DrumKitDraft>();
    if(!arranger.openDrumKit(kstCatalog_->rootPath,source.msb,source.lsb,source.program,*draft)){
        showToast(arranger.lastError(),5500);return;
    }
    const auto current=arranger.snapshot(soundPlayer_);
    if(current.styleSelectionSerial!=soundSerial_||current.styleSwitchPending){showToast("Select the active Style again",4500);return;}
    arranger.stopPcmPreview();previewDrumNote_=-1;
    inspectSetSound(index);drumDraft_=std::move(draft);drumKey_=drum.note;drumZone_=0;
    drumTab_=2;drumGroupEdit_=-1;drumExitPrompt_=false;drumMidiLearn_=false;
    openInspector(Picker::DrumKitEdit);
}
void ArrangerView::drawDrumEnvelope(Canvas& c,const host::StyleActivity::Drum& drum,const host::ArrangerTrackView& track){
    using Param=DrumParameter;
    const auto transport=[&](float top,float bottom){
        const auto& state=players_[soundPlayer_];
        button(c,{546,top,788,bottom},state.playing?"Stop":"Start",green,state.playing,
            state.playing||(state.loaded&&state.soundAssignmentsReady),
            [this,player=soundPlayer_]{startStopPlayer(player);},18,true);
    };
    static const char* names[]{"Attack","Decay","Sustain","Release","Level","Pan","Tune","Trigger"};
    const auto& settings=track.soundSettings;
    host::StyleDrumTone tone;
    if(settings.tones){const auto it=settings.tones->find(drum.note);if(it!=settings.tones->end())tone=it->second;}
    const std::array<int,8> values{{tone.attack,tone.decay,tone.sustain,tone.release,settings.keyDb[drum.note],tone.pan,tone.tune,tone.gate}};
    const std::array<int,8> low{{0,0,0,0,-60,-100,-2400,-1}},high{{10000,10000,100,10000,12,100,2400,1}};
    const auto format=[](Param param,int n)->std::string{
        if(param==Param::Gate)return n<0?"Kit":n?"One Shot":"Gate";
        if(param==Param::Sustain)return std::to_string(n)+"%";
        if(param==Param::Level)return std::to_string(n)+" dB";
        if(param==Param::Pan)return n==0?"Center":std::string(n<0?"L ":"R ")+std::to_string(std::abs(n));
        if(param==Param::Tune)return std::to_string(n)+" ct";
        return std::to_string(n)+" ms";
    };
    std::uint64_t selection=0;
    const auto channel=host::arrangerHost().styleTrackCombi(soundPlayer_,selection);
    std::array<float,4> inherited{{-1,-1,-1,-1}};
    if(channel&&selection==soundSerial_){
        const auto& u=channel->part(drum.track);
        inherited={u.toneAttackMs,u.toneDecayMs,u.toneSustain<0?-1:u.toneSustain*100,u.toneReleaseMs};
    }
    const int gate=tone.gate>=0?tone.gate:track.soundSettings.trigger;
    const bool oneShot=gate>=0?gate==1:drum.hasOneShotZone&&!drum.hasGatedZone;
    const auto reference=[&](int i){return std::clamp(inherited[i]>=0?int(std::lround(inherited[i])):drum.sourceEnvelope[i],low[i],high[i]);};
    const auto offsetText=[](int i,int n){return (n>0?"+":std::string{})+std::to_string(n)+(i==2?" %":" ms");};
    const auto shown=[&](int i){
        const auto param=static_cast<Param>(i);
        if(i==1||i==2)return offsetText(i,values[i]<0?0:values[i]-reference(i));
        if(i<4&&values[i]<0&&inherited[i]>=0)return std::string("Track · ")+format(param,static_cast<int>(std::lround(inherited[i])));
        if(i<4&&values[i]<0)return drum.mixedEnvelope&(1U<<i)?std::string("Kit · varies"):std::string("Kit · ")+format(param,drum.sourceEnvelope[i]);
        if(param==Param::Gate&&tone.gate<0&&track.soundSettings.trigger>=0)return std::string("Track · ")+format(param,track.soundSettings.trigger);
        if(param==Param::Gate&&tone.gate<0){
            if(drum.hasGatedZone&&drum.hasOneShotZone)return std::string("Kit · mixed");
            return std::string(oneShot?"Kit · One Shot":"Kit · Gate");
        }
        return format(param,values[i]);
    };
    const auto apply=[this,trackId=drum.track,note=drum.note](Param param,int value){editStyleDrum(trackId,note,param,value);};
    const bool soloKey=host::arrangerHost().listenSolo().matches(soundPlayer_,drum.track,drum.note);
    button(c,{424,52,599,88},"Solo key",orange,soloKey,true,[this,drum,serial=soundSerial_]{
        if(host::arrangerHost().snapshot(soundPlayer_).styleSelectionSerial==serial)listenPart(soundPlayer_,drum.track,drum.note);
    },16,true);
    button(c,{606,52,788,88},"Hold to hear",green,previewDrumNote_==drum.note,true,[this,drum,owner=soundSerial_,rev=activityRevision_]{
        if(host::arrangerHost().auditionStyleDrum(soundPlayer_,owner,rev,drum)){
            previewDrumNote_=drum.note;previewDrumDeadline_=nowMs()+10000;dirty_=true;
        }
    },16,true);
    if(drumParameter_){
        const Param param=*drumParameter_;const int i=static_cast<int>(param);
        label(c,names[i],16,120,23,orange,true,290);
        const bool relative=i==1||i==2;
        const int base=relative?reference(i):0;
        const auto display=relative?shown(i)+"   ·   "+format(param,base)+" → "+format(param,values[i]<0?base:values[i]):shown(i);
        label(c,display,783,120,22,white,true,455,Align::Right);
        const int current=values[i]<0&&i<4?(inherited[i]>=0?int(std::lround(inherited[i])):drum.sourceEnvelope[i]):values[i];
        static const std::vector<int> times{0,1,2,5,10,20,40,60,100,150,250,400,600,1000,1500,2500,5000,10000};
        static const std::vector<int> percents{0,5,10,20,30,40,50,60,70,80,90,100};
        static const std::vector<int> levels{-60,-48,-36,-24,-18,-12,-9,-6,-3,0,3,6,9,12};
        static const std::vector<int> pans{-100,-75,-50,-25,-10,0,10,25,50,75,100};
        static const std::vector<int> cents{-2400,-1200,-700,-500,-200,-100,-50,-10,0,10,50,100,200,500,700,1200,2400};
        static const std::vector<int> trigger{-1,0,1};
        std::vector<int> offsets;
        if(relative){
            const std::vector<int> deltas=i==2?std::vector<int>{-100,-75,-50,-25,-10,-5,0,5,10,25,50,75,100}:
                std::vector<int>{-10000,-2500,-1000,-500,-250,-100,-50,-10,0,10,50,100,250,500,1000,2500,10000};
            for(int d:deltas){
                const int value=std::clamp(base+d,low[i],high[i]);
                if(offsets.empty()||offsets.back()!=value)offsets.push_back(value);
            }
        }
        const auto& choices=relative?offsets:param==Param::Gate?trigger:param==Param::Sustain?percents:
            param==Param::Level?levels:param==Param::Pan?pans:param==Param::Tune?cents:times;
        for(std::size_t j=0;j<choices.size();++j){
            const float x=param==Param::Gate?12+(j%3)*262.0F:238+(j%6)*92.0F,y=136+(j/6)*64.0F;const int v=choices[j];
            button(c,{x,y,x+(param==Param::Gate?251:87),y+57},relative?offsetText(i,v-base):format(param,v),orange,relative?current==v:values[i]==v,true,
                   [apply,param,v,base,relative]{apply(param,relative&&v==base?-1:v);},16);
        }
        if(param!=Param::Gate){
            const int lo=low[i],hi=high[i];
            const bool time=i==0||i==1||i==3;
            const auto unit=[time](int value,int range){return range<=0?0.0F:time?
                float(std::log1p(float(value))/std::log1p(float(range))):float(value)/range;};
            const auto denorm=[time](float position,int range){return time?int(std::lround(std::expm1(position*std::log1p(float(range))))):
                int(std::lround(position*range));};
            const float pos=relative?.5F+.5F*(current<base?-unit(base-current,base-lo):unit(current-base,hi-base)):unit(current-lo,hi-lo);
            const float angle=135+270*pos,rad=66,cx=118,cy=231;
            Paint ink;ink.color=liveKey;c.drawCircle(cx,cy,rad,ink);ink.style=Style::Stroke;ink.strokeCap=Cap::Round;ink.strokeWidth=5;
            const RectF arc{cx-rad-5,cy-rad-5,cx+rad+5,cy+rad+5};ink.color=liveLine;c.drawArc(arc,135,270,false,ink);
            ink.color=orange;const float start=relative?270:135;
            if(std::abs(angle-start)>.1F)c.drawArc(arc,std::min(angle,start),std::abs(angle-start),false,ink);
            const float a=angle*.01745329252F;c.drawLine(cx+std::cos(a)*rad*.32F,cy+std::sin(a)*rad*.32F,cx+std::cos(a)*rad*.86F,cy+std::sin(a)*rad*.86F,ink);
            const auto slide=[=](float,float y){
                if(toneDialPreview_!=i){
                    toneDialGrabY_=y;toneDialPreview_=i;toneGestureLast_=current;return;
                }
                const float n=std::clamp(pos+(toneDialGrabY_-y)/182.0F,0.0F,1.0F);
                const int value=std::clamp(relative?(n<.5F?base-denorm(1-2*n,base-lo):base+denorm(2*n-1,hi-base)):lo+denorm(n,hi-lo),lo,hi);
                if(value!=int(toneGestureLast_)){apply(param,relative&&value==base?-1:value);toneGestureLast_=value;}
            };
            hit({12,132,222,326},{},slide,false,slide);
            auto& control=hits_.back();
            control.resetTarget={ResetSurface::TrackTone,soundPlayer_,drum.track*128+drum.note,names[i],soundSerial_,activityRevision_,{}};
            control.reset=[apply,param,i]{apply(param,i<4?-1:0);};
            const int step=1;
            button(c,{12,337,179,398},"−",orange,false,current>low[i],[apply,param,base,relative,v=std::clamp(current-step,low[i],high[i])]{apply(param,relative&&v==base?-1:v);},24);
            button(c,{189,337,357,398},"+",orange,false,current<high[i],[apply,param,base,relative,v=std::clamp(current+step,low[i],high[i])]{apply(param,relative&&v==base?-1:v);},24);
            button(c,{397,337,787,398},i<4?"Use kit envelope":"Reset",green,false,true,[apply,param,i]{apply(param,i<4?-1:0);},18);
        }
        transport(418,474);
        button(c,{12,418,535,474},"‹ Drum edit",green,false,true,[this]{drumParameter_.reset();dirty_=true;},19);
        return;
    }
    for(int i=0;i<8;++i){
        const float x=12+(i%2)*393,y=97+(i/2)*78;
        const auto param=static_cast<Param>(i);const bool enabled=param!=Param::Release||!oneShot;
        const RectF r{x,y,x+383,y+70};box(c,r,panel,kBorder,5);
        label(c,names[i],x+14,y+26,17,enabled?orange:dim,true,178);
        label(c,enabled?shown(i):"One Shot · select Gate",x+14,y+55,21,enabled?white:dim,true,326);
        label(c,"›",r.right-15,y+46,24,orange,true,20,Align::Right);
        hit(r,[this,param,enabled]{drumParameter_=enabled?param:Param::Gate;dirty_=true;});
    }
    label(c,"Release follows note-off. One Shot plays to the end of the sample.",16,434,14,dim,false,765);
    transport(443,477);
    button(c,{12,443,279,477},"‹ Active drums",green,false,true,[this]{drumNote_=-1;dirty_=true;},15);
    button(c,{289,443,535,477},"Kit groups",orange,false,kstCatalog_&&drum.auditionSource,
           [this,drum]{openStyleDrumGroups(drum);},16);
}
void ArrangerView::drawLiveSoundPage(Canvas& c){
    const bool keyboard=picker_==Picker::KeyboardParts;
    const bool drums=picker_==Picker::StyleDrums;
    const auto& player=players_[selectedPlayer_];
    const bool current=keyboard||(player.loaded&&!player.styleSwitchPending&&selectedPlayer_==soundPlayer_&&
                            soundSerial_==player.styleSelectionSerial);
    const auto accent=keyboard?green:orange;
    button(c,{8,7,91,49},"‹ Back",accent,false,true,[this]{panelExit();},16);
    label(c,keyboard?"Keyboard Sounds":drums?"Drum Editor / Drum Edit":"Style Sounds",108,36,24,white,true,440);
    button(c,{603,7,791,49},keyboard?"Save Keyboard Set":"Save Style",accent,false,current,[this,keyboard]{openResourceSave(!keyboard);},16);
    if(!current){label(c,"The Style changed. Return to Live to edit the active Style.",24,172,21,dim,false,750);return;}
    if(!keyboard)updateStyleActivity(player);
    if(drums&&drumNote_>=0){
        const auto* it=editedDrum_?&*editedDrum_:nullptr;
        if(it&&it->track==drumTrack_&&it->note==drumNote_){
            label(c,player.elementName+"   /   "+(it->track?"Perc":"Drum")+"   "+std::to_string(it->note)+"   "+it->name,16,79,18,orange,true,575);
            drawDrumEnvelope(c,*it,player.tracks[it->track]);return;
        }
    }
    label(c,keyboard?combiName_:(player.elementName+"   /   Player "+std::to_string(selectedPlayer_+1)+"   /   "+player.name),16,80,18,accent,true,keyboard||drums?760:410);
    if(!drums){
        for(int i=0;i<(keyboard?7:8);++i){
            const float x=12+(i%2)*392,y=98+(i/2)*91;
            const RectF rect{x,y,x+384,y+79};
            const auto& track=player.tracks[i];
            const std::string name=keyboard?(uppers_[i]?uppers_[i]->soundName:""):styleSoundName(i);
            box(c,rect,panel,kBorder,6);
            const bool muted=keyboard?(!uppers_[i]||!uppers_[i]->enabled||uppers_[i]->mute):track.mute;
            label(c,keyboard?arrangerKeyboardPartName(i):track.name,x+15,y+27,17,accent,true,245);
            if(muted)label(c,"MUTE",rect.right-16,y+27,14,dim,true,76,Align::Right);
            label(c,name.empty()?"Select Sound":name,x+15,y+60,21,white,true,325);
            label(c,"›",rect.right-21,y+48,26,accent,true,28,Align::Center);
            hit(rect,[this,i,keyboard]{openTargetSound(keyboard?i:0,keyboard?-1:i);});
        }
        return;
    }
    std::vector<const host::StyleActivity::Drum*> visible;
    for(const auto& item:activity_.drums)
        if(!player.playing||!recentPartsOnly_||recentHits_.drums[item.track].test(item.note))visible.push_back(&item);
    button(c,{12,90,235,128},"Drum Families",orange,false,true,[this]{openLiveSoundPage(Picker::DrumFamilyEdit);},15);
    if(kstCatalog_)button(c,{245,90,454,128},"Edit SET Drum Kit",green,false,true,[this]{openInspector(Picker::SetSounds);filterSetSounds(2);},14);
    drawActivitySwitch(c,{474,90,638,128},player.playing);
    label(c,std::to_string(visible.size())+" keys",784,120,16,dim,false,275,Align::Right);
    const int pages=std::max(1,static_cast<int>((visible.size()+3)/4));
    drumPage_=std::clamp(drumPage_,0,pages-1);
    for(int row=0;row<4;++row){
        const int index=drumPage_*4+row;
        if(index>=static_cast<int>(visible.size()))break;
        const auto& item=*visible[index];const int note=item.note,track=item.track;
        const auto& settings=player.tracks[track].soundSettings;
        const int db=settings.keyDb[note];
        const float y=135+row*70.0F;
        const RectF rect{12,y,788,y+64};box(c,rect,panel,kBorder,5);
        label(c,item.name.empty()?arrangerNoteName(note):item.name,24,y+26,19,white,true,348);
        std::string detail=std::string(track?"Perc":"Drum")+"   MIDI "+std::to_string(note);
        if(item.name.empty()&&(note==35||note==36))detail+="   ·   GM map: Kick";
        label(c,detail,24,y+53,14,dim,false,340);
        const auto edit=[this,track,note,item]{editedDrum_=item;drumTrack_=track;drumNote_=note;drumParameter_.reset();dirty_=true;};
        hit({12,y,366,y+64},edit);
        button(c,{370,y+4,460,y+60},"Edit",accent,false,true,edit,17);
        button(c,{469,y+4,541,y+60},"−",accent,false,db> -60,[this,track,note,db]{editStyleDrum(track,note,DrumParameter::Level,db-1);},24);
        label(c,std::to_string(db)+" dB",596,y+39,19,white,true,102,Align::Center);
        button(c,{650,y+4,716,y+60},"+",accent,false,db<12,[this,track,note,db]{editStyleDrum(track,note,DrumParameter::Level,db+1);},22);
        button(c,{722,y+4,783,y+60},"Reset",accent,false,db!=0,[this,track,note]{editStyleDrum(track,note,DrumParameter::Level,0);},14);
    }
    if(visible.empty())label(c,recentPartsOnly_&&player.playing?"Waiting for Drum / Perc hits…":"No playable Drum or Perc hits in this section.",400,241,20,dim,false,758,Align::Center);
    button(c,{12,423,108,473},"‹",accent,false,drumPage_>0,[this]{--drumPage_;dirty_=true;},26);
    label(c,std::to_string(drumPage_+1)+" / "+std::to_string(pages),400,457,18,dim,false,245,Align::Center);
    button(c,{692,423,788,473},"›",accent,false,drumPage_+1<pages,[this]{++drumPage_;dirty_=true;},26);
}

// Style-local quick editor: family names are conservative sample-name suggestions,
// not Korg family IDs or exclusive/choke groups. Unknown keys remain individually editable.
void ArrangerView::drawDrumFamilyEdit(Canvas& c){
    using Edit=host::ArrangerHost::DrumKeyEdit;
    auto& h=host::arrangerHost();const auto player=h.snapshot(soundPlayer_);
    box(c,{0,0,800,480},bg);
    label(c,drumStyleNotes_?"DRUM EDITOR / STYLE NOTES":"DRUM EDITOR / DRUM EDIT",12,27,19,orange,true,490);
    button(c,{670,4,790,35},"‹ Back",orange,false,true,[this]{panelExit();},15);
    if(drumStyleNotes_)button(c,{520,4,664,35},player.playing?"Stop":"Start",green,player.playing,
        soundPlayer_==selectedPlayer_&&player.styleSelectionSerial==soundSerial_&&!player.styleSwitchPending&&
        (player.playing||(player.loaded&&player.soundAssignmentsReady)),[this]{startStopPlayer(soundPlayer_);},15);
    if(soundPlayer_!=selectedPlayer_||!player.loaded||player.styleSwitchPending||player.styleSelectionSerial!=soundSerial_){
        label(c,"Select the current Style before editing.",400,230,20,dim,false,760,Align::Center);return;
    }
    const int track=std::clamp(drumTrack_,0,1);
    if(drumStyleNotes_&&(styleNotesPlayer_!=soundPlayer_||styleNotesSerial_!=soundSerial_||styleNotesRevision_!=player.soundRevision)){
        allStyleDrums_=h.styleActivity(soundPlayer_,player,true);
        styleNotesPlayer_=soundPlayer_;styleNotesSerial_=soundSerial_;styleNotesRevision_=player.soundRevision;
        styleNoteKey_=-1;styleNotePage_=0;
    }
    if(drumFamilySerial_!=soundSerial_||drumFamilyMap_.revision!=player.soundRevision||drumFamilyMapTrack_!=track||drumFamilyMapPlayer_!=soundPlayer_){
        drumFamilyMap_=h.styleDrumFamilies(soundPlayer_,track,soundSerial_);
        drumFamilySerial_=soundSerial_;drumFamilyMapTrack_=track;drumFamilyMapPlayer_=soundPlayer_;
        if(!drumFamilyMap_.available)drumFamilyMap_.revision=player.soundRevision;
    }
    const auto& map=drumFamilyMap_;const auto& setting=player.tracks[track].soundSettings;
    label(c,std::string(track==0?"DRUM   /   ":"PERC   /   ")+(map.kitName.empty()?styleSoundName(track):map.kitName),12,59,16,white,true,445);
    button(c,{485,40,580,68},"Mute",orange,player.tracks[track].mute,true,[this,track,serial=soundSerial_]{
        bool muted=false;if(host::arrangerHost().toggleTrackMute(soundPlayer_,track,serial,muted)){refresh(false);markPersistentStateChanged();dirty_=true;}
    },14);
    button(c,{586,40,678,68},"Solo",orange,partSolo(soundPlayer_,track),player.tracks[track].assigned||partSolo(soundPlayer_,track),[this,track]{listenPart(soundPlayer_,track);},14);
    button(c,{684,40,790,68},"Save Style",green,false,true,[this]{openResourceSave(true);},13);
    std::array<std::vector<int>,8> notes;int unknown=0;
    for(int key=0;key<128;++key)if(map.keys[key].present){const int f=map.keys[key].family;if(f>=0&&f<8)notes[f].push_back(key);else ++unknown;}
    std::vector<const host::StyleActivity::Drum*> used;
    if(drumStyleNotes_)for(const auto& row:allStyleDrums_.drums)if(row.track==track)used.push_back(&row);
    const int pages=std::max(1,int((used.size()+7)/8));
    styleNotePage_=std::clamp(styleNotePage_,0,pages-1);
    const auto selectedRow=[&]()->const host::StyleActivity::Drum*{
        for(const auto* row:used)if(row->note==styleNoteKey_)return row;
        return nullptr;
    };
    if(drumStyleNotes_&&!selectedRow())styleNoteKey_=used.empty()?-1:used[std::size_t(styleNotePage_)*8]->note;
    const auto* row=selectedRow();
    const auto sourceKey=[&](int key){
        auto source=map.keys[key];
        if(drumStyleNotes_)for(const auto* hit:used)if(hit->note==key){source.envelope=hit->sourceEnvelope;source.mixedEnvelope=hit->mixedEnvelope;break;}
        return source;
    };
    drumFamily_=std::clamp(drumFamily_,0,7);drumFamilyParam_=std::clamp(drumFamilyParam_,0,drumStyleNotes_?7:6);
    const auto makeEdit=[&](int note){Edit e;e.note=note;e.db=setting.keyDb[note];if(setting.tones){const auto i=setting.tones->find(note);if(i!=setting.tones->end())e.tone=i->second;}return e;};
    static constexpr const char* params[]{"Volume trim","Fine tune","Pan trim","Attack override","Decay override","Sustain override","Release override","Trigger"};
    static constexpr const char* units[]{" dB"," ct"," %"," ms"," ms"," %"," ms",""};
    static constexpr int step[]{1,10,5,5,10,5,10,1},lo[]{-60,-2400,-100,0,0,0,0,-1},hi[]{12,2400,100,10000,10000,100,10000,1};
    const auto value=[](const Edit& e,int p){switch(p){case 0:return e.db;case 1:return e.tone.tune;case 2:return e.tone.pan;case 3:return e.tone.attack;case 4:return e.tone.decay;case 5:return e.tone.sustain;case 6:return e.tone.release;default:return e.tone.gate;}};
    const auto assign=[](Edit& e,int p,int v){switch(p){case 0:e.db=v;break;case 1:e.tone.tune=v;break;case 2:e.tone.pan=v;break;case 3:e.tone.attack=v;break;case 4:e.tone.decay=v;break;case 5:e.tone.sustain=v;break;case 6:e.tone.release=v;break;default:e.tone.gate=v;break;}};
    const auto overview=[&](const std::vector<int>& group,int p){
        if(group.empty())return std::string("—");const int first=value(makeEdit(group.front()),p);
        for(int key:group)if(value(makeEdit(key),p)!=first)return std::string("Mixed");
        if(p==7)return std::string(first<0?"Kit":first==0?"Gate":"One Shot");
        if(p>=3&&first<0)return std::string("Kit");return (first>0&&p<3?"+":std::string{})+std::to_string(first)+units[p];
    };
    if(drumStyleNotes_){
        // Fixed note tiles: activity never changes their position or the selected edit target.
        for(int f=0;f<8;++f){
            const float x=8+98.0F*f,cx=x+47;const RectF tile{x,79,x+94,157};
            const auto index=std::size_t(styleNotePage_)*8+f;
            if(index>=used.size()){box(c,tile,panel,kBorder,3);continue;}
            const auto* hitRow=used[index];const int key=hitRow->note;const bool on=key==styleNoteKey_;
            const bool lit=player.playing&&styleNoteLamps_.drums[track].test(key);
            box(c,tile,on?0xFF37332BU:panel,on?orange:kBorder,3);
            label(c,arrangerNoteName(key)+" / "+std::to_string(key),cx,99,14,on?orange:dim,true,90,Align::Center);
            label(c,hitRow->name.empty()?"Unnamed sample":hitRow->name,cx,120,12,white,true,90,Align::Center);
            label(c,overview({key},drumFamilyParam_),cx,136,11,dim,false,90,Align::Center);
            Paint lamp;lamp.color=lit?0xFF4CFF83U:0xFF263B32U;c.drawCircle(cx,147,5.5F,lamp);
            lamp.style=Style::Stroke;lamp.strokeWidth=1;lamp.color=lit?0xFFB9FFD0U:0xFF4C675AU;c.drawCircle(cx,147,5.5F,lamp);
            hit(tile,[this,key]{styleNoteKey_=key;dirty_=true;});
        }
        const int prevKey=styleNotePage_>0?used[std::size_t(styleNotePage_-1)*8]->note:-1;
        const int nextKey=styleNotePage_+1<pages?used[std::size_t(styleNotePage_+1)*8]->note:-1;
        button(c,{12,161,65,190},"‹",blue,false,prevKey>=0,[this,prevKey]{--styleNotePage_;styleNoteKey_=prevKey;dirty_=true;},17);
        button(c,{735,161,788,190},"›",blue,false,nextKey>=0,[this,nextKey]{++styleNotePage_;styleNoteKey_=nextKey;dirty_=true;},17);
        label(c,std::to_string(used.size())+" playable keys · All Style sections / CVs · "+std::to_string(styleNotePage_+1)+" / "+std::to_string(pages),400,180,13,dim,false,654,Align::Center);
    }else for(int f=0;f<8;++f){
        const float x=8+98.0F*f,cx=x+47;const bool on=drumFamily_==f;const RectF r{x,79,x+94,157};
        box(c,r,on?0xFF37332BU:panel,on?orange:kBorder,3);Paint ink;ink.color=on?orange:dim;ink.style=Style::Stroke;ink.strokeWidth=2.3F;
        if(f<3){c.drawCircle(cx,100,f==0?16.0F:12.0F,ink);if(f==1)c.drawLine(cx-10,88,cx+11,112,ink);if(f==2){c.drawCircle(cx-16,94,6,ink);c.drawCircle(cx+16,94,6,ink);}}
        else if(f<5){c.drawLine(cx-19,94,cx+19,94,ink);c.drawLine(cx,91,cx,115,ink);c.drawLine(cx-10,115,cx+10,115,ink);if(f==3)c.drawLine(cx-17,100,cx+17,100,ink);}
        else if(f<7)box(c,{cx-10,87,cx+10,112},bg,on?orange:dim,3);else label(c,"FX",cx,110,20,on?orange:dim,true,80,Align::Center);
        label(c,host::drumFamilyNames[f],cx,130,13,on?white:dim,true,90,Align::Center);label(c,overview(notes[f],drumFamilyParam_),cx,148,12,dim,false,90,Align::Center);
        hit(r,[this,f]{drumFamily_=f;dirty_=true;});
    }
    if(!drumStyleNotes_)label(c,map.available?"Suggested families from sample names · "+std::to_string(unknown)+" unclassified keys":"Kit unavailable: "+map.reason,12,180,13,dim,false,776);
    const auto members=drumStyleNotes_?(row?std::vector<int>{row->note}:std::vector<int>{}):notes[drumFamily_];
    label(c,drumStyleNotes_?(row?arrangerNoteName(row->note)+"  /  MIDI "+std::to_string(row->note)+"  /  "+row->name:"No playable drum notes in this track"):
        std::string(host::drumFamilyNames[drumFamily_])+"   /   "+std::to_string(members.size())+" mapped keys",12,204,16,orange,true,776);
    std::array<std::array<int,4>,128> sourceEnvelopes{};std::array<unsigned,128> sourceMixed{};
    for(int key:members){const auto source=sourceKey(key);sourceEnvelopes[key]=source.envelope;sourceMixed[key]=source.mixedEnvelope;}
    const auto change=[this,track,selection=soundSerial_,revision=player.soundRevision,value,assign,sourceEnvelopes,sourceMixed](std::vector<Edit> edits,int p,int delta,bool reset){
        const auto current=host::arrangerHost().snapshot(soundPlayer_);
        if(current.styleSwitchPending||current.styleSelectionSerial!=selection||current.soundRevision!=revision)return;
        // Use current edits (not stale values from the previous frame).
        const auto& s=current.tracks[track].soundSettings;
        for(auto& e:edits){e.db=s.keyDb[e.note];e.tone={};if(s.tones){const auto i=s.tones->find(e.note);if(i!=s.tones->end())e.tone=i->second;}
            int v=value(e,p);if(p>=3&&p<7&&v<0){v=sourceEnvelopes[e.note][p-3];if(!reset&&(v<0||(sourceMixed[e.note]&(1U<<(p-3)))))return;}
            assign(e,p,reset?(p>=3?-1:0):std::clamp(v+delta,lo[p],hi[p]));}
        if(!host::arrangerHost().setStyleDrumKeys(soundPlayer_,track,selection,revision,edits)){showToast(host::arrangerHost().lastError(),4500);return;}
        refresh(false);markPersistentStateChanged();dirty_=true;
    };
    std::vector<Edit> edits;for(int key:members)edits.push_back(makeEdit(key));
    for(int p=0;p<(drumStyleNotes_?8:7);++p){const float x=12+(p%2)*394.0F,y=216+(p/2)*40.0F;bool enabled=!edits.empty();
        if(p>=3&&p<7)for(const auto& e:edits)if(value(e,p)<0&&((sourceMixed[e.note]&(1U<<(p-3)))||sourceEnvelopes[e.note][p-3]<0))enabled=false;
        box(c,{x,y,x+382,y+37},panel,p==drumFamilyParam_?orange:kBorder,3);label(c,params[p],x+6,y+23,12,enabled?white:dim,false,139);
        hit({x,y,x+142,y+37},[this,p]{drumFamilyParam_=p;dirty_=true;});
        button(c,{x+146,y+2,x+187,y+35},"−",blue,false,enabled,[change,edits,p,this]{drumFamilyParam_=p;change(edits,p,-step[p],false);},17);
        label(c,overview(members,p),x+244,y+24,14,white,true,110,Align::Center);
        button(c,{x+300,y+2,x+339,y+35},"+",blue,false,enabled,[change,edits,p,this]{drumFamilyParam_=p;change(edits,p,step[p],false);},16);
        button(c,{x+342,y+2,x+380,y+35},"R",orange,false,!edits.empty(),[change,edits,p,this]{drumFamilyParam_=p;change(edits,p,0,true);},14);
    }
    if(!drumStyleNotes_)label(c,"Family EQ / Filter / Ambience: not implemented",407,360,12,dim,false,378);
    button(c,{12,381,250,413},drumStyleNotes_?"Drum Families":"Style Notes",blue,drumStyleNotes_,true,[this]{
        drumStyleNotes_=!drumStyleNotes_;styleNotePage_=0;styleNoteKey_=-1;styleNoteLamps_={};refresh(false);dirty_=true;
    },14);
    button(c,{257,381,518,413},drumStyleNotes_?"Solo key":"Sound Edit / Drum Kit",green,drumStyleNotes_&&row&&h.listenSolo().matches(soundPlayer_,track,row->note),drumStyleNotes_?row!=nullptr:kstCatalog_!=nullptr,[this,track,key=styleNoteKey_]{
        if(drumStyleNotes_){if(key>=0)listenPart(soundPlayer_,track,key);}else{openInspector(Picker::SetSounds);filterSetSounds(2);}
    },14);
    button(c,{525,381,788,413},drumStyleNotes_?"Reset key":"Reset Family",orange,false,!edits.empty(),[this,track,edits,selection=soundSerial_,revision=player.soundRevision,individual=drumStyleNotes_]()mutable{
        const auto current=host::arrangerHost().snapshot(soundPlayer_);
        if(current.styleSelectionSerial!=selection||current.soundRevision!=revision||current.styleSwitchPending)return;
        const auto& settings=current.tracks[track].soundSettings;
        for(auto& e:edits){e.db=0;e.tone={};if(!individual&&settings.tones){const auto i=settings.tones->find(e.note);if(i!=settings.tones->end())e.tone.gate=i->second.gate;}}
        if(host::arrangerHost().setStyleDrumKeys(soundPlayer_,track,selection,revision,edits)){refresh(false);markPersistentStateChanged();dirty_=true;}
    },14);
    static constexpr const char* tracks[]{"DRUM","PERC","BASS","ACC1","ACC2","ACC3","ACC4","ACC5"};
    for(int t=0;t<8;++t){const float x=8+98.0F*t;button(c,{x,430,x+94,474},tracks[t],orange,t==track,t<2,[this,t]{drumTrack_=t;drumFamilyMapTrack_=-1;styleNoteKey_=-1;styleNotePage_=0;dirty_=true;},14);}
}
