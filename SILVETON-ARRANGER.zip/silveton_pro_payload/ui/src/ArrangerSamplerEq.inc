// The graph, band mapping, frequency scale and FFT are shared with the sampler's EQ page.
const auto& eq=u.eq;
const int band=std::clamp(toneEqBand_,0,6);
const bool pass=band==0||band==6;
const bool hp=band==0;
const auto& peakBand=eq.band[std::clamp(band-1,0,4)];
const float freq=pass?(hp?eq.hpHz:eq.lpHz):peakBand.freqHz;
const bool bandOn=pass?(hp?eq.hpOn:eq.lpOn):peakBand.on;
const int slope=hp?eq.hpSlopeDb:eq.lpSlopeDb;
const float minHz=hp?10.0F:band==6?1000.0F:20.0F,maxHz=hp?2000.0F:20000.0F;
const auto setFreq=[](Part& part,int b,float f){
    if(b==0)part.eq.hpHz=std::clamp(f,10.0F,2000.0F);
    else if(b==6)part.eq.lpHz=std::clamp(f,1000.0F,20000.0F);
    else part.eq.band[b-1].freqHz=std::clamp(f,20.0F,20000.0F);
};
const auto setGain=[](Part& part,int b,float gain){
    part.eq.band[b-1].gainDb=gain;
    if(b==1)part.eqLowDb=gain;
    if(b==3)part.eqMidDb=gain;
    if(b==5)part.eqHighDb=gain;
};
const auto beforeEqHits=hits_.size();
std::vector<float> params(42);
params[15]=eq.on;
for(int n=1;n<=5;++n){
    int count=0;const auto ids=eqBandIds(n,count);const auto& data=eq.band[n-1];
    params[ids[0]]=data.on;params[ids[1]]=data.freqHz;params[ids[2]]=data.gainDb;params[ids[3]]=data.q;
}
params[36]=eq.hpOn;params[37]=eq.hpHz;params[38]=eq.hpSlopeDb;
params[39]=eq.lpOn;params[40]=eq.lpHz;params[41]=eq.lpSlopeDb;
const auto frame=[this,player,part]{
    return player<0?ctrl_.engine.nativeAnalyzerFrame(part,eqAfter_):
        host::arrangerHost().styleAnalyzerFrame(player,part,eqAfter_);
};
const auto scope=[&](const RectF& plot){
    if(!eqAnalyzerOn_||audioSampleRate_<=0){stopEqTap();return;}
    if(eqTapPlayer_!=player||eqTapPart_!=part||eqTapSerial_!=selection){
        stopEqTap();clearEqSpectrum();eqTapPlayer_=player;eqTapPart_=part;eqTapSerial_=selection;
        (void)frame();
        eqTapReadyMs_=nowMs()+20+(8192000+audioSampleRate_-1)/audioSampleRate_;
    }
    if(nowMs()>=eqTapReadyMs_)drawEqSpectrum(c,plot,audioSampleRate_,eqPeak_,frame);
};
const auto bindPoint=[&](int b,const RectF& rect,const RectF& plot){
    int count=0;const auto ids=eqBandIds(b,count);
    const float startingHz=params[ids[1]],startingGain=b==0||b==6?0.0F:params[ids[2]];
    const auto drag=[this,snapshot,commit,b,plot,startingHz,startingGain,setFreq,setGain](float x,float y){
        if(toneDialPreview_!=100+b){
            toneEqBand_=b;toneDialPreview_=100+b;toneGestureOwner_=snapshot;
            eqGrabX_=x;toneDialGrabY_=y;dirty_=true;return;
        }
        if(!toneGestureOwner_)return;
        const float hz=std::round(std::clamp(startingHz*std::pow(1000.0F,(x-eqGrabX_)/plot.width()),
            b==0?10.0F:b==6?1000.0F:20.0F,b==0?2000.0F:20000.0F));
        const float gain=std::round(10*std::clamp(startingGain+(toneDialGrabY_-y)*36/plot.height(),-18.0F,18.0F))*.1F;
        const auto& live=toneGestureOwner_->part(homeTonePart_).eq;
        const float prev=b==0?live.hpHz:b==6?live.lpHz:live.band[b-1].freqHz;
        if(hz==prev&&(b==0||b==6||std::abs(live.band[b-1].gainDb-gain)<.0001F))return;
        if(!commit(toneGestureOwner_,[=](Part& dest,float){setFreq(dest,b,hz);if(b>0&&b<6)setGain(dest,b,gain);},0))
            toneGestureOwner_.reset();
    };
    hit(rect,{},drag,false,drag);
    static const char* names[]{"EQ HP","EQ LF","EQ Low Mid","EQ MF","EQ High Mid","EQ HF","EQ LP"};
    auto& control=hits_.back();
    control.resetTarget={ResetSurface::HomeTone,player,part,names[b],selection,0,player<0?snapshot:nullptr};
    control.reset=[=]{apply([=](Part& dest,float){if(b==0||b==6)setFreq(dest,b,b==0?40.0F:18000.0F);else setGain(dest,b,0);},0);};
};
drawSamplerEqGraph(c,{28,308,1259,601},params,band,scope,bindPoint);
const auto toggleEq=[&](RectF r,const std::string& title,bool on,const Write& write){
    editButton(r,title,on,[=]{apply(write,on?0:1);});
};
toggleEq({1274,308,1435,375},"EQ On",eq.on,[](Part& p,float v){p.eq.on=v!=0;});
toggleEq({1446,308,1612,375},"Band On",bandOn,[=](Part& p,float v){
    if(band==0)p.eq.hpOn=v!=0;else if(band==6)p.eq.lpOn=v!=0;else p.eq.band[band-1].on=v!=0;
});
editButton({1274,387,1612,451},"Analyzer",eqAnalyzerOn_,[this]{eqAnalyzerOn_=!eqAnalyzerOn_;if(!eqAnalyzerOn_)stopEqTap();dirty_=true;});
editButton({1274,463,1454,526},eqAfter_?"After EQ":"Before EQ",false,[this]{stopEqTap();eqAfter_=!eqAfter_;dirty_=true;});
editButton({1465,463,1612,526},"Peak",eqPeak_,[this]{eqPeak_=!eqPeak_;clearEqSpectrum();dirty_=true;});
editButton({1274,538,1612,601},"Flat EQ",false,[apply,setGain]{
    apply([=](Part& p,float){for(int n=1;n<=5;++n)setGain(p,n,0);p.eq.hpOn=false;p.eq.lpOn=false;},0);
});
const char* names[]{"HP","1 · LF","2 · Low Mid","3 · Mid","4 · High Mid","5 · HF","LP"};
for(int n=0;n<7;++n){
    const float x=28+n*227;
    editButton({x,612,x+220,671},names[n],band==n,[this,n]{toneEqBand_=n;eqNumberField_=-1;dirty_=true;});
}
enum {Frequency,Gain,Q};
const auto slider=[&](int field,float x,const char* title,const char* unit,float value,float lo,float hi,
                       int digits,float initial,const Write& write){
    const bool log=field!=Gain;
    const auto normalized=[=](float v){return log?std::log(v/lo)/std::log(hi/lo):(v-lo)/(hi-lo);};
    const auto snap=[=](float v){const float m=digits==2?100.0F:digits==1?10.0F:1.0F;return std::clamp(std::round(v*m)/m,lo,hi);};
    const RectF tile{x,681,x+521,813};
    box(c,tile,liveCard,liveLine,6);
    label(c,title,x+12,719,21,liveText,true,92);
    editButton({x+100,686,x+330,735},fmtFixed(value,digits)+" "+unit,false,[this,value,digits,field,snapshot]{
        eqNumberField_=field;eqNumber_=fmtFixed(value,digits);eqNumberFresh_=true;eqNumberOwner_=snapshot;dirty_=true;
    });
    const auto step=[=](int dir){
        const float v=field==Frequency?value*(dir>0?1.02F:1/1.02F):field==Q?value*(dir>0?1.05F:1/1.05F):value+dir*.5F;
        float next=snap(v);
        if(next==value)next=snap(value+dir*(digits==2?.01F:digits==1?.1F:1.0F));
        apply(write,next);
    };
    editButton({x+339,686,x+423,735},"−",false,[step]{step(-1);});
    editButton({x+432,686,x+514,735},"+",false,[step]{step(1);});
    const auto track=RectF{x+24,746,x+497,808};const float cy=track.centerY();
    const float marker=track.left+std::clamp(normalized(value),0.0F,1.0F)*track.width();
    box(c,{track.left,cy-3,track.right,cy+3},liveLine);
    box(c,{track.left,cy-3,marker,cy+3},liveMint);
    Paint dot;dot.color=liveText;c.drawCircle(marker,cy,15,dot);
    const auto move=[=](float px,float){
        if(toneDialPreview_!=200+field){
            toneDialPreview_=200+field;toneGestureOwner_=snapshot;eqGrabX_=px;toneGestureLast_=value;return;
        }
        if(!toneGestureOwner_)return;
        const float n=std::clamp(normalized(value)+(px-eqGrabX_)/track.width(),0.0F,1.0F);
        const float next=snap(log?lo*std::pow(hi/lo,n):lo+n*(hi-lo));
        if(std::abs(next-toneGestureLast_)<.0001F)return;
        if(!commit(toneGestureOwner_,write,next))toneGestureOwner_.reset();
        toneGestureLast_=next;
    };
    hit(track,{},move,false,move);
    auto& ctl=hits_.back();
    ctl.resetTarget={ResetSurface::HomeTone,player,part*8+band,title,selection,0,player<0?snapshot:nullptr};
    ctl.reset=[apply,write,initial]{apply(write,initial);};
};
const auto writeHz=[=](Part& p,float v){setFreq(p,band,v);};
const auto writeGain=[=](Part& p,float v){setGain(p,band,v);};
const auto writeQ=[=](Part& p,float v){p.eq.band[band-1].q=v;};
const auto eqDefaults=sampler::UpperEq{};
slider(Frequency,28,"Freq","Hz",freq,minHz,maxHz,0,hp?eqDefaults.hpHz:band==6?eqDefaults.lpHz:eqDefaults.band[band-1].freqHz,writeHz);
if(pass){
    for(int i=0;i<2;++i){
        const int db=i?24:12;const float x=559+i*267;
        editButton({x,703,x+254,791},std::to_string(db)+" dB/oct",slope==db,[=]{apply([hp](Part& p,float v){
            (hp?p.eq.hpSlopeDb:p.eq.lpSlopeDb)=static_cast<std::uint8_t>(v);},db);});
    }
}else{
    slider(Gain,559,"Gain","dB",peakBand.gainDb,-18,18,1,0,writeGain);
    if(band>1&&band<5)slider(Q,1090,"Q","",peakBand.q,.1F,10,2,eqDefaults.band[band-1].q,writeQ);
    else label(c,band==1?"Low Shelf":"High Shelf",1351,762,27,liveDim,true,490,Align::Center);
}
if(eqNumberField_>=0){
    if(eqNumberOwner_.lock()!=snapshot){eqNumberField_=-1;dirty_=true;return;}
    hits_.resize(beforeEqHits);box(c,body,liveBg,liveLine,7);hit(body,[]{});
    const int field=eqNumberField_;
    const float lo=field==Frequency?minHz:field==Gain?-18.0F:.1F,hi=field==Frequency?maxHz:field==Gain?18.0F:10.0F;
    const int digits=field==Frequency?0:field==Gain?1:2;
    const std::string title=field==Frequency?"Frequency · Hz":field==Gain?"Gain · dB":"Q";
    label(c,title,60,374,31,liveText,true,555);
    label(c,eqNumber_,60,457,45,liveMint,true,570);
    label(c,fmtFixed(lo,digits)+" … "+fmtFixed(hi,digits),60,512,23,liveDim,false,560);
    static const char* keys[]{"7","8","9","4","5","6","1","2","3","±","0","."};
    for(int n=0;n<12;++n){
        if((n==9&&lo>=0)||(n==11&&!digits))continue;
        const float x=656+n%3*183,y=321+n/3*117;
        editButton({x,y,x+168,y+102},keys[n],false,[this,n,digits]{
            if(n==9){
                if(eqNumber_.empty()||eqNumber_.front()!='-')eqNumber_.insert(0,"-");else eqNumber_.erase(0,1);
            }else{
                if(eqNumberFresh_)eqNumber_.clear();
                if(n==11){if(eqNumber_.find('.')==std::string::npos){if(eqNumber_.empty()||eqNumber_=="-")eqNumber_+="0";eqNumber_+=".";}}
                else if(eqNumber_.size()<9){
                    const auto pos=eqNumber_.find('.');
                    if(pos==std::string::npos||eqNumber_.size()-pos-1<static_cast<unsigned>(digits))eqNumber_+=keys[n];
                }
            }
            eqNumberFresh_=false;dirty_=true;
        });
    }
    editButton({1224,321,1583,423},"⌫",false,[this]{if(!eqNumber_.empty())eqNumber_.pop_back();eqNumberFresh_=false;dirty_=true;});
    editButton({1224,438,1583,540},"Cancel",false,[this]{eqNumberField_=-1;dirty_=true;});
    char* end=nullptr;const float v=std::strtof(eqNumber_.c_str(),&end);
    const bool valid=end!=eqNumber_.c_str()&&*end=='\0'&&std::isfinite(v)&&v>=lo&&v<=hi;
    button(c,{1224,672,1583,774},"OK",liveMint,true,valid,[=]{
        Owner owner=snapshot;const Write write=field==Frequency?Write(writeHz):field==Gain?Write(writeGain):Write(writeQ);
        if(commit(owner,write,v))eqNumberField_=-1;dirty_=true;
    },25);
}
