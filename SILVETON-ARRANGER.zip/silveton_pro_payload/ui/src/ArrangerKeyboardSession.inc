// Included inside silveton::ui by ArrangerView.cpp. SetPackage.h is included
// by the owning translation unit. This is app-private performance metadata;
// every waveform and Program remains in its original prepared SET/bank.
namespace {
constexpr long long kKeyboardMetadataMaximumBytes=4LL*1024LL*1024LL;
constexpr std::size_t kKeyboardMetadataMaximumPath=65536U;

struct StoredKeyboardBinding {
    int msb{-1},lsb{-1},program{-1};
    std::string sourcePath;
};
struct StoredKeyboardSource {
    bool expected{false};
    int slot{0};
    std::string name,bankIdentity;
};
struct StoredKeyboardMetadata {
    std::string sourcePath;
    std::array<StoredKeyboardBinding,7> bindings{};
    std::array<int,7> rangeLow{{0,0,0,0,0,0,0}},rangeHigh{{127,127,127,127,127,127,127}};
    bool rangesDeclared{false};
    std::array<bool,7> splitSuppressed{};
    bool splitDeclared{false},splitEnabled{true},lowerMuteBeforeFull{false},useGlobalSplit{true};
    int splitPoint{-1},chordScanArea{-1},bassInversion{-1};
    std::array<std::array<StoredKeyboardSource,sampler::kUpperLayers+1>,sampler::kPartCount> sources{};
};
bool keyboardAddressComplete(const StoredKeyboardBinding& value) {
    return value.msb>=0&&value.msb<=127&&value.lsb>=0&&value.lsb<=127&&value.program>=0&&value.program<=127;
}
bool keyboardAddressAbsent(const StoredKeyboardBinding& value) {
    return value.msb==-1&&value.lsb==-1&&value.program==-1&&value.sourcePath.empty();
}
bool readStoredKeyboardMetadata(const std::string& text,StoredKeyboardMetadata& result) {
    if(text.size()>1024U*1024U)return false;
    std::istringstream input(text);std::string magic,tag;int version=0;
    if(!(input>>magic>>version)||magic!="SILVETON_KEYBOARD_PERFORMANCE"||version<1||version>5)return false;
    bool pathSeen=false,ended=false;
    std::array<bool,7> bindingsSeen{},rangesSeen{};
    std::array<std::array<bool,sampler::kUpperLayers+1>,sampler::kPartCount> sourcesSeen{};
    while(input>>tag){
        if(tag=="PATH"){
            if(pathSeen||!(input>>std::quoted(result.sourcePath))||result.sourcePath.size()>kKeyboardMetadataMaximumPath)return false;
            pathSeen=true;
        }else if(tag=="KORG"){
            int part=0;StoredKeyboardBinding value;
            if(!(input>>part>>value.msb>>value.lsb>>value.program>>std::quoted(value.sourcePath))||part<0||part>=7||
               bindingsSeen[static_cast<std::size_t>(part)]||value.sourcePath.size()>kKeyboardMetadataMaximumPath||
               (!keyboardAddressAbsent(value)&&(!keyboardAddressComplete(value)||value.sourcePath.empty())))return false;
            bindingsSeen[static_cast<std::size_t>(part)]=true;result.bindings[static_cast<std::size_t>(part)]=std::move(value);
        }else if(tag=="SPLIT"){
            int enabled=1,lowerMute=0;
            if(result.splitDeclared||!(input>>enabled>>lowerMute)||(enabled!=0&&enabled!=1)||(lowerMute!=0&&lowerMute!=1))return false;
            result.splitDeclared=true;result.splitEnabled=enabled!=0;result.lowerMuteBeforeFull=lowerMute!=0;
            if(version>=3&&(!(input>>result.splitPoint)||result.splitPoint<1||result.splitPoint>127))return false;
            if(version>=4){int global=0;if(!(input>>global)||(global!=0&&global!=1))return false;result.useGlobalSplit=global!=0;}
            else result.useGlobalSplit=false;
        }else if(tag=="CHORD_SCAN"){
            if(version<4||result.chordScanArea>=0||!(input>>result.chordScanArea)||result.chordScanArea<0||result.chordScanArea>3)return false;
        }else if(tag=="BASS_INVERSION"){
            if(version<5||result.bassInversion>=0||!(input>>result.bassInversion)||result.bassInversion<0||result.bassInversion>1)return false;
        }else if(tag=="RANGE"){
            int part=0,low=0,high=127,suppressed=0;
            if(!(input>>part>>low>>high)||(version>=2&&!(input>>suppressed))||part<0||part>=7||low<0||high>127||low>high||
               (suppressed!=0&&suppressed!=1)||rangesSeen[static_cast<std::size_t>(part)])return false;
            rangesSeen[static_cast<std::size_t>(part)]=true;result.rangeLow[static_cast<std::size_t>(part)]=low;result.rangeHigh[static_cast<std::size_t>(part)]=high;
            result.splitSuppressed[static_cast<std::size_t>(part)]=suppressed!=0;
        }else if(tag=="SOURCE"){
            int part=0,source=0,expected=0;StoredKeyboardSource value;
            if(!(input>>part>>source>>expected>>value.slot>>std::quoted(value.name))||part<0||part>=sampler::kPartCount||
               source<0||source>sampler::kUpperLayers||(expected!=0&&expected!=1)||value.slot<0||value.slot>500||
               value.name.size()>kKeyboardMetadataMaximumPath||sourcesSeen[static_cast<std::size_t>(part)][static_cast<std::size_t>(source)])return false;
            if(version>=3&&(!(input>>std::quoted(value.bankIdentity))||value.bankIdentity.size()>kKeyboardMetadataMaximumPath))return false;
            value.expected=expected!=0;sourcesSeen[static_cast<std::size_t>(part)][static_cast<std::size_t>(source)]=true;
            result.sources[static_cast<std::size_t>(part)][static_cast<std::size_t>(source)]=std::move(value);
        }else if(tag=="END"){ended=true;break;}
        else return false;
    }
    input>>std::ws;if(!pathSeen||!ended||!input.eof())return false;
    for(const bool seen:bindingsSeen)if(!seen)return false;
    const auto rangeCount=std::count(rangesSeen.begin(),rangesSeen.end(),true);
    if(rangeCount!=0&&rangeCount!=7)return false;
    result.rangesDeclared=rangeCount==7;
    for(const auto& part:sourcesSeen)for(const bool seen:part)if(!seen)return false;
    return true;
}
bool keyboardMetadataFileNameValid(const std::string& name) {
    if(name.empty())return true; // Private initial-format fallback, never a path.
    const std::string prefix="ARRANGER_KEYBOARD_",suffix=".SVSET";
    if(name.size()>128U||!startsWith(name,prefix)||!endsWith(name,suffix)||name.size()<=prefix.size()+suffix.size())return false;
    for(std::size_t i=prefix.size();i<name.size()-suffix.size();++i){
        const auto ch=static_cast<unsigned char>(name[i]);
        if(ch!='_'&&!std::isxdigit(ch))return false;
    }
    return true;
}
std::string keyboardPerformancePath(const std::string& sessionPath,const std::string& metadataFile) {
    if(sessionPath.empty()||!keyboardMetadataFileNameValid(metadataFile))return {};
    return files::join(files::parentOf(sessionPath),metadataFile.empty()?"ARRANGER_KEYBOARD.SVSET":metadataFile);
}
std::uint64_t keyboardMetadataHash(const std::string& bytes) {
    std::uint64_t value=14695981039346656037ULL;
    for(const auto ch:bytes){value^=static_cast<unsigned char>(ch);value*=1099511628211ULL;}
    return value;
}
std::string keyboardSamplerBankIdentity(const std::string& bank) {
    if(bank.empty()||!files::exists(bank))return {};
    auto metadata=bank;if(files::isDirectory(bank))metadata=files::join(bank,"manifest.svs");
    const auto size=files::fileSize(metadata),time=files::lastModifiedMs(metadata);
    if(size<0||time<=0)return {};
    std::ostringstream out;out<<std::quoted(files::absolute(bank))<<' '<<std::quoted(files::absolute(metadata))<<' '<<size<<' '<<time;
    return out.str();
}
bool loadKeyboardMetadataPackage(const std::string& path,sampler::SetLoadResult& loaded,StoredKeyboardMetadata& metadata,std::string& error) {
    const auto bytes=files::fileSize(path);
    if(bytes<0){error="Saved keyboard performance is unavailable";return false;}
    if(files::isDirectory(path)||bytes<=0||bytes>kKeyboardMetadataMaximumBytes){error="Saved keyboard performance metadata has an invalid size";return false;}
    loaded=sampler::SetPackage::load(path);
    if(!loaded.ok()){error="Saved keyboard performance could not be read: "+loaded.error;return false;}
    if(!loaded.data.performance||!loaded.data.samples.empty()||!loaded.data.multisamples.empty()||!loaded.data.programs.empty()||
       !loaded.data.combis.empty()||!loaded.data.lists.empty()||!readStoredKeyboardMetadata(loaded.data.extra,metadata)){
        error="Saved keyboard performance is not valid reference-only metadata";return false;
    }
    if(!metadata.rangesDeclared)for(std::size_t index=0;index<metadata.rangeLow.size();++index){
        const auto& part=loaded.data.performance->combi.part(static_cast<int>(index));
        metadata.rangeLow[index]=part.keyLow;metadata.rangeHigh[index]=part.keyHigh;
    }
    return true;
}
std::string keyboardContainingSetRoot(const std::string& sourcePath) {
    if(sourcePath.empty())return {};
    // New bindings store the exact SET root. For an older path to an individual
    // resource, only walk directory names; never scan or decode the SET here.
    if(files::isDirectory(sourcePath))return sourcePath;
    std::string current=files::parentOf(sourcePath);
    for(unsigned depth=0;!current.empty()&&depth<32U;++depth){
        auto base=files::nameOf(current);
        std::transform(base.begin(),base.end(),base.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});
        if(endsWith(base,".kst")||endsWith(base,".set"))return current;
        const auto parent=files::parentOf(current);if(parent==current)break;current=parent;
    }
    return {};
}
} // namespace

bool ArrangerView::saveKeyboardPerformanceMetadata(bool force){
    keyboardMetadataError_.clear();
    // Plain COMBIs also need the performance SPLIT/Lower/range metadata:
    // runtime caps are deliberately absent from the generic bank serializer.
    if(!ctrl_.engine.nativeKeyboardCombi()){
        if(force){keyboardMetadataError_="No keyboard performance is available to save";return false;}
        return true;
    }
    auto state=captureKeyboardWorkingSet();
    if(!writeKeyboardWorkingMetadata(state,keyboardMetadataError_))return false;
    keyboardMetadataFile_=state.metadataFile;keyboardSoundBindings_=state.recall.bindings;
    keyboardMetadataSavedState_=state.combi;keyboardMetadataSavedBindings_=state.metadataBindings;
    return true;
}
bool ArrangerView::writeKeyboardWorkingMetadata(KeyboardWorkingSet& state,std::string& error){
    error.clear();
    const auto path=keyboardPerformancePath(persistentSessionPath_,state.metadataFile);
    if(path.empty()){error="Keyboard performance storage is not configured";return false;}
    const auto current=state.combi;
    if(!current){error="No keyboard performance is available to save";return false;}
    if(state.sourcePath.size()>kKeyboardMetadataMaximumPath){error="The Keyboard Set source path is too long";return false;}
    auto normalizedBindings=state.recall.bindings;
    for(std::size_t index=0;index<normalizedBindings.size();++index){
        auto& binding=normalizedBindings[index];const auto& source=current->part(static_cast<int>(index));
        if(binding.msb<0)continue;
        if(!source.program&&source.name.empty()){binding=KeyboardSoundBinding{};continue;}
        if(!source.program)continue;
        const auto original=host::arrangerHost().preparedKeyboardSound(binding.msb,binding.lsb,binding.program,binding.sourcePath);
        const auto bank=source.soundSlotId>0?host::resolveArrangerBankSound(static_cast<int>(source.soundSlotId)):sampler::ProgramPtr{};
        if(original&&original.get()==source.program.get())continue;
        if(bank&&bank.get()==source.program.get())binding=KeyboardSoundBinding{};
        else{
            error="A Keyboard Set Sound no longer matches a prepared original Sound or an exact bank Sound; load its source SET before saving";return false;
        }
    }
    std::ostringstream text;text<<"SILVETON_KEYBOARD_PERFORMANCE 5\nPATH "<<std::quoted(state.sourcePath)<<'\n';
    for(std::size_t index=0;index<normalizedBindings.size();++index){
        const auto& binding=normalizedBindings[index];
        StoredKeyboardBinding value{binding.msb,binding.lsb,binding.program,binding.sourcePath};
        if(!keyboardAddressAbsent(value)&&(!keyboardAddressComplete(value)||value.sourcePath.empty())){
            error="A keyboard part has an incomplete original Sound reference";return false;
        }
        if(value.sourcePath.size()>kKeyboardMetadataMaximumPath){error="A keyboard source path is too long";return false;}
        text<<"KORG "<<index<<' '<<value.msb<<' '<<value.lsb<<' '<<value.program<<' '<<std::quoted(value.sourcePath)<<'\n';
    }
    text<<"SPLIT "<<state.recall.splitEnabled<<' '<<state.recall.lowerMuteBeforeFull<<' '<<std::clamp(state.recall.splitPoint,1,127)<<' '<<state.recall.useGlobalSplit<<'\n';
    if(state.recall.chordScanArea>=0)text<<"CHORD_SCAN "<<std::clamp(state.recall.chordScanArea,0,3)<<'\n';
    if(state.recall.bassInversion< -1||state.recall.bassInversion>1){error="The saved Bass Inversion setting is invalid";return false;}
    if(state.recall.bassInversion>=0){
        text<<"BASS_INVERSION "<<state.recall.bassInversion<<'\n';
    }
    for(std::size_t index=0;index<state.recall.low.size();++index){
        const int low=state.recall.low[index],high=state.recall.high[index];
        if(low<0||high>127||low>high){error="A keyboard part has an invalid saved key range";return false;}
        text<<"RANGE "<<index<<' '<<low<<' '<<high<<' '<<state.recall.suppressed[index]<<'\n';
    }
    StoredKeyboardMetadata previousMetadata;
    const bool havePreviousMetadata=readStoredKeyboardMetadata(state.metadataBindings,previousMetadata)&&previousMetadata.sourcePath==state.sourcePath;
    auto copy=*current;
    for(int part=0;part<sampler::kPartCount;++part){
        auto& upper=copy.part(part);
        for(int source=0;source<=sampler::kUpperLayers;++source){
            auto& assignment=sampler::soundSource(upper,source);
            const int slot=static_cast<int>(assignment.soundSlotId);
            auto name=assignment.program?assignment.program->name:assignment.name;
            bool expected=assignment.program!=nullptr||(slot>0&&!name.empty());
            std::string bankIdentity;
            const bool original=source==0&&part<7&&normalizedBindings[static_cast<std::size_t>(part)].msb>=0;
            if(!assignment.program&&havePreviousMetadata){
                const auto& previous=previousMetadata.sources[static_cast<std::size_t>(part)][static_cast<std::size_t>(source)];
                bool sameReference=slot>0&&slot==previous.slot;
                if(original){
                    const auto& binding=normalizedBindings[static_cast<std::size_t>(part)];
                    const auto& oldBinding=previousMetadata.bindings[static_cast<std::size_t>(part)];
                    sameReference=binding.msb==oldBinding.msb&&binding.lsb==oldBinding.lsb&&binding.program==oldBinding.program&&binding.sourcePath==oldBinding.sourcePath;
                }
                if(sameReference&&previous.expected){expected=true;name=previous.name;bankIdentity=previous.bankIdentity;}
            }
            if(expected&&!original&&(slot<1||slot>500||name.empty())){
                error="Keyboard part "+std::to_string(part+1)+" contains a Sound without a recoverable original address or saved bank slot";return false;
            }
            if(name.size()>kKeyboardMetadataMaximumPath){error="A keyboard Sound name is too long";return false;}
            if(expected&&!original){
                if(assignment.program)bankIdentity=keyboardSamplerBankIdentity(ctrl_.currentBankFile());
                if(bankIdentity.empty()){
                    error="A non-Korg Sound has no verified saved sampler-bank revision; save its bank before saving this performance";return false;
                }
            }
            text<<"SOURCE "<<part<<' '<<source<<' '<<expected<<' '<<slot<<' '<<std::quoted(name)<<' '<<std::quoted(bankIdentity)<<'\n';
            assignment.program.reset();
            if(!assignment.engine.chosen())assignment.soloModel.reset();
        }
    }
    text<<"END\n";const auto bindings=text.str();
    if(bindings.size()>1024U*1024U){error="Keyboard performance references are too large";return false;}
    if(keyboardMetadataSavedState_.get()==current.get()&&state.metadataBindings==bindings&&files::exists(path))return true;
    sampler::SetData data;data.name="ARRANGER keyboard performance metadata";data.extra=bindings;
    sampler::PerformanceSnapshot performance;performance.combi=std::move(copy);data.performance=std::move(performance);
    // Models that belong to configured SOLO sources are part of that sound,
    // not sample PCM. Keep those models in SetPackage's existing SVSM/SVSS
    // blocks; clear only unused model cache references above. Reject oversized
    // model data before creating the unreferenced staging file.
    std::size_t modelBytes=0U;
    for(int part=0;part<sampler::kPartCount;++part){
        const auto& upper=data.performance->combi.part(part);
        for(int source=0;source<=sampler::kUpperLayers;++source){
            const auto& assignment=sampler::soundSource(upper,source);
            if(assignment.soloModel){
                modelBytes+=sampler::solo::encodeModel(*assignment.soloModel).size();
                if(modelBytes>static_cast<std::size_t>(kKeyboardMetadataMaximumBytes)){
                    error="The configured keyboard models exceed the performance metadata size limit";return false;
                }
            }
        }
    }
    const auto parent=files::parentOf(persistentSessionPath_);
    const auto staged=files::join(parent,"ARRANGER_KEYBOARD_BUILD.SVSET");
    const auto saved=sampler::SetPackage::save(staged,data);
    if(!saved.success){error="Keyboard performance was not saved: "+saved.error;return false;}
    const auto bytes=files::fileSize(staged);std::string content;
    if(bytes<=0||bytes>kKeyboardMetadataMaximumBytes||!files::readText(staged,content)||
       content.size()!=static_cast<std::size_t>(bytes)){
        (void)files::removeRecursively(staged);error="Keyboard performance metadata exceeds the size limit or could not be read";return false;
    }
    std::ostringstream hash;hash<<std::hex<<std::setfill('0')<<std::setw(16)<<keyboardMetadataHash(content);
    std::string committedName;
    for(unsigned collision=0;collision<1000U;++collision){
        const auto name="ARRANGER_KEYBOARD_"+hash.str()+(collision==0U?std::string{}:"_"+std::to_string(collision))+".SVSET";
        const auto destination=files::join(parent,name);
        if(files::exists(destination)){
            std::string previous;
            if(files::fileSize(destination)==bytes&&files::readText(destination,previous)&&previous==content){
                (void)files::removeRecursively(staged);committedName=name;break;
            }
            continue; // Hash collision: never overwrite an earlier revision.
        }
        if(std::rename(staged.c_str(),destination.c_str())==0){committedName=name;break;}
        (void)files::removeRecursively(staged);error="Keyboard performance revision could not be committed";return false;
    }
    if(committedName.empty()){
        (void)files::removeRecursively(staged);error="Keyboard performance revision name could not be allocated";return false;
    }
    state.metadataFile=std::move(committedName);
    state.recall.bindings=std::move(normalizedBindings);
    state.metadataBindings=bindings;return true;
}

bool ArrangerView::restoreKeyboardPerformanceMetadata(){
    keyboardMetadataError_.clear();
    bool native=keyboardMetadataRestorePending_||!activeNativeKeyboardSetPath_.empty()||!activeSavedKeyboardEntryPath_.empty();
    for(const auto& binding:keyboardSoundBindings_)native=native||binding.msb>=0;
    if(!native)return true; // Legacy/SILVETON sessions must not recall a stale native snapshot.
    const auto path=keyboardPerformancePath(persistentSessionPath_,keyboardMetadataFile_);
    sampler::SetLoadResult loaded;StoredKeyboardMetadata metadata;
    if(path.empty()||!loadKeyboardMetadataPackage(path,loaded,metadata,keyboardMetadataError_))return false;
    if(!activeNativeKeyboardSetPath_.empty()&&activeNativeKeyboardSetPath_!=metadata.sourcePath){
        keyboardMetadataError_="The saved keyboard performance belongs to a different Keyboard Set";return false;
    }
    auto combi=loaded.data.performance->combi;
    std::size_t expectedCount=0,readyCount=0,missingCount=0;
    for(int part=0;part<sampler::kPartCount;++part){
        auto& upper=combi.part(part);
        for(int source=0;source<=sampler::kUpperLayers;++source){
            auto& assignment=sampler::soundSource(upper,source);
            const auto& saved=metadata.sources[static_cast<std::size_t>(part)][static_cast<std::size_t>(source)];
            assignment.program.reset();
            if(!assignment.engine.chosen())assignment.soloModel.reset();
            if(static_cast<int>(assignment.soundSlotId)!=saved.slot){keyboardMetadataError_="Saved keyboard Sound reference does not match its performance metadata";return false;}
            const bool original=source==0&&part<7&&keyboardAddressComplete(metadata.bindings[static_cast<std::size_t>(part)]);
            if(saved.expected)++expectedCount;
            if(original){
                const auto& binding=metadata.bindings[static_cast<std::size_t>(part)];
                assignment.program=host::arrangerHost().preparedKeyboardSound(binding.msb,binding.lsb,binding.program,binding.sourcePath);
            }else if(saved.expected){
                if(saved.slot<1||saved.slot>500||saved.name.empty()){
                    keyboardMetadataError_="Saved keyboard Sound cannot be resolved to an original address or bank slot";return false;
                }
                const auto bankIdentity=keyboardSamplerBankIdentity(ctrl_.currentBankFile());
                if(!saved.bankIdentity.empty()&&saved.bankIdentity==bankIdentity){
                    const auto candidate=host::resolveArrangerBankSound(saved.slot);
                    if(candidate&&candidate->name==saved.name)assignment.program=candidate;
                }
            }
            if(assignment.program||assignment.engine.chosen())++readyCount;
            else if(saved.expected){
                ++missingCount;
                // Preserve the expected program identity and controls. The
                // missing assignment is silent, never a substituted patch.
                if(!assignment.soloModel)assignment.engine.type=sampler::EngineType::Off;
                // The missing source itself is silent. Keep the part/layer's
                // enabled setting so available companion sources still play.
            }
        }
    }
    if(expectedCount>0U&&readyCount==0U){keyboardMetadataError_="No saved keyboard Sounds are available in the prepared SET/bank; current keyboard performance was kept";return false;}
    // Keyboard performance caps are runtime-only. Reconstruct them from the
    // saved SPLIT intent while retaining each source/layer's own key/velocity range.
    const bool splitEnabled=metadata.splitDeclared?metadata.splitEnabled:keyboardSplitEnabled_;
    const int effectiveSplit=metadata.useGlobalSplit?host::arrangerHost().globalSplit():
        metadata.splitPoint>=1?metadata.splitPoint:host::arrangerHost().snapshot(selectedPlayer_).split;
    for(int part=0;part<7;++part){auto& upper=combi.part(part);const auto i=static_cast<std::size_t>(part);
        if(metadata.rangesDeclared){upper.keyLow=static_cast<std::uint8_t>(metadata.rangeLow[i]);upper.keyHigh=static_cast<std::uint8_t>(metadata.rangeHigh[i]);}
        upper.performanceKeyLow=static_cast<std::uint8_t>(splitEnabled&&part!=6?effectiveSplit+1:0);
        upper.performanceKeyHigh=static_cast<std::uint8_t>(splitEnabled&&part==6?effectiveSplit:127);
        if(metadata.splitSuppressed[i])upper.enabled=true;
    }
    combi.part(6).mute=splitEnabled?(metadata.splitDeclared?metadata.lowerMuteBeforeFull:keyboardLowerMuteBeforeFull_):true;
    const auto previousKeyboard=ctrl_.engine.nativeKeyboardCombi();
    if(!ctrl_.engine.nativeApplyKeyboardCombi(combi)){
        keyboardMetadataError_=ctrl_.engine.nativeLastTextError();if(keyboardMetadataError_.empty())keyboardMetadataError_="Saved keyboard performance could not be applied";return false;
    }
    if(!postKeyboardRecall(effectiveSplit,splitEnabled,metadata.chordScanArea,metadata.bassInversion)){
        if(previousKeyboard)(void)ctrl_.engine.nativeApplyKeyboardCombi(*previousKeyboard,true);
        keyboardMetadataError_=host::arrangerHost().lastError();return false;
    }
    scaleMainRemembered_=false;activeNativeKeyboardSetPath_=std::move(metadata.sourcePath);
    for(std::size_t index=0;index<keyboardSoundBindings_.size();++index){
        const auto& saved=metadata.bindings[index];auto& binding=keyboardSoundBindings_[index];
        binding.msb=saved.msb;binding.lsb=saved.lsb;binding.program=saved.program;binding.sourcePath=saved.sourcePath;
    }
    keyboardRangeLow_=metadata.rangeLow;keyboardRangeHigh_=metadata.rangeHigh;keyboardSplitSuppressed_.fill(false);
    if(!metadata.rangesDeclared)for(int part=0;part<7;++part){keyboardRangeLow_[part]=combi.part(part).keyLow;keyboardRangeHigh_[part]=combi.part(part).keyHigh;}
    if(metadata.splitDeclared){keyboardSplitEnabled_=metadata.splitEnabled;keyboardLowerMuteBeforeFull_=metadata.lowerMuteBeforeFull;keyboardUseGlobalSplit_=metadata.useGlobalSplit;}
    for(std::size_t index=0;index<keyboardSoundBindings_.size();++index){
        const auto& binding=keyboardSoundBindings_[index];
        if(binding.msb>=0&&combi.part(static_cast<int>(index)).program){
            (void)host::arrangerHost().retainPreparedKeyboardSound(static_cast<int>(index),binding.msb,binding.lsb,binding.program,binding.sourcePath);
        }else (void)host::arrangerHost().retainPreparedKeyboardSound(static_cast<int>(index),-1,-1,-1);
    }
    keyboardMetadataSavedState_=ctrl_.engine.nativeKeyboardCombi();keyboardMetadataSavedBindings_=loaded.data.extra;
    keyboardFxOverride_={};keyboardFxWarning_.clear();
    if(!activeNativeKeyboardSetPath_.empty()){
        host::ArrangerKeyboardSet source;
        if(host::arrangerHost().prepareKeyboardSet(activeNativeKeyboardSetPath_,source,combi.part(0).midiChannel,keyboardSplitEnabled_)&&source.read){
            auto processingOnly=source.combi;
            (void)prepareKeyboardFxOverride(activeNativeKeyboardSetPath_,*source.read,processingOnly,keyboardFxOverride_,keyboardFxWarning_);
        }
    }
    if(missingCount>0U)keyboardMetadataError_=std::to_string(missingCount)+" saved keyboard Sound assignments are unavailable and remain silent";
    return true;
}

std::vector<std::string> ArrangerView::keyboardPerformanceSetRoots() const{
    std::vector<std::string> roots;
    const auto add=[&roots](const std::string& source){
        const auto root=keyboardContainingSetRoot(source);
        if(!root.empty()&&std::find(roots.begin(),roots.end(),root)==roots.end())roots.push_back(root);
    };
    for(const auto& binding:keyboardSoundBindings_)if(binding.msb>=0)add(binding.sourcePath);
    // During startup, caller has restored the selected native Keyboard Set
    // intent, while the per-part source references still reside in this file.
    if(keyboardMetadataRestorePending_||!activeNativeKeyboardSetPath_.empty()){
        sampler::SetLoadResult loaded;StoredKeyboardMetadata metadata;std::string error;
        if(loadKeyboardMetadataPackage(keyboardPerformancePath(persistentSessionPath_,keyboardMetadataFile_),loaded,metadata,error)&&
           (activeNativeKeyboardSetPath_.empty()||metadata.sourcePath==activeNativeKeyboardSetPath_)){
            for(const auto& binding:metadata.bindings)if(keyboardAddressComplete(binding))add(binding.sourcePath);
        }
        if(roots.empty())add(activeNativeKeyboardSetPath_);
    }
    return roots;
}

// Per-original-Keyboard-Set SILVETON FX edits. These are not Korg FX decodes.
namespace {
constexpr long long kKeyboardFxSourceMaximumBytes=64LL*1024LL*1024LL;
std::array<float,4> keyboardFxSends(const sampler::UpperPart& part) {
    return {{part.fxSend1,part.fxSend2,part.fxSend3,part.fxSend4}};
}
void keyboardFxSetSend(sampler::UpperPart& part,std::size_t send,float value) {
    switch(send){case 0:part.fxSend1=value;break;case 1:part.fxSend2=value;break;
        case 2:part.fxSend3=value;break;case 3:part.fxSend4=value;break;default:break;}
}
std::string keyboardFxHex(std::uint64_t value) {
    std::ostringstream out;out<<std::hex<<std::setfill('0')<<std::setw(16)<<value;return out.str();
}
bool keyboardFxRevision(const std::string& path,const arranger::Pa5xKeyboardSetRead& read,
                         std::string& identity,std::string& error) {
    const auto embedded=path.find("!/");
    const auto physical=embedded==std::string::npos?path:path.substr(0,embedded);
    const auto size=files::fileSize(physical);std::string bytes;
    if(size<=0||size>kKeyboardFxSourceMaximumBytes||files::isDirectory(physical)||
       !files::readText(physical,bytes)||bytes.size()!=static_cast<std::size_t>(size)){
        error="Keyboard Set FX edits cannot be linked to a readable original resource revision";return false;
    }
    std::ostringstream out;out<<"SILVETON_KEYBOARD_FX_SOURCE 1\nPATH "<<std::quoted(files::absolute(path))
        <<"\nBYTES "<<size<<"\nREVISION "<<keyboardFxHex(keyboardMetadataHash(bytes))<<'\n';
    for(const auto& part:read.parts)out<<"PART "<<part.role<<' '<<part.present<<' '<<part.addressKnown<<' '
        <<part.msb<<' '<<part.lsb<<' '<<part.program<<' '<<std::quoted(part.soundPath)<<'\n';
    identity=out.str();return true;
}

}

bool ArrangerView::prepareKeyboardFxOverride(const std::string& path,const arranger::Pa5xKeyboardSetRead& read,
        sampler::Combi& combi,KeyboardFxOverrideState& state,std::string& fxIssue) {
    (void)combi;state={};fxIssue.clear();
    // Legacy source-overlay files remain intact, but source selection never
    // recalls unsaved global edits. Explicit saved resources own their FX.
    return keyboardFxRevision(path,read,state.identity,fxIssue);
}

void ArrangerView::captureKeyboardFxOverride(const sampler::Combi&,const sampler::Combi&) {
    // All processing edits belong to the current edit buffer and session.
}

bool ArrangerView::saveKeyboardFxOverride() {
    // Session autosave records the live Combi separately. Leaving a resource
    // must not publish edits into a Library/Style resource without Save.
    return true;
}

void ArrangerView::clearKeyboardFxOverride() {
    if(activeNativeKeyboardSetPath_.empty())return;
    host::ArrangerKeyboardSet source;const auto current=ctrl_.engine.nativeKeyboardCombi();if(!current)return;
    if(!host::arrangerHost().prepareKeyboardSet(activeNativeKeyboardSetPath_,source,current->part(0).midiChannel,keyboardSplitEnabled_,true)){
        showToast(host::arrangerHost().lastError(),6500);return;
    }
    if(!source.combi.sourceEffects){showToast("This Keyboard Set has no readable original FX profile",5000);return;}
    auto edited=*current;edited.fx=source.combi.fx;edited.fxRouting=source.combi.fxRouting;
    edited.sourceEffects=source.combi.sourceEffects;
    for(int part=0;part<sampler::kPartCount;++part){edited.insertOf(part)=source.combi.insertOf(part);
        const auto sends=keyboardFxSends(source.combi.part(part));for(std::size_t send=0;send<sends.size();++send)keyboardFxSetSend(edited.part(part),send,sends[send]);}
    if(!ctrl_.engine.nativeApplyKeyboardCombi(edited,true)){showToast(ctrl_.engine.nativeLastTextError(),6000);return;}
    fxChoosing_=false;keyboardSourceFxPage_=0;
    markPersistentStateChanged();refresh();dirty_=true;showToast(edited.sourceEffects->summary(),6500);
}
