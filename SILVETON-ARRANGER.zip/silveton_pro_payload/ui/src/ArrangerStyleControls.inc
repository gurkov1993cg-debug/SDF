// The Fill destination belongs to the active Style. Shared pages own the other controls.
void ArrangerView::drawStyleControls(Canvas& c){
    static constexpr const char* fills[]={"Fill 1","Fill 2","Fill 3","Fill 4","Break"};
    static constexpr const char* modes[]={"Off","1 & 2","1 & 3","1 & 4","2 & 3","2 & 4","3 & 4","Up","Down","Increase","Decrease","Variation 1","Variation 2","Variation 3","Variation 4"};
    const int player=selectedPlayer_;const auto& p=players_[player];const auto serial=p.styleSelectionSerial;
    const bool ready=p.loaded&&!p.styleSwitchPending;
    if(fillControlSlot_>=0&&(player!=fillControlPlayer_||serial!=fillControlSerial_||!ready))fillControlSlot_=-1;
    box(c,{0,0,800,480},bg);
    label(c,"STYLE CONTROLS",15,29,20,white,true,265);
    label(c,"Player "+std::to_string(player+1)+"   "+p.name,279,28,16,dim,false,414);
    button(c,{709,3,795,39},"‹ Back",orange,false,true,[this]{panelExit();},15);
    if(fillControlSlot_>=0){
        const int slot=fillControlSlot_;
        label(c,std::string(fills[slot])+"   /   Next Variation",14,74,20,orange,true,760);
        for(int i=0;i<15;++i){
            const float x=12+(i%3)*261.0F,y=93+(i/3)*71.0F;
            button(c,{x,y,x+251,y+62},modes[i],orange,p.fillModes[slot]==i,ready,[this,player,serial,slot,i]{
                if(host::arrangerHost().setFillMode(player,serial,slot,i)){fillControlSlot_=-1;markPersistentStateChanged(false);refresh(false);}
                else showToast(host::arrangerHost().lastError(),4000);
                dirty_=true;
            },18);
        }
        return;
    }
    label(c,"Fill Mode",16,72,21,orange,true,385);
    label(c,"After a manual Fill or Break",17,96,14,dim,false,421);
    for(int i=0;i<5;++i){
        const float y=108+i*64.0F;
        button(c,{13,y,787,y+56},std::string(fills[i])+"     ›     "+modes[std::clamp(p.fillModes[i],0,14)],orange,false,ready,[this,i,serial,player]{
            fillControlSlot_=i;fillControlPlayer_=player;fillControlSerial_=serial;dirty_=true;
        },17);
    }
    if(!p.loaded)label(c,"Select a Style on Home.",15,451,15,dim,false,765);
}
