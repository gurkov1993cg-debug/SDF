// Explicit User Keyboard Set entries point to immutable reference-only snapshots.
namespace {
std::string keyboardLibraryEntryName(int bank,int position) {
    std::ostringstream out;out<<"ARRANGER_USER_KBD_B"<<std::setfill('0')<<std::setw(2)<<bank<<"_P"<<std::setw(3)<<position<<".ref";return out.str();
}
bool savedKeyboardEntryName(const std::string& name){
    if(!endsWith(name,".ref")||name.size()>128U)return false;
    return startsWith(name,"ARRANGER_USER_KBD_")||startsWith(name,"ARRANGER_STYLE_KBD_")||startsWith(name,"ARRANGER_SOURCE_KBD_")||startsWith(name,"ARRANGER_NATIVE_KBD_");
}
}
bool ArrangerView::readSavedKeyboardEntry(const std::string& path,SavedKeyboardEntry& entry,std::string& error) const {
    if(!savedKeyboardEntryName(files::nameOf(path))||persistentSessionPath_.empty()||
       files::absolute(files::parentOf(path))!=files::absolute(files::parentOf(persistentSessionPath_))){error="Not a saved User Keyboard Set entry";return false;}
    const auto size=files::fileSize(path);std::string text;
    if(size<=0||size>1024LL*1024LL||!files::readText(path,text)){error="Saved Keyboard Set entry is unavailable";return false;}
    std::istringstream in(text);std::string magic;int version=0;
    if(!(in>>magic>>version>>entry.bank>>entry.position>>std::quoted(entry.name)>>std::quoted(entry.sourcePath)>>
        std::quoted(entry.identity)>>std::quoted(entry.metadataFile))||magic!="SILVETON_USER_KEYBOARD_SET"||version!=1||
       entry.bank<0||entry.bank>16||entry.position<1||entry.position>128||entry.name.empty()||entry.name.size()>256U||
       entry.sourcePath.size()>kKeyboardMetadataMaximumPath||entry.identity.size()>1024U*1024U||
       !keyboardMetadataFileNameValid(entry.metadataFile)||entry.metadataFile.empty()){
        error="Saved Keyboard Set entry has invalid references";return false;
    }
    in>>std::ws;if(!in.eof()){error="Saved Keyboard Set entry has trailing data";return false;}
    entry.path=path;return true;
}
bool ArrangerView::prepareSavedKeyboardEntry(const SavedKeyboardEntry& entry,host::ArrangerKeyboardSet& prepared,
        SavedKeyboardRecall& recall,std::string& error){
    if(entry.sourcePath.empty()){
        if(entry.identity!="SILVETON_ASSEMBLED_KEYBOARD_SET 1\nREVISION "+entry.metadataFile){error="Saved assembled Keyboard Set revision is invalid";return false;}
    }else{
        if(!prepared.read){error="Original Keyboard Set metadata is unavailable";return false;}
        std::string identity;
        if(!keyboardFxRevision(entry.sourcePath,*prepared.read,identity,error)||identity!=entry.identity){
            error="The original Keyboard Set revision or Sound addresses changed; saved edits were kept but not applied";return false;
        }
    }
    sampler::SetLoadResult loaded;StoredKeyboardMetadata metadata;
    const auto path=keyboardPerformancePath(persistentSessionPath_,entry.metadataFile);
    if(!loadKeyboardMetadataPackage(path,loaded,metadata,error))return false;
    if(metadata.sourcePath!=entry.sourcePath){error="Saved performance belongs to another original Keyboard Set";return false;}
    auto combi=loaded.data.performance->combi;std::size_t readyCount=0,missingCount=0;bool expectedSound=false;
    for(int part=0;part<sampler::kPartCount;++part){
        auto& upper=combi.part(part);
        for(int source=0;source<=sampler::kUpperLayers;++source){
            auto& assignment=sampler::soundSource(upper,source);
            const auto& saved=metadata.sources[static_cast<std::size_t>(part)][static_cast<std::size_t>(source)];
            assignment.program.reset();if(!assignment.engine.chosen())assignment.soloModel.reset();
            if(static_cast<int>(assignment.soundSlotId)!=saved.slot){error="Saved Sound reference does not match its performance";return false;}
            const bool original=source==0&&part<7&&keyboardAddressComplete(metadata.bindings[static_cast<std::size_t>(part)]);
            expectedSound=expectedSound||saved.expected||original;
            if(original){const auto& binding=metadata.bindings[static_cast<std::size_t>(part)];
                assignment.program=host::arrangerHost().preparedKeyboardSound(binding.msb,binding.lsb,binding.program,binding.sourcePath);
            }else if(saved.expected){
                if(saved.slot<1||saved.slot>500||saved.name.empty()){error="A saved Sound has no recoverable original address or library slot";return false;}
                const auto bankIdentity=keyboardSamplerBankIdentity(ctrl_.currentBankFile());
                if(!saved.bankIdentity.empty()&&saved.bankIdentity==bankIdentity){
                    const auto sound=host::resolveArrangerBankSound(saved.slot);if(sound&&sound->name==saved.name)assignment.program=sound;
                }
            }
            if(assignment.program||assignment.engine.chosen())++readyCount;
            else if(saved.expected){++missingCount;if(!assignment.soloModel)assignment.engine.type=sampler::EngineType::Off;}
        }
    }
    // Preparation also serves Save Style; unavailable assignments retain their
    // exact refs silently. Live publication applies the availability guard.
    combi.name=entry.name;prepared.combi=std::move(combi);prepared.playableParts=readyCount;
    recall.active=true;recall.requiresAvailableSound=expectedSound;recall.chordScanArea=metadata.chordScanArea;recall.splitDeclared=metadata.splitDeclared;recall.splitEnabled=metadata.splitDeclared?metadata.splitEnabled:keyboardSplitEnabled_;recall.useGlobalSplit=metadata.splitDeclared?metadata.useGlobalSplit:prepared.read?prepared.read->useGlobalSplit!=0:keyboardUseGlobalSplit_;
    recall.bassInversion=metadata.bassInversion;
    recall.lowerMuteBeforeFull=metadata.splitDeclared?metadata.lowerMuteBeforeFull:prepared.read?prepared.read->parts[0].mute==1:prepared.combi.part(6).mute;recall.splitPoint=metadata.splitPoint>=1?metadata.splitPoint:prepared.splitPoint>=1?prepared.splitPoint:host::arrangerHost().snapshot(selectedPlayer_).split;
    recall.low=metadata.rangeLow;recall.high=metadata.rangeHigh;recall.suppressed=metadata.splitSuppressed;
    if(!metadata.rangesDeclared)for(int part=0;part<7;++part){recall.low[part]=prepared.combi.part(part).keyLow;recall.high[part]=prepared.combi.part(part).keyHigh;}
    for(std::size_t part=0;part<recall.bindings.size();++part){const auto& binding=metadata.bindings[part];
        recall.bindings[part]={binding.msb,binding.lsb,binding.program,binding.sourcePath};}
    if(metadata.splitPoint>=1)prepared.splitPoint=metadata.splitPoint;
    if(missingCount>0U)prepared.warnings.push_back(std::to_string(missingCount)+" saved Sound assignments are unavailable and remain silent");
    return true;
}
void ArrangerView::refreshSavedKeyboardEntries(){
    if(!savedKeyboardLibraryDirty_)return;
    savedKeyboardLibraryDirty_=false;savedKeyboardEntries_.clear();
    if(persistentSessionPath_.empty())return;
    const auto parent=files::parentOf(persistentSessionPath_);
    for(const auto& name:files::listNames(parent)){
        if(!startsWith(name,"ARRANGER_USER_KBD_")||!endsWith(name,".ref"))continue;
        SavedKeyboardEntry entry;std::string error;
        if(readSavedKeyboardEntry(files::join(parent,name),entry,error)&&entry.bank>=1)
            savedKeyboardEntries_.push_back(std::move(entry));
    }
    std::sort(savedKeyboardEntries_.begin(),savedKeyboardEntries_.end(),[](const auto& a,const auto& b){return std::tie(a.bank,a.position)<std::tie(b.bank,b.position);});
}
ArrangerView::KeyboardWorkingSet ArrangerView::captureKeyboardWorkingSet() const {
    KeyboardWorkingSet state;state.combi=ctrl_.engine.nativeKeyboardCombi();state.read=keyboardSetContents_;
    state.sourcePath=activeNativeKeyboardSetPath_;state.entryPath=activeSavedKeyboardEntryPath_;
    state.nativeSlot=currentKeyboardCombiSlot_;state.nativeBankIdentity=currentKeyboardCombiBankIdentity_;
    state.metadataFile=keyboardMetadataFile_;state.metadataBindings=keyboardMetadataSavedBindings_;state.sourceIdentity=keyboardFxOverride_.identity;
    auto& recall=state.recall;recall.active=true;recall.splitDeclared=true;
    recall.splitEnabled=keyboardSplitEnabled_;recall.useGlobalSplit=keyboardUseGlobalSplit_;recall.lowerMuteBeforeFull=keyboardLowerMuteBeforeFull_;
    // ACK is read before the snapshot. A not-yet-published recall keeps its
    // accepted intent even if the audio thread publishes during this capture.
    const auto committed=host::arrangerHost().keyboardRecallCommittedSerial();
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    recall.splitPoint=player.split;recall.chordScanArea=player.chordScanArea;recall.bassInversion=player.bassInversion?1:0;
    if(keyboardRecallPendingSerial_!=0U&&committed!=keyboardRecallPendingSerial_){
        recall.splitPoint=keyboardRecallPendingSplit_;
        if(keyboardRecallPendingArea_>=0)recall.chordScanArea=keyboardRecallPendingArea_;
        if(keyboardRecallPendingBass_>=0)recall.bassInversion=keyboardRecallPendingBass_;
    }
    recall.bindings=keyboardSoundBindings_;recall.low=keyboardRangeLow_;recall.high=keyboardRangeHigh_;recall.suppressed=keyboardSplitSuppressed_;
    for(const auto& binding:recall.bindings)recall.requiresAvailableSound=recall.requiresAvailableSound||binding.msb>=0;
    if(state.combi)for(int part=0;part<sampler::kPartCount;++part)for(int source=0;source<=sampler::kUpperLayers;++source){
        const auto& assignment=sampler::soundSource(state.combi->part(part),source);
        recall.requiresAvailableSound=recall.requiresAvailableSound||assignment.program||assignment.engine.chosen()||
            (assignment.soundSlotId>0&&!assignment.name.empty());
    }
    return state;
}
void ArrangerView::rememberStyleKeyboardSet(){
    if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4&&!selectedStyleKey_.empty()){
        auto state=captureKeyboardWorkingSet();state.nativeSlot=0;state.nativeBankIdentity.clear();
        keyboardWorkingSets_[static_cast<std::size_t>(selectedKeyboardSet_)]=std::move(state);
        // A Style position owns a copy, not the original Library COMBI slot.
        currentKeyboardCombiSlot_=0;currentKeyboardCombiBankIdentity_.clear();
    }
}
bool ArrangerView::prepareWorkingKeyboardSet(const std::string& path,int slot,KeyboardWorkingSet& state,std::string& error){
    state={};host::ArrangerKeyboardSet prepared;SavedKeyboardEntry entry;SavedKeyboardRecall recall;
    const bool saved=!path.empty()&&savedKeyboardEntryName(files::nameOf(path));
    if(saved&&!readSavedKeyboardEntry(path,entry,error))return false;
    const auto source=saved?entry.sourcePath:path;
    const auto current=ctrl_.engine.nativeKeyboardCombi();const int channel=current?current->part(0).midiChannel:0;
    if(!source.empty()&&!host::arrangerHost().prepareKeyboardSet(source,prepared,channel,keyboardSplitEnabled_,true)){
        error=host::arrangerHost().lastError();return false;
    }
    if(!saved&&!source.empty()&&prepared.read){
        std::string sourceOverwrite;
        if(!findSourceKeyboardOverwrite(source,*prepared.read,sourceOverwrite,error))return false;
        if(!sourceOverwrite.empty())return prepareWorkingKeyboardSet(sourceOverwrite,0,state,error);
        if(!error.empty()){showToast(error,6500);error.clear();}
    }
    if(saved){
        if(!prepareSavedKeyboardEntry(entry,prepared,recall,error))return false;
        state.entryPath=path;state.metadataFile=entry.metadataFile;state.sourceIdentity=entry.identity;
        sampler::SetLoadResult loaded;StoredKeyboardMetadata metadata;
        if(!loadKeyboardMetadataPackage(keyboardPerformancePath(persistentSessionPath_,entry.metadataFile),loaded,metadata,error))return false;
        state.metadataBindings=loaded.data.extra;
    }else if(source.empty()){
        const auto stored=slot>0?ctrl_.engine.nativeStoredCombi(0,0,slot):std::shared_ptr<const sampler::Combi>{};
        if(!stored){error="The assigned Keyboard Set is unavailable";return false;}
        prepared.combi=*stored;
        state.nativeSlot=slot;state.nativeBankIdentity=keyboardSamplerBankIdentity(ctrl_.currentBankFile());
        bool nativeApplied=false;
        if(!prepareNativeKeyboardOverwrite(slot,state.nativeBankIdentity,*stored,state,nativeApplied,error))return false;
        if(nativeApplied)return true;
        if(!error.empty()){showToast(error,6500);error.clear();}
    }
    if(!recall.active){
        recall.active=true;recall.splitDeclared=true;recall.splitEnabled=keyboardSplitEnabled_;
        recall.splitPoint=prepared.splitPoint>=1?prepared.splitPoint:host::arrangerHost().snapshot(selectedPlayer_).split;
        recall.low.fill(0);recall.high.fill(127);
        if(prepared.read){
            recall.lowerMuteBeforeFull=prepared.read->parts[0].mute==1;recall.useGlobalSplit=prepared.read->useGlobalSplit!=0;
            recall.bassInversion=prepared.read->bassInversionRaw;
            for(const auto& part:prepared.read->parts){
                const int target=part.role==1?6:part.role-2;if(target<0||target>=7)continue;
                const auto i=static_cast<std::size_t>(target);recall.low[i]=part.keyLow>=0?part.keyLow:0;recall.high[i]=part.keyHigh>=0?part.keyHigh:127;
                if(part.addressKnown)recall.bindings[i]={part.msb,part.lsb,part.program,source};
                recall.suppressed[i]=!prepared.combi.part(target).enabled&&prepared.combi.part(target).program&&
                    std::max(1,part.velocityLow<0?1:part.velocityLow)<=(part.velocityHigh<0?127:part.velocityHigh);
            }
        }else{
            recall.lowerMuteBeforeFull=prepared.combi.part(6).mute;
            for(int part=0;part<7;++part){recall.low[part]=prepared.combi.part(part).keyLow;recall.high[part]=prepared.combi.part(part).keyHigh;}
        }
    }
    if(!saved)for(int part=0;part<sampler::kPartCount;++part)for(int sourceIndex=0;sourceIndex<=sampler::kUpperLayers;++sourceIndex){
        const auto& assignment=sampler::soundSource(prepared.combi.part(part),sourceIndex);
        recall.requiresAvailableSound=recall.requiresAvailableSound||assignment.program||assignment.engine.chosen()||
            (assignment.soundSlotId>0&&!assignment.name.empty());
    }
    state.combi=std::make_shared<const sampler::Combi>(std::move(prepared.combi));state.read=prepared.read;
    state.sourcePath=source;state.recall=std::move(recall);
    if(!source.empty()&&!saved&&prepared.read&&!keyboardFxRevision(source,*prepared.read,state.sourceIdentity,error))return false;
    return true;
}
bool ArrangerView::postKeyboardRecall(int split,bool enabled,int scan,int bass){
    auto& arranger=host::arrangerHost();
    const auto committed=arranger.keyboardRecallCommittedSerial();
    const bool previousPending=keyboardRecallPendingSerial_!=0U&&committed!=keyboardRecallPendingSerial_;
    // Two queued recalls compose in order. An absent optional field in the
    // second recall keeps an explicit first recall even before publication.
    const int pendingArea=scan>=0?scan:previousPending?keyboardRecallPendingArea_:-1;
    const int pendingBass=bass>=0?bass:previousPending?keyboardRecallPendingBass_:-1;
    std::uint32_t serial=0;
    if(!arranger.setKeyboardRecall(split,enabled,scan,bass,&serial))return false;
    keyboardRecallPendingSerial_=serial;keyboardRecallPendingSplit_=split;
    keyboardRecallPendingArea_=pendingArea;keyboardRecallPendingBass_=pendingBass;
    return true;
}
bool ArrangerView::applyWorkingKeyboardSet(const KeyboardWorkingSet& state,int position,bool notify){
    if(!state.combi)return false;
    if(!state.sourcePath.empty()||state.recall.requiresAvailableSound){
        bool available=false;
        for(int part=0;part<sampler::kPartCount;++part)for(int source=0;source<=sampler::kUpperLayers;++source){
            const auto& assignment=sampler::soundSource(state.combi->part(part),source);available=available||assignment.program||assignment.engine.chosen();
        }
        if(!available){if(notify)showToast("This Keyboard Set has no available User Sounds; current sounds were kept",6500);return false;}
    }
    rememberStyleKeyboardSet();const auto previous=ctrl_.engine.nativeKeyboardCombi();
    const int split=state.recall.useGlobalSplit?host::arrangerHost().snapshot(selectedPlayer_).globalSplit:state.recall.splitPoint;
    auto adjusted=*state.combi;auto suppressed=state.recall.suppressed;
    adjusted.part(6).mute=state.recall.splitEnabled?state.recall.lowerMuteBeforeFull:true;
    for(int part=0;part<7;++part){auto& upper=adjusted.part(part);const auto i=static_cast<std::size_t>(part);
        upper.keyLow=static_cast<std::uint8_t>(state.recall.low[i]);upper.keyHigh=static_cast<std::uint8_t>(state.recall.high[i]);
        upper.performanceKeyLow=static_cast<std::uint8_t>(state.recall.splitEnabled&&part!=6?split+1:0);
        upper.performanceKeyHigh=static_cast<std::uint8_t>(state.recall.splitEnabled&&part==6?split:127);
        if(suppressed[i])upper.enabled=true;
        suppressed[i]=false;
    }
    if(!ctrl_.engine.nativeApplyKeyboardCombi(adjusted)){if(notify)showToast(ctrl_.engine.nativeLastTextError(),6000);return false;}
    if(!postKeyboardRecall(split,state.recall.splitEnabled,state.recall.chordScanArea,state.recall.bassInversion)){
        if(previous)(void)ctrl_.engine.nativeApplyKeyboardCombi(*previous,true);
        if(notify)showToast(host::arrangerHost().lastError(),6000);
        return false;
    }
    scaleMainRemembered_=false;keyboardSetContents_=state.read;activeNativeKeyboardSetPath_=state.sourcePath;activeSavedKeyboardEntryPath_=state.entryPath;
    currentKeyboardCombiSlot_=position<0?state.nativeSlot:0;currentKeyboardCombiBankIdentity_=position<0?state.nativeBankIdentity:std::string{};
    keyboardMetadataFile_=state.metadataFile;keyboardMetadataSavedBindings_=state.metadataBindings;keyboardMetadataSavedState_=state.combi;
    keyboardSoundBindings_=state.recall.bindings;keyboardRangeLow_=state.recall.low;keyboardRangeHigh_=state.recall.high;
    keyboardSplitSuppressed_=suppressed;keyboardSplitEnabled_=state.recall.splitEnabled;keyboardLowerMuteBeforeFull_=state.recall.lowerMuteBeforeFull;keyboardUseGlobalSplit_=state.recall.useGlobalSplit;
    keyboardFxOverride_={};keyboardFxOverride_.identity=state.sourceIdentity;keyboardFxWarning_.clear();keyboardMetadataRestorePending_=false;
    for(int part=0;part<7;++part){const auto& binding=keyboardSoundBindings_[part];
        (void)host::arrangerHost().retainPreparedKeyboardSound(part,binding.msb,binding.lsb,binding.program,binding.sourcePath);}
    selectedKeyboardSet_=position;pendingKeyboardSet_=-1;persistentSaveAllowed_=true;persistentRecordProtected_=false;
    markPersistentStateChanged();refresh();dirty_=true;return true;
}
bool ArrangerView::freezeKeyboardWorkingSet(KeyboardWorkingSet& state,const std::string& owner,int position,const std::string& name,std::string& path,std::string& error){
    if(!state.combi){error="No Keyboard Set is available to save";return false;}
    std::string identity;
    if(!state.sourcePath.empty()){
        host::ArrangerKeyboardSet original;
        if(!host::arrangerHost().prepareKeyboardSet(state.sourcePath,original,state.combi->part(0).midiChannel,state.recall.splitEnabled,true)||!original.read){error=host::arrangerHost().lastError();return false;}
        if(!keyboardFxRevision(state.sourcePath,*original.read,identity,error))return false;
        if(!state.sourceIdentity.empty()&&state.sourceIdentity!=identity){error="The original Keyboard Set changed; select it again before saving";return false;}
    }
    auto named=*state.combi;named.name=name;state.combi=std::make_shared<const sampler::Combi>(std::move(named));
    if(!writeKeyboardWorkingMetadata(state,error))return false;
    if(state.sourcePath.empty())identity="SILVETON_ASSEMBLED_KEYBOARD_SET 1\nREVISION "+state.metadataFile;
    const auto filename="ARRANGER_STYLE_KBD_"+keyboardFxHex(keyboardMetadataHash(owner))+"_"+std::to_string(position+1)+"_"+keyboardFxHex(keyboardMetadataHash(state.metadataFile+identity+name))+".ref";
    path=files::join(files::parentOf(persistentSessionPath_),filename);
    std::ostringstream record;record<<"SILVETON_USER_KEYBOARD_SET 1\n0 "<<position+1<<'\n'<<std::quoted(name)<<'\n'<<std::quoted(state.sourcePath)<<'\n'<<std::quoted(identity)<<'\n'<<std::quoted(state.metadataFile)<<'\n';
    if(files::exists(path)){std::string previous;if(!files::readText(path,previous)||previous!=record.str()){error="Saved Keyboard Set revision is inconsistent";return false;}}
    else {const auto pending=path+".pending";if(!files::writeText(pending,record.str())||std::rename(pending.c_str(),path.c_str())!=0){(void)files::removeRecursively(pending);error="Keyboard Set revision could not be committed";return false;}}
    state.entryPath=path;return true;
}
bool ArrangerView::commitKeyboardSave(bool toStyle,int bank,int position,int stylePosition,const std::string& name){
    if(persistentSessionPath_.empty()||!ctrl_.engine.nativeKeyboardCombi()){showToast("Keyboard Set saving is unavailable",6000);return false;}
    if(name.empty()||name.size()>256U||name.find_first_of("\r\n")!=std::string::npos||bank<1||bank>16||position<1||position>128||stylePosition<0||stylePosition>3){showToast("Choose a valid name, bank and position",5000);return false;}
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    if(toStyle&&(!player.loaded||player.sourcePath.empty())){showToast("Select a Style before saving its Keyboard Set",6000);return false;}
    if(toStyle){players_[static_cast<std::size_t>(selectedPlayer_)]=player;selectStyleLinks();}
    rememberStyleKeyboardSet();auto state=captureKeyboardWorkingSet();std::string entryPath,error;
    const auto owner=toStyle?arrangerStyleSelectionKey(player):std::string("Library");
    if(!freezeKeyboardWorkingSet(state,owner,stylePosition,name,entryPath,error)){showToast(error,6500);return false;}
    if(toStyle){
        auto refs=host::arrangerHost().savedStyleKeyboardSets(selectedPlayer_);
        // Legacy styles freeze their old saved refs before migrating. Dirty
        // edit buffers in the other positions are not saved by this command.
        for(std::size_t i=0;i<4;++i)if(static_cast<int>(i)!=stylePosition&&refs[i].first.empty()&&(!keyboardSetPaths_[i].empty()||keyboardSets_[i]>0)){
            KeyboardWorkingSet previous;if(!prepareWorkingKeyboardSet(keyboardSetPaths_[i],keyboardSets_[i],previous,error)){showToast(error,6500);return false;}
            const auto previousName=keyboardSetNames_[i].empty()?previous.combi->name:keyboardSetNames_[i];
            if(!freezeKeyboardWorkingSet(previous,owner,static_cast<int>(i),previousName,refs[i].first,error)){showToast(error,6500);return false;}refs[i].second=previousName;
        }
        refs[static_cast<std::size_t>(stylePosition)]={entryPath,name};
        if(!host::arrangerHost().saveStyleKeyboardSets(selectedPlayer_,refs)){showToast(host::arrangerHost().lastError(),6500);return false;}
        rememberStyleKeyboardSet();keyboardWorkingSets_[static_cast<std::size_t>(stylePosition)]=state;
        keyboardSetPaths_[static_cast<std::size_t>(stylePosition)]=entryPath;keyboardSetNames_[static_cast<std::size_t>(stylePosition)]=name;keyboardSets_[static_cast<std::size_t>(stylePosition)]=0;
        nativeKeyboardSetLinks_[owner]=refs;for(std::size_t i=0;i<4;++i)keyboardSetLinks_[owner][i]={0,refs[i].second};
        selectedKeyboardSet_=stylePosition;activeSavedKeyboardEntryPath_=entryPath;
    }else{
        SavedKeyboardEntry frozen;if(!readSavedKeyboardEntry(entryPath,frozen,error)){showToast(error,6500);return false;}
        const auto libraryPath=files::join(files::parentOf(persistentSessionPath_),keyboardLibraryEntryName(bank,position));
        std::ostringstream record;record<<"SILVETON_USER_KEYBOARD_SET 1\n"<<bank<<' '<<position<<'\n'<<std::quoted(name)<<'\n'<<std::quoted(frozen.sourcePath)<<'\n'<<std::quoted(frozen.identity)<<'\n'<<std::quoted(frozen.metadataFile)<<'\n';
        const auto pending=libraryPath+".pending";
        if(!files::writeText(pending,record.str())||std::rename(pending.c_str(),libraryPath.c_str())!=0){(void)files::removeRecursively(pending);showToast("Keyboard Set was not saved; previous destination was kept",6500);return false;}
        // A Library save never changes a Style position or its working buffer.
        activeSavedKeyboardEntryPath_=libraryPath;selectedKeyboardSet_=-1;savedKeyboardBank_=bank;savedKeyboardPage_=(position-1)/(liveView_?libraryPositions:10);
        currentKeyboardCombiSlot_=0;currentKeyboardCombiBankIdentity_.clear();
    }
    keyboardMetadataFile_=state.metadataFile;keyboardMetadataSavedBindings_=state.metadataBindings;
    savedKeyboardLibraryDirty_=true;persistentSaveAllowed_=true;persistentRecordProtected_=false;
    (void)ctrl_.engine.nativeApplyKeyboardCombi(*state.combi,true);refresh();markPersistentStateChanged();flushPersistentState();
    showToast(toStyle?"Keyboard Set saved to Style position "+std::to_string(stylePosition+1):"Keyboard Set saved to User bank "+std::to_string(bank)+", position "+std::to_string(position),4500);return true;
}
bool ArrangerView::resourceSaveDestinationExists() const {
    if(resourceSaveIsStyle_){if(resourceSaveStyleSource_)return players_[static_cast<std::size_t>(selectedPlayer_)].loaded;for(const auto& entry:host::arrangerHost().savedStyleEdits())if(entry.bank==resourceSaveBank_&&entry.position==resourceSavePosition_)return true;return false;}
    if(resourceSaveToStyle_){
        const auto index=static_cast<std::size_t>(std::clamp(resourceSaveStylePosition_,0,3));
        if(keyboardWorkingSets_[index].combi||!keyboardSetPaths_[index].empty()||keyboardSets_[index]>0)return true;
        const auto selectionKey=arrangerStyleSelectionKey(host::arrangerHost().snapshot(selectedPlayer_));
        const auto native=nativeKeyboardSetLinks_.find(selectionKey);if(native!=nativeKeyboardSetLinks_.end()&&!native->second[index].first.empty())return true;
        const auto saved=keyboardSetLinks_.find(selectionKey);return saved!=keyboardSetLinks_.end()&&saved->second[index].first>0;
    }
    return !persistentSessionPath_.empty()&&files::exists(files::join(files::parentOf(persistentSessionPath_),keyboardLibraryEntryName(resourceSaveBank_,resourceSavePosition_)));
}
bool ArrangerView::commitStyleSave(int bank,int position,const std::string& name){
    players_[static_cast<std::size_t>(selectedPlayer_)]=host::arrangerHost().snapshot(selectedPlayer_);selectStyleLinks();rememberStyleKeyboardSet();
    auto destination=players_[static_cast<std::size_t>(selectedPlayer_)];destination.savedStyleBank=bank;destination.savedStylePosition=position;
    const auto destinationKey=arrangerStyleSelectionKey(destination);auto frozen=keyboardWorkingSets_;
    host::ArrangerStyleKeyboardLinks refs{};std::string error;
    for(int part=0;part<4;++part){const auto i=static_cast<std::size_t>(part);
        if(!frozen[i].combi){
            if(keyboardSetPaths_[i].empty()&&keyboardSets_[i]<=0)continue;
            if(!prepareWorkingKeyboardSet(keyboardSetPaths_[i],keyboardSets_[i],frozen[i],error)){showToast(error,6500);return false;}
        }
        auto keyboardName=keyboardSetNames_[i].empty()?frozen[i].combi->name:keyboardSetNames_[i];
        if(keyboardName.empty())keyboardName="Keyboard Set "+std::to_string(part+1);
        if(!freezeKeyboardWorkingSet(frozen[i],destinationKey,part,keyboardName,refs[i].first,error)){showToast(error,6500);return false;}
        refs[i].second=keyboardName;
    }
    // The four immutable Keyboard Set refs live in the same saved Style
    // revision as its accompaniment mix. One atomic destination pointer owns all.
    if(!host::arrangerHost().saveStyleEdits(selectedPlayer_,bank,position,name,refs)){showToast(host::arrangerHost().lastError(),7000);return false;}
    players_[static_cast<std::size_t>(selectedPlayer_)]=host::arrangerHost().snapshot(selectedPlayer_);
    selectedStyleKey_=destinationKey;keyboardWorkingSets_=std::move(frozen);
    // Saving changes resource identity, not the live musical selection.
    keyboardRecallStyle_=destinationKey;keyboardRecallElement_=players_[static_cast<std::size_t>(selectedPlayer_)].element;
    auto& native=nativeKeyboardSetLinks_[destinationKey];auto& slots=keyboardSetLinks_[destinationKey];
    for(std::size_t i=0;i<4;++i){native[i]=refs[i];slots[i]={0,refs[i].second};keyboardSetPaths_[i]=refs[i].first;keyboardSetNames_[i]=refs[i].second;keyboardSets_[i]=0;}
    if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4)activeSavedKeyboardEntryPath_=refs[static_cast<std::size_t>(selectedKeyboardSet_)].first;
    rememberPlayerKeyboardBuffers();
    savedStyleEntries_=host::arrangerHost().savedStyleEdits();savedStyleBank_=std::max(1,bank);savedStylePage_=std::max(0,(position-1)/(liveView_?libraryPositions:10));
    markPersistentStateChanged();flushPersistentState();showToast(bank>0?"Style saved to User bank "+std::to_string(bank)+", position "+std::to_string(position):"Current Style and its four Keyboard Sets saved",4500);return true;
}

void ArrangerView::openSavedKeyboardLibrary(){
    if(!sameSelectorFamily(Picker::SavedKeyboardLibrary))rememberNavigation();
    refreshSavedKeyboardEntries();
    for(const auto& entry:savedKeyboardEntries_)if(entry.path==activeSavedKeyboardEntryPath_){savedKeyboardBank_=entry.bank;savedKeyboardPage_=(entry.position-1)/(liveView_?libraryPositions:10);break;}
    picker_=Picker::SavedKeyboardLibrary;editor_=false;dirty_=true;
}
void ArrangerView::drawSavedKeyboardLibrary(Canvas& c){
    refreshSavedKeyboardEntries();box(c,{0,0,displayWidth_,displayHeight_},bg);
    const bool large=fullLibrarySelector();
    const int rows=large?8:5,columns=large?3:2,positions=rows*columns;
    const int pages=(128+positions-1)/positions;
    const float right=large?displayWidth_-4.0F:795.0F;
    const float tileWidth=(right-208.0F-4.0F*(columns-1))/columns;
    const float stride=large?39.0F:58.0F,tileHeight=large?36.0F:54.0F;
    savedKeyboardPage_=std::clamp(savedKeyboardPage_,0,pages-1);
    button(c,{3,3,96,35},"‹ Back",green,false,true,[this]{panelExit();},14);
    label(c,"KEYBOARD SET SELECT",110,27,18,green,true,370);
    button(c,{right-301,3,right-157,35},"Save Keyboard Set",green,false,ctrl_.engine.nativeKeyboardCombi()!=nullptr,[this]{openResourceSave(false);},12);
    button(c,{right-148,3,right,35},kstCatalog_?"Source KST":"Load SET / KST",green,false,true,[this]{openKstCatalog(2);},12);
    label(c,"SILVETON USER",12,72,16,green,true,180);
    for(int bank=1;bank<=16;++bank){const float x=5+((bank-1)%2)*98.0F,y=(large?77.0F:89.0F)+((bank-1)/2)*39.0F;
        button(c,{x,y,x+93,y+35},"User "+std::to_string(bank),green,savedKeyboardBank_==bank,true,[this,bank]{savedKeyboardBank_=bank;savedKeyboardPage_=0;dirty_=true;},12);}
    for(int tile=0;tile<positions;++tile){const int position=savedKeyboardPage_*positions+tile+1;
        const SavedKeyboardEntry* found=nullptr;for(const auto& entry:savedKeyboardEntries_)if(entry.bank==savedKeyboardBank_&&entry.position==position){found=&entry;break;}
        const int row=tile%rows,col=tile/rows;const float x=208+col*(tileWidth+4),y=(large?77.0F:89.0F)+row*stride;const RectF rect{x,y,x+tileWidth,y+tileHeight};
        if(position>128){box(c,rect,panel,kBorder,2);continue;}
        const bool selected=found&&found->path==activeSavedKeyboardEntryPath_;
        box(c,rect,selected?0xFFE7D58CU:panel,selected?green:kBorder,2);
        label(c,std::to_string(position),x+9,y+(large?23:32),13,selected?bg:dim,true,34);
        label(c,found?found->name:"Empty",x+43,y+(large?23:32),16,selected?bg:found?white:dim,true,tileWidth-49);
        if(found){const auto path=found->path;hit(rect,[this,path]{activateNativeKeyboardSet(path,targetKbdSet_);});}
    }
    button(c,{208,large?393.0F:391.0F,253,large?433.0F:426.0F},"◀",green,false,savedKeyboardPage_>0,[this]{--savedKeyboardPage_;dirty_=true;},15);
    const int first=(savedKeyboardPage_/8)*8;
    for(int i=0;i<8&&first+i<pages;++i){const int page=first+i;const float pagerStride=(right-47-264)/8.0F;const float x=264+i*pagerStride;
        button(c,{x,large?393.0F:391.0F,x+pagerStride-4,large?433.0F:426.0F},std::to_string(page+1),green,page==savedKeyboardPage_,true,[this,page]{savedKeyboardPage_=page;dirty_=true;},13);}
    button(c,{right-47,large?393.0F:391.0F,right,large?433.0F:426.0F},"▶",green,false,savedKeyboardPage_+1<pages,[this]{++savedKeyboardPage_;dirty_=true;},15);
    button(c,{5,large?393.0F:438.0F,196,large?433.0F:477.0F},"Sampler COMBI",green,false,true,[this]{bankSoundsOnly_=true;openPicker(Picker::KeyboardSet);},12);
    label(c,"User "+std::to_string(savedKeyboardBank_)+"  /  "+std::to_string(savedKeyboardPage_+1)+" of "+std::to_string(pages),210,large?447.0F:463.0F,13,dim,false,right-218);
}
void ArrangerView::openSavedStyleLibrary(int player){
    const int targetPlayer=player>=0?std::clamp(player,0,1):styleSelectorPlayer();
    if(!sameSelectorFamily(Picker::SavedStyleLibrary))rememberNavigation();
    styleSelectorPlayer_=targetPlayer;
    savedStyleBank_=savedStyleBrowse_[static_cast<std::size_t>(targetPlayer)].first;
    savedStylePage_=savedStyleBrowse_[static_cast<std::size_t>(targetPlayer)].second;
    savedStyleEntries_=host::arrangerHost().savedStyleEdits();const auto current=host::arrangerHost().snapshot(targetPlayer);
    if(current.savedStyleBank>0){savedStyleBank_=current.savedStyleBank;savedStylePage_=(current.savedStylePosition-1)/(liveView_?libraryPositions:10);}
    picker_=Picker::SavedStyleLibrary;editor_=false;dirty_=true;
}
void ArrangerView::drawSavedStyleLibrary(Canvas& c){
    const int targetPlayer=styleSelectorPlayer();
    savedStyleBrowse_[static_cast<std::size_t>(targetPlayer)]={savedStyleBank_,savedStylePage_};
    box(c,{0,0,displayWidth_,displayHeight_},bg);const auto current=players_[static_cast<std::size_t>(targetPlayer)];
    const bool large=fullLibrarySelector();
    const int rows=large?8:5,columns=large?3:2,positions=rows*columns;
    const int pages=(128+positions-1)/positions;
    const float right=large?displayWidth_-4.0F:795.0F;
    const float tileWidth=(right-208.0F-4.0F*(columns-1))/columns;
    const float stride=large?39.0F:58.0F,tileHeight=large?36.0F:54.0F;
    savedStylePage_=std::clamp(savedStylePage_,0,pages-1);
    button(c,{3,3,96,35},"‹ Back",orange,false,true,[this]{panelExit();},14);
    label(c,"STYLE SELECT",110,27,18,orange,true,370);
    // A nonfocused Player has no current keyboard edit buffers in this view.
    // Do not let this shortcut save the focused Player under another title.
    button(c,{right-301,3,right-157,35},"Save Style",orange,false,current.loaded&&targetPlayer==selectedPlayer_,[this,targetPlayer]{if(targetPlayer==selectedPlayer_)openResourceSave(true);},12);
    button(c,{right-148,3,right,35},kstCatalog_?"Source KST":"Load SET / KST",orange,false,true,[this]{openKstCatalog(0);},12);
    button(c,{right-148,43,right,77},"Style Files",orange,false,true,[this,targetPlayer]{bankSoundsOnly_=true;openPicker(Picker::Style,targetPlayer);},12);
    label(c,"SILVETON USER",12,72,16,orange,true,180);
    for(int bank=1;bank<=16;++bank){const float x=5+((bank-1)%2)*98.0F,y=(large?77.0F:89.0F)+((bank-1)/2)*39.0F;
        button(c,{x,y,x+93,y+35},"User "+std::to_string(bank),orange,savedStyleBank_==bank,true,[this,bank]{savedStyleBank_=bank;savedStylePage_=0;dirty_=true;},12);}
    for(int tile=0;tile<positions;++tile){const int position=savedStylePage_*positions+tile+1;
        const host::ArrangerSavedStyleEntry* found=nullptr;for(const auto& entry:savedStyleEntries_)if(entry.bank==savedStyleBank_&&entry.position==position){found=&entry;break;}
        const int row=tile%rows,col=tile/rows;const float x=208+col*(tileWidth+4),y=(large?77.0F:89.0F)+row*stride;const RectF rect{x,y,x+tileWidth,y+tileHeight};
        if(position>128){box(c,rect,panel,kBorder,2);continue;}
        const bool selected=current.savedStyleBank==savedStyleBank_&&current.savedStylePosition==position;
        box(c,rect,selected?0xFFE7D58CU:panel,selected?orange:kBorder,2);
        label(c,std::to_string(position),x+9,y+(large?23:32),13,selected?bg:dim,true,34);
        label(c,found?found->name:"Empty",x+43,y+(large?23:32),16,selected?bg:found?white:dim,true,tileWidth-49);
        if(found){const int bank=savedStyleBank_;hit(rect,[this,bank,position,targetPlayer]{
            if(!host::arrangerHost().loadSavedStyleEdits(targetPlayer,bank,position)){showToast(host::arrangerHost().lastError(),6500);return;}
            styleKeyboardSelectionAccepted(targetPlayer);
            markPersistentStateChanged();refresh();dirty_=true;
        });}
    }
    button(c,{208,large?393.0F:391.0F,253,large?433.0F:426.0F},"◀",orange,false,savedStylePage_>0,[this]{--savedStylePage_;dirty_=true;},15);
    const int first=(savedStylePage_/8)*8;
    for(int i=0;i<8&&first+i<pages;++i){const int page=first+i;const float pagerStride=(right-47-264)/8.0F;const float x=264+i*pagerStride;
        button(c,{x,large?393.0F:391.0F,x+pagerStride-4,large?433.0F:426.0F},std::to_string(page+1),orange,page==savedStylePage_,true,[this,page]{savedStylePage_=page;dirty_=true;},13);}
    button(c,{right-47,large?393.0F:391.0F,right,large?433.0F:426.0F},"▶",orange,false,savedStylePage_+1<pages,[this]{++savedStylePage_;dirty_=true;},15);
    button(c,{5,large?393.0F:438.0F,196,large?433.0F:477.0F},"Player "+std::to_string(targetPlayer+1),orange,false,true,[this,targetPlayer]{
        savedStyleBrowse_[static_cast<std::size_t>(targetPlayer)]={savedStyleBank_,savedStylePage_};
        styleSelectorPlayer_=1-targetPlayer;
        const auto next=static_cast<std::size_t>(styleSelectorPlayer_);
        savedStyleBank_=savedStyleBrowse_[next].first;savedStylePage_=savedStyleBrowse_[next].second;
        dirty_=true;
    },12);
    label(c,"User "+std::to_string(savedStyleBank_)+"  /  "+std::to_string(savedStylePage_+1)+" of "+std::to_string(pages),210,large?447.0F:463.0F,13,dim,false,right-218);
}
