#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>

namespace silveton::ui::detail {
// Allocation-free identities for menu cache buckets and displayed telemetry.
// A menu identity never certifies pixel freshness: the renderer still compares
// the freshly recorded operations before retaining any old pixels.
struct ViewStateKey {
    std::uint64_t value{1469598103934665603ULL};
    template <class T> void add(T input) noexcept {
        auto bits=static_cast<std::uint64_t>(input);
        for(unsigned n=0;n<8;++n){value^=bits&255U;value*=1099511628211ULL;bits>>=8U;}
    }
    void text(const std::string& input) noexcept {
        add(input.size());for(const unsigned char byte:input){value^=byte;value*=1099511628211ULL;}
    }
};
inline std::int64_t displayNumber(double value,double scale=1.0) noexcept {
    if(!std::isfinite(value))return -9223372036854775807LL;
    return static_cast<std::int64_t>(std::nearbyint(std::clamp(value*scale,-1.0e15,1.0e15)));
}
inline float meterPosition(float peak) noexcept {
    if(!std::isfinite(peak)||peak<=0.000001F)return 0;
    const float db=std::min(12.0F,20.0F*std::log10(peak));
    if(db<=-60)return 0;
    if(db<-24)return (db+60)/108;
    if(db<0)return 1.0F/3.0F+(db+24)/72;
    return 2.0F/3.0F+db/36;
}
template <class Audio,class Midi,class Meters>
void displayedTelemetry(ViewStateKey& key,const Audio& a,const Midi& m,const Meters& meters,
                        bool running,int error,int connections,bool midiFlash,bool showMeters,
                        bool classic,float uiScale) noexcept {
    key.add(running);key.add(error);key.add(a.sampleRate);key.add(a.framesPerBurst);key.add(a.bufferSizeFrames);
    key.add(a.sharingMode>=0);key.add(a.xrunCount);key.add(displayNumber(a.estimatedLatencyMs,classic?10:100));
    key.add(a.activeVoices);key.add(displayNumber(a.cpuLoadPercent));key.add(a.cpuLoadPercent>95);
    if(!classic){key.add(a.cpuLoadPercent>80);key.add(a.coresWorking);}
    const bool connected=std::max(connections,m.deviceCount)>0;
    key.add(connected);if(!connected&&!midiFlash)key.add(m.lastError);
    key.add(midiFlash);
    if(midiFlash){const bool note=(m.status&0xF0)==0x90&&m.data2>0;key.add(note);if(note)key.add(m.data1);}
    bool audioSignal=a.activeVoices>0;
    float masterPeak=0;
    for(const auto& channel:meters){
        audioSignal=audioSignal||channel.first>0.0001F||channel.second>0.0001F;
        masterPeak=std::max(masterPeak,std::max(channel.first,channel.second));
        if(showMeters){
            // The regular meter is a continuous pixel bar; the classic LIVE
            // highlight also uses the continuous level, beyond its25 segments.
            const double steps=600.0*std::max(1.0F,uiScale);
            key.add(displayNumber(meterPosition(channel.first),steps));
            key.add(displayNumber(meterPosition(channel.second),steps));
        }
    }
    if(!classic){
        key.add(audioSignal);
        // The master meter is in the regular top bar on every page, including
        // settings and pickers, where individual part meters are hidden.
        const float master=std::clamp((20.0F*std::log10(std::max(masterPeak,1.0e-5F))+60.0F)/60.0F,0.0F,1.0F);
        key.add(displayNumber(master,84.0*std::max(1.0F,uiScale)));
        key.add(master>0.9F);key.add(master>0.002F);
    }
}
template <class Ctrl>
void displayedPerformance(ViewStateKey& key,const Ctrl& ctrl,bool list,bool parts,bool scale) {
    if(list||parts||scale){
        key.add(ctrl.tercaMasterOn());key.add(ctrl.scaleMasterOn());
        key.add(ctrl.hasTercaUppers());key.add(ctrl.hasScaleUppers());
    }
    if(list){
        const auto terca=ctrl.tercaState();key.add(terca.root);key.add(terca.cell);
        key.add(ctrl.quarterNotes());
    }
    if(parts||scale)for(int part=0;part<(scale?15:7);++part){
        key.add(ctrl.tercaChosen(part));key.add(ctrl.quarterChosen(part));
    }
    if(scale){
        key.add(ctrl.scaleEnabled());key.add(ctrl.scaleTonic());key.text(ctrl.scaleName());
        for(const float cents:ctrl.scaleCents())key.add(displayNumber(cents,100));
    }
}
template <class Advanced>
void displayedMidiSettings(ViewStateKey& key,const Advanced& settings) noexcept {
    key.add(static_cast<bool>(settings));if(!settings)return;
    const auto& a=*settings;
    key.add(a.midiInMask);key.add(a.filterNotes);key.add(a.filterCc);key.add(a.filterBend);
    key.add(a.filterAftertouch);key.add(a.damperReversed);
    key.add(displayNumber(a.breathMin,10000));key.add(displayNumber(a.breathMax,10000));
    key.add(displayNumber(a.expressionMin,10000));key.add(displayNumber(a.expressionMax,10000));
    key.add(displayNumber(a.breathCurve,100));key.add(displayNumber(a.expressionCurve,100));
}
} // namespace silveton::ui::detail
