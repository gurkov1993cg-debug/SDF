// EXIT closes the current overlay before returning to its underlying page.
// MEDIA and GLOBAL are real modes; MENU is scoped to the active mode.
// Library source switches (KST / USER / local files) are sibling routes,
// never another Back level. The caller owns the selector session.
int ArrangerView::selectorFamily(Picker picker,int catalogTab){
    if(picker==Picker::Style||picker==Picker::SavedStyleLibrary)return 0;
    if(picker==Picker::Sound)return 1;
    if(picker==Picker::KeyboardSet||picker==Picker::SavedKeyboardLibrary)return 2;
    if(picker==Picker::KstCatalog)return catalogTab;
    return -1;
}
bool ArrangerView::sameSelectorFamily(Picker picker,int catalogTab) const{
    const int from=selectorFamily(picker_,kstCatalogTab_),to=selectorFamily(picker,catalogTab);
    return !editor_&&!homeSoundEdit_&&from>=0&&from==to;
}
void ArrangerView::rememberNavigation(){
    NavigationFrame frame;
    frame.picker=picker_;frame.tab=tab_;frame.editor=editor_;frame.keyboardPage=keyboardEditPage_;
    frame.mode=panelMode_;frame.globalSplit=globalSplitEditing_;frame.styleSelectorTarget=styleSelectorPlayer_;
    frame.catalogTab=kstCatalogTab_;frame.keyboardTarget=targetKbdSet_;frame.globalPage=globalPage_;
    if(editor_)frame.editorPage=page();
    if(picker_==Picker::KstCatalog)frame.catalogPage=kstCatalogPage_;
    const bool list=picker_==Picker::Style||picker_==Picker::Sound||picker_==Picker::KeyboardSet||
        picker_==Picker::Split||picker_==Picker::KstFolder||picker_==Picker::Set;
    if(list){frame.listPage=pickerPage_;frame.listCategory=pickerCategory_;frame.listDirectory=pickerDirectory_;
        frame.listError=stylePickerError_;frame.listEntries=entries_;if(picker_==Picker::Sound)frame.listSounds=sounds_;}
    frame.soundEdit=homeSoundEdit_;
    const bool soundPicker=frame.picker==Picker::Sound||(frame.picker==Picker::KstCatalog&&(frame.catalogTab==1||frame.catalogTab==3));
    if(soundPicker){frame.soundPart=targetPart_;frame.soundTrack=targetTrack_;}
    frame.soundPlayer=soundPlayer_;frame.soundSerial=soundSerial_;
    if(frame.picker==Picker::WriteMenu||frame.picker==Picker::SaveAsMenu)frame.picker=Picker::None;
    if(frame.picker==Picker::KstProgress){
        frame.picker=frame.mode==PanelMode::File?Picker::Media:Picker::None;
    }
    const bool styleSelector=frame.picker==Picker::Style||frame.picker==Picker::SavedStyleLibrary||
        (frame.picker==Picker::KstCatalog&&frame.catalogTab==0);
    if(!styleSelector)frame.styleSelectorTarget=-1;
    if(frame.picker!=Picker::KstCatalog)frame.catalogTab=0;
    if(frame.picker!=Picker::KstCatalog&&frame.picker!=Picker::KeyboardSet&&frame.picker!=Picker::SavedKeyboardLibrary)
        frame.keyboardTarget=-1;
    if(frame.keyboardTarget>=0){frame.keyboardTargetPlayer=targetKbdPlayer_;frame.keyboardTargetSerial=targetKbdSerial_;}
    if(frame.picker!=Picker::SettingsMenu)frame.globalPage=GlobalPage::Menu;
    const auto same=[](const NavigationFrame& a,const NavigationFrame& b){
        return std::tie(a.picker,a.tab,a.editor,a.keyboardPage,a.mode,a.globalSplit,a.styleSelectorTarget,a.catalogTab,a.keyboardTarget,a.globalPage,a.soundPart,a.soundTrack,a.soundPlayer,a.soundSerial,a.soundEdit,a.keyboardTargetPlayer,a.keyboardTargetSerial,a.editorPage,a.listPage,a.listCategory,a.listDirectory,a.catalogPage)==
            std::tie(b.picker,b.tab,b.editor,b.keyboardPage,b.mode,b.globalSplit,b.styleSelectorTarget,b.catalogTab,b.keyboardTarget,b.globalPage,b.soundPart,b.soundTrack,b.soundPlayer,b.soundSerial,b.soundEdit,b.keyboardTargetPlayer,b.keyboardTargetSerial,b.editorPage,b.listPage,b.listCategory,b.listDirectory,b.catalogPage);
    };
    if(!navigationHistory_.empty()&&same(navigationHistory_.back(),frame))return;
    if(navigationHistory_.size()>=16U)navigationHistory_.erase(navigationHistory_.begin());
    navigationHistory_.push_back(std::move(frame));
}
bool ArrangerView::restoreNavigation(){
    if(navigationHistory_.empty())return false;
    auto frame=std::move(navigationHistory_.back());navigationHistory_.pop_back();
    targetPart_=frame.soundPart;targetTrack_=frame.soundTrack;soundPlayer_=frame.soundPlayer;soundSerial_=frame.soundSerial;
    homeSoundEdit_=frame.soundEdit;
    picker_=frame.picker;tab_=frame.tab;editor_=frame.editor;
    keyboardEditPage_=frame.keyboardPage;panelMode_=frame.mode;globalSplitEditing_=frame.globalSplit;styleSelectorPlayer_=frame.styleSelectorTarget;
    kstCatalogTab_=frame.catalogTab;targetKbdSet_=frame.keyboardTarget;
    targetKbdPlayer_=frame.keyboardTargetPlayer;targetKbdSerial_=frame.keyboardTargetSerial;
    globalPage_=frame.globalPage;kstCatalogPage_=frame.catalogPage;
    if(editor_)setPage(frame.editorPage);
    if(picker_==Picker::Style||picker_==Picker::Sound||picker_==Picker::KeyboardSet||
       picker_==Picker::Split||picker_==Picker::KstFolder||picker_==Picker::Set){
        pickerPage_=frame.listPage;pickerCategory_=frame.listCategory;
        pickerDirectory_=std::move(frame.listDirectory);stylePickerError_=std::move(frame.listError);
        entries_=std::move(frame.listEntries);if(picker_==Picker::Sound)sounds_=std::move(frame.listSounds);
    }
    held_={};dragging_=false;pointerActive_=false;dirty_=true;return true;
}
void ArrangerView::openKeyboardSetSelector(int position){
    if(kstJob_||persistentRestoreActive_)return;
    const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
    if(position>3)return;
    if(position>=0&&owner.styleSwitchPending){showToast("Wait for the next Style",3500);return;}
    cancelKeyboardSetHold();
    choosingPerformance_=false;liveSlot_=-1;
    openPicker(Picker::KeyboardSet);
    if(picker_!=Picker::KeyboardSet&&picker_!=Picker::SavedKeyboardLibrary&&
       !(picker_==Picker::KstCatalog&&kstCatalogTab_==2))return;
    if(homeSoundEdit_)closeSoundWindow();
    editor_=false;
    targetKbdSet_=position;targetKbdPlayer_=position>=0?selectedPlayer_:-1;
    targetKbdSerial_=position>=0?owner.styleSelectionSerial:0;
    dirty_=true;
}
bool ArrangerView::keyboardSetTargetValid(int position){
    if(position<0)return true;
    const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
    if(position<4&&targetKbdSet_==position&&targetKbdPlayer_==selectedPlayer_&&
       targetKbdSerial_==owner.styleSelectionSerial&&!owner.styleSwitchPending)return true;
    targetKbdSet_=-1;targetKbdPlayer_=-1;targetKbdSerial_=0;
    showToast("Style changed. Select the Keyboard Set position again.",4500);return false;
}
void ArrangerView::cancelKeyboardSetHold(){
    keyboardHoldPosition_=-1;keyboardHoldDeadline_=0;keyboardHoldStyleKey_.clear();keyboardHoldStyleSerial_=0;
}
void ArrangerView::armKeyboardSetHold(int position,const RectF& rect){
    cancelKeyboardSetHold();
    if(!pointerActive_||editor_||picker_!=Picker::None||position<0||position>3||selectedKeyboardSet_!=position||styleKeyboardCue_.serial!=0)return;
    keyboardHoldPosition_=position;keyboardHoldRect_=rect;
    const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
    keyboardHoldStyleKey_=arrangerStyleSelectionKey(owner);keyboardHoldStyleSerial_=owner.styleSelectionSerial;
    keyboardHoldDeadline_=(pointerEventTimeMs_>0?pointerEventTimeMs_:nowMs())+1000;
}
void ArrangerView::panelExit(){
    if(soundWindowVisible()){
        if(eqNumberField_>=0){eqNumberField_=-1;dirty_=true;return;}
        if(soundResetPanel_){soundResetPanel_=false;dirty_=true;}
        else if(!toneDetail_.empty()){toneDetail_.clear();dirty_=true;}
        else closeSoundWindow();
        return;
    }
    if(picker_==Picker::None&&tab_==Tab::Main&&choosingPerformance_){
        choosingPerformance_=false;liveSlot_=-1;dirty_=true;return;
    }
    cancelKeyboardSetHold();resetTempoWheelGesture();held_={};dragging_=false;pointerActive_=false;
    if((resourceSaveNameEditing_||scaleNameEditing_||mediaNameEditing_)&&editor_){
        SilvetonSamplerView::keyDown(Key::Escape);dirty_=true;return;
    }
    if(editor_&&SilvetonSamplerView::dialogOpen()){
        SilvetonSamplerView::keyDown(Key::Escape);dirty_=true;return;
    }
    if(picker_==Picker::KstReport&&!kstDetail_.empty()){
        kstDetail_.clear();kstReportPage_=kstReportListPage_;dirty_=true;return;
    }
    if(picker_==Picker::DrumKitEdit&&drumExitPrompt_){drumExitPrompt_=false;dirty_=true;return;}
    if(picker_==Picker::StyleControls&&fillControlSlot_>=0){fillControlSlot_=-1;dirty_=true;return;}
    if(picker_==Picker::StyleDrums&&drumParameter_){drumParameter_.reset();dirty_=true;return;}
    if(picker_==Picker::StyleDrums&&drumNote_>=0){drumNote_=-1;dirty_=true;return;}
    if(picker_==Picker::DrumKitEdit&&drumGroupEdit_>=0){drumGroupEdit_=-1;dirty_=true;return;}
    if(picker_==Picker::KeyboardEdit&&choosingRangeElement_){choosingRangeElement_=false;dirty_=true;return;}
    if(picker_==Picker::KeyboardEdit&&fxChoosing_){fxChoosing_=false;dirty_=true;return;}
    const auto previous=picker_;
    if(previous==Picker::DrumKitEdit&&drumDraft_&&drumDraft_->dirty){
        drumExitPrompt_=true;dirty_=true;return;
    }
    if(previous==Picker::DrumKitEdit){drumDraft_.reset();drumExitPrompt_=false;}
    if(previous==Picker::KstSample||previous==Picker::DrumKitEdit||previous==Picker::SetSoundInfo)
        host::arrangerHost().stopPcmPreview();
    if(previous==Picker::KstProgress){
        closeKstScan();
        // A failed/cancelled MEDIA restore has already restored its own page.
        if(picker_==Picker::Media&&previous!=Picker::Media){dirty_=true;return;}
    }
    if(previous==Picker::SaveAsMenu){picker_=Picker::WriteMenu;dirty_=true;return;}
    // All entry points to a detail page now save the actual caller. A Back
    // button, hardware EXIT and Android Back use this same path.
    if(restoreNavigation())return;
    if(previous==Picker::KeyboardEdit){picker_=Picker::HomeMenu;dirty_=true;return;}
    picker_=Picker::None;editor_=false;panelMode_=PanelMode::Home;tab_=Tab::Main;
    targetTrack_=-1;targetPart_=0;targetKbdSet_=-1;targetKbdPlayer_=-1;targetKbdSerial_=0;
    dirty_=true;
}
void ArrangerView::openPanelFile(){
    if(leaveInstrumentEditor())return;
    
    cancelKeyboardSetHold();
    if(panelMode_!=PanelMode::File){openMedia();return;}
    if(kstJob_||persistentRestoreActive_)closeKstScan();
    if(picker_!=Picker::Media){returnToModeMenu();return;}
    while(!navigationHistory_.empty()){
        const bool previousMode=navigationHistory_.back().mode!=PanelMode::File;
        (void)restoreNavigation();if(previousMode)return;
    }
    home();
}
void ArrangerView::openPanelSettings(){
    if(leaveInstrumentEditor())return;
    
    cancelKeyboardSetHold();
    if(kstJob_||persistentRestoreActive_)return;
    if(panelMode_==PanelMode::Settings&&picker_==Picker::SettingsMenu&&globalPage_==GlobalPage::Menu){
        while(!navigationHistory_.empty()){
            const bool previousMode=navigationHistory_.back().mode!=PanelMode::Settings;
            (void)restoreNavigation();if(previousMode)return;
        }
        home();return;
    }
    if(panelMode_==PanelMode::Settings){returnToModeMenu();return;}
    rememberNavigation();panelMode_=PanelMode::Settings;picker_=Picker::SettingsMenu;globalPage_=GlobalPage::Menu;editor_=false;held_={};dirty_=true;
}
void ArrangerView::returnToModeMenu(){
    const auto mode=panelMode_;
    const auto root=mode==PanelMode::File?Picker::Media:Picker::SettingsMenu;
    const auto isRoot=[&](const NavigationFrame& frame){return frame.mode==mode&&frame.picker==root&&
        (mode!=PanelMode::Settings||frame.globalPage==GlobalPage::Menu);};
    if(picker_==root&&(mode!=PanelMode::Settings||globalPage_==GlobalPage::Menu))return;
    while(!navigationHistory_.empty()&&navigationHistory_.back().mode==mode){
        const bool found=isRoot(navigationHistory_.back());(void)restoreNavigation();if(found)return;
    }
    picker_=root;globalPage_=GlobalPage::Menu;editor_=false;held_={};dirty_=true;
}
void ArrangerView::panelMenu(){
    if(leaveInstrumentEditor())return;
    
    cancelKeyboardSetHold();
    if(kstJob_||persistentRestoreActive_)return;
    if(panelMode_!=PanelMode::Home){returnToModeMenu();return;}
    if(picker_==Picker::HomeMenu){panelExit();return;}
    rememberNavigation();picker_=Picker::HomeMenu;editor_=false;held_={};dirty_=true;
}
