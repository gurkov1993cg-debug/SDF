// EXIT closes the current overlay before returning to its underlying page.
// MEDIA and GLOBAL are real modes; MENU is scoped to the active mode.
void ArrangerView::rememberNavigation(){
    NavigationFrame frame{picker_,tab_,editor_,keyboardEditPage_,panelMode_,globalSplitEditing_,styleSelectorPlayer_,kstCatalogTab_,targetKbdSet_,globalPage_};
    frame.soundEdit=homeSoundEdit_;
    const bool soundPicker=frame.picker==Picker::Sound||(frame.picker==Picker::KstCatalog&&(frame.catalogTab==1||frame.catalogTab==3));
    if(soundPicker){frame.soundPart=targetPart_;frame.soundTrack=targetTrack_;}
    frame.soundPlayer=soundPlayer_;frame.soundSerial=soundSerial_;
    if(frame.picker==Picker::WriteMenu||frame.picker==Picker::SaveAsMenu)frame.picker=Picker::None;
    if(frame.picker==Picker::KstProgress||frame.picker==Picker::KstReport){
        frame.picker=frame.mode==PanelMode::File?Picker::Media:Picker::None;
    }
    const bool styleSelector=frame.picker==Picker::Style||frame.picker==Picker::SavedStyleLibrary||
        (frame.picker==Picker::KstCatalog&&frame.catalogTab==0);
    if(!styleSelector)frame.styleSelectorTarget=-1;
    if(frame.picker!=Picker::KstCatalog)frame.catalogTab=0;
    if(frame.picker!=Picker::KstCatalog&&frame.picker!=Picker::KeyboardSet&&frame.picker!=Picker::SavedKeyboardLibrary)
        frame.keyboardTarget=-1;
    if(frame.keyboardTarget>=0){frame.keyboardTargetPlayer=targetKbdPlayer_;frame.keyboardTargetSerial=targetKbdSerial_;}
    if(frame.picker!=Picker::SettingsMenu)frame.globalPage=GlobalPage::Menu;
    const auto same=[](const NavigationFrame& a,const NavigationFrame& b){
        return std::tie(a.picker,a.tab,a.editor,a.keyboardPage,a.mode,a.globalSplit,a.styleSelectorTarget,a.catalogTab,a.keyboardTarget,a.globalPage,a.soundPart,a.soundTrack,a.soundPlayer,a.soundSerial,a.soundEdit,a.keyboardTargetPlayer,a.keyboardTargetSerial)==
            std::tie(b.picker,b.tab,b.editor,b.keyboardPage,b.mode,b.globalSplit,b.styleSelectorTarget,b.catalogTab,b.keyboardTarget,b.globalPage,b.soundPart,b.soundTrack,b.soundPlayer,b.soundSerial,b.soundEdit,b.keyboardTargetPlayer,b.keyboardTargetSerial);
    };
    if(!navigationHistory_.empty()&&same(navigationHistory_.back(),frame))return;
    if(navigationHistory_.size()>=16U)navigationHistory_.erase(navigationHistory_.begin());
    navigationHistory_.push_back(frame);
}
bool ArrangerView::restoreNavigation(){
    if(navigationHistory_.empty())return false;
    const auto frame=navigationHistory_.back();navigationHistory_.pop_back();
    targetPart_=frame.soundPart;targetTrack_=frame.soundTrack;soundPlayer_=frame.soundPlayer;soundSerial_=frame.soundSerial;
    homeSoundEdit_=frame.soundEdit;
    picker_=frame.picker;tab_=frame.tab;editor_=frame.editor;
    keyboardEditPage_=frame.keyboardPage;panelMode_=frame.mode;globalSplitEditing_=frame.globalSplit;styleSelectorPlayer_=frame.styleSelectorTarget;
    kstCatalogTab_=frame.catalogTab;targetKbdSet_=frame.keyboardTarget;
    targetKbdPlayer_=frame.keyboardTargetPlayer;targetKbdSerial_=frame.keyboardTargetSerial;
    globalPage_=frame.globalPage;held_={};dragging_=false;dirty_=true;return true;
}
void ArrangerView::openKeyboardSetSelector(int position){
    if(kstJob_||persistentRestoreActive_)return;
    const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
    if(position>3)return;
    if(position>=0&&owner.styleSwitchPending){showToast("Wait for the next Style",3500);return;}
    cancelKeyboardSetHold();
    choosingPerformance_=false;liveSlot_=-1;
    openPicker(Picker::KeyboardSet);
    if(picker_!=Picker::KeyboardSet&&picker_!=Picker::SavedKeyboardLibrary&&
       !(picker_==Picker::KstCatalog&&kstCatalogTab_==2))return;
    if(homeSoundEdit_)closeSoundWindow();
    editor_=false;
    targetKbdSet_=position;targetKbdPlayer_=position>=0?selectedPlayer_:-1;
    targetKbdSerial_=position>=0?owner.styleSelectionSerial:0;
    dirty_=true;
}
bool ArrangerView::keyboardSetTargetValid(int position){
    if(position<0)return true;
    const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
    if(position<4&&targetKbdSet_==position&&targetKbdPlayer_==selectedPlayer_&&
       targetKbdSerial_==owner.styleSelectionSerial&&!owner.styleSwitchPending)return true;
    targetKbdSet_=-1;targetKbdPlayer_=-1;targetKbdSerial_=0;
    showToast("Style changed. Select the Keyboard Set position again.",4500);return false;
}
void ArrangerView::cancelKeyboardSetHold(){
    keyboardHoldPosition_=-1;keyboardHoldDeadline_=0;keyboardHoldStyleKey_.clear();keyboardHoldStyleSerial_=0;
}
void ArrangerView::armKeyboardSetHold(int position,const RectF& rect){
    cancelKeyboardSetHold();
    if(!pointerActive_||editor_||picker_!=Picker::None||position<0||position>3||selectedKeyboardSet_!=position||styleKeyboardCue_.serial!=0)return;
    keyboardHoldPosition_=position;keyboardHoldRect_=rect;
    const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
    keyboardHoldStyleKey_=arrangerStyleSelectionKey(owner);keyboardHoldStyleSerial_=owner.styleSelectionSerial;
    keyboardHoldDeadline_=(pointerEventTimeMs_>0?pointerEventTimeMs_:nowMs())+1000;
}
void ArrangerView::panelExit(){
    if(soundWindowVisible()){
        if(eqNumberField_>=0){eqNumberField_=-1;dirty_=true;return;}
        if(soundResetPanel_){soundResetPanel_=false;dirty_=true;}
        else if(!toneDetail_.empty()){toneDetail_.clear();dirty_=true;}
        else closeSoundWindow();
        return;
    }
    if(picker_==Picker::None&&tab_==Tab::Main&&choosingPerformance_){
        choosingPerformance_=false;liveSlot_=-1;dirty_=true;return;
    }
    cancelKeyboardSetHold();resetTempoWheelGesture();held_={};dragging_=false;pointerActive_=false;
    if((resourceSaveNameEditing_||scaleNameEditing_||mediaNameEditing_)&&editor_){
        SilvetonSamplerView::keyDown(Key::Escape);dirty_=true;return;
    }
    if(editor_&&SilvetonSamplerView::dialogOpen()){
        SilvetonSamplerView::keyDown(Key::Escape);dirty_=true;return;
    }
    if(picker_==Picker::StyleControls&&fillControlSlot_>=0){fillControlSlot_=-1;dirty_=true;return;}
    if(picker_==Picker::StyleDrums&&drumParameter_){drumParameter_.reset();dirty_=true;return;}
    if(picker_==Picker::StyleDrums&&drumNote_>=0){drumNote_=-1;dirty_=true;return;}
    if(picker_==Picker::DrumKitEdit&&drumGroupEdit_>=0){drumGroupEdit_=-1;dirty_=true;return;}
    if(picker_==Picker::KeyboardEdit&&choosingRangeElement_){choosingRangeElement_=false;dirty_=true;return;}
    if(picker_==Picker::KeyboardEdit&&fxChoosing_){fxChoosing_=false;dirty_=true;return;}
    const auto previous=picker_;
    if(previous==Picker::DrumKitEdit&&drumDraft_&&drumDraft_->dirty){
        drumExitPrompt_=true;dirty_=true;return;
    }
    if(previous==Picker::DrumKitEdit){drumDraft_.reset();drumExitPrompt_=false;}
    if(previous==Picker::KstSample||previous==Picker::DrumKitEdit||previous==Picker::SetSoundInfo)
        host::arrangerHost().stopPcmPreview();
    if(previous==Picker::KstProgress||previous==Picker::KstReport){
        closeKstScan();
        // A failed/cancelled MEDIA restore has already restored its own page.
        if(picker_==Picker::Media&&previous!=Picker::Media){dirty_=true;return;}
    }
    if(previous==Picker::SaveAsMenu){picker_=Picker::WriteMenu;dirty_=true;return;}
    if(previous==Picker::StyleInfo||previous==Picker::StyleRead||previous==Picker::KeyboardSetRead||previous==Picker::KstSample){
        const auto underlying=previous==Picker::StyleInfo?styleInfoReturn_:
            previous==Picker::KstSample?Picker::KstCatalog:contentsReturn_;
        if(!navigationHistory_.empty()&&navigationHistory_.back().picker==underlying)(void)restoreNavigation();
        else{picker_=underlying;editor_=false;dirty_=true;}
        return;
    }
    if(restoreNavigation())return;
    if(previous==Picker::KeyboardEdit){picker_=Picker::HomeMenu;dirty_=true;return;}
    if(previous!=Picker::None||editor_){picker_=Picker::None;editor_=false;panelMode_=PanelMode::Home;dirty_=true;return;}
    tab_=Tab::Main;panelMode_=PanelMode::Home;dirty_=true;
}
void ArrangerView::openPanelFile(){
    if(leaveInstrumentEditor())return;
    
    cancelKeyboardSetHold();
    if(panelMode_!=PanelMode::File){openMedia();return;}
    if(kstJob_||persistentRestoreActive_)closeKstScan();
    while(!navigationHistory_.empty()){
        const bool previousMode=navigationHistory_.back().mode!=PanelMode::File;
        (void)restoreNavigation();if(previousMode)return;
    }
    home();
}
void ArrangerView::openPanelSettings(){
    if(leaveInstrumentEditor())return;
    
    cancelKeyboardSetHold();
    if(kstJob_||persistentRestoreActive_)return;
    if(panelMode_==PanelMode::Settings&&picker_==Picker::SettingsMenu&&globalPage_==GlobalPage::Menu){
        while(!navigationHistory_.empty()){
            const bool previousMode=navigationHistory_.back().mode!=PanelMode::Settings;
            (void)restoreNavigation();if(previousMode)return;
        }
        home();return;
    }
    rememberNavigation();panelMode_=PanelMode::Settings;picker_=Picker::SettingsMenu;globalPage_=GlobalPage::Menu;editor_=false;held_={};dirty_=true;
}
void ArrangerView::panelMenu(){
    if(leaveInstrumentEditor())return;
    
    cancelKeyboardSetHold();
    if(kstJob_||persistentRestoreActive_)return;
    if(panelMode_==PanelMode::File){picker_=Picker::Media;editor_=false;held_={};dirty_=true;return;}
    if(panelMode_==PanelMode::Settings){
        if(picker_!=Picker::SettingsMenu||globalPage_!=GlobalPage::Menu)rememberNavigation();
        picker_=Picker::SettingsMenu;globalPage_=GlobalPage::Menu;editor_=false;held_={};dirty_=true;return;
    }
    if(picker_==Picker::HomeMenu){panelExit();return;}
    rememberNavigation();picker_=Picker::HomeMenu;editor_=false;held_={};dirty_=true;
}
