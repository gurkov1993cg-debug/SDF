// Supplemental Pa5X HOME panes.  Every actionable control calls an existing
// audio-owned host/editor operation.  Unsupported Korg DSP is stated explicitly
// rather than replaced with a nonfunctional painted widget.
void ArrangerView::drawMicGuitar(Canvas& c){
    const auto& p=players_[static_cast<std::size_t>(selectedPlayer_)];
    const bool hasStyle=p.loaded&&!p.styleSwitchPending;
    box(c,{10,165,790,168},green);
    label(c,"Mic & Guitar",20,194,21,white,true);
    box(c,{15,209,387,416},panel,kBorder,6);
    box(c,{399,209,785,416},panel,green,6);
    label(c,"MIC",29,238,18,dim,true);
    label(c,"Mic input / vocal DSP",29,270,16,white,true,339);
    label(c,"Not connected in this Android audio host.",29,296,12,dim,false,339);
    label(c,"No fake mic faders or vocal FX.",29,319,12,dim,false,339);
    label(c,"GUITAR  /  STYLE TRACKS",414,239,18,green,true,351);
    label(c,hasStyle?p.name:"Load a Style to access Guitar Mode",414,269,14,white,false,356);
    label(c,"ACC Guitar Mode and its source settings",414,296,12,dim,false,352);
    button(c,{414,314,590,354},"Guitar Mode",green,false,hasStyle,[this]{
        trackEditPlayer_=selectedPlayer_;openKeyboardEdit(KeyboardEditPage::Guitar);
    },14);
    button(c,{598,314,771,354},"Guitar FX",green,false,hasStyle,[this]{
        trackEditPlayer_=selectedPlayer_;openKeyboardEdit(KeyboardEditPage::Effects);
    },14);
    button(c,{414,361,771,402},"Choose Style / Guitar Track",green,false,true,[this]{
        openStyleSelectorForPlayer(selectedPlayer_);
    },13);
}

void ArrangerView::drawJukebox(Canvas& c){
    box(c,{10,165,790,168},orange);
    label(c,"Jukebox",20,195,21,white,true);
    label(c,"Two live Style players. MIDI / MP3 Song Jukebox is not implemented.",20,218,12,dim,false,765);
    for(int player=0;player<2;++player){
        const auto& p=players_[static_cast<std::size_t>(player)];
        const float x=14.0F+player*392.0F;
        const ColorInt accent=player==0?orange:blue;
        box(c,{x,231,x+382,364},panel,player==selectedPlayer_?accent:kBorder,5);
        label(c,"PLAYER "+std::to_string(player+1),x+12,254,16,accent,true);
        label(c,p.loaded?p.name:"No Style selected",x+12,285,18,white,true,350);
        button(c,{x+12,304,x+134,348},"Style...",accent,false,true,[this,player]{openStyleSelectorForPlayer(player);},14);
        const bool canPlay=p.playing||(p.loaded&&p.soundAssignmentsReady&&!p.styleSwitchPending);
        button(c,{x+142,304,x+257,348},p.playing?"Stop":"Start",accent,p.playing,canPlay,
            [this,player]{startStopPlayer(player);},14);
        button(c,{x+266,304,x+370,348},"Focus",accent,player==selectedPlayer_,true,
            [this,player]{setPlayerFocus(player);},13);
    }
    const float mix=host::arrangerHost().crossfade();
    box(c,{15,377,785,417},panel,kBorder,5);
    label(c,"P1",26,403,15,orange,true);
    label(c,"P2",775,403,15,blue,true,40,Align::Right);
    constexpr float left=85.0F, right=714.0F;
    const float thumb=left+(right-left)*std::clamp(mix,0.0F,1.0F);
    box(c,{left,394,right,400},dim);
    box(c,{thumb-12,385,thumb+12,410},green,0,5);
    hit({left,378,right,418},{},[this](float x,float){
        constexpr float l=85.0F,r=714.0F;
        movePlayerFader(std::clamp((x-l)/(r-l),0.0F,1.0F));
    });
}

void ArrangerView::drawMatrix(Canvas& c){
    const auto& p=players_[static_cast<std::size_t>(selectedPlayer_)];
    const bool enabled=p.loaded&&!p.styleSwitchPending;
    box(c,{10,165,790,168},orange);
    label(c,"Matrix",20,192,21,white,true);
    label(c,"Style-section triggers (original Pa5X Pad Matrix not yet available)",20,208,12,dim,false,762);
    // VAR x4, FILL x4, INTRO x3 + BREAK, ENDING x3 + AUTO FILL.
    static constexpr int elements[16]={3,4,5,6,7,8,9,10,0,1,2,11,12,13,14,-1};
    static constexpr const char* names[16]={
        "VAR 1","VAR 2","VAR 3","VAR 4",
        "FILL 1","FILL 2","FILL 3","FILL 4",
        "INTRO 1","INTRO 2","INTRO 3","BREAK",
        "ENDING 1","ENDING 2","ENDING 3","AUTO FILL"
    };
    for(int i=0;i<16;++i){
        const int element=elements[i];
        const float x=14.0F+(i%4)*194.0F,y=219.0F+(i/4)*49.5F;
        const RectF r{x,y,x+185,y+45};
        const bool available=element<0?enabled:enabled&&p.available[element];
        const bool active=element<0?p.autoFill:p.element==element;
        const bool queued=element>=0&&p.pendingElement==element&&available;
        box(c,r,active?orange:panel,queued?green:active?orange:kBorder,4);
        label(c,names[i],r.centerX(),r.centerY()+6,16,active?bg:available?white:dim,true,r.width()-8,Align::Center);
        if(available){
            if(element<0)hit(r,[this]{controlRequested(host::arrangerHost().toggleAutoFill(selectedPlayer_));});
            else hit(r,[this,element,player=selectedPlayer_]{controlRequested(host::arrangerHost().selectElement(player,element));});
        }
    }
}

void ArrangerView::drawKaoss(Canvas& c){
    box(c,{10,165,790,168},green);
    label(c,"Kaoss",20,194,21,white,true);
    box(c,{17,208,782,411},panel,kBorder,6);
    label(c,"Live FX",35,245,22,green,true);
    label(c,"Korg Kaoss XY DSP is not implemented in the current engine.",35,277,14,white,false,720);
    label(c,"Use the working effect editors below. No simulated XY controller.",35,305,13,dim,false,720);
    button(c,{35,338,392,390},"Keyboard / Master FX",green,false,true,[this]{
        trackEditPlayer_=-1;openKeyboardEdit(KeyboardEditPage::Effects);
    },16);
    button(c,{410,338,758,390},"Pa5X FX Catalog",green,false,true,[this]{
        openPa5xFxCatalog();
    },16);
}
