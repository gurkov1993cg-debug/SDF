// Explicit overwrite of an original Keyboard Set's visible catalog entry.
// The Korg resource stays immutable; a source/revision-bound SILVETON pointer
// selects a full saved performance. Autosession never publishes this pointer.
namespace {
std::string sourceKeyboardOverwriteName(const std::string& source,unsigned collision){
    return "ARRANGER_SOURCE_KBD_"+keyboardFxHex(keyboardMetadataHash(files::absolute(source)))+
        (collision==0U?std::string{}:"_"+std::to_string(collision))+".ref";
}
std::set<std::string> sourceKeyboardOverwriteFiles(const std::string& parent,const std::string& source){
    std::set<std::string> result;
    const auto prefix="ARRANGER_SOURCE_KBD_"+keyboardFxHex(keyboardMetadataHash(files::absolute(source)));
    for(const auto& name:files::listNames(parent))
        if(startsWith(name,prefix)&&endsWith(name,".ref"))result.insert(name);
    return result;
}
}

bool ArrangerView::findSourceKeyboardOverwrite(const std::string& source,
        const arranger::Pa5xKeyboardSetRead& read,std::string& entryPath,std::string& error) const {
    entryPath.clear();error.clear();
    if(source.empty()||persistentSessionPath_.empty())return true;
    const auto parent=files::parentOf(persistentSessionPath_);
    const auto canonical=files::absolute(source);
    const auto primary=files::join(parent,sourceKeyboardOverwriteName(source,0U));
    // A missing primary is the normal unsaved-resource path: one stat, no
    // directory scan or extra full source read on every Keyboard Set change.
    if(!files::exists(primary))return true;
    SavedKeyboardEntry first;
    if(!readSavedKeyboardEntry(primary,first,error)){
        error="Saved changes for this Keyboard Set could not be read; current sounds were kept";return false;
    }
    std::string identity;
    if(!keyboardFxRevision(source,read,identity,error))return false;
    if(files::absolute(first.sourcePath)==canonical){
        if(first.identity==identity)entryPath=primary;
        else error="The original Keyboard Set changed; earlier saved edits were kept and not applied";
        return true;
    }
    // Only an actual path-hash collision scans its real bucket. Full source
    // and revision/role identities, never the file-name hash, decide the match.
    const auto profiles=sourceKeyboardOverwriteFiles(parent,source);
    bool previousRevision=false;
    for(unsigned collision=1;collision<1000U;++collision){
        const auto filename=sourceKeyboardOverwriteName(source,collision);
        if(profiles.find(filename)==profiles.end())continue;
        const auto path=files::join(parent,filename);
        SavedKeyboardEntry entry;std::string issue;
        if(!readSavedKeyboardEntry(path,entry,issue)){
            error="Saved changes for this Keyboard Set could not be read; current sounds were kept";return false;
        }
        if(files::absolute(entry.sourcePath)!=canonical)continue;
        if(entry.identity==identity){entryPath=path;return true;}
        previousRevision=true;
    }
    if(previousRevision)error="The original Keyboard Set changed; earlier saved edits were kept and not applied";
    return true;
}

bool ArrangerView::commitSourceKeyboardOverwrite(const std::string& name){
    if(persistentSessionPath_.empty()||activeNativeKeyboardSetPath_.empty()||!ctrl_.engine.nativeKeyboardCombi()){
        showToast("This Keyboard Set has no current source destination; use Save As",6000);return false;
    }
    if(name.empty()||name.size()>256U||name.find_first_of("\r\n")!=std::string::npos){
        showToast("Choose a valid Keyboard Set name",5000);return false;
    }
    // An Immediate Style preview has a new Sound context while the old Style
    // still owns the four positions. Never reinterpret that as a source save.
    if(styleKeyboardCue_.serial!=0){
        showToast("Wait for the Style change to finish before saving",5000);return false;
    }
    if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4){
        showToast("Save this Keyboard Set to its current Style position",5000);return false;
    }
    if(!activeSavedKeyboardEntryPath_.empty()&&
       !startsWith(files::nameOf(activeSavedKeyboardEntryPath_),"ARRANGER_SOURCE_KBD_")){
        showToast("The current saved destination is unavailable; select it again or use Save As",6000);return false;
    }
    auto state=captureKeyboardWorkingSet();std::string frozenPath,error;
    if(!freezeKeyboardWorkingSet(state,"Source "+files::absolute(state.sourcePath),0,name,frozenPath,error)){
        showToast(error,6500);return false;
    }
    SavedKeyboardEntry frozen;
    if(!readSavedKeyboardEntry(frozenPath,frozen,error)){showToast(error,6500);return false;}
    const auto parent=files::parentOf(persistentSessionPath_);
    const auto canonical=files::absolute(state.sourcePath);
    const auto primary=files::join(parent,sourceKeyboardOverwriteName(state.sourcePath,0U));
    std::string destination;
    if(!files::exists(primary))destination=primary;
    else{
        SavedKeyboardEntry first;
        if(!readSavedKeyboardEntry(primary,first,error)){
            showToast("The previous saved destination could not be read; it was kept",6500);return false;
        }
        if(files::absolute(first.sourcePath)==canonical)destination=primary;
        else{
            const auto profiles=sourceKeyboardOverwriteFiles(parent,state.sourcePath);
            std::string firstEmpty;
            for(unsigned collision=1;collision<1000U;++collision){
                const auto filename=sourceKeyboardOverwriteName(state.sourcePath,collision);
                const auto path=files::join(parent,filename);
                if(profiles.find(filename)==profiles.end()){if(firstEmpty.empty())firstEmpty=path;continue;}
                SavedKeyboardEntry entry;
                if(!readSavedKeyboardEntry(path,entry,error)){
                    showToast("The previous saved destination could not be read; it was kept",6500);return false;
                }
                if(files::absolute(entry.sourcePath)==canonical){destination=path;break;}
            }
            if(destination.empty())destination=firstEmpty;
        }
    }
    if(destination.empty()){showToast("A source save destination could not be allocated",6500);return false;}
    std::ostringstream record;record<<"SILVETON_USER_KEYBOARD_SET 1\n0 1\n"<<std::quoted(name)<<'\n'
        <<std::quoted(frozen.sourcePath)<<'\n'<<std::quoted(frozen.identity)<<'\n'<<std::quoted(frozen.metadataFile)<<'\n';
    const auto pending=destination+".pending";
    if(!files::writeText(pending,record.str())||std::rename(pending.c_str(),destination.c_str())!=0){
        (void)files::removeRecursively(pending);
        showToast("Keyboard Set was not saved; its previous destination was kept",6500);return false;
    }
    activeSavedKeyboardEntryPath_=destination;
    keyboardMetadataFile_=state.metadataFile;keyboardMetadataSavedBindings_=state.metadataBindings;
    keyboardMetadataSavedState_=state.combi;keyboardFxOverride_.identity=frozen.identity;
    persistentSaveAllowed_=true;persistentRecordProtected_=false;
    // Naming an explicitly saved resource is not a full recall or a restart.
    (void)ctrl_.engine.nativeApplyKeyboardCombi(*state.combi,true);
    refresh();markPersistentStateChanged();flushPersistentState();
    showToast("Keyboard Set saved over the current entry",4500);return true;
}
