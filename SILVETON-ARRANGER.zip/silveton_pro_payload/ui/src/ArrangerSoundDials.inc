// Both entry points edit the same COMBI. A gesture follows its own published
// revisions, and stops if a preset switch replaces its target.
void ArrangerView::drawPartSoundDials(Canvas& c,bool home,int player,int part,std::uint64_t selection,
                                     const std::shared_ptr<const sampler::Combi>& snapshot,bool oneShot){
    using Part=sampler::UpperPart;
    using Owner=std::shared_ptr<const sampler::Combi>;
    using Write=std::function<void(Part&,float)>;
    const auto& u=snapshot->part(part);
    const auto& modulation=partModulation(u);
    const auto accent=player<0?liveMint:liveAmber;
    const auto context=std::to_string(home)+"/"+std::to_string(player)+"/"+std::to_string(part)+"/"+
        std::to_string(selection)+"/"+(player<0?combiName_+std::to_string(selectedKeyboardSet_):std::string{});
    if(context!=toneDetailContext_){toneDetail_.clear();toneDetailContext_=context;}
    const auto commit=[this,home,player,part,selection](Owner& owner,const Write& write,float value){
        if(!owner)return false;
        if(home){
            if(!homeSoundEdit_||homeTonePart_!=part||
               homeToneKeyboard_!=(player<0)||(player>=0&&selectedPlayer_!=player))return false;
        }else if(picker_!=Picker::KeyboardEdit||keyboardEditPage_!=KeyboardEditPage::SoundEdit||
                 trackEditPlayer_!=player||(player<0?keyboardEditPart_:styleEditTrack_)!=part)return false;
        if(player<0){
            if(ctrl_.engine.nativeKeyboardCombi()!=owner){showToast("The Keyboard Set changed during the edit",3000);return false;}
            auto next=*owner;write(next.part(part),value);
            if(!ctrl_.engine.nativeApplyKeyboardCombi(next,true)){showToast(ctrl_.engine.nativeLastTextError(),4000);return false;}
            owner=ctrl_.engine.nativeKeyboardCombi();
        }else{
            if(!host::arrangerHost().editStyleCombi(player,selection,[&](auto& next){write(next.part(part),value);},owner.get())){
                showToast(host::arrangerHost().lastError(),4000);return false;
            }
            std::uint64_t serial=0;owner=host::arrangerHost().styleTrackCombi(player,serial);
            if(serial!=selection){owner.reset();return false;}
        }
        markPersistentStateChanged(false);dirty_=true;return true;
    };
    const auto apply=[snapshot,commit](const Write& write,float v){Owner owner=snapshot;commit(owner,write,v);};
    const RectF body=home?RectF{28,300,1612,816}:RectF{12,90,703,353};
    const auto editButton=[&](const RectF& r,const std::string& name,bool on,std::function<void()> action){
        box(c,r,on?accent:liveCard,on?accent:liveLine,5);
        label(c,name,r.centerX(),r.centerY()+(home?7:5),home?21:15,on?liveBg:liveText,true,r.width()-6,Align::Center);
        if(action)hit(r,std::move(action));
    };
    const char* pages[]{"Tone","Voice","EQ","Strip Gate"};
    for(int i=0;i<4;++i){
        const RectF r=home?RectF{28+i*206.0F,221,226+i*206.0F,284}:RectF{12+i*174.0F,91,180+i*174.0F,131};
        editButton(r,pages[i],tonePage_==i,[this,i]{tonePage_=i;eqNumberField_=-1;toneDetail_.clear();dirty_=true;});
    }
    int slot=0;
    const auto cell=[&]{
        const int id=slot++;
        const int cols=5;
        const float left=home?28:12,top=home?301:136,w=((home?1612.0F:704.0F)-left)/cols;
        const float x=left+(id%cols)*w,y=top+(id/cols)*(home?258:108);
        return RectF{x,y,x+w-(home?9:3),y+(home?247:105)};
    };
    const auto hitsBefore=hits_.size();
    std::function<void()> overlay;
    const auto overlayHeader=[&](const std::string& title){
        hits_.resize(hitsBefore);
        box(c,body,liveBg,liveLine,6);
        hit(body,[]{});
        label(c,title,body.left+16,body.top+(home?35:43),home?26:22,accent,true,body.width()*.68F);
        editButton({body.right-(home?230:115),body.top+4,body.right-5,body.top+(home?68:55)},"‹ Back",false,[this]{toneDetail_.clear();dirty_=true;});
    };
    enum class Scale { Linear, Time, Frequency };
    const auto dial=[&](const char* title,float current,float low,float high,float step,Scale scale,bool inherited,bool enabled,
                        const std::function<std::string(float)>& format,const Write& write,float resetValue,bool bipolar=false,bool relative=false,std::string referenceText={}){
        const int id=slot;const RectF r=cell();
        const auto normalized=[=](float v){
            v=std::clamp(v,low,high);
            if(high<=low)return relative?.5F:0.0F;
            if(relative){
                const float range=v<0?-low:high;
                if(!range||v==0)return .5F;
                const float n=scale==Scale::Time?std::log1p(std::abs(v))/std::log1p(range):std::abs(v)/range;
                return .5F+std::copysign(.5F*n,v);
            }
            if(scale==Scale::Time)return std::log1p(v-low)/std::log1p(high-low);
            if(scale==Scale::Frequency)return std::log(v/low)/std::log(high/low);
            return (v-low)/(high-low);
        };
        const auto at=[=](float n){
            n=std::clamp(n,0.0F,1.0F);
            if(relative){
                const float side=2*n-1,range=side<0?-low:high;
                const float distance=scale==Scale::Time?std::expm1(std::abs(side)*std::log1p(range)):std::abs(side)*range;
                return std::clamp(std::round(std::copysign(distance,side)/step)*step,low,high);
            }
            float v=low+n*(high-low);
            if(scale==Scale::Time)v=low+std::expm1(n*std::log1p(high-low));
            if(scale==Scale::Frequency)v=low*std::pow(high/low,n);
            return std::clamp(std::round(v/step)*step,low,high);
        };
        const float displayed=toneDialPreview_==id?toneDialValue_:current;
        const float cx=r.centerX(),cy=r.top+(home?116.0F:44.0F),rad=home?62.0F:19.0F;
        const float arcRadius=rad+(home?5.5F:3.5F);
        const RectF arc{cx-arcRadius,cy-arcRadius,cx+arcRadius,cy+arcRadius};
        const float pos=normalized(displayed),angle=135.0F+270.0F*pos;
        Paint ink;ink.style=Style::Stroke;ink.strokeCap=Cap::Round;ink.strokeWidth=home?4:2.5F;
        ink.color=liveLine;c.drawArc(arc,135,270,false,ink);
        const float start=bipolar?135.0F+270.0F*normalized(0):135.0F;
        if(relative){
            ink.color=liveDim;c.drawLine(cx,cy-arcRadius-4,cx,cy-arcRadius+3,ink);
        }
        ink.color=enabled?accent:liveOff;
        if(std::abs(angle-start)>.1F)c.drawArc(arc,std::min(start,angle),std::abs(angle-start),false,ink);
        ink.style=Style::Fill;ink.color=liveLine;c.drawCircle(cx,cy,rad,ink);
        ink.color=liveKey;c.drawCircle(cx,cy,rad-1.5F,ink);
        const float radians=angle*.01745329252F;
        const float dx=std::cos(radians),dy=std::sin(radians);
        ink.color=enabled?liveText:liveOff;ink.strokeWidth=home?4:2.4F;
        c.drawLine(cx+dx*rad*.30F,cy+dy*rad*.30F,cx+dx*rad*.84F,cy+dy*rad*.84F,ink);
        label(c,title,cx,r.top+(home?32:14),home?26:14,enabled?liveText:liveDim,true,r.width()-4,Align::Center);
        const RectF number{r.left,r.bottom-(home?57.0F:32.0F),r.right,r.bottom};
        box(c,number,liveCard,liveLine,5);
        const std::string shown=format(displayed)+(inherited&&!relative&&toneDialPreview_!=id?" *":"");
        label(c,shown,cx,number.centerY()+(home?7:5),home?27:15,enabled?accent:liveDim,true,r.width()-4,Align::Center);
        if(!enabled||low>=high){
            if(oneShot&&player>=0&&std::strcmp(title,"Release")==0)
                hit(r,[this]{tonePage_=1;toneDetail_="Note Trigger";dirty_=true;});
            return;
        }
        const float travel=high-low<=8&&step==1?(high-low)*(home?20:15):(home?295:145);
        const auto fromY=[this,current,origin=normalized(current),travel,at](float y){
            const float delta=toneDialGrabY_-y;
            return std::abs(delta)<2?current:at(origin+delta/travel);
        };
        const auto move=[this,fromY,commit,write](float y){
            const float next=fromY(y);toneDialValue_=next;dirty_=true;
            if(!toneGestureOwner_||std::abs(next-toneGestureLast_)<.00001F)return;
            if(!commit(toneGestureOwner_,write,next))toneGestureOwner_.reset();
            toneGestureLast_=next;
        };
        hit({r.left,r.top,r.right,number.top},{},[this,id,current,snapshot,move](float,float y){
            if(toneDialPreview_!=id){
                toneDialGrabY_=y;toneDialPreview_=id;toneDialValue_=toneGestureLast_=current;
                toneGestureOwner_=snapshot;dirty_=true;
            }else move(y);
        },false,[move](float,float y){move(y);});
        auto& bound=hits_.back();
        bound.resetTarget={home?ResetSurface::HomeTone:ResetSurface::TrackTone,player,part,title,selection,
                           player<0?0:players_[player].soundRevision,player<0?snapshot:nullptr};
        bound.reset=[apply,write,resetValue]{apply(write,resetValue);};
        const auto boundCopy=bound;
        hit(number,[this,title]{toneDetail_=title;dirty_=true;});
        if(toneDetail_==title){
            const Hit dialGesture=boundCopy;
            overlay=[&,title,current,low,high,step,format,apply,write,resetValue,inherited,relative,referenceText,dialGesture,angle,displayed]{
                overlayHeader(std::string(title)+(referenceText.empty()?"   ·   Fine adjustment":"   ·   "+referenceText));
                if(home){
                    const float cx=body.centerX(),cy=body.top+250,rad=119;
                    Paint p;p.color=liveKey;c.drawCircle(cx,cy,rad,p);
                    p.style=Style::Stroke;p.strokeCap=Cap::Round;p.strokeWidth=8;p.color=liveLine;
                    const RectF arc{cx-rad-7,cy-rad-7,cx+rad+7,cy+rad+7};
                    c.drawArc(arc,135,270,false,p);p.color=accent;
                    if(angle>135)c.drawArc(arc,135,angle-135,false,p);
                    const float a=angle*.01745329252F;
                    c.drawLine(cx+std::cos(a)*rad*.55F,cy+std::sin(a)*rad*.55F,cx+std::cos(a)*rad*.9F,cy+std::sin(a)*rad*.9F,p);
                    label(c,format(displayed),cx,cy+14,36,liveText,true,rad*1.75F,Align::Center);
                    auto enlarged=dialGesture;enlarged.rect={cx-185,cy-153,cx+185,cy+153};hits_.push_back(std::move(enlarged));
                    editButton({body.left+120,cy-48,cx-250,cy+50},"−",false,[=]{apply(write,std::clamp(std::round((current-step)/step)*step,low,high));});
                    editButton({cx+250,cy-48,body.right-120,cy+50},"+",false,[=]{apply(write,std::clamp(std::round((current+step)/step)*step,low,high));});
                    editButton({cx-170,body.bottom-90,cx+170,body.bottom-16},(relative||resetValue==-1)?"Use Sound":"Reset",false,[=]{apply(write,resetValue);});
                    return;
                }
                const float w=body.width()/5,y=body.top+86,h=90;
                editButton({body.left+8,y,body.left+w-4,y+h},"−",false,[=]{apply(write,std::clamp(std::round((current-step)/step)*step,low,high));});
                label(c,format(current),body.left+2*w,y+h*.62F,home?32:26,liveText,true,2*w-8,Align::Center);
                editButton({body.left+3*w,y,body.left+4*w-5,y+h},"+",false,[=]{apply(write,std::clamp(std::round((current+step)/step)*step,low,high));});
                editButton({body.left+4*w,y,body.right-8,y+h},(relative||resetValue==-1)?"Use Sound":"Reset",false,[=]{apply(write,resetValue);});
                if(!home&&inherited&&!relative)label(c,"* Value from Sound",body.centerX(),body.bottom-15,15,liveDim,false,500,Align::Center);
            };
        }
    };
    const auto toggle=[&](const char* title,bool on,const char* offText,const char* onText,const Write& write){
        const auto r=cell();
        label(c,title,r.centerX(),r.top+(home?32:18),home?26:14,liveText,true,r.width()-3,Align::Center);
        editButton({r.left,r.top+(home?65:27),r.right,r.bottom-(home?50:4)},on?onText:offText,on,[apply,write,on]{apply(write,!on);});
    };
    const auto menu=[&](const char* title,std::vector<std::string> items,int value,std::function<void(int)> choose,bool withDamper=false){
        const auto r=cell();
        label(c,title,r.centerX(),r.top+(home?32:18),home?26:14,liveText,true,r.width()-3,Align::Center);
        const float bottom=withDamper?r.bottom-(home?90:44):r.bottom-(home?50:4);
        editButton({r.left,r.top+(home?65:27),r.right,bottom},items.at(value),false,[this,title]{toneDetail_=title;dirty_=true;});
        if(withDamper){
            editButton({r.left,bottom+4,r.right,r.bottom-4},u.damperEnabled?"Damper On":"Damper Off",u.damperEnabled,
                [apply,on=u.damperEnabled]{apply([](Part& d,float v){d.damperEnabled=v!=0;},!on);});
        }
        if(toneDetail_==title)overlay=[&,title,items=std::move(items),value,choose]{
            overlayHeader(title);
            const int columns=items.size()>5?4:int(items.size());
            const float w=(body.width()-16)/columns;
            for(unsigned i=0;i<items.size();++i){
                const float x=body.left+8+(i%columns)*w,y=body.top+(home?110:76)+(i/columns)*(home?139:82);
                editButton({x,y,x+w-5,y+(home?112:74)},items[i],int(i)==value,[this,choose,i,home]{choose(i);if(!home)toneDetail_.clear();dirty_=true;});
            }
        };
    };
    const auto units=[](std::string unit,int digits=0){return [=](float v){return fmtFixed(v,digits)+unit;};};
    const auto* layer=firstPartLayer(u);
    const auto effective=layer?sampler::effectiveLayerTone(*layer):sampler::effectiveUpperTone(u);
    std::array<float,6> source{{effective.attackMs,effective.decayMs,effective.sustain,effective.releaseMs,effective.cutoffHz,effective.resonance}};
    auto program=layer?layer->program:u.program;
    unsigned representative=0;
    if(player>=0&&activityPlayer_==player&&activitySerial_==selection&&activity_.sourcePrograms[part]){
        program=activity_.sourcePrograms[part];representative=activity_.representativeLayers[part];
    }
    const auto savedSoundEdits=player>=0?players_[static_cast<std::size_t>(player)].tracks[static_cast<std::size_t>(part)].sourceSoundEdits:u.sourceSoundEdits;
    if(program)editButton(home?RectF{856,221,1050,284}:RectF{715,210,797,257},"Source",false,
        [this,program,edits=savedSoundEdits]{openOriginalSoundSettings(program,edits);});
    // For engine-only parts use the sampler defaults without already applied overrides.
    if(!program){
        const sampler::EnvelopeParams env{};
        source[1]=env.decaySec*1000*(layer?1:u.ampDecayScale);
        source[2]=env.sustain*(layer?1:u.ampSustainScale);
    }
    if(program&&representative<program->layers.size()){
        const auto& src=program->layers[representative];
        const auto env=host::editableAmpEnvelope(src);
        const bool editing=partEnvelopeValue(u,1)>=0||partEnvelopeValue(u,2)>=0;
        source[0]=(editing||src.sourceAmpEnvelope.runtimeEnabled()?env.attackSec:src.ampEnvelope.attackSec)*1000*(layer?1:u.ampAttackScale);
        source[1]=env.decaySec*1000*(layer?1:u.ampDecayScale);
        source[2]=env.sustain*(layer?1:u.ampSustainScale);
        source[3]=env.releaseSec*1000*(layer?1:u.ampReleaseScale);
        // Display the saved part edit as well as the underlying Sound.
        if(savedSoundEdits.controller(73)>=0)source[0]=sampler::sourceSoundEditTimeMs(
            (editing||src.sourceAmpEnvelope.runtimeEnabled()?env.attackSec:src.ampEnvelope.attackSec)*1000,savedSoundEdits.controller(73))*(layer?1:u.ampAttackScale);
        if(savedSoundEdits.controller(75)>=0)source[1]=sampler::sourceSoundEditTimeMs(env.decaySec*1000,savedSoundEdits.controller(75))*(layer?1:u.ampDecayScale);
        if(savedSoundEdits.controller(72)>=0)source[3]=sampler::sourceSoundEditTimeMs(env.releaseSec*1000,savedSoundEdits.controller(72))*(layer?1:u.ampReleaseScale);
    }
    if(player<0){
        bool found=false,allOneShot=true;
        for(int i=0;i<=sampler::kUpperLayers;++i){
            if(i>0&&!u.layers[i-1].enabled)continue;
            const auto& assignment=sampler::soundSource(u,i);
            if(!assignment.hasSource())continue;
            found=true;
            if(assignment.engine.chosen()||!assignment.program){allOneShot=false;break;}
            auto& entry=gateSources_[i];
            if(entry.program.lock()!=assignment.program){
                bool gated=false,one=false;
                for(const auto& lay:assignment.program->layers){
                    if(!lay.enabled||!lay.multisample)continue;
                    for(const auto& z:lay.multisample->zones)if(z.sample){
                        if(z.oneShot)one=true;else{gated=true;break;}
                    }
                    if(gated)break;
                }
                entry.program=assignment.program;entry.onlyOneShot=one&&!gated;
            }
            if(!entry.onlyOneShot){allOneShot=false;break;}
        }
        oneShot=found&&allOneShot;
    }
    if(player>=0&&part<2&&activityPlayer_==player&&activitySerial_==selection){
        const auto& settings=players_[player].tracks[part].soundSettings;
        bool found=false,gated=false;
        for(const auto& drum:activity_.drums)if(drum.track==part){
            int gate=settings.trigger;
            if(settings.tones){
                const auto hit=settings.tones->find(drum.note);
                if(hit!=settings.tones->end()&&hit->second.gate>=0)gate=hit->second.gate;
            }
            found=true;gated|=gate==0||(gate<0&&drum.hasGatedZone);
        }
        if(found)oneShot=!gated;
    }
    const auto envelope=[&](int index,const char* name){
        const bool percent=index==2||index==5,cutoff=index==4,locked=index==3&&oneShot;
        const float low=cutoff?20:0,high=percent?1:cutoff?20000:10000;
        const float stored=partEnvelopeValue(u,index);
        const float current=stored<0?std::clamp(source[index],low,high):stored;
        if(index==1||index==2){
            const float factor=percent?100.0F:1.0F;
            const float reference=std::clamp(source[index],low,high)*factor;
            const float offset=stored<0?0:current*factor-reference;
            const std::string unit=percent?" %":" ms";
            const auto signedValue=[unit](float v){return (std::round(v)>0?"+":std::string{})+fmtFixed(std::round(v)==0?0:v,0)+unit;};
            dial(name,offset,-reference,high*factor-reference,1,percent?Scale::Linear:Scale::Time,stored<0,true,
                 signedValue,[=](auto& d,float delta){
                     setPartEnvelopeOffset(d,index,delta/factor,reference/factor);
                 },0,true,true,"Base "+fmtFixed(reference,0)+unit+"   /   Result "+fmtFixed(current*factor,0)+unit);
            return;
        }
        dial(name,current,low,high,percent?.01F:1,percent?Scale::Linear:cutoff?Scale::Frequency:Scale::Time,stored<0,!locked,
             [=](float v){return locked?std::string("One Shot"):fmtFixed(percent?v*100:v,0)+(percent?" %":cutoff?" Hz":" ms");},
             [index](auto& d,float v){setPartEnvelope(d,index,v);},-1);
    };
    const sampler::ToneExtra defaults{};
    const auto lfo=[&](const char* name,float sampler::ToneExtra::*member,float low,float high,float step,Scale scale,const char* unit,int digits){
        dial(name,modulation.*member,low,high,step,scale,false,true,units(unit,digits),
             [member](auto& d,float v){setPartModulation(d,member,v);},defaults.*member);
    };
    const int mode=std::clamp(int(u.portaMode),0,3);
    const auto sourceGlide=partSourceGlide(u,savedSoundEdits,program);
    const bool keyboardSource=player<0&&partInheritsGlide(u)&&sourceGlide.present;
    if(tonePage_==0){
        const auto bounds=partOctaveBounds(u);
        dial("Octave",u.octave,bounds.first,bounds.second,1,Scale::Linear,false,true,[](float v){return signedNumber(int(v));},
             [](auto& d,float v){setPartOctave(d,int(v));},0,true);
        envelope(0,"Attack");envelope(1,"Decay");envelope(2,"Sustain");envelope(3,"Release");
        lfo("Vibrato Depth",&sampler::ToneExtra::lfoDepthCents,0,200,.1F,Scale::Linear," ct",1);
        lfo("Vibrato Speed",&sampler::ToneExtra::lfoRateHz,.05F,20,.01F,Scale::Frequency," Hz",2);
        toggle("Portamento",keyboardSource?sourceGlide.on:partGlideEnabled(u),"Off","On",[this,player,part,selection,keyboardSource](auto& d,float v){
            if(keyboardSource){d.sourceSoundEdits.setController(65,v>=.5F?127:0);return;}
            if((v>=.5F)!=partGlideEnabled(d))togglePartGlide(d,player,part,selection);
        });
        if(keyboardSource){
            const int stored=savedSoundEdits.controller(5);
            const int low=sourceGlide.low,high=sourceGlide.high;
            const float value=stored>=0?stored:std::max(0,high);
            const auto format=[=](float v){
                if(stored<0&&low>=0&&low!=high&&v==value)return std::to_string(low)+"–"+std::to_string(high);
                if(stored<0&&high<0&&v==value)return std::string("Unknown");
                return fmtFixed(v,0);
            };
            dial("Portamento Time",value,0,127,1,Scale::Linear,stored<0,true,format,
                [](auto& d,float v){d.sourceSoundEdits.setController(5,v<0?-1:int(std::lround(v)));},-1,false,false,
                "SET / OSC · 0–127");
        }else dial("Portamento Time",mode?u.portaTime:u.portamentoSec*1000,0,mode?127:100,1,Scale::Linear,false,true,units(mode?"":" ms"),setPartGlideTime,0);
    }else if(tonePage_==1){
        const auto voiceMode=u.sourceVoiceInherit&&program&&program->sourceVoiceAssignment.present?
            (program->legato?2:program->mono?1:0):std::clamp(int(u.voiceMode),0,2);
        menu("Voice Mode",{"Poly","Mono","Legato"},voiceMode,[apply](int n){
            apply([](auto& d,float v){d.sourceVoiceInherit=false;d.voiceMode=static_cast<sampler::UpperVoiceMode>(int(v));},n);
        });
        if(player>=0){
            const auto trigger=players_[player].tracks[part].soundSettings.trigger;
            menu("Note Trigger",{"Sound","Gate","One Shot"},std::clamp(trigger+1,0,2),[this,player,selection,part](int n){
                controlRequested(host::arrangerHost().setTrackTrigger(player,selection,part,n-1));
            },true);
        }else toggle("Damper",u.damperEnabled,"Off","On",[](auto& d,float v){d.damperEnabled=v>=.5F;});
        std::vector<std::string> glideModes{glideAlgorithms[0],glideAlgorithms[1],glideAlgorithms[2],glideAlgorithms[3]};
        if(player<0&&sourceGlide.present)glideModes.emplace_back("SET / OSC");
        menu("Glide Mode",std::move(glideModes),keyboardSource?4:mode,[apply](int n){
            apply([](auto& d,float v){
                if(int(v)==4){d.sourcePortamentoInherit=true;d.portaMode=sampler::PortamentoMode::Silveton;d.portamentoSec=0;return;}
                d.sourcePortamentoInherit=false;d.portaMode=static_cast<sampler::PortamentoMode>(int(v));
            },n);
        });
        toggle("Vibrato Control",modulation.lfoModWheel,"Fixed","CC1",[](auto& d,float v){setPartModulation(d,&sampler::ToneExtra::lfoModWheel,v>=.5F);});
        lfo("Vibrato Delay",&sampler::ToneExtra::lfoDelayMs,0,10000,1,Scale::Time," ms",0);
        lfo("Vibrato Fade",&sampler::ToneExtra::lfoFadeMs,0,10000,1,Scale::Time," ms",0);
        if(mode==1)toggle("Fingered",u.portaFingered,"Off","On",[](auto& d,float v){d.sourcePortamentoInherit=false;d.portaFingered=v>=.5F;});
        if(mode!=0)toggle("Glide timing",u.portaRateMode,"Fixed time","Rate / octave",[](auto& d,float v){d.sourcePortamentoInherit=false;d.portaRateMode=v>=.5F;});
        envelope(4,"Cutoff");envelope(5,"Resonance");
    }else if(tonePage_==3){
        const auto& g=u.channelGate;
        toggle("Channel Strip Gate",g.enabled,"Off","On",[](Part& p,float v){p.channelGate.enabled=v!=0;});
        dial("Threshold",g.thresholdDb,-30,10,.1F,Scale::Linear,false,true,units(" dB",1),
             [](Part& p,float v){p.channelGate.thresholdDb=v;},-30);
        dial("Range",g.rangeDb,0,40,.1F,Scale::Linear,false,true,units(" dB",1),
             [](Part& p,float v){p.channelGate.rangeDb=v;},20);
        dial("Hold",g.holdSec*1000,0,4000,1,Scale::Time,false,true,units(" ms"),
             [](Part& p,float v){p.channelGate.holdSec=v*.001F;},50);
        dial("Gate Release",g.releaseSec*1000,100,4000,1,Scale::Time,false,true,units(" ms"),
             [](Part& p,float v){p.channelGate.releaseSec=v*.001F;},300);
        toggle("Mode",g.expand,"Gate","Expand 1:2",[](Part& p,float v){p.channelGate.expand=v!=0;});
        toggle("Attack",g.fastAttack,"Normal","Fast",[](Part& p,float v){p.channelGate.fastAttack=v!=0;});
        const float reduction=g.enabled?(player<0?ctrl_.engine.nativeGateReduction(part):
            host::arrangerHost().styleGateReduction(player,part)):0;
        if(home){gateDisplayKey_=gateMeterDisplayKey(reduction);gateDisplayValid_=true;gatePollMs_=nowMs();}
        const float left=home?699:304,right=home?1581:687,top=home?615:259;
        label(c,"Gain reduction",left,top,home?27:16,liveText,true,(right-left)*.6F);
        label(c,fmtFixed(reduction,1)+" dB",right,top,home?26:15,liveAmber,true,(right-left)*.35F,Align::Right);
        const float y=top+(home?30:12),height=home?28:12;
        box(c,{left,y,right,y+height},liveCard,liveLine,4);
        if(reduction>.01F)box(c,{left,y,left+(right-left)*std::clamp(reduction/40.0F,0.0F,1.0F),y+height},liveAmber,0,3);
        label(c,"0",left,y+height+(home?28:14),home?19:11,liveDim,false,60);
        label(c,"40 dB",right,y+height+(home?28:14),home?19:11,liveDim,false,100,Align::Right);
        if(home)label(c,"Threshold reference   0 dB = −18 dBFS",left,top+133,20,liveDim,false,right-left);
    }else if(home){
#include "ArrangerSamplerEq.inc"
        return;
    }else{
        editButton(body,"Open Sampler EQ",true,[this,player,part]{
            if(player>=0)setPlayerFocus(player,false);openSoundWindow(player<0,part);tonePage_=2;
        });
    }
    if(overlay)overlay();else if(!toneDetail_.empty())toneDetail_.clear();
}
