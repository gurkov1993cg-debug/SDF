#include "silveton/arranger/ArrangerEngine.h"
#include <cstring>
#include "UiViewState.h"
#include "silveton/arranger/PaStyleBank.h"
#include "silveton/arranger/PaSampleIdentity.h"
#include "silveton/ui/ArrangerView.h"
#include "silveton/arranger/Pa5xSampleProgram.h"
#include "silveton/host/detail/ImportedLegatoPortamento.h"
#include "silveton/arranger/Pa5xSoundGraph.h"
#include "silveton/arranger/Pa5xPreparedSetSnapshot.h"
#include "silveton/arranger/Pa5xEffectCatalog.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SourceEffects.h"
#include "silveton/sampler/SourceOscillatorRuntime.h"
#include "silveton/sampler/NumberedFxRuntime.h"
#include "silveton/sampler/SvBankFormat.h"
#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/PerformanceDiagnostics.h"
#include "silveton/sampler/SampleStreamPrefetcher.h"
#include "silveton/sampler/CpuWorkPolicy.h"
#include <fstream>
#include <chrono>
#include <ctime>
#include <iterator>
#include "silveton/arranger/LiveTrace.h"
#if defined(__linux__) || defined(__ANDROID__)
#include <sched.h>
#include <dirent.h>
#endif

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <iomanip>
#include <sstream>
#include <set>
#include <stdexcept>
#include <thread>
#include <tuple>
#include <utility>

namespace silveton::ui {
namespace {
std::string keyboardSamplerBankIdentity(const std::string& bank);
constexpr ColorInt bg=0xFF000000U, panel=0xFF101419U, key=0xFF202C34U;
constexpr ColorInt white=0xFFE3E7E8U, dim=0xFF8A969BU, kBorder=0xFF41484BU;
constexpr ColorInt orange=0xFFFF8A00U, green=0xFF00DA9CU, blue=0xFF35A5E8U;
constexpr ColorInt styleBlue=0xFF0757CDU;
constexpr float sx=320.0F, sy=24.0F, ss=1.25F;
// Keep the approved display fixed while providing the right-hand data/tempo
// column shown on the Pa5X control panel. No physical keyboard is drawn.
constexpr float kPanelWidth=1640.0F,kPanelHeight=1040.0F;
// Relative touch gain: gentle constant dB change, independent of visual taper.
// A grab never changes the level. Fractional movement is retained, and
// overshoot at the ends is discarded so reversal responds immediately.
struct RelativeVolumeGesture {
    bool grabbed=false,moving=false;
    float lastY=0.0F,exact=0.0F,origin=0.0F;
    float update(float y,float initial,float low,float high,float zoom=1.0F){
        if(!grabbed){grabbed=true;lastY=y;exact=origin=initial;return initial;}
        float delta=(lastY-y)*zoom;
        if(!moving){
            constexpr float deadZone=4.0F;
            if(std::abs(delta)<=deadZone)return initial;
            delta-=std::copysign(deadZone,delta);moving=true;
        }
        lastY=y;
        if(delta==0.0F)return initial;
        exact=std::clamp(exact+delta*0.10F,low,high);
        if(exact==low||exact==high){origin=exact;return exact;}
        return std::clamp(origin+std::round((exact-origin)*5.0F)/5.0F,low,high);
    }
    void rebase(float actual){exact=origin=actual;}
};
// A cancelled detached worker may still be inside a source read. Serialize
// SET preparation on workers so replacement requests never overlap that I/O.
// Neither UI controls nor the audio callback acquire this mutex.
std::mutex setPreparationMutex;
constexpr float kTempoWheelCenterX=1482.0F,kTempoWheelCenterY=286.0F,kTempoWheelRadius=76.0F;
constexpr std::array<int,4> partOrder{{6,2,1,0}};
constexpr std::array<const char*,4> partNames{{"Lower","Upper 3","Upper 2","Upper 1"}};
constexpr std::array<const char*,15> elementNames{{"INTRO 1","INTRO 2","INTRO 3","VAR 1","VAR 2","VAR 3","VAR 4","FILL 1","FILL 2","FILL 3","FILL 4","BREAK","ENDING 1","ENDING 2","ENDING 3"}};
struct ElementCue {bool selected,queued,returning,looping;};
ElementCue liveElementCue(const host::ArrangerPlayerView& p,int index){
    const auto isTransient=[](int i){return i>=0&&(i<3||(i>=7&&i<=11));};
    const bool returning=(isTransient(p.element)||isTransient(p.pendingElement))&&p.returnElement==index&&index>=3&&index<=6;
    return {p.element==index,p.pendingElement==index,returning,p.loopElement==index};
}
std::string signedNumber(int n) { return (n>=0?"+":"")+std::to_string(n); }
std::string arrangerNoteName(int n) {
    static const char* names[]={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
    return std::string(names[((n%12)+12)%12])+std::to_string(n/12-1);
}
bool styleFile(const std::string& n) {
    std::string s=n; std::transform(s.begin(),s.end(),s.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});
    return endsWith(s,".stg")||endsWith(s,".mid")||endsWith(s,".midi");
}
std::string tempoText(double bpm) {
    auto value=fmtFixed(bpm,2);
    while(!value.empty()&&value.back()=='0')value.pop_back();
    if(!value.empty()&&value.back()=='.')value.pop_back();
    return value;
}
std::string rawValue(int value) { return value<0?"—":std::to_string(value); }
// Compare digit runs without conversion: RAM2 precedes RAM10, even with
// leading zeros or identifiers too long for a machine integer.
bool pcmPathLess(const std::string& a,const std::string& b) {
    std::size_t ai=0,bi=0;
    const auto digit=[](unsigned char c){return c>='0'&&c<='9';};
    const auto fold=[](unsigned char c){return c>='A'&&c<='Z'?static_cast<unsigned char>(c-'A'+'a'):c;};
    while(ai<a.size()&&bi<b.size()){
        const auto ac=static_cast<unsigned char>(a[ai]),bc=static_cast<unsigned char>(b[bi]);
        if(digit(ac)&&digit(bc)){
            auto ae=ai,be=bi;
            while(ae<a.size()&&digit(static_cast<unsigned char>(a[ae])))++ae;
            while(be<b.size()&&digit(static_cast<unsigned char>(b[be])))++be;
            auto as=ai,bs=bi;
            while(as<ae&&a[as]=='0')++as;
            while(bs<be&&b[bs]=='0')++bs;
            if(ae-as!=be-bs)return ae-as<be-bs;
            const auto comparison=a.compare(as,ae-as,b,bs,be-bs);
            if(comparison!=0)return comparison<0;
            ai=ae;bi=be;continue;
        }
        if(fold(ac)!=fold(bc))return fold(ac)<fold(bc);
        ++ai;++bi;
    }
    if(ai!=a.size()||bi!=b.size())return ai==a.size();
    return a<b;
}
bool pcmFileReady(const arranger::Pa5xPcmFileStatus& file){
    return file.indexed&&file.preparationComplete&&file.samples>0U&&file.ready==file.samples&&
        file.failed==0U&&file.unlinked==0U&&file.error.empty();
}
const char* pcmFileState(const arranger::Pa5xPcmFileStatus& file){
    if(pcmFileReady(file))return "READY";
    if(file.unlinked>0U&&file.failed==0U)return "UNLINKED";
    if(!file.error.empty()||file.failed>0U)return file.ready>0U?"PARTIAL":"ERROR";
    if(file.unlinked>0U)return "UNLINKED";
    if(!file.indexed)return "NOT READ";
    if(!file.preparationComplete)return "UNCHECKED";
    return file.samples==0U?"EMPTY":"PARTIAL";
}
std::string pcmFileSummary(const std::vector<arranger::Pa5xPcmFileStatus>& files){
    std::size_t ready=0,partial=0,errors=0,unchecked=0;
    for(const auto& file:files){
        if(pcmFileReady(file))++ready;
        else if(file.unlinked>0U&&file.failed==0U)++partial;
        else if(!file.error.empty()||file.failed>0U){if(file.ready>0U)++partial;else ++errors;}
        else if(file.unlinked>0U||file.preparationComplete)++partial;
        else ++unchecked;
    }
    return "PCM files "+std::to_string(files.size())+" | Ready "+std::to_string(ready)+
        " | Partial "+std::to_string(partial)+" | Error "+std::to_string(errors)+" | Unchecked "+std::to_string(unchecked);
}
bool writePersistentRecord(const std::string& sessionPath,const std::string& text,
                           const std::string& legacyPath,const std::string& root){
    const auto parent=files::parentOf(sessionPath);
    const auto temporary=sessionPath+".pending";
    if((!parent.empty()&&!files::makeDirectories(parent))||!files::writeText(temporary,text)||
       std::rename(temporary.c_str(),sessionPath.c_str())!=0)return false;
    if(!legacyPath.empty()){
        std::ostringstream legacy;legacy<<"SILVETON_KST 1 "<<std::quoted(root)<<'\n';
        const auto pending=legacyPath+".pending";
        if(files::writeText(pending,legacy.str()))(void)std::rename(pending.c_str(),legacyPath.c_str());
    }
    return true;
}
bool sameTrackDisplay(const host::ArrangerTrackView& a,const host::ArrangerTrackView& b,bool meters){
    const auto values=[](const auto& v){return std::tie(v.name,v.soundName,v.soundSlot,v.soundSettings.setAddress,v.soundSettings.tones,v.soundSettings.keyDb,v.msb,v.lsb,v.program,
        v.addressKnown,v.addressVaries,v.originalSoundName,v.originalSoundPath,v.originalSoundStatus,
        v.originalSoundAddressComplete,v.originalSoundMultiple,v.originalSoundAtCvStart,v.soundSettings.trigger,v.selectedCv,
        v.playbackBlocked,v.volumeDb,v.pan,v.mute,v.assigned,v.originalSoundRouted);};
    if(values(a)!=values(b))return false;
    if(meters&&std::tie(a.sourceVolumeRaw,a.sourcePanRaw,a.sourceExpressionRaw)!=
        std::tie(b.sourceVolumeRaw,b.sourcePanRaw,b.sourceExpressionRaw))return false;
    const auto pixels=[](float peak){return static_cast<int>(43.0F*std::clamp(peak,0.0F,1.0F));};
    return !meters||pixels(a.peak)==pixels(b.peak);
}
bool samePlayerDisplay(const host::ArrangerPlayerView& a,const host::ArrangerPlayerView& b,bool transport,bool showTracks,bool meters){
    const auto values=[](const auto& v){return std::tie(v.name,v.elementName,v.pendingElementName,v.sourcePath,v.styleSelectionSerial,v.soundRevision,
        v.pendingStylePath,v.pendingStyleName,v.styleSwitchPending,v.playbackWarning,v.playing,v.syncStart,
        v.autoFill,v.drumBassOnly,v.manualBass,v.manualBassReady,v.velocityControl,v.velocityThreshold,v.velocityPlayer,v.autoFillMode,v.fillModes,v.globalSplit,v.scaleAssignment,v.syncStop,v.syncStartAutoOff,v.loopElement,
        v.fadeDirection,v.fadeInSeconds,v.fadeOutSeconds,v.memory,v.memoryMode,v.chordRecognitionMode,v.chordScanArea,v.splitEnabled,v.bassInversion,v.damperLatch,
        v.loaded,v.savedStyleBank,v.savedStylePosition,v.tempoLock,v.nativeKorgStyle,v.soundAssignmentsReady,v.samplePlaybackMode,v.blockedTrackMask,
        v.bpm,v.originalBpm,v.numerator,v.denominator,v.split,v.element,v.pendingElement,v.returnElement,v.available);};
    if(values(a)!=values(b)||(transport&&std::tie(a.bar,a.beat,a.chordName)!=std::tie(b.bar,b.beat,b.chordName)))return false;
    if(!showTracks)return true;
    for(std::size_t track=0;track<a.tracks.size();++track)if(!sameTrackDisplay(a.tracks[track],b.tracks[track],meters))return false;
    return true;
}
bool sameUpperDisplay(const std::optional<SamplerAppController::UpperState>& a,
                      const std::optional<SamplerAppController::UpperState>& b){
    if(a.has_value()!=b.has_value())return false;
    if(!a)return true;
    return std::tie(a->enabled,a->solo,a->mute,a->levelDb,a->pan,a->octave,a->soundName)==
           std::tie(b->enabled,b->solo,b->mute,b->levelDb,b->pan,b->octave,b->soundName);
}
const char* arrangerKeyboardPartName(int part) {
    static const char* names[]{"Upper 1","Upper 2","Upper 3","Upper 4","Upper 5","Upper 6","Lower"};
    return names[static_cast<std::size_t>(std::clamp(part,0,6))];
}
std::string flagValue(int value) { return value<0?"Unknown":(value==0?"Off":(value==1?"On":"Raw "+std::to_string(value))); }
std::string originalAddress(int msb,int lsb,int program) {
    return rawValue(msb)+" / "+rawValue(lsb)+" / "+rawValue(program);
}
const char* originalSoundStatus(arranger::KstResolution status) {
    switch(status){
        case arranger::KstResolution::ExactUserSound:return "User Sound found";
        case arranger::KstResolution::FactorySoundRequired:return "Factory Sound";
        case arranger::KstResolution::MissingUserSound:return "User Sound missing";
        case arranger::KstResolution::AmbiguousSound:return "Conflicting Sounds";
        case arranger::KstResolution::UnsupportedSoundAddress:return "Address unresolved";
    }
    return "Address unresolved";
}
std::string arrangerStyleSelectionKey(const host::ArrangerPlayerView& player) {
    std::string selectionKey=player.sourcePath.empty()?"<No Style>":player.sourcePath;
    if(player.savedStyleBank>0&&player.savedStylePosition>0)
        selectionKey+="\nSILVETON_USER_STYLE "+std::to_string(player.savedStyleBank)+" "+std::to_string(player.savedStylePosition);
    return selectionKey;
}
const char* keyboardRole(int role) {
    switch(role){case 1:return "Lower";case 2:return "Upper 1";case 3:return "Upper 2";case 4:return "Upper 3";default:return "Part";}
}
std::string keyRange(int low,int high) {
    return low<0||high<0?"—":arrangerNoteName(low)+" – "+arrangerNoteName(high);
}
const arranger::Pa5xStyleSoundChange* initialCvSound(const arranger::Pa5xStyleRead& read,
        const arranger::Pa5xStyleReadCv& cv,std::size_t track) {
    if(cv.soundChanges.empty())return nullptr;
    if(read.nativeStyle){
        const auto channel=read.nativeStyle->tracks[track].sourceChannel;
        return cv.soundAt(channel,0);
    }
    const arranger::Pa5xStyleSoundChange* initial=nullptr;
    for(const auto& change:cv.soundChanges)if(change.tick==0)initial=&change;
    return initial;
}
bool multipleInitialCvSounds(const arranger::Pa5xStyleReadCv& cv) {
    std::map<int,const arranger::Pa5xStyleSoundChange*> channels;
    for(const auto& change:cv.soundChanges)if(change.tick==0)channels[change.channel]=&change;
    const arranger::Pa5xStyleSoundChange* first=nullptr;
    for(const auto& entry:channels){const auto* sound=entry.second;if(!first)first=sound;
        else if(sound->msb!=first->msb||sound->lsb!=first->lsb||sound->program!=first->program)return true;}
    return false;
}
std::string soundChangeText(const arranger::Pa5xStyleSoundChange& change) {
    std::string text="Tick "+std::to_string(change.tick)+" / MIDI ch "+std::to_string(change.channel+1U)+
        " / MSB / LSB / Program: "+originalAddress(change.msb,change.lsb,change.program);
    text+="\n"+(change.sound.name.empty()?std::string("Name unresolved"):change.sound.name)+" — "+originalSoundStatus(change.sound.resolution);
    if(!change.sound.path.empty())text+="\n"+change.sound.path;
    if(!change.sound.message.empty())text+="\n"+change.sound.message;
    return text;
}
std::vector<std::string> wrappedKstText(const std::string& value,float width,float size) {
    struct CachedWrap {
        std::string value;
        float width{0},size{0};
        std::vector<std::string> lines;
    };
    // UI-only and bounded: repeated frames/pages of the same report must not
    // repeatedly shape every growing prefix of the entire report.
    thread_local std::vector<CachedWrap> cache;
    for(const auto& cached:cache)
        if(cached.width==width&&cached.size==size&&cached.value==value)return cached.lines;
    Paint paint;paint.textSize=size;
    std::vector<std::string> lines;std::string line;float lineWidth=0;
    for(std::size_t pos=0;pos<value.size()&&lines.size()<512;){
        const auto ch=static_cast<unsigned char>(value[pos]);
        const auto length=ch<0x80U?1U:((ch&0xE0U)==0xC0U?2U:((ch&0xF0U)==0xE0U?3U:4U));
        const auto count=std::min<std::size_t>(length,value.size()-pos);
        const auto next=value.substr(pos,count);pos+=count;
        if(next=="\n"){lines.push_back(line);line.clear();lineWidth=0;continue;}
        // The font layout uses additive advances without kerning. Measuring
        // one code point preserves its width without quadratic prefix shaping.
        const float nextWidth=paint.measureText(next);
        if(!line.empty()&&lineWidth+nextWidth>width){lines.push_back(line);line.clear();lineWidth=0;}
        line+=next;lineWidth+=nextWidth;
    }
    if(!line.empty()||lines.empty())lines.push_back(line);
    if(value.size()<=256U*1024U){
        if(cache.size()>=4U)cache.erase(cache.begin());
        cache.push_back({value,width,size,lines});
    }
    return lines;
}
std::string canonicalKstPath(const std::string& path){
    std::unique_ptr<char,decltype(&std::free)> resolved(::realpath(path.c_str(),nullptr),&std::free);
    return resolved?std::string(resolved.get()):std::string{};
}
struct PreparedSetSamples {
    std::vector<host::ArrangerOriginalProgram> programs;
    std::vector<std::string> warnings;
};
const arranger::KstDiagnostic* sampleCoverage(const arranger::Pa5xKstIndex& index){
    for(const auto& d:index.diagnostics)if(d.code=="KMP_PCM_COVERAGE")return &d;
    return nullptr;
}
void addSampleCoverage(arranger::Pa5xKstIndex& index,const arranger::Pa5xSetBank& bank){
    if(sampleCoverage(index))return;
    std::set<std::uint64_t> expected,available;
    for(const auto& inventory:bank.sampleResourceInventories()){
        if(!inventory.index||!inventory.index->valid)continue;
        if(inventory.index->kind==arranger::Pa5xSampleContainerKind::Multisamples){
            for(const auto& s:inventory.index->samples)expected.insert(s.resourceId);
        }else if(inventory.index->kind==arranger::Pa5xSampleContainerKind::PcmSamples){
            for(const auto& s:inventory.index->objects)if(s.hasId)available.insert(s.resourceId);
        }
    }
    if(expected.empty())return;
    std::size_t present=0;
    for(const auto id:expected)if(available.count(id))++present;
    const auto missing=expected.size()-present;
    if(missing)index.structurallyValid=false;
    index.diagnostics.push_back({missing?arranger::KstSeverity::Blocking:arranger::KstSeverity::Info,"KMP_PCM_COVERAGE",{},
        "KMP samples "+std::to_string(expected.size())+" | Found in indexed PCM "+std::to_string(present)+
        " | Unmatched "+std::to_string(missing)});
}
void finishSampleResourceIndex(arranger::Pa5xKstIndex& index,
        const arranger::Pa5xSetBank& bank){
    addSampleCoverage(index,bank);
    std::set<std::string> indexedPaths;
    index.indexedSamples=0;index.indexedMultisamples=0;
    for(const auto& inventory:bank.sampleResourceInventories()){
        if(!inventory.index||!inventory.index->valid)continue;
        if(inventory.index->kind==arranger::Pa5xSampleContainerKind::PcmSamples)
            index.indexedSamples+=static_cast<std::uint64_t>(inventory.index->objects.size());
        else if(inventory.index->kind==arranger::Pa5xSampleContainerKind::Multisamples)
            index.indexedMultisamples+=static_cast<std::uint64_t>(inventory.index->multisamples.size());
        else continue;
        indexedPaths.insert(inventory.sourcePath);
    }
    for(auto& resource:index.resources){
        if(resource.kind!=arranger::KstResourceKind::Sample&&resource.kind!=arranger::KstResourceKind::Multisample)continue;
        resource.indexed=indexedPaths.count(files::join(index.rootPath,resource.relativePath))!=0;
        if(!resource.indexed)index.structurallyValid=false;
    }
    std::set<std::tuple<std::string,std::string,std::string>> messages;
    for(const auto& diagnostic:index.diagnostics)messages.emplace(diagnostic.code,diagnostic.relativePath,diagnostic.message);
    const auto prefix=index.rootPath+"/";
    const auto status=bank.status();
    if(status.samplesFailed>0U||status.samplesUnlinked>0U)index.structurallyValid=false;
    for(const auto& issue:status.issues){
        auto path=issue.path;
        if(path.compare(0,prefix.size(),prefix)==0)path.erase(0,prefix.size());
        if(index.diagnostics.size()<10000U&&messages.emplace(issue.code,path,issue.message).second)
            index.diagnostics.push_back({arranger::KstSeverity::Blocking,issue.code,std::move(path),issue.message});
        index.structurallyValid=false;
    }
    if(status.samplePreparationComplete||status.samplesAttempted>0){
        const auto summary="PCM prepared "+std::to_string(status.samplesReady)+" / "+std::to_string(status.samplesAttempted)+
            "  •  Failed "+std::to_string(status.samplesFailed)+"  •  No KMP "+std::to_string(status.samplesUnlinked)+
            "  •  RAM fallback "+std::to_string(status.samplesRamFallbacks);
        index.diagnostics.push_back({arranger::KstSeverity::Info,"PCM_PREPARATION_STATUS",{},summary});
        const auto activity="PCM source files read "+std::to_string(status.pcmSourceFilesRead)+
            "  •  Index cache "+std::to_string(status.pcmMetadataCacheHits)+
            "  •  Cached samples "+std::to_string(status.samplesDiskCacheHits)+
            "  •  Decoded "+std::to_string(status.samplesDecoded);
        index.diagnostics.push_back({arranger::KstSeverity::Info,"PCM_CACHE_ACTIVITY",{},activity});
        for(const auto& issue:status.samplePreparationIssues){
            auto path=issue.path;
            if(path.compare(0,prefix.size(),prefix)==0)path.erase(0,prefix.size());
            if(index.diagnostics.size()>=10000U||!messages.emplace(issue.code,path,issue.message).second)continue;
            const auto severity=issue.code.find("FAILED")!=std::string::npos?arranger::KstSeverity::Blocking:arranger::KstSeverity::Warning;
            index.diagnostics.push_back({severity,issue.code,std::move(path),issue.message});
        }
    }
    // The deferred inspections have now run in the shared bank loader; this
    // says nothing about complete original Sound synthesis or missing zones.
    index.sampleResourcesDeferred=false;
}
void configureSetSampleCache(const std::string& cacheDirectory,
        const std::atomic<bool>* cancel,arranger::Pa5xMultisampleCache& cache,
        arranger::Pa5xMultisampleBuildOptions& options){
    if(cacheDirectory.empty()||!files::makeDirectories(cacheDirectory))
        throw std::runtime_error("Cannot create the SET sample cache in app storage");
    cache.maximumDecodedFrames=64U*1024U*1024U;
    options.endConvention=arranger::Pa5xSampleEndConvention::KorgLoopBoundary;
    options.maximumTotalFrames=64U*1024U*1024U;
    options.streamCacheDirectory=cacheDirectory;
    options.preloadFrames=2048U;
    options.cancel=cancel;
}
PreparedSetSamples prepareSetSamples(const arranger::Pa5xSetBank& bank,
        arranger::Pa5xMultisampleCache& cache,
        const arranger::Pa5xMultisampleBuildOptions& options,
        const std::function<void(const arranger::KstProgress&)>& progress,
        const std::atomic<bool>* cancel){
    PreparedSetSamples result;
    using Address=std::tuple<int,int,int>;
    std::set<Address> addresses;
    for(const auto& sound:bank.sounds()){
        const auto& d=sound.descriptor;
        if(d.addressKnown&&d.msb<=127&&d.lsb<=127&&d.rawProgram<=127)
            addresses.emplace(d.msb,d.lsb,d.rawProgram);
    }
    std::uint64_t done=0;
    const auto total=static_cast<std::uint64_t>(addresses.size());
    for(const auto& address:addresses){
        if(cancel&&cancel->load(std::memory_order_acquire))return {};
        const auto [msb,lsb,program]=address;
        const auto sound=bank.resolveSoundAddress(msb,lsb,program);
        if(progress)progress({done,total,"Preparing all SET instruments",sound.name.empty()?originalAddress(msb,lsb,program):sound.name});
        auto built=arranger::buildPa5xSampleProgram(bank,msb,lsb,program,options,&cache);
        if(cancel&&cancel->load(std::memory_order_acquire))return {};
        if(built.ready&&built.program)result.programs.push_back({msb,lsb,program,std::move(built.program)});
        for(const auto& message:built.warnings)
            if(result.warnings.size()<12U&&std::find(result.warnings.begin(),result.warnings.end(),message)==result.warnings.end())result.warnings.push_back(message);
        ++done;
    }
    if(progress)progress({total,total,"SET instruments ready",bank.status().rootPath});
    return result;
}
#include "ArrangerStyleSource.inc"
}

// Jobs retain only their own state. Closing the view cancels the scan without
// waiting on storage or leaving a callback with a pointer to the old view.
namespace {
bool catalogUsesPerformances(const arranger::Pa5xKstCatalog& catalog){
    // Mixed-source catalogs can contain both legacy and Pa5X types.
    return std::any_of(catalog.keyboardSets.begin(),catalog.keyboardSets.end(),[](const auto& row){
        const auto slash=row.relativePath.find('/');
        return slash==7&&std::equal(row.relativePath.begin(),row.relativePath.begin()+7,"perform",
            [](unsigned char a,char b){return std::tolower(a)==b;});
    });
}
bool hasReadablePerformanceCatalog(const arranger::Pa5xKstCatalog& catalog) {
    return std::any_of(catalog.styles.begin(),catalog.styles.end(),[](const auto& style){
        return style.loadable || arranger::paStyleSlot(style.path);
    }) || std::any_of(catalog.keyboardSets.begin(),catalog.keyboardSets.end(),[](const auto& performance){
        return performance.metadataSupported || arranger::paKeyboardLocation(performance.path);
    });
}
}

struct ArrangerView::KstJob {
    std::atomic<bool> cancel{false}, done{false};
    std::mutex mutex;
    arranger::KstProgress progress;
    std::string rootPath, pcmCacheProgress;
    int mediaTab{-1};
    std::string mediaBank;
    int stage{0}; // one full preparation operation: discovery, samples, catalog, Programs, snapshot
    std::shared_ptr<const arranger::Pa5xKstIndex> result;
    std::shared_ptr<const arranger::Pa5xKstCatalog> catalog;
    std::shared_ptr<const arranger::Pa5xSetBank> bank;
    std::vector<host::ArrangerOriginalProgram> programs;
    std::vector<std::string> warnings;
    bool restoringSession{false},automaticRequest{false};
};

// The writer owns immutable bytes and paths, never the view or host. There is
// only one writer at a time; lifecycle flushes join it before saving newer data.
struct ArrangerView::PersistentSaveJob {
    std::string text;
    std::atomic<bool> done{false};
    bool success{false};
    std::thread worker;
    ~PersistentSaveJob(){if(worker.joinable())worker.join();}
};


#include "ArrangerLiveLog.inc"

ArrangerView::ArrangerView(SamplerAppController& controller)
    : SilvetonSamplerView(controller),ctrl_(controller) {
    sampleCacheDirectory_=files::join(files::homeDirectory(),".cache/SILVETON-ARRANGER/samples");
    refresh();
}
ArrangerView::~ArrangerView(){stopEqTap();liveLog_.reset();flushPersistentState();closeKstScan();host::arrangerHost().stopPcmPreview();}

void ArrangerView::updatePcmFileReport(const arranger::Pa5xSetBank* bank,const arranger::Pa5xKstIndex& index){
    kstPcmFiles_=bank?bank->pcmFileStatuses():std::vector<arranger::Pa5xPcmFileStatus>{};
    // Older prepared snapshots did not retain per-file outcomes. Merge their
    // discovered inventory without inventing successful preparation results.
    std::set<std::string> paths;
    for(const auto& file:kstPcmFiles_)paths.insert(file.path);
    for(const auto& resource:index.resources){
        if(resource.kind!=arranger::KstResourceKind::Sample)continue;
        const auto path=files::join(index.rootPath,resource.relativePath);
        if(!paths.insert(path).second)continue;
        arranger::Pa5xPcmFileStatus file;file.path=path;file.indexed=resource.indexed;
        if(!resource.readable)file.error="File cannot be read";
        for(const auto& issue:index.diagnostics)if(issue.relativePath==resource.relativePath&&
            issue.severity==arranger::KstSeverity::Blocking){file.error=issue.message;break;}
        kstPcmFiles_.push_back(std::move(file));
    }
    sampleSummary_={};
    for(const auto& resource:index.resources)if(resource.kind==arranger::KstResourceKind::Sample)
        sampleSummary_.pcmBytes+=resource.sizeBytes;
    for(const auto& file:kstPcmFiles_)if(!file.indexed||!file.preparationComplete)++sampleSummary_.uncheckedFiles;
    for(const auto& issue:index.diagnostics){
        if(issue.code=="DIRECTORY_DEPTH"||issue.code=="TOO_MANY_FILES"||issue.code=="FOLDER_UNREADABLE"||
           issue.code=="FOLDER_READ_FAILED"||issue.code=="LINKED_RESOURCE")sampleSummary_.inventoryIncomplete=true;
    }
    for(const auto& resource:index.resources)if(resource.kind==arranger::KstResourceKind::Multisample&&!resource.indexed)
        sampleSummary_.inventoryIncomplete=true;
    if(bank){
        const auto status=bank->status();
        sampleSummary_.preparationKnown=status.samplePreparationComplete||status.samplesAttempted!=0;
        sampleSummary_.ready=status.samplesReady;sampleSummary_.failed=status.samplesFailed;
        sampleSummary_.unlinked=status.samplesUnlinked;
        std::set<std::uint64_t> identified,expected;
        for(const auto& inventory:bank->sampleResourceInventories()){
            if(!inventory.index||!inventory.index->valid)continue;
            if(inventory.index->kind==arranger::Pa5xSampleContainerKind::PcmSamples){
                for(const auto& object:inventory.index->objects)if(object.hasId)identified.insert(object.resourceId);
            }else if(inventory.index->kind==arranger::Pa5xSampleContainerKind::Multisamples){
                for(const auto& sample:inventory.index->samples)expected.insert(sample.resourceId);
            }
        }
        for(auto id:expected)if(identified.insert(id).second)++sampleSummary_.missing;
        sampleSummary_.identified=identified.size();
    }
    std::sort(kstPcmFiles_.begin(),kstPcmFiles_.end(),[](const auto& a,const auto& b){return pcmPathLess(a.path,b.path);});
}

void ArrangerView::setWarning(const std::string& message) {
    {std::lock_guard<std::mutex> lock(warningMutex_);warning_=message;}
    warningChanged_.store(true,std::memory_order_release);
    SilvetonSamplerView::setWarning(message);
}
void ArrangerView::setMidiConnections(int count){midiConnections_=count;dirty_=true;SilvetonSamplerView::setMidiConnections(count);}
void ArrangerView::globalChangedOutside(){
    if(ctrl_.initialBankLoadFinished()&&!globalSettingsRestorePending_&&!persistentRestoreActive_&&!kstJob_)rememberCurrentGlobalSettings(false);
    markPersistentStateChanged();dirty_=true;SilvetonSamplerView::globalChangedOutside();
}
void ArrangerView::showToast(const std::string& text,int durationMs){toast_=text;toastUntil_=nowMs()+durationMs;dirty_=true;SilvetonSamplerView::showToast(text,durationMs);}
void ArrangerView::showSoloPart(int upper,int sound){editor_=true;SilvetonSamplerView::showSoloPart(upper,sound);dirty_=true;}
void ArrangerView::chooseSoloModelFile(int upper,int sound,const std::string& dir){editor_=true;SilvetonSamplerView::chooseSoloModelFile(upper,sound,dir);dirty_=true;}
void ArrangerView::setHomePageForPreview(int p){switchHomeTab(homeTabAt(static_cast<std::size_t>(std::clamp(p,0,9))));}
void ArrangerView::setKstDirectoryForPreview(const std::string& path){
    closeKstScan();
    auto report=std::make_shared<arranger::Pa5xKstIndex>(arranger::indexPa5xKst(path,{},nullptr,true));
    auto bank=std::make_shared<arranger::Pa5xSetBank>();
    arranger::Pa5xMultisampleCache cache;arranger::Pa5xMultisampleBuildOptions options;
    configureSetSampleCache(sampleCacheDirectory_,nullptr,cache,options);
    (void)bank->loadForSamplePlayback(*report,{},nullptr,&options,&cache);
    finishSampleResourceIndex(*report,*bank);
    kstCatalog_=std::make_shared<arranger::Pa5xKstCatalog>(arranger::buildPa5xKstCatalog(*report,{},nullptr,bank.get()));
    report->metadataReadCache.reset();kstReport_=std::move(report);
    auto prepared=prepareSetSamples(*bank,cache,options,{},nullptr);
    updatePcmFileReport(bank.get(),*kstReport_);classifySetSamples(*bank);
    host::arrangerHost().installKorgSampleBank(std::move(bank),prepared.programs,prepared.warnings,hasReadablePerformanceCatalog(*kstCatalog_));
    keyboardSetContents_.reset();
    kstReportTab_=0;kstReportPage_=0;kstDetail_.clear();openKstCatalog();editor_=false;dirty_=true;
}
void ArrangerView::requestKstScan(const std::string& path){startKstScan(path);}
void ArrangerView::setKstStatePath(const std::string& path){
    if(persistentConfigured_&&kstStatePath_==path)return;
    finishPersistentSave(true);
    persistentRecordValid_=false;persistentSaveAllowed_=false;persistentRestoreUi_.reset();
    persistentRestoreText_.clear();persistentRestoreRoot_.clear();persistentLastSaved_.clear();
    persistentObservedUiRevision_=0;persistentObservedHostRevision_=0;persistentSavePending_=false;
    const auto parent=files::parentOf(path);
    if(!parent.empty())sampleCacheDirectory_=files::join(parent,"ARRANGER_SAMPLE_CACHE");
#if defined(__ANDROID__)
    if(!parent.empty()){
        liveLog_.reset();
        try{liveLog_=std::make_unique<LiveLog>(parent,ctrl_);}catch(const std::exception&){showToast("Live diagnostics could not start",5000);}
    }
#endif
    kstStatePath_=path;persistentSessionPath_=files::join(parent,"ARRANGER_SESSION.txt");
    configureGlobalSettings(parent);
    host::arrangerHost().configureStyleEditStorage(parent);savedKeyboardLibraryDirty_=true;
    persistentConfigured_=true;savedKstRoot_.clear();std::string data;
    if(files::readText(path,data)&&data.size()<=65536){
    std::istringstream input(data);std::string magic,root;int version=0;
    if(input>>magic>>version>>std::quoted(root)){input>>std::ws;if(magic=="SILVETON_KST"&&version==1&&input.eof())savedKstRoot_=root;}
    }
    persistentRecordProtected_=files::exists(persistentSessionPath_);
    if(!readPersistentState())persistentRestoreRoot_=savedKstRoot_;
    persistentRestorePending_=!persistentRestoreRoot_.empty()||!persistentRestoreText_.empty();
    persistentRestoreRetry_=true;
}
void ArrangerView::setStorageAccessRequest(std::function<bool()> request){storageAccessRequest_=std::move(request);}
bool ArrangerView::readPersistentState(){
    std::string data;if(!files::readText(persistentSessionPath_,data)||data.size()>2U*1024U*1024U)return false;
    return readPersistentStateText(data);
}
bool ArrangerView::readPersistentStateText(const std::string& data){
    if(data.size()>2U*1024U*1024U)return false;
    std::istringstream input(data);std::string magic,tag,root,hostText;int version=0;
    if(!(input>>magic>>version)||magic!="SILVETON_ARRANGER_SESSION"||(version!=1&&version!=2))return false;
    PersistentUiState ui;bool rootSeen=false,viewSeen=false,hostSeen=false,ended=false;
    std::size_t links=0,pages=0;
    while(input>>tag){
        if(tag=="ROOT"){
            if(rootSeen||!(input>>std::quoted(root))||root.size()>65536U)return false;
            rootSeen=true;
        }else if(tag=="VIEW"){
            int mixer=0;if(viewSeen||!(input>>ui.selectedPlayer>>ui.catalogTab>>mixer)||ui.selectedPlayer<0||ui.selectedPlayer>1||ui.catalogTab<0||ui.catalogTab>3||(mixer!=0&&mixer!=1))return false;
            ui.mixerStyle=mixer!=0;viewSeen=true;
        }else if(tag=="BROWSE"){
            if(!(input>>std::quoted(ui.pickerDirectory))||ui.pickerDirectory.size()>65536U)return false;
        }else if(tag=="SELECTOR"){
            std::string set;int player=0,initialized=0;StyleSelectState state;
            if(!(input>>std::quoted(set)>>player>>std::quoted(state.browserPath)>>std::quoted(state.categoryPath)>>state.categoryPage>>initialized>>std::quoted(state.lastSourcePath))||player<0||player>1||state.categoryPage<0||state.categoryPage>50000||(initialized!=0&&initialized!=1)||ui.selectors.size()>=128U)return false;
            state.initialized=initialized!=0;state.locateActive=false;
            if(!ui.selectors.emplace(std::make_pair(set,player),std::move(state)).second)return false;
        }else if(tag=="PAGE"){
            std::string set,category;int player=0,page=0;
            if(!(input>>std::quoted(set)>>player>>std::quoted(category)>>page)||page<0||page>50000||++pages>8192U)return false;
            const auto selected=ui.selectors.find({set,player});if(selected==ui.selectors.end())return false;
            selected->second.pages[category]=page;
        }else if(tag=="K"){
            std::string style,name;int position=0,slot=0;
            if(!(input>>std::quoted(style)>>position>>slot>>std::quoted(name))||position<0||position>3||slot<1||slot>500||++links>8192U)return false;
            ui.keyboardLinks[style][static_cast<std::size_t>(position)]={slot,std::move(name)};
        }else if(tag=="NK"){
            std::string style,path,name;int position=0;
            if(!(input>>std::quoted(style)>>position>>std::quoted(path)>>std::quoted(name))||position<0||position>3||path.empty()||path.size()>65536U||style.size()>65536U||name.size()>4096U||++links>8192U)return false;
            ui.nativeKeyboardLinks[style][static_cast<std::size_t>(position)]={std::move(path),std::move(name)};
        }else if(tag=="KMODE"){
            int next=0;if(!(input>>ui.styleToKeyboardSet>>next)||ui.styleToKeyboardSet<0||ui.styleToKeyboardSet>2||(next!=0&&next!=1))return false;
            // Legacy mode 2 followed Variations. Keep its Style link, but never
            // restore the removed Variation-to-Keyboard-Set behavior.
            if(ui.styleToKeyboardSet==2)ui.styleToKeyboardSet=1;
            ui.keyboardSetNextMeasure=next!=0;
        }else if(tag=="UPPER_LINK"){
            int linked=0;if(!(input>>linked)||(linked!=0&&linked!=1))return false;
            ui.upperVolumeLink=linked!=0;
        }else if(tag=="KBD_SPLIT"){
            int split=0,lower=0;if(!(input>>split>>lower)||(split!=0&&split!=1)||(lower!=0&&lower!=1))return false;
            ui.keyboardSplitEnabled=split!=0;ui.keyboardLowerMuteBeforeFull=lower!=0;
        }else if(tag=="KEYBOARD"){
            int native=0;if(!(input>>native>>std::quoted(ui.nativeKeyboardSetPath)>>std::quoted(ui.keyboardMetadataFile))||(native!=0&&native!=1)||ui.nativeKeyboardSetPath.size()>65536U||ui.keyboardMetadataFile.size()>128U)return false;
            ui.nativeKeyboardActive=native!=0;
        }else if(tag=="KEYBOARD_ENTRY"){
            if(!(input>>std::quoted(ui.savedKeyboardEntryPath))||ui.savedKeyboardEntryPath.size()>65536U)return false;
        }else if(tag=="COMBI_OWNER"){
            if(ui.currentCombiSlot!=0||!(input>>ui.currentCombiSlot>>std::quoted(ui.currentCombiBankIdentity))||ui.currentCombiSlot<1||ui.currentCombiSlot>500||ui.currentCombiBankIdentity.empty()||ui.currentCombiBankIdentity.size()>65536U)return false;
        }else if(tag=="STYLE_KBD_OWNER"){
            if(ui.styleKeyboardPosition!=-1||!(input>>std::quoted(ui.styleKeyboardOwner)>>ui.styleKeyboardPosition)||ui.styleKeyboardOwner.empty()||ui.styleKeyboardOwner.size()>65536U||ui.styleKeyboardPosition<0||ui.styleKeyboardPosition>3)return false;
        }else if(tag=="HOST"){
            if(hostSeen||!(input>>std::quoted(hostText))||hostText.empty()||hostText.size()>1024U*1024U)return false;
            hostSeen=true;
        }else if(tag=="END"){ended=true;break;}
        else return false;
    }
    input>>std::ws;if(!ended||!rootSeen||!viewSeen||!hostSeen||!input.eof()||(ui.styleKeyboardPosition>=0&&ui.currentCombiSlot>0))return false;
    persistentRestoreRoot_=root;savedKstRoot_=root;persistentRestoreText_=std::move(hostText);
    keyboardMetadataRestorePending_=ui.nativeKeyboardActive;activeNativeKeyboardSetPath_=ui.nativeKeyboardSetPath;activeSavedKeyboardEntryPath_=ui.savedKeyboardEntryPath;keyboardMetadataFile_=ui.keyboardMetadataFile;
    persistentRestoreUi_=std::move(ui);persistentLastSaved_=std::move(data);persistentRecordValid_=true;return true;
}
std::string ArrangerView::persistentStateText() const{
    const auto hostText=host::arrangerHost().persistentSession();if(hostText.empty())return {};
    std::ostringstream output;output<<"SILVETON_ARRANGER_SESSION 2\nROOT "<<std::quoted(savedKstRoot_)<<
        "\nVIEW "<<selectedPlayer_<<' '<<kstCatalogTab_<<' '<<mixerStyle_<<"\nBROWSE "<<std::quoted(pickerDirectory_)<<'\n';
    for(const auto& selected:styleSelectStates_){
        const auto& selectorKey=selected.first;const auto& state=selected.second;
        output<<"SELECTOR "<<std::quoted(selectorKey.first)<<' '<<selectorKey.second<<' '<<std::quoted(state.browserPath)<<' '<<std::quoted(state.categoryPath)<<' '<<state.categoryPage<<' '<<state.initialized<<' '<<std::quoted(state.lastSourcePath)<<'\n';
        for(const auto& page:state.pages)output<<"PAGE "<<std::quoted(selectorKey.first)<<' '<<selectorKey.second<<' '<<std::quoted(page.first)<<' '<<page.second<<'\n';
    }
    for(const auto& link:keyboardSetLinks_)for(std::size_t position=0;position<link.second.size();++position)
        if(link.second[position].first>0)output<<"K "<<std::quoted(link.first)<<' '<<position<<' '<<link.second[position].first<<' '<<std::quoted(link.second[position].second)<<'\n';
    for(const auto& link:nativeKeyboardSetLinks_)for(std::size_t position=0;position<link.second.size();++position)
        if(!link.second[position].first.empty())output<<"NK "<<std::quoted(link.first)<<' '<<position<<' '<<std::quoted(link.second[position].first)<<' '<<std::quoted(link.second[position].second)<<'\n';
    output<<"KMODE "<<styleToKeyboardSet_<<' '<<keyboardSetNextMeasure_<<'\n';
    output<<"UPPER_LINK "<<upperVolumeLink_<<'\n';
    output<<"KBD_SPLIT "<<keyboardSplitEnabled_<<' '<<keyboardLowerMuteBeforeFull_<<'\n';
    const bool nativeKeyboard=!keyboardMetadataFile_.empty()&&ctrl_.engine.nativeKeyboardCombi()!=nullptr;
    output<<"KEYBOARD "<<nativeKeyboard<<' '<<std::quoted(activeNativeKeyboardSetPath_)<<' '<<std::quoted(keyboardMetadataFile_)<<'\n';
    output<<"KEYBOARD_ENTRY "<<std::quoted(activeSavedKeyboardEntryPath_)<<'\n';
    if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4&&!selectedStyleKey_.empty())
        output<<"STYLE_KBD_OWNER "<<std::quoted(selectedStyleKey_)<<' '<<selectedKeyboardSet_<<'\n';
    else if(currentKeyboardCombiSlot_>=1&&currentKeyboardCombiSlot_<=500&&!currentKeyboardCombiBankIdentity_.empty())
        output<<"COMBI_OWNER "<<currentKeyboardCombiSlot_<<' '<<std::quoted(currentKeyboardCombiBankIdentity_)<<'\n';
    output<<"HOST "<<std::quoted(hostText)<<"\nEND\n";return output.str();
}
void ArrangerView::flushPersistentState(){
    flushGlobalSettings();
    finishPersistentSave(true);
    if(!persistentConfigured_||!persistentSaveAllowed_||persistentRestorePending_||kstJob_)return;
    if(!saveKeyboardPerformanceMetadata()){showToast(keyboardMetadataError_,7000);return;}
    const auto hostRevision=host::arrangerHost().persistenceRevision();
    const auto text=persistentStateText();
    if(text.empty()){const auto error=host::arrangerHost().lastError();if(!error.empty())showToast("Session was not saved: "+error,7000);return;}
    if(text!=persistentLastSaved_&&!writePersistentRecord(persistentSessionPath_,text,kstStatePath_,savedKstRoot_)){
        persistentSavePending_=true;
        persistentChangedAt_=nowMs()+1500;
        showToast("Session could not be saved; the previous session was kept",6000);return;
    }
    persistentLastSaved_=text;persistentRecordProtected_=true;persistentRecordValid_=true;
    persistentObservedHostRevision_=hostRevision;persistentObservedUiRevision_=persistentUiRevision_;
    persistentSavePending_=false;
}
void ArrangerView::markPersistentStateChanged(bool refreshMetadata){++persistentUiRevision_;if(refreshMetadata)lastMetadataPoll_=-1000;}
void ArrangerView::finishPersistentSave(bool wait){
    if(!persistentSaveJob_||(!wait&&!persistentSaveJob_->done.load(std::memory_order_acquire)))return;
    auto job=std::move(persistentSaveJob_);
    if(job->worker.joinable())job->worker.join();
    if(job->success){
        persistentLastSaved_=std::move(job->text);persistentRecordProtected_=true;persistentRecordValid_=true;
    }else{
        persistentSavePending_=true;persistentChangedAt_=nowMs()+1500;
        showToast("Session could not be saved; the previous session was kept",6000);
    }
}
void ArrangerView::pollPersistentState(std::int64_t now){
    finishPersistentSave(false);
    if(persistentRestoreActive_&&!kstJob_){finishPersistentRestore();return;}
    if(!persistentConfigured_||!persistentSaveAllowed_||persistentRestorePending_||kstJob_)return;
    const auto hostRevision=host::arrangerHost().persistenceRevision();
    if(hostRevision!=persistentObservedHostRevision_||persistentUiRevision_!=persistentObservedUiRevision_){
        persistentObservedHostRevision_=hostRevision;persistentObservedUiRevision_=persistentUiRevision_;
        persistentChangedAt_=now;persistentSavePending_=true;
    }
    // Do not capture/write keyboard metadata in the middle of a live gesture.
    // Explicit Save and lifecycle flushes retain their separate immediate path.
    if(pointerActive_||!persistentSavePending_||persistentSaveJob_||now-persistentChangedAt_<500)return;
    if(!saveKeyboardPerformanceMetadata()){persistentChangedAt_=now;showToast(keyboardMetadataError_,7000);return;}
    auto text=persistentStateText();if(text.empty()){persistentChangedAt_=now;return;}
    persistentSavePending_=false;if(text==persistentLastSaved_)return;
    auto job=std::make_shared<PersistentSaveJob>();job->text=std::move(text);
    const auto sessionPath=persistentSessionPath_,legacyPath=kstStatePath_,root=savedKstRoot_;
    persistentSaveJob_=job;
    try{
        job->worker=std::thread([job,sessionPath,legacyPath,root]{
            try{job->success=writePersistentRecord(sessionPath,job->text,legacyPath,root);}catch(...){job->success=false;}
            job->done.store(true,std::memory_order_release);
        });
    }catch(...){
        job->success=false;job->done.store(true,std::memory_order_release);finishPersistentSave(false);
    }
}
void ArrangerView::abandonPersistentRestore(){
    if(persistentRestoreLease_)host::arrangerHost().cancelPersistentSessionRestore();
    persistentRestoreLease_=false;persistentRestoreActive_=false;persistentHostPosted_=false;persistentRestorePending_=false;
    persistentRestoreRoots_.clear();persistentRestoreNext_=0;
}
void ArrangerView::persistentRestoreFailed(const std::string& reason){
    if(mediaRestore_){failMediaRestore(reason);return;}
    if(persistentRestoreLease_)host::arrangerHost().cancelPersistentSessionRestore();
    persistentRestoreLease_=false;persistentRestoreActive_=false;persistentRestorePending_=true;
    persistentRestoreNext_=0;persistentSaveAllowed_=false;
    if(picker_==Picker::KstProgress){
        if(kstCatalog_)openKstCatalog();
        else{picker_=Picker::None;editor_=false;tab_=Tab::Main;}
    }
    if(ctrl_.initialBankLoadFinished())restoreSavedGlobalSettings();
    showToast(reason.empty()?"Saved session could not be restored; it was kept for retry":reason+" — saved session kept",8000);
}
void ArrangerView::resumePersistentState(){
    dirty_=true;lastMetadataPoll_=-1000;
    if(!persistentConfigured_||!persistentRestorePending_||persistentRestoreActive_||!persistentRestoreRetry_||kstJob_)return;
    if(storageAccessRequest_&&!storageAccessRequest_())return;
    const auto normalized=[](const std::string& path){const auto canonical=canonicalKstPath(path);return canonical.empty()?path:canonical;};
    std::vector<std::string> keyboardRoots;
    for(const auto& path:mediaRestore_?mediaRestoreSetRoots():keyboardPerformanceSetRoots()){
        const auto root=normalized(path);if(!root.empty()&&std::find(keyboardRoots.begin(),keyboardRoots.end(),root)==keyboardRoots.end())keyboardRoots.push_back(root);
    }
    if(!persistentRestoreText_.empty()){
        if(!host::arrangerHost().beginPersistentSessionRestore(persistentRestoreText_,keyboardRoots)){persistentRestoreFailed(host::arrangerHost().lastError());return;}
        persistentRestoreLease_=true;
        persistentRestoreRoots_=host::arrangerHost().persistentSessionSetRoots(persistentRestoreText_);
    }else persistentRestoreRoots_.clear();
    std::vector<std::string> uniqueRoots;
    const auto addRoot=[&](const std::string& path){const auto root=normalized(path);
        if(!root.empty()&&std::find(uniqueRoots.begin(),uniqueRoots.end(),root)==uniqueRoots.end())uniqueRoots.push_back(root);};
    for(const auto& root:persistentRestoreRoots_)addRoot(root);
    for(const auto& root:keyboardRoots)addRoot(root);
    if(!persistentRestoreRoot_.empty()){
        const auto catalog=normalized(persistentRestoreRoot_);
        uniqueRoots.erase(std::remove(uniqueRoots.begin(),uniqueRoots.end(),catalog),uniqueRoots.end());uniqueRoots.push_back(catalog);
    }
    persistentRestoreRoots_=std::move(uniqueRoots);
    if(persistentRestoreRoots_.size()>10U){persistentRestoreFailed("Saved session references too many SET folders");return;}
    persistentRestoreActive_=true;persistentHostPosted_=false;persistentRestoreNext_=0;
    (void)host::arrangerHost().stop(0);(void)host::arrangerHost().stop(1);
    (void)host::arrangerHost().setSyncStart(0,false);(void)host::arrangerHost().setSyncStart(1,false);
    if(!persistentRestoreRoots_.empty()){
        startKstScan(persistentRestoreRoots_.front(),true);
        if(!kstJob_)persistentRestoreFailed("Saved SET folder is unavailable");
    }else finishPersistentRestore();
}
void ArrangerView::finishPersistentRestore(){
    if(!persistentRestoreActive_||kstJob_||persistentRestoreNext_<persistentRestoreRoots_.size())return;
    // Startup bank publication can overwrite tuning and legacy keyboard links,
    // so restore both the host and UI only after that publication has finished.
    if(!ctrl_.initialBankLoadFinished())return;
    if(mediaRestore_&&!prepareMediaRestore())return;
    if(!persistentHostPosted_){
        if(!persistentRestoreText_.empty()&&!host::arrangerHost().restorePersistentSession(persistentRestoreText_)){
            persistentRestoreFailed(host::arrangerHost().lastError());return;
        }
        persistentHostPosted_=true;kstProgress_.phase="Applying SET";dirty_=true;
    }
    if(!host::arrangerHost().persistentSessionRestoreCommitted())return;
    refresh();
    int restoredStyleKeyboardPosition=-1;std::string restoredStyleKeyboardOwner;
    if(persistentRestoreUi_){
        auto ui=std::move(*persistentRestoreUi_);persistentRestoreUi_.reset();
        restoredStyleKeyboardPosition=ui.styleKeyboardPosition;restoredStyleKeyboardOwner=std::move(ui.styleKeyboardOwner);
        selectedPlayer_=ui.selectedPlayer;kstCatalogTab_=ui.catalogTab;mixerStyle_=ui.mixerStyle;
        pickerDirectory_=std::move(ui.pickerDirectory);styleSelectStates_=std::move(ui.selectors);keyboardSetLinks_=std::move(ui.keyboardLinks);
        nativeKeyboardSetLinks_=std::move(ui.nativeKeyboardLinks);styleToKeyboardSet_=ui.styleToKeyboardSet;keyboardSetNextMeasure_=ui.keyboardSetNextMeasure;upperVolumeLink_=ui.upperVolumeLink;
        keyboardSplitEnabled_=ui.keyboardSplitEnabled;keyboardLowerMuteBeforeFull_=ui.keyboardLowerMuteBeforeFull;
        currentKeyboardCombiSlot_=ui.currentCombiSlot;currentKeyboardCombiBankIdentity_=std::move(ui.currentCombiBankIdentity);
        for(auto& selected:styleSelectStates_){selected.second.lastSourcePath=players_[static_cast<std::size_t>(selected.first.second)].sourcePath;selected.second.locateActive=false;}
    }
    if(!host::arrangerHost().setSplitEnabled(keyboardSplitEnabled_)){
        persistentRestoreFailed(host::arrangerHost().lastError());return;
    }
    if(keyboardMetadataRestorePending_&&!restoreKeyboardPerformanceMetadata()){persistentRestoreFailed(keyboardMetadataError_);return;}
    keyboardMetadataRestorePending_=false;
    selectedStyleKey_.clear();selectStyleLinks();
    if(restoredStyleKeyboardPosition>=0&&restoredStyleKeyboardPosition<4&&restoredStyleKeyboardOwner==selectedStyleKey_){
        selectedKeyboardSet_=restoredStyleKeyboardPosition;currentKeyboardCombiSlot_=0;currentKeyboardCombiBankIdentity_.clear();
        keyboardWorkingSets_[static_cast<std::size_t>(selectedKeyboardSet_)]=captureKeyboardWorkingSet();
    }
    const bool restoringMedia=mediaRestore_!=nullptr;
    if(mediaRestore_&&!finishMediaRestore())return;
    if(!restoringMedia)restoreSavedGlobalSettings();
    if(persistentRestoreLease_)host::arrangerHost().cancelPersistentSessionRestore();
    persistentRestoreLease_=false;persistentHostPosted_=false;
    navigationHistory_.clear();panelMode_=PanelMode::Home;
    tab_=Tab::Main;picker_=Picker::None;editor_=false;
    keyboardRecallStyle_=arrangerStyleSelectionKey(players_[static_cast<std::size_t>(selectedPlayer_)]);
    keyboardRecallElement_=players_[static_cast<std::size_t>(selectedPlayer_)].element;
    persistentRestoreActive_=false;persistentRestorePending_=false;
    persistentSaveAllowed_=!persistentRecordProtected_||persistentRecordValid_;
    persistentRestoreRoots_.clear();persistentRestoreNext_=0;dirty_=true;
    markPersistentStateChanged();persistentChangedAt_=nowMs();flushPersistentState();
    if(!persistentSaveAllowed_)showToast("The stored session could not be read. Its file was kept; select a Style to save a new session.",8000);
}
void ArrangerView::home(){
    if(leaveInstrumentEditor())return;
    if(homeSoundEdit_)closeSoundWindow();
    navigationHistory_.clear();panelMode_=PanelMode::Home;cancelKeyboardSetHold();targetTrack_=-1;targetPart_=0;targetKbdSet_=-1;targetKbdPlayer_=-1;targetKbdSerial_=0;styleSelectorPlayer_=-1;host::arrangerHost().stopPcmPreview();closeKstScan();picker_=Picker::None;editor_=false;tab_=Tab::Main;held_={};dirty_=true;refresh();}
void ArrangerView::openEditor(Page p){rememberNavigation();closeKstScan();picker_=Picker::None;editor_=true;setPage(p);dirty_=true;}
bool ArrangerView::dialogOpen() const {return homeSoundEdit_||picker_!=Picker::None||editor_;}
void ArrangerView::keyDown(Key k){
    if(k==Key::Escape){markPersistentStateChanged();panelExit();return;}
    if(editor_){SilvetonSamplerView::keyDown(k);dirty_=true;}
}
void ArrangerView::secondPointerDown(float x,float y){if(editor_)SilvetonSamplerView::secondPointerDown(x,y);}
void ArrangerView::tick(std::int64_t now){
    if(previewDrumNote_>=0&&(now>=previewDrumDeadline_||picker_!=Picker::StyleDrums)){
        host::arrangerHost().releasePreviewNote(previewDrumNote_);previewDrumNote_=-1;dirty_=true;
    }
    if(drumMidiLearn_&&picker_==Picker::DrumKitEdit&&drumDraft_&&!drumExitPrompt_){
        const auto input=host::arrangerHost().takeEditorNote();
        if(input>=0){drumKey_=input>>7;const int velocity=input&127;drumZone_=0;
            const auto& zones=drumDraft_->keys[drumKey_];
            for(std::size_t i=0;i<zones.size();++i)if(zones[i].zone.matches(drumKey_,velocity)){drumZone_=static_cast<int>(i);break;}
            dirty_=true;}
    }
    if(warningChanged_.exchange(false,std::memory_order_acq_rel))dirty_=true;
    if(keyboardHoldDeadline_>0){
        const auto owner=host::arrangerHost().snapshot(selectedPlayer_);
        if(!pointerActive_||editor_||picker_!=Picker::None||styleKeyboardCue_.serial!=0||
           selectedKeyboardSet_!=keyboardHoldPosition_||arrangerStyleSelectionKey(owner)!=keyboardHoldStyleKey_||
           owner.styleSelectionSerial!=keyboardHoldStyleSerial_)cancelKeyboardSetHold();
        else if(now>=keyboardHoldDeadline_){cancelKeyboardSetHold();openResourceSave(false);}
    }
    const auto& selected=players_[static_cast<std::size_t>(selectedPlayer_)];
    const bool flash=selected.loopElement>=0||selected.pendingElement>=0||selected.element<3||
        (selected.element>=7&&selected.element<=11);
    const auto phase=now/250;
    if(!liveView_&&!editor_&&flash&&phase!=panelFlashPhase_){panelFlashPhase_=phase;dirty_=true;}
    if(editor_){
        SilvetonSamplerView::tick(now);
        int unit=0;
        if(picker_==Picker::None&&SilvetonSamplerView::takeArrangerFxSelection(unit)){
            trackEditPlayer_=-1;keyboardFxUnit_=unit;
            if(unit>=4){keyboardEditPart_=unit-4;keyboardExtension_=keyboardEditPart_>=3&&keyboardEditPart_<=5;}
            openKeyboardEdit(unit>=4?KeyboardEditPage::InsertFx:KeyboardEditPage::Effects);
        }
    }
    pollKstScan();
    if(tab_==Tab::Chords&&chordSequencePage_&&now-lastPoll_>=100){
        const auto revision=host::arrangerHost().chordSequence().revision;
        if(revision!=chordSequenceSeen_){chordSequenceSeen_=revision;dirty_=true;}
    }
    const auto pollInterval=interactiveFeedbackActive(now)?12:(picker_==Picker::DrumFamilyEdit&&drumStyleNotes_?25:100);
    if(now-lastPoll_>=pollInterval){refresh(false);pollKeyboardSetRecall();pollPersistentState(now);pollGlobalSettings(now);lastPoll_=now;}
    if(soundWindowVisible()&&tonePage_==3&&!soundResetPanel_){
        if(now-gatePollMs_>=50){
            gatePollMs_=now;
            const auto key=gateMeterDisplayKey(visibleGateReduction());
            if(!gateDisplayValid_||key!=gateDisplayKey_){gateDisplayKey_=key;gateDisplayValid_=true;dirty_=true;}
        }
    }else gateDisplayValid_=false;
    if(eqTapPlayer_!=-2){
        if(!soundWindowVisible()||tonePage_!=2||soundResetPanel_||!eqAnalyzerOn_)stopEqTap();
        else if(now-lastDraw_>=50)dirty_=true;
    }
    if(!toast_.empty()&&now>=toastUntil_){toast_.clear();dirty_=true;}
}
bool ArrangerView::redrawDue(std::int64_t now) const{return dirty_||(editor_&&SilvetonSamplerView::redrawDue(now));}
std::int64_t ArrangerView::nextWorkMs() const {
    auto due=lastPoll_+(interactiveFeedbackActive(nowMs())?12:(picker_==Picker::DrumFamilyEdit&&drumStyleNotes_?25:100));
    if(eqTapPlayer_!=-2)due=std::min(due,lastDraw_+50);
    if(soundWindowVisible()&&tonePage_==3&&!soundResetPanel_)due=std::min(due,gatePollMs_+50);
    if(keyboardHoldDeadline_>0)due=std::min(due,keyboardHoldDeadline_);
    return dirty_?0:std::min(due,editor_?SilvetonSamplerView::nextWorkMs():due);
}
std::uint64_t ArrangerView::renderCacheKey() const noexcept {
    // Select a bounded retained menu slot. Names, values, meter readings and
    // source revisions deliberately do not create new slots; they are diffed.
    detail::ViewStateKey key;key.add(0x415252414E474552ULL);key.add(editor_);
    if(editor_){key.add(SilvetonSamplerView::renderCacheKey());return key.value;}
    key.add(colorTheme());key.add(tab_);if(tab_==Tab::Chords){key.add(chordSequencePage_);key.add(chordSequenceEdit_);}key.add(picker_);key.add(panelMode_);key.add(globalPage_);
    if(picker_==Picker::DrumFamilyEdit)key.add(drumStyleNotes_);
    key.add(liveView_);key.add(homeSoundEdit_);key.add(homeToneKeyboard_);key.add(homeTonePart_);
    key.add(tonePage_);key.text(toneDetail_);key.add(soundResetPanel_);
    key.add(selectedPlayer_);key.add(mixerStyle_);key.add(keyboardEditPage_);key.add(keyboardEditPart_);
    key.add(trackEditPlayer_);key.add(styleEditTrack_);key.add(keyboardExtension_);key.add(styleTracksSecondPage_);
    key.add(pickerPage_);key.add(pickerCategory_);key.add(kstCatalogTab_);key.add(kstCatalogPage_);
    key.add(kstReportTab_);key.add(kstReportPage_);key.add(fxCatalogCategory_);key.add(fxCatalogPage_);
    key.add(numberedFxSection_);key.add(numberedFxPage_);key.add(numberedFxZoom_);key.add(originalSoundTab_);
    return key.value;
}
std::uint64_t ArrangerView::gateMeterDisplayKey(float reduction) const noexcept {
    detail::ViewStateKey key;
    key.add(detail::displayNumber(reduction,10));
    key.add(detail::displayNumber(std::clamp(reduction/40.0F,0.0F,1.0F)*882.0F*scale_));
    return key.value;
}
float ArrangerView::visibleGateReduction() const {
    const int player=selectedPlayer_,part=homeTonePart_;
    if(kstJob_||persistentRestoreActive_||part<0||part>=(homeToneKeyboard_?7:8))return 0;
    std::uint64_t serial=0;
    const auto owner=homeToneKeyboard_?ctrl_.engine.nativeKeyboardCombi():host::arrangerHost().styleTrackCombi(player,serial);
    if(!owner||!owner->part(part).channelGate.enabled)return 0;
    if(homeToneKeyboard_){if(!owner->part(part).hasAnySound())return 0;}
    else{
        const auto& state=players_[static_cast<std::size_t>(player)];
        if(!state.loaded||state.styleSwitchPending||serial!=state.styleSelectionSerial||!state.tracks[part].assigned)return 0;
    }
    return homeToneKeyboard_?ctrl_.engine.nativeGateReduction(part):host::arrangerHost().styleGateReduction(player,part);
}

void ArrangerView::startKstScan(const std::string& path,bool automatic){
    if(storageAccessRequest_&&!storageAccessRequest_())return;
    const auto root=canonicalKstPath(path);
    if(automatic&&persistentRestorePending_&&!persistentRestoreActive_){resumePersistentState();return;}
    // A repeated input while this exact full request is running joins that
    // operation. A later explicit LOAD still performs its fresh revision pass.
    if(kstJob_&&!root.empty()&&kstJob_->rootPath==root&&kstJob_->automaticRequest==automatic&&
       kstJob_->restoringSession==persistentRestoreActive_&&!kstJob_->cancel.load(std::memory_order_acquire)){
        picker_=Picker::KstProgress;editor_=false;dirty_=true;return;
    }
    if(!automatic){
        const bool retryableSession=persistentRestoreText_.empty()||!host::arrangerHost().persistentSessionSetRoots(persistentRestoreText_).empty();
        if(persistentRestorePending_&&retryableSession&&!persistentRestoreRoot_.empty()&&root==canonicalKstPath(persistentRestoreRoot_)){
            closeKstScan(true);
            if(persistentRestoreLease_)host::arrangerHost().cancelPersistentSessionRestore();
            persistentRestoreLease_=false;persistentRestoreActive_=false;persistentRestoreRetry_=true;
            resumePersistentState();return;
        }
        abandonPersistentRestore();
    }
    if(!arranger::canSelectPa5xKstDirectory(path)){showToast("Select the Pa .SET or .KST folder containing the resources",5000);return;}
    if(picker_!=Picker::KstProgress)rememberNavigation();
    closeKstScan(true);kstDetail_.clear();kstReportTab_=0;kstReportPage_=0;
    kstProgress_={0,0,automatic?"Restoring saved SET":"Reading folder",path};kstPcmCacheProgress_.clear();
    auto job=std::make_shared<KstJob>();job->progress=kstProgress_;job->rootPath=root;job->restoringSession=persistentRestoreActive_;job->automaticRequest=automatic;kstJob_=job;
    picker_=Picker::KstProgress;editor_=false;dirty_=true;
    try {
        std::thread([job,path,automatic,cacheDirectory=sampleCacheDirectory_]{
            std::shared_ptr<arranger::Pa5xKstIndex> result;
            try {
                const auto updateProgress=[job](const arranger::KstProgress& progress){
                    std::lock_guard<std::mutex> lock(job->mutex);job->progress=progress;
                    if(job->stage>0)job->progress.phase="Step "+std::to_string(job->stage)+" / 5 — "+progress.phase;
                };
                std::unique_lock<std::mutex> preparationLock(setPreparationMutex,std::defer_lock);
                if(!preparationLock.try_lock()){
                    updateProgress({0,0,"Waiting for the previous SET read to finish",path});
                    preparationLock.lock();
                }
                if(job->cancel.load(std::memory_order_acquire)){
                    auto cancelled=std::make_shared<arranger::Pa5xKstIndex>();
                    cancelled->rootPath=path;cancelled->cancelled=true;
                    {
                        std::lock_guard<std::mutex> lock(job->mutex);
                        job->result=std::move(cancelled);
                    }
                    job->done.store(true,std::memory_order_release);return;
                }
                const auto setStage=[job](int stage){std::lock_guard<std::mutex> lock(job->mutex);job->stage=stage;};
                arranger::Pa5xMultisampleCache cache;arranger::Pa5xMultisampleBuildOptions options;
                configureSetSampleCache(cacheDirectory,&job->cancel,cache,options);
                if(automatic){
                    arranger::Pa5xPreparedSetSnapshot restored;
                    if(arranger::loadPa5xPreparedSetSnapshot(job->rootPath,cacheDirectory,restored,&job->cancel,updateProgress)){
                        addSampleCoverage(restored.index,*restored.bank);
                        std::vector<host::ArrangerOriginalProgram> programs;programs.reserve(restored.programs.size());
                        for(auto& program:restored.programs)programs.push_back({program.msb,program.lsb,program.program,std::move(program.sound)});
                        {
                            std::lock_guard<std::mutex> lock(job->mutex);
                            job->result=std::make_shared<arranger::Pa5xKstIndex>(std::move(restored.index));
                            job->catalog=std::make_shared<arranger::Pa5xKstCatalog>(std::move(restored.catalog));
                            job->bank=std::move(restored.bank);job->programs=std::move(programs);job->warnings=std::move(restored.warnings);
                            job->pcmCacheProgress="Saved SET restored: source PCM read 0 / decoded 0 / instrument rebuild 0";
                            job->progress={1,1,"Saved SET ready",job->rootPath};
                        }
                        job->done.store(true,std::memory_order_release);return;
                    }
                    updateProgress({0,0,"Preparing saved SET cache",path});
                }
                setStage(1);
                const auto sourceState=arranger::capturePa5xPreparedSetSources(job->rootPath,&job->cancel);
                auto index=arranger::indexPa5xKst(path,updateProgress,&job->cancel,true);
                result=std::make_shared<arranger::Pa5xKstIndex>(std::move(index));
                if(!job->cancel.load(std::memory_order_acquire)){
                    auto bank=std::make_shared<arranger::Pa5xSetBank>();setStage(2);
                    const auto sampleProgress=[&](const arranger::KstProgress& p){
                        updateProgress(p);
                        std::lock_guard<std::mutex> lock(job->mutex);
                        job->pcmCacheProgress="Sample buffers prepared so far: "+std::to_string(cache.samples.size());
                    };
                    (void)bank->loadForSamplePlayback(*result,sampleProgress,&job->cancel,&options,&cache);
                    if(!job->cancel.load(std::memory_order_acquire)){
                        finishSampleResourceIndex(*result,*bank);
                        const auto activity=std::find_if(result->diagnostics.begin(),result->diagnostics.end(),[](const arranger::KstDiagnostic& diagnostic){return diagnostic.code=="PCM_CACHE_ACTIVITY";});
                        if(activity!=result->diagnostics.end()){std::lock_guard<std::mutex> lock(job->mutex);job->pcmCacheProgress="Samples ready "+std::to_string(bank->status().samplesReady)+"  |  "+activity->message;}
                        setStage(3);
                        auto catalog=arranger::buildPa5xKstCatalog(*result,updateProgress,&job->cancel,bank.get());
                        result->metadataReadCache.reset();
                        {std::lock_guard<std::mutex> lock(job->mutex);job->catalog=std::make_shared<arranger::Pa5xKstCatalog>(std::move(catalog));}
                        setStage(4);
                        auto prepared=prepareSetSamples(*bank,cache,options,updateProgress,&job->cancel);
                        if(!job->cancel.load(std::memory_order_acquire)){
                            setStage(5);updateProgress({0,1,"Saving prepared SET",result->rootPath});
                            std::vector<arranger::Pa5xPreparedProgram> savedPrograms;savedPrograms.reserve(prepared.programs.size());
                            for(const auto& program:prepared.programs)savedPrograms.push_back({program.msb,program.lsb,program.program,program.sound});
                            if(!arranger::savePa5xPreparedSetSnapshot(cacheDirectory,*result,*job->catalog,*bank,savedPrograms,prepared.warnings,sourceState,&job->cancel)&&
                               !job->cancel.load(std::memory_order_acquire)){
                                const std::string message="Prepared SET could not be saved; the next startup will need preparation again";
                                prepared.warnings.push_back(message);
                                result->diagnostics.push_back({arranger::KstSeverity::Warning,"SET_SNAPSHOT_SAVE_FAILED",{},message});
                            }
                            if(job->cancel.load(std::memory_order_acquire))throw std::runtime_error("SET preparation cancelled");
                            std::lock_guard<std::mutex> lock(job->mutex);
                            job->programs=std::move(prepared.programs);job->warnings=std::move(prepared.warnings);job->bank=std::move(bank);
                        }
                    }
                }
            }catch(const std::exception& e){
                result=std::make_shared<arranger::Pa5xKstIndex>();result->rootPath=path;
                const auto slash=path.find_last_of('/');result->name=slash==std::string::npos?path:path.substr(slash+1);result->cancelled=job->cancel.load(std::memory_order_relaxed);
                result->diagnostics.push_back({arranger::KstSeverity::Blocking,"KST_READ_FAILED","",e.what()});
            }catch(...){
                result=std::make_shared<arranger::Pa5xKstIndex>();result->rootPath=path;
                result->diagnostics.push_back({arranger::KstSeverity::Blocking,"KST_READ_FAILED","","Cannot read the selected KST"});
            }
            if(result)result->metadataReadCache.reset(); // exception/cancellation paths release transient metadata too
            {std::lock_guard<std::mutex> lock(job->mutex);job->result=std::move(result);}
            job->done.store(true,std::memory_order_release);
        }).detach();
    }catch(const std::exception& e){kstJob_.reset();picker_=Picker::KstFolder;showToast(e.what(),5000);}
}
void ArrangerView::pollKstScan(){
    const auto job=kstJob_;if(!job)return;
    std::shared_ptr<const arranger::Pa5xKstIndex> completed;
    std::shared_ptr<const arranger::Pa5xKstCatalog> catalog;
    std::shared_ptr<const arranger::Pa5xSetBank> bank;
    {
        std::lock_guard<std::mutex> lock(job->mutex);
        const auto& p=job->progress;
        if(p.done!=kstProgress_.done||p.total!=kstProgress_.total||p.phase!=kstProgress_.phase||p.relativePath!=kstProgress_.relativePath){kstProgress_=p;dirty_=true;}
        if(job->pcmCacheProgress!=kstPcmCacheProgress_){kstPcmCacheProgress_=job->pcmCacheProgress;dirty_=true;}
        if(job->done.load(std::memory_order_acquire)){completed=job->result;catalog=job->catalog;bank=job->bank;}
    }
    if(completed){
        kstJob_.reset();kstReportTab_=0;kstReportPage_=0;kstDetail_.clear();
        const bool cancelled=job->cancel.load(std::memory_order_acquire)||completed->cancelled||(catalog&&catalog->cancelled);
        const bool legacyBanks=std::any_of(completed->diagnostics.begin(),completed->diagnostics.end(),
            [](const auto& diagnostic){return diagnostic.code=="LEGACY_PA_BANK";});
        const bool unsupportedOnly=catalog&&catalog->styles.empty()&&catalog->sounds.empty()&&catalog->samples.empty()&&catalog->keyboardSets.empty();
        const bool accepted=!unsupportedOnly&&catalog&&catalog->recognized&&bank&&bank->status().recognized&&!cancelled&&host::arrangerHost().installKorgSampleBank(bank,job->programs,job->warnings,hasReadablePerformanceCatalog(*catalog));
        if(accepted){
            kstReport_=std::move(completed);kstCatalog_=std::move(catalog);savedKstRoot_=kstCatalog_->rootPath;
            updatePcmFileReport(bank.get(),*kstReport_);classifySetSamples(*bank);
            keyboardSetContents_.reset();
            if(job->restoringSession&&persistentRestoreActive_){
                ++persistentRestoreNext_;
                if(persistentRestoreNext_<persistentRestoreRoots_.size()){
                    startKstScan(persistentRestoreRoots_[persistentRestoreNext_],true);
                    if(!kstJob_)persistentRestoreFailed("Saved SET folder is unavailable");
                }else{
                    kstProgress_.phase="Restoring saved player settings";kstProgress_.relativePath.clear();finishPersistentRestore();
                }
                dirty_=true;return;
            }
            persistentSaveAllowed_=true;persistentRecordProtected_=false;
            if(!mediaLoadingSource_.empty()&&canonicalKstPath(savedKstRoot_)==mediaLoadingSource_){rememberMediaSetPath({});mediaLoadingSource_.clear();}
            if(!pendingStylePath_.empty()){
                const auto path=std::move(pendingStylePath_);pendingStylePath_.clear();
                loadStyleForPlayback(pendingStylePlayer_,path);
            }else{
                styleSelectorPlayer_=selectedPlayer_;
                const int catalogTab=job->mediaTab>=0?job->mediaTab:!kstCatalog_->styles.empty()?0:!kstCatalog_->keyboardSets.empty()?2:!kstCatalog_->sounds.empty()?1:3;
                if(liveView_&&job->mediaTab<0){
                    navigationHistory_.clear();panelMode_=PanelMode::Home;tab_=Tab::Main;picker_=Picker::None;editor_=false;
                }else openKstCatalog(catalogTab);
                if(job->mediaTab>=0){
                    auto& state=catalogTab==0?styleSelectStates_[{kstCatalog_->rootPath,styleSelectorPlayer()}]:
                                              keyboardSelectStates_[{kstCatalog_->rootPath,catalogTab}];
                    state={};state.initialized=true;state.locateActive=false;
                    state.categoryPath=job->mediaBank.empty()?"@all":job->mediaBank;
                    state.locateCategory=!job->mediaBank.empty();
                    state.browserPath=files::parentOf(job->mediaBank);
                    state.lastSourcePath=catalogTab==0?players_[static_cast<std::size_t>(styleSelectorPlayer())].sourcePath:activeNativeKeyboardSetPath_;
                }
                const bool allPcmReady=!kstPcmFiles_.empty()&&std::all_of(kstPcmFiles_.begin(),kstPcmFiles_.end(),pcmFileReady);
                const auto* coverage=sampleCoverage(*kstReport_);
                const auto counts=std::to_string(kstCatalog_->styles.size())+" Style entries, "+
                    std::to_string(kstCatalog_->keyboardSets.size())+(catalogUsesPerformances(*kstCatalog_)?" Performance entries":" Keyboard Set entries");
                std::string detail;
                if(coverage&&coverage->severity==arranger::KstSeverity::Blocking)detail=coverage->message;
                else if(legacyBanks || (!kstPcmFiles_.empty()&&!allPcmReady))detail="See Report for unavailable resources";
                else if(!kstPcmFiles_.empty())detail=pcmFileSummary(kstPcmFiles_);
                const auto sampleCount=sampleSummary_.preparationKnown?"Samples ready "+std::to_string(sampleSummary_.ready)+" / "+std::to_string(sampleSummary_.identified)+" known. MEDIA > Sample Info":counts;
                showToast(sampleCount+(detail.empty()?std::string{}:" — "+detail),8500);
            }
            flushPersistentState();
        }else if(cancelled&&!job->restoringSession){
            pendingStylePath_.clear();if(!restoreNavigation()){picker_=Picker::None;editor_=false;tab_=Tab::Main;panelMode_=PanelMode::Home;}
            showToast("Scan cancelled. Current SET kept",5000);
        }else{
            pendingStylePath_.clear();kstReport_=std::move(completed);updatePcmFileReport(bank.get(),*kstReport_);
            kstReportTab_=4;picker_=Picker::KstReport;
            const auto problem=std::find_if(kstReport_->diagnostics.begin(),kstReport_->diagnostics.end(),[](const auto& d){return d.severity==arranger::KstSeverity::Blocking;});
            const std::string reason=problem!=kstReport_->diagnostics.end()?problem->message:unsupportedOnly?"No catalog entries found":"SET could not be opened";
            showToast(kstReport_->name+" — "+reason,8000);
        }
        if(!accepted&&!mediaLoadingSource_.empty()&&job->rootPath==mediaLoadingSource_)mediaLoadingSource_.clear();
        if(!accepted&&job->restoringSession){
            if(cancelled)persistentRestoreRetry_=false;
            persistentRestoreFailed(cancelled?"Session restoration cancelled":"Saved SET could not be opened");
        }
        dirty_=true;
    }
}
void ArrangerView::closeKstScan(bool preserveRestore){
    if(kstJob_)kstJob_->cancel.store(true,std::memory_order_release);
    kstJob_.reset();
    pendingStylePath_.clear();
    if(!preserveRestore&&persistentRestoreActive_){persistentRestoreRetry_=false;persistentRestoreFailed("Session restoration cancelled");}
}
void ArrangerView::loadStyleForPlayback(int player,const std::string& path,bool keepHome){
    player=std::clamp(player,0,1);
    styleSelectorPlayer_=player;
    if(kstJob_){showToast("The SET is loading. Wait for it to finish or press Cancel.",4500);return;}
    if(persistentRestorePending_)abandonPersistentRestore();
    const bool holdSelector=keepHome||picker_==Picker::KstCatalog||picker_==Picker::Style;
    const auto dot=path.find_last_of('.');
    auto extension=dot==std::string::npos?std::string{}:path.substr(dot);
    std::transform(extension.begin(),extension.end(),extension.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});
    const auto activeRoot=kstCatalog_?kstCatalog_->rootPath+"/":std::string{};
    if((arranger::paStyleSlot(path)||extension==".stg"||extension==".mid"||extension==".midi")&&(activeRoot.empty()||path.compare(0,activeRoot.size(),activeRoot)!=0)){
        // Prepare a different SET before requesting its Style. The current
        // player can continue while the new bank is read in the worker.
        auto root=files::parentOf(path);
        for(int depth=0;depth<32&&!root.empty();++depth){
            if(arranger::canSelectPa5xKstDirectory(root)){
                if(!kstCatalog_||canonicalKstPath(root)!=kstCatalog_->rootPath){
                    startKstScan(root,true);
                    if(kstJob_){pendingStylePath_=path;pendingStylePlayer_=player;}
                    return;
                }
                break;
            }
            const auto parent=files::parentOf(root);if(parent==root)break;root=parent;
        }
    }
    if(!host::arrangerHost().loadStyle(player,path)){
        stylePickerError_=host::arrangerHost().lastError();
        if(stylePickerError_.empty())stylePickerError_="Style could not be loaded";
        if(holdSelector)showToast(stylePickerError_,6000);
        else showStyleInfo("Style Load Failed",stylePickerError_);
        refresh();dirty_=true;return;
    }
    styleKeyboardSelectionAccepted(player);
    persistentSaveAllowed_=true;persistentRecordProtected_=false;
    stylePickerError_.clear();
    if(!holdSelector&&kstCatalog_)openKstCatalog(0,player);
    refresh();
    const auto& selected=players_[static_cast<std::size_t>(player)];
    if(selected.styleSwitchPending&&selected.pendingStylePath==path){dirty_=true;return;}
    const auto read=host::arrangerHost().styleRead(player);
    if(!read||!read->valid||!read->nativeStyle){dirty_=true;return;}
    if(!host::arrangerHost().styleBank(player)){
        // A directly browsed STG may precede opening its KST. Discover its
        // actual resource root and run the same cancellable bank load first.
        auto root=files::parentOf(path);
        for(int depth=0;depth<32&&!root.empty();++depth){
            if(arranger::canSelectPa5xKstDirectory(root)){
                startKstScan(root,true);
                if(kstJob_){pendingStylePath_=path;pendingStylePlayer_=player;}
                return;
            }
            const auto parent=files::parentOf(root);if(parent==root)break;root=parent;
        }
        showStyleInfo("Style samples", "Open the KST folder containing this Style's SOUND, MULTISMP and PCM resources, then select the Style again.");
        return;
    }
    dirty_=true;
}
void ArrangerView::drawKstProgress(Canvas& c){
    button(c,{3,3,96,35},"‹ Back",orange,false,true,[this]{panelExit();},16);
    label(c,"LOAD SET",115,27,19,orange,true,570);
    const bool cancelling=kstJob_&&kstJob_->cancel.load(std::memory_order_acquire);
    label(c,cancelling?"Cancelling…":"Loading the SET and its instruments",400,114,25,white,true,750,Align::Center);
    const bool waitingForAudio=persistentRestoreActive_&&persistentHostPosted_&&!kstJob_&&audioSampleRate_<=0;
    label(c,waitingForAudio?"Waiting for audio — Cancel to return":kstProgress_.phase,400,166,18,dim,false,740,Align::Center);
    const auto total=kstProgress_.total;
    const double ratio=total>0?std::clamp(static_cast<double>(kstProgress_.done)/static_cast<double>(total),0.0,1.0):0.0;
    box(c,{60,205,740,241},panel,kBorder,3);
    if(ratio>0)box(c,{63,208,63+674*static_cast<float>(ratio),238},orange);
    const auto count=total>0?std::to_string(kstProgress_.done)+" / "+std::to_string(total)+" items":"Preparing...";
    label(c,count,400,280,26,orange,true,700,Align::Center);
    label(c,kstProgress_.relativePath,400,324,16,dim,false,740,Align::Center);
    if(!kstPcmCacheProgress_.empty())label(c,kstPcmCacheProgress_,400,352,12,dim,false,740,Align::Center);
    label(c,persistentRestoreActive_?"Restoring saved session — playback stays stopped":"Current performance is unchanged",400,375,17,green,false,740,Align::Center);
    button(c,{250,409,550,456},cancelling?"Cancelling…":"Cancel",orange,false,!cancelling,[this]{if(kstJob_)kstJob_->cancel.store(true,std::memory_order_release);else if(persistentRestoreActive_)closeKstScan();dirty_=true;},18);
}
void ArrangerView::drawKstReport(Canvas& c){
    button(c,{3,3,96,35},"‹ Back",orange,false,true,[this]{if(!kstDetail_.empty()){kstDetail_.clear();kstReportPage_=kstReportListPage_;}else{panelExit();}dirty_=true;},16);
    if(!kstReport_){label(c,"No KST selected",400,245,23,dim,false,740,Align::Center);return;}
    const auto& report=*kstReport_;
    label(c,kstDetail_.empty()?"Pa SET / KST":kstDetailTitle_,115,27,19,orange,true,660);
    const auto pageControls=[this,&c](int pages){
        pages=std::max(1,pages);kstReportPage_=std::clamp(kstReportPage_,0,pages-1);
        button(c,{15,404,96,441},"◀",orange,false,kstReportPage_>0,[this]{--kstReportPage_;dirty_=true;},18);
        button(c,{108,404,190,441},"First",orange,false,kstReportPage_>0,[this]{kstReportPage_=0;dirty_=true;},14);
        label(c,std::to_string(kstReportPage_+1)+" / "+std::to_string(pages),400,430,17,dim,false,570,Align::Center);
        button(c,{610,404,692,441},"Last",orange,false,kstReportPage_+1<pages,[this,pages]{kstReportPage_=pages-1;dirty_=true;},14);
        button(c,{704,404,785,441},"▶",orange,false,kstReportPage_+1<pages,[this]{++kstReportPage_;dirty_=true;},18);
    };
    if(!kstDetail_.empty()){
        const auto lines=wrappedKstText(kstDetail_,750,17);
        const int pages=std::max(1,(static_cast<int>(lines.size())+12)/13);kstReportPage_=std::clamp(kstReportPage_,0,pages-1);
        for(int row=0;row<13;++row){const auto index=static_cast<std::size_t>(kstReportPage_*13+row);if(index<lines.size())label(c,lines[index],25,65.0F+row*25.0F,17,white,false,750);}
        pageControls(pages);return;
    }
    const std::string state=report.cancelled?"KST check cancelled":(!report.recognized?"KST could not be opened":(report.structurallyValid?"KST checked":"KST needs attention"));
    label(c,state,18,61,21,report.cancelled?dim:(report.structurallyValid?green:orange),true,762);
    label(c,report.name.empty()?report.rootPath:report.name,18,82,15,dim,false,762);
    const char* tabs[]={"Overview","Files","Sound links","Messages","PCM files"};
    for(int i=0;i<5;++i){const float x=12+i*156.0F;button(c,{x,92,x+149,125},tabs[i],orange,kstReportTab_==i,true,[this,i]{kstReportTab_=i;kstReportPage_=0;dirty_=true;},15);}
    if(kstReportTab_==0){
        if(kstCatalog_&&kstCatalog_->rootPath==report.rootPath){
            const auto catalog=kstCatalog_;const auto guitars=originalSetGuitarCounts(*catalog);
            const auto summary="SET Guitar: "+std::to_string(guitars.styles)+" Styles · "+std::to_string(guitars.entries)+
                " element/track entries · "+std::to_string(guitars.blocked)+" blocked · "+
                std::to_string(guitars.unreadable+guitars.unindexed)+" unread";
            label(c,summary,20,144,12,guitars.blocked||guitars.unreadable||guitars.unindexed?orange:green,false,760);
            hit({18,129,782,151},[this,catalog,guitars]{
                if(kstCatalog_!=catalog)return;
                std::string text=catalog->name+"\n"+catalog->rootPath+"\n\nOriginal Guitar: "+
                    std::to_string(guitars.styles)+" Styles / "+std::to_string(guitars.entries)+" element/track entries.";
                text+="\nBlocked or unavailable Guitar patterns: "+std::to_string(guitars.blocked);
                text+="\nUnreadable Style settings: "+std::to_string(guitars.unreadable)+
                    "; not yet read: "+std::to_string(guitars.unindexed);
                text+="\nCounts describe original declarations, before saved manual overrides. One ACC can occur in several elements.";
                text+="\nPattern readiness does not guarantee that its original Sound samples are available.";
                for(const auto& style:catalog->styles){
                    const auto source=originalStyleGuitars(style.originalSettings);
                    if(source.entries)text+="\n\n"+style.name+": "+originalGuitarParts(source.tracks)+
                        "; "+std::to_string(source.entries)+" entries, "+std::to_string(source.blocked)+" blocked.";
                    else if(!style.originalSettings.indexed||!style.originalSettings.readable)
                        text+="\n\n"+style.name+": "+(style.originalSettings.indexed?"settings unreadable":"settings not read")+
                            (style.originalSettings.error.empty()?std::string{}:" — "+style.originalSettings.error);
                }
                showStyleInfo("Original SET Guitar settings",text);
            });
        }else label(c,"Original Style settings: no matching loaded catalog",20,144,12,dim,false,760);
        for(int i=0;i<8;++i){const int row=i%4,col=i/4;const auto kind=static_cast<arranger::KstResourceKind>(i);const float x=20+col*270.0F,y=164+row*47.0F;
            label(c,arranger::kstResourceKindName(kind),x,y,16,dim,false,192);label(c,std::to_string(report.counts[static_cast<std::size_t>(i)]),x+238,y,18,white,true,70,Align::Right);
        }
        label(c,"Sounds indexed",568,164,15,dim,false,210);label(c,std::to_string(report.indexedSounds),778,189,22,white,true,210,Align::Right);
        label(c,"Samples indexed",568,221,15,dim,false,210);label(c,std::to_string(report.indexedSamples),778,247,22,white,true,210,Align::Right);
        label(c,"Exact sound links",20,366,16,dim);label(c,std::to_string(report.resolvedUserReferences),236,366,20,green,true,110,Align::Right);
        label(c,"Missing User links",289,366,16,dim);label(c,std::to_string(report.missingUserReferences),525,366,20,report.missingUserReferences?orange:white,true,100,Align::Right);
        label(c,"Factory sound links",568,326,15,dim,false,210);label(c,std::to_string(report.factoryReferences),778,353,22,report.factoryReferences?orange:white,true,210,Align::Right);
        const auto pcm=std::find_if(report.diagnostics.begin(),report.diagnostics.end(),[](const arranger::KstDiagnostic& diagnostic){return diagnostic.code=="PCM_PREPARATION_STATUS";});
        if(pcm!=report.diagnostics.end()){
            label(c,pcmFileSummary(kstPcmFiles_),400,399,13,white,true,760,Align::Center);
            label(c,pcm->message,400,419,13,dim,false,760,Align::Center);
            const auto* coverage=sampleCoverage(report);
            label(c,coverage?coverage->message:"Tap for every PCM file and its preparation status",400,440,13,
                  coverage&&coverage->severity==arranger::KstSeverity::Blocking?orange:dim,false,760,Align::Center);
            hit({18,384,782,449},[this]{kstReportTab_=4;kstReportPage_=0;dirty_=true;});
        }else label(c,"Resource index — sample preparation not reported",400,419,17,dim,false,760,Align::Center);
    }else if(kstReportTab_==4){
        const auto* coverage=sampleCoverage(report);
        label(c,coverage?coverage->message:pcmFileSummary(kstPcmFiles_),400,145,13,white,true,760,Align::Center);
        constexpr std::size_t perPage=5U;
        const auto count=kstPcmFiles_.size();
        const int pages=std::max(1,static_cast<int>((count+perPage-1U)/perPage));
        kstReportPage_=std::clamp(kstReportPage_,0,pages-1);
        for(std::size_t row=0;row<perPage;++row){
            const auto index=static_cast<std::size_t>(kstReportPage_)*perPage+row;
            if(index>=count)break;
            const auto& file=kstPcmFiles_[index];
            const auto prefix=report.rootPath+"/";
            const auto path=file.path.compare(0,prefix.size(),prefix)==0?file.path.substr(prefix.size()):file.path;
            const auto slash=path.find_last_of('/');
            const auto name=slash==std::string::npos?path:path.substr(slash+1U);
            const auto pcmState=std::string(pcmFileState(file));
            const auto color=pcmFileReady(file)?green:pcmState=="UNCHECKED"?dim:orange;
            const auto primary=std::to_string(index+1U)+". "+name+"   "+pcmState;
            const auto preparedCount=file.preparationComplete||file.attempted>0U||file.unlinked>0U?std::to_string(file.ready):std::string("unknown");
            const auto secondary="Samples ready "+preparedCount+" / "+std::to_string(file.samples)+
                " | Failed "+std::to_string(file.failed)+" | Unlinked "+std::to_string(file.unlinked);
            const auto detail=path+"\nFile "+std::to_string(index+1U)+" / "+std::to_string(count)+"\nStatus: "+pcmState+
                "\n"+secondary+"\nIndexed: "+(file.indexed?"Yes":"No")+
                "\nPreparation finished: "+(file.preparationComplete?"Yes":"No / outcome not retained")+
                "\nAttempted recordings: "+std::to_string(file.attempted)+
                "\nOpened this time: "+(file.restored?"Saved preparation":file.sourceRead?"PCM source read":file.metadataCacheHit?"PCM index cache":"Not read")+
                (file.error.empty()?"":"\nReason: "+file.error)+
                (file.indexed&&!file.preparationComplete?"\nUse MEDIA Load to obtain current per-file preparation results.":"");
            const float y=154.0F+static_cast<float>(row)*47.0F;
            const RectF rect{14,y,786,y+43};box(c,rect,panel,kBorder);
            label(c,primary,24,y+18,16,color,true,750);
            label(c,secondary,24,y+36,12,dim,false,750);
            hit(rect,[this,detail]{kstReportListPage_=kstReportPage_;kstDetailTitle_="PCM file";kstDetail_=detail;kstReportPage_=0;dirty_=true;});
        }
        if(count==0)label(c,"No PCM files found in this SET folder",400,250,19,orange,false,740,Align::Center);
        pageControls(pages);
        label(c,"Files and recordings are counted separately",400,468,14,dim,false,760,Align::Center);
        return;
    }else{
        const std::size_t count=kstReportTab_==1?report.resources.size():(kstReportTab_==2?report.soundReferences.size():report.diagnostics.size());
        const int pages=std::max(1,static_cast<int>((count+5U)/6U));kstReportPage_=std::clamp(kstReportPage_,0,pages-1);
        for(int row=0;row<6;++row){const auto index=static_cast<std::size_t>(kstReportPage_*6+row);if(index>=count)break;
            const float y=133.0F+row*43.0F;const RectF rect{14,y,786,y+39};box(c,rect,panel,kBorder);
            std::string primary,secondary,details;ColorInt color=white;
            if(kstReportTab_==1){const auto& resource=report.resources[index];primary=resource.relativePath;secondary=std::string(arranger::kstResourceKindName(resource.kind))+"  •  "+std::to_string(resource.sizeBytes)+" bytes  •  "+(resource.indexed?"Indexed":(resource.readable?"Not decoded":"Cannot read"));details=primary+"\n"+secondary;}
            else if(kstReportTab_==2){const auto& sound=report.soundReferences[index];
                const char* status="Unsupported address";switch(sound.resolution){case arranger::KstResolution::ExactUserSound:status="Exact user sound";color=green;break;case arranger::KstResolution::MissingUserSound:status="Missing user sound";color=orange;break;case arranger::KstResolution::FactorySoundRequired:status="Factory sound required";color=orange;break;case arranger::KstResolution::AmbiguousSound:status="Conflicting sounds";color=orange;break;default:break;}
                primary=sound.element+" / "+sound.track+"   "+std::to_string(sound.msb)+" / "+std::to_string(sound.lsb)+" / "+std::to_string(sound.program);
                secondary=std::string(status)+(sound.soundName.empty()?"":"  •  "+sound.soundName);
                details=std::string(arranger::kstResourceKindName(sound.resourceKind))+"\n"+sound.stylePath+"\n"+sound.element+" / "+sound.track+"\nBank MSB / LSB / Program: "+std::to_string(sound.msb)+" / "+std::to_string(sound.lsb)+" / "+std::to_string(sound.program)+"\n"+status+"\n"+sound.soundName+"\n"+sound.soundPath;
            }else{const auto& message=report.diagnostics[index];primary=message.message;secondary=message.relativePath.empty()?message.code:message.relativePath;color=message.severity==arranger::KstSeverity::Blocking?orange:(message.severity==arranger::KstSeverity::Warning?0xFFE4C56EU:dim);details=message.message+"\n"+message.relativePath+"\n"+message.code;}
            label(c,primary,24,y+17,15,color,false,750);label(c,secondary,24,y+34,12,dim,false,750);
            hit(rect,[this,details]{kstReportListPage_=kstReportPage_;kstDetailTitle_=kstReportTab_==2?"Sound link":"KST details";kstDetail_=details;kstReportPage_=0;dirty_=true;});
        }
        if(count==0)label(c,kstReportTab_==2?"No sound links were found":"No entries",400,258,20,dim,false,740,Align::Center);
        pageControls(pages);
    }
    label(c,"Current performance kept",400,468,15,green,false,760,Align::Center);
}
void ArrangerView::refresh(bool forceMetadata){
    const bool showTransport=picker_==Picker::None;
    const bool liveMain=liveView_&&showTransport&&tab_==Tab::Main&&!editor_;
    const bool editMix=picker_==Picker::KeyboardEdit&&keyboardEditPage_==KeyboardEditPage::Main;
    const bool showTrackMeters=(showTransport&&tab_==Tab::Mixer&&mixerStyle_)||(editMix&&trackEditPlayer_>=0);
    for(int p=0;p<2;++p){
        auto next=host::arrangerHost().snapshot(p);auto& current=players_[static_cast<std::size_t>(p)];
        if(liveLog_)liveLog_->observeSource(p,next,savedKstRoot_);
        auto& buffers=playerKeyboardBuffers_[static_cast<std::size_t>(p)];
        if(!buffers.owner.empty()&&(buffers.owner!=arrangerStyleSelectionKey(next)||buffers.serial!=next.styleSelectionSerial))buffers={};
        if(current.styleSelectionSerial!=next.styleSelectionSerial&&host::arrangerHost().listenSolo().player==p)
            ctrl_.engine.nativeListenSolo(-2,-1);
        if(!samePlayerDisplay(current,next,showTransport,!liveMain||p==selectedPlayer_,showTrackMeters&&p==selectedPlayer_))dirty_=true;
        current=std::move(next);
    }
    const auto& selected=players_[selectedPlayer_];
    if(activityPlayer_>=0&&(activityPlayer_!=selectedPlayer_||activitySerial_!=selected.styleSelectionSerial||
       activityRevision_!=selected.soundRevision)){activity_={};activityPlayer_=-1;}
    if(picker_==Picker::StyleDrums&&recentPartsOnly_&&selected.playing&&!pointerActive_){
        auto hits=host::arrangerHost().recentStyleHits(selectedPlayer_,selected.styleSelectionSerial);
        if(hits.drums!=recentHits_.drums)dirty_=true;
        recentHits_=std::move(hits);
    }
    if(picker_==Picker::DrumFamilyEdit&&drumStyleNotes_){
        host::RecentStyleHits hits;
        if(soundPlayer_==selectedPlayer_&&selected.playing&&!selected.styleSwitchPending&&soundSerial_==selected.styleSelectionSerial)
            hits=host::arrangerHost().recentStyleHits(soundPlayer_,soundSerial_,65);
        if(hits.drums!=styleNoteLamps_.drums)dirty_=true;
        styleNoteLamps_=std::move(hits);
    }
    const bool showUpperMeters=(showTransport&&((tab_==Tab::Main&&!liveView_)||(tab_==Tab::Mixer&&!mixerStyle_)))||
        (editMix&&trackEditPlayer_<0);
    if(showUpperMeters){
        auto meters=ctrl_.upperMeters();
        for(int part=0;part<7;++part){
            const auto level=[part](const auto& values){return static_cast<std::size_t>(part)<values.size()?
                std::max(values[static_cast<std::size_t>(part)].first,values[static_cast<std::size_t>(part)].second):0.0F;};
            const float width=tab_==Tab::Mixer?43.0F:69.0F;
            if(static_cast<int>(std::clamp(level(meters),0.0F,1.0F)*width)!=
               static_cast<int>(std::clamp(level(upperMeters_),0.0F,1.0F)*width))dirty_=true;
        }
        upperMeters_=std::move(meters);
    }
    const auto now=nowMs();
    if(forceMetadata||now-lastMetadataPoll_>=500){
        lastMetadataPoll_=now;
        // Native Korg pages show four parts; the extension can show Upper4–6.
        for(int part=0;part<7;++part){
            auto next=ctrl_.upperState(part);auto& current=uppers_[static_cast<std::size_t>(part)];
            if(!sameUpperDisplay(current,next))dirty_=true;
            current=std::move(next);
        }
        auto global=ctrl_.globalUiState();
        if(global.has_value()!=globalUi_.has_value()||(global&&globalUi_&&
            std::tie(global->transpose,global->masterGainDb)!=std::tie(globalUi_->transpose,globalUi_->masterGainDb)))dirty_=true;
        globalUi_=std::move(global);
        const auto combi=ctrl_.combiName(),scale=ctrl_.scaleName();
        if(combiName_!=combi||scaleName_!=scale)dirty_=true;
        combiName_=combi;scaleName_=scale;
        const int sampleRate=ctrl_.audioStatus().sampleRate;
        if(audioSampleRate_!=sampleRate)dirty_=true;
        audioSampleRate_=sampleRate;
        const auto cents=ctrl_.scaleCents();
        for(std::size_t i=0;i<cents_.size();++i){const float value=i<cents.size()?cents[i]:0.0F;if(cents_[i]!=value)dirty_=true;cents_[i]=value;}
        const auto bank=ctrl_.currentBankFile();
        if(!bank.empty()&&bank!=uiBank_){uiBank_=bank;uiStatePath_=files::join(files::parentOf(bank),"SILVETON_ARRANGER_UI.txt");loadUiState();selectedStyleKey_.clear();markPersistentStateChanged();dirty_=true;}
    }
    selectStyleLinks();
}
void ArrangerView::loadUiState(){
    keyboardSetLinks_.clear();nativeKeyboardSetLinks_.clear();
    std::string data;if(uiStatePath_.empty()||!files::readText(uiStatePath_,data)||data.size()>2U*1024U*1024U)return;
    std::istringstream input(data);std::string magic,tag;int version=0;
    if(!(input>>magic>>version)||magic!="SILVETON_ARRANGER_UI"||(version!=1&&version!=2))return;
    std::size_t count=0;
    while(input>>tag){
        std::string style,name,path;int index=0,slot=0;
        if(++count>8192U)break;
        if(tag=="K"){
            if(!(input>>std::quoted(style)>>index>>slot>>std::quoted(name))||index<0||index>3||slot<1||slot>500)break;
            keyboardSetLinks_[style][static_cast<std::size_t>(index)]={slot,std::move(name)};
        }else if(tag=="NK"){
            if(!(input>>std::quoted(style)>>index>>std::quoted(path)>>std::quoted(name))||index<0||index>3||path.empty())break;
            nativeKeyboardSetLinks_[style][static_cast<std::size_t>(index)]={std::move(path),std::move(name)};
        }else break;
    }
}
void ArrangerView::selectStyleLinks(){
    const auto& p=players_[static_cast<std::size_t>(selectedPlayer_)];
    const std::string style=arrangerStyleSelectionKey(p);
    if(selectedStyleKey_==style&&keyboardWorkingPlayer_==selectedPlayer_&&keyboardWorkingStyleSerial_==p.styleSelectionSerial)return;
    keyboardWorkingPlayer_=selectedPlayer_;keyboardWorkingStyleSerial_=p.styleSelectionSerial;
    selectedStyleKey_=style;selectedKeyboardSet_=-1;keyboardWorkingSets_={};
    keyboardSets_.fill(0);keyboardSetNames_.fill("");keyboardSetPaths_.fill("");
    const auto& buffers=playerKeyboardBuffers_[static_cast<std::size_t>(selectedPlayer_)];
    if(!buffers.owner.empty()&&buffers.owner==style&&buffers.serial==p.styleSelectionSerial){
        keyboardWorkingSets_=buffers.working;keyboardSets_=buffers.slots;
        keyboardSetPaths_=buffers.paths;keyboardSetNames_=buffers.names;
        // Focus alone does not recall a sound or mark a cached slot as active.
        return;
    }
    // Import only the four explicitly mapped embedded Style Keyboard Sets.
    // The Library remains independent; unavailable original Sounds stay silent.
    const auto read=host::arrangerHost().styleRead(selectedPlayer_);
    if(read&&read->keyboardSetMappingKnown)for(std::size_t i=0;i<4;++i){const auto& entry=read->keyboardSets[i];
        if(entry.available&&entry.keyboardSet){keyboardSetPaths_[i]=entry.keyboardSet->sourcePath;keyboardSetNames_[i]=entry.name.empty()?entry.keyboardSet->name:entry.name;}
    }
    const auto found=keyboardSetLinks_.find(style);
    if(found!=keyboardSetLinks_.end())for(std::size_t i=0;i<4;++i)if(found->second[i].first>0){keyboardSets_[i]=found->second[i].first;keyboardSetNames_[i]=found->second[i].second;keyboardSetPaths_[i].clear();}
    const auto native=nativeKeyboardSetLinks_.find(style);
    if(native!=nativeKeyboardSetLinks_.end())for(std::size_t i=0;i<4;++i)if(!native->second[i].first.empty()){
        keyboardSets_[i]=0;keyboardSetPaths_[i]=native->second[i].first;keyboardSetNames_[i]=native->second[i].second;
    }
    // New saved Styles own all four immutable refs atomically. Legacy saved
    // Styles can still use the earlier UI-link records until explicitly saved.
    {const auto refs=host::arrangerHost().savedStyleKeyboardSets(selectedPlayer_);
        if(std::any_of(refs.begin(),refs.end(),[](const auto& ref){return !ref.first.empty();}))
            for(std::size_t i=0;i<4;++i){keyboardSets_[i]=0;keyboardSetPaths_[i]=refs[i].first;keyboardSetNames_[i]=refs[i].second;}
    }
    for(std::size_t i=0;i<4;++i)if(!keyboardSetPaths_[i].empty()&&(keyboardSetPaths_[i]==activeNativeKeyboardSetPath_||keyboardSetPaths_[i]==activeSavedKeyboardEntryPath_))selectedKeyboardSet_=static_cast<int>(i);
}

bool ArrangerView::saveUiState(){
    // Legacy saved links are retained for migration. Current selection/edit
    // buffers are session state; only explicit Save publishes resource refs.
    markPersistentStateChanged();if(uiStatePath_.empty())return false;
    std::ostringstream data;data<<"SILVETON_ARRANGER_UI 2\n";
    for(const auto& row:keyboardSetLinks_)for(std::size_t i=0;i<4;++i)if(row.second[i].first>0)data<<"K "<<std::quoted(row.first)<<' '<<i<<' '<<row.second[i].first<<' '<<std::quoted(row.second[i].second)<<'\n';
    for(const auto& row:nativeKeyboardSetLinks_)for(std::size_t i=0;i<4;++i)if(!row.second[i].first.empty())data<<"NK "<<std::quoted(row.first)<<' '<<i<<' '<<std::quoted(row.second[i].first)<<' '<<std::quoted(row.second[i].second)<<'\n';
    const std::string temp=uiStatePath_+".pending";
    if(!files::writeText(temp,data.str())||std::rename(temp.c_str(),uiStatePath_.c_str())!=0){showToast("Cannot save Keyboard Set links",5000);return false;}
    return true;
}
void ArrangerView::changeUpper(int part,const std::function<void(SamplerAppController::UpperState&)>& change){
    auto s=ctrl_.upperState(part);if(!s)return;change(*s);
    // In Full keyboard mode Lower has no playable zone (Pa5X UM p.100).
    // Keep its remembered split-mode mute state intact while other edits apply.
    if(part==6&&!keyboardSplitEnabled_)s->mute=true;
    if(!ctrl_.updateUpperMain(part,*s))showToast(ctrl_.lastFailure());
    refresh();dirty_=true;
}
void ArrangerView::controlRequested(bool accepted){
    if(!accepted){
        const auto error=host::arrangerHost().lastError();
        showToast(error.empty()?"Arranger control request was not accepted":error,5000);
    }
    // A successful queue write is not an applied setting. Selection and status
    // stay tied to the engine snapshot, published by the audio/control block.
    // A tempo detent only needs transport state, not all keyboard/Sound
    // metadata. Poll committed state promptly after the audio block applies it.
    controlFeedbackUntil_=nowMs()+150;
    refresh(false);dirty_=true;
}
void ArrangerView::applySplit(int keyNumber){
    const int keyValue=std::clamp(keyNumber,1,127);
    const auto current=ctrl_.engine.nativeKeyboardCombi();
    if(!current){
        if(!host::arrangerHost().setKeyboardSplit(keyValue,keyboardSplitEnabled_)){showToast(host::arrangerHost().lastError(),6000);return;}
        if(keyboardUseGlobalSplit_)(void)host::arrangerHost().setGlobalSplit(keyValue,false);
        controlFeedbackUntil_=nowMs()+150;markPersistentStateChanged();refresh();dirty_=true;return;
    }
    auto next=*current;auto suppressed=keyboardSplitSuppressed_;
    for(int part=0;part<7;++part){
        const auto index=static_cast<std::size_t>(part);auto& upper=next.part(part);
        upper.keyLow=static_cast<std::uint8_t>(keyboardRangeLow_[index]);upper.keyHigh=static_cast<std::uint8_t>(keyboardRangeHigh_[index]);
        upper.performanceKeyLow=static_cast<std::uint8_t>(keyboardSplitEnabled_&&part!=6?keyValue+1:0);
        upper.performanceKeyHigh=static_cast<std::uint8_t>(keyboardSplitEnabled_&&part==6?keyValue:127);
        if(suppressed[index])upper.enabled=true;
        suppressed[index]=false;
    }
    if(!keyboardSplitEnabled_)next.part(6).mute=true;
    if(!ctrl_.engine.nativeApplyKeyboardCombi(next,true)){showToast(ctrl_.engine.nativeLastTextError(),6000);return;}
    if(!host::arrangerHost().setKeyboardSplit(keyValue,keyboardSplitEnabled_)){
        (void)ctrl_.engine.nativeApplyKeyboardCombi(*current,true);
        showToast(host::arrangerHost().lastError(),6000);return;
    }
    if(keyboardUseGlobalSplit_)(void)host::arrangerHost().setGlobalSplit(keyValue,false);
    keyboardSplitSuppressed_=suppressed;controlFeedbackUntil_=nowMs()+150;markPersistentStateChanged();refresh();dirty_=true;
}
void ArrangerView::normalizeKeyboardPartRange(int part){
    if(part<0||part>=7)return;
    const auto current=ctrl_.engine.nativeKeyboardCombi();if(!current)return;
    auto adjusted=*current;auto& upper=adjusted.part(part);const auto index=static_cast<std::size_t>(part);
    const int split=std::clamp(host::arrangerHost().snapshot(selectedPlayer_).split,1,127);
    upper.keyLow=static_cast<std::uint8_t>(keyboardRangeLow_[index]);upper.keyHigh=static_cast<std::uint8_t>(keyboardRangeHigh_[index]);
    upper.performanceKeyLow=static_cast<std::uint8_t>(keyboardSplitEnabled_&&part!=6?split+1:0);
    upper.performanceKeyHigh=static_cast<std::uint8_t>(keyboardSplitEnabled_&&part==6?split:127);
    if(keyboardSplitSuppressed_[index])upper.enabled=true;
    keyboardSplitSuppressed_[index]=false;
    if(part==6&&!keyboardSplitEnabled_)upper.mute=true;
    if(!ctrl_.engine.nativeApplyKeyboardCombi(adjusted,true))showToast(ctrl_.engine.nativeLastTextError(),5000);
}
void ArrangerView::label(Canvas& c,const std::string& value,float x,float y,float size,ColorInt color,bool bold,float width,Align align){
    Paint p;p.color=color;p.textSize=size;p.typeface=bold?Face::Bold:Face::Regular;p.textAlign=align;
    std::string text=value;
    if(p.measureText(text)>width){text.resize(p.textPrefixLength(text,width-p.measureText("…")));text+="…";}
    c.drawText(text,x,y,p);
}
void ArrangerView::box(Canvas& c,const RectF& r,ColorInt fill,ColorInt edge,float radius){
    Paint p;p.color=fill;
    if(radius>0)c.drawRoundRect(r,radius,radius,p);else c.drawRect(r,p);
    if(edge){p.color=edge;p.style=Style::Stroke;p.strokeWidth=1.0F;if(radius>0)c.drawRoundRect(r,radius,radius,p);else c.drawRect(r,p);}
}
void ArrangerView::hit(const RectF& r,std::function<void()> action,std::function<void(float,float)> drag,
                       bool triggerOnDown,std::function<void(float,float)> finishDrag){
    if(screenDrawing_){screenHit(r,std::move(action),std::move(drag),triggerOnDown,std::move(finishDrag));return;}
    hits_.push_back({r,std::move(action),std::move(drag),triggerOnDown,std::move(finishDrag),{},{}});
}
void ArrangerView::screenHit(const RectF& r,std::function<void()> action,std::function<void(float,float)> drag,
                             bool triggerOnDown,std::function<void(float,float)> finishDrag){
    const float left=displayLeft_,top=displayTop_,zoom=displayZoom_;
    const auto map=[left,top,zoom](std::function<void(float,float)> fn)->std::function<void(float,float)>{
        if(!fn)return {};
        return [fn=std::move(fn),left,top,zoom](float x,float y){fn((x-left)/zoom,(y-top)/zoom);};
    };
    // Do not leave tappable controls outside the clipped, visible page.
    const RectF visible{std::max(0.0F,r.left),std::max(0.0F,r.top),
                        std::min(displayWidth_,r.right),std::min(displayHeight_,r.bottom)};
    if(visible.isEmpty())return;
    hits_.push_back({RectF(left+visible.left*zoom,top+visible.top*zoom,left+visible.right*zoom,top+visible.bottom*zoom),
                     std::move(action),map(std::move(drag)),triggerOnDown,map(std::move(finishDrag)),{},{}});
}
void ArrangerView::button(Canvas& c,const RectF& r,const std::string& text,ColorInt accent,bool on,bool enabled,std::function<void()> action,float size,bool triggerOnDown){
    const ColorInt fill=on?(enabled?accent:0xFF30363AU):key;
    box(c,r,fill,on&&enabled?accent:kBorder,2.0F);
    // Use the button area instead of globally forcing tiny fixed type. Never
    // enlarge past the available label width/height or shrink approved sizes.
    if(liveView_&&screenDrawing_){
        Paint metrics;metrics.typeface=Face::Bold;metrics.textSize=size;
        const float advance=metrics.measureText(text)/std::max(size,1.0F);
        if(advance>0){
            const float preferred=std::max(size,18.0F);
            const float fit=std::min({preferred,r.height()*0.58F,(r.width()-10.0F)/advance});
            size=std::max(size,fit);
        }
    }
    label(c,text,r.centerX(),r.centerY()+size*0.34F,size,enabled?(on?bg:white):0xFF5E696EU,true,r.width()-8,Align::Center);
    if(enabled&&action)hit(r,std::move(action),{},triggerOnDown);
}
void ArrangerView::keyboard(Canvas& c,float x,float y,float w,float h,ColorInt color){
    const float ww=w/7.0F;for(int i=0;i<7;++i)box(c,{x+i*ww,y,x+(i+1)*ww-1,y+h},color);
    for(int i:{0,1,3,4,5})box(c,{x+(i+0.68F)*ww,y,x+(i+1.3F)*ww,y+h*0.62F},bg);
}

void ArrangerView::drawDisplayAt(Canvas& c,float left,float top,float zoom,float contentHeight,float contentWidth){
    displayLeft_=left;displayTop_=top;displayZoom_=zoom;displayHeight_=contentHeight;displayWidth_=contentWidth;
    c.save();c.translate(left,top);c.scale(zoom,zoom);
    c.clipRect({0,0,contentWidth,contentHeight});
    screenDrawing_=true;drawDisplay(c);screenDrawing_=false;c.restore();
}
void ArrangerView::drawTabletPage(Canvas& c,const RectF& area,float contentHeight){
    // Fit the actual usable window, not the old picture of the hardware panel.
    // Preserve square geometry (no stretched fonts, dials or EQ graphs).
    const float zoom=std::min(area.width()/800.0F,area.height()/contentHeight);
    if(zoom<=0)return;
    const bool library=fullLibrarySelector();
    const float contentWidth=library?area.width()/zoom:800.0F;
    drawDisplayAt(c,area.centerX()-0.5F*contentWidth*zoom,
                  area.centerY()-0.5F*contentHeight*zoom,zoom,contentHeight,contentWidth);
}
std::pair<float,float> ArrangerView::detailPoint(float x,float y) const noexcept {
    return {xOffset_+scale_*(displayLeft_+x*displayZoom_),
            yOffset_+scale_*(displayTop_+y*displayZoom_)};
}

void ArrangerView::draw(Canvas& c){
    if(scaleNameEditing_&&editor_&&!SilvetonSamplerView::dialogOpen()){
        scaleNameEditing_=false;editor_=false;picker_=Picker::None;tab_=Tab::Scale;dirty_=true;
    }
    if(resourceSaveNameEditing_&&editor_&&!SilvetonSamplerView::dialogOpen()){
        resourceSaveNameEditing_=false;editor_=false;picker_=Picker::ResourceSave;dirty_=true;
    }

    hits_.clear();screenDrawing_=false;
    if(c.width()<=0||c.height()<=0)return;
    scale_=std::min(static_cast<float>(c.width())/kPanelWidth,static_cast<float>(c.height())/kPanelHeight);
    xOffset_=(static_cast<float>(c.width())-kPanelWidth*scale_)*0.5F;
    yOffset_=(static_cast<float>(c.height())-kPanelHeight*scale_)*0.5F;
    panelViewport_={-xOffset_/scale_,-yOffset_/scale_,
        (static_cast<float>(c.width())-xOffset_)/scale_,
        (static_cast<float>(c.height())-yOffset_)/scale_};
    if(editor_){
        SilvetonSamplerView::draw(c);c.save();c.translate(xOffset_,yOffset_);c.scale(scale_,scale_);
        button(c,{5,5,165,42},"‹ Back",orange,false,true,[this]{panelExit();},14);c.restore();
    }else{
        c.clear(0xFF16191CU);c.save();c.translate(xOffset_,yOffset_);c.scale(scale_,scale_);
        if(soundWindowVisible())drawHomeTone(c,!kstJob_&&!persistentRestoreActive_);
        else if(liveView_)drawLiveView(c);
        else{
            drawPanel(c);box(c,{sx-5,sy-5,sx+1005,sy+605},0xFF030303U,0xFF41484BU,4);
            drawDisplayAt(c,sx,sy,ss);
        }
        if(!homeSoundEdit_&&!liveView_&&!toast_.empty()){
            box(c,{18,568,302,626},0xFF28323AU,orange,4);
            const auto lines=wrappedKstText(toast_,260,12);
            for(std::size_t line=0;line<std::min<std::size_t>(2,lines.size());++line)
                label(c,lines[line],29,589+static_cast<float>(line)*17,12,white,false,260);
            const auto message=toast_;hit({18,568,302,626},[this,message]{showStyleInfo("Message",message);});
        }
        c.restore();
    }
    lastDraw_=nowMs();dirty_=false;
}
bool ArrangerView::ResetTarget::matches(const ResetTarget& other) const {
    return parameter&&other.parameter&&surface==other.surface&&player==other.player&&part==other.part&&
           std::strcmp(parameter,other.parameter)==0&&selection==other.selection&&soundRevision==other.soundRevision&&
           !keyboard.owner_before(other.keyboard)&&!other.keyboard.owner_before(keyboard);
}
bool ArrangerView::isResetDrag(float x,float y) const {
    const bool dial=held_.resetTarget.surface==ResetSurface::HomeTone||held_.resetTarget.surface==ResetSurface::TrackTone;
    const bool volume=held_.resetTarget.surface==ResetSurface::Volume;
    const float threshold=dial||volume?std::max(2.0F,3.0F/scale_):std::clamp(8.0F/scale_,5.0F,14.0F);
    return std::hypot(x-resetDownX_,y-resetDownY_)>threshold;
}
void ArrangerView::finishResetTap(const Hit& hit){
    const auto duration=pointerEventTimeMs_-resetDownTime_;
    if(duration<0||duration>280){lastResetTapUp_=0;return;}
    const auto gap=resetDownTime_-lastResetTapUp_;
    const float separation=std::clamp(30.0F/scale_,20.0F,44.0F);
    if(lastResetTapUp_>0&&gap>=0&&gap<=320&&lastResetTarget_.matches(hit.resetTarget)&&
       std::hypot(resetDownX_-lastResetX_,resetDownY_-lastResetY_)<=separation){
        lastResetTapUp_=0;hit.reset();return;
    }
    lastResetTarget_=hit.resetTarget;lastResetX_=resetDownX_;lastResetY_=resetDownY_;
    lastResetTapUp_=pointerEventTimeMs_;
}
void ArrangerView::pointer(PointerAction action,float rawX,float rawY,std::int64_t eventTimeMs){
    if(previewDrumNote_>=0&&(action==PointerAction::Up||action==PointerAction::Cancel||action==PointerAction::Down)){
        host::arrangerHost().releasePreviewNote(previewDrumNote_);previewDrumNote_=-1;dirty_=true;
    }
    pointerEventTimeMs_=eventTimeMs>0?eventTimeMs:nowMs();
    const float x=(rawX-xOffset_)/scale_,y=(rawY-yOffset_)/scale_;
    if(action==PointerAction::Down){toneGestureOwner_.reset();toneDialPreview_=-1;cancelKeyboardSetHold();pointerActive_=true;}
    else if(action==PointerAction::Up||action==PointerAction::Cancel){cancelKeyboardSetHold();pointerActive_=false;}
    if(editor_){
        if(x>=5&&x<165&&y>=5&&y<42){if(action==PointerAction::Up)panelExit();return;}
        SilvetonSamplerView::pointer(action,rawX,rawY);markPersistentStateChanged();return;
    }
    if(action==PointerAction::Down){
        resetTempoWheelGesture();held_={};dragging_=false;
        for(auto i=hits_.rbegin();i!=hits_.rend();++i)if(i->rect.contains(x,y)){held_=*i;break;}
        resetDownX_=x;resetDownY_=y;resetDownTime_=pointerEventTimeMs_;resetDragged_=false;
        if(!held_.reset||!lastResetTarget_.matches(held_.resetTarget))lastResetTapUp_=0;
        if(held_.triggerOnDown&&held_.tap){
            auto activate=std::move(held_.tap);held_.tap={};
            activate();markPersistentStateChanged(false);dirty_=true;
        }
        if(held_.drag){held_.drag(x,y);dragging_=true;markPersistentStateChanged(false);dirty_=true;}
    }
    else if(action==PointerAction::Move){
        if(keyboardHoldDeadline_>0&&!keyboardHoldRect_.contains(x,y))cancelKeyboardSetHold();
        if(held_.reset){
            resetDragged_=resetDragged_||isResetDrag(x,y);
            if(!resetDragged_)return;
            lastResetTapUp_=0;
        }
        if(held_.drag){held_.drag(x,y);dragging_=true;markPersistentStateChanged(false);dirty_=true;}
    }else if(action==PointerAction::Up){
        auto h=std::move(held_);held_={};
        if(h.reset&&!resetDragged_&&!isResetDrag(x,y)&&h.rect.contains(x,y))finishResetTap(h);
        else{
            lastResetTapUp_=0;
            if(dragging_&&h.finishDrag)h.finishDrag(x,y);
            else if(!dragging_&&h.tap&&h.rect.contains(x,y))h.tap();
        }
        toneGestureOwner_.reset();toneDialPreview_=-1;resetTempoWheelGesture();markPersistentStateChanged();dirty_=true;
    }else{held_={};lastResetTapUp_=0;toneGestureOwner_.reset();toneDialPreview_=-1;dragging_=false;resetTempoWheelGesture();dirty_=true;}
}

void ArrangerView::drawDisplay(Canvas& c){
    box(c,{0,0,displayWidth_,displayHeight_},bg);
    if(picker_!=Picker::None){drawPicker(c);return;}
    drawHeader(c);drawPlayers(c);
    if(tab_==Tab::Mixer)drawMixer(c);
    else if(tab_==Tab::Control)drawControl(c);
    else if(tab_==Tab::Scale)drawScale(c);
    else if(tab_==Tab::Chords)drawChords(c);
    else if(tab_==Tab::MicGuitar)drawMicGuitar(c);
    else if(tab_==Tab::Jukebox)drawJukebox(c);
    else if(tab_==Tab::Matrix)drawMatrix(c);
    else if(tab_==Tab::Kaoss)drawKaoss(c);
    else {drawKeys(c,tab_==Tab::Keys);}
    if(!liveView_||panelMode_!=PanelMode::Home)drawTabs(c);
}
void ArrangerView::drawHeader(Canvas& c){
    box(c,{7,3,143,31},bg,orange);label(c,"HOME",75,23,15,orange,true,120,Align::Center);hit({7,3,143,34},[this]{if(panelMode_==PanelMode::Home)switchHomeTab(Tab::Main);else panelExit();});
    const auto& g=globalUi_;label(c,"b/#: "+signedNumber(g?g->transpose:0),440,24,18,dim);
    keyboard(c,514,11,30,15,dim);label(c,signedNumber(uppers_[0]?uppers_[0]->octave:0),553,24,16,dim);
    hit({505,0,576,36},[this]{trackEditPlayer_=-1;openKeyboardEdit(KeyboardEditPage::Tune);});
    const auto& p=players_[static_cast<std::size_t>(selectedPlayer_)];
    label(c,p.chordName.empty()?"N.C.":p.chordName,598,28,24,white,false,142);
    for(int i=0;i<3;++i)box(c,{762.0F,10.0F+i*6.0F,786.0F,13.0F+i*6.0F},dim);
    hit({749,0,799,38},[this]{rememberNavigation();picker_=Picker::WriteMenu;editor_=false;dirty_=true;});
}
void ArrangerView::drawPlayers(Canvas& c){
    for(int n=0;n<2;++n){
        const float x=n==0?9.0F:404.0F;const auto& p=players_[static_cast<std::size_t>(n)];
        const ColorInt ac=n==0?orange:blue;const ColorInt col=n==selectedPlayer_?ac:dim;
        box(c,{x,44,x+388,157},bg,n==selectedPlayer_?ac:kBorder);
        box(c,{x,44,x+82,75},n==selectedPlayer_?ac:key);
        label(c,"Player "+std::to_string(n+1),x+7,66,17,n==selectedPlayer_?bg:dim);
        hit({x,44,x+82,75},[this,n]{setPlayerFocus(n);});
        label(c,p.loaded?(p.nativeKorgStyle?"Korg Style":"User Style"):"Style",x+86,61,12,col);
        label(c,p.loaded?p.name:"Select a Style",x+86,88,22,col,true,290);
        box(c,{x+292,44,x+388,68},bg,col);
        label(c,p.loaded?p.elementName:"—",x+340,61,13,col,false,86,Align::Center);
        label(c,std::to_string(p.numerator)+"/"+std::to_string(p.denominator),x+346,91,13,col);
        hit({x+83,69,x+388,111},[this,n]{openStyleSelectorForPlayer(n);});
        keyboard(c,x+8,86,63,55,p.loaded?col:0xFF30383CU);
        if(p.loaded)hit({x+4,79,x+78,153},[this,n]{openStyleRead(n);});
        box(c,{x+82,114,x+388,156},bg,col);
        label(c,"bpm",x+91,129,14,col);
        const auto tempo=tempoText(p.bpm);
        label(c,tempo,x+86,152,tempo.size()>4U?19.0F:26.0F,col,true,65);
        label(c,std::to_string(p.bar),x+147,147,14,col);
        const int beats=std::clamp(p.numerator,1,8);for(int b=0;b<beats;++b){float l=x+138+b*(242.0F/beats);box(c,{l,120,l+232.0F/beats,126},p.playing&&b==p.beat-1?col:0xFF333A3DU);}
        label(c,p.pendingElementName.empty()?(p.playing?(p.element>=3&&p.element<=6?"Loop":"Playing"):"Stopped"):p.pendingElementName,x+382,148,13,col,false,175,Align::Right);
        hit({x+82,114,x+388,157},[this,n]{setPlayerFocus(n);});
    }
}
void ArrangerView::drawPads(Canvas& c){
    for(int i=0;i<4;++i){const float x=10.0F+i*183.0F;box(c,{x,188,x+36,218},0xFF0A0E11U,0xFF20282DU);label(c,"↻",x+18,212,25,0xFF465057U,false,30,Align::Center);label(c,"Pad "+std::to_string(i+1),x+85,194,14,dim);label(c,"Unassigned",x+85,217,14,0xFF59676CU,false,100,Align::Center);}
    box(c,{11,233,789,235},green);
}
void ArrangerView::drawKeys(Canvas& c,bool detailed){
    if(detailed){
        for(int i=0;i<4;++i){const int part=partOrder[static_cast<std::size_t>(i)];const auto& u=uppers_[static_cast<std::size_t>(part)];const float x=22.0F+i*190.0F;const bool on=u&&u->enabled&&!u->mute;const ColorInt ac=on?green:dim;
            box(c,{x,247,x+182,328},bg,ac);keyboard(c,x+6,267,62,49,on?0xFF427C69U:0xFF343E42U);
            box(c,{x+79,248,x+182,274},on?green:0xFF5C6467U);label(c,partNames[static_cast<std::size_t>(i)],x+130,266,15,on?bg:white,true,99,Align::Center);
            label(c,u&&!u->soundName.empty()?u->soundName:"Select Sound",x+131,299,14,ac,false,97,Align::Center);
            hit({x,275,x+182,328},[this,part]{targetPart_=part;targetTrack_=-1;openPicker(Picker::Sound);});
            if(part!=6||keyboardSplitEnabled_)hit({x+79,247,x+182,274},[this,part]{togglePartMute(-1,part);});
        }
        label(c,"Keyboard Set Library",25,363,16,green);label(c,combiName_.empty()?"My Setting":combiName_,214,363,23,green,true,450);
        hit({13,338,696,377},[this]{openKeyboardSetSelector();});keyboard(c,726,341,61,28,green);
    }else{
        box(c,{13,243,138,367},bg,green);keyboard(c,28,271,94,75,0xFF287A63U);
        label(c,"KEYS",166,262,17,green,true);label(c,"Keyboard Set Library",166,290,16,green);
        label(c,combiName_.empty()?"My Setting":combiName_,166,330,30,green,true,495);
        hit({13,242,658,376},[this]{openKeyboardSetSelector();});
        static const char* names[]={"UP1","UP2","UP3","LWR"};static const int parts[]={0,1,2,6};
        for(int i=0;i<4;++i){const int part=parts[i];const auto& u=uppers_[static_cast<std::size_t>(part)];const bool on=u&&u->enabled&&!u->mute;label(c,names[i],676,252.0F+i*16.0F,13,on?green:dim,true);
            float level=0;if(static_cast<std::size_t>(part)<upperMeters_.size())level=std::max(upperMeters_[static_cast<std::size_t>(part)].first,upperMeters_[static_cast<std::size_t>(part)].second);
            box(c,{710,247.0F+i*16.0F,779,250.0F+i*16.0F},on?0xFF1F5444U:kBorder);box(c,{710,247.0F+i*16.0F,710+69*std::clamp(level,0.0F,1.0F),250.0F+i*16.0F},green);
            if(part!=6||keyboardSplitEnabled_)hit({671,238.0F+i*16.0F,788,254.0F+i*16.0F},[this,part]{togglePartMute(-1,part);});
        }
        label(c,arrangerNoteName(players_[static_cast<std::size_t>(selectedPlayer_)].split),677,351,14,dim);keyboard(c,710,322,73,44,green);
        hit({664,314,790,368},[this]{globalSplitEditing_=false;openPicker(Picker::Split);});
    }
    box(c,{11,376,789,378},green);
    for(int i=0;i<4;++i){const float x=16.0F+i*188.0F;keyboard(c,x+4,395,26,18,green);
        label(c,std::to_string(i+1),x+31,410,16,green,true);
        label(c,keyboardSetNames_[static_cast<std::size_t>(i)].empty()?"Assign Keyboard Set":keyboardSetNames_[static_cast<std::size_t>(i)],x+47,409,13,green,false,136);
        if(selectedKeyboardSet_==i)box(c,{x,419,x+184,422},green);
        hit({x,382,x+184,422},[this,i]{if(keyboardSets_[static_cast<std::size_t>(i)]>0||!keyboardSetPaths_[static_cast<std::size_t>(i)].empty()){pendingKeyboardSet_=-1;recallKeyboardSet(i);}else openKeyboardSetSelector(i);});
    }
}
bool ArrangerView::partSolo(int player,int part) const {
    const auto active=host::arrangerHost().listenSolo();
    if(active.player!=-2)return active.player==player&&active.part==part;
    return player<0&&part>=0&&part<7&&uppers_[part]&&uppers_[part]->solo;
}
void ArrangerView::togglePartMute(int player,int part,std::uint64_t selection){
    bool muted=false;
    if(player<0){
        if(part<0||part>=7||(part==6&&!keyboardSplitEnabled_))return;
        const auto current=ctrl_.engine.nativeKeyboardCombi();if(!current)return;
        auto next=*current;auto& target=next.part(part);
        const auto solo=host::arrangerHost().listenSolo();
        muted=(solo.player==-1&&solo.part==part)||(target.enabled&&!target.mute);
        target.enabled=true;target.mute=muted;
        if(!ctrl_.engine.nativeApplyKeyboardCombi(next,true)){showToast(ctrl_.engine.nativeLastTextError(),4000);return;}
        keyboardSplitSuppressed_[part]=false;
        uppers_[part]=ctrl_.upperState(part);
    }else if(!host::arrangerHost().toggleTrackMute(player,part,selection,muted)){
        showToast(host::arrangerHost().lastError(),4000);return;
    }
    const auto listening=host::arrangerHost().listenSolo();
    if(muted&&listening.player==player&&listening.part==part)ctrl_.engine.nativeListenSolo(-2,-1);
    refresh(false);markPersistentStateChanged(false);dirty_=true;
}
void ArrangerView::listenPart(int player,int part,int note){
    const auto active=host::arrangerHost().listenSolo();
    if(player<0&&active.player==-2&&partSolo(player,part)){
        changeUpper(part,[](auto& u){u.solo=false;});return;
    }
    if(active.matches(player,part,note)||(note<0&&active.player==player&&active.part==part))ctrl_.engine.nativeListenSolo(-2,-1);
    else{
        if(player<0){
            const auto keys=ctrl_.engine.nativeKeyboardCombi();
            if(!keys||part<0||part>=7||(part==6&&!keyboardSplitEnabled_)||!keys->part(part).hasAnySound()){
                showToast("Select a playable keyboard part",2500);return;
            }
        }else{
            const auto style=host::arrangerHost().snapshot(player);
            if(!style.loaded||style.styleSwitchPending||part<0||part>=8||!style.tracks[part].assigned){
                showToast("Select an assigned Style track",2500);return;
            }
        }
        ctrl_.engine.nativeListenSolo(player,part,note);
    }
    dirty_=true;
}
void ArrangerView::solo(int track){listenPart(selectedPlayer_,track);}
void ArrangerView::drawMixer(Canvas& c){
    const auto& p=players_[static_cast<std::size_t>(selectedPlayer_)];const auto ac=selectedPlayer_==0?orange:blue;
    box(c,{9,163,791,165},ac);
    button(c,{722,170,789,202},"Keys",ac,!mixerStyle_,true,[this]{mixerStyle_=false;dirty_=true;},14);
    button(c,{722,246,789,288},"FX",ac,false,!mixerStyle_||p.loaded,[this]{trackEditPlayer_=mixerStyle_?selectedPlayer_:-1;openKeyboardEdit(KeyboardEditPage::Effects);},16);
    button(c,{722,387,789,421},"Style",ac,mixerStyle_,true,[this]{mixerStyle_=true;dirty_=true;},14);
    static const char* keyboardLabels[]={"Lower","Upper 3","Upper 2","Upper 1"};
    for(int i=0;i<(mixerStyle_?8:4);++i){const int trackIndex=i;
        const float x=11.0F+i*88.0F;const auto& track=p.tracks[static_cast<std::size_t>(trackIndex)];
        const int part=i<4?partOrder[static_cast<std::size_t>(i)]:-1;const auto u=part>=0?uppers_[static_cast<std::size_t>(part)]:std::optional<SamplerAppController::UpperState>{};
        const bool enabled=mixerStyle_?p.loaded&&!p.styleSwitchPending:i<4;const bool assigned=mixerStyle_?track.assigned:(u&&!u->soundName.empty());const bool mute=mixerStyle_?track.mute:(u&&u->mute);
        const float db=mixerStyle_?track.volumeDb:(u?u->levelDb:-60.0F);const float pan=mixerStyle_?track.pan:(u?u->pan:0.0F);
        const bool original=mixerStyle_&&p.nativeKorgStyle;
        const std::string sound=mixerStyle_?(assigned?track.soundName:""):(u?u->soundName:"");
        keyboard(c,x+24,171,34,21,assigned?white:kBorder);
        box(c,{x,197,x+82,235},panel,kBorder);
        label(c,sound.empty()?(enabled?"Select Sound":"—"):sound,x+41,original?212.0F:220.0F,original?12.0F:13.0F,enabled?white:dim,false,76,Align::Center);
        if(original)label(c,"Vol "+rawValue(track.sourceVolumeRaw)+"  E "+rawValue(track.sourceExpressionRaw),x+41,230,10,dim,false,76,Align::Center);
        if(enabled)hit({x,original?197.0F:169.0F,x+82,235},[this,part,trackIndex]{openTargetSound(part,mixerStyle_?trackIndex:-1);});
        if(original)hit({x,169,x+82,196},[this]{openStyleRead(selectedPlayer_);});
        const std::string panText=pan==0?"C":std::string(pan<0?"L":"R")+std::to_string(static_cast<int>(std::abs(pan)*64));
        box(c,{x,239,x+82,265},panel,kBorder);
        label(c,original?"P"+rawValue(track.sourcePanRaw)+" / Trim "+panText:
            (pan==0?"C 00":std::string(pan<0?"L ":"R ")+std::to_string(static_cast<int>(std::abs(pan)*64))),
            x+41,282,original?10.0F:13.0F,dim,false,80,Align::Center);
        const float px=x+41+pan*32;box(c,{x+6,250,x+76,252},dim);box(c,{px-3,241,px+3,263},white);
        if(original&&track.sourcePanRaw>=0&&track.sourcePanRaw<=127){
            const float sourcePan=track.sourcePanRaw<=1?-1.0F:static_cast<float>(track.sourcePanRaw-64)/63.0F;
            const float sourceX=x+41+sourcePan*32;
            box(c,{sourceX-2,264,sourceX+2,268},ac);
        }
        if(enabled)hit({x,237,x+82,284},{},[this,part,x,trackIndex](float xx,float){const float v=std::clamp((xx-(x+41))/34,-1.0F,1.0F);if(mixerStyle_)host::arrangerHost().setTrackPan(selectedPlayer_,trackIndex,v);else changeUpper(part,[v](auto& s){s.pan=v;});});
        const bool muteEnabled=enabled&&(mixerStyle_||part!=6||keyboardSplitEnabled_);
        button(c,{x,287,x+40,315},"M",ac,mute,muteEnabled,[this,part,trackIndex,player=selectedPlayer_,style=mixerStyle_,serial=p.styleSelectionSerial]{
            togglePartMute(style?player:-1,style?trackIndex:part,serial);
        },14,true);
        button(c,{x+42,287,x+82,315},"S",ac,partSolo(mixerStyle_?selectedPlayer_:-1,mixerStyle_?trackIndex:part),enabled&&(!mixerStyle_||assigned||partSolo(selectedPlayer_,trackIndex)),[this,part,trackIndex]{listenPart(mixerStyle_?selectedPlayer_:-1,mixerStyle_?trackIndex:part);},14,true);
        box(c,{x+26,330,x+28,400},kBorder);for(int y=333;y<400;y+=7)box(c,{x+14,static_cast<float>(y),x+25,static_cast<float>(y+1)},dim);
        if(original){
            label(c,"Trim",x+27,327,10,dim,false,38,Align::Center);
            label(c,"V",x+51,327,9,ac,true,10,Align::Center);
            // The colored source axis is MIDI CC7 0..127. The white fader
            // remains a dB trim; source CC7 is already applied by the sampler.
            box(c,{x+49,333,x+53,376},key);
            if(track.sourceVolumeRaw>=0&&track.sourceVolumeRaw<=127){
                const float sourceY=376-static_cast<float>(track.sourceVolumeRaw)*43.0F/127.0F;
                if(track.sourceVolumeRaw>0)box(c,{x+49,sourceY,x+53,376},ac);
                box(c,{x+48,sourceY-1,x+54,sourceY+1},ac);
            }
        }
        const float ceiling=mixerStyle_?12.0F:18.0F;
        const float fy=400-(std::clamp(db,-60.0F,ceiling)+60)*70.0F/(ceiling+60.0F);
        box(c,{x+6,fy-8,x+46,fy+8},enabled?dim:kBorder,white,3);
        if(enabled)hit({x,318,x+47,409},{},[this,part,trackIndex,ceiling,style=mixerStyle_,player=selectedPlayer_,serial=p.styleSelectionSerial,
                    zoom=displayZoom_,gesture=RelativeVolumeGesture{},last=db,owner=std::shared_ptr<const sampler::Combi>{}](float,float yy) mutable {
            if(style!=mixerStyle_||player!=selectedPlayer_)return;
            const auto current=style?nullptr:ctrl_.engine.nativeKeyboardCombi();
            if(style){const auto now=host::arrangerHost().snapshot(player);if(now.styleSelectionSerial!=serial||now.styleSwitchPending)return;}
            else if(!current||(gesture.grabbed&&current!=owner))return;
            if(!gesture.grabbed){last=style?host::arrangerHost().snapshot(player).tracks[trackIndex].volumeDb:current->part(part).levelDb;owner=current;}
            const float v=gesture.update(yy,last,-60.0F,ceiling,zoom);
            if(std::abs(v-last)<0.01F)return;
            if(style){if(!host::arrangerHost().setTrackVolume(player,trackIndex,v,serial))return;last=v;}
            else{if(!setKeyboardFader(part,v))return;owner=ctrl_.engine.nativeKeyboardCombi();if(!owner)return;last=owner->part(part).levelDb;if(std::abs(v-last)>0.01F)gesture.rebase(last);}
            dirty_=true;
        });
        const float peak=mixerStyle_?track.peak:(part>=0&&static_cast<std::size_t>(part)<upperMeters_.size()?std::max(upperMeters_[static_cast<std::size_t>(part)].first,upperMeters_[static_cast<std::size_t>(part)].second):0);
        box(c,{x+61,333,x+69,376},0xFF102718U);if(enabled&&peak>0)box(c,{x+61,376-43*std::clamp(peak,0.0F,1.0F),x+69,376},0xFF58E34DU);
        label(c,db<=-60?"−∞":fmtFixed(db,0),x+64,397,17,enabled?white:dim,false,31,Align::Center);
        label(c,mixerStyle_?track.name:keyboardLabels[i],x+41,420,12,enabled?white:dim,false,83,Align::Center);
    }
    box(c,{9,425,791,427},ac);
}
void ArrangerView::drawControl(Canvas& c){
    box(c,{10,165,790,167},orange);
    button(c,{16,172,203,211},std::string("Style to KbdSet: ")+(styleToKeyboardSet_==0?"Off":"On"),green,styleToKeyboardSet_!=0,true,[this]{styleToKeyboardSet_=styleToKeyboardSet_==0?1:0;keyboardRecallStyle_.clear();if(styleToKeyboardSet_==0)clearStyleKeyboardCue(false);else styleKeyboardSelectionAccepted(selectedPlayer_);markPersistentStateChanged();dirty_=true;},14);
    const auto p=players_[static_cast<std::size_t>(selectedPlayer_)];
    button(c,{211,172,349,211},"Tempo Lock",orange,p.tempoLock,true,[this]{controlRequested(host::arrangerHost().toggleTempoLock(selectedPlayer_));},15);
    button(c,{357,172,480,211},"Bass Inv.",orange,p.bassInversion,true,[this]{controlRequested(host::arrangerHost().toggleBassInversion());},15);
    button(c,{488,172,631,211},"Drum&Bass",orange,p.drumBassOnly,true,[this]{controlRequested(host::arrangerHost().toggleDrumBass(selectedPlayer_));},14);
    button(c,{639,172,784,211},"Manual Bass",green,p.manualBass,p.manualBass||p.manualBassReady,[this]{controlRequested(host::arrangerHost().toggleManualBass(selectedPlayer_));},15);
    for(int i=0;i<9;++i){
        const float x=20+i*85.0F;float db=i<8?p.tracks[static_cast<std::size_t>(i)].volumeDb:(globalUi_?globalUi_->masterGainDb:0.0F);
        label(c,i<8?p.tracks[static_cast<std::size_t>(i)].name:"Master",x+35,224,12,white,false,76,Align::Center);
        const float ceiling=i<8?12.0F:6.0F;
        box(c,{x+30,238,x+36,361},kBorder);const float y=361-(std::clamp(db,-60.0F,ceiling)+60)*123/(ceiling+60.0F);box(c,{x+8,y-10,x+58,y+10},dim,white,4);
        if(i==8||(p.loaded&&!p.styleSwitchPending))hit({x,232,x+72,370},{},[this,i,ceiling,player=selectedPlayer_,serial=p.styleSelectionSerial,
                     zoom=displayZoom_,gesture=RelativeVolumeGesture{},last=db](float,float yy) mutable {
            if(i<8){const auto now=host::arrangerHost().snapshot(player);if(player!=selectedPlayer_||now.styleSelectionSerial!=serial||now.styleSwitchPending)return;if(!gesture.grabbed)last=now.tracks[i].volumeDb;}
            else if(!gesture.grabbed)last=globalUi_?globalUi_->masterGainDb:0.0F;
            const float v=gesture.update(yy,last,-60.0F,ceiling,zoom);
            if(std::abs(v-last)<0.01F)return;
            if(i<8){if(!host::arrangerHost().setTrackVolume(player,i,v,serial))return;}
            else changeGlobalSettings([v](auto& g){g.masterGainDb=v;});
            last=v;dirty_=true;
        });
        if(controlStyleTracks_ && i<8){
            const auto& track=p.tracks[static_cast<std::size_t>(i)];
            button(c,{x,373,x+72,401},"Mute",orange,track.mute,p.loaded,[this,i,player=selectedPlayer_,serial=p.styleSelectionSerial]{togglePartMute(player,i,serial);},12,true);
        }else label(c,fmtFixed(db,1)+" dB",x+35,397,13,white,false,78,Align::Center);
    }
    button(c,{16,405,360,430},keyboardSetNextMeasure_?"Style KbdSet: Next Measure":"Style KbdSet: Immediate",green,keyboardSetNextMeasure_,true,[this]{keyboardSetNextMeasure_=!keyboardSetNextMeasure_;pendingKeyboardSet_=-1;markPersistentStateChanged();dirty_=true;},12);
    button(c,{370,405,610,430},"Style Tracks",orange,controlStyleTracks_,true,[this]{
        controlStyleTracks_=!controlStyleTracks_;dirty_=true;
    },12);
    button(c,{620,405,784,430},"Reset Tempo",orange,false,p.loaded,[this]{tempoWheelDisplayUntil_=0;controlRequested(host::arrangerHost().resetTempo(selectedPlayer_));},12);
}
void ArrangerView::drawScale(Canvas& c){
    box(c,{10,165,790,167},green);
    button(c,{16,172,121,197},"Scale",green,!scaleQuarterTonePage_,true,[this]{
        if(scaleQuarterTonePage_&&scaleMainRemembered_){
            ctrl_.setScale(scaleMainCents_,scaleMainName_,scaleMainTonic_);ctrl_.setScaleEnabled(scaleMainEnabled_);
        }else if(scaleQuarterTonePage_)ctrl_.setScaleEnabled(false);
        scaleQuarterTonePage_=false;refresh();dirty_=true;
    },14);
    button(c,{130,172,268,197},"Quarter Tone",green,scaleQuarterTonePage_,true,[this]{
        if(!scaleQuarterTonePage_){
            scaleMainCents_=ctrl_.scaleCents();scaleMainName_=ctrl_.scaleName();scaleMainTonic_=ctrl_.scaleTonic();
            scaleMainEnabled_=ctrl_.scaleEnabled();scaleMainRemembered_=true;
        }
        scaleQuarterTonePage_=true;scalePresetPage_=0;dirty_=true;
    },14);
    button(c,{278,172,367,197},"Write",green,false,scaleQuarterTonePage_,[this]{
        scaleNameEditing_=true;editor_=true;held_={};
        const std::string initial=ctrl_.scaleName()=="MANUAL"?"QT Preset":ctrl_.scaleName();
        SilvetonSamplerView::requestExternalTextEdit("Quarter Tone Preset",initial,[this](const std::string& name){
            const bool saved=ctrl_.saveUserScale(name);scaleNameEditing_=false;editor_=false;picker_=Picker::None;tab_=Tab::Scale;
            if(!saved)showToast("Enter a valid preset name",4000);
            else{scalePresetPage_=std::max(0,(ctrl_.userScaleCount()-1)/16);showToast("Quarter Tone preset saved",2500);}
            refresh();dirty_=true;
        });dirty_=true;
    },12);
    const auto& presets=SamplerAppController::scalePresets();
    for(int i=0;i<16;++i){const int row=i/4,col=i%4;const float x=16+col*89.0F,y=204+row*46.0F;
        const int index=scaleQuarterTonePage_?scalePresetPage_*16+i:i;
        const bool supported=scaleQuarterTonePage_?index<ctrl_.userScaleCount():static_cast<std::size_t>(index)<presets.size();
        const std::string name=!supported?"—":scaleQuarterTonePage_?ctrl_.userScaleName(index):presets[static_cast<std::size_t>(index)].name;
        const bool selected=supported&&ctrl_.scaleEnabled()&&scaleName_==name;
        button(c,{x,y,x+82,y+37},name,green,selected,supported,[this,index,name]{
            const bool already=ctrl_.scaleEnabled()&&ctrl_.scaleName()==name;
            if(scaleQuarterTonePage_&&already)ctrl_.setScaleEnabled(false);
            else{
                if(scaleQuarterTonePage_)ctrl_.useUserScale(index);
                else{const auto& preset=SamplerAppController::scalePresets()[static_cast<std::size_t>(index)];ctrl_.setScale(SamplerAppController::scaleTurned(preset.cents,0),preset.name,0);}
                ctrl_.setScaleEnabled(true);
            }
            refresh();dirty_=true;
        },12);
    }
    if(scaleQuarterTonePage_){
        button(c,{17,391,192,421},"Clear",green,false,true,[this]{ctrl_.setScale(std::vector<float>(12,0.0F),"MANUAL",0);ctrl_.setScaleEnabled(true);refresh();},14);
        button(c,{201,391,280,421},"◀",green,false,scalePresetPage_>0,[this]{--scalePresetPage_;dirty_=true;},15);
        button(c,{288,391,367,421},"▶",green,false,(scalePresetPage_+1)*16<ctrl_.userScaleCount(),[this]{++scalePresetPage_;dirty_=true;},15);
    }else button(c,{17,391,367,421},"Equal",green,false,true,[this]{ctrl_.setScale(std::vector<float>(12,0.0F),"EQUAL",0);ctrl_.setScaleEnabled(true);refresh();},14);
    constexpr int whites[]={0,2,4,5,7,9,11};constexpr int blacks[]={1,3,6,8,10};
    const float x=377,y=209,w=403,h=190,kw=w/7;
    const auto editNote=[this](int note){
        const auto current=ctrl_.scaleCents();
        ctrl_.setScaleNote(note,current[static_cast<std::size_t>(note)]==0?-50.0F:0.0F);ctrl_.setScaleEnabled(true);refresh();dirty_=true;
    };
    for(int i=0;i<7;++i){const int n=whites[i];box(c,{x+i*kw,y,x+(i+1)*kw-2,y+h},cents_[static_cast<std::size_t>(n)]==0?0xFFD4D5D4U:green,bg,2);
        label(c,signedNumber(static_cast<int>(std::lround(cents_[static_cast<std::size_t>(n)]))),x+(i+0.5F)*kw,416,17,dim,true,kw-4,Align::Center);
        hit({x+i*kw,y,x+(i+1)*kw-2,y+h},[editNote,n]{editNote(n);});
    }
    for(int i=0;i<5;++i){const int n=blacks[i],after=i<2?i:i+1;const float xx=x+(after+0.69F)*kw;box(c,{xx,y-10,xx+kw*0.63F,y+132},cents_[static_cast<std::size_t>(n)]==0?0xFF111414U:0xFF008A65U,kBorder,2);
        label(c,signedNumber(static_cast<int>(std::lround(cents_[static_cast<std::size_t>(n)]))),xx+kw*0.31F,191,17,dim,true,kw,Align::Center);
        hit({xx,y-10,xx+kw*0.63F,y+132},[editNote,n]{editNote(n);});
    }
}
void ArrangerView::drawChords(Canvas& c){
    if(chordSequencePage_){drawChordSequence(c);return;}
    const auto& p=players_[static_cast<std::size_t>(selectedPlayer_)];
    box(c,{11,165,789,167},orange);
    label(c,"Chord Recognition",20,195,20,white,true);
    button(c,{280,170,566,207},"CHORD SEQUENCE  >",blue,false,true,[this]{chordSequencePage_=true;chordSequencePageIndex_=0;dirty_=true;},15);
    label(c,p.chordName.empty()?"N.C.":p.chordName,780,198,29,orange,true,400,Align::Right);
    static const char* recognitionModes[]={"One Finger","One Finger Plus","Fingered (1 Note)","Fingered (3 Notes)","Advanced"};
    for(int mode=0;mode<5;++mode){
        const float x=16.0F+static_cast<float>(mode)*155.0F;
        const bool available=mode!=0||p.splitEnabled;
        button(c,{x,211,x+148,250},recognitionModes[mode],orange,p.chordRecognitionMode==mode,available,
            [this,mode]{controlRequested(host::arrangerHost().setChordRecognitionMode(mode));},12);
    }
    label(c,"Chord Scan Area",20,277,15,dim,true);
    label(c,"Keyboard Split",404,277,15,dim,true);
    static const char* scanAreas[]={"Off","Lower","Upper","Full"};
    for(int area=0;area<4;++area){
        const float x=16.0F+static_cast<float>(area)*93.0F;
        button(c,{x,285,x+86,323},scanAreas[area],orange,p.chordScanArea==area,true,
            [this,area]{controlRequested(host::arrangerHost().setChordScanArea(area));},14);
    }
    button(c,{404,285,577,323},"SPLIT",orange,keyboardSplitEnabled_,true,
        [this]{setKeyboardSplit(!keyboardSplitEnabled_);},14);
    button(c,{589,285,784,323},"Split Point "+arrangerNoteName(p.split),orange,false,true,[this]{globalSplitEditing_=false;openPicker(Picker::Split);},14);
    button(c,{16,341,196,381},"Memory",orange,p.memory,true,
        [this]{controlRequested(host::arrangerHost().toggleMemory());},14);
    button(c,{208,341,388,381},"Bass Inversion",orange,p.bassInversion,true,
        [this]{controlRequested(host::arrangerHost().toggleBassInversion());},14);
    button(c,{400,341,580,381},"Damper&Latch",orange,p.damperLatch,true,
        [this]{controlRequested(host::arrangerHost().toggleDamperLatch());},14);
    button(c,{592,341,784,381},"Synchro Start",orange,p.syncStart,p.syncStart||(p.loaded&&p.soundAssignmentsReady),
        [this]{controlRequested(host::arrangerHost().toggleSyncStart(selectedPlayer_));},14);
    label(c,"Memory Mode",20,400,12,dim,true);
    static const char* memoryModes[]={"Chord","Lower","Chord + Lower"};
    for(int mode=0;mode<3;++mode){
        const float x=154.0F+mode*210.0F;
        button(c,{x,390,x+202,430},memoryModes[mode],orange,p.memoryMode==mode,true,
            [this,mode]{controlRequested(host::arrangerHost().setMemoryMode(mode));},14);
    }
}
#include "ArrangerChordSequence.inc"
void ArrangerView::switchHomeTab(Tab selected){
    if(selected==tab_)return;
    if(kstJob_||persistentRestoreActive_||picker_!=Picker::None||panelMode_!=PanelMode::Home)return;
    cancelKeyboardSetHold();held_={};dragging_=false;
    // HOME tabs are peers. MAIN is the only root, not a history item.
    navigationHistory_.clear();tab_=selected;chordSequencePage_=false;chordSequenceEdit_=false;dirty_=true;
}
void ArrangerView::drawTabs(Canvas& c){
    // Pa5X v1.4 HOME: exact pane order.  All 10 tabs stay in one fixed row.
    constexpr float left=3.0F, end=797.0F, gap=1.0F;
    const float width=(end-left-gap*9.0F)/10.0F;
    for(std::size_t i=0;i<kPa5xHomeTabs.size();++i){
        const auto& entry=kPa5xHomeTabs[i];
        const float x=left+static_cast<float>(i)*(width+gap);
        const RectF r{x,433.0F,x+width,477.0F};
        const bool active=tab_==entry.tab;
        box(c,r,active?0xFFFFA527U:key,active?orange:kBorder,2);
        const float font= i==4 || i==5 ? 10.0F:12.5F;
        label(c,entry.compact,r.centerX(),461.0F,font,active?bg:dim,active,width-5,Align::Center);
        if(!active)hit(r,[this,tab=entry.tab]{switchHomeTab(tab);});
    }
}

void ArrangerView::stepTempo(int step){
    const auto current=host::arrangerHost().snapshot(selectedPlayer_);
    const auto source=arrangerStyleSelectionKey(current);
    const bool recent=selectedPlayer_==tempoWheelPlayer_&&source==tempoWheelSourceKey_&&nowMs()<tempoWheelDisplayUntil_;
    const double base=recent?tempoWheelDesired_:current.bpm;
    const double desired=std::clamp(base+static_cast<double>(step),20.0,400.0);
    const bool accepted=host::arrangerHost().setTempo(selectedPlayer_,desired);
    if(accepted){tempoWheelPlayer_=selectedPlayer_;tempoWheelSourceKey_=source;tempoWheelDesired_=desired;
        tempoWheelDisplayUntil_=nowMs()+150;tapTempoCount_=0;lastTap_=0;}
    controlRequested(accepted);
}

void ArrangerView::selectPanelKeyboardSet(int position,const RectF& rect){
    const auto index=static_cast<std::size_t>(position);
    if(keyboardWorkingSets_[index].combi||keyboardSets_[index]>0||!keyboardSetPaths_[index].empty()){
        pendingKeyboardSet_=-1;
        if(recallKeyboardSet(position))armKeyboardSetHold(position,rect);
    }else openKeyboardSetSelector(position);
}
void ArrangerView::startStopPlayer(int player){
    auto& arranger=host::arrangerHost();
    if(!arranger.snapshot(0).playing&&!arranger.snapshot(1).playing)setPlayerFocus(player);
    controlRequested(arranger.startStop(player));
}
void ArrangerView::movePlayerFader(float position){
    host::arrangerHost().setCrossfade(position);
    const int focus=position<0.5F?0:position>0.5F?1:selectedPlayer_;
    setPlayerFocus(focus,false);
}

void ArrangerView::drawPanel(Canvas& c){
    // Approved performance layout: the inner 800x480 display stays fixed.
    // Style controls share one blue; Keyboard Set and Sound controls use teal.
    const auto p=players_[static_cast<std::size_t>(selectedPlayer_)];
    auto& h=host::arrangerHost();
    const bool navigationReady=!kstJob_&&!persistentRestoreActive_;
    constexpr ColorInt keyboardTeal=0xFF008C9FU,soundTeal=0xFF00786EU;
    constexpr ColorInt navigationGrey=0xFF33414FU,panicRed=0xFFD22635U;
    const auto panelButton=[&](const RectF& rect,const std::string& text,ColorInt color,
                              bool on,bool enabled,std::function<void()> action,float size=16.0F){
        box(c,rect,enabled?color:0xFF183044U,kBorder,7.0F);
        if(on&&enabled){
            Paint outline;outline.color=white;outline.style=Style::Stroke;outline.strokeWidth=3.0F;
            c.drawRoundRect({rect.left+1.5F,rect.top+1.5F,rect.right-1.5F,rect.bottom-1.5F},6.0F,6.0F,outline);
        }
        const auto line=text.find('\n');
        if(line==std::string::npos)label(c,text,rect.centerX(),rect.centerY()+size*.34F,size,enabled?white:dim,true,rect.width()-12,Align::Center);
        else{
            label(c,text.substr(0,line),rect.centerX(),rect.centerY()-size*.28F,size,enabled?white:dim,true,rect.width()-12,Align::Center);
            label(c,text.substr(line+1),rect.centerX(),rect.centerY()+size*.94F,size,enabled?white:dim,true,rect.width()-12,Align::Center);
        }
        if(enabled&&action)hit(rect,std::move(action),{},true);
    };
    label(c,"SILVETON",22,42,28,white,true,276);
    label(c,"ARRANGER",23,65,15,dim,true,276);
    if(picker_==Picker::None)panelButton({156,16,298,84},"LIVE VIEW",keyboardTeal,false,navigationReady,[this]{
        home();liveView_=true;dirty_=true;
    },19);

    // Master and the live accompaniment/keyboard switches are all at the left.
    label(c,"MASTER",54,100,13,dim,true,82,Align::Center);
    const float master=globalUi_?globalUi_->masterGainDb:0.0F;
    box(c,{50,124,56,482},kBorder);
    const float masterY=482.0F-(std::clamp(master,-60.0F,6.0F)+60.0F)*358.0F/66.0F;
    box(c,{29,masterY-10,77,masterY+10},dim,white,2);
    if(globalUi_)hit({18,113,89,496},{},[this](float,float y){
        if(globalSettingsRestorePending_)restoreSavedGlobalSettings();
        auto state=ctrl_.globalUiState();if(!state)return;
        state->masterGainDb=std::clamp(-60.0F+(482.0F-y)*66.0F/358.0F,-60.0F,6.0F);
        if(ctrl_.updateGlobalUi(*state)){globalUi_=*state;rememberCurrentGlobalSettings();}
        else showToast(ctrl_.lastFailure(),5000);
        refresh(false);dirty_=true;
    });
    label(c,fmtFixed(master,1),54,522,18,white,true,84,Align::Center);
    label(c,"dB",54,542,11,dim,false,82,Align::Center);
    panelButton({106,113,196,177},"SYNC\nSTART",styleBlue,p.syncStart,p.syncStart||(p.loaded&&p.soundAssignmentsReady),
        [this]{controlRequested(host::arrangerHost().toggleSyncStart(selectedPlayer_));},14);
    panelButton({206,113,296,177},"SYNC\nSTOP",styleBlue,p.syncStop,p.syncStop||(p.loaded&&p.soundAssignmentsReady),
        [this]{controlRequested(host::arrangerHost().toggleSyncStop(selectedPlayer_));},14);
    panelButton({106,189,196,253},"CHORD\nLOWER",styleBlue,(p.chordScanArea&1)!=0,true,
        [this]{controlRequested(host::arrangerHost().toggleChordScanAreaBit(1));},14);
    panelButton({206,189,296,253},"CHORD\nUPPER",styleBlue,(p.chordScanArea&2)!=0,true,
        [this]{controlRequested(host::arrangerHost().toggleChordScanAreaBit(2));},14);
    panelButton({106,265,196,329},"MEMORY",styleBlue,p.memory,true,[this]{controlRequested(host::arrangerHost().toggleMemory());},12);
    panelButton({206,265,296,329},"AUTO\nFILL",styleBlue,p.autoFill,true,[this]{controlRequested(host::arrangerHost().toggleAutoFill(selectedPlayer_));},14);
    panelButton({106,343,296,397},"SPLIT",soundTeal,keyboardSplitEnabled_,true,[this]{setKeyboardSplit(!keyboardSplitEnabled_);},19);
    constexpr std::array<int,4> panelParts{{6,2,1,0}};
    constexpr std::array<const char*,4> panelPartNames{{"LOWER","UPPER\n3","UPPER\n2","UPPER\n1"}};
    for(std::size_t i=0;i<panelParts.size();++i){
        const int part=panelParts[i];const auto& upper=uppers_[static_cast<std::size_t>(part)];
        const float x=i%2U==0U?106.0F:206.0F,y=i<2U?411.0F:481.0F;
        const bool on=upper&&upper->enabled&&!upper->mute;
        panelButton({x,y,x+90,y+58},panelPartNames[i],soundTeal,on,upper.has_value()&&(part!=6||keyboardSplitEnabled_),
            [this,part]{togglePartMute(-1,part);},14);
    }
    label(c,"MIDI "+std::to_string(midiConnections_)+"  |  "+(audioSampleRate_>0?std::to_string(audioSampleRate_/1000)+" kHz":"Audio stopped"),18,562,12,dim,false,280);
    std::string statusWarning;{std::lock_guard<std::mutex> lock(warningMutex_);statusWarning=warning_;}
    if(!p.playbackWarning.empty())statusWarning=p.playbackWarning+(statusWarning.empty()?"":" | "+statusWarning);
    if(!statusWarning.empty()){
        label(c,statusWarning,20,598,11,0xFFED8976U,false,277);
        hit({18,578,302,624},[this,statusWarning]{showStyleInfo("Playback Status",statusWarning);});
    }

    // The four navigation destinations remain obvious, above the Tempo wheel.
    panelButton({1338,38,1476,88},"MEDIA",navigationGrey,false,true,[this]{openPanelFile();},17);
    panelButton({1486,38,1624,88},"GLOBAL",navigationGrey,false,navigationReady,[this]{openPanelSettings();},17);
    panelButton({1338,100,1476,150},"MENU",navigationGrey,false,navigationReady,[this]{panelMenu();},17);
    panelButton({1486,100,1624,150},"EXIT",navigationGrey,false,true,[this]{panelExit();},17);
    label(c,"TEMPO",1482,190,20,white,true,280,Align::Center);
    drawTempoWheel(c,p);
    panelButton({1338,257,1396,315},"−",styleBlue,false,true,[this]{stepTempo(-1);},30);
    panelButton({1568,257,1624,315},"+",styleBlue,false,true,[this]{stepTempo(1);},30);
    panelButton({1338,384,1403,442},"RESET /\nTAP",styleBlue,false,true,[this]{tapTempo();},11);
    panelButton({1411,384,1476,442},"LOCK",styleBlue,p.tempoLock,true,[this]{controlRequested(host::arrangerHost().toggleTempoLock(selectedPlayer_));},11);
    panelButton({1484,384,1549,442},"FADE",styleBlue,p.fadeDirection!=0,p.loaded&&p.soundAssignmentsReady,[this]{controlRequested(host::arrangerHost().toggleFade(selectedPlayer_));},11);
    panelButton({1557,384,1624,442},"RESET\nTEMPO",styleBlue,false,p.loaded,[this]{tempoWheelDisplayUntil_=0;controlRequested(host::arrangerHost().resetTempo(selectedPlayer_));},11);
    label(c,"TRANSPOSE",1482,478,18,white,true,280,Align::Center);
    panelButton({1338,496,1422,552},"−",navigationGrey,false,true,[this]{stepTranspose(-1);},28);
    panelButton({1432,496,1530,552},signedNumber(globalUi_?globalUi_->transpose:0),navigationGrey,false,true,[this]{stepTranspose(0);},26);
    panelButton({1540,496,1624,552},"+",navigationGrey,false,true,[this]{stepTranspose(1);},28);

    // Direct Keyboard Sets, targeted Style selectors and X-fader are one row.
    label(c,"KEYBOARD SET",296,656,20,white,true,556,Align::Center);
    for(int position=0;position<4;++position){const float x=18.0F+static_cast<float>(position)*94.0F;
        const RectF rect{x,670,x+84,738};
        panelButton(rect,std::to_string(position+1),keyboardTeal,selectedKeyboardSet_==position,navigationReady,
            [this,position,rect]{selectPanelKeyboardSet(position,rect);},30);
    }
    panelButton({394,670,574,738},"LIBRARY",keyboardTeal,false,navigationReady,[this]{openKeyboardSetSelector();},20);
    panelButton({600,670,740,738},"STYLE P1",styleBlue,selectedPlayer_==0,navigationReady,[this]{openStyleSelectorForPlayer(0);},18);
    label(c,"X-FADER",900,656,20,white,true,280,Align::Center);
    box(c,{768,702,1032,708},0xFF5B6266U);
    const float crossfadeX=768.0F+h.crossfade()*264.0F;
    box(c,{crossfadeX-10,681,crossfadeX+10,729},white,kBorder,3);
    hit({750,670,1050,738},{},[this](float x,float){
        const float position=std::clamp((x-768.0F)/264.0F,0.0F,1.0F);
        movePlayerFader(position);
    });
    panelButton({1060,670,1200,738},"STYLE P2",styleBlue,selectedPlayer_==1,navigationReady,[this]{openStyleSelectorForPlayer(1);},18);
    panelButton({1220,670,1388,738},"PANIC",panicRed,false,true,[this]{host::arrangerHost().panic();ctrl_.panic();refresh();},23);
    panelButton({1400,670,1624,738},"STOP ALL",styleBlue,false,true,[this]{controlRequested(host::arrangerHost().stop(0));controlRequested(host::arrangerHost().stop(1));},23);
    box(c,{18,752,1624,754},kBorder);

    // Keep every section bound to the same actual pending/loop/booked state.
    const auto styleElement=[&](int index,const RectF& rect,const std::string& text,float size){
        const bool available=p.loaded&&p.available[static_cast<std::size_t>(index)];
        const auto cue=liveElementCue(p,index);
        const bool lit=cue.queued||cue.looping||cue.returning?(nowMs()/250)%2==0:cue.selected;
        panelButton(rect,text,styleBlue,lit,available,[this,index]{controlRequested(host::arrangerHost().selectElement(selectedPlayer_,index));},size);
        if(p.pendingElement==index)box(c,{rect.left+6,rect.bottom-6,rect.right-6,rect.bottom-3},white);
    };
    label(c,"INTRO",260,786,20,white,true,480,Align::Center);
    label(c,"FILL",808,786,20,white,true,576,Align::Center);
    label(c,"ENDING",1369,786,20,white,true,510,Align::Center);
    for(int i=0;i<3;++i){const float x=18.0F+static_cast<float>(i)*164.0F;styleElement(i,{x,798,x+156,878},"INTRO "+std::to_string(i+1),20);}
    for(int i=0;i<4;++i){const float x=520.0F+static_cast<float>(i)*146.0F;styleElement(7+i,{x,798,x+138,878},"FILL "+std::to_string(i+1),20);}
    for(int i=0;i<3;++i){const float x=1114.0F+static_cast<float>(i)*173.0F;styleElement(12+i,{x,798,x+164,878},"ENDING "+std::to_string(i+1),19);}

    // These are the largest targets and the bottommost row of the application.
    label(c,"VARIATION",397,906,19,white,true,758,Align::Center);
    for(int i=0;i<4;++i){const float x=18.0F+static_cast<float>(i)*192.0F;styleElement(3+i,{x,916,x+182,1024},"VAR "+std::to_string(i+1),31);}
    styleElement(11,{786,916,986,1024},"BREAK",31);
    for(int player=0;player<2;++player){
        const auto& state=players_[static_cast<std::size_t>(player)];const float x=player==0?998.0F:1317.0F;
        panelButton({x,916,x+307,1024},"PLAYER "+std::to_string(player+1)+"\nSTART / STOP",styleBlue,state.playing,
            state.playing||(state.loaded&&state.soundAssignmentsReady),[this,player]{
                startStopPlayer(player);
            },25);
    }
}
void ArrangerView::rememberPlayerKeyboardBuffers(){
    const auto& player=players_[static_cast<std::size_t>(selectedPlayer_)];
    if(selectedStyleKey_.empty()||keyboardWorkingPlayer_!=selectedPlayer_||keyboardWorkingStyleSerial_!=player.styleSelectionSerial)return;
    auto& buffers=playerKeyboardBuffers_[static_cast<std::size_t>(selectedPlayer_)];
    buffers.owner=selectedStyleKey_;buffers.serial=keyboardWorkingStyleSerial_;
    buffers.working=keyboardWorkingSets_;buffers.slots=keyboardSets_;
    buffers.paths=keyboardSetPaths_;buffers.names=keyboardSetNames_;
}
void ArrangerView::setPlayerFocus(int player,bool forceMetadata){
    player=std::clamp(player,0,1);if(player==selectedPlayer_)return;
    // A pending Immediate preview belongs to its incoming Style, never to the
    // old Player's edit buffers. Restore its previous live setup before capture.
    if(styleKeyboardCue_.serial!=0)clearStyleKeyboardCue(true);
    refresh(false);
    if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4)rememberStyleKeyboardSet();
    rememberPlayerKeyboardBuffers();selectedPlayer_=player;
    tempoWheelDisplayUntil_=0;
    if(styleToKeyboardSet_!=0)keyboardRecallStyle_.clear();
    refresh(forceMetadata);dirty_=true;
}
int ArrangerView::styleSelectorPlayer() const {
    return styleSelectorPlayer_>=0?std::clamp(styleSelectorPlayer_,0,1):std::clamp(selectedPlayer_,0,1);
}
bool ArrangerView::styleSelectorOpen() const {
    return picker_==Picker::Style||picker_==Picker::SavedStyleLibrary||
        (picker_==Picker::KstCatalog&&kstCatalogTab_==0);
}
void ArrangerView::openStyleSelectorForPlayer(int player){
    player=std::clamp(player,0,1);
    const auto current=host::arrangerHost().snapshot(player);
    if(!kstCatalog_&&!current.loaded){
        openSavedStyleLibrary(player);
        return;
    }
    openPicker(Picker::Style,player);
    if(picker_==Picker::Style&&current.loaded&&!current.sourcePath.empty()){
        const auto dir=files::parentOf(current.sourcePath);
        if(!dir.empty()&&files::isDirectory(dir)){
            listDirectory(dir);pickerCategory_=2;
            int position=0;
            for(const auto& entry:entries_)if(!entry.directory){
                if(entry.path==current.sourcePath){pickerPage_=position/(liveView_?libraryPositions:10);break;}
                ++position;
            }
        }
    }
}
void ArrangerView::openPicker(Picker type,int target){
    if(leaveInstrumentEditor())return;
    
    if(type==Picker::KstFolder||type==Picker::Set){openMedia();return;}
    if(kstJob_){picker_=Picker::KstProgress;showToast("The SET is loading. Wait for it to finish or press Cancel.",4500);return;}
    bool bankOnly=bankSoundsOnly_;bankSoundsOnly_=false;
    const int styleTarget=target>=0?std::clamp(target,0,1):styleSelectorOpen()?styleSelectorPlayer():selectedPlayer_;
    if(type!=Picker::Style&&target>=0)targetPart_=target;
    if(type==Picker::Style&&!bankOnly&&host::arrangerHost().snapshot(styleTarget).savedStyleBank>0){openSavedStyleLibrary(styleTarget);return;}
    if(type==Picker::KeyboardSet&&!bankOnly){
        refreshSavedKeyboardEntries();
        const bool currentCombi=currentKeyboardCombiSlot_>0&&!currentKeyboardCombiBankIdentity_.empty()&&
            currentKeyboardCombiBankIdentity_==keyboardSamplerBankIdentity(ctrl_.currentBankFile());
        const bool haveSetKeyboards=kstCatalog_&&!kstCatalog_->keyboardSets.empty();
        if(startsWith(files::nameOf(activeSavedKeyboardEntryPath_),"ARRANGER_USER_KBD_")||
           (!currentCombi&&!haveSetKeyboards&&!savedKeyboardEntries_.empty())){openSavedKeyboardLibrary();return;}
        // Keep an active sampler COMBI in its own library. A SET containing
        // only Styles/Sounds must not hide usable USER/COMBI performances.
        if(currentCombi||!haveSetKeyboards)bankOnly=true;
    }
    if(!bankOnly&&kstCatalog_&&(type==Picker::Style||type==Picker::Sound||type==Picker::KeyboardSet)){
        if(type==Picker::Sound||type==Picker::KeyboardSet)keyboardSelectStates_[{kstCatalog_->rootPath,type==Picker::Sound?1:2}].locateActive=true;
        openKstCatalog(type==Picker::Style?0:(type==Picker::Sound?1:2),type==Picker::Style?styleTarget:-1);return;
    }
    if(type==Picker::Style&&storageAccessRequest_&&!storageAccessRequest_())return;
    if(!sameSelectorFamily(type))rememberNavigation();
    if(type==Picker::Style||type==Picker::KeyboardSet){targetTrack_=-1;targetPart_=0;}
    pickerPage_=0;pickerCategory_=0;entries_.clear();stylePickerError_.clear();
    if(type==Picker::Style)styleSelectorPlayer_=styleTarget;picker_=type;editor_=false;
    if(type==Picker::Style||type==Picker::KstFolder){
        std::string dir=pickerDirectory_;if(dir.empty())dir=files::parentOf(ctrl_.currentBankFile());
        if(dir.empty()||!files::isDirectory(dir))dir=files::isDirectory("/storage/emulated/0")?"/storage/emulated/0":files::homeDirectory();
        listDirectory(dir);
    }else if(type==Picker::Sound){sounds_=ctrl_.soundCatalog();for(std::size_t i=0;i<sounds_.size();++i){
        const auto& sound=sounds_[i];
        if(targetTrack_>=0&&(sound.bank!=0||sound.page!=0||sound.slot<1||sound.slot>500))continue;
        entries_.push_back({sound.name,"",false,static_cast<int>(i)});}}
    else if(type==Picker::KeyboardSet){
        const bool currentBank=!currentKeyboardCombiBankIdentity_.empty()&&
            currentKeyboardCombiBankIdentity_==keyboardSamplerBankIdentity(ctrl_.currentBankFile());
        for(const auto& p:ctrl_.combiCatalog()){
            if(currentBank&&p.first==currentKeyboardCombiSlot_)pickerPage_=static_cast<int>(entries_.size()/(liveView_?libraryPositions:10));
            entries_.push_back({p.second,"",false,p.first});
        }
    }
    else if(type==Picker::Set){for(const auto& n:ctrl_.savedSets())entries_.push_back({n,"",false,-1});}
    else if(type==Picker::Split){for(int n=1;n<128;++n)entries_.push_back({arrangerNoteName(n)+"   MIDI "+std::to_string(n),"",false,n});pickerPage_=std::clamp((players_[static_cast<std::size_t>(selectedPlayer_)].split-1)/10,0,12);}
    dirty_=true;
}
void ArrangerView::listDirectory(const std::string& path){
    pickerDirectory_=path;pickerPage_=0;pickerCategory_=0;entries_.clear();stylePickerError_.clear();
    for(const auto& n:files::listNames(path)){const auto p=files::join(path,n);if(files::isDirectory(p))entries_.push_back({n,p,true,-1});else if(picker_!=Picker::KstFolder&&styleFile(n))entries_.push_back({n,p,false,-1});}
    std::sort(entries_.begin(),entries_.end(),[](const Entry& a,const Entry& b){if(a.directory!=b.directory)return a.directory>b.directory;return a.name<b.name;});
}
void ArrangerView::chooseEntry(const Entry& e){
    if(picker_==Picker::KstFolder){if(e.directory){if(arranger::canSelectPa5xKstDirectory(e.path))startKstScan(e.path);else listDirectory(e.path);}dirty_=true;return;}
    if(picker_==Picker::Style){
        if(e.directory){listDirectory(e.path);dirty_=true;return;}
        loadStyleForPlayback(styleSelectorPlayer(),e.path);
    }
    else if(picker_==Picker::Sound){
        const auto s=sounds_[static_cast<std::size_t>(e.value)];
        if(targetTrack_>=0){
            auto& arranger=host::arrangerHost();
            auto program=host::resolveArrangerBankSound(s.slot);
            if(!program){showToast("This USER Sound is unavailable",4500);return;}
            if(!arranger.assignSound(soundPlayer_,targetTrack_,s.slot,program,soundSerial_)){showToast(arranger.lastError(),5000);return;}
            finishSoundSelection();return;
        }
        const bool ok=ctrl_.assignUpperSound(targetPart_,s);
        if(!ok){showToast(ctrl_.lastFailure(),5000);return;}
        if(targetPart_>=0&&targetPart_<7){keyboardSoundBindings_[targetPart_]={};(void)host::arrangerHost().retainPreparedKeyboardSound(targetPart_,-1,-1,-1);}
        normalizeKeyboardPartRange(targetPart_);finishSoundSelection();
    }else if(picker_==Picker::KeyboardSet){
        KeyboardWorkingSet state;std::string error;
        if(!prepareWorkingKeyboardSet("",e.value,state,error)){showToast(error,6000);return;}
        const int target=targetKbdSet_>=0&&targetKbdSet_<4?targetKbdSet_:-1;
        if(!keyboardSetTargetValid(target))return;
        if(!applyWorkingKeyboardSet(state,target,true))return;
        if(target>=0){const auto i=static_cast<std::size_t>(target);keyboardSetPaths_[i].clear();keyboardSets_[i]=e.value;
            keyboardSetNames_[i]=state.combi->name;keyboardWorkingSets_[i]=captureKeyboardWorkingSet();}
        overrideStyleKeyboardCue();refresh();
    }else if(picker_==Picker::Set){
        rememberStyleKeyboardSet();
        const auto error=ctrl_.loadSavedSet(e.name);if(error){showToast(*error,5000);return;}
        activeNativeKeyboardSetPath_.clear();activeSavedKeyboardEntryPath_.clear();keyboardSoundBindings_={};keyboardMetadataRestorePending_=false;
        keyboardFxOverride_={};keyboardFxWarning_.clear();keyboardSplitSuppressed_.fill(false);
        const auto recalled=ctrl_.engine.nativeKeyboardCombi();
        if(recalled)for(int part=0;part<7;++part){
            keyboardRangeLow_[static_cast<std::size_t>(part)]=recalled->part(part).keyLow;
            keyboardRangeHigh_[static_cast<std::size_t>(part)]=recalled->part(part).keyHigh;
            (void)host::arrangerHost().retainPreparedKeyboardSound(part,-1,-1,-1);
        }
        selectedKeyboardSet_=-1;scaleMainRemembered_=false;
        if(recalled){
            keyboardLowerMuteBeforeFull_=recalled->part(6).mute;
            auto state=captureKeyboardWorkingSet();state.recall.lowerMuteBeforeFull=keyboardLowerMuteBeforeFull_;
            state.metadataFile.clear();state.metadataBindings.clear();state.sourceIdentity.clear();
            (void)applyWorkingKeyboardSet(state,-1,true);
        }
        overrideStyleKeyboardCue();picker_=Picker::None;refresh();
    }
    else if(picker_==Picker::Split){
        if(globalSplitEditing_){
            if(keyboardUseGlobalSplit_)applySplit(e.value);
            else controlRequested(host::arrangerHost().setGlobalSplit(e.value,false));
            if(!restoreNavigation())picker_=Picker::ArrangerControl;
            globalSplitEditing_=false;
        }else{keyboardUseGlobalSplit_=false;applySplit(e.value);if(!restoreNavigation())picker_=Picker::None;}
    }
    dirty_=true;
}
void ArrangerView::drawPicker(Canvas& c){
    if(picker_==Picker::OriginalSoundSettings){drawOriginalSoundSettings(c);return;}
    if(picker_==Picker::SetInfo||picker_==Picker::SetSounds||picker_==Picker::SetSoundInfo){drawSetInspector(c);return;}
    if(picker_==Picker::DrumKitEdit){drawDrumEditor(c);return;}
    if(picker_==Picker::DrumSampleSelect||picker_==Picker::DrumKeySelect){drawDrumSampleSelect(c);return;}
    if(picker_==Picker::SettingsMenu){drawSettingsMenu(c);return;}
    if(picker_==Picker::Media){drawMedia(c);return;}
    if(picker_==Picker::StyleControls){drawStyleControls(c);return;}
    if(picker_==Picker::ArrangerControl){drawArrangerSettings(c);return;}
    if(picker_==Picker::WriteMenu||picker_==Picker::SaveAsMenu){drawWriteMenu(c);return;}
    if(picker_==Picker::ResourceSave){drawResourceSave(c);return;}
    if(picker_==Picker::SavedStyleLibrary){drawSavedStyleLibrary(c);return;}
    if(picker_==Picker::SavedKeyboardLibrary){drawSavedKeyboardLibrary(c);return;}
    if(picker_==Picker::HomeMenu){drawHomeMenu(c);return;}
    if(picker_==Picker::Switches){drawSwitches(c);return;}
    if(picker_==Picker::VelocityControl){drawVelocityControl(c);return;}
    if(picker_==Picker::Pa5xFxCatalog){drawPa5xFxCatalog(c);return;}
    if(picker_==Picker::NumberedFxEdit){drawNumberedFxEditor(c);return;}
    if(picker_==Picker::NumberedFxValue){drawNumberedFxValue(c);return;}
    if(picker_==Picker::NumberedFxTrack){drawNumberedFxTrack(c);return;}
    if(picker_==Picker::KeyboardEdit){drawKeyboardEdit(c);return;}
    if(picker_==Picker::DrumFamilyEdit){drawDrumFamilyEdit(c);return;}
    if(picker_==Picker::StyleSounds||picker_==Picker::StyleDrums||picker_==Picker::KeyboardParts){drawLiveSoundPage(c);return;}
    if(picker_==Picker::StyleInfo){drawStyleInfo(c);return;}
    if(picker_==Picker::KstProgress){drawKstProgress(c);return;}
    if(picker_==Picker::KstReport){drawKstReport(c);return;}
    if(picker_==Picker::KstCatalog){drawKstCatalog(c);return;}
    if(picker_==Picker::KstSample){drawKstSample(c);return;}
    if(picker_==Picker::StyleRead){drawStyleRead(c);return;}
    if(picker_==Picker::KeyboardSetRead){drawKeyboardSetRead(c);return;}
    const bool large=fullLibrarySelector();
    const int rows=large?8:5,columns=large?3:2,positions=rows*columns;
    const float right=large?displayWidth_-4.0F:796.0F;
    const float tileWidth=(right-208.0F-4.0F*(columns-1))/columns;
    const float stride=large?39.0F:62.0F,tileHeight=large?36.0F:59.0F;
    box(c,{0,0,displayWidth_,displayHeight_},bg);
    const ColorInt ac=picker_==Picker::Sound||picker_==Picker::KeyboardSet?green:orange;
    button(c,{3,3,96,35},"‹ Back",ac,false,true,[this]{panelExit();},16);
    std::string title=picker_==Picker::KstFolder?"LOAD Pa SET / KST":picker_==Picker::Style?"STYLE":picker_==Picker::Sound?"SOUND":picker_==Picker::KeyboardSet?"KEYBOARD SET":picker_==Picker::Set?"SET":picker_==Picker::Split?"SPLIT POINT":"PAGE MENU";
    if(picker_==Picker::Split&&globalSplitEditing_)title="GLOBAL SPLIT";
    if(picker_==Picker::Sound)title=targetTrack_>=0&&soundPlayer_>=0?"SOUND / "+players_[soundPlayer_].tracks[targetTrack_].name:
        std::string("SOUND / ")+(targetPart_==6?"Lower":"Upper "+std::to_string(targetPart_+1));
    label(c,title,113,26,18,ac,true,230);label(c,"Player "+std::to_string((picker_==Picker::Style?styleSelectorPlayer():selectedPlayer_)+1),(208+right)*.5F,26,18,ac,true,170,Align::Center);
    if(picker_==Picker::Split&&!globalSplitEditing_)button(c,{515,3,795,35},keyboardUseGlobalSplit_?"Global Split: On":"Global Split: Off",green,keyboardUseGlobalSplit_,true,[this]{
        keyboardUseGlobalSplit_=!keyboardUseGlobalSplit_;
        if(keyboardUseGlobalSplit_)applySplit(host::arrangerHost().snapshot(selectedPlayer_).globalSplit);
        markPersistentStateChanged();dirty_=true;
    },14);
    const bool folders=picker_==Picker::KstFolder;
    const bool fileBrowser=picker_==Picker::Style||folders;
    if(picker_==Picker::KeyboardSet)button(c,{4,40,97,75},"USER",ac,false,true,[this]{openSavedKeyboardLibrary();},15);
    else{box(c,{4,40,97,75},bg,ac,2);label(c,"USER",50,64,15,ac,true,90,Align::Center);}
    box(c,{102,40,196,75},panel,kBorder);label(c,folders?"KST":picker_==Picker::Style?"STG / MIDI":picker_==Picker::KeyboardSet?"COMBI":"BANK",149,64,picker_==Picker::Style?12.0F:15.0F,dim,false,90,Align::Center);
    button(c,{right-98,40,right,75},fileBrowser?"DRIVES":"LIBRARY",ac,false,fileBrowser,[this]{listDirectory(files::isDirectory("/storage")?"/storage":files::homeDirectory());dirty_=true;},14);
    if(picker_==Picker::Style||picker_==Picker::Sound||picker_==Picker::KeyboardSet)
        button(c,{210,40,382,75},kstCatalog_?"KST Catalog":"Load Pa SET / KST",orange,false,true,[this]{if(kstCatalog_)openKstCatalog(picker_==Picker::Style?0:(picker_==Picker::Sound?1:2));else openPicker(Picker::KstFolder);},13);
    const bool filtered=picker_==Picker::Style||picker_==Picker::Sound;
    const char* categories[]={"All",picker_==Picker::Style?"Folders":"Recent",picker_==Picker::Style?"Styles":"Favorites"};
    for(int i=0;i<(filtered?3:1);++i){
        const float y=84+i*70.0F;
        button(c,{5,y,196,y+62},categories[i],ac,pickerCategory_==i,true,
            [this,i]{pickerCategory_=i;pickerPage_=0;dirty_=true;},19);
    }
    std::vector<const Entry*> visible;
    const auto recent=picker_==Picker::Sound?ctrl_.recentSounds():std::vector<int>{};
    const auto favorites=picker_==Picker::Sound?ctrl_.soundFavourites():std::set<int>{};
    for(const auto& entry:entries_){bool keep=true;
        if(picker_==Picker::Style){if(pickerCategory_==1)keep=entry.directory;else if(pickerCategory_==2)keep=!entry.directory;}
        else if(picker_==Picker::Sound&&pickerCategory_>0){const int slot=sounds_[static_cast<std::size_t>(entry.value)].slot;keep=pickerCategory_==1?std::find(recent.begin(),recent.end(),slot)!=recent.end():favorites.count(slot)>0;}
        if(keep)visible.push_back(&entry);
    }
    const int pages=std::max(1,(static_cast<int>(visible.size())+positions-1)/positions);
    pickerPage_=std::clamp(pickerPage_,0,pages-1);
    for(int i=0;i<positions;++i){const int index=pickerPage_*positions+i;const int row=i%rows,col=i/rows;const float x=208+col*(tileWidth+4),y=(large?77.0F:82.0F)+row*stride;
        const RectF rect{x,y,x+tileWidth,y+tileHeight};box(c,rect,0xFF111316U,kBorder);
        if(index<static_cast<int>(visible.size())){const auto entry=*visible[static_cast<std::size_t>(index)];
            if(large){label(c,entry.name,x+10,y+24,16,white,true,tileWidth-20);}
            else {if(entry.directory){box(c,{x+8,y+17,x+43,y+40},0xFF8C7D4CU);box(c,{x+8,y+11,x+26,y+20},0xFF8C7D4CU);}else keyboard(c,x+7,y+18,37,24,ac);
                label(c,entry.name,x+54,y+36,19,white,true,tileWidth-60);}
            hit(rect,[this,entry]{chooseEntry(entry);});
        }else if(large){label(c,"Empty",x+10,y+24,13,dim,false,tileWidth-20);}
    }
    if(visible.empty())label(c,folders?"No folders here":(picker_==Picker::Style?"No STG / MIDI styles or folders":"No matching resources"),(208+right)*.5F,424,13,dim,false,right-390,Align::Center);
    button(c,{209,large?393.0F:398.0F,282,large?433.0F:434.0F},"◀",ac,false,pickerPage_>0,[this]{--pickerPage_;dirty_=true;},18);
    if(!visible.empty())label(c,std::to_string(pickerPage_+1)+" / "+std::to_string(pages),(208+right)*.5F,424,18,white,true,right-390,Align::Center);
    button(c,{right-76,large?393.0F:398.0F,right,large?433.0F:434.0F},"▶",ac,false,pickerPage_+1<pages,[this]{++pickerPage_;dirty_=true;},18);
    button(c,{5,large?393.0F:442.0F,98,large?433.0F:478.0F},"ROOT",ac,false,fileBrowser,[this]{listDirectory(files::isDirectory("/storage")?"/storage":files::homeDirectory());dirty_=true;},14);
    button(c,{104,large?393.0F:442.0F,196,large?433.0F:478.0F},"UP",ac,false,fileBrowser,[this]{const auto p=files::parentOf(pickerDirectory_);if(!p.empty())listDirectory(p);dirty_=true;},14);
    if(stylePickerError_.empty()||!large)label(c,fileBrowser?pickerDirectory_:"SILVETON User Library",216,large?447.0F:465.0F,14,dim,false,right-224);
    if(picker_==Picker::Style&&!stylePickerError_.empty()){
        label(c,stylePickerError_,216,447.0F,12,0xFFED8976U,false,right-224);
        hit({208,435,right,large?454.0F:456.0F},[this]{showStyleInfo("Style Load Failed",stylePickerError_);});
    }
    if(folders)label(c,"Choose the .SET or .KST folder",503,59,15,dim,false,380,Align::Center);
}

void ArrangerView::openKstCatalog(int catalogTab,int styleTarget){
    if(!kstCatalog_){if(!savedKstRoot_.empty()&&files::isDirectory(savedKstRoot_))startKstScan(savedKstRoot_,true);else openPicker(Picker::KstFolder);return;}
    const int targetPlayer=styleTarget>=0?std::clamp(styleTarget,0,1):styleSelectorOpen()?styleSelectorPlayer():selectedPlayer_;
    if(catalogTab==0&&(picker_!=Picker::KstCatalog||kstCatalogTab_!=0))
        styleSelectStates_[{kstCatalog_->rootPath,targetPlayer}].locateActive=true;
    if(picker_!=Picker::KstProgress&&!sameSelectorFamily(Picker::KstCatalog,catalogTab))rememberNavigation();
    if(catalogTab==0||catalogTab==2){targetTrack_=-1;targetPart_=0;}
    if(catalogTab==0)styleSelectorPlayer_=targetPlayer;
    picker_=Picker::KstCatalog;kstCatalogTab_=std::clamp(catalogTab,0,3);kstCatalogPage_=0;editor_=false;dirty_=true;
}
void ArrangerView::drawKstStyleSelect(Canvas& c){
    const auto catalogHandle=kstCatalog_;if(!catalogHandle)return;
    const auto& catalog=*catalogHandle;
    const bool compact=compactKstSelector();
    const float bankTop=compact?44.0F:84.0F, bankBottom=compact?72.0F:111.0F;
    const int rows=compact?8:5, columns=compact?3:2, positions=rows*columns;
    const float right=compact?displayWidth_-4.0F:796.0F;
    const float tileWidth=(right-208.0F-4.0F*(columns-1))/columns;
    const float tileTop=compact?77.0F:116.0F, tileStride=compact?39.0F:53.0F, tileHeight=compact?36.0F:49.0F;
    const float catStride=compact?51.0F:44.0F, catHeight=compact?47.0F:40.0F;
    const float pagerTop=compact?393.0F:385.0F, pagerBottom=compact?433.0F:418.0F;
    const int targetPlayer=styleSelectorPlayer();
    const auto stateKey=std::make_pair(catalog.rootPath,targetPlayer);
    auto& state=styleSelectStates_[stateKey];
    constexpr const char* allCategory="@all";
    struct Folder {std::string name,path,parent;std::vector<int> slots;std::map<std::size_t,std::string> missingSlots;std::size_t count{0};};
    std::map<std::string,Folder> folders;
    for(const auto& group:catalog.styleGroups){
        auto& folder=folders[group.relativePath];
        folder.name=group.name;folder.path=group.relativePath;folder.parent=group.parentPath;
        folder.slots=group.slotStyleIndices;
        folder.missingSlots=group.missingSlotFiles;
        if(folder.slots.empty())for(const auto index:group.styleIndices)folder.slots.push_back(static_cast<int>(index));
    }
    // Keep every actual file reachable, even if a folder's order metadata is
    // incomplete. Only explicitly empty metadata slots produce empty tiles.
    for(std::size_t index=0;index<catalog.styles.size();++index){
        const auto& entry=catalog.styles[index];
        auto path=entry.categoryPath;
        if(path.empty())path=files::parentOf(entry.relativePath);
        auto& folder=folders[path];folder.path=path;
        if(folder.name.empty())folder.name=files::nameOf(path);
        if(folder.parent.empty())folder.parent=files::parentOf(path);
        if(std::find(folder.slots.begin(),folder.slots.end(),static_cast<int>(index))==folder.slots.end())folder.slots.push_back(static_cast<int>(index));
        auto ancestor=folder.parent;
        while(!ancestor.empty()){
            auto& parent=folders[ancestor];parent.path=ancestor;
            if(parent.name.empty())parent.name=files::nameOf(ancestor);
            parent.parent=files::parentOf(ancestor);
            if(parent.parent==ancestor)break;
            ancestor=parent.parent;
        }
    }
    std::string rootFolder;
    if(!catalog.styles.empty()){
        const auto& path=catalog.styles.front().categoryPath;
        rootFolder=path.substr(0,path.find('/'));
    }
    if(rootFolder.empty()&&!folders.empty())rootFolder=folders.begin()->first;
    for(auto& item:folders){
        auto& folder=item.second;
        const auto prefix=folder.path+"/";
        for(const auto& entry:catalog.styles)
            if(entry.categoryPath==folder.path||entry.categoryPath.compare(0,prefix.size(),prefix)==0)++folder.count;
    }
    std::vector<int> allSlots;std::vector<bool> included(catalog.styles.size(),false);
    for(const auto& group:catalog.styleGroups)for(const auto index:group.styleIndices)
        if(index<catalog.styles.size()&&!included[index]){included[index]=true;allSlots.push_back(static_cast<int>(index));}
    for(std::size_t index=0;index<catalog.styles.size();++index)if(!included[index])allSlots.push_back(static_cast<int>(index));
    const auto& player=players_[static_cast<std::size_t>(targetPlayer)];
    const auto& activePath=player.sourcePath;
    if(!state.initialized||state.locateActive){
        markPersistentStateChanged();
        if(!state.initialized){state.browserPath=rootFolder;state.categoryPath=allCategory;state.categoryPage=0;}
        bool located=false;
        for(std::size_t index=0;index<catalog.styles.size();++index)if(catalog.styles[index].path==activePath){
            state.categoryPath=catalog.styles[index].categoryPath;
            const auto folder=folders.find(state.categoryPath);
            if(folder!=folders.end()){
                state.browserPath=folder->second.parent.empty()?rootFolder:folder->second.parent;
                const auto slot=std::find(folder->second.slots.begin(),folder->second.slots.end(),static_cast<int>(index));
                if(slot!=folder->second.slots.end())state.pages[state.categoryPath]=static_cast<int>(std::distance(folder->second.slots.begin(),slot)/positions);
            }
            state.locateCategory=true;located=true;break;
        }
        const auto previousFolder=folders.find(state.categoryPath);
        const bool emptyFolder=state.categoryPath!=allCategory&&(previousFolder==folders.end()||previousFolder->second.slots.empty());
        if(!located&&(!state.initialized||emptyFolder))for(const auto& group:catalog.styleGroups)if(!group.styleIndices.empty()){
            state.categoryPath=group.relativePath;state.browserPath=group.parentPath.empty()?rootFolder:group.parentPath;state.locateCategory=true;break;
        }
        state.lastSourcePath=activePath;state.initialized=true;
    }
    // Display Hold keeps the bank/page where the user is browsing, including
    // when a queued Style becomes active at the bar boundary.
    if(state.lastSourcePath!=activePath)markPersistentStateChanged();
    state.lastSourcePath=activePath;state.locateActive=false;
    if(state.categoryPath!=allCategory&&folders.count(state.categoryPath)==0){state.categoryPath=allCategory;markPersistentStateChanged();}
    if(folders.count(state.browserPath)==0){state.browserPath=rootFolder;markPersistentStateChanged();}
    struct Category {std::string path,name;std::size_t count;bool children;};
    std::vector<Category> categories;
    if(state.browserPath==rootFolder)categories.push_back({allCategory,"All Styles",catalog.styles.size(),false});
    const auto currentFolder=folders.find(state.browserPath);
    if(currentFolder!=folders.end()&&!currentFolder->second.slots.empty()){
        const auto count=std::count_if(currentFolder->second.slots.begin(),currentFolder->second.slots.end(),[&](int index){return index>=0&&static_cast<std::size_t>(index)<catalog.styles.size();});
        categories.push_back({currentFolder->first,"This folder",static_cast<std::size_t>(count),false});
    }
    std::set<std::string> listedFolders;
    const auto appendFolder=[&](const std::string& path){
        const auto item=folders.find(path);if(item==folders.end())return;
        const auto& folder=item->second;
        if(folder.parent!=state.browserPath||folder.path==state.browserPath||!listedFolders.insert(path).second)return;
        const bool children=std::any_of(folders.begin(),folders.end(),[&](const auto& candidate){return candidate.second.parent==folder.path&&candidate.first!=folder.path;});
        categories.push_back({folder.path,folder.name,folder.count,children});
    };
    // The catalog owns saved/natural ordering; the map is for lookup only.
    for(const auto& group:catalog.styleGroups)if(group.relativePath==state.browserPath)
        for(const auto child:group.childGroups)if(child<catalog.styleGroups.size())appendFolder(catalog.styleGroups[child].relativePath);
    for(const auto& group:catalog.styleGroups)appendFolder(group.relativePath);
    for(const auto& item:folders)appendFolder(item.first);
    if(state.locateCategory){
        state.locateCategory=false;
        const auto selected=std::find_if(categories.begin(),categories.end(),[&](const auto& category){return category.path==state.categoryPath;});
        if(selected!=categories.end())state.categoryPage=static_cast<int>((selected-categories.begin())/12);
    }
    const int categoryPages=std::max(1,static_cast<int>((categories.size()+11U)/12U));
    const int categoryPage=std::clamp(state.categoryPage,0,categoryPages-1);
    if(state.categoryPage!=categoryPage){state.categoryPage=categoryPage;markPersistentStateChanged();}
    button(c,{5,bankTop,98,bankBottom},"KST",orange,true,true,[this,catalogHandle,stateKey,rootFolder]{
        if(kstCatalog_!=catalogHandle)return;
        auto& browse=styleSelectStates_[stateKey];browse.browserPath=rootFolder;browse.categoryPath=allCategory;browse.categoryPage=0;dirty_=true;
    },14);
    button(c,{104,bankTop,196,bankBottom},"USER",orange,false,true,[this]{openSavedStyleLibrary();},11);
    const bool all=state.categoryPath==allCategory;
    const auto selectedFolder=folders.find(state.categoryPath);
    const std::vector<int> slots=all?allSlots:(selectedFolder!=folders.end()?selectedFolder->second.slots:std::vector<int>{});
    const auto title=all?std::string("All Styles"):state.categoryPath;
    if(player.styleSwitchPending){
        const float middle=208+(right-208)*.47F;
        label(c,title,211,bankBottom-7,13,orange,true,middle-220);
        label(c,"Next: "+player.pendingStyleName,middle,bankBottom-7,12,blue,true,right-middle-4);
    }else label(c,title,211,bankBottom-7,15,orange,true,right-215);
    for(int tile=0;tile<12;++tile){
        const auto offset=static_cast<std::size_t>(state.categoryPage*12+tile);
        const float x=5+static_cast<float>(tile%2)*98.0F,y=tileTop+static_cast<float>(tile/2)*catStride;
        const RectF rect{x,y,x+93,y+catHeight};
        if(offset>=categories.size()){box(c,rect,panel,kBorder,2);continue;}
        const auto category=categories[offset];const bool selected=state.categoryPath==category.path;
        box(c,rect,selected?0xFFE7D58CU:panel,selected?orange:kBorder,2);
        const auto lines=wrappedKstText(category.name,83,compact?13:11);
        label(c,lines.empty()?category.name:lines.front(),x+46.5F,y+(compact?15:13),compact?13:11,selected?bg:white,true,85,Align::Center);
        if(lines.size()>1)label(c,lines[1],x+46.5F,y+(compact?29:25),compact?13:11,selected?bg:white,true,85,Align::Center);
        label(c,std::to_string(category.count)+(category.children?"  >":""),x+46.5F,y+(compact?42:36),compact?11:9,selected?bg:dim,false,85,Align::Center);
        hit(rect,[this,catalogHandle,stateKey,category]{
            if(kstCatalog_!=catalogHandle)return;
            auto& browse=styleSelectStates_[stateKey];browse.categoryPath=category.path;
            if(category.children){browse.browserPath=category.path;browse.categoryPage=0;}dirty_=true;
        });
    }
    button(c,{5,pagerTop,48,pagerBottom},"◀",orange,false,state.categoryPage>0,[this,stateKey]{--styleSelectStates_[stateKey].categoryPage;dirty_=true;},14);
    label(c,std::to_string(state.categoryPage+1)+" / "+std::to_string(categoryPages),100,(pagerTop+pagerBottom)*0.5F+4,12,dim,false,94,Align::Center);
    button(c,{153,pagerTop,196,pagerBottom},"▶",orange,false,state.categoryPage+1<categoryPages,[this,stateKey]{++styleSelectStates_[stateKey].categoryPage;dirty_=true;},14);
    auto& page=state.pages[state.categoryPath];const int pages=std::max(1,static_cast<int>((slots.size()+static_cast<std::size_t>(positions)-1U)/static_cast<std::size_t>(positions)));
    const int clampedPage=std::clamp(page,0,pages-1);
    if(page!=clampedPage){page=clampedPage;markPersistentStateChanged();}
    std::size_t visible=0,totalInCategory=0;
    for(const auto index:slots)if(index>=0&&static_cast<std::size_t>(index)<catalog.styles.size())++totalInCategory;
    for(int tile=0;tile<positions;++tile){
        const auto offset=static_cast<std::size_t>(page*positions+tile);const int row=tile%rows,col=tile/rows;
        const float x=208+static_cast<float>(col)*(tileWidth+4),y=tileTop+static_cast<float>(row)*tileStride;const RectF rect{x,y,x+tileWidth,y+tileHeight};
        if(offset>=slots.size()){box(c,rect,panel,kBorder,2);continue;}
        const int index=slots[offset];
        if(index<0||static_cast<std::size_t>(index)>=catalog.styles.size()){
            box(c,rect,panel,kBorder,2);label(c,std::to_string(offset+1),x+9,y+(compact?14:18),11,dim,false,36);
            const auto missing=selectedFolder!=folders.end()?selectedFolder->second.missingSlots.find(offset):std::map<std::size_t,std::string>::const_iterator{};
            if(selectedFolder!=folders.end()&&missing!=selectedFolder->second.missingSlots.end()){
                const auto reference=missing->second;
                label(c,"Missing file",x+49,y+(compact?16:24),compact?15:17,0xFFB58D6EU,true,tileWidth-56);label(c,reference,x+49,y+(compact?27:42),10,dim,false,tileWidth-56);
                hit(rect,[this,reference]{showStyleInfo("Saved Style position", "This saved position cannot be loaded from the SET.\n"+reference);});
            }else label(c,"Empty",x+49,y+(compact?20:29),compact?13:16,0xFF59636AU,false,tileWidth-56);
            continue;
        }
        ++visible;const auto& entry=catalog.styles[static_cast<std::size_t>(index)];const bool selected=entry.path==activePath;
        const bool queued=player.styleSwitchPending&&entry.path==player.pendingStylePath&&!selected;
        const ColorInt tileColor=selected?0xFFE7D58CU:(queued?0xFF182C39U:(entry.loadable?panel:0xFF161A1DU));
        box(c,rect,tileColor,selected?orange:(queued?blue:kBorder),2);
        const ColorInt textColor=selected?bg:(entry.loadable?white:0xFF718087U);
        const auto sourceGuitars=originalStyleGuitars(entry.originalSettings);
        const bool sourceUnread=!entry.originalSettings.indexed||!entry.originalSettings.readable;
        const bool sourceBadge=sourceGuitars.entries!=0||sourceUnread;
        const float inset=compact?9.0F:48.0F;
        const float badgeWidth=sourceBadge?(compact?57.0F:75.0F):0.0F;
        const float textWidth=tileWidth-inset-7-badgeWidth-(sourceBadge?5.0F:0.0F);
        const int originalPosition=entry.positionSlot>=0?entry.positionSlot+1:static_cast<int>(offset+1);
        if(!compact)label(c,std::to_string(originalPosition),x+9,y+15,10,selected?bg:orange,false,34);
        if(!compact)keyboard(c,x+8,y+23,31,17,entry.loadable?(selected?bg:dim):0xFF475158U);
        label(c,entry.name,x+inset,y+(compact?16:23),compact?15:17,textColor,true,textWidth);
        std::string metadata=entry.loadable?(entry.bpm>0?tempoText(entry.bpm)+" BPM  "+std::to_string(entry.numerator)+"/"+std::to_string(entry.denominator):"Style"):entry.error=="Protected Pa resource"?"Protected Style":"Unavailable — tap for details";
        if(all&&!entry.categoryPath.empty())metadata=entry.categoryPath+"  •  "+metadata;
        if(queued)metadata="NEXT BAR  •  "+metadata;
        if(compact)metadata=std::to_string(originalPosition)+"  •  "+metadata;
        label(c,metadata,x+inset,y+(compact?31:42),compact?11:11,selected?bg:(queued?blue:(entry.loadable?dim:0xFFB58D6EU)),false,textWidth);
        hit(rect,[this,catalogHandle,index,targetPlayer]{
            if(kstCatalog_!=catalogHandle||index<0||static_cast<std::size_t>(index)>=catalogHandle->styles.size())return;
            const auto& chosen=catalogHandle->styles[static_cast<std::size_t>(index)];
            if(!chosen.loadable){showStyleInfo(chosen.name,(chosen.error.empty()?"This Style could not be decoded":chosen.error)+"\n"+chosen.relativePath);return;}
            loadStyleForPlayback(targetPlayer,chosen.path);
        });
        if(sourceBadge){
            const RectF badge{rect.right-badgeWidth-3,y+3,rect.right-3,y+(compact?33:45)};
            const ColorInt ink=selected?bg:(sourceUnread||sourceGuitars.blocked?orange:green);
            box(c,badge,selected?0xFFD6C57DU:key,ink);
            label(c,sourceUnread?"SET ?":sourceGuitars.blocked?"SET GTR !":"SET GTR",badge.centerX(),y+(compact?14:19),compact?10:10,ink,true,badgeWidth-4,Align::Center);
            const auto parts=sourceUnread?std::string("Details"):
                ((sourceGuitars.tracks&7U)?originalGuitarParts(sourceGuitars.tracks):"ACC "+originalGuitarParts(sourceGuitars.tracks,true));
            label(c,parts,badge.centerX(),y+(compact?28:35),compact?10:9,ink,false,badgeWidth-4,Align::Center);
            hit(badge,[this,catalogHandle,index]{
                if(kstCatalog_!=catalogHandle||index<0||static_cast<std::size_t>(index)>=catalogHandle->styles.size())return;
                showStyleInfo("Original Style settings",originalStyleSettingsText(catalogHandle->styles[static_cast<std::size_t>(index)]));
            });
        }
    }
    if(slots.empty())label(c,catalog.styles.empty()?"No Style files found":"Select a subcategory on the left",(208+right)*.5F,246,18,dim,false,right-224,Align::Center);
    const auto categoryKey=state.categoryPath;
    button(c,{208,pagerTop,253,pagerBottom},"◀",orange,false,page>0,[this,stateKey,categoryKey]{--styleSelectStates_[stateKey].pages[categoryKey];dirty_=true;},15);
    const int firstPage=(page/8)*8;
    for(int number=0;number<8&&firstPage+number<pages;++number){
        const int targetPage=firstPage+number;const float stride=(right-47-264)/8.0F;const float x=264+static_cast<float>(number)*stride;
        button(c,{x,pagerTop,x+stride-4,pagerBottom},std::to_string(targetPage+1),orange,page==targetPage,true,[this,stateKey,categoryKey,targetPage]{styleSelectStates_[stateKey].pages[categoryKey]=targetPage;dirty_=true;},14);
    }
    button(c,{right-47,pagerTop,right,pagerBottom},"▶",orange,false,page+1<pages,[this,stateKey,categoryKey]{++styleSelectStates_[stateKey].pages[categoryKey];dirty_=true;},15);
    std::string counts=std::to_string(visible)+" shown / "+std::to_string(totalInCategory)+" in bank  •  SET "+std::to_string(catalog.styles.size())+"/"+std::to_string(catalog.discoveredStyleFiles)+"  •  Unavailable "+std::to_string(catalog.unavailableStyles);
    std::size_t missingSlots=0;for(const auto& group:catalog.styleGroups)missingSlots+=group.missingSlotFiles.size();
    if(missingSlots>0)counts+="  •  Missing slots "+std::to_string(missingSlots);
    label(c,counts,210,compact?447.0F:435.0F,12.0F,catalog.styleListComplete?dim:orange,false,right-215);
    if(compact){
        // KST already goes to the root. Show a single parent-folder action only
        // when it is needed, instead of repeating ROOT and UP on every page.
        if(state.browserPath!=rootFolder){
            const auto here=folders.find(state.browserPath);
            const auto parent=here==folders.end()?rootFolder:here->second.parent;
            button(c,{53,pagerTop,148,pagerBottom},"Up",orange,false,true,[this,stateKey,parent,rootFolder]{auto& selected=styleSelectStates_[stateKey];selected.browserPath=parent.empty()?rootFolder:parent;selected.categoryPath=(parent.empty()||parent==rootFolder)?allCategory:parent;selected.categoryPage=0;dirty_=true;},13);
            label(c,std::to_string(state.categoryPage+1)+" / "+std::to_string(categoryPages),100,447,11,dim,false,94,Align::Center);
        }
        return;
    }
    const bool canNavigate=state.browserPath!=rootFolder||state.categoryPath!=allCategory;
    button(c,{5,443,98,478},"ROOT",orange,false,canNavigate,[this,stateKey,rootFolder]{auto& selected=styleSelectStates_[stateKey];selected.browserPath=rootFolder;selected.categoryPath=allCategory;selected.categoryPage=0;dirty_=true;},14);
    const auto navigationFolder=folders.find(all?state.browserPath:state.categoryPath);
    const auto parent=navigationFolder!=folders.end()?navigationFolder->second.parent:rootFolder;
    button(c,{104,443,196,478},"UP",orange,false,canNavigate,[this,stateKey,parent,rootFolder]{auto& selected=styleSelectStates_[stateKey];selected.browserPath=parent.empty()?rootFolder:parent;selected.categoryPath=(parent.empty()||parent==rootFolder)?allCategory:parent;selected.categoryPage=0;dirty_=true;},14);
    const auto breadcrumb="Files: "+catalog.name+" / "+(all?std::string("All Styles"):state.categoryPath);
    box(c,{208,443,796,478},panel,kBorder,2);label(c,breadcrumb,216,465,12,dim,false,552);label(c,"›",781,466,19,orange,true,20,Align::Center);
    const auto fileDirectory=files::join(catalog.rootPath,all?rootFolder:state.categoryPath);
    hit({208,443,796,478},[this,catalogHandle,fileDirectory,targetPlayer]{if(kstCatalog_!=catalogHandle)return;pickerDirectory_=fileDirectory;bankSoundsOnly_=true;openPicker(Picker::Style,targetPlayer);});
}

void ArrangerView::drawCompactKstSelectorHeader(Canvas& c){
    const bool styles=kstCatalogTab_==0;
    const auto& catalog=*kstCatalog_;
    if(kstCatalogTab_==1){
        button(c,{4,3,93,39},"‹ Back",green,false,true,[this]{panelExit();},16);
        const auto target=targetTrack_>=0&&soundPlayer_>=0?players_[soundPlayer_].tracks[targetTrack_].name:arrangerKeyboardPartName(targetPart_);
        label(c,"SOUNDS  /  "+target,105,27,18,green,true,displayWidth_-330);
        button(c,{displayWidth_-186,3,displayWidth_-105,39},"Inspect",green,false,true,[this]{openInspector(Picker::SetSounds);},14);
        button(c,{displayWidth_-98,3,displayWidth_-4,39},"Load SET",green,false,true,[this]{openPicker(Picker::KstFolder);},14);
        return;
    }
    button(c,{4,3,93,39},"‹ Back",orange,false,true,[this]{panelExit();},16);
    button(c,{98,3,346,39},"Styles  "+std::to_string(catalog.styles.size()),orange,styles,true,[this]{
        if(kstCatalogTab_==0)return;
        targetKbdSet_=-1;targetKbdPlayer_=-1;targetKbdSerial_=0;targetTrack_=-1;targetPart_=0;
        styleSelectorPlayer_=styleSelectorPlayer();
        kstCatalogTab_=0;kstCatalogPage_=0;dirty_=true;
    },17);
    const std::string keyboardLabel=catalogUsesPerformances(catalog)?"Performances  ":"Keyboard Sets  ";
    button(c,{351,3,639,39},keyboardLabel+std::to_string(catalog.keyboardSets.size()),green,!styles,true,[this]{
        if(kstCatalogTab_==2)return;
        targetKbdSet_=-1;targetKbdPlayer_=-1;targetKbdSerial_=0;targetTrack_=-1;targetPart_=0;
        kstCatalogTab_=2;kstCatalogPage_=0;dirty_=true;
    },17);
    if(styles)button(c,{644,3,displayWidth_-4,39},"Player "+std::to_string(styleSelectorPlayer()+1),orange,false,true,[this]{
        styleSelectorPlayer_=1-styleSelectorPlayer();styleSelectStates_[{kstCatalog_->rootPath,styleSelectorPlayer_}].locateActive=true;dirty_=true;
    },15);
    else label(c,targetKbdSet_>=0?"Position "+std::to_string(targetKbdSet_+1):"Live select",(640+displayWidth_)*.5F,27,14,dim,true,displayWidth_-650,Align::Center);
}
void ArrangerView::drawKstCatalog(Canvas& c){
    if(compactKstSelector()){
        if(kstCatalogTab_==0){drawCompactKstSelectorHeader(c);drawKstStyleSelect(c);}
        else drawKstKeyboardSelect(c);
        return;
    }
    if(kstCatalog_&&(kstCatalogTab_==1||kstCatalogTab_==2)){drawKstKeyboardSelect(c);return;}
    button(c,{3,3,96,35},"‹ Back",orange,false,true,[this]{panelExit();},16);
    if(!kstCatalog_){label(c,"Choose a Pa .SET or .KST folder to see its Styles and Sounds",400,210,21,dim,false,740,Align::Center);button(c,{225,250,575,300},"Load Pa SET / KST",orange,false,true,[this]{openPicker(Picker::KstFolder);},20);return;}
    const auto& catalog=*kstCatalog_;
    label(c,kstCatalogTab_==0?"STYLE SELECT":(catalog.name.empty()?"Pa SET Catalog":catalog.name),113,26,18,orange,true,405);
    if(kstCatalogTab_==0)button(c,{526,3,670,35},"Player "+std::to_string(styleSelectorPlayer()+1),orange,false,true,[this]{styleSelectorPlayer_=1-styleSelectorPlayer();styleSelectStates_[{kstCatalog_->rootPath,styleSelectorPlayer_}].locateActive=true;dirty_=true;},14);
    else label(c,"Player "+std::to_string(selectedPlayer_+1),598,27,14,dim,true,144,Align::Center);
    button(c,{681,3,796,35},"Sample Info",orange,false,kstReport_!=nullptr,[this]{openInspector(Picker::SetInfo);},13);
    const std::array<std::string,4> tabs{{"Styles "+std::to_string(catalog.styles.size()),"Sounds "+std::to_string(catalog.sounds.size()),(catalogUsesPerformances(catalog)?"Performances ":"Keyboard Sets ")+std::to_string(catalog.keyboardSets.size()),"Samples "+std::to_string(catalog.samples.size())}};
    for(int i=0;i<4;++i){const float x=8+static_cast<float>(i)*198.0F;button(c,{x,44,x+192,80},tabs[static_cast<std::size_t>(i)],i==0?orange:green,kstCatalogTab_==i,true,[this,i]{if(i==0&&kstCatalogTab_!=0&&kstCatalog_){styleSelectorPlayer_=selectedPlayer_;styleSelectStates_[{kstCatalog_->rootPath,styleSelectorPlayer()}].locateActive=true;}kstCatalogTab_=i;kstCatalogPage_=0;dirty_=true;},14);}
    if(kstCatalogTab_==0){drawKstStyleSelect(c);return;}
    drawSampleFilters(c,false,82);
    const auto count=catalogSampleRows_.size();
    const int pages=std::max(1,static_cast<int>((count+5U)/6U));kstCatalogPage_=std::clamp(kstCatalogPage_,0,pages-1);
    for(int row=0;row<6;++row){
        const auto at=static_cast<std::size_t>(kstCatalogPage_*6+row);if(at>=count)break;
        const auto index=catalogSampleRows_[at];
        const float y=121+static_cast<float>(row)*45.0F;const RectF rect{12,y,788,y+42};box(c,rect,panel,kBorder,2);
        const auto& entry=catalog.samples[index];const auto& name=entry.name;
        const auto found=sampleClasses_.find(entry.resourceId);const unsigned use=found==sampleClasses_.end()?0:found->second;
        std::string metadata=std::string(use==3?"Drum + melodic":use==1?"Drum Sample":use==2?"Melodic":"Unclassified")+"   "+std::to_string(entry.rate)+" Hz   "+std::to_string(entry.frames)+" frames   "+(entry.previewable?"Audition waveform":"Unavailable");
        const auto color=entry.previewable?white:orange;
            hit(rect,[this,index]{if(!kstCatalog_||index>=kstCatalog_->samples.size())return;const auto& selected=kstCatalog_->samples[index];if(!selected.previewable){showStyleInfo("Sample unavailable",selected.blocker);return;}kstSampleIndex_=static_cast<int>(index);host::arrangerHost().stopPcmPreview();if(!host::arrangerHost().loadPcmPreview(selected.pcmPath,selected.kmpPath,selected.resourceId)){showStyleInfo("Sample could not be decoded",host::arrangerHost().pcmPreview().error);return;}rememberNavigation();picker_=Picker::KstSample;dirty_=true;});
        label(c,name,24,y+19,17,color,true,750);label(c,metadata,24,y+36,12,dim,false,750);
    }
    if(count==0)label(c,"No samples in this category",400,238,18,dim,false,745,Align::Center);
    inspectorPager(c,kstCatalogPage_,static_cast<int>(count),6);
}
const arranger::Pa5xStyleSourceSettings& ArrangerView::originalStyleSettings(
        const std::shared_ptr<const arranger::Pa5xStyleRead>& read){
    if(!read){styleSourceOwner_.reset();styleSourceSettings_={};}
    else if(styleSourceOwner_.lock()!=read){
        styleSourceSettings_=arranger::summarizePa5xStyleSourceSettings(*read);
        styleSourceOwner_=read;
    }
    return styleSourceSettings_;
}
void ArrangerView::openStyleRead(int player){
    const int requestedPlayer=std::clamp(player,0,1);
    const auto read=host::arrangerHost().styleRead(requestedPlayer);
    if(!read||!read->valid){
        const auto& p=players_[static_cast<std::size_t>(requestedPlayer)];
        showStyleInfo("Style contents",read&&!read->error.empty()?read->error:
            (p.loaded?p.name+"\nOriginal tempo: "+tempoText(p.originalBpm)+" BPM\nMeter: "+std::to_string(p.numerator)+"/"+std::to_string(p.denominator)+"\n"+p.playbackWarning:"Load a Style to read its contents"));
        return;
    }
    styleReadPlayer_=requestedPlayer;
    if(picker_!=Picker::StyleRead){rememberNavigation();contentsReturn_=picker_;}
    styleReadElement_=std::clamp(players_[static_cast<std::size_t>(styleReadPlayer_)].element,0,static_cast<int>(arranger::kElementCount)-1);
    if(!read->sections[static_cast<std::size_t>(styleReadElement_)].available)
        for(std::size_t section=0;section<read->sections.size();++section)if(read->sections[section].available){styleReadElement_=static_cast<int>(section);break;}
    for(std::size_t track=0;track<styleReadCvs_.size();++track){
        const auto& cvs=read->sections[static_cast<std::size_t>(styleReadElement_)].tracks[track].cvs;
        int selected=std::clamp(players_[static_cast<std::size_t>(styleReadPlayer_)].tracks[track].selectedCv-1,0,5);
        if(!cvs[static_cast<std::size_t>(selected)].available)
            for(std::size_t cv=0;cv<cvs.size();++cv)if(cvs[cv].available){selected=static_cast<int>(cv);break;}
        styleReadCvs_[track]=selected;
    }
    picker_=Picker::StyleRead;editor_=false;dirty_=true;
}
void ArrangerView::drawStyleRead(Canvas& c){
    button(c,{3,3,96,35},"‹ Back",orange,false,true,[this]{panelExit();},16);
    const auto read=host::arrangerHost().styleRead(styleReadPlayer_);
    if(!read||!read->valid){label(c,"Style contents are unavailable",400,220,22,orange,false,750,Align::Center);return;}
    const auto& p=players_[static_cast<std::size_t>(styleReadPlayer_)];
    const auto sectionIndex=static_cast<std::size_t>(std::clamp(styleReadElement_,0,static_cast<int>(arranger::kElementCount)-1));
    const auto& section=read->sections[sectionIndex];
    const auto& sourceSettings=originalStyleSettings(read);
    label(c,"Style contents: "+read->name,113,26,18,orange,true,530);
    button(c,{655,3,796,35},"Player "+std::to_string(styleReadPlayer_+1),orange,false,true,[this]{openStyleRead(1-styleReadPlayer_);},14);
    const auto moveSection=[this,read](int direction){
        int next=styleReadElement_;
        for(std::size_t attempt=0;attempt<read->sections.size();++attempt){
            next=(next+direction+static_cast<int>(read->sections.size()))%static_cast<int>(read->sections.size());
            if(read->sections[static_cast<std::size_t>(next)].available){styleReadElement_=next;break;}
        }
        for(std::size_t track=0;track<styleReadCvs_.size();++track){
            const auto& cvs=read->sections[static_cast<std::size_t>(styleReadElement_)].tracks[track].cvs;
            if(!cvs[static_cast<std::size_t>(styleReadCvs_[track])].available)
                for(std::size_t cv=0;cv<cvs.size();++cv)if(cvs[cv].available){styleReadCvs_[track]=static_cast<int>(cv);break;}
        }
        dirty_=true;
    };
    button(c,{12,45,70,79},"◀",orange,false,true,[moveSection]{moveSection(-1);},17);
    label(c,elementNames[sectionIndex],255,69,19,white,true,350,Align::Center);
    button(c,{439,45,497,79},"▶",orange,false,true,[moveSection]{moveSection(1);},17);
    label(c,"CV for all:",512,66,12,dim,false,80);
    for(int cv=0;cv<6;++cv){const float x=589.0F+static_cast<float>(cv)*33.0F;button(c,{x,45,x+30,79},std::to_string(cv+1),green,false,true,[this,cv]{styleReadCvs_.fill(cv);dirty_=true;},13);}
    const std::string sectionMeter=section.meterKnown?std::to_string(section.numerator)+"/"+std::to_string(section.denominator):"Unknown";
    label(c,(read->originalBpm>0?"Original "+tempoText(read->originalBpm)+" BPM":"Original tempo unknown")+"   •   "+sectionMeter+"   •   Player "+tempoText(p.bpm)+" BPM"+(p.tempoLock?" (Tempo Lock)":""),16,103,15,green,false,770);
    label(c,"Track / CV",18,125,12,dim,false,120);label(c,"Sound at CV start / MSB / LSB / Program",150,125,12,dim,false,415);label(c,"Player assignment",592,125,12,dim,false,190);
    for(std::size_t track=0;track<8;++track){
        const float y=132.0F+static_cast<float>(track)*34.0F;box(c,{12,y,788,y+32},panel,kBorder);
        const auto& source=section.tracks[track];const auto cvIndex=static_cast<std::size_t>(std::clamp(styleReadCvs_[track],0,5));const auto& cv=source.cvs[cvIndex];
        const auto& assigned=p.tracks[track];
        const auto* sourceSettingsTrack=originalStyleTrack(sourceSettings,static_cast<int>(sectionIndex),static_cast<int>(track));
        label(c,assigned.name,20,y+14,12,source.present?white:dim,true,66);
        const bool sourceGuitar=sourceSettingsTrack&&sourceSettingsTrack->declaredType=="Guitar";
        const bool blockedGuitar=sourceGuitar&&(!sourceSettingsTrack->available||sourceSettingsTrack->nativeMode!=arranger::NativePatternMode::Guitar);
        const auto type=sourceGuitar?(blockedGuitar?std::string("GTR blocked"):std::string("SET GTR")):
            !sourceSettingsTrack?std::string("Type unread"):
            sourceSettingsTrack->declaredType=="Accompaniment"?std::string("SET ACC"):sourceSettingsTrack->declaredType;
        label(c,source.present?type:"Absent",20,y+28,9,blockedGuitar?orange:sourceGuitar?green:dim,false,66);
        button(c,{88,y+2,139,y+30},"CV"+std::to_string(cvIndex+1),green,false,source.present,[this,track,read,sectionIndex]{
            const auto& cvs=read->sections[sectionIndex].tracks[track].cvs;
            for(int next=1;next<=6;++next){const int value=(styleReadCvs_[track]+next)%6;if(cvs[static_cast<std::size_t>(value)].available){styleReadCvs_[track]=value;break;}}dirty_=true;
        },12);
        const auto* sound=initialCvSound(*read,cv,track);
        const bool multiple=multipleInitialCvSounds(cv);
        const std::string name=!source.present?"Track absent":(!cv.available?"CV unavailable":(multiple?"Multiple initial Sounds — tap for channels":(sound?(sound->sound.name.empty()?"Name unresolved":sound->sound.name):"No Sound address at CV start")));
        const auto color=sound&&sound->sound.resolution==arranger::KstResolution::ExactUserSound?white:orange;
        label(c,name,150,y+14,14,source.present&&cv.available?color:dim,true,427);
        std::string address=multiple?"Different original addresses across MIDI channels":(sound?originalAddress(sound->msb,sound->lsb,sound->program):"— / — / —");
        if(sound&&!multiple)address+="   ch "+std::to_string(sound->channel+1U);
        if(cv.soundChanges.size()>1)address+="   "+std::to_string(cv.soundChanges.size())+" changes";
        label(c,address,150,y+28,11,dim,false,427);
        label(c,assigned.assigned?(assigned.playbackBlocked?"Assigned / blocked":"Assigned"):"Unassigned",592,y+14,12,assigned.assigned&&!assigned.playbackBlocked?green:dim,true,185);
        label(c,assigned.assigned?assigned.soundName:"Audio not activated",592,y+28,11,dim,false,185);
        hit({145,y,582,y+32},[this,read,sectionIndex,track,cvIndex,selection=p.styleSelectionSerial,player=styleReadPlayer_]{
            const auto& sourceTrack=read->sections[sectionIndex].tracks[track];const auto& sourceCv=sourceTrack.cvs[cvIndex];
            std::string detail=read->name+" / "+elementNames[sectionIndex]+" / "+players_[static_cast<std::size_t>(styleReadPlayer_)].tracks[track].name+" / CV"+std::to_string(cvIndex+1);
            const auto& original=originalStyleSettings(read);
            if(const auto* settings=originalStyleTrack(original,static_cast<int>(sectionIndex),static_cast<int>(track)))
                detail+="\n\n"+originalStyleTrackText(*settings,false);
            else detail+="\n\nOriginal track settings: unreadable / unavailable";
            const auto effective=host::arrangerHost().styleGuitar(player,selection,static_cast<int>(sectionIndex),static_cast<int>(track));
            if(effective.available)detail+=std::string("\nPlayer mode: ")+(effective.guitar?"GTR":"ACC")+
                (effective.overrides.mode<0?" (Auto from SET)":" (manual override)");
            detail+="\nOriginal source chord: "+(sourceCv.sourceRoot.empty()?"—":sourceCv.sourceRoot)+" "+sourceCv.sourceChord;
            detail+="\nCV length: "+std::to_string(sourceCv.lengthTicks)+" ticks / PPQ "+std::to_string(sourceTrack.ppq);
            for(const auto& tempo:sourceCv.tempoChanges)detail+="\nTempo @tick "+std::to_string(tempo.tick)+": "+tempoText(tempo.bpm)+" BPM";
            for(const auto& meter:sourceCv.timeSignatureChanges)detail+="\nMeter @tick "+std::to_string(meter.tick)+": "+std::to_string(meter.numerator)+"/"+std::to_string(meter.denominator);
            detail+="\n\nOriginal Sound changes in this CV:";
            if(sourceCv.soundChanges.empty())detail+="\nNo committed Sound address was decoded";
            for(const auto& change:sourceCv.soundChanges)detail+="\n\n"+soundChangeText(change);
            if(!sourceTrack.setupSoundChanges.empty()){detail+="\n\nSetup Sound changes:";for(const auto& change:sourceTrack.setupSoundChanges)detail+="\n\n"+soundChangeText(change);}
            for(const auto& tempo:sourceTrack.setupTempoChanges)detail+="\nSetup tempo @tick "+std::to_string(tempo.tick)+": "+tempoText(tempo.bpm)+" BPM";
            for(const auto& meter:sourceTrack.setupTimeSignatureChanges)detail+="\nSetup meter @tick "+std::to_string(meter.tick)+": "+std::to_string(meter.numerator)+"/"+std::to_string(meter.denominator);
            detail+="\n\nPlayer audio assignment: "+players_[static_cast<std::size_t>(styleReadPlayer_)].tracks[track].soundName;
            showStyleInfo("Original Style track settings",detail);
        });
    }
    label(c,p.soundAssignmentsReady?"Player assignments ready":"Style read; original Sound playback is not activated",16,428,13,p.soundAssignmentsReady?green:dim,false,770);
    button(c,{12,443,193,478},"Player Mixer",orange,false,true,[this]{setPlayerFocus(styleReadPlayer_);navigationHistory_.clear();panelMode_=PanelMode::Home;picker_=Picker::None;tab_=Tab::Mixer;dirty_=true;},14);
    button(c,{204,443,385,478},"Read messages ("+std::to_string(read->warnings.size())+")",orange,false,true,[this,read]{std::string text=read->sourcePath;for(const auto& message:read->warnings)text+="\n\n"+message;const auto& playbackMessage=players_[static_cast<std::size_t>(styleReadPlayer_)].playbackWarning;if(!playbackMessage.empty())text+="\n\nPlayback: "+playbackMessage;showStyleInfo("Style read status",text);},13);
    label(c,"Tap a Sound for its changes; CV buttons inspect data",400,466,12,dim,false,385);
}
void ArrangerView::openKeyboardSetRead(const std::string& path){
    if(!host::arrangerHost().readKeyboardSet(path)){showStyleInfo("Keyboard Set read failed",host::arrangerHost().lastError());return;}
    keyboardSetContents_=host::arrangerHost().keyboardSetRead();
    if(!keyboardSetContents_){showStyleInfo("Keyboard Set read failed","No Keyboard Set contents were returned");return;}
    if(picker_!=Picker::KeyboardSetRead){rememberNavigation();contentsReturn_=picker_;}
    picker_=Picker::KeyboardSetRead;editor_=false;dirty_=true;
}
void ArrangerView::drawKeyboardSetRead(Canvas& c){
    button(c,{3,3,96,35},"‹ Back",green,false,true,[this]{panelExit();},16);
    if(!keyboardSetContents_){label(c,"Select a Keyboard Set to read its contents",400,220,20,dim,false,750,Align::Center);return;}
    const auto read=keyboardSetContents_;
    label(c,"Keyboard Set contents: "+read->name,113,26,18,green,true,675);
    const std::string split=read->splitPoint<0?"Unknown":arrangerNoteName(read->splitPoint);
    label(c,"Saved Split "+split+"   •   Use Global Split "+flagValue(read->useGlobalSplit)+"   •   Upper Octave "+(read->upperOctaveTransposeKnown?signedNumber(read->upperOctaveTranspose):"Unknown"),18,64,15,white,false,764);
    label(c,read->readComplete?"Original part settings and Sound addresses read":"Some part settings or Sound addresses are unresolved",18,91,14,read->readComplete?green:orange,false,764);
    for(std::size_t index=0;index<read->parts.size();++index){
        const auto& part=read->parts[index];const float y=106.0F+static_cast<float>(index)*79.0F;box(c,{12,y,788,y+76},panel,kBorder,2);
        const std::string sound=part.soundName.empty()?(part.present?"Name unresolved":"Part absent"):part.soundName;
        label(c,std::string(keyboardRole(part.role))+"   "+sound,24,y+19,17,part.present?white:dim,true,750);
        label(c,"MSB / LSB / Program: "+originalAddress(part.msb,part.lsb,part.program)+"   •   ch "+(part.channel<0?"—":std::to_string(part.channel+1))+"   •   "+arranger::pa5xKeyboardSetSoundStatusName(part.status),24,y+37,12,part.addressKnown?green:orange,false,750);
        label(c,"Volume "+rawValue(part.volumeRaw)+"   •   Pan "+rawValue(part.panRaw)+"   •   Expression "+rawValue(part.expressionRaw)+"   •   Mute "+flagValue(part.mute),24,y+53,12,dim,false,750);
        label(c,"Keys "+keyRange(part.keyLow,part.keyHigh)+"   •   Velocity "+rawValue(part.velocityLow)+" – "+rawValue(part.velocityHigh)+"   •   Octave "+(part.octaveTransposeKnown?signedNumber(part.octaveTranspose):"Unknown"),24,y+69,12,dim,false,750);
        hit({12,y,788,y+76},[this,read,index]{const auto& source=read->parts[index];std::string detail=std::string(keyboardRole(source.role))+" / "+source.name+"\n"+source.resourcePath+"\n"+source.soundName+"\nMSB / LSB / Program: "+originalAddress(source.msb,source.lsb,source.program)+"\n"+arranger::pa5xKeyboardSetSoundStatusName(source.status)+"\n"+source.soundMessage+"\n"+source.soundPath+"\nSetup read through tick "+std::to_string(source.setupLastTick);if(source.partTranspositionDeclared)detail+="\nSaved part transposition (raw): "+std::to_string(source.partTranspositionRaw);
            if(source.sourceNativeTrack){const auto& native=*source.sourceNativeTrack;
                detail+="\n\nNative Pa track settings";
                if(!native.structurallyValid)detail+="\n"+native.error;
                else {
                    detail+="\nDetune: "+(native.detuneKnown?std::to_string(native.detuneCents)+" cents":"Unknown");
                    detail+="\nTrack octave: "+(native.octaveTransposeKnown?signedNumber(native.octaveTranspose):"Unknown");
                    detail+="\nPitch Bend: "+rawValue(native.pitchBendRangeSemitones)+" semitones";
                    detail+="\nMaster FX sends 1 / 2: "+rawValue(native.masterFxSendRaw[0])+" / "+rawValue(native.masterFxSendRaw[1]);
                    detail+="\nMixer EQ low / mid / high (dB): ";
                    for(unsigned band=0;band<3U;++band){if(band)detail+=" / ";
                        detail+=(native.eqGainKnownMask&(1U<<band))?std::to_string(native.eqGainHalfDb[band]*.5F):"Unknown";}
                    detail+="\nMixer EQ bypass and Dry polarity are retained without applying an unverified switch.";
                }
            }
            for(const auto& issue:source.issues)detail+="\n\n"+issue;showStyleInfo("Keyboard Set part",detail);});
    }
    label(c,activeNativeKeyboardSetPath_==read->sourcePath?"Selected Keyboard Set — available User Sounds are active":"Select this Keyboard Set to apply available User Sounds",16,438,12,dim,false,770);
    button(c,{12,446,211,478},"Keyboard Set Library",green,false,true,[this]{
        if(!navigationHistory_.empty()&&selectorFamily(navigationHistory_.back().picker,navigationHistory_.back().catalogTab)==2)panelExit();
        else openKstCatalog(2);
    },13);
    button(c,{222,446,411,478},"Read messages",green,false,true,[this,read]{std::string text=read->sourcePath;if(!read->error.empty())text+="\n\n"+read->error;for(const auto& issue:read->issues)text+="\n\n"+issue;showStyleInfo("Keyboard Set read status",text);},13);
    button(c,{422,446,788,478},"Select Keyboard Set",green,false,true,[this,read]{activateNativeKeyboardSet(read->sourcePath,targetKbdSet_);},13);
}
void ArrangerView::drawKstSample(Canvas& c){
    button(c,{3,3,96,35},"‹ Back",green,false,true,[this]{panelExit();},16);
    const auto preview=host::arrangerHost().pcmPreview();
    label(c,"PCM waveform audition",113,26,19,green,true,670);
    box(c,{20,56,780,277},panel,kBorder,3);label(c,preview.name,40,91,25,white,true,720);
    label(c,std::to_string(preview.sampleRate)+" Hz     "+std::to_string(preview.frames)+" frames     Root "+(preview.rootKey<0?std::string("Unknown"):arrangerNoteName(preview.rootKey)),40,132,18,dim,false,720);
    label(c,"This auditions one decoded waveform, not the complete Korg Sound.",40,174,16,orange,false,720);
    if(!preview.error.empty())label(c,preview.error,40,217,15,orange,false,720);
    button(c,{102,303,379,361},"Play sample",green,false,preview.ready,[this]{if(!host::arrangerHost().playPcmPreview())showStyleInfo("Sample playback failed",host::arrangerHost().pcmPreview().error);dirty_=true;},23);
    button(c,{421,303,698,361},"Stop",orange,false,true,[this]{host::arrangerHost().stopPcmPreview();dirty_=true;},23);
    if(targetTrack_>=0&&targetTrack_<8)button(c,{102,388,698,436},"Assign raw sample: Player "+std::to_string(selectedPlayer_+1)+" / "+players_[static_cast<std::size_t>(selectedPlayer_)].tracks[static_cast<std::size_t>(targetTrack_)].name+" (session)",green,false,preview.ready,[this]{if(!host::arrangerHost().assignPcmPreview(selectedPlayer_,targetTrack_))showStyleInfo("Sample assignment failed",host::arrangerHost().pcmPreview().error);else{refresh();showToast("Temporary raw PCM assignment — not the original Korg Sound",5000);}dirty_=true;},16);
    else label(c,"Choose a Style track in Mixer before assigning a preview sample.",400,418,16,dim,false,750,Align::Center);
}

void ArrangerView::showStyleInfo(const std::string& title,const std::string& text){
    performanceDiagnosticsInfo_=false;
    if(picker_!=Picker::StyleInfo){rememberNavigation();styleInfoReturn_=picker_;}
    styleInfoTitle_=title;styleInfoText_=text;styleInfoPage_=0;picker_=Picker::StyleInfo;dirty_=true;
}
void ArrangerView::drawStyleInfo(Canvas& c){
    button(c,{3,3,96,35},"‹ Back",orange,false,true,[this]{panelExit();},16);
    label(c,styleInfoTitle_,113,26,18,orange,true,performanceDiagnosticsInfo_?310.0F:670.0F);
    if(performanceDiagnosticsInfo_){
        button(c,{432,3,536,35},"Reset",orange,false,true,[this]{resetPerformanceDiagnostics();},12);
        button(c,{544,3,658,35},"Refresh",green,false,true,[this]{showPerformanceDiagnostics();},14);
        button(c,{666,3,788,35},"Save Report",green,false,true,[this]{exportPerformanceDiagnostics();},13);
    }
    box(c,{16,48,784,430},panel,kBorder,2);
    const auto lines=wrappedKstText(styleInfoText_,738.0F,14.0F);
    constexpr int perPage=20;
    const int pages=std::max(1,(static_cast<int>(lines.size())+perPage-1)/perPage);
    styleInfoPage_=std::clamp(styleInfoPage_,0,pages-1);
    for(int row=0;row<perPage;++row){
        const auto index=static_cast<std::size_t>(styleInfoPage_*perPage+row);
        if(index>=lines.size())break;
        label(c,lines[index],30,76.0F+static_cast<float>(row)*18.0F,14,white,false,738);
    }
    button(c,{16,441,106,477},"◀",orange,false,styleInfoPage_>0,[this]{--styleInfoPage_;dirty_=true;},18);
    label(c,std::to_string(styleInfoPage_+1)+" / "+std::to_string(pages),400,466,17,white,true,550,Align::Center);
    button(c,{694,441,784,477},"▶",orange,false,styleInfoPage_+1<pages,[this]{++styleInfoPage_;dirty_=true;},18);
}

void ArrangerView::chooseKstKeyboardSound(std::size_t index){
                if(!kstCatalog_||index>=kstCatalog_->sounds.size())return;
                const auto selected=kstCatalog_->sounds[index];
                const auto program=host::arrangerHost().preparedKeyboardSound(selected.msb,selected.lsb,selected.program,selected.path);
                if(!program){showStyleInfo(selected.name,"No prepared User samples are available for this original Sound.\n"+selected.relativePath+"\n"+selected.blocker);return;}
                if(targetTrack_>=0){
                    auto& arranger=host::arrangerHost();
                    const int address=(selected.msb<<16)|(selected.lsb<<8)|selected.program;
                    if(!arranger.assignSound(soundPlayer_,targetTrack_,0,program,soundSerial_,address,kstCatalog_->rootPath)){
                        showToast(arranger.lastError(),6000);return;
                    }
                    finishSoundSelection();return;
                }
                if(targetPart_<0||targetPart_>=7||!ctrl_.engine.nativeAssignPreparedKeyboardSound(targetPart_,program)){showToast(ctrl_.engine.nativeLastTextError(),6500);return;}
                auto& binding=keyboardSoundBindings_[static_cast<std::size_t>(targetPart_)];
                binding.msb=selected.msb;binding.lsb=selected.lsb;binding.program=selected.program;binding.sourcePath=selected.path;
                (void)host::arrangerHost().retainPreparedKeyboardSound(targetPart_,binding.msb,binding.lsb,binding.program,binding.sourcePath);
                normalizeKeyboardPartRange(targetPart_);
                keyboardMetadataRestorePending_=false;
                persistentSaveAllowed_=true;persistentRecordProtected_=false;markPersistentStateChanged();
                finishSoundSelection();
}

#include "ArrangerHomePanels.inc"
#include "ArrangerLiveView.inc"
#include "ArrangerLiveSelector.inc"
#include "ArrangerNavigation.inc"
#include "ArrangerTempoWheel.inc"
#include "ArrangerGlobal.inc"
#include "ArrangerSettings.inc"
#include "ArrangerKeyboardSession.inc"
#include "ArrangerKeyboardSaved.inc"
#include "ArrangerKeyboardSourceOverwrite.inc"
#include "ArrangerKeyboardNativeOverwrite.inc"
#include "ArrangerKeyboardRecall.inc"
#include "ArrangerStyleKeyboardTiming.inc"
#include "ArrangerFxCatalog.inc"
#include "ArrangerOriginalSound.inc"
#include "ArrangerKeyboardPages.inc"
#include "ArrangerStyleControls.inc"
#include "ArrangerSavePages.inc"
#include "ArrangerKeyboardSelect.inc"
#include "ArrangerLiveSounds.inc"
#include "ArrangerPerformanceDiagnostics.inc"
#include "ArrangerMedia.inc"
#include "ArrangerSetInspector.inc"

} // namespace silveton::ui
