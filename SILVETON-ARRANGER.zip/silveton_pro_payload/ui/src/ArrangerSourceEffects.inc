// Original source rack inspection inside drawKeyboardEdit(). Native controls
// are offered only after the explicit whole-owner SILVETON FX switch.
const auto& sourceFx=*snapshot->sourceEffects;
label(c,insert?"SET · Original Insert FX":"SET · Original Master FX",16,111,18,green,true,318);
button(c,{350,88,508,123},"Pa5X FX · групи",green,false,true,[this]{openPa5xFxCatalog();},12);
button(c,{520,88,695,123},"SILVETON FX",orange,false,true,manualFx,12);
unsigned sourceRead=0,sourcePartial=0,sourcePlaying=0;
for(const auto& slot:sourceFx.slots){
    if(slot.parameterBlockValid&&slot.parametersComplete)++sourceRead;
    else if(sourceFxKnownParameterCount(slot))++sourcePartial;
    if(slot.status==sampler::SourceFxStatus::Applied)++sourcePlaying;
}
label(c,"SET FX: "+std::to_string(sourceFx.slots.size())+" · Разчетени: "+std::to_string(sourceRead)+
    " · Частично: "+std::to_string(sourcePartial)+" · Работят: "+std::to_string(sourcePlaying),15,138,12,dim,false,680);
std::vector<const sampler::SourceFxSlotStatus*> sourceRows;
for(const auto& slot:sourceFx.slots){
    if(insert?!slot.master&&(slot.part==focused||slot.part<0):slot.master&&(slot.slot==unit||slot.slot<0))
        sourceRows.push_back(&slot);
}
constexpr int rowsPerPage=5;
const int sourcePages=std::max(1,(static_cast<int>(sourceRows.size())+rowsPerPage-1)/rowsPerPage);
keyboardSourceFxPage_=std::clamp(keyboardSourceFxPage_,0,sourcePages-1);
for(int row=0;row<rowsPerPage;++row){
    const int index=keyboardSourceFxPage_*rowsPerPage+row;
    if(index>=static_cast<int>(sourceRows.size()))break;
    const auto& slot=*sourceRows[static_cast<std::size_t>(index)];
    const float y=148.0F+row*40.0F;
    box(c,{12,y,695,y+36},panel,kBorder);
    const char* status=sourceFxPlaybackStatus(slot);
    const ColorInt color=slot.status==sampler::SourceFxStatus::Applied?green:
        slot.status==sampler::SourceFxStatus::Off?dim:orange;
    std::string title=(slot.master?"MFX ":"IFX ")+std::to_string(slot.slot+1)+" · Korg "+std::to_string(slot.selector);
    if(!slot.name.empty())title+=" · "+slot.name;
    label(c,title,19,y+15,12,white,true,466);
    label(c,status,687,y+15,11,color,true,195,Align::Right);
    label(c,sourceFxParameterStatus(slot)+" · стойности: "+std::to_string(sourceFxKnownParameterCount(slot))+
        " · докосни за преглед",19,y+30,10,dim,false,668);
    std::string context=styleTarget?"Player "+std::to_string(trackEditPlayer_+1)+" · Style":"Keyboard Set";
    if(!snapshot->name.empty())context+=" · "+snapshot->name;
    if(!slot.master&&slot.part>=0)context+=" · "+(styleTarget?"Track "+std::to_string(slot.part+1):arrangerKeyboardPartName(slot.part));
    hit({12,y,695,y+36},[this,sourceSlot=slot,context=std::move(context),styleTarget]{
        openOriginalSourceFxEditor(sourceSlot,context,styleTarget);
    });
}
if(sourceRows.empty())label(c,insert?"Няма записан оригинален IFX за тази партия":"Няма записан оригинален MFX в този слот",353,218,16,dim,false,665,Align::Center);
if(sourcePages>1){
    button(c,{12,352,80,379},"‹",green,false,keyboardSourceFxPage_>0,[this]{--keyboardSourceFxPage_;dirty_=true;},17);
    label(c,std::to_string(keyboardSourceFxPage_+1)+" / "+std::to_string(sourcePages),128,372,12,dim,false,86,Align::Center);
    button(c,{176,352,244,379},"›",green,false,keyboardSourceFxPage_+1<sourcePages,[this]{++keyboardSourceFxPage_;dirty_=true;},17);
}
if(!sourceFx.note.empty()){
    label(c,sourceFx.note,sourcePages>1?255:15,371,11,dim,false,sourcePages>1?440:680);
    hit({sourcePages>1?251.0F:12.0F,351,695,380},[this,note=sourceFx.note]{showToast(note,9000);});
}
label(c,"Разчитане и звук са отделни статуси · Save пази оригиналните SET настройки",14,396,11,dim,false,685);
