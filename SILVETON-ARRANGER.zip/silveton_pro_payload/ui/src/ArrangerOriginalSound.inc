// Immutable Sound-source inspection. Original Sound records remain separate
// from the active Keyboard Set / Style effect rack and manual Sound controls.
void ArrangerView::openOriginalSoundSettings(sampler::ProgramPtr program,sampler::SourceSoundEdits edits){
    if(!program)return;
    rememberNavigation();
    if(homeSoundEdit_)closeSoundWindow();
    originalSoundSettings_=std::move(program);originalSoundPage_=0;originalSoundTab_=0;
    originalSoundEdits_=edits;
    originalSoundFx_.clear();
    if(originalSoundSettings_->sourceSoundEffects)
        for(const auto& record:originalSoundSettings_->sourceSoundEffects->records)
            originalSoundFx_.push_back(sampler::inspectSoundEffectParameters(record));
    numberedFxSourcePreview_.reset();numberedFxTarget_={};
    picker_=Picker::OriginalSoundSettings;editor_=false;held_={};dragging_=false;dirty_=true;
}

void ArrangerView::drawOriginalSoundSettings(Canvas& c){
    box(c,{0,0,800,480},bg);
    button(c,{8,5,99,41},"‹ Back",blue,false,true,[this]{panelExit();},16);
    if(!originalSoundSettings_)return;
    label(c,originalSoundSettings_->name,116,32,21,green,true,670);
    button(c,{12,50,158,91},"Обвивка",green,originalSoundTab_==0,true,[this]{
        originalSoundTab_=0;originalSoundPage_=0;dirty_=true;
    },16);
    button(c,{168,50,314,91},"Sound FX",green,originalSoundTab_==1,true,[this]{
        originalSoundTab_=1;originalSoundPage_=0;dirty_=true;
    },16);
    button(c,{324,50,470,91},"OSC / LFO",green,originalSoundTab_==2,true,[this]{
        originalSoundTab_=2;originalSoundPage_=0;dirty_=true;
    },16);
    button(c,{480,50,626,91},"Voice / Porta",green,false,true,[this,program=originalSoundSettings_]{
        std::ostringstream text;
        text<<program->name<<"\n\n";
        const auto& voice=program->sourceVoiceAssignment;
        if(voice.present){
            text<<"Оригинален Voice Mode: "<<(voice.mono()?"Mono":"Poly")<<"\n";
            if(voice.legatoControlsSupported()){
                text<<"Legato: "<<(voice.legatoOffset()?"Offset":voice.legato()?"On":"Off")<<"\n";
                if(voice.legatoOffset())text<<"Режимът е разчетен; точката No Attack на семпъла още не е възстановена.\n";
            }
            else text<<"Разширеният Legato режим още не е разчетен.\n";
        }else text<<"Няма разчетен оригинален Voice Mode.\n";
        for(std::size_t i=0;i<program->layers.size();++i){
            const auto& layer=program->layers[i];const auto& porta=layer.sourcePortamento;
            if(!porta.present)continue;
            text<<"\n"<<(layer.name.empty()?"Layer "+std::to_string(i+1):layer.name)
                <<"\nPortamento Time (записан индекс): "<<int(porta.timeRaw)<<"\n";
            if(porta.basicPlaybackSupported()){
                if(!porta.encodingSupported)text<<"Базово плъзгане по собствен алгоритъм; разширените режими остават неизвестни.\n";
                text<<"Enable: "<<(porta.enabled()?"On":"Off")<<" · Fingered: "<<(porta.fingered()?"On":"Off")<<"\n";
            }else text<<"Запазено, но не се прилага: режимът или модулацията още не са разчетени.\n";
        }
        text<<"\nВсеки слой запазва собствените си стойности. Ръчната настройка на партията има предимство; Use Sound values възстановява наследяването. Времето на плъзгане се изчислява от собствен SILVETON алгоритъм.";
        showStyleInfo("Sound · Voice / Portamento",text.str());
    },16);
    button(c,{636,50,788,91},"Партия · SET",green,false,originalSoundEdits_.present(),[this,edits=originalSoundEdits_]{
        static constexpr const char* names[]{"Resonance","Release","Attack","Cutoff","Decay","Vibrato Speed","Vibrato Depth","Vibrato Delay"};
        std::ostringstream text;text<<"Записани корекции на партията\n\n";
        for(std::size_t i=0;i<edits.raw.size();++i){
            const int raw=edits.raw[i];text<<names[i]<<": ";
            if(raw<0)text<<"няма записана стойност";
            else text<<(raw>64?"+":"")<<(raw-64)<<" (MIDI "<<raw<<")";
            text<<"\n";
        }
        text<<"\nPortamento: ";
        if(edits.portamentoOnRaw<0)text<<"от Sound";
        else text<<(edits.portamentoOnRaw>=64?"On":"Off")<<" (MIDI "<<edits.portamentoOnRaw<<")";
        text<<"\nPortamento Time: ";
        if(edits.portamentoTimeRaw<0)text<<"от Sound";else text<<edits.portamentoTimeRaw;
        text<<"\n\nСтойностите се зареждат за тази партия. 0 е неутрална корекция (MIDI 64). Ръчните Tone настройки имат предимство. Реакцията на корекциите използва собствен SILVETON DSP.";
        showStyleInfo("Партия · записани SET настройки",text.str());
    },16);
    constexpr int perPage=5;
    if(originalSoundTab_==1){
        label(c,"Sound FX · параметри от PCG · тези записи още не се прилагат към звука",15,116,13,orange,false,770);
        inspectorPager(c,originalSoundPage_,static_cast<int>(originalSoundFx_.size()),perPage);
        if(originalSoundFx_.empty()){
            label(c,"За тази бленда няма разчетени Sound FX записи",400,235,18,dim,false,755,Align::Center);
            return;
        }
        const auto raw=originalSoundSettings_->sourceSoundEffects;
        for(int row=0;row<perPage;++row){
            const auto index=static_cast<std::size_t>(originalSoundPage_*perPage+row);
            if(index>=originalSoundFx_.size())break;
            const auto& slot=originalSoundFx_[index];
            const bool selectorKnown=raw&&index<raw->records.size()&&raw->records[index].selectorDecoded;
            const float y=132+row*55.0F;
            box(c,{12,y,788,y+51},panel,kBorder);
            const std::string title="Запис "+std::to_string(index+1)+(selectorKnown?
                " · "+std::to_string(slot.selector)+" · "+slot.name:" · номерът още не е разчетен");
            label(c,title,22,y+21,15,white,true,752);
            label(c,sourceFxParameterStatus(slot)+" · "+std::to_string(sourceFxKnownParameterCount(slot))+
                " стойности · "+sourceFxPlaybackStatus(slot),22,y+42,12,orange,false,750);
            const std::string context="Sound · "+originalSoundSettings_->name+" · запис "+std::to_string(index+1);
            hit({12,y,788,y+51},[this,slot,context,selectorKnown]{
                if(selectorKnown)openOriginalSourceFxEditor(slot,context,false);
                else showStyleInfo(context,sourceFxInspectionDetails(slot,context));
            });
        }
        return;
    }
    if(originalSoundTab_==2){
        std::vector<std::size_t> oscillatorLayers;
        for(std::size_t i=0;i<originalSoundSettings_->layers.size();++i)
            if(originalSoundSettings_->layers[i].sourceOscillatorDsp)oscillatorLayers.push_back(i);
        label(c,"Оригинални OSC настройки · всяка секция се проверява отделно",15,116,13,dim,false,770);
        inspectorPager(c,originalSoundPage_,static_cast<int>(oscillatorLayers.size()),perPage);
        if(oscillatorLayers.empty()){
            label(c,"За тази бленда няма запазени оригинални OSC настройки",400,235,18,dim,false,755,Align::Center);
            return;
        }
        for(int row=0;row<perPage;++row){
            const auto at=static_cast<std::size_t>(originalSoundPage_*perPage+row);if(at>=oscillatorLayers.size())break;
            const auto& layer=originalSoundSettings_->layers[oscillatorLayers[at]];
            const auto source=layer.sourceOscillatorDsp;const auto support=sampler::sourceOscillatorSupport(*source);
            const auto name=layer.name.empty()?"OSC "+std::to_string(source->oscillatorIndex+1):layer.name;
            const float y=132+row*55.0F;box(c,{12,y,788,y+51},panel,kBorder);
            label(c,name,22,y+20,15,white,true,752);
            const std::string status="Pitch "+std::string(support.pitch?"✓":"—")+" · Filter "+(support.filter?"✓":"—")+
                " · LFO 1 "+(support.lfo[0]?"✓":"—")+" · LFO 2 "+(support.lfo[1]?"✓":"—");
            label(c,status,22,y+42,13,dim,false,750);
            hit({12,y,788,y+51},[this,source,support,name]{
                const auto& d=source->dspRaw;const auto& p=source->pitchEnvelopeRaw;
                const auto state=[&](sampler::SourceOscillatorModule module,bool ready){
                    return source->overridden(module)?"ръчна настройка":ready?"прилага се":"непълна поддръжка";
                };
                std::ostringstream text;text<<name<<"\n\nPitch: "<<state(sampler::SourceOscillatorModule::Pitch,support.pitch)
                    <<"\nPitch slope: "<<sampler::sourceSignedByte(d[2])/10.0F
                    <<"\nAMS: "<<int(d[0])<<" / "<<sampler::sourcePitchSemitones(d[1])<<" semitones"
                    <<"\nPitch LFO 1/2: "<<sampler::sourcePitchSemitones(d[6])<<" / "<<sampler::sourcePitchSemitones(d[7])<<" semitones";
                text<<"\n\nPitch EG: "<<state(sampler::SourceOscillatorModule::PitchEnvelope,support.pitchEnvelope);
                if(source->pitchEnvelopePresent)text<<"\nНива S/A/R: "<<sampler::sourceSignedByte(p[0])<<" / "
                    <<sampler::sourceSignedByte(p[2])<<" / "<<sampler::sourceSignedByte(p[5])
                    <<"\nВремена A/D/R: "<<int(p[1])<<" / "<<int(p[3])<<" / "<<int(p[4]);
                text<<"\n\nFilter: "<<state(sampler::SourceOscillatorModule::Filter,support.filter)
                    <<"\nТип: "<<(d[20]==0?"Low Pass 24dB":d[20]==1?"Low Pass + High Pass 12dB":"неразчетен")
                    <<"\nTrim / Resonance: "<<int(d[21])<<" / "<<int(d[22])
                    <<"\nFrequency A/B: "<<int(d[28])<<" / "<<int(d[43]);
                text<<"\nFilter EG: "<<state(sampler::SourceOscillatorModule::FilterEnvelope,support.filterEnvelope)
                    <<"\nНива S/A/B/S/R: "<<sampler::sourceSignedByte(d[58])<<" / "<<sampler::sourceSignedByte(d[60])
                    <<" / "<<sampler::sourceSignedByte(d[62])<<" / "<<sampler::sourceSignedByte(d[64])<<" / "<<sampler::sourceSignedByte(d[66])
                    <<"\nВремена A/D/S/R: "<<int(d[59])<<" / "<<int(d[61])<<" / "<<int(d[63])<<" / "<<int(d[65]);
                for(unsigned i=0;i<2U;++i){const auto base=i*10U;const auto& l=source->lfoRaw;
                    text<<"\n\nLFO "<<i+1U<<": "<<state(i==0?sampler::SourceOscillatorModule::Lfo1:sampler::SourceOscillatorModule::Lfo2,support.lfo[i])
                        <<"\nWave / Frequency: "<<int(l[base]&31U)<<" / "<<int(l[base+1U])
                        <<"\nOffset / Delay / Fade: "<<sampler::sourceSignedByte(l[base+2U])<<" / "<<int(l[base+3U])<<" / "<<int(l[base+4U])
                        <<"\nTempo Sync: "<<((l[base+5U]&128U)!=0U?"On":"Off")
                        <<"\nAMS 1: "<<int(l[base+6U])<<" / "<<sampler::sourceSignedByte(l[base+7U])
                        <<"\nAMS 2: "<<int(l[base+8U])<<" / "<<sampler::sourceSignedByte(l[base+9U]);
                }
                text<<"\n\nAmp Level: "<<state(sampler::SourceOscillatorModule::Level,support.level)
                    <<"\nMultisample Level: "<<state(sampler::SourceOscillatorModule::Level,support.multisampleLevel)
                    <<"\nAmp модулация: "<<state(sampler::SourceOscillatorModule::Amplitude,support.amplitude)
                    <<"\nPan: "<<state(sampler::SourceOscillatorModule::Pan,support.pan);
                if(support.amplitudeSecondUnknown)text<<"\nДопълнителният Amp AMS маршрут още не е разчетен.";
                text<<"\n\nScaled Velocity: "<<(support.scaledVelocity?"прилага се":"непълна поддръжка");
                if(source->velocityZonePresent)text<<"\nВходна зона OSC: "<<int(source->velocityZoneRaw[0])<<" – "<<int(source->velocityZoneRaw[1]);
                if(source->scaledVelocityDecoded)text<<"\nИзходен диапазон: "<<int(source->scaledVelocityRaw[0])<<" – "<<int(source->scaledVelocityRaw[1]);
                if(source->equalizerPresent){
                    const auto& eq=source->equalizerRaw;
                    text<<"\n\nEQ: "<<state(sampler::SourceOscillatorModule::Equalizer,support.equalizerComplete)
                        <<"\nEnable / Trim: "<<int(eq[0])<<" / "<<int(eq[1])
                        <<"\nLow / Mid / High: "<<sampler::sourceSignedByte(eq[2])*.5F<<" / "
                        <<sampler::sourceSignedByte(eq[4])*.5F<<" / "<<sampler::sourceSignedByte(eq[5])*.5F<<" dB"
                        <<"\nMid Frequency (записан индекс): "<<int(eq[3]);
                    if(support.equalizerTrim||support.equalizerLow||support.equalizerHigh)
                        text<<"\nTrim и крайните ленти използват собствената EQ характеристика на SILVETON.";
                    if(support.equalizerUnknown)
                        text<<"\nНеразчетените EQ контроли не се прилагат. Активната средна лента изисква точната таблица за честотата.";
                }
                if(support.delayUnknown)text<<"\nОригиналният режим за отложен старт още не е разчетен.";
                text<<"\n\nПоказаните индекси са запазени от Sound. Възпроизвеждането използва собствен SILVETON DSP; корекциите на партията и ръчните настройки могат да променят резултата.";
                showStyleInfo(name+" · OSC / LFO",text.str());
            });
        }
        return;
    }
    std::vector<std::size_t> layers;
    for(std::size_t i=0;i<originalSoundSettings_->layers.size();++i)
        if(originalSoundSettings_->layers[i].sourceAmpEnvelope.present)layers.push_back(i);
    label(c,"Точни записани индекси 0–99 · времето и кривата използват SILVETON DSP",15,116,13,dim,false,770);
    inspectorPager(c,originalSoundPage_,static_cast<int>(layers.size()),perPage);
    if(layers.empty()){
        label(c,"За тази бленда няма разчетена оригинална обвивка",400,235,18,dim,false,755,Align::Center);
        return;
    }
    for(int row=0;row<perPage;++row){
        const auto at=static_cast<std::size_t>(originalSoundPage_*perPage+row);
        if(at>=layers.size())break;
        const auto i=layers[at];const auto& layer=originalSoundSettings_->layers[i];
        const auto source=layer.sourceAmpEnvelope;
        const float y=132+row*55.0F;
        box(c,{12,y,788,y+51},panel,kBorder);
        const std::string name=layer.name.empty()?"Layer "+std::to_string(i+1):layer.name;
        label(c,name,22,y+19,14,white,true,490);
        label(c,source.enabled?"Приложена при импорт":source.runtimeEnabled()?"EG активна · AMS частично":"EG неактивна",777,y+19,12,
            source.enabled?green:orange,true,270,Align::Right);
        const auto values=[](const auto& v){return std::to_string(v[0])+" / "+std::to_string(v[1])+" / "+std::to_string(v[2])+" / "+std::to_string(v[3]);};
        label(c,"Level S/A/B/S: "+values(source.levels)+"    Time A/D/S/R: "+values(source.times),22,y+41,13,dim,false,750);
        std::ostringstream detail;
        detail<<name<<"\n\nОригинални нива (0–99):\nStart: "<<int(source.levels[0])
            <<"\nAttack: "<<int(source.levels[1])<<"\nBreak: "<<int(source.levels[2])
            <<"\nSustain: "<<int(source.levels[3])
            <<"\n\nОригинални времена (индекс 0–99):\nAttack: "<<int(source.times[0])
            <<"\nDecay: "<<int(source.times[1])<<"\nSlope: "<<int(source.times[2])
            <<"\nRelease: "<<int(source.times[3]);
        detail<<"\n\nЗаписана AMS модулация (номер / сила / посоки):";
        for(unsigned route=0;route<source.amsSources.size();++route)
            detail<<"\n"<<(route==0?"Time 1":route==1?"Time 2":"Level")<<": "
                <<int(source.amsSources[route])<<" / "<<int(source.amsIntensities[route])<<" / "
                <<int(source.amsDirections[route]);
        detail<<"\n\n"<<(source.enabled?
            "Обвивката се зарежда в звуковия двигател за този слой. Ръчните настройки на партията могат да я променят.":
            "При валидни базови нива и времена обвивката се прилага. Неподдържаните AMS маршрути се пропускат поотделно; суровите стойности са запазени.");
        detail<<"\n\nПреобразуването на индексите във време и сила използва собствената SILVETON реализация; не е измерено съвпадение с оригиналния инструмент.";
        hit({12,y,788,y+51},[this,name,text=detail.str()]{showStyleInfo(name+" · Sound EG",text);});
    }
}
