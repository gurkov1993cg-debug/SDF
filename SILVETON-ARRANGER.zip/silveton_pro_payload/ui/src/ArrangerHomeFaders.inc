// Home uses full-sized panel coordinates. Names and volume gestures are separate touch targets.
bool ArrangerView::setKeyboardFader(int part,float level,bool followLink){
    if(part<0||part>=7)return false;
    const auto current=ctrl_.engine.nativeKeyboardCombi();
    if(!current)return false;
    const bool linked=followLink&&upperVolumeLink_&&part<3;
    const int first=linked?0:part,last=linked?2:part;
    float minDelta=-1000.0F,maxDelta=1000.0F;
    for(int i=first;i<=last;++i){
        const float db=current->part(i).levelDb;
        minDelta=std::max(minDelta,-60.0F-db);
        maxDelta=std::min(maxDelta,18.0F-db);
    }
    if(minDelta>maxDelta)return false;
    const float change=std::clamp(level-current->part(part).levelDb,minDelta,maxDelta);
    if(std::abs(change)<0.01F)return true;
    auto adjusted=*current;
    for(int i=first;i<=last;++i)adjusted.part(i).levelDb+=change;
    if(!ctrl_.engine.nativeApplyKeyboardCombi(adjusted,true)){
        showToast(ctrl_.engine.nativeLastTextError(),4000);return false;
    }
    for(int i=first;i<=last;++i)if(uppers_[i])uppers_[i]->levelDb=adjusted.part(i).levelDb;
    markPersistentStateChanged(false);dirty_=true;return true;
}

std::string ArrangerView::styleSoundName(int index) const {
    const auto& player=players_[selectedPlayer_];
    const auto& track=player.tracks[index];
    if(!track.assigned)return {};
    if(track.originalSoundRouted&&activityPlayer_==selectedPlayer_&&activitySerial_==player.styleSelectionSerial&&
       activityRevision_==player.soundRevision&&!activity_.programNames[index].empty())return activity_.programNames[index];
    return track.soundName;
}

void ArrangerView::drawHomeFader(Canvas& c,float left,float width,bool keyboard,int index,bool ready){
    const int player=selectedPlayer_;
    const auto& p=players_[player];const auto serial=p.styleSelectionSerial;
    const auto accent=keyboard?liveMint:liveAmber;
    const auto& upper=uppers_[keyboard?index:0];
    const auto& track=p.tracks[keyboard?0:index];
    const std::string name=keyboard?(upper?upper->soundName:""):styleSoundName(index);
    const std::string role=keyboard?arrangerKeyboardPartName(index):track.name;
    const bool empty=name.empty()||name=="EMPTY"||name=="Unassigned";
    const bool muted=keyboard?upper&&(!upper->enabled||upper->mute):track.mute;
    const bool compact=!keyboard&&width<148;
    const bool stacked=compact&&!homeSoundEdit_;
    const float namesBottom=homeSoundEdit_?227:249;
    const RectF sound{left,175,left+width,namesBottom};
    const float buttonTop=namesBottom+2,buttonBottom=homeSoundEdit_?270:stacked?325:304;
    const RectF fader{left,buttonBottom+3,left+width,495};
    const bool selected=homeSoundEdit_&&keyboard==homeToneKeyboard_&&index==homeTonePart_;
    box(c,sound,selected?(keyboard?0xFF214138U:0xFF443623U):liveKey,selected?accent:liveLine,6);

    const float margin=compact?6.0F:12.0F,font=compact?17.0F:22.0F;
    const float usable=width-2*margin;
    // At eight parts the entire name area is still one touch target. Use its
    // full width for the two lines of the actual sound name.
    label(c,role,left+margin,195,compact?17:19,accent,true,usable-(compact?9:18));
    if(!compact)label(c,"›",sound.right-margin,196,17,accent,true,18,Align::Right);
    const std::string display=empty?(keyboard||p.loaded?"Select Sound":"—"):name;
    Paint type;type.typeface=Face::Bold;type.textSize=font;
    const auto split=type.textPrefixLength(display,usable);
    if(split>0&&split<display.size()){
        label(c,display.substr(0,split),left+margin,homeSoundEdit_?224:220,font,liveText,true,usable);
        if(!homeSoundEdit_)label(c,display.substr(split),left+margin,244,font,liveText,true,usable);
    }else label(c,display,left+margin,homeSoundEdit_?222:235,font,empty?liveDim:liveText,true,usable);
    if(ready)hit(sound,[this,keyboard,index,player,serial,empty]{
        if(!keyboard){
            if(selectedPlayer_!=player)return;
            const auto current=host::arrangerHost().snapshot(player);
            if(current.styleSelectionSerial!=serial||current.styleSwitchPending)return;
        }
        if(homeSoundEdit_&&!empty){homeToneKeyboard_=keyboard;homeTonePart_=index;toneDialPreview_=-1;dirty_=true;return;}
        openTargetSound(keyboard?index:0,keyboard?-1:index);
    });

    const auto owner=keyboard?ctrl_.engine.nativeKeyboardCombi():nullptr;
    const bool isolated=partSolo(keyboard?-1:player,index);
    const bool available=ready&&!empty&&(!keyboard||(upper&&(index!=6||keyboardSplitEnabled_)));
    const auto current=[this,owner,keyboard,index,player,serial]{
        if(keyboard){
            const auto now=ctrl_.engine.nativeKeyboardCombi();
            return owner&&now&&now->part(index).program==owner->part(index).program&&now->name==owner->name&&(index!=6||keyboardSplitEnabled_);
        }
        const auto v=host::arrangerHost().snapshot(player);
        return selectedPlayer_==player&&v.styleSelectionSerial==serial&&!v.styleSwitchPending;
    };
    const float mid=left+width*.5F,half=(buttonTop+buttonBottom)*.5F;
    const RectF muteBox=stacked?RectF{left,buttonTop,left+width,half-1}:RectF{left,buttonTop,mid-1,buttonBottom};
    const RectF soloBox=stacked?RectF{left,half+1,left+width,buttonBottom}:RectF{mid+1,buttonTop,left+width,buttonBottom};
    const auto channelButton=[&](const RectF& r,const char* name,bool active,ColorInt color){
        box(c,r,active?color:liveCard,active?color:liveLine,4);
        label(c,name,r.centerX(),r.centerY()+6,17,active?liveBg:available?liveText:liveOff,true,r.width()-4,Align::Center);
    };
    channelButton(muteBox,compact&&homeSoundEdit_?"M":"Mute",muted&&!empty&&!isolated,liveStop);
    channelButton(soloBox,compact&&homeSoundEdit_?"S":"Solo",isolated,liveAmber);
    if(available)hit(muteBox,[this,current,keyboard,index,player,serial]{
        if(current())togglePartMute(keyboard?-1:player,index,serial);
    },{},true);
    if(available||isolated)hit(soloBox,[this,current,keyboard,index,player]{
        if(!current())return;
        listenPart(keyboard?-1:player,index);
        dirty_=true;
    },{},true);
    if(homeSoundEdit_)return;
    const float ceiling=keyboard?18.0F:12.0F;
    const float level=keyboard?(upper?upper->levelDb:0.0F):track.volumeDb;
    const float bottom=465.0F,top=fader.top+17.0F;
    // More physical travel around working levels, while retaining the full gain range.
    const auto position=[ceiling](float db){
        db=std::clamp(db,-60.0F,ceiling);
        return db < -24.0F?(db+60.0F)/36.0F*0.28F:0.28F+(db+24.0F)/(ceiling+24.0F)*0.72F;
    };
    const float x=left+width*(compact?.5F:.32F),y=bottom-(bottom-top)*position(level);
    const float unity=bottom-(bottom-top)*position(0);
    const bool enabled=ready&&(!keyboard||upper.has_value());
    box(c,fader,liveCard,liveLine,6);
    box(c,{x-5,top,x+5,bottom},liveLine,0,4);
    box(c,{x-5,y,x+5,bottom},enabled?accent:liveOff,0,4);
    box(c,{x-28,unity-1,x-10,unity+1},liveDim);
    box(c,{x+10,unity-1,x+28,unity+1},liveDim);
    const float cap=compact?std::min(40.0F,width*.44F):40.0F;
    box(c,{x-cap,y-14,x+cap,y+14},enabled?accent:liveOff,0,6);
    box(c,{x-cap+12,y-1,x+cap-12,y+1},liveBg);
    char dbText[20];std::snprintf(dbText,sizeof(dbText),"%+.1f",level);
    if(compact){
        label(c,std::string(dbText)+" dB",fader.centerX(),489,17,enabled?liveText:liveOff,true,width-6,Align::Center);
    }else{
        label(c,dbText,left+width*.74F,354,24,enabled?liveText:liveOff,true,width*.48F,Align::Center);
        label(c,"dB",left+width*.74F,379,17,liveDim,false,width*.44F,Align::Center);
    }
    if(!enabled)return;

    // The whole strip grabs at the current level. A touch alone never jumps in level.
    hit(fader,{},[this,keyboard,index,player,serial,ceiling,gesture=RelativeVolumeGesture{},
                   lastLevel=0.0F,expected=std::shared_ptr<const sampler::Combi>{}](float,float touchY) mutable {
        if(!keyboard&&(player!=selectedPlayer_||players_[player].styleSelectionSerial!=serial||players_[player].styleSwitchPending))return;
        const auto current=keyboard?ctrl_.engine.nativeKeyboardCombi():nullptr;
        if(keyboard&&!current)return;
        if(!gesture.grabbed){
            expected=current;
            lastLevel=keyboard?current->part(index).levelDb:host::arrangerHost().snapshot(player).tracks[index].volumeDb;
            gesture.update(touchY,lastLevel,-60.0F,ceiling);return;
        }
        // A queued Keyboard Set can take over while a finger is held down.
        if(keyboard&&expected!=current)return;
        const float value=gesture.update(touchY,lastLevel,-60.0F,ceiling);
        if(std::abs(value-lastLevel)<0.01F)return;
        if(keyboard){
            if(!setKeyboardFader(index,value))return;
            expected=ctrl_.engine.nativeKeyboardCombi();
            if(!expected)return;
            lastLevel=expected->part(index).levelDb;
            if(std::abs(lastLevel-value)>0.01F)gesture.rebase(lastLevel);
            dirty_=true;return;
        }else if(!host::arrangerHost().setTrackVolume(player,index,value,serial)){
            showToast(host::arrangerHost().lastError(),3500);return;
        }
        lastLevel=value;dirty_=true;
    });
    auto& bound=hits_.back();
    const auto revision=keyboard?0:p.soundRevision;
    bound.resetTarget={ResetSurface::Volume,keyboard?-1:player,index,"Volume",keyboard?0:serial,revision,owner};
    bound.reset=[this,keyboard,index,player,serial,revision,owner]{
        if(selectedPlayer_!=player||homeSoundEdit_||picker_!=Picker::None||tab_!=Tab::Main)return;
        if(keyboard){
            if(ctrl_.engine.nativeKeyboardCombi()==owner)setKeyboardFader(index,0.0F,false);
        }else{
            const auto current=host::arrangerHost().snapshot(player);
            if(current.styleSwitchPending||current.styleSelectionSerial!=serial||current.soundRevision!=revision)return;
            if(!host::arrangerHost().setTrackVolume(player,index,0.0F,serial))showToast(host::arrangerHost().lastError(),3500);
        }
        dirty_=true;
    };
}
