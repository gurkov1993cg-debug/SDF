void ArrangerView::stepTranspose(int step){
    if(globalSettingsRestorePending_)restoreSavedGlobalSettings();
    if(ctrl_.stepGlobalTranspose(step)){globalUi_=ctrl_.globalUiState();rememberCurrentGlobalSettings();}
    else showToast(ctrl_.lastFailure(),5000);
    refresh(false);dirty_=true;
}

// Outer-panel tempo encoder. The approved inner display is unchanged.
// One turn is 120 integer BPM detents; a touch establishes a relative anchor.
void ArrangerView::tapTempo(bool tempoOnly){
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    tempoWheelDisplayUntil_=0;
    if(player.playing&&!tempoOnly){
        tapTempoCount_=0;tapTempoElapsed_=0;lastTap_=0;
        controlRequested(host::arrangerHost().resetPosition(selectedPlayer_));
        return;
    }
    if(!player.loaded||!player.soundAssignmentsReady){
        tapTempoCount_=0;tapTempoElapsed_=0;lastTap_=0;
        showToast("Select a playable Style before RESET / TAP",4500);return;
    }
    const auto identity=arrangerStyleSelectionKey(player)+"/"+(tempoOnly?"bpm":std::to_string(player.element))+"/"+
        std::to_string(player.numerator)+"/"+std::to_string(player.denominator);
    const auto now=pointerEventTimeMs_>0?pointerEventTimeMs_:nowMs();
    const int beats=std::max(1,player.numerator);
    const double beatFactor=tempoOnly?1.0:4.0/static_cast<double>(std::max(1,player.denominator));
    const auto interval=now-lastTap_;
    const double intervalBpm=interval>0?60000.0*beatFactor/static_cast<double>(interval):0.0;
    if(tapTempoPlayer_!=selectedPlayer_||tapTempoSourceKey_!=identity||lastTap_<=0||
       intervalBpm<20.0||intervalBpm>400.0){
        tapTempoPlayer_=selectedPlayer_;tapTempoSourceKey_=identity;
        tapTempoCount_=1;tapTempoElapsed_=0;
    }else{
        ++tapTempoCount_;tapTempoElapsed_+=interval;
    }
    lastTap_=now;
    if(tempoOnly){
        if(tapTempoCount_>=2){
            const double bpm=60000.0*double(tapTempoCount_-1)/double(tapTempoElapsed_);
            controlRequested(host::arrangerHost().setTempo(selectedPlayer_,std::clamp(bpm,20.0,400.0)));
            if(tapTempoCount_>=5){tapTempoElapsed_=std::lround(tapTempoElapsed_*0.75);tapTempoCount_=4;}
        }else showToast("Tap again for tempo",900);
        return;
    }
    if(tapTempoCount_>=beats){
        const double bpm=tapTempoCount_>1&&tapTempoElapsed_>0?
            60000.0*beatFactor*static_cast<double>(tapTempoCount_-1)/static_cast<double>(tapTempoElapsed_):player.bpm;
        tapTempoCount_=0;tapTempoElapsed_=0;lastTap_=0;
        controlRequested(host::arrangerHost().startWithTempo(selectedPlayer_,std::clamp(bpm,20.0,400.0)));
    }else showToast("Tap "+std::to_string(tapTempoCount_)+" / "+std::to_string(beats),1200);
}

void ArrangerView::resetTempoWheelGesture(){
    tempoWheelTracking_=false;
    tempoWheelAnchored_=false;
    tempoWheelRemainder_=0.0;
}

void ArrangerView::drawTempoWheel(Canvas& c,const host::ArrangerPlayerView& player){
    constexpr float centerX=kTempoWheelCenterX,centerY=kTempoWheelCenterY,radius=kTempoWheelRadius;
    constexpr double pi=3.14159265358979323846;
    constexpr ColorInt accent=styleBlue;
    const double actual=std::isfinite(player.bpm)?std::clamp(player.bpm,20.0,400.0):120.0;
    // Keep the last accepted target visible across a quick lift/re-grab while
    // the next lightweight snapshot catches the audio block's applied value.
    const bool recentTarget=selectedPlayer_==tempoWheelPlayer_&&
        arrangerStyleSelectionKey(player)==tempoWheelSourceKey_&&nowMs()<tempoWheelDisplayUntil_;
    const double shown=tempoWheelTracking_||recentTarget?tempoWheelDesired_:actual;
    Paint encoderPaint;encoderPaint.color=0xFF172229U;
    c.drawCircle(centerX,centerY,radius,encoderPaint);
    encoderPaint.style=Style::Stroke;encoderPaint.strokeWidth=2.0F;encoderPaint.color=tempoWheelTracking_?white:accent;
    c.drawCircle(centerX,centerY,radius-1.0F,encoderPaint);
    encoderPaint.style=Style::Fill;encoderPaint.color=0xFF080D11U;
    c.drawCircle(centerX,centerY,radius-14.0F,encoderPaint);
    encoderPaint.color=0xFF4F626CU;encoderPaint.strokeWidth=2.0F;
    for(int tick=0;tick<24;++tick){
        const double angle=static_cast<double>(tick)*2.0*pi/24.0-pi/2.0;
        const float inner=tick%6==0?radius-12.0F:radius-8.0F;
        const auto cosine=static_cast<float>(std::cos(angle));
        const auto sine=static_cast<float>(std::sin(angle));
        c.drawLine(centerX+inner*cosine,centerY+inner*sine,
                   centerX+(radius-4.0F)*cosine,centerY+(radius-4.0F)*sine,encoderPaint);
    }
    encoderPaint.color=0xFF11191EU;c.drawCircle(centerX,centerY,radius-28.0F,encoderPaint);
    const double position=std::fmod(shown,120.0)*2.0*pi/120.0-pi/2.0;
    encoderPaint.color=accent;
    c.drawCircle(centerX+(radius-21.0F)*static_cast<float>(std::cos(position)),
                 centerY+(radius-21.0F)*static_cast<float>(std::sin(position)),4.0F,encoderPaint);
    label(c,"TEMPO",centerX,centerY-32.0F,11.0F,dim,true,110.0F,Align::Center);
    const auto value=tempoText(shown);
    label(c,value,centerX,centerY+6.0F,value.size()>5U?24.0F:31.0F,white,true,110.0F,Align::Center);
    label(c,"BPM",centerX,centerY+26.0F,11.0F,dim,false,90.0F,Align::Center);
    const int target=tempoWheelTracking_?tempoWheelPlayer_:selectedPlayer_;
    label(c,"PLAYER "+std::to_string(target+1),centerX,centerY+45.0F,10.0F,accent,true,95.0F,Align::Center);

    hit({centerX-radius,centerY-radius,centerX+radius,centerY+radius},{},
        [this](float x,float y){
            constexpr double gesturePi=3.14159265358979323846;
            constexpr double detent=2.0*gesturePi/120.0;
            const double dx=static_cast<double>(x)-static_cast<double>(kTempoWheelCenterX);
            const double dy=static_cast<double>(y)-static_cast<double>(kTempoWheelCenterY);
            const double distanceSquared=dx*dx+dy*dy;
            if(!std::isfinite(distanceSquared))return;
            if(!tempoWheelTracking_){
                // Reject the square hit-box corners. Once captured, a finger
                // can move outside the rim without losing the encoder gesture.
                if(distanceSquared>static_cast<double>(kTempoWheelRadius*kTempoWheelRadius))return;
                tempoWheelTracking_=true;
                const int gesturePlayer=std::clamp(selectedPlayer_,0,1);
                const auto& targetState=players_[static_cast<std::size_t>(gesturePlayer)];
                const auto source=arrangerStyleSelectionKey(targetState);
                const bool recent=gesturePlayer==tempoWheelPlayer_&&source==tempoWheelSourceKey_&&nowMs()<tempoWheelDisplayUntil_;
                tempoWheelPlayer_=gesturePlayer;
                tempoWheelSourceKey_=source;
                const double tempo=players_[static_cast<std::size_t>(tempoWheelPlayer_)].bpm;
                if(!recent)tempoWheelDesired_=std::isfinite(tempo)?std::clamp(tempo,20.0,400.0):120.0;
                tempoWheelRemainder_=0.0;
                tempoWheelAnchored_=false;
            }
            // Crossing the dead centre establishes a new angle on exit. It
            // must never be interpreted as a sudden half-turn of the wheel.
            if(distanceSquared<24.0*24.0){
                tempoWheelAnchored_=false;tempoWheelRemainder_=0.0;return;
            }
            const double angle=std::atan2(dy,dx);
            if(!tempoWheelAnchored_){
                tempoWheelAngle_=angle;tempoWheelAnchored_=true;return;
            }
            double delta=angle-tempoWheelAngle_;tempoWheelAngle_=angle;
            if(delta>gesturePi)delta-=2.0*gesturePi;
            else if(delta< -gesturePi)delta+=2.0*gesturePi;
            tempoWheelRemainder_+=delta;
            const double detents=std::trunc(tempoWheelRemainder_/detent);
            if(detents==0.0)return;
            tempoWheelRemainder_-=detents*detent;
            const double desired=std::clamp(tempoWheelDesired_+detents,20.0,400.0);
            if(desired==tempoWheelDesired_)return;
            // Accumulate from the last accepted request, not a snapshot that
            // can still be one housekeeping interval behind the gesture.
            const bool accepted=host::arrangerHost().setTempo(tempoWheelPlayer_,desired);
            if(accepted){tempoWheelDesired_=desired;tempoWheelDisplayUntil_=nowMs()+150;tapTempoCount_=0;lastTap_=0;}
            controlRequested(accepted);
        });
}
