// One MEDIA surface. Native SET data remains source-backed; no Korg writer.
namespace {
constexpr std::size_t kMediaBundleMaximum=10U*1024U*1024U;
constexpr std::size_t kMediaFileMaximum=4U*1024U*1024U;
const std::string kMediaExtraKey="ARRANGER_MEDIA_BUNDLE=";
const std::string kMediaMagic="SILVETON_MEDIA_SET_2";
const std::string kMediaLegacyMagic="SILVETON_MEDIA_SET_1";
const std::string kMediaDrumPrefix="ARRANGER_DRUMKIT_";
int mediaResourceTab(const std::string& directory){
    std::string name=files::nameOf(directory);
    for(char& c:name)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    if(name=="style")return 0;
    if(name=="perform"||name=="keyboardset")return 2;
    return -1;
}
bool mediaNativeSet(const std::string& path){
    auto name=files::nameOf(path);std::transform(name.begin(),name.end(),name.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    return endsWith(name,".svset");
}
bool mediaMutableName(const std::string& name){
    return endsWith(name,".ref")&&(startsWith(name,"ARRANGER_USER_KBD_")||startsWith(name,"ARRANGER_SOURCE_KBD_")||startsWith(name,"ARRANGER_NATIVE_KBD_")||
        startsWith(name,"ARRANGER_USER_STYLE_")||startsWith(name,"ARRANGER_STYLE_SOURCE_"));
}
bool mediaDrumName(const std::string& name){
    return name.size()==kMediaDrumPrefix.size()+64U+5U&&startsWith(name,kMediaDrumPrefix)&&endsWith(name,".svdk")&&
        std::all_of(name.begin()+static_cast<std::ptrdiff_t>(kMediaDrumPrefix.size()),name.end()-5,
            [](unsigned char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');});
}
std::string mediaResourcePath(const std::string& parent,const std::string& name){
    return mediaDrumName(name)?files::join(files::join(parent,"DrumKits"),name.substr(kMediaDrumPrefix.size())):files::join(parent,name);
}
bool mediaResourceName(const std::string& name){
    if(name.empty()||name.size()>180U||!std::all_of(name.begin(),name.end(),[](unsigned char c){return std::isalnum(c)||c=='_'||c=='.'||c=='-';}))return false;
    return mediaDrumName(name)||mediaMutableName(name)||(startsWith(name,"ARRANGER_STYLE_KBD_")&&endsWith(name,".ref"))||
        (startsWith(name,"ARRANGER_KEYBOARD_")&&endsWith(name,".SVSET"))||
        (startsWith(name,"ARRANGER_STYLE_REV_")&&endsWith(name,".svstyle"));
}
bool mediaReadFile(const std::string& path,std::string& bytes,std::size_t maximum=kMediaFileMaximum){
    std::ifstream in(path,std::ios::binary|std::ios::ate);const auto size=in.tellg();
    if(!in||size<0||size>static_cast<std::streamoff>(maximum))return false;
    bytes.resize(static_cast<std::size_t>(size));in.seekg(0);
    if(!bytes.empty())in.read(bytes.data(),static_cast<std::streamsize>(bytes.size()));
    return static_cast<bool>(in);
}
bool mediaAtomicWrite(const std::string& path,const std::string& bytes){
    const auto pending=path+".media-pending";
    if(!files::writeText(pending,bytes)||std::rename(pending.c_str(),path.c_str())!=0){(void)files::removeRecursively(pending);return false;}return true;
}
void mediaU32(std::string& out,std::uint32_t value){for(unsigned shift=0;shift<32U;shift+=8U)out.push_back(static_cast<char>((value>>shift)&255U));}
void mediaString(std::string& out,const std::string& value){mediaU32(out,static_cast<std::uint32_t>(value.size()));out+=value;}
struct MediaReader {
    const std::string& bytes;std::size_t at{0};bool valid{true};
    std::uint32_t u32(){if(at>bytes.size()||bytes.size()-at<4U){valid=false;return 0;}std::uint32_t v=0;
        for(unsigned shift=0;shift<32U;shift+=8U)v|=static_cast<std::uint32_t>(static_cast<unsigned char>(bytes[at++]))<<shift;
        return v;}
    std::string string(std::size_t maximum){const auto size=u32();if(!valid||size>maximum||at>bytes.size()||bytes.size()-at<size){valid=false;return {};}
        auto value=bytes.substr(at,size);at+=size;return value;}
};
std::string mediaBase64(const std::string& bytes){
    static constexpr char alphabet[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;out.reserve((bytes.size()+2U)/3U*4U);
    for(std::size_t i=0;i<bytes.size();i+=3U){const auto a=static_cast<unsigned char>(bytes[i]);
        const auto b=i+1U<bytes.size()?static_cast<unsigned char>(bytes[i+1U]):0U;
        const auto d=i+2U<bytes.size()?static_cast<unsigned char>(bytes[i+2U]):0U;
        out.push_back(alphabet[a>>2U]);out.push_back(alphabet[((a&3U)<<4U)|(b>>4U)]);
        out.push_back(i+1U<bytes.size()?alphabet[((b&15U)<<2U)|(d>>6U)]:'=');out.push_back(i+2U<bytes.size()?alphabet[d&63U]:'=');}
    return out;
}
bool mediaUnbase64(const std::string& text,std::string& bytes){
    if(text.empty()||text.size()%4U!=0||text.size()>((kMediaBundleMaximum+2U)/3U)*4U)return false;
    const auto digit=[](unsigned char c)->int{if(c>='A'&&c<='Z')return c-'A';if(c>='a'&&c<='z')return c-'a'+26;
        if(c>='0'&&c<='9')return c-'0'+52;
        if(c=='+')return 62;
        if(c=='/')return 63;
        return -1;};
    bytes.clear();bytes.reserve(text.size()/4U*3U);
    for(std::size_t i=0;i<text.size();i+=4U){const int a=digit(static_cast<unsigned char>(text[i])),b=digit(static_cast<unsigned char>(text[i+1U]));
        const int c=text[i+2U]=='='?-2:digit(static_cast<unsigned char>(text[i+2U]));const int d=text[i+3U]=='='?-2:digit(static_cast<unsigned char>(text[i+3U]));
        if(a<0||b<0||c==-1||d==-1||(c==-2&&d!=-2)||((c==-2||d==-2)&&i+4U!=text.size())||
           (c==-2&&(b&15)!=0)||(d==-2&&c>=0&&(c&3)!=0))return false;
        bytes.push_back(static_cast<char>((a<<2)|(b>>4)));if(c>=0)bytes.push_back(static_cast<char>(((b&15)<<4)|(c>>2)));
        if(d>=0)bytes.push_back(static_cast<char>(((c&3)<<6)|d));}
    return bytes.size()<=kMediaBundleMaximum;
}
std::set<std::string> mediaDependencies(const std::string& text){
    std::set<std::string> result;std::size_t at=0;
    while((at=text.find("ARRANGER_",at))!=std::string::npos){auto end=at;
        while(end<text.size()){const auto c=static_cast<unsigned char>(text[end]);if(!(std::isalnum(c)||c=='_'||c=='.'||c=='-'))break;++end;}
        const auto name=text.substr(at,end-at);if(mediaResourceName(name))result.insert(name);at=end>at?end:at+1U;}
    return result;
}
std::string mediaSetStem(const std::string& path){auto name=files::nameOf(path);if(mediaNativeSet(path)&&name.size()>6U)name.resize(name.size()-6U);return name;}
}

struct ArrangerView::MediaRestore {
    std::string path,session,origin,owner,beforeSession,beforeHost,beforeSettings,beforeSetPath,beforeStyleKey,beforeRoot,bankIdentity;
    std::map<std::string,std::string> files;
    std::vector<std::string> roots;
    std::map<std::string,std::optional<std::string>> pointerBackups;
    std::map<std::string,std::optional<std::string>> drumBackups;
    host::ArrangerStyleKeyboardLinks workingRefs{};
    std::array<KeyboardWorkingSet,4> working{},beforeWorking{};
    std::array<int,4> beforeSlots{};std::array<std::string,4> beforePaths{},beforeNames{};
    KeyboardWorkingSet beforeKeyboard;
    std::shared_ptr<const sampler::SetData> preparedData;
    std::shared_ptr<const host::PerformanceCheckpoint> checkpoint;
    std::shared_ptr<const host::ArrangerSourceCheckpoint> sourceCheckpoint;
    std::shared_ptr<const arranger::Pa5xKstCatalog> beforeCatalog;
    std::shared_ptr<const arranger::Pa5xKstIndex> beforeReport;
    std::map<std::uint64_t,unsigned> beforeClasses;
    SampleSummary beforeSamples;
    std::vector<arranger::Pa5xPcmFileStatus> beforePcm;
    std::optional<PersistentUiState> beforeUi;
    int selectedPosition{-1},beforePosition{-1};bool nativeLoaded{false},pointersChanged{false};
    bool hasDrumSnapshot{false},drumsChanged{false};
};

void ArrangerView::rememberMediaSetPath(const std::string& path){
    mediaCurrentSetPath_=path;
    if(persistentSessionPath_.empty())return;
    std::ostringstream text;text<<"SILVETON_MEDIA_CURRENT 1\n"<<std::quoted(path)<<'\n';
    if(!mediaAtomicWrite(files::join(files::parentOf(persistentSessionPath_),"ARRANGER_MEDIA_CURRENT.txt"),text.str()))
        showToast("The SET path could not be remembered",4500);
}
void ArrangerView::openMedia(bool saving){
    if(leaveInstrumentEditor())return;
    
    if(kstJob_){picker_=Picker::KstProgress;dirty_=true;return;}
    if(storageAccessRequest_&&!storageAccessRequest_())return;
    if(panelMode_!=PanelMode::File)rememberNavigation();
    targetTrack_=-1;targetPart_=0;panelMode_=PanelMode::File;
    if(!mediaPathRead_){mediaPathRead_=true;std::string text,path,magic;int version=0;
        if(files::readText(files::join(files::parentOf(persistentSessionPath_),"ARRANGER_MEDIA_CURRENT.txt"),text)&&text.size()<65536U){
            std::istringstream in(text);if(in>>magic>>version>>std::quoted(path)&&magic=="SILVETON_MEDIA_CURRENT"&&version==1&&mediaNativeSet(path)&&files::isFile(path))mediaCurrentSetPath_=path;}}
    mediaSaveTab_=saving;mediaOverwriteConfirm_=false;mediaNameEditing_=false;editor_=false;held_={};picker_=Picker::Media;
    auto directory=mediaDirectory_;
    if(directory.empty())directory=!mediaCurrentSetPath_.empty()?files::parentOf(mediaCurrentSetPath_):!savedKstRoot_.empty()?files::parentOf(savedKstRoot_):pickerDirectory_;
    if(directory.empty()||!files::isDirectory(directory))directory=files::isDirectory("/storage/emulated/0")?"/storage/emulated/0":files::homeDirectory();
    listMediaDirectory(directory);
    if(mediaName_.empty())mediaName_=mediaCurrentSetPath_.empty()?savedKstRoot_.empty()?"My SET":mediaSetStem(savedKstRoot_):mediaSetStem(mediaCurrentSetPath_);
    dirty_=true;
}
void ArrangerView::listMediaDirectory(const std::string& path){
    if(!files::isDirectory(path)){showToast("The folder is unavailable",4500);return;}
    mediaDirectory_=files::absolute(path);mediaPage_=0;mediaSelected_=-1;mediaOverwriteConfirm_=false;mediaEntries_.clear();
    mediaSetRoot_.clear();mediaFolderTab_=-1;
    if(arranger::canSelectPa5xKstDirectory(mediaDirectory_))mediaSetRoot_=mediaDirectory_;
    else {
        const int tab=mediaResourceTab(mediaDirectory_);
        const auto parent=files::parentOf(mediaDirectory_);
        if(tab>=0&&arranger::canSelectPa5xKstDirectory(parent)){mediaFolderTab_=tab;mediaSetRoot_=parent;}
    }
    for(const auto& name:files::listNames(mediaDirectory_)){
        if(name.empty()||name.front()=='.'||name=="__MACOSX")continue;
        const auto full=files::join(mediaDirectory_,name);
        const bool directory=files::isDirectory(full);
        int kind=0;
        if(mediaNativeSet(full))kind=2;
        else if(directory&&arranger::canSelectPa5xKstDirectory(full))kind=1;
        else if(!mediaSetRoot_.empty()){
            const int tab=directory&&mediaSetRoot_==mediaDirectory_?mediaResourceTab(full):mediaFolderTab_;
            if(tab==0&&((directory&&mediaSetRoot_==mediaDirectory_)||(!directory&&arranger::paStyleBankPath(full))))kind=3;
            if(tab==2&&((directory&&mediaSetRoot_==mediaDirectory_)||(!directory&&arranger::paPerformanceBankPath(full))))kind=4;
        }
        if(directory||kind!=0)mediaEntries_.push_back({name,full,directory,kind});
    }
    std::sort(mediaEntries_.begin(),mediaEntries_.end(),[](const auto& a,const auto& b){if(a.directory!=b.directory)return a.directory>b.directory;return a.name<b.name;});
    for(std::size_t i=0;i<mediaEntries_.size();++i)if(mediaEntries_[i].path==mediaCurrentSetPath_){mediaSelected_=static_cast<int>(i);mediaPage_=mediaSelected_/5;break;}
    dirty_=true;
}
void ArrangerView::editMediaSetName(){
    mediaNameEditing_=true;editor_=true;held_={};mediaOverwriteConfirm_=false;
    SilvetonSamplerView::requestExternalTextEdit("SET Name",mediaName_,[this](const std::string& value){mediaName_=trimmed(value);mediaNameEditing_=false;editor_=false;picker_=Picker::Media;dirty_=true;if(!mediaName_.empty())saveMediaSet(true);});
    dirty_=true;
}
void ArrangerView::drawMedia(Canvas& c){
    box(c,{0,0,800,480},bg);label(c,"MEDIA",17,30,23,orange,true,300);
    button(c,{688,5,790,39},"‹ Back",orange,false,true,[this]{panelExit();},15);
    button(c,{10,47,152,85},"Load",orange,!mediaSaveTab_,true,[this]{mediaSaveTab_=false;mediaOverwriteConfirm_=false;dirty_=true;},18);
    button(c,{160,47,302,85},"Save",green,mediaSaveTab_,true,[this]{mediaSaveTab_=true;mediaOverwriteConfirm_=false;dirty_=true;},18);
    label(c,mediaDirectory_,318,72,13,dim,false,470);
    box(c,{10,94,790,336},panel,kBorder);
    if(mediaEntries_.empty())label(c,"No SETs or folders",400,211,18,dim,false,740,Align::Center);
    for(int row=0;row<5;++row){const int index=mediaPage_*5+row;if(index>=static_cast<int>(mediaEntries_.size()))break;
        const auto entry=mediaEntries_[static_cast<std::size_t>(index)];const float y=96.0F+static_cast<float>(row)*48.0F;
        const bool selected=index==mediaSelected_;box(c,{12,y,787,y+45},selected?0xFFE7D58CU:panel,kBorder);
        const char* type=entry.value==3?(entry.directory?"STYLE":"STY"):entry.value==4?(entry.directory?"KBD":"PRF"):entry.value>0?"SET":entry.directory?"DIR":"FILE";
        label(c,type,23,y+29,15,selected?bg:dim,true,58);
        label(c,entry.name,91,y+30,20,selected?bg:white,true,682);
        hit({12,y,787,y+45},[this,index]{mediaSelected_=index;mediaOverwriteConfirm_=false;dirty_=true;});
    }
    const bool selected=mediaSelected_>=0&&mediaSelected_<static_cast<int>(mediaEntries_.size());
    const bool directory=selected&&mediaEntries_[static_cast<std::size_t>(mediaSelected_)].directory;
    button(c,{10,345,108,385},"Drives",orange,false,true,[this]{listMediaDirectory(files::isDirectory("/storage")?"/storage":files::homeDirectory());},14);
    button(c,{116,345,214,385},"Up",orange,false,files::parentOf(mediaDirectory_)!=mediaDirectory_,[this]{listMediaDirectory(files::parentOf(mediaDirectory_));},14);
    button(c,{222,345,320,385},"Open",orange,false,directory,[this]{listMediaDirectory(mediaEntries_[static_cast<std::size_t>(mediaSelected_)].path);},14);
    const int pages=std::max(1,(static_cast<int>(mediaEntries_.size())+4)/5);
    button(c,{540,345,607,385},"◀",orange,false,mediaPage_>0,[this]{--mediaPage_;mediaSelected_=-1;dirty_=true;},17);
    label(c,std::to_string(mediaPage_+1)+" / "+std::to_string(pages),663,372,14,white,true,95,Align::Center);
    button(c,{720,345,788,385},"▶",orange,false,mediaPage_+1<pages,[this]{++mediaPage_;mediaSelected_=-1;dirty_=true;},17);
    if(!mediaSaveTab_){
        label(c,!mediaCurrentSetPath_.empty()?"Current: "+files::nameOf(mediaCurrentSetPath_):!savedKstRoot_.empty()?"Current: "+files::nameOf(savedKstRoot_):"Select a SET, then Load",17,412,14,dim,false,770);
        const bool navigate=directory&&mediaEntries_[static_cast<std::size_t>(mediaSelected_)].value==0;
        button(c,{12,430,233,472},"Sample Info",blue,false,kstReport_!=nullptr,[this]{openInspector(Picker::SetInfo);},17);
        button(c,{241,430,466,472},"SET Sounds",green,false,kstCatalog_!=nullptr,[this]{openInspector(Picker::SetSounds);},17);
        button(c,{487,430,788,472},navigate?"Open":!selected&&mediaFolderTab_<0?"Load SET":"Load",green,true,(selected||!mediaSetRoot_.empty())&&styleKeyboardCue_.serial==0,[this]{loadMediaSelection();},19);
    }else{
        const bool current=!mediaCurrentSetPath_.empty();
        label(c,current?"Current: "+files::nameOf(mediaCurrentSetPath_):"Save a new SET in this folder",17,412,14,dim,false,770);
        if(current)button(c,{12,430,320,472},"Save As...",orange,false,styleKeyboardCue_.serial==0,[this]{mediaName_=mediaSetStem(mediaCurrentSetPath_);editMediaSetName();},17);
        button(c,{487,430,788,472},current?"Save":"Save SET",green,true,styleKeyboardCue_.serial==0,[this,current]{if(current)saveMediaSet(false);else editMediaSetName();},19);
    }
    if(mediaOverwriteConfirm_){
        box(c,{45,151,755,327},bg,orange,3);label(c,"Replace this SET?",400,187,21,orange,true,680,Align::Center);
        const auto target=mediaSaveTarget_;
        label(c,files::nameOf(target),400,225,18,white,true,680,Align::Center);
        button(c,{67,264,376,308},"Cancel",orange,false,true,[this]{mediaOverwriteConfirm_=false;dirty_=true;},17);
        button(c,{423,264,731,308},"Overwrite",green,true,true,[this]{saveMediaSet(mediaSaveTargetAs_);},17);
    }
}

void ArrangerView::saveMediaSet(bool saveAs){
    if(!ctrl_.initialBankLoadFinished()||kstJob_||persistentRestorePending_||mediaRestore_||styleKeyboardCue_.serial!=0||host::arrangerHost().snapshot(0).styleSwitchPending||host::arrangerHost().snapshot(1).styleSwitchPending){showToast("Wait for the current SET or Style change to finish",5000);return;}
    if(persistentSessionPath_.empty()){showToast("SET storage is unavailable",5000);return;}
    if(saveAs&&mediaName_.empty()){editMediaSetName();return;}
    if(!saveAs&&!mediaOverwriteConfirm_)mediaName_.clear();
    if(saveAs&&(mediaName_.empty()||mediaName_.size()>160U||mediaName_=="."||mediaName_==".."||mediaName_.find_first_of("/\\\r\n")!=std::string::npos||mediaName_.find('\0')!=std::string::npos)){
        showToast("Enter a SET name without folder separators",4500);return;}
    const auto target=mediaOverwriteConfirm_?mediaSaveTarget_:saveAs?files::join(mediaDirectory_,mediaName_+(mediaNativeSet(mediaName_)?"":".SVSET")):mediaCurrentSetPath_;
    if(target.empty()){mediaName_="My SET";editMediaSetName();return;}
    if(saveAs&&files::exists(target)&&!mediaOverwriteConfirm_){mediaSaveTarget_=target;mediaSaveTargetAs_=saveAs;mediaOverwriteConfirm_=true;dirty_=true;return;}
    mediaOverwriteConfirm_=false;finishPersistentSave(true);rememberStyleKeyboardSet();
    if(!saveKeyboardPerformanceMetadata(true)){showToast(keyboardMetadataError_,6500);return;}
    host::ArrangerStyleKeyboardLinks workingRefs{};std::string error;
    if(!selectedStyleKey_.empty())for(int position=0;position<4;++position){const auto index=static_cast<std::size_t>(position);auto state=keyboardWorkingSets_[index];
        if(!state.combi){if(keyboardSetPaths_[index].empty()&&keyboardSets_[index]<=0)continue;
            if(!prepareWorkingKeyboardSet(keyboardSetPaths_[index],keyboardSets_[index],state,error)){showToast(error,6500);return;}}
        auto name=keyboardSetNames_[index].empty()?state.combi->name:keyboardSetNames_[index];if(name.empty())name="Keyboard Set "+std::to_string(position+1);
        if(!freezeKeyboardWorkingSet(state,"MEDIA:"+target+":"+selectedStyleKey_,position,name,workingRefs[index].first,error)){showToast(error,6500);return;}
        workingRefs[index].second=name;
    }
    const auto session=persistentStateText();if(session.empty()||session.size()>2U*1024U*1024U){showToast("The current SET settings could not be captured",6500);return;}
    const auto parent=files::parentOf(persistentSessionPath_);std::map<std::string,std::string> resources;std::set<std::string> pending;
    for(const auto& name:files::listNames(parent))if(mediaMutableName(name))pending.insert(name);
    for(const auto& name:files::listNames(files::join(parent,"DrumKits"))){
        const auto resource=kMediaDrumPrefix+name;
        if(mediaDrumName(resource)&&files::isFile(mediaResourcePath(parent,resource)))pending.insert(resource);
    }
    for(const auto& name:mediaDependencies(session))pending.insert(name);
    if(!keyboardMetadataFile_.empty())pending.insert(keyboardMetadataFile_);
    for(const auto& ref:workingRefs)if(!ref.first.empty())pending.insert(files::nameOf(ref.first));
    std::size_t total=0;
    while(!pending.empty()){
        const auto name=*pending.begin();pending.erase(pending.begin());if(resources.count(name))continue;
        if(!mediaResourceName(name)||resources.size()>=4096U){showToast("The SET has too many saved resources",6500);return;}
        std::string bytes;if(!mediaReadFile(mediaResourcePath(parent,name),bytes)){showToast("A saved SET resource is missing or too large: "+name,6500);return;}
        if(mediaDrumName(name)&&!host::ArrangerHost::inspectDrumKitEdit(name.substr(kMediaDrumPrefix.size(),64U),bytes)){
            showToast("A saved Drum Kit edit could not be included in this SET",6500);return;
        }
        total+=bytes.size();if(total+session.size()>kMediaBundleMaximum-65536U){showToast("The SET settings exceed the supported file size",6500);return;}
        if(!endsWith(name,".SVSET"))for(const auto& dependency:mediaDependencies(bytes))if(!resources.count(dependency))pending.insert(dependency);
        resources.emplace(name,std::move(bytes));
    }
    std::string payload=kMediaMagic;mediaString(payload,parent);mediaString(payload,keyboardSamplerBankIdentity(ctrl_.currentBankFile()));mediaString(payload,session);mediaString(payload,selectedStyleKey_);
    mediaU32(payload,static_cast<std::uint32_t>(selectedKeyboardSet_+1));
    for(const auto& ref:workingRefs){mediaString(payload,ref.first);mediaString(payload,ref.second);}
    mediaU32(payload,static_cast<std::uint32_t>(resources.size()));for(const auto& resource:resources){mediaString(payload,resource.first);mediaString(payload,resource.second);}
    if(payload.size()>kMediaBundleMaximum){showToast("The SET settings exceed the supported file size",6500);return;}
    const auto saved=ctrl_.saveSetFile(target,kMediaExtraKey+mediaBase64(payload)+"\n");
    if(saved){showToast(*saved,7000);return;}
    rememberMediaSetPath(files::absolute(target));mediaName_.clear();listMediaDirectory(files::parentOf(target));
    mediaSaveTab_=true;showToast("SET saved: "+files::nameOf(target),5000);dirty_=true;
}
void ArrangerView::adoptLoadedSetPerformance(){
    liveListsDirty_=true;
    activeNativeKeyboardSetPath_.clear();activeSavedKeyboardEntryPath_.clear();keyboardSoundBindings_={};keyboardMetadataRestorePending_=false;
    keyboardFxOverride_={};keyboardFxWarning_.clear();keyboardSplitSuppressed_.fill(false);currentKeyboardCombiSlot_=0;currentKeyboardCombiBankIdentity_.clear();
    const auto recalled=ctrl_.engine.nativeKeyboardCombi();
    if(recalled)for(int part=0;part<7;++part){keyboardRangeLow_[static_cast<std::size_t>(part)]=recalled->part(part).keyLow;keyboardRangeHigh_[static_cast<std::size_t>(part)]=recalled->part(part).keyHigh;
        (void)host::arrangerHost().retainPreparedKeyboardSound(part,-1,-1,-1);}
    selectedKeyboardSet_=-1;scaleMainRemembered_=false;
    if(recalled){keyboardLowerMuteBeforeFull_=recalled->part(6).mute;auto state=captureKeyboardWorkingSet();state.recall.lowerMuteBeforeFull=keyboardLowerMuteBeforeFull_;
        state.metadataFile.clear();state.metadataBindings.clear();state.sourceIdentity.clear();(void)applyWorkingKeyboardSet(state,-1,true);}
    clearStyleKeyboardCue(false);keyboardRecallStyle_=arrangerStyleSelectionKey(host::arrangerHost().snapshot(selectedPlayer_));keyboardRecallElement_=host::arrangerHost().snapshot(selectedPlayer_).element;
}
void ArrangerView::loadMediaSelection(){
    // A queued second tap may still carry a hit from the previous frame.
    if(picker_!=Picker::Media)return;
    if(kstJob_||persistentRestoreActive_||mediaRestore_){picker_=Picker::KstProgress;dirty_=true;return;}
    const bool selected=mediaSelected_>=0&&mediaSelected_<static_cast<int>(mediaEntries_.size());
    if(!selected&&mediaSetRoot_.empty())return;
    if(styleKeyboardCue_.serial!=0||host::arrangerHost().snapshot(0).styleSwitchPending||host::arrangerHost().snapshot(1).styleSwitchPending){showToast("Wait for the Style change to finish",4500);return;}
    const Entry entry=selected?mediaEntries_[static_cast<std::size_t>(mediaSelected_)]:Entry{"",mediaDirectory_,true,mediaFolderTab_==0?3:mediaFolderTab_==2?4:1};
    if(entry.value==0&&entry.directory){listMediaDirectory(entry.path);return;}
    if(entry.value==1||entry.value==3||entry.value==4){
        const auto root=entry.value==1?entry.path:mediaSetRoot_;
        startKstScan(root);
        if(kstJob_&&kstJob_->rootPath==canonicalKstPath(root)){
            mediaLoadingSource_=kstJob_->rootPath;
            kstJob_->mediaTab=entry.value==3?0:entry.value==4?2:-1;
            if(!entry.directory)kstJob_->mediaBank=files::nameOf(files::parentOf(entry.path))+"/"+entry.name;
        }
        return;
    }
    auto loaded=sampler::SetPackage::load(entry.path);if(!loaded.ok()){showToast(loaded.error,7000);return;}
    const auto prepared=std::make_shared<const sampler::SetData>(std::move(loaded.data));
    const auto marker=prepared->extra.find(kMediaExtraKey);
    if(marker!=std::string::npos){(void)beginMediaRestore(entry.path,prepared);return;}
    rememberStyleKeyboardSet();const auto error=ctrl_.loadSetFile(entry.path,prepared);if(error){showToast(*error,6500);return;}
    adoptLoadedSetPerformance();rememberMediaSetPath(entry.path);rememberCurrentGlobalSettings();flushGlobalSettings();picker_=Picker::None;editor_=false;panelMode_=PanelMode::Home;navigationHistory_.clear();refresh();markPersistentStateChanged();showToast("SET loaded: "+entry.name+(globalSettingsSaveFailed_?" — GLOBAL changes were not saved":""),globalSettingsSaveFailed_?8000:4500);
}
bool ArrangerView::beginMediaRestore(const std::string& path,const std::shared_ptr<const sampler::SetData>& prepared){
    if(!prepared){showToast("The SET could not be read",5000);return false;}
    const auto& extra=prepared->extra;
    if(mediaRestore_||kstJob_||persistentRestoreActive_||styleKeyboardCue_.serial!=0){showToast("Wait for the current change to finish",4500);return false;}
    auto at=extra.find(kMediaExtraKey);if(at==std::string::npos||(at>0U&&extra[at-1U]!='\n')){showToast("The SET settings are invalid",6000);return false;}
    at+=kMediaExtraKey.size();const auto end=extra.find('\n',at);std::string payload;
    if(!mediaUnbase64(extra.substr(at,end==std::string::npos?end:end-at),payload)||
       (!startsWith(payload,kMediaMagic)&&!startsWith(payload,kMediaLegacyMagic))){showToast("The SET settings are invalid",6500);return false;}
    MediaReader reader{payload};reader.at=kMediaMagic.size();auto job=std::make_shared<MediaRestore>();job->path=path;job->preparedData=prepared;
    job->hasDrumSnapshot=startsWith(payload,kMediaMagic);
    job->origin=reader.string(65536U);job->bankIdentity=reader.string(65536U);job->session=reader.string(2U*1024U*1024U);job->owner=reader.string(65536U);const auto selected=reader.u32();
    if(selected>4U)reader.valid=false;
    job->selectedPosition=static_cast<int>(selected)-1;
    for(auto& ref:job->workingRefs){ref.first=reader.string(65536U);ref.second=reader.string(4096U);}
    const auto count=reader.u32();if(count>4096U)reader.valid=false;
    for(std::uint32_t i=0;reader.valid&&i<count;++i){auto name=reader.string(180U);auto bytes=reader.string(kMediaFileMaximum);
        if(!mediaResourceName(name)||!job->files.emplace(std::move(name),std::move(bytes)).second)reader.valid=false;}
    if(!reader.valid||reader.at!=payload.size()||job->session.empty()||job->origin!=files::parentOf(persistentSessionPath_)){
        showToast("This SET cannot be restored in this application location",7000);return false;}
    if(job->bankIdentity!=keyboardSamplerBankIdentity(ctrl_.currentBankFile())){showToast("Load this SET's original sound bank before selecting it",7000);return false;}
    const auto parent=files::parentOf(persistentSessionPath_);
    for(const auto& ref:job->workingRefs)if(!ref.first.empty()&&(files::parentOf(ref.first)!=parent||!job->files.count(files::nameOf(ref.first)))){
        showToast("A saved Keyboard Set reference is invalid",7000);return false;}
    const auto plain=[](const std::string& text,std::size_t maximum){return text.size()<=maximum&&text.find('\0')==std::string::npos&&text.find_first_of("\r\n")==std::string::npos;};
    const auto hexadecimal=[](const std::string& value,std::size_t length){return value.size()==length&&std::all_of(value.begin(),value.end(),[](unsigned char c){return std::isxdigit(c)!=0;});};
    struct StyleIdentity {std::string path,identity,name;};std::map<std::string,StyleIdentity> styleIdentities;
    std::map<std::string,std::string> metadataOwners;
    const auto invalid=[this]{showToast("A saved SET entry is damaged or has invalid references",7000);return false;};
    for(const auto& resource:job->files)if(mediaDrumName(resource.first)){
        if(!job->hasDrumSnapshot||!host::ArrangerHost::inspectDrumKitEdit(resource.first.substr(kMediaDrumPrefix.size(),64U),resource.second))return invalid();
    }
    // Typed validation also covers entries not selected by the current players.
    for(const auto& resource:job->files){const auto& name=resource.first;if(!endsWith(name,".svstyle"))continue;
        StyleIdentity identity;host::ArrangerStyleKeyboardLinks links;
        if(!host::ArrangerHost::inspectStyleRevision(name,resource.second,identity.path,identity.identity,identity.name,links))return invalid();
        for(const auto& link:links){
            const auto& pathRef=link.first;
            if(!pathRef.empty()&&(files::parentOf(pathRef)!=parent||!startsWith(files::nameOf(pathRef),"ARRANGER_STYLE_KBD_")||
                                 !job->files.count(files::nameOf(pathRef))))return invalid();
        }
        styleIdentities.emplace(name,std::move(identity));
    }
    for(const auto& resource:job->files){const auto& name=resource.first;if(!endsWith(name,".ref"))continue;
        std::istringstream in(resource.second);std::string magic,display,pathRef,identity,revision;int version=0,bank=0,position=0;
        if(!(in>>magic>>version>>bank>>position>>std::quoted(display)>>std::quoted(pathRef)>>std::quoted(identity)>>std::quoted(revision))||version!=1||
           !plain(display,256U)||display.empty()||!plain(pathRef,65536U)||bank<0||bank>16)return invalid();
        in>>std::ws;if(!in.eof())return invalid();
        if(startsWith(name,"ARRANGER_USER_STYLE_")||startsWith(name,"ARRANGER_STYLE_SOURCE_")){
            if(magic!="SILVETON_STYLE_POINTER"||position<0||position>128||((bank==0)!=(position==0))||!hexadecimal(identity,64U)||!styleIdentities.count(revision))return invalid();
            const auto& declared=styleIdentities.at(revision);if(declared.path!=pathRef||declared.identity!=identity)return invalid();
            if(bank==0){if(name!="ARRANGER_STYLE_SOURCE_"+identity+".ref")return invalid();}
            else {std::ostringstream expected;expected<<"ARRANGER_USER_STYLE_"<<std::setfill('0')<<std::setw(2)<<bank<<'_'<<std::setw(3)<<position<<".ref";if(name!=expected.str())return invalid();}
        }else{
            if(magic!="SILVETON_USER_KEYBOARD_SET"||position<1||position>128||identity.size()>1024U*1024U||!keyboardMetadataFileNameValid(revision)||!job->files.count(revision))return invalid();
            if(startsWith(name,"ARRANGER_USER_KBD_")){if(bank<1||name!=keyboardLibraryEntryName(bank,position))return invalid();}
            else if(bank!=0)return invalid();
            if(startsWith(name,"ARRANGER_NATIVE_KBD_")){
                std::istringstream native(identity);std::string nativeMagic,tag,bankIdentity,hash;int nativeVersion=0,slot=0;std::uint64_t bytes=0;
                if(!pathRef.empty()||position!=1||!(native>>nativeMagic>>nativeVersion>>tag)||nativeMagic!="SILVETON_NATIVE_COMBI"||nativeVersion!=1||tag!="BANK"||
                   !(native>>std::quoted(bankIdentity)>>tag>>slot)||tag!="SLOT"||bankIdentity.empty()||slot<1||slot>500||
                   !(native>>tag>>bytes)||tag!="BYTES"||bytes==0U||!(native>>tag>>hash)||tag!="REVISION"||!hexadecimal(hash,16U))return invalid();
                native>>std::ws;if(!native.eof())return invalid();
            }else if(pathRef.empty()){
                if(identity!="SILVETON_ASSEMBLED_KEYBOARD_SET 1\nREVISION "+revision)return invalid();
            }else{
                std::istringstream original(identity);std::string sourceMagic,tag,sourcePath,hash;int sourceVersion=0;std::uint64_t sourceBytes=0;
                if(!(original>>sourceMagic>>sourceVersion>>tag>>std::quoted(sourcePath))||sourceMagic!="SILVETON_KEYBOARD_FX_SOURCE"||sourceVersion!=1||tag!="PATH"||
                   sourcePath!=files::absolute(pathRef)||!(original>>tag>>sourceBytes)||tag!="BYTES"||sourceBytes==0U||sourceBytes>64U*1024U*1024U||
                   !(original>>tag>>hash)||tag!="REVISION"||!hexadecimal(hash,16U))return invalid();
                std::set<int> roles;
                for(int part=0;part<4;++part){int role=0,present=0,known=0,msb=0,lsb=0,program=0;std::string soundPath;
                    if(!(original>>tag>>role>>present>>known>>msb>>lsb>>program>>std::quoted(soundPath))||tag!="PART"||role<1||role>4||!roles.insert(role).second||
                       (present!=0&&present!=1)||(known!=0&&known!=1)||msb< -1||msb>127||lsb< -1||lsb>127||program< -1||program>127||
                       (known&&(msb<0||lsb<0||program<0))||!plain(soundPath,65536U))return invalid();}
                original>>std::ws;if(!original.eof())return invalid();
            }
            const auto existingOwner=metadataOwners.find(revision);
            if(existingOwner!=metadataOwners.end()&&existingOwner->second!=pathRef)return invalid();
            metadataOwners[revision]=pathRef;
        }
    }
    // Install only immutable content before activation. Existing revisions must match byte-for-byte.
    for(const auto& resource:job->files){if(mediaMutableName(resource.first)||mediaDrumName(resource.first))continue;const auto destination=files::join(parent,resource.first);std::string previous;
        if(files::exists(destination)){if(!mediaReadFile(destination,previous)||previous!=resource.second){showToast("A saved SET revision conflicts with an existing resource",7000);return false;}}
        else if(!mediaAtomicWrite(destination,resource.second)){showToast("The SET resources could not be prepared",7000);return false;}
        if(endsWith(resource.first,".SVSET")){sampler::SetLoadResult metadata;StoredKeyboardMetadata stored;std::string error;
            if(!loadKeyboardMetadataPackage(destination,metadata,stored,error)){showToast(error,7000);return false;}
            const auto declaredOwner=metadataOwners.find(resource.first);
            if(declaredOwner!=metadataOwners.end()&&declaredOwner->second!=stored.sourcePath)return invalid();}
    }
    finishPersistentSave(true);rememberStyleKeyboardSet();
    if(!saveKeyboardPerformanceMetadata(true)){showToast(keyboardMetadataError_,7000);return false;}
    job->beforeSession=persistentStateText();job->beforeHost=host::arrangerHost().persistentSession();job->beforeSettings=ctrl_.setSettingsSnapshot();job->beforeSetPath=mediaCurrentSetPath_;
    job->beforeKeyboard=captureKeyboardWorkingSet();job->beforeWorking=keyboardWorkingSets_;job->beforeSlots=keyboardSets_;job->beforePaths=keyboardSetPaths_;job->beforeNames=keyboardSetNames_;job->beforePosition=selectedKeyboardSet_;job->beforeStyleKey=selectedStyleKey_;
    job->beforeRoot=savedKstRoot_;job->beforeCatalog=kstCatalog_;job->beforeReport=kstReport_;job->beforeClasses=sampleClasses_;job->beforeSamples=sampleSummary_;job->beforePcm=kstPcmFiles_;job->checkpoint=ctrl_.engine.nativePerformanceCheckpoint();job->sourceCheckpoint=host::arrangerHost().sourceCheckpoint();
    if(job->beforeSession.empty()||!job->checkpoint||!job->sourceCheckpoint){showToast("The current SET could not be retained",6500);return false;}
    if(!readPersistentStateText(job->session)){(void)readPersistentStateText(job->beforeSession);persistentRestoreUi_.reset();keyboardMetadataRestorePending_=false;persistentRestorePending_=false;showToast("The saved SET session is invalid",6500);return false;}
    const auto& ui=persistentRestoreUi_;
    const bool matchingOwner=ui&&(job->selectedPosition>=0?
        !job->owner.empty()&&!job->workingRefs[static_cast<std::size_t>(job->selectedPosition)].first.empty()&&ui->styleKeyboardPosition==job->selectedPosition&&ui->styleKeyboardOwner==job->owner:
        ui->styleKeyboardPosition<0);
    if(!matchingOwner){(void)readPersistentStateText(job->beforeSession);persistentRestoreUi_.reset();keyboardMetadataRestorePending_=false;showToast("The SET Keyboard Set owner is invalid",7000);return false;}
    std::string error;
    const auto addMetadataRoots=[&](const std::string& filename){
        if(filename.empty())return true;
        sampler::SetLoadResult metadata;StoredKeyboardMetadata stored;std::string reason;
        if(!loadKeyboardMetadataPackage(keyboardPerformancePath(persistentSessionPath_,filename),metadata,stored,reason)){error=reason;return false;}
        const auto add=[&](const std::string& source){const auto root=keyboardContainingSetRoot(source);if(!root.empty()&&std::find(job->roots.begin(),job->roots.end(),root)==job->roots.end())job->roots.push_back(root);};
        add(stored.sourcePath);for(const auto& binding:stored.bindings)if(keyboardAddressComplete(binding))add(binding.sourcePath);return true;
    };
    if(!addMetadataRoots(keyboardMetadataFile_)){(void)readPersistentStateText(job->beforeSession);persistentRestoreUi_.reset();keyboardMetadataRestorePending_=false;showToast(error,7000);return false;}
    for(const auto& ref:job->workingRefs)if(!ref.first.empty()){SavedKeyboardEntry saved;std::string reason;
        if(!readSavedKeyboardEntry(ref.first,saved,reason)||!addMetadataRoots(saved.metadataFile)){(void)readPersistentStateText(job->beforeSession);persistentRestoreUi_.reset();keyboardMetadataRestorePending_=false;showToast(reason.empty()?error:reason,7000);return false;}}
    mediaRestore_=job;clearStyleKeyboardCue(false);pendingKeyboardSet_=-1;keyboardRecallStyle_.clear();keyboardRecallElement_=-1;
    if(job->hasDrumSnapshot){
        // Kit overlays must be present before bank preparation resolves Style
        // and Keyboard Programs. Keep the prior files for the same rollback
        // transaction as the pinned source bank and performance checkpoint.
        std::set<std::string> names;
        for(const auto& name:files::listNames(files::join(parent,"DrumKits"))){
            const auto resource=kMediaDrumPrefix+name;
            if(mediaDrumName(resource)&&files::isFile(mediaResourcePath(parent,resource)))names.insert(resource);
        }
        for(const auto& resource:job->files)if(mediaDrumName(resource.first))names.insert(resource.first);
        for(const auto& name:names){const auto destination=mediaResourcePath(parent,name);std::string previous;
            if(files::exists(destination)){
                if(!mediaReadFile(destination,previous)){failMediaRestore("The current Drum Kit edits could not be retained");return false;}
                job->drumBackups[name]=std::move(previous);
            }else job->drumBackups[name]=std::nullopt;
        }
        if(!names.empty()&&!files::makeDirectories(files::join(parent,"DrumKits"))){failMediaRestore("Drum Kit storage is unavailable");return false;}
        job->drumsChanged=true;
        for(const auto& name:names){const auto found=job->files.find(name);const auto destination=mediaResourcePath(parent,name);
            const bool restored=found==job->files.end()?files::removeRecursively(destination):mediaAtomicWrite(destination,found->second);
            if(!restored){failMediaRestore("The saved Drum Kit edits could not be restored");return false;}
        }
    }
    kstProgress_={0,0,"Loading SET",path};picker_=Picker::KstProgress;editor_=false;dirty_=true;
    persistentRestorePending_=true;persistentRestoreRetry_=true;persistentSaveAllowed_=false;persistentRecordProtected_=true;
    resumePersistentState();
    // Permission or startup readiness can defer the restore before a worker
    // owns it. Never leave the staged kit collection behind on that path.
    if(mediaRestore_&&!persistentRestoreActive_&&!kstJob_){
        failMediaRestore("SET loading could not start; check storage access and select Load again");return false;
    }
    return mediaRestore_!=nullptr;
}
std::vector<std::string> ArrangerView::mediaRestoreSetRoots() const{return mediaRestore_?mediaRestore_->roots:std::vector<std::string>{};}
bool ArrangerView::prepareMediaRestore(){
    const auto job=mediaRestore_;if(!job)return true;if(job->nativeLoaded)return true;
    const auto error=ctrl_.loadSetFile(job->path,job->preparedData);if(error){failMediaRestore(*error);return false;}
    job->nativeLoaded=true;
    for(std::size_t i=0;i<job->workingRefs.size();++i){const auto& ref=job->workingRefs[i];if(ref.first.empty())continue;std::string reason;
        if(!prepareWorkingKeyboardSet(ref.first,0,job->working[i],reason)){failMediaRestore(reason);return false;}}
    return true;
}
bool ArrangerView::finishMediaRestore(){
    const auto job=mediaRestore_;if(!job)return true;const auto parent=files::parentOf(persistentSessionPath_);
    std::set<std::string> names;for(const auto& name:files::listNames(parent))if(mediaMutableName(name))names.insert(name);
    for(const auto& resource:job->files)if(mediaMutableName(resource.first))names.insert(resource.first);
    for(const auto& name:names){const auto path=files::join(parent,name);std::string previous;
        if(files::exists(path)){if(!mediaReadFile(path,previous)){failMediaRestore("A current SET entry could not be retained");return false;}job->pointerBackups[name]=std::move(previous);}
        else job->pointerBackups[name]=std::nullopt;}
    job->pointersChanged=true;
    for(const auto& name:names){const auto found=job->files.find(name);const auto path=files::join(parent,name);
        if(found==job->files.end()){if(!files::removeRecursively(path)){failMediaRestore("The old SET entries could not be replaced");return false;}}
        else if(!mediaAtomicWrite(path,found->second)){failMediaRestore("The saved SET entries could not be restored");return false;}}
    // The four exported working copies are not writes to named Style resources.
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);const auto owner=arrangerStyleSelectionKey(player);
    if(!job->owner.empty()&&job->owner!=owner){failMediaRestore("The saved keyboard buffers belong to another Style");return false;}
    selectedStyleKey_.clear();selectStyleLinks();
    if(!job->owner.empty())for(std::size_t i=0;i<4;++i){keyboardSetPaths_[i]=job->workingRefs[i].first;keyboardSets_[i]=0;keyboardSetNames_[i]=job->workingRefs[i].second;keyboardWorkingSets_[i]=job->working[i];}
    selectedKeyboardSet_=job->selectedPosition;clearStyleKeyboardCue(false);pendingKeyboardSet_=-1;keyboardRecallStyle_=owner;keyboardRecallElement_=player.element;
    liveListsDirty_=true;savedKeyboardLibraryDirty_=true;savedStyleEntries_=host::arrangerHost().savedStyleEdits();rememberMediaSetPath(job->path);
    mediaRestore_.reset();rememberCurrentGlobalSettings();flushGlobalSettings();showToast("SET loaded: "+files::nameOf(job->path)+(globalSettingsSaveFailed_?" — GLOBAL changes were not saved":""),globalSettingsSaveFailed_?8000:5000);return true;
}
void ArrangerView::failMediaRestore(const std::string& reason){
    const auto job=std::move(mediaRestore_);if(!job)return;
    const auto parent=files::parentOf(persistentSessionPath_);bool okay=true;
    if(job->pointersChanged)for(const auto& entry:job->pointerBackups){const auto path=files::join(parent,entry.first);
        okay=(entry.second?mediaAtomicWrite(path,*entry.second):files::removeRecursively(path))&&okay;}
    if(job->drumsChanged)for(const auto& entry:job->drumBackups){const auto path=mediaResourcePath(parent,entry.first);
        okay=(entry.second?mediaAtomicWrite(path,*entry.second):files::removeRecursively(path))&&okay;}
    if(job->nativeLoaded){okay=ctrl_.engine.nativeRestorePerformanceCheckpoint(job->checkpoint)&&okay;okay=ctrl_.restoreSetSettingsSnapshot(job->beforeSettings)&&okay;}
    // Previous source banks remain pinned by the restore lease until rollback finishes.
    okay=host::arrangerHost().restoreSourceCheckpoint(job->sourceCheckpoint)&&okay;
    (void)readPersistentStateText(job->beforeSession);
    if(persistentRestoreUi_){auto ui=std::move(*persistentRestoreUi_);persistentRestoreUi_.reset();selectedPlayer_=ui.selectedPlayer;kstCatalogTab_=ui.catalogTab;mixerStyle_=ui.mixerStyle;
        pickerDirectory_=std::move(ui.pickerDirectory);styleSelectStates_=std::move(ui.selectors);keyboardSetLinks_=std::move(ui.keyboardLinks);nativeKeyboardSetLinks_=std::move(ui.nativeKeyboardLinks);
        styleToKeyboardSet_=ui.styleToKeyboardSet;keyboardSetNextMeasure_=ui.keyboardSetNextMeasure;upperVolumeLink_=ui.upperVolumeLink;}
    kstCatalog_=job->beforeCatalog;kstReport_=job->beforeReport;sampleClasses_=std::move(job->beforeClasses);filterSamples(false,0);sampleSummary_=job->beforeSamples;kstPcmFiles_=job->beforePcm;savedKstRoot_=job->beforeRoot;
    selectedStyleKey_=job->beforeStyleKey;keyboardWorkingSets_=job->beforeWorking;keyboardSets_=job->beforeSlots;keyboardSetPaths_=job->beforePaths;keyboardSetNames_=job->beforeNames;selectedKeyboardSet_=-1;
    okay=applyWorkingKeyboardSet(job->beforeKeyboard,job->beforePosition,false)&&okay;keyboardWorkingSets_=job->beforeWorking;
    if(persistentRestoreLease_)host::arrangerHost().cancelPersistentSessionRestore();
    persistentRestoreLease_=false;persistentRestoreActive_=false;persistentHostPosted_=false;persistentRestorePending_=false;persistentRestoreRoots_.clear();persistentRestoreNext_=0;persistentSaveAllowed_=true;
    clearStyleKeyboardCue(false);keyboardRecallStyle_=job->beforeStyleKey;keyboardRecallElement_=host::arrangerHost().snapshot(selectedPlayer_).element;
    mediaCurrentSetPath_=job->beforeSetPath;mediaSaveTab_=false;picker_=Picker::Media;editor_=false;savedKeyboardLibraryDirty_=true;refresh();dirty_=true;
    showToast((reason.empty()?"SET loading failed":reason)+(okay?" — current SET kept":" — previous SET could not be fully restored"),9000);
}
