// GLOBAL edits use current whole-instrument state, never a Keyboard Set copy.
void ArrangerView::openGlobalPage(GlobalPage page){
    rememberNavigation();globalPage_=page;picker_=Picker::SettingsMenu;
    panelMode_=PanelMode::Settings;editor_=false;held_={};dirty_=true;
}
bool ArrangerView::changeGlobalSettings(const std::function<void(SamplerAppController::GlobalUiState&)>& change){
    if(globalSettingsRestorePending_)restoreSavedGlobalSettings();
    auto state=ctrl_.globalUiState();
    if(!state){showToast("GLOBAL settings are unavailable",5000);return false;}
    change(*state);
    if(!ctrl_.updateGlobalUi(*state)){showToast(ctrl_.lastFailure(),6000);return false;}
    globalUi_=*state;rememberCurrentGlobalSettings();markPersistentStateChanged();dirty_=true;return true;
}
bool ArrangerView::changeGlobalMidi(const std::function<void(SamplerAppController::GlobalAdvanced&)>& change){
    if(globalSettingsRestorePending_)restoreSavedGlobalSettings();
    auto state=ctrl_.globalAdvanced();
    if(!state){showToast("GLOBAL MIDI settings are unavailable",5000);return false;}
    change(*state);
    if(!ctrl_.updateGlobalAdvanced(*state)){showToast(ctrl_.lastFailure(),6000);return false;}
    rememberCurrentGlobalSettings();markPersistentStateChanged();dirty_=true;return true;
}
void ArrangerView::drawSettingsMenu(Canvas& c){
    if(globalPage_!=GlobalPage::Menu){drawGlobalSettingsPage(c);return;}
    box(c,{0,0,800,480},bg);
    label(c,"GLOBAL",20,35,27,white,true,620);
    button(c,{660,5,784,49},"‹ Back",orange,false,true,[this]{panelExit();},20);
    label(c,"Settings for the whole instrument",20,78,20,dim,true,760);
    const auto tile=[&](int column,int row,const std::string& title,const std::function<void()>& action){
        const float x=20.0F+390.0F*static_cast<float>(column),y=98.0F+105.0F*static_cast<float>(row);
        button(c,{x,y,x+370,y+89},title,column==0?orange:green,false,true,action,24);
    };
    tile(0,0,"General Controls",[this]{openGlobalPage(GlobalPage::General);});
    tile(1,0,"Controllers",[this]{openGlobalPage(GlobalPage::Controllers);});
    tile(0,1,"MIDI Input",[this]{openGlobalPage(GlobalPage::MidiInput);});
    tile(1,1,"Master EQ / Limiter",[this]{openGlobalPage(GlobalPage::MasterEq);});
    tile(0,2,"Arranger Preferences",[this]{rememberNavigation();picker_=Picker::ArrangerControl;editor_=false;dirty_=true;});
    tile(1,2,"Audio / Graphics Info",[this]{showPerformanceDiagnostics();});
    const char* status=globalSettingsRecordProtected_?"Stored GLOBAL settings are unreadable":globalSettingsRestoreFailed_?"Saved GLOBAL settings are waiting to be restored":globalSettingsSaveFailed_?"GLOBAL changes are not saved":globalSettingsDirty_?"Saving GLOBAL changes…":"GLOBAL changes are saved automatically";
    label(c,status,20,455,13,(globalSettingsSaveFailed_||globalSettingsRestoreFailed_||globalSettingsRecordProtected_)?orange:dim,false,554);
    button(c,{593,429,784,473},"Save Global",green,false,true,[this]{rememberCurrentGlobalSettings();flushGlobalSettings();},15);
}
void ArrangerView::drawGlobalSettingsPage(Canvas& c){
    using Global=SamplerAppController::GlobalUiState;
    using Midi=SamplerAppController::GlobalAdvanced;
    box(c,{0,0,800,480},bg);
    const char* title=globalPage_==GlobalPage::General?"General Controls":globalPage_==GlobalPage::Controllers?"Controllers":globalPage_==GlobalPage::MidiInput?"MIDI Input":"Master EQ / Limiter";
    label(c,std::string("GLOBAL  /  ")+title,20,34,24,white,true,625);
    button(c,{660,5,784,49},"Back",orange,false,true,[this]{panelExit();},20);
    const auto state=ctrl_.globalUiState();const auto midi=ctrl_.globalAdvanced();
    if(!state||!midi){label(c,"GLOBAL settings are unavailable",20,107,18,orange,true,760);return;}
    const auto cell=[](int index){const float x=20.0F+390.0F*static_cast<float>(index%2),y=67.0F+110.0F*static_cast<float>(index/2);return RectF{x,y,x+370,y+100};};
    const auto numeric=[&](int index,const std::string& name,float value,const std::string& text,float lo,float hi,float step,
            const std::function<float(const Global&)>& read,const std::function<void(Global&,float)>& write){
        const auto r=cell(index);box(c,r,panel,kBorder,2);label(c,name,r.left+13,r.top+23,18,dim,true,344);
        label(c,text,r.left+13,r.top+59,25,white,true,238);
        const auto adjust=[this,read,write,lo,hi](float delta){changeGlobalSettings([read,write,lo,hi,delta](Global& current){write(current,std::clamp(read(current)+delta,lo,hi));});};
        button(c,{r.left+258,r.top+33,r.left+303,r.top+69},"−",green,false,value>lo,[adjust,step]{adjust(-step);},22,true);
        button(c,{r.left+312,r.top+33,r.right-13,r.top+69},"+",green,false,value<hi,[adjust,step]{adjust(step);},22,true);
        const float position=std::clamp((value-lo)/(hi-lo),0.0F,1.0F);
        box(c,{r.left+14,r.top+82,r.right-14,r.top+87},key);
        box(c,{r.left+14,r.top+82,r.left+14+342*position,r.top+87},green);
        hit({r.left+10,r.top+73,r.right-10,r.bottom-2},{},[this,r,lo,hi,step,write](float x,float){
            const float fraction=std::clamp((x-r.left-14)/342.0F,0.0F,1.0F);
            const float valueNow=std::clamp(lo+std::round(fraction*(hi-lo)/step)*step,lo,hi);
            changeGlobalSettings([write,valueNow](Global& current){write(current,valueNow);});
        });
    };
    const auto toggle=[&](int index,const std::string& name,bool on,const std::function<void()>& action){
        const auto r=cell(index);box(c,r,panel,kBorder,2);label(c,name,r.left+13,r.top+29,19,dim,true,344);
        button(c,{r.left+13,r.top+46,r.right-13,r.bottom-11},on?"On":"Off",green,on,true,action,20,true);
    };
    // These safety messages are consumed before assignable CC routing.
    const auto assignableCc=[](int current,float value){
        int next=std::clamp(static_cast<int>(std::lround(value)),0,127);
        while(next==120||next==123)next+=next<current?-1:1;
        return next;
    };
    if(globalPage_==GlobalPage::General){
        numeric(0,"Master Tune",state->masterTuneHz,fmtFixed(state->masterTuneHz,1)+" Hz",400,480,0.1F,[](const Global& g){return g.masterTuneHz;},[](Global& g,float v){g.masterTuneHz=v;});
        numeric(1,"Master Transpose",static_cast<float>(state->transpose),signedNumber(state->transpose),-12,12,1,[](const Global& g){return static_cast<float>(g.transpose);},[](Global& g,float v){g.transpose=static_cast<int>(std::lround(v));});
        label(c,"Velocity Level Curve",20,214,17,dim,true,760);
        static const char* curves[]={"Linear","Soft","Hard","Fixed"};
        for(int index=0;index<4;++index){const float x=20.0F+195.0F*static_cast<float>(index);
            const bool selected=state->velocityCurve==index||(index==0&&state->velocityCurve==4);
            button(c,{x,234,x+175,301},curves[index],green,selected,true,[this,index]{changeGlobalSettings([index](Global& g){g.velocityCurve=index;});},19,true);
        }
        label(c,"The curve changes note level; Sound velocity layers keep their own settings.",20,341,14,dim,false,760);
    }else if(globalPage_==GlobalPage::Controllers){
        // Raw input values show whether the actual hardware sends each CC.
        const auto inputLabel=[this](const std::string& name,int cc){
            const int value=ctrl_.midiCcValue(cc);
            return name+"  |  In: "+(value<0?std::string("--"):std::to_string(value));
        };
        numeric(0,inputLabel("Breath CC",state->breathCc),static_cast<float>(state->breathCc),"CC "+std::to_string(state->breathCc),0,127,1,[](const Global& g){return static_cast<float>(g.breathCc);},[assignableCc](Global& g,float v){g.breathCc=assignableCc(g.breathCc,v);});
        numeric(1,inputLabel("Expression CC",state->expressionCc),static_cast<float>(state->expressionCc),"CC "+std::to_string(state->expressionCc),0,127,1,[](const Global& g){return static_cast<float>(g.expressionCc);},[assignableCc](Global& g,float v){g.expressionCc=assignableCc(g.expressionCc,v);});
        numeric(2,inputLabel("Damper CC",state->damperCc),static_cast<float>(state->damperCc),"CC "+std::to_string(state->damperCc),0,127,1,[](const Global& g){return static_cast<float>(g.damperCc);},[assignableCc](Global& g,float v){g.damperCc=assignableCc(g.damperCc,v);});
        toggle(3,"Damper Polarity Reversed",midi->damperReversed,[this]{changeGlobalMidi([](Midi& current){current.damperReversed=!current.damperReversed;});});
        toggle(4,"Pitch Bend to Pitch",state->pitchBendEnabled,[this]{changeGlobalSettings([](Global& current){current.pitchBendEnabled=!current.pitchBendEnabled;});});
        toggle(5,"Aftertouch Input",state->aftertouchEnabled,[this]{changeGlobalSettings([](Global& current){current.aftertouchEnabled=!current.aftertouchEnabled;});});
    }else if(globalPage_==GlobalPage::MasterEq){
        numeric(0,"Master Gain",state->masterGainDb,fmtFixed(state->masterGainDb,1)+" dB",-60,6,0.5F,[](const Global& g){return g.masterGainDb;},[](Global& g,float v){g.masterGainDb=v;});
        numeric(1,"EQ Low",state->eqLowDb,fmtFixed(state->eqLowDb,1)+" dB",-18,18,0.5F,[](const Global& g){return g.eqLowDb;},[](Global& g,float v){g.eqLowDb=v;});
        numeric(2,"EQ Mid",state->eqMidDb,fmtFixed(state->eqMidDb,1)+" dB",-18,18,0.5F,[](const Global& g){return g.eqMidDb;},[](Global& g,float v){g.eqMidDb=v;});
        numeric(3,"EQ High",state->eqHighDb,fmtFixed(state->eqHighDb,1)+" dB",-18,18,0.5F,[](const Global& g){return g.eqHighDb;},[](Global& g,float v){g.eqHighDb=v;});
        toggle(4,"Limiter",state->limiterEnabled,[this]{changeGlobalSettings([](Global& current){current.limiterEnabled=!current.limiterEnabled;});});
        numeric(5,"Limiter Ceiling",state->limiterCeilingDb,fmtFixed(state->limiterCeilingDb,1)+" dB",-12,0,0.5F,[](const Global& g){return g.limiterCeilingDb;},[](Global& g,float v){g.limiterCeilingDb=v;});
    }else{
        label(c,"Receive MIDI Channels",20,80,17,dim,true,760);
        for(int channel=0;channel<16;++channel){const float x=20.0F+97.5F*static_cast<float>(channel%8),y=95.0F+59.0F*static_cast<float>(channel/8);
            const int bit=1<<channel;button(c,{x,y,x+85,y+47},std::to_string(channel+1),green,(midi->midiInMask&bit)!=0,true,[this,bit]{changeGlobalMidi([bit](Midi& current){current.midiInMask^=bit;});},19,true);
        }
        label(c,"Input Filters  /  Block disables the listed input action",20,238,16,dim,true,760);
        static const char* filters[]={"Notes","Control Change","Bend to Pitch","Aftertouch"};
        const std::array<bool,4> blocked{{midi->filterNotes,midi->filterCc,midi->filterBend,midi->filterAftertouch}};
        for(int filter=0;filter<4;++filter){const float x=20.0F+195.0F*static_cast<float>(filter);
            button(c,{x,255,x+175,325},std::string(filters[filter])+(blocked[static_cast<std::size_t>(filter)]?": Block":": Pass"),green,blocked[static_cast<std::size_t>(filter)],true,[this,filter]{changeGlobalMidi([filter](Midi& current){
                if(filter==0)current.filterNotes=!current.filterNotes;else if(filter==1)current.filterCc=!current.filterCc;
                else if(filter==2)current.filterBend=!current.filterBend;else current.filterAftertouch=!current.filterAftertouch;
            });},15,true);
        }
    }
    const char* scope=globalPage_==GlobalPage::MidiInput?"External MIDI input; Style playback keeps its own tracks":
        globalPage_==GlobalPage::Controllers?"In: last received MIDI value; -- means no message received":"Applies to the whole instrument";
    const char* status=globalSettingsRecordProtected_?"Stored GLOBAL settings are unreadable":globalSettingsRestoreFailed_?"Saved GLOBAL settings are waiting to be restored":globalSettingsSaveFailed_?"GLOBAL changes are not saved":globalSettingsDirty_?"Saving GLOBAL changes…":scope;
    label(c,status,20,421,13,(globalSettingsSaveFailed_||globalSettingsRestoreFailed_||globalSettingsRecordProtected_)?orange:dim,false,760);
    button(c,{20,437,385,477},"Global Menu",orange,false,true,[this]{panelMenu();},15);
    button(c,{410,437,780,477},"Save Global",green,false,true,[this]{rememberCurrentGlobalSettings();flushGlobalSettings();},15);
}

void ArrangerView::drawArrangerSettings(Canvas& c){
    box(c,{0,0,800,480},bg);
    label(c,"ARRANGER SETTINGS",20,31,21,white,true,340);
    button(c,{370,4,670,48},"Velocity Control",green,false,true,[this]{rememberNavigation();picker_=Picker::VelocityControl;dirty_=true;},17);
    button(c,{686,6,784,42},"‹ Back",orange,false,true,[this]{panelExit();},14);
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    const auto control=[this](bool accepted){controlRequested(accepted);dirty_=true;};
    button(c,{20,55,386,94},"Player 1",orange,selectedPlayer_==0,true,[this]{setPlayerFocus(0);},16);
    button(c,{402,55,784,94},"Player 2",blue,selectedPlayer_==1,true,[this]{setPlayerFocus(1);},16);
    button(c,{20,112,386,151},"Auto Fill (global)",orange,player.autoFill,true,[this,control]{control(host::arrangerHost().toggleAutoFill(selectedPlayer_));},15);
    button(c,{402,112,784,151},player.autoFillMode==0?"Fill: Current Variation":"Fill: Target Variation",orange,false,true,[control]{control(host::arrangerHost().cycleAutoFillMode());},15);
    button(c,{20,161,386,200},"Synchro Start",orange,player.syncStart,player.syncStart||(player.loaded&&player.soundAssignmentsReady),[this,control]{control(host::arrangerHost().toggleSyncStart(selectedPlayer_));},15);
    button(c,{402,161,784,200},"Synchro Stop",orange,player.syncStop,player.loaded,[this,control]{control(host::arrangerHost().toggleSyncStop(selectedPlayer_));},15);
    button(c,{20,210,386,249},"Synchro Start Auto Off (global)",orange,player.syncStartAutoOff,true,[control]{control(host::arrangerHost().toggleSyncStartAutoOff());},14);
    const bool variation=player.element>=3&&player.element<=6;
    button(c,{402,210,784,249},variation?"Variation: Loop":player.loopElement==player.element?"Section Loop: On":"Section Loop: Off",orange,variation||player.loopElement==player.element,player.loaded&&!variation,[this,control]{control(host::arrangerHost().toggleSectionLoop(selectedPlayer_));},15);
    button(c,{20,259,386,298},player.fadeDirection>0?"Fade In…":player.fadeDirection<0?"Fade Out…":"Player Fade In / Out",green,player.fadeDirection!=0,player.loaded&&player.soundAssignmentsReady,[this,control]{control(host::arrangerHost().toggleFade(selectedPlayer_));},16);
    label(c,"Fade times (global)",593,275,13,dim,false,370,Align::Center);
    label(c,"In "+fmtFixed(player.fadeInSeconds,1)+"s / Out "+fmtFixed(player.fadeOutSeconds,1)+"s",593,296,14,white,false,370,Align::Center);
    button(c,{20,310,194,348},"In −0.5s",green,false,player.fadeInSeconds>0.1F,[control]{control(host::arrangerHost().adjustFadeTimes(-0.5F,0.0F));},14);
    button(c,{211,310,386,348},"In +0.5s",green,false,player.fadeInSeconds<60.0F,[control]{control(host::arrangerHost().adjustFadeTimes(0.5F,0.0F));},14);
    button(c,{402,310,585,348},"Out −0.5s",green,false,player.fadeOutSeconds>0.1F,[control]{control(host::arrangerHost().adjustFadeTimes(0.0F,-0.5F));},14);
    button(c,{602,310,784,348},"Out +0.5s",green,false,player.fadeOutSeconds<60.0F,[control]{control(host::arrangerHost().adjustFadeTimes(0.0F,0.5F));},14);
    label(c,"Assign alternative scale (global)",20,380,15,dim,true,764);
    static const char* scopeNames[]={"Keyboard Tracks","Upper Tracks","All: Keyboard Priority"};
    for(int scope=0;scope<3;++scope){const float x=20.0F+static_cast<float>(scope)*258.0F;
        button(c,{x,391,x+248,432},scopeNames[scope],green,player.scaleAssignment==scope,true,[this,scope]{
            if(!host::arrangerHost().setScaleAssignment(scope)){showToast(host::arrangerHost().lastError(),4500);return;}
            for(int part:{0,1,2})ctrl_.setScaleTarget(part,true);
            ctrl_.setScaleTarget(6,scope!=1);refresh();dirty_=true;
        },14);
    }
    button(c,{20,442,386,477},"Global Split: "+arrangerNoteName(player.globalSplit),green,false,true,[this]{
        globalSplitEditing_=true;openPicker(Picker::Split);
        pickerPage_=(host::arrangerHost().globalSplit()-1)/10;dirty_=true;
    },14);
    button(c,{402,442,784,477},"Chord Recognition / Damper",orange,false,true,[this]{
        rememberNavigation();picker_=Picker::None;tab_=Tab::Chords;dirty_=true;
    },14);
}

// Full-screen touch editor. Settings are published by the audio engine, not
// locally toggled optimistically. Threshold changes use a bounded queue.
void ArrangerView::drawVelocityControl(Canvas& c){
    box(c,{0,0,800,480},bg);
    label(c,"VELOCITY CONTROL",20,34,26,white,true,540);
    button(c,{646,4,784,51},"‹ Back",orange,false,true,[this]{panelExit();},18);
    const auto p=host::arrangerHost().snapshot(selectedPlayer_);
    const auto set=[this](int mode,int threshold,int player){controlRequested(host::arrangerHost().setVelocityControl(mode,threshold,player));dirty_=true;};
    label(c,"Target player (Break / Start-Stop)",20,77,17,dim,true,760);
    for(int i=0;i<2;++i){const float x=20+i*386.0F;
        button(c,{x,88,x+374,144},"Player "+std::to_string(i+1),orange,p.velocityPlayer==i,true,[set,p,i]{set(p.velocityControl,p.velocityThreshold,i);},21);
    }
    label(c,"Action on a strong Lower-key attack",20,173,17,dim,true,760);
    static const char* names[]={"Off","Break","Start / Stop","Bass Inversion","Memory"};
    for(int i=0;i<5;++i){const float x=20+(i%3)*258.0F,y=185+(i/3)*68.0F;
        button(c,{x,y,x+248,y+59},names[i],green,p.velocityControl==i,true,[set,p,i]{set(i,p.velocityThreshold,p.velocityPlayer);},20);
    }
    label(c,"Trigger threshold  ·  "+std::to_string(p.velocityThreshold),20,349,22,white,true,760);
    const auto adjust=[this](int delta){const auto v=host::arrangerHost().snapshot(selectedPlayer_);controlRequested(host::arrangerHost().setVelocityControl(v.velocityControl,std::clamp(v.velocityThreshold+delta,1,127),v.velocityPlayer));dirty_=true;};
    const int deltas[]={-10,-1,1,10};
    for(int i=0;i<4;++i){const float x=20+i*194.0F;const int d=deltas[i];
        button(c,{x,360,x+180,421},(d>0?"+":"")+std::to_string(d),orange,false,d<0?p.velocityThreshold>1:p.velocityThreshold<127,[adjust,d]{adjust(d);},22);
    }
    label(c,p.splitEnabled?"Triggers once per Lower-hand gesture, above the threshold.":"Enable SPLIT to use Velocity Control.",20,455,16,dim,false,760);
}
