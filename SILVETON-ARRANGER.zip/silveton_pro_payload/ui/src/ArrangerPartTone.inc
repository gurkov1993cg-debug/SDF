namespace {
using PartToneMember=float sampler::UpperPart::*;
using LayerToneMember=float sampler::SoundTone::*;
constexpr std::array<PartToneMember,6> partEnvelope{{&sampler::UpperPart::toneAttackMs,&sampler::UpperPart::toneDecayMs,
    &sampler::UpperPart::toneSustain,&sampler::UpperPart::toneReleaseMs,&sampler::UpperPart::toneCutoffHz,&sampler::UpperPart::toneResonance}};
constexpr std::array<LayerToneMember,6> layerEnvelope{{&sampler::SoundTone::attackMs,&sampler::SoundTone::decayMs,
    &sampler::SoundTone::sustain,&sampler::SoundTone::releaseMs,&sampler::SoundTone::cutoffHz,&sampler::SoundTone::resonance}};

const sampler::UpperLayer* firstPartLayer(const sampler::UpperPart& u){
    if(!u.hasSource())for(const auto& layer:u.layers)if(layer.enabled&&layer.hasSource())return &layer;
    return nullptr;
}
float partEnvelopeValue(const sampler::UpperPart& u,int field){
    const auto* layer=firstPartLayer(u);
    return layer?layer->tone.*layerEnvelope[field]:u.*partEnvelope[field];
}
const sampler::ToneExtra& partModulation(const sampler::UpperPart& u){
    const auto* layer=firstPartLayer(u);
    return layer?layer->tone.x:u.toneExtra;
}
void setPartEnvelope(sampler::UpperPart& u,int field,float value){
    u.*partEnvelope[field]=value;
    for(auto& layer:u.layers)if(layer.hasSource())layer.tone.*layerEnvelope[field]=value;
}
// The controls show one signed offset. Each assigned layer starts at its own
// source envelope, so layering two different sounds preserves their balance.
void setPartEnvelopeOffset(sampler::UpperPart& u,int field,float delta,float mainBase){
    const bool percent=field==2;
    const auto withOffset=[&](float base){
        if(delta==0)return -1.0F;
        return std::clamp(base+delta,0.0F,percent?1.0F:10000.0F);
    };
    u.*partEnvelope[field]=withOffset(mainBase);
    for(auto& layer:u.layers)if(layer.hasSource()){
        sampler::EnvelopeParams env{};
        if(layer.program&&!layer.program->layers.empty())env=host::editableAmpEnvelope(layer.program->layers.front());
        layer.tone.*layerEnvelope[field]=withOffset(percent?env.sustain:env.decaySec*1000);
    }
}
template<class T> void setPartModulation(sampler::UpperPart& u,T sampler::ToneExtra::*member,T value){
    u.toneExtra.*member=value;
    for(auto& layer:u.layers)if(layer.hasSource())layer.tone.x.*member=value;
}
constexpr const char* glideAlgorithms[]={"Silveton","Kronos","Instrument","Bass"};
bool partGlideEnabled(const sampler::UpperPart& u){
    if(u.portaMode==sampler::PortamentoMode::Silveton?u.portamentoSec>0:u.portaTime>0)return true;
    if(!u.sourcePortamentoInherit)return false;
    const auto* layer=firstPartLayer(u);const auto& program=layer?layer->program:u.program;
    if(program)for(const auto& osc:program->layers)
        if(osc.enabled&&osc.sourcePortamento.enabled()&&osc.sourcePortamento.timeRaw>0)return true;
    return false;
}
void setPartGlideTime(sampler::UpperPart& u,float value){
    u.sourcePortamentoInherit=false;
    if(u.portaMode==sampler::PortamentoMode::Silveton)u.portamentoSec=std::clamp(value,0.0F,100.0F)*.001F;
    else u.portaTime=static_cast<std::uint8_t>(std::clamp(std::lround(value),0L,127L));
}
// The sampler stores MAIN and layer octaves independently. Move the assigned
// sounds by one common delta so layered octaves keep their original spacing.
std::pair<int,int> partOctaveBounds(const sampler::UpperPart& u){
    int low=-4,high=4;
    for(const auto& layer:u.layers)if(layer.hasSource()){
        const int offset=int(layer.octave)-int(u.octave);
        // The shared control spans four octaves each way. A layered
        // registration can already contain a deliberate octave offset.
        low=std::max(low,int(std::numeric_limits<std::int8_t>::min())-offset);
        high=std::min(high,int(std::numeric_limits<std::int8_t>::max())-offset);
    }
    return {std::min(low,int(u.octave)),std::max(high,int(u.octave))};
}
void setPartOctave(sampler::UpperPart& u,int requested){
    const auto bounds=partOctaveBounds(u);
    const int value=std::clamp(requested,bounds.first,bounds.second);
    const int shift=value-int(u.octave);
    for(auto& layer:u.layers)if(layer.hasSource())layer.octave=static_cast<std::int8_t>(int(layer.octave)+shift);
    u.octave=static_cast<std::int8_t>(value);
}
void resetPartSoundControls(sampler::UpperPart& d){
    setPartOctave(d,0);
    for(int i=0;i<6;++i)setPartEnvelope(d,i,-1);
    const sampler::UpperPart base{};
    setPartModulation(d,&sampler::ToneExtra::lfoDepthCents,base.toneExtra.lfoDepthCents);setPartModulation(d,&sampler::ToneExtra::lfoRateHz,base.toneExtra.lfoRateHz);
    setPartModulation(d,&sampler::ToneExtra::lfoDelayMs,base.toneExtra.lfoDelayMs);setPartModulation(d,&sampler::ToneExtra::lfoFadeMs,base.toneExtra.lfoFadeMs);
    setPartModulation(d,&sampler::ToneExtra::lfoModWheel,base.toneExtra.lfoModWheel);d.portaMode=base.portaMode;d.portamentoSec=base.portamentoSec;
    d.portaTime=base.portaTime;d.portaRateMode=base.portaRateMode;d.portaFingered=base.portaFingered;
    d.sourcePortamentoInherit=true;
    d.sourceVoiceInherit=true;
}
}
