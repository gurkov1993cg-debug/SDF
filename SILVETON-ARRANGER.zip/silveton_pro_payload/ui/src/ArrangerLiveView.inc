// Performance controls work in panel coordinates, including their touch areas.
// The detailed pages keep their 800 x 480 coordinates inside drawDisplayAt.
namespace {
constexpr ColorInt liveBg=0xFF0D151AU,liveCard=0xFF18252BU,liveKey=0xFF243239U;
constexpr ColorInt liveLine=0xFF405057U,liveText=0xFFF2F3EBU,liveDim=0xFFB0C0C2U;
constexpr ColorInt liveAmber=0xFFFFC16CU,liveMint=0xFF78DBC2U,liveStop=0xFFFFA18DU;
constexpr ColorInt liveOff=0xFF849197U;
constexpr float liveInset=24,liveStride=218,liveKeyWidth=204;
RectF liveColumn(int column,float top,float bottom){
    const float x=liveInset+liveStride*column;
    return {x,top,x+liveKeyWidth,bottom};
}
static_assert(liveInset+liveStride*4+liveKeyWidth+14<=1120,"Leave a gap before transport");
}

#include "ArrangerPartTone.inc"
#include "ArrangerHomeFaders.inc"
#include "ArrangerSoundDials.inc"
#include "ArrangerHomeTone.inc"

void ArrangerView::drawLiveElement(Canvas& c,int index,const RectF& rect,const std::string& title,bool compact){
    const int player=selectedPlayer_;
    const auto& p=players_[player];
    const auto cue=liveElementCue(p,index);
    const bool available=p.loaded&&p.available[index];
    const bool selected=available&&cue.selected;
    const bool queued=available&&cue.queued;
    const bool special=available&&(cue.returning||cue.looping);
    const ColorInt ink=!available?liveOff:selected?liveBg:liveText;
    box(c,rect,selected?liveAmber:available?liveKey:liveCard,
        queued||special||selected?liveAmber:liveLine,5);
    const char* state=queued?"NEXT":cue.looping&&available?"LOOP":cue.returning&&available?"RETURN":
        selected?(p.playing?"PLAYING":"SELECTED"):"";
    const float size=compact?27.0F:35.0F;
    const bool hasState=state[0]!='\0';
    label(c,title,rect.centerX(),rect.centerY()+size*.34F-(hasState?12:0),size,ink,true,rect.width()-14,Align::Center);
    if(hasState)label(c,state,rect.centerX(),rect.centerY()+28,16,selected?liveBg:liveAmber,true,rect.width()-10,Align::Center);
    if(available)hit(rect,[this,index,player]{controlRequested(host::arrangerHost().selectElement(player,index));},{},true);
}

void ArrangerView::drawLiveTransport(Canvas& c){
    const int player=selectedPlayer_;const auto& p=players_[player];
    label(c,"VARIATION",liveInset,886,19,liveDim,true);
    for(int i=0;i<4;++i)drawLiveElement(c,3+i,liveColumn(i,900,1016),std::to_string(i+1),false);
    drawLiveElement(c,11,liveColumn(4,900,1016),"Break",false);
    const RectF transport{1120,900,1616,1016};
    const bool enabled=p.playing||(p.loaded&&p.soundAssignmentsReady);
    const ColorInt ink=enabled?liveBg:liveOff;
    box(c,transport,enabled?(p.playing?liveStop:liveMint):liveCard,enabled?0:liveLine,12);
    Paint symbol;symbol.color=ink;const float x=transport.left+37,y=transport.centerY();
    if(p.playing)box(c,{x,y-13,x+26,y+13},ink,0,3);
    else {Path triangle;triangle.moveTo(x,y-16);triangle.lineTo(x+27,y);triangle.lineTo(x,y+16);triangle.close();c.drawPath(triangle,symbol);}
    label(c,p.playing?"Stop":"Start",transport.left+86,y+13,43,ink,true,270);
    label(c,"P"+std::to_string(player+1),transport.right-28,y+8,23,ink,true,90,Align::Right);
    if(enabled)hit(transport,[this,player]{startStopPlayer(player);},{},true);
}

void ArrangerView::drawLiveHome(Canvas& c){
    const auto& p=players_[selectedPlayer_];
    const bool ready=!kstJob_&&!persistentRestoreActive_;
    const bool playable=p.loaded&&p.soundAssignmentsReady;
    if(liveSlot_>=0&&(liveSlotPlayer_!=selectedPlayer_||liveSlotSerial_!=p.styleSelectionSerial||p.styleSwitchPending))liveSlot_=-1;
    if(choosingPerformance_)rebuildLiveLists();
    if(!pointerActive_||activityPlayer_!=selectedPlayer_||activitySerial_!=p.styleSelectionSerial)
        updateStyleActivity(p);
    const auto nav=[this,&c](const RectF& r,const std::string& name,bool active,bool enabled,std::function<void()> go,bool immediate=false){
        box(c,r,active?liveMint:liveCard,active?liveMint:liveLine,5);
        label(c,name,r.centerX(),r.centerY()+8,24,active?liveBg:enabled?liveText:liveOff,true,r.width()-14,Align::Center);
        if(enabled)hit(r,std::move(go),{},immediate);
    };
    const RectF editSwitch{24,14,169,74};
    box(c,editSwitch,homeSoundEdit_?liveMint:liveKey,homeSoundEdit_?liveMint:liveAmber,5);
    label(c,"HOME",editSwitch.centerX(),36,15,homeSoundEdit_?liveBg:liveDim,true,124,Align::Center);
    label(c,homeSoundEdit_?"Faders":"Sound Edit",editSwitch.centerX(),62,23,homeSoundEdit_?liveBg:liveText,true,129,Align::Center);
    if(ready)hit(editSwitch,[this]{openSoundWindow(homeToneKeyboard_,homeTonePart_);});
    for(int i=0;i<2;++i){
        const float x=183+i*169.0F;const RectF r{x,14,x+158,74};
        nav(r,"Player "+std::to_string(i+1),selectedPlayer_==i,ready,[this,i]{setPlayerFocus(i);});
        if(players_[i].playing){Paint lamp;lamp.color=i==selectedPlayer_?liveBg:liveMint;c.drawCircle(r.right-11,r.top+11,4,lamp);}
    }
    if(ready)hit({526,14,701,74},[this]{switchHomeTab(Tab::Chords);});
    label(c,"CHORD",531,37,16,liveDim,true,106);
    label(c,p.chordName.empty()?"—":p.chordName,531,68,31,liveText,true,174);
    const auto monitor=host::arrangerHost().listenSolo();
    if(monitor.player!=-2){
        const RectF releaseSolo{711,11,866,45};
        box(c,releaseSolo,liveAmber,0,5);label(c,"Clear Solo",releaseSolo.centerX(),35,20,liveBg,true,148,Align::Center);
        hit(releaseSolo,[this]{ctrl_.engine.nativeListenSolo(-2,-1);dirty_=true;},{},true);
    }else label(c,std::to_string(p.numerator)+"/"+std::to_string(p.denominator),714,38,19,liveDim,true,115);
    label(c,"Bar "+std::to_string(p.bar)+" · "+std::to_string(p.beat),714,65,20,liveText,true,150);
    const RectF panic{874,14,1005,74};
    box(c,panic,liveCard,0xFF85574FU,5);
    label(c,"Panic",panic.centerX(),53,23,liveStop,true,118,Align::Center);
    hit(panic,[this]{host::arrangerHost().panic();ctrl_.panic();refresh();},{},true);
    nav({1022,14,1163,74},"Media",false,ready,[this]{openPanelFile();});
    nav({1174,14,1317,74},"Global",false,ready,[this]{openPanelSettings();});
    nav({1328,14,1495,74},"Menu",false,ready,[this]{panelMenu();});
    const RectF pageMenu{1507,14,1616,74};
    box(c,pageMenu,liveCard,liveLine,5);
    for(int i=0;i<3;++i){
        const float y=30+i*12.0F;box(c,{1536,y,1542,y+5},liveText);box(c,{1549,y,1587,y+5},liveText);
    }
    if(ready)hit(pageMenu,[this]{rememberNavigation();picker_=Picker::WriteMenu;dirty_=true;});
    box(c,{24,85,809,165},liveCard,liveAmber,4);
    box(c,{823,85,1616,165},liveCard,liveMint,4);
    const bool editStyle=ready&&p.loaded&&!p.styleSwitchPending;
    constexpr float titleRight=627;
    label(c,"STYLE  /  P"+std::to_string(selectedPlayer_+1)+"   ▾",39,112,17,liveAmber,true,141);
    if(!p.pendingStyleName.empty())label(c,"Next: "+p.pendingStyleName,186,112,17,liveAmber,true,titleRight-198);
    label(c,p.loaded?p.name:"Select Style",39,148,31,liveText,true,titleRight-49);
    if(ready)hit({24,85,titleRight,165},[this]{openStyleSelectorForPlayer(selectedPlayer_);});
    if(homeSoundEdit_)nav({635,94,798,156},"Save Style",false,editStyle,[this]{openResourceSave(true);});
    else nav({635,94,798,156},"Drum Levels",false,editStyle,[this]{openLiveSoundPage(Picker::StyleDrums);});
    label(c,"PERFORMANCE / KEYBOARD SET   ▾",839,112,17,liveMint,true,412);
    label(c,combiName_.empty()?"Select Performance":combiName_,839,148,31,liveText,true,404);
    if(ready)hit({823,85,1245,165},[this]{openKeyboardSetSelector();});
    if(homeSoundEdit_)nav({1253,94,1457,156},"Save Kbd Set",false,ready&&ctrl_.engine.nativeKeyboardCombi()!=nullptr,[this]{openResourceSave(false);});
    else nav({1253,94,1457,156},"Upper Link",upperVolumeLink_,ready,[this]{
        upperVolumeLink_=!upperVolumeLink_;markPersistentStateChanged(false);dirty_=true;
    });
    nav({1467,94,1605,156},"All Parts",false,ready,[this]{openLiveSoundPage(Picker::KeyboardParts);});
    constexpr int trackCount=8;
    constexpr float start=24,end=809,gap=5;
    constexpr float width=(end-start-gap*(trackCount-1))/trackCount;
    for(int track=0;track<trackCount;++track)
        drawHomeFader(c,start+track*(width+gap),width,false,track,editStyle);
    if(choosingPerformance_)drawLiveSelector(c,ready);
    else for(int i=0;i<4;++i)drawHomeFader(c,823+i*200.0F,193,true,i==3?6:i,ready);
    for(int i=0;i<4;++i){
        const float x=24+i*274.0F;const RectF r{x,452,x+262,526};
        const bool armed=liveSlot_==i,active=selectedKeyboardSet_==i,queued=pendingKeyboardSet_==i;
        const bool assigned=keyboardWorkingSets_[i].combi||keyboardSets_[i]>0||!keyboardSetPaths_[i].empty();
        box(c,r,armed||active?0xFF203E39U:liveCard,armed||active||queued?liveMint:liveLine,5);
        label(c,"KBD SET "+std::to_string(i+1),x+12,477,16,liveMint,true,119);
        if(queued||armed||active)label(c,armed?"ASSIGN":queued?"NEXT":"SELECTED",r.right-12,477,15,liveMint,true,105,Align::Right);
        const auto& name=keyboardSetNames_[i];
        label(c,armed?"Pick performance":!name.empty()?name:assigned?"Keyboard Set":p.loaded?"Assign…":"—",x+12,512,25,liveText,true,239);
        if(ready&&(assigned||p.loaded))hit(r,[this,i,r]{tapLiveKeyboardSlot(i,r);},{},true);
    }
    nav({1120,452,1362,526},"Sync Start",p.syncStart,playable||p.syncStart,[this]{controlRequested(host::arrangerHost().toggleSyncStart(selectedPlayer_));},true);
    nav({1374,452,1616,526},"Memory",p.memory,true,[this]{controlRequested(host::arrangerHost().toggleMemory());},true);

    label(c,"INTRO",24,554,19,liveDim,true);
    label(c,"ENDING",586,554,19,liveDim,true);
    label(c,"TEMPO  /  BPM",1120,554,19,liveDim,true);
    for(int i=0;i<3;++i){
        const float introX=24+i*181.0F,endingX=586+i*176.0F;
        drawLiveElement(c,i,{introX,563,introX+169,652},std::to_string(i+1),true);
        drawLiveElement(c,12+i,{endingX,563,endingX+164,652},std::to_string(i+1),true);
    }
    const bool recent=selectedPlayer_==tempoWheelPlayer_&&arrangerStyleSelectionKey(p)==tempoWheelSourceKey_&&nowMs()<tempoWheelDisplayUntil_;
    const auto bpm=tempoText(recent?tempoWheelDesired_:p.bpm);
    nav({1120,563,1190,652},"−",false,true,[this]{stepTempo(-1);},true);
    label(c,bpm,1253,622,36,liveText,true,117,Align::Center);
    nav({1317,563,1387,652},"+",false,true,[this]{stepTempo(1);},true);
    nav({1400,563,1616,652},"Tap Tempo",false,p.playing||playable,[this]{tapTempo(true);},true);
    label(c,"FILL",24,702,19,liveDim,true);
    for(int i=0;i<4;++i)drawLiveElement(c,7+i,liveColumn(i,716,808),std::to_string(i+1),true);
    nav(liveColumn(4,716,808),"Auto Fill",p.autoFill,true,[this]{controlRequested(host::arrangerHost().toggleAutoFill(selectedPlayer_));});
    const float mix=host::arrangerHost().crossfade();
    label(c,"TRANSPOSE",1120,702,19,liveDim,true);
    nav({1120,716,1187,808},"−",false,true,[this]{stepTranspose(-1);});
    nav({1192,716,1263,808},signedNumber(globalUi_?globalUi_->transpose:0),false,true,[this]{stepTranspose(0);});
    nav({1268,716,1335,808},"+",false,true,[this]{stepTranspose(1);});
    label(c,"PLAYER MIX",1350,702,19,liveDim,true);
    const char* audible=mix<=0?"P1 only":mix>=1?"P2 only":"P1 + P2";
    label(c,audible,1616,702,19,liveMint,true,245,Align::Right);
    const RectF fader{1346,716,1616,808};
    box(c,fader,liveCard,liveLine,10);
    label(c,"P1",1354,773,22,liveText,true,44);
    label(c,"P2",1600,773,22,liveText,true,44,Align::Right);
    constexpr float left=1398,right=1566;
    const float thumb=left+(right-left)*mix;
    box(c,{left,757,right,765},liveLine,0,4);
    box(c,{thumb-12,741,thumb+12,781},liveMint,0,6);
    hit(fader,{},[this](float x,float){movePlayerFader(std::clamp((x-left)/(right-left),0.0F,1.0F));});
}

void ArrangerView::drawLiveHomeTabs(Canvas& c){
    // Fixed bottom row; original Korg Pa5X v1.4 labels in original order.
    constexpr float left=24.0F, right=1616.0F, gap=4.0F;
    const float width=(right-left-gap*9.0F)/10.0F;
    for(std::size_t i=0;i<kPa5xHomeTabs.size();++i){
        const auto& entry=kPa5xHomeTabs[i];
        const float x=left+static_cast<float>(i)*(width+gap);
        const RectF r{x,817.0F,x+width,868.0F};
        const bool active=tab_==entry.tab;
        box(c,r,active?liveAmber:liveCard,active?liveAmber:liveLine,3);
        const float size=i==4||i==5?17.0F:20.0F;
        label(c,entry.label,r.centerX(),r.centerY()+7,size,active?liveBg:liveText,true,r.width()-7,Align::Center);
        if(!active)hit(r,[this,selected=entry.tab]{switchHomeTab(selected);});
    }
}

void ArrangerView::drawLiveMessage(Canvas& c,float top){
    std::string message=toast_;
    if(message.empty())message=players_[selectedPlayer_].playbackWarning;
    if(message.empty()){std::lock_guard<std::mutex> lock(warningMutex_);message=warning_;}
    if(message.empty())return;
    box(c,{24,top,1616,top+34},0xFF322C23U,0,5);
    label(c,message,38,top+24,18,liveAmber,false,1562);
    if(!homeSoundEdit_&&picker_==Picker::None)hit({24,top,1616,top+34},[this,message]{showStyleInfo("Playback status",message);});
}

void ArrangerView::drawLiveView(Canvas& c){
    box(c,{0,0,kPanelWidth,kPanelHeight},liveBg);
    if(picker_==Picker::StyleDrums&&drumNote_>=0){
        drawDisplayAt(c,20,35,2.0F);return;
    }
    const bool homePage=picker_==Picker::None&&panelMode_==PanelMode::Home;
    const bool main=homePage&&tab_==Tab::Main;
    // Editing or confirmation screens own their input. During a performance
    // the same live row remains available in the two instrument selectors.
    const bool allowTransport=picker_==Picker::None||picker_==Picker::Style||picker_==Picker::Sound||
        picker_==Picker::KeyboardSet||picker_==Picker::KstCatalog||
        picker_==Picker::SavedStyleLibrary||picker_==Picker::SavedKeyboardLibrary||
        picker_==Picker::StyleSounds||picker_==Picker::StyleDrums||picker_==Picker::DrumFamilyEdit||picker_==Picker::KeyboardParts||
        picker_==Picker::KeyboardEdit||picker_==Picker::StyleControls;
    const bool transport=allowTransport&&!kstJob_&&!persistentRestoreActive_;
    if(main)drawLiveHome(c);
    else{
        liveSlot_=-1;choosingPerformance_=false;
        if(compactKstSelector()){
            // 800 x 410 logical units, uniform scale: full width, no stretched text.
            // Keep playback/status below y=824 and the LIVE transport unchanged.
            c.save();c.clipRect({24,8,1616,824});
            drawDisplayAt(c,24,8,1.99F);c.restore();
        }else{
            // An editor's own Back is the single navigation control. HOME
            // panes use the MAIN tab; only popups/Global shortcuts need a
            // wrapper Back because their inner screen has no such control.
            const bool wrapperBack=picker_==Picker::WriteMenu||picker_==Picker::SaveAsMenu||
                (picker_==Picker::None&&panelMode_!=PanelMode::Home);
            if(wrapperBack)button(c,{24,8,216,67},"‹ Back",liveMint,false,true,[this]{panelExit();},24);
            const char* mode=panelMode_==PanelMode::File?"SILVETON  /  MEDIA":
                panelMode_==PanelMode::Settings?"SILVETON  /  GLOBAL":"SILVETON  /  HOME";
            label(c,mode,820,50,23,liveDim,true,650,Align::Center);
            const float zoom=homePage?1.61F:transport?1.54F:1.88F;
            drawDisplayAt(c,(kPanelWidth-800*zoom)*0.5F,78,zoom);
        }
    }
    drawLiveMessage(c,main?655.0F:homePage?777.0F:transport?824.0F:990.0F);
    if(homePage&&transport)drawLiveHomeTabs(c);
    if(transport)drawLiveTransport(c);
}
