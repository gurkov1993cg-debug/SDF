// Included in silveton::ui. Measurements are snapshots; exporting is explicit.
std::string ArrangerView::performanceDiagnosticsText() {
    namespace diagnostics = silveton::sampler::diagnostics;
    // /proc reads belong to the UI request, never to an audio callback.
    diagnostics::sampleAudioPageFaults();
    const auto measured=diagnostics::snapshot();
    const auto audio=ctrl_.audioStatus();
    const auto midi=ctrl_.midiStatus();
    const auto arranger=host::arrangerHost().snapshot(selectedPlayer_);
    const auto lower=ctrl_.upperState(6);
    const auto milliseconds=[](double us){return fmtFixed(static_cast<float>(us/1000.0),3);};
    std::ostringstream out;
    out<<"SILVETON ARRANGER — AUDIO / GRAPHICS\n"
       <<"Rate: "<<audio.sampleRate<<" Hz; burst: "<<audio.framesPerBurst
       <<" frames; buffer: "<<audio.bufferSizeFrames<<" frames\n"
       <<"Sharing / performance / device: "<<audio.sharingMode<<" / "<<audio.performanceMode<<" / "<<audio.deviceId<<'\n'
       <<"Current-stream XRUNs: "<<audio.xrunCount<<" (not reset by Reset)\n";
    const auto scheduling=ctrl_.audioSchedulingStatus();
    if(!scheduling.empty())out<<"Android scheduling setup: "<<scheduling<<'\n';
    if(liveLog_)out<<"Automatic live diagnostics: "<<(liveLog_->healthy.load()?"recording":"waiting for writable storage")<<" (included in Save Report)\n";
    if(performanceDiagnosticsXrunBaseline_>=0&&performanceDiagnosticsResetTid_==measured.audioThreadId&&
       measured.audioThreadId>0&&audio.xrunCount>=performanceDiagnosticsXrunBaseline_)
        out<<"XRUNs since Reset on this audio thread: "<<audio.xrunCount-performanceDiagnosticsXrunBaseline_<<'\n';
    else out<<"XRUNs since Reset: unavailable (Reset required or audio thread changed)\n";
    out<<"Audio blocks: "<<measured.audioBlocks<<"; over budget: "<<measured.audioDeadlineMisses<<'\n'
       <<"DSP wall time last / worst / budget: "<<milliseconds(measured.audioLastUs)<<" / "
       <<milliseconds(measured.audioWorstUs)<<" / "<<milliseconds(measured.audioBudgetUs)<<" ms\n"
       <<"Output clipped channel samples: "<<measured.clippedSamples
       <<"; pre-clamp peak: "<<fmtFixed(static_cast<float>(measured.outputPeakAbs),4)<<'\n'
       <<"Voice steals: "<<measured.voiceSteals<<"; without free fade tail: "<<measured.hardVoiceSteals<<'\n'
       <<"Total active voices (keyboard, players and preview): "<<audio.activeVoices<<"; dropped MIDI/control events: "<<audio.droppedRealtimeEvents<<'\n'
       <<"Performance engine voice capacity: "<<ctrl_.voiceCapacity()<<" slots each; no lower application ceiling\n"
       <<"Highest working core count reported by an engine: "<<audio.coresWorking<<"; last measured DSP: "<<fmtFixed(audio.cpuLoadPercent,1)<<" %\n"
       <<"Audio thread: "<<measured.audioThreadId<<'\n'
       <<"MIDI devices: "<<midi.deviceCount<<"; last status: 0x"<<std::hex<<midi.status<<std::dec
       <<"; data: "<<midi.data1<<" / "<<midi.data2<<'\n'
       <<"Chord scan area: "<<arranger.chordScanArea<<" (0=Off,1=Lower,2=Upper,3=Full); Chord Split: "<<arranger.splitEnabled<<'\n'
       <<"Split: "<<arrangerNoteName(arranger.split)<<" (MIDI "<<arranger.split<<"); chord: "<<arranger.chordName<<'\n';
#if defined(__linux__) || defined(__ANDROID__)
    const auto dumpScheduling=[&](int tid){
        const int policy=::sched_getscheduler(tid);
        sched_param priority{};cpu_set_t allowed;CPU_ZERO(&allowed);
        std::string cpus;
        if(::sched_getaffinity(tid,sizeof(allowed),&allowed)==0)
            for(int cpu=0;cpu<CPU_SETSIZE;++cpu)if(CPU_ISSET(cpu,&allowed)){
                if(!cpus.empty())cpus+=',';
                cpus+=std::to_string(cpu);
            }
        if(policy>=0&&::sched_getparam(tid,&priority)==0){
            out<<(policy==SCHED_FIFO?"FIFO":policy==SCHED_RR?"RR":policy==SCHED_OTHER?"OTHER":std::to_string(policy));
            out<<" / "<<priority.sched_priority<<" / "<<(cpus.empty()?"unavailable":cpus)<<'\n';
        }else out<<"unavailable\n";
    };
    if(measured.audioThreadId>0){
        out<<"Audio scheduling policy / priority / allowed CPUs: ";
        dumpScheduling(measured.audioThreadId);
    }
#if defined(__ANDROID__)
    const auto& placement = sampler::deviceCpuWorkPolicy();
    const char* basis = "general";
    switch (placement.layout) {
        case sampler::CpuLayout::CapacityPair: basis = "kernel cpu_capacity"; break;
        case sampler::CpuLayout::FrequencyPair: basis = "kernel cpuinfo_max_freq"; break;
        case sampler::CpuLayout::GalaxyA11: basis = "SM-X130 device profile"; break;
        default: break;
    }
    out << "CPU placement requested (" << basis << "): audio=" << placement.audioCpu << " render=";
    for (int i = 0; i < placement.renderThreads - 1; ++i)
        out << (i ? "," : "") << placement.renderCpu(i);
    out << " MIDI=" << placement.midiFirstCpu << ".." << placement.midiLastCpu
        << " prefetch=" << placement.streamFirstCpu << ".." << placement.streamLastCpu
        << " UI/background=0.." << placement.backgroundLastCpu << '\n';
    if(DIR* tasks=::opendir("/proc/self/task")){
        while(const auto* task=::readdir(tasks)){
            if(task->d_name[0]<'0' || task->d_name[0]>'9')continue;
            const int tid=std::atoi(task->d_name);
            std::ifstream comm(std::string("/proc/self/task/")+task->d_name+"/comm");
            std::string name;
            if(!std::getline(comm,name))continue;
            if(name.compare(0,10,"SilvRender")!=0 && name!="SilvMidiRT" &&
               name!="SilvPrefetch" && name!="SilvetonMain")continue;
            out<<name<<" (TID "<<tid<<") policy / priority / allowed CPUs: ";
            dumpScheduling(tid);
        }
        ::closedir(tasks);
    }
#endif
#endif
    if(lower)out<<"Lower enabled / muted: "<<lower->enabled<<" / "<<lower->mute<<"; Sound: "<<lower->soundName<<'\n';
    if(measured.pageFaultsValid){
        out<<"Audio-thread page faults minor / major: "<<measured.audioMinorFaults<<" / "<<measured.audioMajorFaults<<'\n'
           <<"Faults since first sample / Reset: "<<measured.audioMinorFaultDelta<<" / "<<measured.audioMajorFaultDelta<<'\n';
    }else out<<"Audio-thread page faults: unavailable\n";
    const auto prefetch=sampler::samplePrefetchStatus();
    out<<"Prefetch lifetime requested / populated ranges: "<<prefetch.requestedRanges<<" / "<<prefetch.populateReadRanges<<'\n'
       <<"Prefetch lifetime leased-touch ranges / pages: "<<prefetch.leasedTouchRanges<<" / "<<prefetch.leasedTouchPages<<'\n'
       <<"Prefetch lifetime unleased / failed WILLNEED / unsupported workers: "<<prefetch.unleasedRanges<<" / "
       <<prefetch.failedWillNeedRanges<<" / "<<prefetch.unsupportedPopulateWorkers<<'\n';
    const auto entryWarm=silveton::arranger::pa5xSampleWarmTotals();
    out<<"Program entry warm lifetime batches / eligible entries / warmed entries: "
       <<entryWarm.batches<<" / "<<entryWarm.entries<<" / "<<entryWarm.warmedEntries<<'\n'
       <<"Program entry warm lifetime successful range bytes / touched pages: "
       <<entryWarm.warmedBytes<<" / "<<entryWarm.touchedPages<<'\n'
       <<"Program entry warm lifetime failed / budget-skipped entries / cancelled batches: "
       <<entryWarm.failedEntries<<" / "<<entryWarm.budgetSkippedEntries<<" / "<<entryWarm.cancelledBatches<<'\n';
    out<<"UI tick last / worst: "<<milliseconds(measured.uiTickLastUs)<<" / "<<milliseconds(measured.uiTickWorstUs)<<" ms\n"
       <<"UI draw-list last / worst: "<<milliseconds(measured.uiRecordLastUs)<<" / "<<milliseconds(measured.uiRecordWorstUs)<<" ms\n"
       <<"GL submit/present wall last / worst: "<<milliseconds(measured.uiRenderWallLastUs)<<" / "<<milliseconds(measured.uiRenderWallWorstUs)<<" ms\n"
       <<"Visual redraw attempts: "<<measured.uiFrames<<"; last measured attempts/s: "<<fmtFixed(static_cast<float>(measured.uiFps),1)<<'\n'
       <<"Draw operations last / worst: "<<measured.uiOperationCount<<" / "<<measured.uiWorstOperationCount<<"\n\n"
       <<"Android records automatically while you play. After the issue, use Save Report to export the timeline.\n"
       <<"Counters identify candidates, not a proven cause: clipping, late blocks, XRUNs, tail overflow and file page faults are separate.\n"
       <<"Prefetch counters are process-lifetime, not reset here. Unleased ranges can be stale/unloaded requests, not proven dropouts.\n"
       <<"Program entry warm counters are process-lifetime too; touched pages do not guarantee permanent RAM residency.\n"
       <<"Without-free-tail events now use a bounded emergency declick residual; the counter still records full-tail pool exhaustion.\n"
       <<"GL wall time includes driver and VSync waiting; it is not GPU busy percent. Page faults cover the main audio thread only.\n"
       <<"UI draw-list last/worst includes this diagnostics page; it does not isolate Main-page performance.\n"
       <<"Visual redraw interval is 33 ms while audio runs; active touch/live-control feedback uses 12 ms. These are redraw limits, not measured screen/input latency. Sample quality and audio buffers are unchanged; performance engines use their full allocated voice capacity.\n"
       <<"Measurements are from this app run on this device; no synthetic benchmark is substituted.\n";
    out<<"\nSET PCM FILES\n";
    if(kstReport_)out<<"SET: "<<kstReport_->rootPath<<'\n';
    if(kstReport_)if(const auto* cover=sampleCoverage(*kstReport_))out<<cover->message<<'\n';
    out<<pcmFileSummary(kstPcmFiles_)<<'\n';
    for(std::size_t index=0;index<kstPcmFiles_.size();++index){
        const auto& file=kstPcmFiles_[index];
        out<<index+1U<<" / "<<kstPcmFiles_.size()<<" | "<<file.path<<" | "<<pcmFileState(file)
           <<" | recordings ready "<<(file.preparationComplete||file.attempted>0U||file.unlinked>0U?std::to_string(file.ready):std::string("unknown"))<<" / "<<file.samples
           <<" | failed "<<file.failed<<" | unlinked "<<file.unlinked
           <<" | attempted "<<file.attempted
           <<" | source-read "<<file.sourceRead<<" | index-cache "<<file.metadataCacheHit
           <<" | restored "<<file.restored<<'\n';
        if(!file.error.empty())out<<"  Reason: "<<file.error<<'\n';
    }
    return out.str();
}

void ArrangerView::resetPerformanceDiagnostics() {
    namespace diagnostics = silveton::sampler::diagnostics;
    diagnostics::resetStatistics();
    performanceDiagnosticsXrunBaseline_=ctrl_.audioStatus().xrunCount;
    performanceDiagnosticsResetTid_=diagnostics::snapshot().audioThreadId;
    diagnostics::sampleAudioPageFaults();
    showPerformanceDiagnostics();
}

void ArrangerView::showPerformanceDiagnostics() {
    const auto report=performanceDiagnosticsText();
    showStyleInfo("Audio / Graphics",report);
    performanceDiagnosticsInfo_=true;
}

void ArrangerView::exportPerformanceDiagnostics() {
    const auto summary=performanceDiagnosticsText();
    std::string report=summary;
    if(liveLog_)report+="\nLIVE SESSION HISTORY\n"+liveLog_->history();
    std::vector<std::string> directories;
#if defined(__ANDROID__)
    directories.push_back("/storage/emulated/0/Download");
    directories.push_back("/sdcard/Download");
#else
    directories.push_back(files::join(files::homeDirectory(),"Documents"));
#endif
    if(!persistentSessionPath_.empty())directories.push_back(files::parentOf(persistentSessionPath_));
    for(const auto& directory:directories){
        if(!files::makeDirectories(directory))continue;
        const auto path=files::join(directory,"SILVETON-AUDIO-DIAGNOSTICS.txt");
        const auto pending=path+".pending";
        if(files::writeText(pending,report)&&std::rename(pending.c_str(),path.c_str())==0){
            styleInfoText_=summary;styleInfoPage_=0;dirty_=true;
            showToast("Report saved: "+path,8000);return;
        }
        (void)files::removeRecursively(pending);
    }
    showToast("The diagnostics report could not be saved. Check file access permission.",7000);
}
