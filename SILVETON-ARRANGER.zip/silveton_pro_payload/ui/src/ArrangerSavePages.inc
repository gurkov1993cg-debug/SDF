// Default Save replaces the selected resource. Save As is the only path that
// asks for another destination. Native snapshots retain original media refs.
void ArrangerView::drawWriteMenu(Canvas& c){
    const auto menu=picker_;picker_=Picker::None;drawDisplay(c);picker_=menu;
    hit({0,0,800,480},[this]{panelExit();});
    const float left=410.0F,right=793.0F,top=39.0F;
    const bool saveAs=menu==Picker::SaveAsMenu;
    const int rows=saveAs?2:3;
    box(c,{left,top,right,top+static_cast<float>(rows)*53.0F+8.0F},panel,kBorder,2);
    const auto row=[&](int index,const std::string& text,bool enabled,const std::function<void()>& action){
        const float y=top+4.0F+static_cast<float>(index)*53.0F;
        button(c,{left+5.0F,y,right-5.0F,y+48.0F},text,orange,false,enabled,action,16);
    };
    const bool keyboard=ctrl_.engine.nativeKeyboardCombi()!=nullptr;
    const bool style=host::arrangerHost().snapshot(selectedPlayer_).loaded;
    if(saveAs){
        row(0,"Save Keyboard Set As...",keyboard,[this]{openResourceSave(false,true);});
        row(1,"Save Style As...",style,[this]{openResourceSave(true,true);});
    }else{
        row(0,"Save Keyboard Set",keyboard,[this]{openResourceSave(false);});
        row(1,"Save Current Style Settings",style,[this]{openResourceSave(true);});
        row(2,"Save As...",keyboard||style,[this]{picker_=Picker::SaveAsMenu;dirty_=true;});
    }
}

void ArrangerView::openResourceSave(bool style,bool saveAs){
    if(kstJob_){showToast("Wait for the SET to finish loading",4500);return;}
    const auto selection=host::arrangerHost().keyboardStyleSelection(selectedPlayer_);
    if(selection.pending||styleKeyboardCue_.serial!=0){showToast("Wait for the Style change to finish before saving",5000);return;}
    refresh();
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    if(style&&!player.loaded){showToast("Select a Style before saving",4000);return;}
    if(!style&&!ctrl_.engine.nativeKeyboardCombi()){showToast("No keyboard combination is available to save",4000);return;}
    resourceSaveSoundPage_=style&&!saveAs&&(picker_==Picker::StyleSounds||picker_==Picker::StyleDrums||picker_==Picker::DrumFamilyEdit);
    rememberNavigation();
    resourceSaveIsStyle_=style;resourceSaveAs_=saveAs;resourceSaveOwner_=ResourceSaveOwner::None;
    resourceSaveToStyle_=false;resourceSaveStyleSource_=true;
    resourceSaveNameEditing_=false;resourceSaveOverwriteConfirm_=false;
    resourceSavePlayer_=selectedPlayer_;resourceSaveStyleKey_=arrangerStyleSelectionKey(player);
    resourceSaveKeyboardSource_=activeNativeKeyboardSetPath_;resourceSaveKeyboardEntry_=activeSavedKeyboardEntryPath_;
    resourceSaveCombiSlot_=currentKeyboardCombiSlot_;resourceSaveCombiBankIdentity_=currentKeyboardCombiBankIdentity_;
    resourceSaveOriginalKeyboardPosition_=selectedKeyboardSet_;
    resourceSaveBank_=1;resourceSavePosition_=1;
    resourceSaveStylePosition_=std::clamp(selectedKeyboardSet_,0,3);
    resourceSaveName_=style?player.name:combiName_;
    resourceSaveDestinationLabel_.clear();
    if(style){
        resourceSaveOwner_=ResourceSaveOwner::Style;
        resourceSaveBank_=player.savedStyleBank>0?player.savedStyleBank:0;
        resourceSavePosition_=player.savedStyleBank>0?player.savedStylePosition:0;
        resourceSaveDestinationLabel_="Current Style: "+player.name;
    }else if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4&&player.loaded&&selectedStyleKey_==resourceSaveStyleKey_){
        resourceSaveOwner_=ResourceSaveOwner::StyleKeyboard;resourceSaveToStyle_=true;
        resourceSaveDestinationLabel_=player.name+" / Keyboard Set "+std::to_string(selectedKeyboardSet_+1);
    }else if(startsWith(files::nameOf(activeSavedKeyboardEntryPath_),"ARRANGER_USER_KBD_")){
        SavedKeyboardEntry entry;std::string error;
        if(readSavedKeyboardEntry(activeSavedKeyboardEntryPath_,entry,error)&&entry.bank>=1&&entry.bank<=16&&entry.position>=1&&entry.position<=128){
            resourceSaveOwner_=ResourceSaveOwner::LibraryKeyboard;resourceSaveBank_=entry.bank;resourceSavePosition_=entry.position;
            resourceSaveDestinationLabel_="User "+std::to_string(entry.bank)+" / position "+std::to_string(entry.position);
        }
    }else if(!activeNativeKeyboardSetPath_.empty()&&(activeSavedKeyboardEntryPath_.empty()||startsWith(files::nameOf(activeSavedKeyboardEntryPath_),"ARRANGER_SOURCE_KBD_"))){
        resourceSaveOwner_=ResourceSaveOwner::SourceKeyboard;
        resourceSaveDestinationLabel_="Current Keyboard Set: "+combiName_;
    }else if(activeNativeKeyboardSetPath_.empty()&&activeSavedKeyboardEntryPath_.empty()&&currentKeyboardCombiSlot_>=1&&currentKeyboardCombiSlot_<=500&&
        !currentKeyboardCombiBankIdentity_.empty()&&currentKeyboardCombiBankIdentity_==keyboardSamplerBankIdentity(ctrl_.currentBankFile())&&
        ctrl_.engine.nativeCombiSlotOccupied(0,0,currentKeyboardCombiSlot_)){
        resourceSaveOwner_=ResourceSaveOwner::NativeCombi;
        resourceSaveDestinationLabel_="Current COMBI / position "+std::to_string(currentKeyboardCombiSlot_);
    }
    if(resourceSaveName_.empty())resourceSaveName_=style?"My Style":"My Keyboard Set";
    if(resourceSaveOwner_==ResourceSaveOwner::None)resourceSaveAs_=true;
    if(resourceSaveAs_){
        resourceSaveStyleSource_=false;resourceSaveToStyle_=false;
        // A fresh destination is explicit and visible; never silently reuse a
        // previously edited resource's last bank/position.
        resourceSaveBank_=1;resourceSavePosition_=1;
        if(!style){
            refreshSavedKeyboardEntries();
            for(int position=1;position<=128;++position){
                const bool occupied=std::any_of(savedKeyboardEntries_.begin(),savedKeyboardEntries_.end(),[position](const auto& entry){return entry.bank==1&&entry.position==position;});
                if(!occupied){resourceSavePosition_=position;break;}
            }
        }else{
            const auto entries=host::arrangerHost().savedStyleEdits();
            for(int position=1;position<=128;++position){
                const bool occupied=std::any_of(entries.begin(),entries.end(),[position](const auto& entry){return entry.bank==1&&entry.position==position;});
                if(!occupied){resourceSavePosition_=position;break;}
            }
        }
    }
    picker_=Picker::ResourceSave;editor_=false;held_={};dirty_=true;
}

bool ArrangerView::resourceSaveOwnerMatches() const{
    if(resourceSavePlayer_!=selectedPlayer_||host::arrangerHost().keyboardStyleSelection(selectedPlayer_).pending||styleKeyboardCue_.serial!=0)return false;
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    if(arrangerStyleSelectionKey(player)!=resourceSaveStyleKey_)return false;
    if(resourceSaveIsStyle_)return player.loaded&&(!resourceSaveSoundPage_||player.styleSelectionSerial==soundSerial_);
    return ctrl_.engine.nativeKeyboardCombi()&&selectedKeyboardSet_==resourceSaveOriginalKeyboardPosition_&&
        activeNativeKeyboardSetPath_==resourceSaveKeyboardSource_&&activeSavedKeyboardEntryPath_==resourceSaveKeyboardEntry_&&
        currentKeyboardCombiSlot_==resourceSaveCombiSlot_&&currentKeyboardCombiBankIdentity_==resourceSaveCombiBankIdentity_;
}

void ArrangerView::editResourceSaveName(){
    resourceSaveNameEditing_=true;resourceSaveOverwriteConfirm_=false;editor_=true;held_={};
    SilvetonSamplerView::requestExternalTextEdit(resourceSaveIsStyle_?"Style Name":"Keyboard Set Name",resourceSaveName_,
        [this](const std::string& value){resourceSaveName_=value;resourceSaveNameEditing_=false;editor_=false;picker_=Picker::ResourceSave;resourceSaveOverwriteConfirm_=false;dirty_=true;});
    dirty_=true;
}

void ArrangerView::drawResourceSave(Canvas& c){
    const auto player=host::arrangerHost().snapshot(selectedPlayer_);
    const bool toStyle=!resourceSaveIsStyle_&&resourceSaveToStyle_;
    const auto save=[this,toStyle]{
        if(!resourceSaveOwnerMatches()){
            showToast("The selected resource changed; open Save again",5500);resourceSaveOverwriteConfirm_=false;return;
        }
        if(resourceSaveAs_&&!resourceSaveOverwriteConfirm_&&resourceSaveDestinationExists()){
            resourceSaveOverwriteConfirm_=true;dirty_=true;return;
        }
        bool saved=false;
        if(resourceSaveAs_)saved=resourceSaveIsStyle_?commitStyleSave(resourceSaveBank_,resourceSavePosition_,resourceSaveName_):
            commitKeyboardSave(toStyle,resourceSaveBank_,resourceSavePosition_,resourceSaveStylePosition_,resourceSaveName_);
        else switch(resourceSaveOwner_){
            case ResourceSaveOwner::Style:
                if(resourceSaveSoundPage_){
                    auto& arranger=host::arrangerHost();
                    saved=arranger.saveStyleEdits(selectedPlayer_,resourceSaveBank_,resourceSavePosition_,resourceSaveName_);
                    if(saved){refresh();markPersistentStateChanged();flushPersistentState();showToast("Style sounds and levels saved",4200);}
                    else showToast(arranger.lastError(),6000);
                }else saved=commitStyleSave(resourceSaveBank_,resourceSavePosition_,resourceSaveName_);
                break;
            case ResourceSaveOwner::StyleKeyboard:saved=commitKeyboardSave(true,1,1,resourceSaveStylePosition_,resourceSaveName_);break;
            case ResourceSaveOwner::LibraryKeyboard:saved=commitKeyboardSave(false,resourceSaveBank_,resourceSavePosition_,0,resourceSaveName_);break;
            case ResourceSaveOwner::SourceKeyboard:saved=commitSourceKeyboardOverwrite(resourceSaveName_);break;
            case ResourceSaveOwner::NativeCombi:saved=commitNativeKeyboardOverwrite(resourceSaveCombiSlot_,resourceSaveCombiBankIdentity_,resourceSaveName_);break;
            case ResourceSaveOwner::None:showToast("Choose a destination with Save As",5000);break;
        }
        if(saved){liveListsDirty_=true;resourceSaveOverwriteConfirm_=false;if(!restoreNavigation()){picker_=Picker::None;editor_=false;}}
        dirty_=true;
    };
    const bool validName=!resourceSaveName_.empty()&&resourceSaveName_.size()<=256U&&resourceSaveName_.find_first_of("\r\n")==std::string::npos;
    if(!resourceSaveAs_){
        // Normal Save is a short modal: the existing resource is the target.
        const auto currentPicker=picker_;picker_=Picker::None;drawDisplay(c);picker_=currentPicker;
        hit({0,0,800,480},[]{});
        box(c,{128,92,672,384},panel,orange,2);
        label(c,resourceSaveIsStyle_?"Save Current Style Settings":"Save Keyboard Set",151,126,20,orange,true,496);
        label(c,"Name",152,163,14,dim);
        button(c,{151,176,649,225},resourceSaveName_,green,false,true,[this]{editResourceSaveName();},18);
        label(c,resourceSaveDestinationLabel_,151,268,16,white,true,496);
        button(c,{151,311,387,362},"Cancel",orange,false,true,[this]{panelExit();},17);
        button(c,{413,311,649,362},"Save",green,true,validName,save,18);
        return;
    }
    box(c,{0,0,800,480},bg);
    label(c,resourceSaveIsStyle_?"Save Style As...":"Save Keyboard Set As...",20,35,23,orange,true,620);
    button(c,{678,6,790,43},"Cancel",orange,false,true,[this]{resourceSaveOverwriteConfirm_=false;panelExit();},14);
    box(c,{12,52,788,54},orange);label(c,"Name",25,81,15,dim,true);
    button(c,{24,92,776,143},resourceSaveName_,green,false,true,[this]{editResourceSaveName();},19);
    if(!resourceSaveIsStyle_){
        button(c,{24,166,390,212},"to Library",green,!toStyle,true,[this]{resourceSaveToStyle_=false;resourceSaveOverwriteConfirm_=false;dirty_=true;},17);
        button(c,{408,166,776,212},"to Style",green,toStyle,player.loaded,[this]{resourceSaveToStyle_=true;resourceSaveOverwriteConfirm_=false;dirty_=true;},17);
    }else label(c,"Choose another User Style destination",25,190,17,dim,true,750);
    if(toStyle){
        label(c,"Player "+std::to_string(selectedPlayer_+1)+": "+player.name,25,242,16,dim,true,750);
        label(c,"Keyboard Set position",25,272,14,dim);
        for(int position=0;position<4;++position){
            const float x=24.0F+static_cast<float>(position)*192.0F;
            const auto& name=keyboardSetNames_[static_cast<std::size_t>(position)];
            button(c,{x,286,x+176,339},std::to_string(position+1)+(name.empty()?std::string{}:"  "+name),green,resourceSaveStylePosition_==position,true,
                [this,position]{resourceSaveStylePosition_=position;resourceSaveOverwriteConfirm_=false;dirty_=true;},14);
        }
    }else{
        label(c,"User Bank",25,247,15,dim,true);label(c,"Position",424,247,15,dim,true);
        const auto editNumber=[this](bool bank){
            resourceSaveNameEditing_=true;resourceSaveOverwriteConfirm_=false;editor_=true;held_={};
            SilvetonSamplerView::requestExternalTextEdit(bank?"User Bank (1–16)":"Position (1–128)",std::to_string(bank?resourceSaveBank_:resourceSavePosition_),
                [this,bank](const std::string& text){
                    bool valid=false;int value=0;
                    try{std::size_t used=0;value=std::stoi(text,&used,10);valid=used==text.size()&&value>=1&&value<=(bank?16:128);}catch(const std::exception&){valid=false;}
                    if(valid){if(bank)resourceSaveBank_=value;else resourceSavePosition_=value;}
                    else showToast(bank?"Bank must be between 1 and 16":"Position must be between 1 and 128",4500);
                    resourceSaveNameEditing_=false;editor_=false;picker_=Picker::ResourceSave;resourceSaveOverwriteConfirm_=false;dirty_=true;
                });dirty_=true;
        };
        button(c,{24,261,92,316},"−",green,false,resourceSaveBank_>1,[this]{--resourceSaveBank_;resourceSaveOverwriteConfirm_=false;dirty_=true;},26);
        button(c,{104,261,300,316},std::to_string(resourceSaveBank_),green,true,true,[editNumber]{editNumber(true);},22);
        button(c,{312,261,380,316},"+",green,false,resourceSaveBank_<16,[this]{++resourceSaveBank_;resourceSaveOverwriteConfirm_=false;dirty_=true;},26);
        button(c,{424,261,492,316},"−",green,false,resourceSavePosition_>1,[this]{--resourceSavePosition_;resourceSaveOverwriteConfirm_=false;dirty_=true;},26);
        button(c,{504,261,700,316},std::to_string(resourceSavePosition_),green,true,true,[editNumber]{editNumber(false);},22);
        button(c,{712,261,776,316},"+",green,false,resourceSavePosition_<128,[this]{++resourceSavePosition_;resourceSaveOverwriteConfirm_=false;dirty_=true;},26);
        label(c,"Touch the bank or position number to enter it directly",25,343,12,dim,false,750);
    }
    if(resourceSaveOverwriteConfirm_){
        box(c,{18,362,782,472},panel,orange,3);label(c,"Replace the existing destination?",400,391,18,orange,true,735,Align::Center);
        button(c,{33,410,386,459},"Cancel",orange,false,true,[this]{resourceSaveOverwriteConfirm_=false;dirty_=true;},16);
        button(c,{406,410,767,459},"Overwrite",orange,true,validName&&(!toStyle||player.loaded),save,16);
    }else{
        button(c,{25,411,386,462},"Cancel",orange,false,true,[this]{panelExit();},17);
        button(c,{406,411,776,462},"Save",green,true,validName&&(!toStyle||player.loaded),save,18);
    }
}
