// Read-only original Style metadata. Included inside ArrangerView.cpp's
// anonymous namespace; these helpers never change playback or saved edits.
const char* originalStylePartName(int track) {
    static const char* names[]{"Drum","Perc","Bass","ACC1","ACC2","ACC3","ACC4","ACC5"};
    return track>=0&&track<8?names[track]:"Unknown part";
}
struct OriginalStyleGuitars {
    unsigned tracks{0};
    std::size_t entries{0},blocked{0};
};
OriginalStyleGuitars originalStyleGuitars(const arranger::Pa5xStyleSourceSettings& settings) {
    OriginalStyleGuitars result;
    if(!settings.indexed||!settings.readable)return result;
    for(const auto& row:settings.tracks)if(row.declaredType=="Guitar"){
        ++result.entries;
        if(row.track>=0&&row.track<8)result.tracks|=1U<<row.track;
        if(!row.available||row.nativeMode!=arranger::NativePatternMode::Guitar)++result.blocked;
    }
    return result;
}
std::string originalGuitarParts(unsigned tracks,bool compact=false) {
    std::string result;
    for(int track=0;track<8;++track)if(tracks&(1U<<track)){
        if(!result.empty())result+=compact?"/":", ";
        result+=compact&&track>=3?std::to_string(track-2):originalStylePartName(track);
    }
    return result;
}
const arranger::Pa5xStyleSourceTrack* originalStyleTrack(
        const arranger::Pa5xStyleSourceSettings& settings,int element,int track) {
    for(const auto& row:settings.tracks)if(row.element==element&&row.track==track)return &row;
    return nullptr;
}
std::string originalStyleTrackText(const arranger::Pa5xStyleSourceTrack& row,bool includeSounds=true) {
    std::string text="Original type: "+(row.declaredType.empty()?std::string("unreadable"):row.declaredType);
    if(row.declaredType=="Guitar"){
        text+=row.available&&row.nativeMode==arranger::NativePatternMode::Guitar?
            "\nAutomatic Guitar interpretation: ready":"\nAutomatic Guitar interpretation: blocked / unavailable";
        const auto imported=[](bool known,int value){
            return known?std::to_string(value):value>=0?"unsupported raw value "+std::to_string(value):std::string("not decoded");
        };
        text+="\nCapo: "+imported(row.capoKnown,row.capo);
        text+="\nHumanize: "+imported(row.humanizeKnown,row.humanize);
        text+="\nString selectors (raw): high "+rawValue(row.stringHighRaw)+", low "+rawValue(row.stringLowRaw);
        text+="\nUnspecified controls use capo 0, Humanize 0 and strings 1–6 when the pattern is supported. Raw string selector mapping is uncalibrated.";
        text+="\nNoise Offset / Tension (raw): "+rawValue(row.noiseOffsetRaw)+" / "+rawValue(row.tensionRaw);
    }else if(!row.available)text+="\nNative pattern: unavailable";
    text+="\nNTT / NTR / Retrigger (raw): "+rawValue(row.nttRaw)+" / "+rawValue(row.ntrRaw)+" / "+rawValue(row.retriggerRaw);
    text+="\nKey range: "+(row.keyRangeKnown?std::string(row.keyRangeEnabled?"On":"Off"):std::string("not decoded"));
    text+="; low / high: "+rawValue(row.keyLow)+" / "+rawValue(row.keyHigh)+"; Wrap (raw): "+rawValue(row.wrapRaw);
    if(includeSounds&&row.sounds.empty())text+="\nOriginal initial Sound address: not decoded";
    else if(includeSounds){
        text+="\nOriginal initial Sound addresses (MSB / LSB / Program):";
        for(const auto& sound:row.sounds){
            text+="\n  "+(sound.cv==0?std::string("Setup"):"CV"+std::to_string(sound.cv));
            text+=" ch "+(sound.channel>=0?std::to_string(sound.channel+1):std::string("?"))+": "+
                originalAddress(sound.msb,sound.lsb,sound.program)+(sound.varies?"; changes later":"");
        }
    }
    return text;
}
std::string originalStyleSettingsText(const arranger::Pa5xCatalogStyle& entry) {
    const auto& settings=entry.originalSettings;
    std::string text=entry.name+"\n"+entry.relativePath;
    if(!settings.indexed)return text+"\n\nOriginal Style settings have not been read.";
    if(!settings.readable)return text+"\n\nOriginal Style settings are unreadable.\n"+settings.error;
    const auto guitars=originalStyleGuitars(settings);
    text+="\n\nSET Guitar parts: "+(guitars.tracks?originalGuitarParts(guitars.tracks):std::string("none declared"));
    text+="\n"+std::to_string(guitars.entries)+" Guitar element/track entries; "+std::to_string(guitars.blocked)+" blocked / unavailable.";
    text+="\nAuto follows these original per-element/track types. Explicit saved edits take precedence.";
    text+="\nPattern readiness is separate from the availability of its assigned Sound samples.";
    text+="\nGuitar voicing, timing and Humanize use SILVETON processing.";
    for(const auto& row:settings.tracks){
        text+="\n\n"+(row.element>=0&&row.element<int(elementNames.size())?std::string(elementNames[row.element]):"Unknown element")+
            " / "+originalStylePartName(row.track)+"\n"+originalStyleTrackText(row);
        const auto bit=row.track>=0&&row.track<8?1U<<row.track:0U;
        if(settings.muteKnownMask&bit)text+=std::string("\nOriginal Style mute: ")+((settings.muteMask&bit)?"On":"Off");
    }
    return text;
}
struct OriginalSetGuitarCounts {
    std::size_t styles{0},entries{0},blocked{0},unreadable{0},unindexed{0};
};
OriginalSetGuitarCounts originalSetGuitarCounts(const arranger::Pa5xKstCatalog& catalog) {
    OriginalSetGuitarCounts result;
    for(const auto& style:catalog.styles){
        const auto& settings=style.originalSettings;
        if(!settings.indexed){++result.unindexed;continue;}
        if(!settings.readable){++result.unreadable;continue;}
        const auto guitars=originalStyleGuitars(settings);
        result.styles+=guitars.entries!=0;result.entries+=guitars.entries;result.blocked+=guitars.blocked;
    }
    return result;
}
