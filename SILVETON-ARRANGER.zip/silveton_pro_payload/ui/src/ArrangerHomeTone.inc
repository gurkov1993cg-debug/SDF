// The engine represents Off by a duration of zero. Keep the previous time
// for each part and glide algorithm while the same sound is being edited.
void ArrangerView::togglePartGlide(sampler::UpperPart& u,int player,int part,std::uint64_t selection){
    auto& recall=glideRecall_[player+1][part];
    std::string preset;
    if(player<0){
        preset=combiName_+"|"+std::to_string(selectedKeyboardSet_)+"|"+u.name;
        if(selectedKeyboardSet_>=0&&selectedKeyboardSet_<4)preset+="|"+keyboardSetPaths_[selectedKeyboardSet_];
    }
    const auto* layer=firstPartLayer(u);
    const auto& source=layer?layer->program:u.program;
    if(recall.serial!=selection||recall.preset!=preset||recall.sound.lock()!=source){
        recall={};recall.serial=selection;recall.preset=std::move(preset);recall.sound=source;
    }
    auto& previous=recall.duration[std::clamp(int(u.portaMode),0,3)];
    if(partGlideEnabled(u)){
        previous=u.portaMode==sampler::PortamentoMode::Silveton?u.portamentoSec*1000:u.portaTime;
        setPartGlideTime(u,0);
    }else setPartGlideTime(u,previous>0?previous:40);
}

void ArrangerView::stopEqTap(){
    if(eqTapPlayer_==-2)return;
    if(eqTapPlayer_==-1)(void)ctrl_.engine.nativeAnalyzerFrame(-1,true);
    else (void)host::arrangerHost().styleAnalyzerFrame(eqTapPlayer_,-1,true);
    eqTapPlayer_=-2;eqTapPart_=-1;clearEqSpectrum();
}
void ArrangerView::openSoundWindow(bool keyboard,int part){
    stopEqTap();eqNumberField_=-1;soundResetPanel_=false;homeSoundEdit_=true;homeToneKeyboard_=keyboard;homeTonePart_=std::clamp(part,0,keyboard?6:7);
    toneDetail_.clear();toneDialPreview_=-1;toneGestureOwner_.reset();
    cancelKeyboardSetHold();dirty_=true;
}
bool ArrangerView::soundWindowVisible() const {
    return homeSoundEdit_&&picker_!=Picker::ResourceSave&&!resourceSaveNameEditing_;
}
void ArrangerView::closeSoundWindow(){
    stopEqTap();eqNumberField_=-1;homeSoundEdit_=false;toneDetail_.clear();toneGestureOwner_.reset();toneDialPreview_=-1;
    held_={};dragging_=false;lastResetTapUp_=0;dirty_=true;
}
void ArrangerView::drawHomeTone(Canvas& c,bool ready){
    const int player=selectedPlayer_,part=homeTonePart_;
    const bool keyboard=homeToneKeyboard_;
    const auto& state=players_[player];
    if(!pointerActive_||activityPlayer_!=player||activitySerial_!=state.styleSelectionSerial)updateStyleActivity(state);
    const auto accent=keyboard?liveMint:liveAmber;
    std::uint64_t serial=0;
    const auto snapshot=keyboard?ctrl_.engine.nativeKeyboardCombi():host::arrangerHost().styleTrackCombi(player,serial);
    const bool current=ready&&snapshot&&(keyboard||(state.loaded&&!state.styleSwitchPending&&serial==state.styleSelectionSerial));
    const auto playable=[&](int i){return current&&(keyboard?snapshot->part(i).hasAnySound():state.tracks[i].assigned);};
    const bool canChoose=ready&&(keyboard||(state.loaded&&!state.styleSwitchPending));
    const bool available=playable(part);
    const auto chooseSound=[this,keyboard,player,owner=state.styleSelectionSerial](int i){
        if(!keyboard){
            const auto now=host::arrangerHost().snapshot(player);
            if(selectedPlayer_!=player||!now.loaded||now.styleSwitchPending||now.styleSelectionSerial!=owner)return;
        }
        openSoundWindow(keyboard,i);
        openTargetSound(keyboard?i:0,keyboard?-1:i);
    };
    if(!available){stopEqTap();eqNumberField_=-1;}
    const int source=keyboard?-1:player;
    const auto groupName=[](int n){return n<0?std::string("Keyboard Set"):"Player "+std::to_string(n+1)+" · Style";};
    box(c,{0,0,kPanelWidth,kPanelHeight},liveBg);
    label(c,"Sound Edit",32,65,36,liveText,true,180);
    for(int group=-1;group<2;++group){
        const float x=371+(group+1)*257.0F;
        button(c,{x,19,x+246,85},groupName(group),group<0?liveMint:liveAmber,source==group,
            group<0||players_[group].loaded,[this,group]{
                if(group>=0)setPlayerFocus(group,false);
                const bool keyboard=group<0;
                const int next=std::clamp(homeTonePart_,0,keyboard?6:7);
                openSoundWindow(keyboard,next);
            },23);
    }
    button(c,{218,19,352,85},"Reset…",accent,false,available,[this]{soundResetPanel_=true;dirty_=true;},22);
    button(c,{1150,19,1342,85},keyboard?"Save Kbd Set":"Save Style",accent,false,available,
        [this,keyboard]{openResourceSave(!keyboard);},23);
    button(c,{1360,19,1612,85},"Готово",liveMint,true,true,[this]{closeSoundWindow();},27);
    const int count=keyboard?7:8;
    const float width=1584.0F/count;
    for(int i=0;i<count;++i){
        const float x=28+i*width;
        const auto role=keyboard?arrangerKeyboardPartName(i):state.tracks[i].name;
        const auto name=keyboard?(uppers_[i]?uppers_[i]->soundName:std::string{}):
            styleSoundName(i);
        const RectF roleBox{x,98,x+width-5,149},soundBox{x,150,x+width-5,207};
        box(c,roleBox,i==part?liveKey:liveCard,i==part?accent:liveLine,5);
        label(c,role,x+10,132,23,i==part?accent:liveText,true,width-23);
        box(c,soundBox,liveKey,i==part?accent:liveLine,5);
        label(c,playable(i)&&!name.empty()?name:"Select Sound",x+10,186,21,canChoose?liveText:liveOff,true,width-48);
        label(c,"›",soundBox.right-9,186,23,accent,true,19,Align::Right);
        if(canChoose){
            hit(roleBox,[this,keyboard,i]{openSoundWindow(keyboard,i);});
            hit(soundBox,[chooseSound,i]{chooseSound(i);});
        }
    }
    const bool muted=available&&(keyboard?(!snapshot->part(part).enabled||snapshot->part(part).mute):state.tracks[part].mute);
    const bool listenable=available&&(!keyboard||part!=6||keyboardSplitEnabled_);
    const auto monitor=host::arrangerHost().listenSolo();
    const bool listening=monitor.player==source&&monitor.part==part;
    button(c,{1077,221,1242,284},"Mute",liveStop,muted&&!listening,listenable,[this,source,part,serial]{togglePartMute(source,part,serial);},24,true);
    button(c,{1253,221,1418,284},"Solo",liveAmber,partSolo(source,part),listenable,[this,source,part]{listenPart(source,part);},24,true);
    button(c,{1429,221,1612,284},"Clear Solo",liveAmber,false,monitor.player!=-2,[this]{ctrl_.engine.nativeListenSolo(-2,-1);dirty_=true;},23,true);
    if(soundResetPanel_&&available){
        label(c,"Reset sound controls",820,407,35,liveText,true,900,Align::Center);
        const auto reset=[this,keyboard,player,serial,snapshot,part,count](bool all){
            const auto apply=[&](sampler::Combi& combi){
                for(int i=0;i<count;++i)if(all||i==part)resetPartSoundControls(combi.part(i));
            };
            bool ok=false;
            if(keyboard){
                if(ctrl_.engine.nativeKeyboardCombi()!=snapshot){showToast("The Keyboard Set changed during the edit",3000);return;}
                auto next=*snapshot;apply(next);ok=ctrl_.engine.nativeApplyKeyboardCombi(next,true);
            }else ok=host::arrangerHost().editStyleCombi(player,serial,apply,snapshot.get());
            if(!ok){showToast(keyboard?ctrl_.engine.nativeLastTextError():host::arrangerHost().lastError(),3500);return;}
            soundResetPanel_=false;toneDetail_.clear();markPersistentStateChanged(false);dirty_=true;
        };
        button(c,{157,469,545,575},"Use Sound values",accent,false,true,[reset]{reset(false);},26);
        button(c,{567,469,1067,575},keyboard?"Reset Kbd Tracks":"Reset Style Tracks",accent,false,true,[reset]{reset(true);},26);
        button(c,{1089,469,1483,575},"Cancel",accent,false,true,[this]{soundResetPanel_=false;dirty_=true;},26);
    }else if(available)drawPartSoundDials(c,true,source,part,serial,snapshot,!keyboard&&state.tracks[part].soundSettings.trigger==1);
    else if(canChoose){
        const auto role=keyboard?arrangerKeyboardPartName(part):state.tracks[part].name;
        label(c,role,820,436,32,accent,true,860,Align::Center);
        button(c,{494,469,1146,577},"Select Sound",accent,false,true,[chooseSound,part]{chooseSound(part);},30);
    }else label(c,"Select a Style to edit its Sounds",820,521,31,liveDim,true,1450,Align::Center);
    drawLiveMessage(c,825);
    if(ready)drawLiveTransport(c);
}
