// Local, bounded session capture. Only the background writer touches these files
// during performance. Save Report can read current and previous sessions.
struct ArrangerView::LiveLog {
    std::string base;
    SamplerAppController& controller;
    std::atomic<bool> running{true},healthy{false};
    std::thread worker;
    std::mutex fileMutex,contextMutex;
    std::array<std::string,2> pendingContext;
    std::array<std::string,2> previousSet,previousStyle;
    void observeSource(int player,const host::ArrangerPlayerView& view,const std::string& root){
        const auto i=static_cast<std::size_t>(player);
        if(previousSet[i]==root&&previousStyle[i]==view.sourcePath)return;
        previousSet[i]=root;previousStyle[i]=view.sourcePath;
        std::ostringstream line;
        line<<arranger::liveClockMs()<<" player="<<player+1<<" SET="<<std::quoted(root)<<" style="<<std::quoted(view.sourcePath);
        std::lock_guard<std::mutex> lock(contextMutex);
        pendingContext[i]=line.str();
    }
    explicit LiveLog(const std::string& directory,SamplerAppController& owner)
        :base(files::join(directory,"ARRANGER_LIVE")),controller(owner){
        worker=std::thread([this]{try{run();}catch(...){healthy.store(false);}
            arranger::liveEvents.enabled.store(false,std::memory_order_release);});
    }
    ~LiveLog(){
        running.store(false,std::memory_order_release);
        if(worker.joinable())worker.join();
    }
    std::string history(){
        std::lock_guard<std::mutex> lock(fileMutex);
        std::string result;
        for(const char* name:{".previous.1",".previous",".1",".log"}){
            std::ifstream in(base+name,std::ios::binary);
            if(!in)continue;
            result+="\n--- ";result+=name;result+=" ---\n";
            result.append(std::istreambuf_iterator<char>(in),{});
        }
        return result;
    }
    void run(){
        constexpr std::size_t maxFile=2U*1024U*1024U;
        const auto start=arranger::liveClockMs();
        {
            std::lock_guard<std::mutex> lock(fileMutex);
            if(files::isFile(base+".log")){
                if(files::isFile(base+".1"))std::rename((base+".1").c_str(),(base+".previous.1").c_str());
                else std::remove((base+".previous.1").c_str());
                std::rename((base+".log").c_str(),(base+".previous").c_str());
            }
        }
        const auto initialDrops=arranger::liveEvents.omitted.load();
        arranger::liveEvents.enabled.store(true,std::memory_order_release);
        std::int64_t lastStats=start-1000;
        std::uint64_t writeFailures=0;
        bool first=true;
        do{
            const auto now=arranger::liveClockMs();
            std::ostringstream out;
            if(first){
                out<<"SILVETON ARRANGER LIVE 0.1.62 | start_unix_s="<<std::time(nullptr)
                   <<" | times in ms from launch | MIDI notes numbered 0..127\n";
                first=false;
            }
            {
                std::lock_guard<std::mutex> lock(contextMutex);
                for(auto& context:pendingContext)if(!context.empty()){
                    out<<now-start<<" ms SOURCE monotonic_ms="<<context<<'\n';
                    context.clear();
                }
            }
            arranger::LiveEvent event;
            for(unsigned count=0;count<2048&&arranger::liveEvents.pop(event);++count){
                if(event.ms<start)continue;
                out<<event.ms-start<<" ms "<<event.reason;
                if(event.player>=0)out<<" P"<<event.player+1;
                if(event.status>=0){
                    out<<" channel="<<1+(event.status&15)<<" status="<<event.status<<" key/cc="<<event.key<<" value="<<event.value
                       <<" scan="<<event.area<<" mode="<<event.mode<<" split="<<event.split<<" held=";
                    for(unsigned n=0;n<128;++n)if(event.held[n/32]&(1U<<(n%32)))out<<n<<',';
                    out<<" detected="<<arranger::chordName(event.detected)<<" sounding="<<arranger::chordName(event.sounding);
                }else if(event.value>=0)out<<" value="<<event.value;
                out<<'\n';
            }
            if(now-lastStats>=1000||!running.load()){
                lastStats=now;
                sampler::diagnostics::sampleAudioPageFaults();
                const auto d=sampler::diagnostics::snapshot();
                const auto info=controller.engine.nativeAudioInfo();
                const auto meters=controller.engine.nativeMeters();
                const auto midi=controller.midiStatus();
                const auto field=[&](std::size_t i){return i<info.size()?info[i]:-1;};
                out<<now-start<<" ms AUDIO running="<<controller.audioRunning()<<" error="<<controller.audioLastError()
                   <<" rate="<<field(0)<<" period="<<field(1)<<" buffer="<<field(2)<<" xruns="<<field(3)
                   <<" tid="<<d.audioThreadId<<" blocks="<<d.audioBlocks<<" late="<<d.audioDeadlineMisses
                   <<" last_us="<<d.audioLastUs<<" max_us="<<d.audioWorstUs<<" budget_us="<<d.audioBudgetUs
                   <<" clipped="<<d.clippedSamples<<" steals="<<d.voiceSteals<<" hard_steals="<<d.hardVoiceSteals;
                if(meters.size()>20)out<<" voices="<<meters[3]<<" dropped_midi="<<meters[4]<<" cpu_percent="<<meters[19]<<" dsp_cores="<<meters[20];
                if(d.pageFaultsValid)out<<" minor_faults="<<d.audioMinorFaults<<" major_faults="<<d.audioMajorFaults;
                out<<" log_events_dropped="<<arranger::liveEvents.omitted.load()-initialDrops<<" write_failures="<<writeFailures<<'\n';
                out<<now-start<<" ms MIDI_INPUT devices="<<midi.deviceCount<<" error="<<midi.lastError
                   <<" serial="<<midi.activitySerial<<" last="<<midi.status<<','<<midi.data1<<','<<midi.data2<<'\n';
                for(int p=0;p<2;++p){
                    sampler::VoiceActivity voices;
                    if(host::arrangerHost().pollPlayerVoices(p,voices)){
                        static constexpr const char* names[]={"Drum","Perc","Bass","Acc1","Acc2","Acc3","Acc4","Acc5"};
                        out<<voices.capturedMs-start<<" ms TRACK_VOICES P"<<p+1;
                        for(std::size_t t=0;t<8;++t){
                            const auto& channel=voices.channels[t];
                            out<<" "<<names[t]<<"="<<channel.active;
                            if(channel.active)out<<"(held="<<channel.held<<",pedal="<<channel.sustained
                                <<",oneshot="<<channel.oneShots<<",oldest_key="<<channel.oldestKey
                                <<",sample="<<std::quoted(channel.oldestSample.data())<<")";
                        }
                        out<<'\n';
                    }
                    const auto player=host::arrangerHost().liveTransport(p);
                    out<<now-start<<" ms P"<<p+1<<" playing="<<player.playing<<" bar="<<player.bar<<" beat="<<player.beat
                       <<" measure="<<player.transportMeasure<<" element="<<arranger::elementName(player.element)
                       <<" sync_start="<<player.syncStart<<" sync_stop="<<player.syncStop<<" blocked_tracks="<<int(player.blockedTrackMask)
                       <<" chord="<<arranger::chordName(player.chord)<<'\n';
                }
            }
            const auto chunk=out.str();
            if(!chunk.empty()){
                std::lock_guard<std::mutex> lock(fileMutex);
                std::ofstream file(base+".log",std::ios::app|std::ios::binary);
                if(file&&file.tellp()+static_cast<std::streamoff>(chunk.size())>static_cast<std::streamoff>(maxFile)){
                    file.close();
                    if(std::rename((base+".log").c_str(),(base+".1").c_str())==0)
                        file.open(base+".log",std::ios::trunc|std::ios::binary);
                    else file.setstate(std::ios::failbit);
                }
                file<<chunk;file.flush();
                healthy.store(file.good(),std::memory_order_release);
                if(!file)++writeFailures;
            }
            if(!running.load(std::memory_order_acquire))break;
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }while(true);
    }
};
