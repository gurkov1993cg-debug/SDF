// Four KBD SET buttons recall assigned performances or open the full selector.
void ArrangerView::tapLiveKeyboardSlot(int position,const RectF& rect){
    if(keyboardWorkingSets_[position].combi||keyboardSets_[position]>0||!keyboardSetPaths_[position].empty()){
        selectPanelKeyboardSet(position,rect);return;
    }
    openKeyboardSetSelector(position);
}
