// Compact performance selector under the Keyboard Set title.
void ArrangerView::rebuildLiveLists(){
    if(liveSessionPath_!=persistentSessionPath_)savedKeyboardLibraryDirty_=true;
    const bool newSet=liveCatalog_.owner_before(kstCatalog_)||kstCatalog_.owner_before(liveCatalog_);
    if(!liveListsDirty_&&!savedKeyboardLibraryDirty_&&!newSet&&liveSessionPath_==persistentSessionPath_&&liveSamplerBank_==uiBank_)return;
    auto& s=performanceSelector_;
    const std::string previous=!s.banks.empty()&&!newSet?s.banks[s.bank].id:std::string{};
    s.banks.clear();s.bank=0;
    std::map<std::string,std::size_t> indices;
    const auto add=[&](LiveResource type,const std::string& id,const std::string& name,LiveItem item){
        const auto index=indices.emplace(id,s.banks.size());
        if(index.second)s.banks.push_back({id,name,type,{}});
        s.banks[index.first->second].items.push_back(std::move(item));
    };
    if(kstCatalog_){
        for(const auto& k:kstCatalog_->keyboardSets){
            std::string bank;
            if(!arranger::paKeyboardLocation(k.relativePath,&bank))
                bank=arranger::paPerformanceBankPath(k.relativePath)?k.relativePath:files::parentOf(k.relativePath);
            const auto title=files::nameOf(bank);
            add(LiveResource::KeyboardSet,"set/"+bank,title.empty()?"SET Keyboard Sets":title,
                {k.name,k.path,k.metadataSupported?"":k.blocker.empty()?"Unsupported Performance":k.blocker,0,k.ordinal});
        }
    }
    refreshSavedKeyboardEntries();
    for(const auto& k:savedKeyboardEntries_){
        const auto bank="User "+std::to_string(k.bank);
        add(LiveResource::UserKeyboard,"user/"+bank,bank,{k.name,k.path,{},k.bank,k.position});
    }
    for(const auto& k:ctrl_.combiCatalog())
        add(LiveResource::Combi,"combi","COMBI",{k.second,{},{},0,k.first});
    const auto found=indices.find(previous);
    if(found!=indices.end())s.bank=static_cast<int>(found->second);
    else {
        s.bank=0;s.bankPage=s.page=0;s.choosingBank=false;
        for(int bankIndex=0;bankIndex<static_cast<int>(s.banks.size());++bankIndex){
            const auto& bank=s.banks[bankIndex];
            const auto active=std::find_if(bank.items.begin(),bank.items.end(),[&](const LiveItem& item){
                switch(bank.type){
                    case LiveResource::KeyboardSet:return activeSavedKeyboardEntryPath_.empty()&&item.path==activeNativeKeyboardSetPath_;
                    case LiveResource::UserKeyboard:return item.path==activeSavedKeyboardEntryPath_;
                    case LiveResource::Combi:return currentKeyboardCombiSlot_>0&&item.slot==currentKeyboardCombiSlot_;
                }
                return false;
            });
            if(active!=bank.items.end()){
                s.bank=bankIndex;s.page=static_cast<int>((active-bank.items.begin())/6);break;
            }
        }
    }
    liveListsDirty_=false;liveCatalog_=kstCatalog_;liveSessionPath_=persistentSessionPath_;
    liveSamplerBank_=uiBank_;++liveListGeneration_;
}
void ArrangerView::tapLiveKeyboardSlot(int position,const RectF& rect){
    if(keyboardWorkingSets_[position].combi||keyboardSets_[position]>0||!keyboardSetPaths_[position].empty()){
        liveSlot_=-1;choosingPerformance_=false;selectPanelKeyboardSet(position,rect);return;
    }
    openKeyboardSetSelector(position);
}
void ArrangerView::chooseLiveItem(int index){
    auto& s=performanceSelector_;
    if(kstJob_||persistentRestoreActive_||s.banks.empty())return;
    const auto& bank=s.banks[s.bank];
    if(index<0||index>=static_cast<int>(bank.items.size()))return;
    const auto item=bank.items[index];
    if(!item.error.empty()){showToast(item.error,5000);return;}
    const int target=liveSlot_;
    if(target>=0){
        const auto current=host::arrangerHost().snapshot(selectedPlayer_);
        if(liveSlotPlayer_!=selectedPlayer_||liveSlotSerial_!=current.styleSelectionSerial||current.styleSwitchPending){
            liveSlot_=-1;showToast("Style changed. Select the Keyboard Set position again.",4500);return;
        }
    }
    if(bank.type==LiveResource::Combi){
        KeyboardWorkingSet state;std::string error;
        if(!prepareWorkingKeyboardSet({},item.slot,state,error)){showToast(error,5500);return;}
        if(!applyWorkingKeyboardSet(state,target,true))return;
        if(target>=0){
            keyboardSetPaths_[target].clear();keyboardSets_[target]=item.slot;
            keyboardSetNames_[target]=state.combi->name;keyboardWorkingSets_[target]=captureKeyboardWorkingSet();
        }
        overrideStyleKeyboardCue();
    }else if(!activateNativeKeyboardSet(item.path,target))return;
    choosingPerformance_=false;liveSlot_=-1;markPersistentStateChanged();dirty_=true;
}
void ArrangerView::drawLiveSelector(Canvas& c,bool ready){
    auto& s=performanceSelector_;constexpr float x=823;
    constexpr float width=793;
    const auto accent=liveMint;
    const bool empty=s.banks.empty();
    const auto* bank=empty?nullptr:&s.banks[s.bank];
    const int count=s.choosingBank?static_cast<int>(s.banks.size()):bank?static_cast<int>(bank->items.size()):0;
    constexpr int perPage=6;
    const int pages=std::max(1,(count+perPage-1)/perPage);
    int& page=s.choosingBank?s.bankPage:s.page;page=std::clamp(page,0,pages-1);
    const float end=x+width;
    const auto selectorButton=[this,&c,ready](RectF rect,const std::string& name,bool enabled,std::function<void()> action){
        box(c,rect,liveKey,liveLine,5);
        label(c,name,rect.centerX(),rect.centerY()+8,23,enabled?accent:liveOff,true,rect.width()-15,Align::Center);
        if(enabled&&ready)hit(rect,std::move(action));
    };
    selectorButton({x,175,end-375,233},s.choosingBank?"‹  Banks":bank?"Bank   "+bank->name+"   ▾":"Banks",!empty,
        [this]{auto& a=performanceSelector_;a.choosingBank=!a.choosingBank;if(a.choosingBank)a.bankPage=a.bank/6;dirty_=true;});
    selectorButton({end-365,175,end-232,233},"Browse",true,[this]{
        openKeyboardSetSelector(liveSlot_);
    });
    selectorButton({end-221,175,end-151,233},"‹",page>0,[this]{auto& a=performanceSelector_;--(a.choosingBank?a.bankPage:a.page);dirty_=true;});
    label(c,std::to_string(page+1)+"/"+std::to_string(pages),end-110,213,20,liveText,true,81,Align::Center);
    selectorButton({end-70,175,end,233},"›",page+1<pages,[this]{auto& a=performanceSelector_;++(a.choosingBank?a.bankPage:a.page);dirty_=true;});
    if(empty){
        selectorButton({x,246,end,435},"Load a Keyboard Set bank",true,[this]{openPanelFile();});return;
    }
    const auto generation=liveListGeneration_;
    const int expectedBank=s.bank,expectedPage=page,playerNumber=selectedPlayer_;
    const bool choosing=s.choosingBank;
    for(int cell=0;cell<perPage;++cell){
        const int index=page*perPage+cell;
        const float stride=(width+8)*0.5F,left=x+(cell%2)*stride,top=242+(cell/2)*67.0F;
        const RectF rect{left,top,left+stride-8,top+61};
        if(index>=count){box(c,rect,liveBg,liveLine,4);continue;}
        const LiveItem* item=s.choosingBank?nullptr:&bank->items[index];
        bool selected=s.choosingBank&&s.bank==index;
        if(item)switch(bank->type){
            case LiveResource::KeyboardSet:selected=activeNativeKeyboardSetPath_==item->path&&
                !startsWith(files::nameOf(activeSavedKeyboardEntryPath_),"ARRANGER_USER_KBD_");break;
            case LiveResource::UserKeyboard:selected=activeSavedKeyboardEntryPath_==item->path;break;
            case LiveResource::Combi:selected=currentKeyboardCombiSlot_==item->slot;break;
        }
        const bool available=!item||item->error.empty();
        box(c,rect,selected?accent:liveCard,selected?accent:liveLine,5);
        const float inset=item&&item->slot>0?53.0F:15.0F;
        if(item&&item->slot>0)label(c,std::to_string(item->slot),left+9,top+37,17,selected?liveBg:accent,true,40);
        label(c,item?item->name:s.banks[index].name,left+inset,top+39,26,selected?liveBg:available?liveText:liveOff,true,rect.width()-inset-14);
        if(ready)hit(rect,[this,index,generation,expectedBank,expectedPage,choosing,playerNumber]{
            if(liveListGeneration_!=generation||selectedPlayer_!=playerNumber||picker_!=Picker::None||tab_!=Tab::Main)return;
            auto& a=performanceSelector_;
            if(a.bank!=expectedBank||a.choosingBank!=choosing||(choosing?a.bankPage:a.page)!=expectedPage)return;
            if(a.choosingBank){a.bank=index;a.page=0;a.choosingBank=false;dirty_=true;}
            else chooseLiveItem(index);
        });
    }
}
