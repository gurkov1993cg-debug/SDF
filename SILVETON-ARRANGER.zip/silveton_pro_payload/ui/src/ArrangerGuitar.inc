// Included inside drawKeyboardEdit. Guitar controls belong to the exact
// Style element/track and share its CVs; sampler voice mode stays separate.
const int player=trackEditPlayer_;
const auto& state=players_[player];
const int element=rangeElement_<0?state.element:rangeElement_;
if(choosingRangeElement_){
    hits_.resize(panelHits);
    box(c,{0,0,800,480},bg);
    button(c,{12,6,145,51},"‹ Back",orange,false,true,[this]{choosingRangeElement_=false;dirty_=true;},16);
    label(c,"Style Element",167,38,21,white,true,339);
    button(c,{510,6,788,51},"Follow playing section",green,rangeElement_<0,true,[this]{rangeElement_=-1;choosingRangeElement_=false;dirty_=true;},16);
    for(int i=0;i<int(elementNames.size());++i){
        const float x=12+(i%3)*261.0F,y=65+(i/3)*80.0F;
        button(c,{x,y,x+250,y+69},elementNames[i],orange,i==element,state.available[i],[this,i]{choosingRangeElement_=false;rangeElement_=i;dirty_=true;},18);
    }
    return;
}
button(c,{12,43,699,90},std::string("Style Element   ·   ")+elementNames[std::clamp(element,0,14)]+
       (rangeElement_<0?"   ·   Follow":"")+"   ▾",orange,false,true,[this]{choosingRangeElement_=true;dirty_=true;},17);
for(int column=0;column<4;++column){
    const int part=parts[column];const float x=12+column*174.0F;
    const auto guitar=host::arrangerHost().styleGuitar(player,selection,element,part);
    label(c,partName(part),x+83,112,17,styleEditTrack_==part?green:white,true,157,Align::Center);
    hit({x,94,x+166,117},[this,part]{styleEditTrack_=part;dirty_=true;});
    if(!guitar.available){
        if(guitar.sourceDeclaredGuitar){
            label(c,"SET GTR · blocked",x+83,129,11,orange,false,162,Align::Center);
            label(c,"Original Guitar",x+83,214,16,orange,false,157,Align::Center);
            label(c,"pattern unavailable",x+83,238,14,dim,false,157,Align::Center);
            button(c,{x,263,x+166,307},"Read source",orange,false,true,[this,player,selection,element]{
                if(host::arrangerHost().snapshot(player).styleSelectionSerial!=selection){
                    showToast("The selected Style changed",4000);return;
                }
                openStyleRead(player);
                if(picker_==Picker::StyleRead)styleReadElement_=element;
                dirty_=true;
            },13);
        }else{
            label(c,"No ACC/GTR",x+83,214,16,dim,false,157,Align::Center);
            label(c,"pattern here",x+83,238,15,dim,false,157,Align::Center);
        }
        continue;
    }
    label(c,std::string("SET ")+(guitar.sourceGuitar?"GTR":"ACC")+
          (guitar.overrides.mode<0?" · Auto ":" · Manual ")+(guitar.guitar?"On":"Off"),
          x+83,129,11,guitar.guitar?green:dim,false,162,Align::Center);
    const auto apply=[this,player,selection,element,part](host::GuitarField option,int value){
        if(option!=host::GuitarField::Mode){
            const auto current=host::arrangerHost().styleGuitar(player,selection,element,part);
            if(!current.available||!current.guitar)return;
        }
        if(host::arrangerHost().editGuitar(player,selection,element,part,option,value)){
            styleEditTrack_=part;
            markPersistentStateChanged(false);
            if(option==host::GuitarField::ResetSource)showToast("Guitar controls follow the original SET values and defaults. Save Style to keep them.",5000);
        }
        else showToast(host::arrangerHost().lastError(),4500);
        dirty_=true;
    };
    static const char* modes[]{"Auto","ACC","GTR"};
    for(int mode=0;mode<3;++mode){
        const int value=mode-1;const float left=x+mode*57.0F;
        button(c,{left,137,left+52,174},modes[mode],green,guitar.overrides.mode==value,true,
               [apply,value]{apply(host::GuitarField::Mode,value);},12);
    }
    const auto shown=[](int value,int overrideValue,bool fromStyle){
        return std::to_string(value)+(overrideValue<0?(fromStyle?" · SET":" · Default"):"");
    };
    const auto& settings=guitar.settings;
    field({x,181,x+166,223},"Capo · minimum fret",shown(settings.capo,guitar.overrides.capo,guitar.sourceCapoKnown),settings.capo,0,12,
          [apply](float v){apply(host::GuitarField::Capo,int(v));},true,false,guitar.guitar);
    field({x,230,x+166,272},"Highest string",shown(settings.highString,guitar.overrides.highString,false),settings.highString,1,settings.lowString,
          [apply](float v){apply(host::GuitarField::HighString,int(v));},true,false,guitar.guitar);
    field({x,279,x+166,321},"Lowest string",shown(settings.lowString,guitar.overrides.lowString,false),settings.lowString,settings.highString,6,
          [apply](float v){apply(host::GuitarField::LowString,int(v));},true,false,guitar.guitar);
    field({x,328,x+166,370},"Humanize · SILVETON",shown(settings.humanize,guitar.overrides.humanize,guitar.sourceHumanizeKnown),settings.humanize,0,127,
          [apply](float v){apply(host::GuitarField::Humanize,int(v));},true,false,guitar.guitar);
    button(c,{x,377,x+166,412},"Reset source",green,false,guitar.guitar&&guitar.edited,
           [apply]{apply(host::GuitarField::ResetSource,0);},13);
}
