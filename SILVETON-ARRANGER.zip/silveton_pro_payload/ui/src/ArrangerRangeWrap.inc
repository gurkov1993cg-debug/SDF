const int player=trackEditPlayer_;
const auto& state=players_[player];
const int element=rangeElement_<0?state.element:rangeElement_;
if(choosingRangeElement_){
    hits_.resize(panelHits);
    box(c,{0,0,800,480},bg);
    button(c,{12,6,145,51},"‹ Back",orange,false,true,[this]{choosingRangeElement_=false;dirty_=true;},16);
    label(c,"Style Element",167,38,21,white,true,339);
    button(c,{510,6,788,51},"Follow playing section",green,rangeElement_<0,true,[this]{rangeElement_=-1;choosingRangeElement_=false;dirty_=true;},16);
    for(int i=0;i<int(elementNames.size());++i){
        const float x=12+(i%3)*261.0F,y=65+(i/3)*80.0F;
        button(c,{x,y,x+250,y+69},elementNames[i],orange,i==element,state.available[i],[this,i]{choosingRangeElement_=false;rangeElement_=i;dirty_=true;},18);
    }
    return;
}
button(c,{12,43,699,93},std::string("Style Element   ·   ")+elementNames[std::clamp(element,0,14)]+(rangeElement_<0?"   ·   Follow":"")+"   ▾",orange,false,true,[this]{choosingRangeElement_=true;dirty_=true;},17);
for(int i=0;i<4;++i){
    const int part=parts[i];const float x=12+i*174.0F;
    const auto r=host::arrangerHost().styleRange(player,selection,element,part);
    label(c,partName(part),x+83,123,17,white,true,157,Align::Center);
    if(!r.available){label(c,"—",x+83,217,21,dim,false,155,Align::Center);continue;}
    const auto apply=[this,player,selection,element,part](host::RangeField f,int value){
        if(host::arrangerHost().editRange(player,selection,element,part,f,value))markPersistentStateChanged(false);
        else showToast(host::arrangerHost().lastError(),4500);
        dirty_=true;
    };
    toggle({x,137,x+166,179},r.enabled?"Sound Range On":"Sound Range Off",r.enabled,[apply,r]{apply(host::RangeField::Enable,!r.enabled);});
    field({x,186,x+166,232},"Top Key",arrangerNoteName(r.high),r.high,r.low,127,[apply](float v){apply(host::RangeField::High,int(v));},true);
    field({x,238,x+166,284},"Bottom Key",arrangerNoteName(r.low),r.low,0,r.high,[apply](float v){apply(host::RangeField::Low,int(v));},true);
    field({x,290,x+166,336},"Wrap Around",r.wrap?std::to_string(r.wrap)+" st":"Style",r.wrap?r.wrap:6,1,12,[apply](float v){apply(host::RangeField::Wrap,int(v));},true);
    button(c,{x,343,x+166,375},"Reset range",green,false,r.edited,[apply]{apply(host::RangeField::ResetRange,0);},12);
    button(c,{x,380,x+166,414},"Reset wrap",green,false,r.wrapEdited,[apply]{apply(host::RangeField::ResetWrap,0);},12);
}
