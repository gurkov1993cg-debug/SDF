// SILVETON_NEW_LOOK_V1 - SOUND EDIT groups WAVE, EQ, VOICE, MIDI CONTROL
// WAVE, VOICE and MIDI CONTROL are here; the EQ group (drawEditEq) lives next to the analyzer in View_Eq.cpp.
// Every function draws only the BODY inside the content panel (232,160,1088x490), in absolute design units, with the numbers of the
// picture generator (gui/screens2.py: wave(), voice(), midi_control()). The frame (UPPER chips, group list, title, SOUND selector, hint) is drawn by drawSoundEdit.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expf_(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rnd(float v) { return static_cast<int>(std::nearbyint(v)); }
float rndf(float v) { return std::nearbyint(v); }
// defaults of the wave ids (0 mode 1 frames 2 pos 3 start 4 span 5 smooth 6 source 7 amount 8 time ms 9 rate Hz 10..17 slots) - the same as the old WAVE page
float waveDef(int id) {
    static const float d[10] = {0.0F, 16.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, 0.5F, 1500.0F, 0.5F};
    return id >= 0 && id < 10 ? d[id] : 0.0F;
}
std::string msText(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), 2) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}
constexpr ColorInt kHint = Color::rgb(138, 147, 157);      // #8a939d  small grey text
constexpr ColorInt kTxt = Color::rgb(207, 214, 222);       // #cfd6de  plain text
constexpr ColorInt kLitText = Color::rgb(255, 177, 58);    // #ffb13a  text of a lit key
constexpr ColorInt kOffText = Color::rgb(121, 130, 140);   // text of a key that is off
} // namespace

// ---------------------------------------------------------------- helpers
void SilvetonSamplerView::e2Text(Canvas& c, const std::string& s, float x, float top, float size, ColorInt color, const Opt& o) {
    text(c, s, x, top + size * 0.95F, size, color, o);
}

void SilvetonSamplerView::e2Label(Canvas& c, const std::string& s, float x, float top) {
    nlLabel(c, s, x, top + 10.5F, false, NL_TXT2, 11.0F);
}

void SilvetonSamplerView::e2Knob(Canvas& c, float cx, float cy, float d, const std::string& label, const std::string& valueText, float value, float minV,
                                 float maxV, float step, float travel, bool bipolar, float vw, std::function<void(float)> onChange,
                                 std::function<void()> exact, std::function<void()> reset) {
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    nlKnob(c, cx, cy, d * 0.33F, t, bipolar, false, true);
    if (!label.empty()) nlLabel(c, label, cx, cy - d / 2.0F - 5.0F, true, NL_TXT2, 11.0F);
    const float fs = d >= 80.0F ? 13.0F : 12.0F;
    const float vTop = cy + d / 2.0F - 2.0F;
    nlValue(c, RectF(cx - vw / 2.0F, vTop, cx + vw / 2.0F, vTop + fs + 10.0F), valueText, fs);
    const float hw = std::max(vw, d) + 24.0F;
    knobHit(RectF(cx - hw / 2.0F, cy - d / 2.0F - 14.0F, cx + hw / 2.0F, vTop), value, minV, maxV, step, travel, onChange, exact, reset);
    hit(RectF(cx - hw / 2.0F, vTop, cx + hw / 2.0F, vTop + fs + 14.0F), [exact](float, float) { exact(); }, reset);
}

void SilvetonSamplerView::e2Lit(Canvas& c, const RectF& r, const std::string& label, const std::string& sub, bool on, float size, bool lamp) {
    const bool lampOk = lamp && r.height() >= 30.0F;
    nlBtn(c, r, std::string(), on ? NlBtn::Plain : NlBtn::Off, size, lamp);
    if (on && lampOk) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
    }
    const ColorInt col = on ? kLitText : kOffText;
    const float mw = r.width() - 10.0F;
    if (sub.empty()) {
        text(c, label, r.centerX(), r.centerY() + size * 0.36F + (lampOk ? 2.0F : 0.0F), size, col, Opt().center().bold().spacing(0.07F).maxW(mw));
    } else {
        text(c, label, r.centerX(), r.centerY() - size * 0.09F, size, col, Opt().center().bold().spacing(0.05F).maxW(mw));
        text(c, sub, r.centerX(), r.centerY() + size * 0.83F, 10.5F, colorWithAlpha(col, 204), Opt().center().spacing(0.06F).maxW(mw));
    }
}

void SilvetonSamplerView::e2Slider(Canvas& c, float x, const std::string& label, const std::string& value, float t, std::function<void(float)> onDrag,
                                   std::function<void()> plus, std::function<void()> minus, std::function<void()> exact) {
    e2Label(c, label, x, 522.0F);
    const RectF vr(x + 62.0F, 518.0F, x + 182.0F, 542.0F);
    nlValue(c, vr, value, 13.0F);
    const RectF mR(x, 548.0F, x + 44.0F, 588.0F);
    const RectF pR(x + 290.0F, 548.0F, x + 334.0F, 588.0F);
    const float tx0 = x + 52.0F;
    const float tx1 = x + 282.0F;
    fill(c, RectF(tx0, 562.0F, tx1, 574.0F), 6.0F, Color::rgb(11, 14, 18));   // the groove
    line(c, tx0 + 5.0F, 563.0F, tx1 - 5.0F, 563.0F, Color::argb(160, 0, 0, 0), 2.0F);
    const float px = tx0 + (tx1 - tx0) * std::clamp(t, 0.0F, 1.0F);
    if (px > tx0 + 2.0F) fillV(c, RectF(tx0, 562.0F, px, 574.0F), 5.0F, Color::rgb(82, 180, 255), Color::rgb(23, 102, 201));
    nlFaderCap(c, px, 568.0F, 30.0F, 36.0F);
    nlBtn(c, mR, "−", NlBtn::Plain, 18.0F, false);   // minus sign
    nlBtn(c, pR, "+", NlBtn::Plain, 18.0F, false);
    hit(RectF(tx0 - 8.0F, 546.0F, tx1 + 8.0F, 590.0F), [onDrag, tx0, tx1](float px2, float) { onDrag(std::clamp((px2 - tx0) / (tx1 - tx0), 0.0F, 1.0F)); }, nullptr,
        [onDrag, tx0, tx1](float px2, float, bool) { onDrag(std::clamp((px2 - tx0) / (tx1 - tx0), 0.0F, 1.0F)); });
    hit(vr, [exact](float, float) { exact(); });
    hit(mR, [minus](float, float) { minus(); });
    hit(pR, [plus](float, float) { plus(); });
}

// ---------------------------------------------------------------- WAVE (TRANSWAVE): the same controls and ids as the old WAVE page
void SilvetonSamplerView::drawEditWave(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(stripSound[static_cast<std::size_t>(u)], 0, 4);   // the sound chosen in the SOUND row (0 = MAIN, 1..4 = L1..L4)
    editSound = sound;
    if(sampler.soundSource(u,sound).engine.chosen()){drawSoloSource(c,u,sound);return;}
    const std::vector<float> wp = wParams(u, sound);
    auto wv = [&wp](int id) { return getOr(wp, id, waveDef(id)); };
    const int mode = std::clamp(rnd(wv(0)), 0, 2);
    const int source = std::clamp(rnd(wv(6)), 0, 6);

    // MODE
    e2Label(c, "MODE", 250.0F, 232.0F);
    static const char* const modeNames[3] = {"OFF", "AUTO", "MULTI"};
    for (int k = 0; k < 3; ++k) {
        const RectF kr(250.0F + 120.0F * static_cast<float>(k), 254.0F, 364.0F + 120.0F * static_cast<float>(k), 312.0F);
        nlBtn(c, kr, modeNames[k], mode == k ? NlBtn::On : NlBtn::Off, 14.0F, true);
        hit(kr, [this, u, sound, k](float, float) { setWaveP(u, sound, 0, static_cast<float>(k)); });
    }
    const RectF choose(250.0F, 325.0F, 604.0F, 363.0F);
    nlBtn(c, choose, "CHOOSE SOUND…", NlBtn::Plain, 13.0F, false);
    hit(choose, [this, u, sound](float, float) { openPicker(u, sound - 1); });

    // POSITION, START, SMOOTH | SPAN, FRAMES (OFF and AUTO) | the text of MULTI
    auto pctKnob = [&](float cx, int id, const std::string& label, float minPct) {
        const float v = wv(id);
        e2Knob(c, cx, 290.0F, 84.0F, label, std::to_string(rnd(v * 100.0F)) + " %", v, 0.0F, 1.0F, 0.005F, 260.0F, false, 71.0F,
               [this, u, sound, id](float nv) { setWaveP(u, sound, id, nv); },
               [this, u, sound, id, label, v, minPct] {
                   showNumber(label + " %", v * 100.0F, std::max(0.0F, minPct), 100.0F, 0, [this, u, sound, id](float x) { setWaveP(u, sound, id, x / 100.0F); });
               },
               [this, u, sound, id] { setWaveP(u, sound, id, waveDef(id)); });
    };
    pctKnob(670.0F, 2, "POSITION", 0.0F);
    pctKnob(800.0F, 3, "START", 0.0F);
    pctKnob(930.0F, 5, "SMOOTH", 0.0F);
    if (mode == 2) {
        e2Text(c, "MULTI: the frames are", 1060.0F, 262.0F, 13.0F, kTxt);
        e2Text(c, "the chosen sounds", 1060.0F, 284.0F, 13.0F, kTxt);
    } else {
        pctKnob(1060.0F, 4, "SPAN", 2.0F);
        const float fr = wv(1);
        e2Knob(c, 1190.0F, 290.0F, 84.0F, "FRAMES", std::to_string(rnd(fr)), fr, 2.0F, 32.0F, 1.0F, 260.0F, false, 71.0F,
               [this, u, sound](float nv) { setWaveP(u, sound, 1, std::round(nv)); },
               [this, u, sound, fr] { showNumber("FRAMES", fr, 2.0F, 32.0F, 0, [this, u, sound](float x) { setWaveP(u, sound, 1, x); }); },
               [this, u, sound] { setWaveP(u, sound, 1, waveDef(1)); });
    }

    // POSITION MOVES BY | AMOUNT | TIME (ENV) or RATE (LFO)
    e2Label(c, "POSITION MOVES BY", 250.0F, 372.0F);
    static const char* const srcNames[7] = {"OFF", "ENV", "LFO", "VEL", "WHEEL", "AFTER", "NOTE"};
    for (int k = 0; k < 7; ++k) {
        const RectF kr(250.0F + 106.0F * static_cast<float>(k), 394.0F, 350.0F + 106.0F * static_cast<float>(k), 442.0F);
        nlBtn(c, kr, srcNames[k], source == k ? NlBtn::On : NlBtn::Off, 12.0F, true);
        hit(kr, [this, u, sound, k](float, float) { setWaveP(u, sound, 6, static_cast<float>(k)); });
    }
    {
        const float am = wv(7);
        e2Knob(c, 1090.0F, 420.0F, 70.0F, "AMOUNT", (am > 0.004F ? "+" : std::string()) + std::to_string(rnd(am * 100.0F)) + " %", am, -1.0F, 1.0F, 0.01F, 260.0F, true, 78.0F,
               [this, u, sound](float nv) { setWaveP(u, sound, 7, nv); },
               [this, u, sound, am] { showNumber("AMOUNT %", am * 100.0F, -100.0F, 100.0F, 0, [this, u, sound](float x) { setWaveP(u, sound, 7, x / 100.0F); }); },
               [this, u, sound] { setWaveP(u, sound, 7, waveDef(7)); });
    }
    if (source == 1) {
        const float t = wv(8);
        const float norm = lnf(std::clamp(t, 10.0F, 20000.0F) / 10.0F) / lnf(2000.0F);
        e2Knob(c, 1210.0F, 420.0F, 70.0F, "TIME", msText(t), norm, 0.0F, 1.0F, 0.002F, 260.0F, false, 78.0F,
               [this, u, sound](float nv) { setWaveP(u, sound, 8, rndf(10.0F * expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(2000.0F)))); },
               [this, u, sound, t] { showNumber("TIME ms", t, 10.0F, 20000.0F, 0, [this, u, sound](float x) { setWaveP(u, sound, 8, x); }); },
               [this, u, sound] { setWaveP(u, sound, 8, waveDef(8)); });
    } else if (source == 2) {
        const float r = wv(9);
        const float norm = lnf(std::clamp(r, 0.02F, 30.0F) / 0.02F) / lnf(1500.0F);
        e2Knob(c, 1210.0F, 420.0F, 70.0F, "RATE", fmtFixed(static_cast<double>(r), 2) + " Hz", norm, 0.0F, 1.0F, 0.002F, 260.0F, false, 78.0F,
               [this, u, sound](float nv) { setWaveP(u, sound, 9, 0.02F * expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(1500.0F))); },
               [this, u, sound, r] { showNumber("SPEED Hz", r, 0.02F, 30.0F, 2, [this, u, sound](float x) { setWaveP(u, sound, 9, x); }); },
               [this, u, sound] { setWaveP(u, sound, 9, waveDef(9)); });
    } else {
        text(c, source == 0 ? "manual" : "—", 1210.0F, 426.0F, 12.0F, kHint, Opt().center());
    }

    // the bottom panel: the 8 frames of MULTI, or a few words about AUTO / OFF
    nlPanel(c, RectF(250.0F, 512.0F, 1310.0F, 636.0F));
    if (mode == 2) {
        e2Text(c, "FRAMES · UP TO 8 SOUNDS · tap = choose a sound · hold = clear", 264.0F, 518.0F, 11.0F, NL_TXT2, Opt().bold().spacing(0.1F));
        int slots[8];
        bool any = false;
        for (int k = 0; k < 8; ++k) { slots[k] = rnd(wv(10 + k)); if (slots[k] > 0) any = true; }
        std::vector<SoundItem> catalog;
        if (any) catalog = sampler.soundCatalog();
        for (int k = 0; k < 8; ++k) {
            const RectF kr(264.0F + 258.0F * static_cast<float>(k % 4), 540.0F + 44.0F * static_cast<float>(k / 4), 514.0F + 258.0F * static_cast<float>(k % 4), 578.0F + 44.0F * static_cast<float>(k / 4));
            std::string name = "—";
            if (slots[k] > 0) {
                name = "#" + std::to_string(slots[k]);
                for (const auto& it : catalog) if (it.slot == slots[k]) { name = it.name; break; }
            }
            nlBtn(c, kr, std::to_string(k + 1) + "  " + name, NlBtn::Off, 12.0F, false);
            hit(kr, [this, u, sound, k](float, float) { openPicker(u, kWavePickerBase + sound * 8 + k); },
                [this, u, sound, k] { setWaveP(u, sound, 10 + k, 0.0F); });
        }
    } else if (mode == 1) {
        e2Text(c, "AUTO: the sample of the sound is cut into frames", 264.0F, 540.0F, 14.0F, kTxt);
        e2Text(c, "START / SPAN / FRAMES say from where and how many", 264.0F, 566.0F, 13.0F, kHint);
        e2Text(c, "choose MULTI to use up to 8 different sounds as frames", 264.0F, 590.0F, 13.0F, kHint);
    } else {
        e2Text(c, "TRANSWAVE is off", 264.0F, 540.0F, 14.0F, kTxt);
        e2Text(c, "choose AUTO or MULTI", 264.0F, 566.0F, 13.0F, kHint);
    }
}

// ---------------------------------------------------------------- shared Upper tuning and decay
void SilvetonSamplerView::drawEditPartTune(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    auto& state = upperStates[static_cast<std::size_t>(u)];
    if (!state) state = sampler.upperState(u);
    if (!state) return;
    // These two controls are global; keep their scope explicit and separate
    // from the per-Upper even-decay limit.
    nlPanel(c, RectF(250.0F, 222.0F, 870.0F, 610.0F), "SILVETON PORTAMENTO · ALL UPPERS");
    nlPanel(c, RectF(886.0F, 222.0F, 1310.0F, 610.0F), "EVEN DECAY · MAIN + L1–L4");
    const float balance = static_cast<float>(sampler.portaBalance());
    neDial(c, 420.0F, 364.0F, 104.0F, "BALANCE", fmtFixed(balance, 0), balance, 3.0F, 40.0F, 1.0F, 300.0F, false,
           [this](float value) { sampler.setPortaBalance(rnd(value)); },
           [this, balance] { showNumber("GLOBAL PORTA BALANCE (interval timing)", balance, 3.0F, 40.0F, 0,
               [this](float value) { sampler.setPortaBalance(rnd(value)); }); },
           [this] { sampler.setPortaBalance(11); }, 120.0F);
    const float nearMs = static_cast<float>(sampler.portaNear());
    neDial(c, 710.0F, 364.0F, 104.0F, "TIME NEAR", fmtFixed(nearMs, 0) + " ms", nearMs, 0.0F, 400.0F, 1.0F, 300.0F, false,
           [this](float value) { sampler.setPortaNear(rnd(value)); },
           [this, nearMs] { showNumber("GLOBAL NEAR-NOTE TIME ms", nearMs, 0.0F, 400.0F, 0,
               [this](float value) { sampler.setPortaNear(rnd(value)); }); },
           [this] { sampler.setPortaNear(90); }, 120.0F);
    text(c, "BALANCE sets interval timing; TIME NEAR sets adjacent-note time.", 274.0F, 490.0F, 13.0F, NL_TXT2, Opt().maxW(570.0F));
    text(c, "Applies to every Upper in SILVETON portamento mode.", 274.0F, 522.0F, 13.0F, NL_TXT2, Opt().maxW(570.0F));
    text(c, "Each Upper keeps its own TIME in QUICK CONTROLS.", 274.0F, 551.0F, 13.0F, NL_TXT2, Opt().maxW(570.0F));
    const float decayMs = getOr(uParams(u), 49, 0.0F);
    const float normalized = decayMs < 30.0F ? 0.0F : 0.05F + 0.95F * lnf(std::clamp(decayMs, 30.0F, 3000.0F) / 30.0F) / lnf(100.0F);
    neDial(c, 1098.0F, 364.0F, 112.0F, "EVEN DECAY", msText(decayMs), normalized, 0.0F, 1.0F, 0.002F, 260.0F, false,
           [this, u](float value) {
               const float ms = value < 0.03F ? 0.0F : rndf(30.0F * expf_(std::clamp((value - 0.05F) / 0.95F, 0.0F, 1.0F) * lnf(100.0F)));
               setUParam(u, 49, ms);
           },
           [this, u, decayMs] { showNumber("UPPER EVEN DECAY ms (0 = OFF)", decayMs, 0.0F, 3000.0F, 0,
               [this, u](float value) { setUParam(u, 49, value >= 30.0F ? value : 0.0F); }); },
           [this, u] { setUParam(u, 49, 0.0F); }, 132.0F);
    text(c, "A common decay limit for this Upper.", 910.0F, 490.0F, 13.0F, NL_TXT2, Opt().maxW(380.0F));
    text(c, "OFF keeps each sound's own envelope.", 910.0F, 522.0F, 13.0F, NL_TXT2, Opt().maxW(380.0F));
    text(c, "Individual ADSR stays in QUICK CONTROLS.", 910.0F, 551.0F, 13.0F, NL_TXT2, Opt().maxW(380.0F));
}

// ---------------------------------------------------------------- VOICE (old SVIRENE page): POLY / MONO / LEGATO, the portamento modes, the pitch bend range
void SilvetonSamplerView::drawEditVoice(Canvas& c) {
    drawQuickControls(c);
}

// ---------------------------------------------------------------- MIDI CONTROL (old KONTROL page): the controllers of one UPPER + its MIDI channel
void SilvetonSamplerView::drawEditMidiControl(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    auto& slot = upperStates[static_cast<std::size_t>(u)];
    if (!slot) slot = sampler.upperState(u);
    if (!slot) return;
    const UpperState s = *slot;

    const int ccBreath = globalState ? globalState->breathCc : 2;
    const int ccExpression = globalState ? globalState->expressionCc : 11;
    const int ccDamper = globalState ? globalState->damperCc : 64;
    struct Item { const char* name; std::string cc; bool on; };
    const Item items[4] = {{"BREATH", "CC " + std::to_string(ccBreath), s.breath}, {"EXPRESSION", "CC " + std::to_string(ccExpression), s.expression},
                           {"AFTERTOUCH", "PRESSURE", s.aftertouch}, {"DAMPER (SUSTAIN)", "CC " + std::to_string(ccDamper), s.damper}};
    for (int k = 0; k < 4; ++k) {
        const RectF key(262.0F + 190.0F * static_cast<float>(k), 240.0F, 442.0F + 190.0F * static_cast<float>(k), 390.0F);
        e2Lit(c, key, items[k].name, items[k].cc, items[k].on, 14.0F, true);
        hit(key, [this, s, k](float, float) {
            UpperState cur = currentUpper(s);
            switch (k) {
                case 0: cur.breath = !cur.breath; break;
                case 1: cur.expression = !cur.expression; break;
                case 2: cur.aftertouch = !cur.aftertouch; break;
                default: cur.damper = !cur.damper; break;
            }
            commitControl(cur);
        });
    }
    e2Knob(c, 1190.0F, 316.0F, 100.0F, "MIDI CHANNEL", "CH " + std::to_string(s.midiChannel + 1), static_cast<float>(s.midiChannel + 1), 1.0F, 16.0F, 1.0F, 220.0F, false, 76.0F,
           [this, s](float nv) { UpperState n = currentUpper(s); n.midiChannel = static_cast<int>(nv) - 1; commitControl(n); },
           [this, s] {
               showNumber("MIDI Channel", static_cast<float>(s.midiChannel + 1), 1.0F, 16.0F, 0, [this, s](float x) {
                   UpperState n = currentUpper(s);
                   n.midiChannel = static_cast<int>(x) - 1;
                   commitControl(n);
               });
           },
           [this, s] { UpperState n = currentUpper(s); n.midiChannel = 0; commitControl(n); });

    // the controller numbers, ranges, curves and the pedal live on SETTINGS > MIDI (global)
    nlPanel(c, RectF(250.0F, 420.0F, 1310.0F, 610.0F), "GLOBAL MIDI (all parts)");
    e2Text(c, "The controller numbers (CC), ranges, curves and the pedal polarity are global:", 266.0F, 456.0F, 13.0F, kTxt);
    e2Text(c, "BREATH " + items[0].cc + " · EXPRESSION " + items[1].cc + " · DAMPER " + items[3].cc + " · MIN / MAX / CURVE · pedal reversed · MIDI-in channels · filters", 266.0F, 480.0F, 12.5F, kHint);
    const RectF ms(266.0F, 524.0F, 566.0F, 582.0F);
    nlBtn(c, ms, "MIDI SETTINGS ▶", NlBtn::Plain, 14.0F, true);
    hit(ms, [this](float, float) { settingsTab = 1; goPage(Page::SETTINGS); });
}

} // namespace silveton::ui::classic
