// SILVETON_NEW_LOOK_V1 - LIVE and MIXER screens (pictures live.png and mixer.png; numbers are those of gui/screens1.py)
// Both screens show the 7 UPPER strips. The touch logic of a strip is the one of the old strip (drawUpperStrip in View_Combi.cpp):
// same controller calls, same commit functions, same taps / double taps / long presses / drags. Only the drawing and the places of the keys are new.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
int rndi(float v) { return static_cast<int>(std::nearbyint(v)); }
const ColorInt kVeil = Color::argb(120, 35, 38, 43);          // a muted / switched off strip: the picture shows it dimmed
const ColorInt kLitText = Color::rgb(255, 177, 58);           // text of a "lit" key
const float kStripW = 178.0F;
const float kStripStep = 187.0F;                              // 178 wide + 9 gap, from x = 20
// the 7th strip is the LOWER (picture set of the user), the others UPPER 1..6
std::string upperName(int i) { return i == 6 ? std::string("LOWER") : "UPPER " + std::to_string(i + 1); }
std::string upperShort(int i) { return i == 6 ? std::string("LOWER") : "U" + std::to_string(i + 1); }
}

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

// ---------------------------------------------------------------------------------------------- small helpers
float SilvetonSamplerView::lvMeterT(float peak) {
    if (peak <= 0.000001F) return 0.0F;
    const float db = 20.0F * static_cast<float>(std::log10(static_cast<double>(peak)));
    return db <= -60.0F ? 0.0F : faderT(std::min(db, 12.0F));
}

int SilvetonSamplerView::lvSoundSlot(int i, const std::string& name) {
    const std::size_t k = static_cast<std::size_t>(i);
    const std::int64_t now = nowMs();
    if (lvSlotName_[k] != name || now - lvSlotMs_[k] >= 1000) {
        lvSlotName_[k] = name;
        lvSlotMs_[k] = now;
        lvSlotVal_[k] = sampler.upperSoundSlot(i);
    }
    return lvSlotVal_[k];
}

SilvetonSamplerView::LvStrip SilvetonSamplerView::lvStripData(int i, const UpperState& s) {
    LvStrip d;
    d.ls = std::clamp(stripSound[static_cast<std::size_t>(i)], 0, 4);
    d.layerView = d.ls > 0;
    if (d.layerView) {
        d.lp = lParams(i, d.ls - 1);
        d.lHas = soundSlotHas(i,d.ls);
        d.lOn = getOr(d.lp, 0, 0.0F) >= 0.5F;
    }
    d.empty = d.layerView ? !d.lHas : (s.soundName == "EMPTY" || isBlank(s.soundName));
    d.live = d.layerView ? (d.lHas && d.lOn && s.enabled) : (s.enabled && !d.empty);
    d.mute = s.mute;
    d.dim = !d.live || s.mute;
    if (d.layerView) {
        if (d.lHas) {
            d.name = lName(i, d.ls - 1);
            if (isBlank(d.name)) d.name = "L" + std::to_string(d.ls);
        }
    } else {
        d.name = s.soundName;
    }
    d.pan = d.layerView ? getOr(d.lp, 2, 0.0F) : s.pan;
    d.level = d.layerView ? getOr(d.lp, 1, 0.0F) : s.levelDb;
    d.low = d.layerView ? static_cast<int>(getOr(d.lp, 6, 0.0F)) : s.keyLow;
    d.high = d.layerView ? static_cast<int>(getOr(d.lp, 7, 127.0F)) : s.keyHigh;
    return d;
}

// a key of the pictures. Lit = a dark key with amber text and an amber lamp (nlBtn has no such state, so it is drawn on top of a plain key)
void SilvetonSamplerView::lvKey(Canvas& c, const RectF& r, const std::string& label, const std::string& sub, LvLook look, float size, bool lamp, float spacing) {
    NlBtn st = NlBtn::Off;
    ColorInt col = Color::rgb(121, 130, 140);
    switch (look) {
        case LvLook::Plain: st = NlBtn::Plain; col = Color::rgb(179, 187, 196); break;
        case LvLook::Lit: st = NlBtn::Plain; col = kLitText; break;
        case LvLook::On: st = NlBtn::On; col = Color::rgb(28, 19, 4); break;
        case LvLook::Red: st = NlBtn::Red; col = Color::WHITE; break;
        default: break;
    }
    if (look != LvLook::Lit && sub.empty() && spacing == 0.07F && (!lamp || r.height() >= 30.0F)) {
        nlBtn(c, r, label, st, size, lamp);
        return;
    }
    nlBtn(c, r, std::string(), st, size, lamp);
    const bool lampOk = lamp && r.height() >= 26.0F;               // (the picture has the lamp on the 28 px keys too)
    const float textDown = lamp && r.height() >= 30.0F ? 2.0F : 0.0F;
    if (lampOk) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        if (look == LvLook::Lit) {
            fill(c, RectF(r.centerX() - lw / 2.0F - 2.0F, r.top + 3.0F, r.centerX() + lw / 2.0F + 2.0F, r.top + 10.0F), 3.5F, colorWithAlpha(NL_AMBER, 50));
            fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
        } else if (r.height() < 30.0F) {
            fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, look == LvLook::On ? Color::rgb(255, 244, 216) : Color::rgb(20, 23, 26));
        }
    }
    if (sub.empty()) {
        text(c, label, r.centerX(), r.centerY() + size * 0.36F + textDown, size, col, Opt().center().bold().spacing(spacing).maxW(r.width() - 8.0F));
    } else {
        const float subSize=std::max(9.F,size-2.5F);
        const float gap=std::max(3.F,size*.25F);
        const float top=r.centerY()-(size+subSize+gap)*.5F+textDown;
        const float labelBaseline=top+size*.8F;
        text(c, label, r.centerX(), labelBaseline, size, col, Opt().center().bold().spacing(0.05F).maxW(r.width() - 10.0F));
        const ColorInt subCol = look == LvLook::Lit ? Color::argb(205, 255, 177, 58) : colorWithAlpha(col, 205);
        text(c, sub, r.centerX(), labelBaseline+size*.2F+gap+subSize*.8F, subSize, subCol, Opt().center().spacing(0.06F).maxW(r.width() - 10.0F));
    }
}

// the knob of the pictures: the name above, the ring of dots, the cap, a black value box below
void SilvetonSamplerView::lvKnobFace(Canvas& c, float cx, float cy, float diam, float t01, bool bipolar, bool amber, const std::string& label,
                                     const std::string& value, float vw) {
    const float ring = diam * 0.5F - 4.0F;        // radius of the dots in the picture
    const float rad = (ring - 3.0F) / 1.3F;       // nlKnob puts its dots at 1.3 * radius + 3
    nlKnob(c, cx, cy, rad, t01, bipolar, amber, true);
    if (!label.empty()) nlLabel(c, label, cx, cy - diam * 0.5F - 4.0F, true, NL_TXT2, 11.0F);
    const float fs = diam >= 80.0F ? 13.0F : 12.0F;
    const float top = cy + diam * 0.5F - 2.0F;
    nlValue(c, RectF(cx - vw / 2.0F, top, cx + vw / 2.0F, top + fs + 10.0F), value, fs);
}

// 25 segments, 10 x 6 with 2 between, the lowest one at the bottom. The scale is the one of the fader (the cells line up with its ticks).
void SilvetonSamplerView::lvSegMeter(Canvas& c, float x, float y, float peak) {
    const float t = lvMeterT(peak);
    for (int k = 0; k < 25; ++k) {
        const float f = static_cast<float>(k + 1) / 25.0F;
        const float cy = y + static_cast<float>(24 - k) * 8.0F;
        ColorInt col = Color::rgb(26, 30, 35);
        if (f <= t + 0.0001F) col = f > 0.667F ? NL_RED : (f > 0.583F ? NL_AMBER : NL_BLUE);   // above 0 dB red, above -6 dB amber
        fill(c, RectF(x, cy, x + 10.0F, cy + 6.0F), 1.5F, col);
    }
}

// ---------------------------------------------------------------------------------------------- strip parts
void SilvetonSamplerView::lvStripFrame(Canvas& c, const RectF& r, int i, const LvStrip& d) {
    const bool selected = i == selectedUpper_;
    const bool isMarked = marked[static_cast<std::size_t>(i)];
    upperSelectAreas_.emplace_back(r, i);   // a touch anywhere on the strip selects this UPPER (before the strip's own hits)
    const float o = selected ? 4.0F : 0.0F;
    if (isMarked) {   // amber glow behind the panel
        for (int k = 2; k >= 1; --k) {
            const float kk = o + static_cast<float>(k) * 2.0F;
            fill(c, RectF(r.left - kk, r.top - kk, r.right + kk, r.bottom + kk), 12.0F + kk, colorWithAlpha(NL_AMBER, 18));
        }
    }
    nlPanel(c, r, std::string(), selected);
    if (isMarked) strokeRR(c, RectF(r.left - o, r.top - o, r.right + o, r.bottom + o), 12.0F + o, NL_AMBER, 2.0F);
    text(c, upperName(i), r.left + 14.0F, r.top + 24.0F, 15.0F, selected ? NL_BLUE : Color::rgb(207, 214, 222), Opt().bold().spacing(0.14F));
    led(c, r.right - 23.0F, r.top + 18.0F, d.live && !d.mute, 7.0F, true);
}

// M, L1..L4: amber = this place has a sound that plays, blue ring = the one the strip shows
void SilvetonSamplerView::lvChips(Canvas& c, float x, float y, float w, int i, const UpperState& s, const LvStrip& d) {
    static const char* const names[5] = {"M", "L1", "L2", "L3", "L4"};
    const float gap = 3.0F;
    const float bw = (w - gap * 4.0F) / 5.0F;
    const bool mainHas = !(s.soundName == "EMPTY" || isBlank(s.soundName));
    for (int k = 0; k < 5; ++k) {
        const RectF cr(x + static_cast<float>(k) * (bw + gap), y, x + static_cast<float>(k) * (bw + gap) + bw, y + 28.0F);
        bool has = mainHas;
        bool plays = has && s.enabled;
        if (k > 0) {
            const std::vector<float> lp = k == d.ls ? d.lp : lParams(i, k - 1);
            has = soundSlotHas(i,k);
            plays = has && getOr(lp, 0, 0.0F) >= 0.5F && s.enabled;
        }
        if (plays) {
            fillV(c, cr, 5.0F, Color::rgb(255, 197, 98), Color::rgb(255, 163, 26));
        } else {
            fill(c, cr, 5.0F, Color::rgb(26, 29, 33));
            line(c, cr.left + 4.0F, cr.top + 1.0F, cr.right - 4.0F, cr.top + 1.0F, Color::argb(38, 255, 255, 255), 1.0F);
        }
        if (k == d.ls) strokeRR(c, RectF(cr.left - 1.0F, cr.top - 1.0F, cr.right + 1.0F, cr.bottom + 1.0F), 6.0F, NL_BLUE, 2.0F);
        text(c, names[k], cr.centerX(), cr.centerY() + 4.0F, 11.0F, plays ? Color::rgb(28, 19, 4) : (has ? NL_TXT2 : NL_MUT), Opt().center().bold());
        // the same as a row of the old drop-down list of the strip
        hit(cr, [this, i, k, has](float, float) {
            stripSound[static_cast<std::size_t>(i)] = k;
            selectedUpper_ = i;
            editSound = k;
            dropUpper = -1;
            if (!has && !copiedSound_) openPicker(i, k - 1);   // a clipboard target must remain selectable without opening the picker
            invalidate();
        });
    }
}

// ON / SOLO / MUTE (SILVETON_GUI_V3 keys of the old strip, same actions)
void SilvetonSamplerView::lvOnSoloMute(Canvas& c, float x, float y, float h, int i, const UpperState& s, const LvStrip& d) {
    for (int k = 0; k < 3; ++k) {
        const float left = x + 10.0F + static_cast<float>(k) * 54.0F;
        const RectF tr(left, y, left + 50.0F, y + h);
        const bool on = k == 0 ? (d.layerView ? (d.lHas && d.lOn) : (s.enabled&&!d.empty)) : (k == 1 ? s.solo : s.mute);
        const std::string label = k == 0 ? "ON" : (k == 1 ? "SOLO" : "MUTE");
        const LvLook look = !on ? LvLook::Off : (k == 0 ? LvLook::Lit : (k == 1 ? LvLook::On : LvLook::Red));
        lvKey(c, tr, label, std::string(), look, k == 0 ? 13.0F : 12.0F, true);
        hit(tr, [this, i, s, k, layerView = d.layerView, lHas = d.lHas, ls = d.ls, isEmpty = d.empty](float, float) {
            const auto& slot = upperStates[static_cast<std::size_t>(i)];
            UpperState cur = slot ? *slot : s;
            if (k == 0) {
                if (layerView) {
                    if (lHas) setLParam(i, ls - 1, 0, layerOn(i, ls - 1) ? 0.0F : 1.0F);
                    else openPicker(i, ls - 1);
                } else if (!isEmpty) {
                    cur.enabled = !cur.enabled;
                    commitMain(i, cur);
                } else openPicker(i, -1);
            } else if (k == 1) {
                cur.solo = !cur.solo;
                commitMain(i, cur);
            } else {
                cur.mute = !cur.mute;
                commitMain(i, cur);
            }
            invalidate();
        });
    }
}

// ---------------------------------------------------------------------------------------------- LIVE strip
void SilvetonSamplerView::lvLiveStrip(Canvas& c, const RectF& r, int i, const UpperState& s, std::pair<float, float> meter) {
    const LvStrip d = lvStripData(i, s);
    lvStripFrame(c, r, i, d);
    const float L = r.left;
    const float T = r.top;
    if (i == 6) fill(c, RectF(L + 16.0F, T + 3.0F, L + kStripW - 16.0F, T + 6.0F), 2.0F, NL_BLUE);   // the picture marks the LOWER strip with a blue line on top

    // the sound: number, name, activity bar. A tap anywhere on it opens the sound picker (SILVETON_SOUND_FIELD_V1).
    const RectF lcdR(L + 10.0F, T + 34.0F, L + 168.0F, T + 92.0F);
    nlLcd(c, lcdR);
    const int slot = d.layerView ? (d.lHas ? static_cast<int>(getOr(d.lp, 31, 0.0F)) : 0) : (d.empty ? 0 : lvSoundSlot(i, s.soundName));
    text(c, slot > 0 ? fmtZeroPad(slot, 3) : std::string("---"), L + 20.0F, T + 49.0F, 11.0F, NL_BLUE, Opt().monoBold());
    text(c, d.empty ? std::string("EMPTY") : d.name, L + 20.0F, T + 73.0F, 17.0F, d.empty ? NL_MUT : Color::WHITE, Opt().bold().maxW(138.0F));
    fill(c, RectF(L + 20.0F, T + 81.0F, L + 158.0F, T + 87.0F), 3.0F, Color::rgb(18, 22, 27));
    const float act = lvMeterT(std::max(meter.first, meter.second));
    if (act > 0.02F) {
        const float bw = 138.0F * act;
        paint.style = Style::Fill;
        paint.color = Color::BLACK;
        paint.shader = linearGradient(L + 20.0F, 0.0F, L + 20.0F + bw, 0.0F, Color::rgb(23, 102, 201), Color::rgb(53, 164, 255), TileMode::Clamp);
        c.drawRoundRect(RectF(L + 20.0F, T + 81.0F, L + 20.0F + bw, T + 87.0F), 3.0F, 3.0F, paint);
        paint.shader = nullptr;
    }
    if (d.dim) fill(c, lcdR, 7.0F, kVeil);
    hit(lcdR, [this, i, ls = d.ls](float, float) { selectedUpper_ = i; openPicker(i, ls - 1); });
    listLongHits.push_back({lcdR, [this, i, ls = d.ls](float, float) { selectedUpper_ = i; showSoundActions(i, ls); }});

    // M, L1..L4
    lvChips(c, L + 10.0F, T + 98.0F, 158.0F, i, s, d);

    // VOLUME: the level of the sound shown (old LEVEL fader: -60..+12 dB, same law and the same touch)
    lvKnobFace(c, L + 89.0F, T + 196.0F, 92.0F, faderT(d.level), false, false, "VOLUME", dbText(d.level), 88.0F);
    if (d.dim) fill(c, RectF(L + 12.0F, T + 132.0F, L + 166.0F, T + 266.0F), 10.0F, kVeil);
    const std::function<void(float)> setLevel = [this, i, s, layerView = d.layerView, ls = d.ls](float nv) {
        if (layerView) { setLParam(i, ls - 1, 1, nv); return; }
        const auto& st = upperStates[static_cast<std::size_t>(i)];
        UpperState cur = st ? *st : s;
        cur.levelDb = nv;
        commitMain(i, cur);
    };
    const std::function<void()> exactLevel = [this, i, layerView = d.layerView, ls = d.ls, level = d.level, setLevel] {
        showNumber(layerView ? upperName(i) + " L" + std::to_string(ls) + " LEVEL dB" : upperName(i) + " LEVEL dB",
                   level, -60.0F, 12.0F, 1, [setLevel](float nv) { setLevel(nv); });
    };
    const std::function<void()> resetLevel = [setLevel] { setLevel(0.0F); };
    faderHit(RectF(L + 6.0F, T + 128.0F, L + 172.0F, T + 239.0F), d.level, 104.0F, setLevel, exactLevel, resetLevel);
    hit(RectF(L + 6.0F, T + 239.0F, L + 172.0F, T + 268.0F), [exactLevel](float, float) { exactLevel(); }, resetLevel);

    lvOnSoloMute(c, L, T + 272.0F, 42.0F, i, s, d);

    // SILVETON_NO_EDIT_KEY_V1 (Цветомир, 04.11.2026): the EDIT key of the LIVE strip is removed (it did the same as VOICE SETTINGS);
    // SOUND EDIT is entered from the bottom menu.
}

// ---------------------------------------------------------------------------------------------- MIXER strip
void SilvetonSamplerView::lvMixStrip(Canvas& c, const RectF& r, int i, const UpperState& s, std::pair<float, float> meter) {
    const LvStrip d = lvStripData(i, s);
    lvStripFrame(c, r, i, d);
    const float L = r.left;
    const float T = r.top;

    // the sound (number + name); a tap opens the sound picker
    const RectF lcdR(L + 10.0F, T + 34.0F, L + 168.0F, T + 78.0F);
    nlLcd(c, lcdR);
    const int slot = d.layerView ? (d.lHas ? static_cast<int>(getOr(d.lp, 31, 0.0F)) : 0) : (d.empty ? 0 : lvSoundSlot(i, s.soundName));
    std::string bank = slot > 0 ? fmtZeroPad(slot, 3) : std::string("---");
    if (d.layerView) bank += " · L" + std::to_string(d.ls);   // a layer is shown (chosen on LIVE)
    text(c, bank, L + 20.0F, T + 47.0F, 10.0F, NL_BLUE, Opt().monoBold());
    text(c, d.empty ? std::string("EMPTY") : d.name, L + 20.0F, T + 67.0F, 15.0F, d.empty ? NL_MUT : Color::WHITE, Opt().bold().maxW(138.0F));
    if (d.dim) fill(c, lcdR, 7.0F, kVeil);
    hit(lcdR, [this, i, ls = d.ls](float, float) { selectedUpper_ = i; openPicker(i, ls - 1); });

    // the engine of this UPPER (left) and its INSERT effect (right); the text shrinks a little when a name is long
    const RectF engR(L + 10.0F, T + 85.0F, L + 86.0F, T + 113.0F);
    const RectF insR(L + 92.0F, T + 85.0F, L + 168.0F, T + 113.0F);
    const int engType = sampler.soundSource(i,d.ls).engine.chosen()?13:0;
    const std::vector<float> insP = fxP(4 + i);
    const int insType = static_cast<int>(getOr(insP, 0, 0.0F));
    const std::string engLabel = engType != 0 ? std::string(sv::engineName(static_cast<sv::EngineType>(engType))) : std::string("SOURCE");
    const std::string insLabel = insType != 0 ? effectName(insType) : std::string("NO FX");
    float engSize = 11.0F;
    while (engSize > 8.0F && textWidth(engLabel, engSize, Face::Bold, 0.0F) > 66.0F) engSize -= 0.5F;
    float insSize = 11.0F;
    while (insSize > 8.0F && textWidth(insLabel, insSize, Face::Bold, 0.0F) > 66.0F) insSize -= 0.5F;
    lvKey(c, engR, engLabel, std::string(), engType != 0 ? LvLook::Lit : LvLook::Off, engSize, true, 0.0F);
    lvKey(c, insR, insLabel, std::string(), insType != 0 ? LvLook::Lit : LvLook::Off, insSize, true, 0.0F);
    // a tap on the engine key opens the ENGINE page on this UPPER, a tap on the effect key opens EFFECTS on its INSERT
    hit(engR, [this, i, ls=d.ls](float, float) {
        selectSound(i,ls);
        editGroup_=EG_WAVE;goPage(Page::COMBI,MODE_EDIT);
    });
    hit(insR, [this, i](float, float) {
        selectedUpper_ = i;
        fxUnitFocus = 4 + i;
        goPage(Page::EFFECTS);
    });

    // PAN, FX 1, FX 2 (the same drag, long press / tap on the value = number, double tap = default as before)
    const float kcy = T + 159.0F;
    const float kcx[3] = {L + 36.3F, L + 89.0F, L + 141.7F};
    const std::function<void(float)> setPan = [this, i, s, layerView = d.layerView, ls = d.ls](float nv) {
        if (layerView) { setLParam(i, ls - 1, 2, nv); return; }
        const auto& st = upperStates[static_cast<std::size_t>(i)];
        UpperState cur = st ? *st : s;
        cur.pan = nv;
        commitMain(i, cur);
    };
    const std::function<void()> exactPan = [this, i, layerView = d.layerView, ls = d.ls, pan = d.pan, setPan] {
        showNumber(layerView ? upperName(i) + " L" + std::to_string(ls) + " PAN" : upperName(i) + " PAN",
                   pan, -1.0F, 1.0F, 2, [setPan](float nv) { setPan(nv); });
    };
    const std::function<void()> resetPan = [setPan] { setPan(0.0F); };
    lvKnobFace(c, kcx[0], kcy, 52.0F, (d.pan + 1.0F) * 0.5F, true, false, "PAN", panText(d.pan), 46.0F);
    knobHit(RectF(kcx[0] - 26.3F, T + 118.0F, kcx[0] + 26.3F, T + 182.0F), d.pan, -1.0F, 1.0F, 0.01F, 160.0F, setPan, exactPan, resetPan);
    hit(RectF(kcx[0] - 26.3F, T + 182.0F, kcx[0] + 26.3F, T + 208.0F), [exactPan](float, float) { exactPan(); }, resetPan);
    for (int n = 1; n <= 2; ++n) {
        const float value = n == 1 ? s.fxSend1 : s.fxSend2;
        const std::function<void(float)> apply = [this, i, s, n](float nv) {
            const auto& st = upperStates[static_cast<std::size_t>(i)];
            UpperState x = st ? *st : s;
            if (n == 1) x.fxSend1 = nv; else x.fxSend2 = nv;
            commitUpperFx(x, i);
        };
        const std::function<void()> exactFx = [this, i, n, value, apply] {
            showNumber(upperName(i) + " FX" + std::to_string(n) + " SEND %", value * 100.0F, 0.0F, 100.0F, 0,
                       [apply](float pct) { apply(std::clamp(pct / 100.0F, 0.0F, 1.0F)); });
        };
        const std::function<void()> resetFx = [apply] { apply(0.0F); };
        const float cx = kcx[n];
        lvKnobFace(c, cx, kcy, 52.0F, value, false, false, n == 1 ? "FX 1" : "FX 2", std::to_string(rndi(value * 100.0F)) + " %", 46.0F);
        knobHit(RectF(cx - 26.3F, T + 118.0F, cx + 26.3F, T + 182.0F), value, 0.0F, 1.0F, 0.01F, 250.0F, apply, exactFx, resetFx);
        hit(RectF(cx - 26.3F, T + 182.0F, cx + 26.3F, T + 208.0F), [exactFx](float, float) { exactFx(); }, resetFx);
    }
    if (d.dim) fill(c, RectF(L + 6.0F, T + 118.0F, L + 172.0F, T + 208.0F), 8.0F, kVeil);

    // the fader (-60..+12 dB, the law of the old strip fader) with its scale, and the two level meters
    const float fy0 = T + 216.0F;
    const float fh = 200.0F;
    const float gx = L + 78.0F;
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    paint.shader = linearGradient(gx - 5.0F, 0.0F, gx + 5.0F, 0.0F, std::vector<ColorInt>{Color::rgb(5, 6, 7), Color::rgb(20, 23, 27), Color::rgb(5, 6, 7)},
                                  std::vector<float>{0.0F, 0.5F, 1.0F}, TileMode::Clamp);
    c.drawRoundRect(RectF(gx - 5.0F, fy0, gx + 5.0F, fy0 + fh), 5.0F, 5.0F, paint);
    paint.shader = nullptr;
    static const std::pair<const char*, float> scale[6] = {{"+12", 12.0F}, {"0", 0.0F}, {"-12", -12.0F}, {"-24", -24.0F}, {"-48", -48.0F}, {"-60", -60.0F}};
    for (const auto& sc : scale) {
        const float ty = fy0 + fh - faderT(sc.second) * fh;
        text(c, sc.first, L + 40.0F, ty + 4.0F, 10.0F, Color::rgb(128, 137, 148), Opt().mono().right());
        line(c, L + 44.0F, ty, L + 44.0F + (sc.second == 0.0F ? 20.0F : 14.0F), ty, Color::rgb(75, 82, 91), 1.0F);
    }
    lvSegMeter(c, L + 126.0F, fy0, meter.first);
    lvSegMeter(c, L + 140.0F, fy0, meter.second);
    const float capY = fy0 + fh - faderT(d.level) * fh;
    nlFaderCap(c, gx, capY, 58.0F, 52.0F);
    if (d.dim) fill(c, RectF(gx - 29.0F, capY - 26.0F, gx + 29.0F, capY + 26.0F), 8.0F, kVeil);
    const RectF dbR(L + 29.0F, T + 426.0F, L + 149.0F, T + 454.0F);
    nlValue(c, dbR, dbText(d.level), 15.0F);
    if (d.dim) fill(c, dbR, 6.0F, kVeil);
    const std::function<void(float)> setLevel = [this, i, s, layerView = d.layerView, ls = d.ls](float nv) {
        if (layerView) { setLParam(i, ls - 1, 1, nv); return; }
        const auto& st = upperStates[static_cast<std::size_t>(i)];
        UpperState cur = st ? *st : s;
        cur.levelDb = nv;
        commitMain(i, cur);
    };
    const std::function<void()> exactLevel = [this, i, layerView = d.layerView, ls = d.ls, level = d.level, setLevel] {
        showNumber(layerView ? upperName(i) + " L" + std::to_string(ls) + " LEVEL dB" : upperName(i) + " LEVEL dB",
                   level, -60.0F, 12.0F, 1, [setLevel](float nv) { setLevel(nv); });
    };
    const std::function<void()> resetLevel = [setLevel] { setLevel(0.0F); };
    faderHit(RectF(L + 4.0F, T + 208.0F, L + 174.0F, T + 424.0F), d.level, 104.0F, setLevel, exactLevel, resetLevel);
    hit(RectF(L, T + 424.0F, r.right, T + 456.0F), [exactLevel](float, float) { exactLevel(); }, resetLevel);

    // T = terca, Q = quarter tone (SILVETON_TQ_LIST_V1: lit = on, grey but brighter = chosen here but switched off on LIST), then the key range
    const RectF tR(L + 10.0F, T + 460.0F, L + 46.0F, T + 492.0F);
    const RectF qR(L + 50.0F, T + 460.0F, L + 86.0F, T + 492.0F);
    const RectF rangeR(L + 90.0F, T + 460.0F, L + 168.0F, T + 492.0F);
    const bool tOn = sampler.tercaOn(i);
    const bool qOn = sampler.quarterOn(i);
    lvKey(c, tR, "T", std::string(), tOn ? LvLook::Lit : ((sampler.tercaChosen(i)) ? LvLook::Plain : LvLook::Off), 12.0F, false);
    lvKey(c, qR, "Q", std::string(), qOn ? LvLook::Lit : ((sampler.quarterChosen(i)) ? LvLook::Plain : LvLook::Off), 12.0F, false);
    hit(tR, [this, i](float, float) { toggleTercaLinked(i); invalidate(); });
    hit(qR, [this, i](float, float) { toggleQuarterLinked(i); invalidate(); });
    // SILVETON_RANGE_KEY_V1: a tap opens the RANGE of this UPPER (SOUND EDIT), double tap = the whole keyboard
    nlBtn(c, rangeR, noteName(d.low) + "–" + noteName(d.high), NlBtn::Off, 11.0F, false);
    hit(rangeR,
        [this, i, ls = d.ls](float, float) {
            selectedUpper_ = i;
            if (sampler.keyScanUpper() == i) sampler.cancelKeyScan();
            editSound = ls;
            tab = UpperTab::RANGE;
            editGroup_ = EG_RANGE;
            goPage(Page::COMBI, MODE_EDIT);
        },
        [this, i, s, layerView = d.layerView, ls = d.ls] {
            if (layerView) {
                setLParam(i, ls - 1, 6, 0.0F);
                setLParam(i, ls - 1, 7, 127.0F);
            } else {
                sampler.cancelKeyScan();
                const auto& st = upperStates[static_cast<std::size_t>(i)];
                UpperState cur = st ? *st : s;
                cur.keyLow = 0;
                cur.keyHigh = 127;
                commitMain(i, cur);
            }
        });

    lvOnSoloMute(c, L, T + 498.0F, 44.0F, i, s, d);
}

// ---------------------------------------------------------------------------------------------- the 7 strips
void SilvetonSamplerView::lvStrips(Canvas& c, bool mixer) {
    const float top = 98.0F;
    const float bottom = mixer ? 650.0F : 432.0F;
    const std::vector<std::pair<float, float>>& meters = frameUpperMeters;
    for (int i = 0; i < 7; ++i) {
        auto& slot = upperStates[static_cast<std::size_t>(i)];
        if (!slot) slot = sampler.upperState(i);
        if (!slot) continue;
        const UpperState state = *slot;
        const float left = 20.0F + static_cast<float>(i) * kStripStep;
        const std::pair<float, float> meter = static_cast<std::size_t>(i) < meters.size() ? meters[static_cast<std::size_t>(i)] : std::pair<float, float>(0.0F, 0.0F);
        const RectF r(left, top, left + kStripW, bottom);
        if (mixer) lvMixStrip(c, r, i, state, meter);
        else lvLiveStrip(c, r, i, state, meter);
    }
    if (markMode) {   // SILVETON_MARK_LINK_V1: a tap on a strip marks / unmarks that UPPER (registered last = wins over the keys of the strip)
        for (int i = 0; i < 7; ++i) {
            const float left = 20.0F + static_cast<float>(i) * kStripStep;
            hit(RectF(left, top, left + kStripW, bottom), [this, i](float, float) { marked[static_cast<std::size_t>(i)] = !marked[static_cast<std::size_t>(i)]; invalidate(); });
        }
    }
}

// MARK / LINK / COPY U / PASTE U (SILVETON_MARK_LINK_V1 and SILVETON_COPY_ALL_V1 of the old COMBI page, same actions)
void SilvetonSamplerView::lvMarkRow(Canvas& c, float y, float h) {
    const long markedCount = std::count(marked.begin(), marked.end(), true);
    const RectF mkR(20.0F, y, 170.0F, y + h);
    const RectF lkR(179.0F, y, 329.0F, y + h);
    const RectF copyR(338.0F, y, 488.0F, y + h);
    const RectF pasteR(497.0F, y, 647.0F, y + h);
    lvKey(c, mkR, markedCount > 0 ? "MARK · " + std::to_string(markedCount) : std::string("MARK"), std::string(), markMode ? LvLook::Lit : LvLook::Plain, 13.0F, true);
    hit(mkR,
        [this](float, float) {
            markMode = !markMode;
            if (markMode) flash("TOUCH THE STRIPS OF THE UPPERS YOU WANT TO MARK");
            invalidate();
        },
        [this] {
            marked.fill(false);
            flash("MARKS CLEARED");
            invalidate();
        });
    lvKey(c, lkR, "LINK", std::string(), linkOn ? LvLook::Lit : LvLook::Plain, 13.0F, true);
    hit(lkR, [this](float, float) {
        linkOn = !linkOn;
        flash(linkOn ? "LINK ON: THE MARKED UPPERS FOLLOW" : "LINK OFF");
        invalidate();
    });
    lvKey(c, copyR, "COPY PART", upperShort(selectedUpper_), LvLook::Plain, 11.5F, true);
    const std::size_t pasteCount = 1U + linkTargets(selectedUpper_).size();
    const std::string pasteTo = pasteCount > 1U ? std::to_string(pasteCount) + " selected" : upperShort(selectedUpper_);
    lvKey(c, pasteR, "PASTE PART", copiedClip ? upperShort(copiedClip->from) + " → " + pasteTo : "Clipboard empty", copiedClip.has_value() ? LvLook::Plain : LvLook::Off, 11.5F, true);
    hit(copyR, [this](float, float) { copyUpper(selectedUpper_); });
    if (copiedClip) hit(pasteR, [this](float, float) { pasteUpper(selectedUpper_); });
}

// ---------------------------------------------------------------------------------------------- LIVE: the panels of the chosen UPPER
void SilvetonSamplerView::lvPanels(Canvas& c) {
    const float py = 504.0F;
    const float bottom = 694.0F;
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(stripSound[static_cast<std::size_t>(u)], 0, 4);
    const std::string un = upperName(u);
    struct Shortcut {
        RectF panel;
        std::string title;
        std::string label;
        std::string subtitle;
        int group;
    };
    // These are entrances to the same editors. LIVE no longer has a second set of
    // pitch/voice/portamento controls that can disagree with the touch editor.
    const Shortcut shortcuts[] = {
        {RectF(20,py,270,bottom), "SOURCE · " + un, "ЗВУК / СИНТ", soundSlotName(u,sound), EG_WAVE},
        {RectF(280,py,720,bottom), "НАСТРОЙКИ ЗА СВИРЕНЕ", "ADSR · VOICE · PORTAMENTO", "OCTAVE · TRANSPOSE · TUNE · PITCH BEND", EG_VOICE},
        {RectF(730,py,1060,bottom), "КОНТРОЛЕРИ · " + un, "MIDI / CONTROL", "BREATH · EXPRESSION · DAMPER", EG_MIDICTL},
        {RectF(1070,py,1320,bottom), "ДОПЪЛНИТЕЛНО", "DECAY / PORTA", "BALANCE · NEAR NOTE", EG_PARTTUNE}
    };
    for(const auto& shortcut:shortcuts) {
        nlPanel(c,shortcut.panel,shortcut.title);
        const RectF button(shortcut.panel.left+14,py+42,shortcut.panel.right-14,bottom-16);
        lvKey(c,button,shortcut.label,shortcut.subtitle,LvLook::Plain,
              shortcut.group==EG_VOICE?18.F:16.F,true);
        hit(button,[this,u,sound,group=shortcut.group](float,float){
            selectSound(u,sound);
            editGroup_=group;
            goPage(Page::COMBI,MODE_EDIT);
        });
    }
}

// ---------------------------------------------------------------------------------------------- the two screens
void SilvetonSamplerView::drawLive(Canvas& c) {
    dropUpper = -1;   // the drop-down list of the old strip is gone: the chips M, L1..L4 are on the strip itself
    lvStrips(c, false);
    drawLiveActions(c);
    lvPanels(c);
}

void SilvetonSamplerView::drawMixer(Canvas& c) {
    dropUpper = -1;
    lvStrips(c, true);
    lvMarkRow(c, 656.0F, 40.0F);
    text(c, "MARK: tap parts to mark them · LINK: a change on a marked part is repeated on all marked parts", 660.0F, 680.0F, 12.0F, Color::rgb(138, 147, 157), Opt().maxW(660.0F));
}

} // namespace silveton::ui::classic
