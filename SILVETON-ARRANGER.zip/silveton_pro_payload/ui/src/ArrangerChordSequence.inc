// Existing HOME > Chords pane: one dedicated subpage, not a new engine/menu tree.
void ArrangerView::saveChordSequenceSlot(){
    const auto sequence=host::arrangerHost().chordSequence();
    const auto data=arranger::encodeChordSequence(sequence.data);
    if(persistentSessionPath_.empty()||data.empty()||sequence.mode==arranger::ChordSequenceMode::Recording){showToast("Record a complete sequence first",4000);return;}
    const auto path=files::join(files::parentOf(persistentSessionPath_),"ARRANGER_CHORD_SEQ_"+std::to_string(chordSequenceSlot_)+".txt");
    const auto temp=path+".pending";
    if(!files::writeText(temp,data)||std::rename(temp.c_str(),path.c_str())!=0){(void)files::removeRecursively(temp);showToast("Chord Sequence save failed",5000);return;}
    showToast("Chord Sequence saved to slot "+std::to_string(chordSequenceSlot_),3000);
}
void ArrangerView::loadChordSequenceSlot(){
    if(persistentSessionPath_.empty()){showToast("Chord Sequence storage unavailable",4000);return;}
    const auto path=files::join(files::parentOf(persistentSessionPath_),"ARRANGER_CHORD_SEQ_"+std::to_string(chordSequenceSlot_)+".txt");
    std::string text;arranger::ChordSequenceData d;
    // Bound disk reads before allocating a buffer. Files are small private slot records.
    std::ifstream in(path,std::ios::binary|std::ios::ate);const auto size=in?in.tellg():std::streampos(-1);
    if(size<=0||size>16384){showToast("Empty or invalid Chord Sequence slot",4000);return;}
    text.resize(static_cast<std::size_t>(size));in.seekg(0);
    if(!in.read(text.data(),static_cast<std::streamsize>(text.size()))||!arranger::decodeChordSequence(text,d)){showToast("Invalid Chord Sequence slot",4000);return;}
    controlRequested(host::arrangerHost().loadChordSequence(d,selectedPlayer_));chordSequencePageIndex_=0;
}
void ArrangerView::drawChordSequence(Canvas& c){
    if(chordSequenceEdit_){drawChordSequenceEdit(c);return;}
    using Mode=arranger::ChordSequenceMode;const auto seq=host::arrangerHost().chordSequence();
    const auto& player=players_[static_cast<std::size_t>(selectedPlayer_)];
    const bool record=seq.mode==Mode::RecordArmed||seq.mode==Mode::Recording;
    const bool play=seq.mode==Mode::PlayArmed||seq.mode==Mode::Playing;
    const bool ready=arranger::validChordSequence(seq.data);
    const char* status=seq.mode==Mode::RecordArmed?"REC ARMED":seq.mode==Mode::Recording?"RECORDING":seq.mode==Mode::PlayArmed?"PLAY ARMED":seq.mode==Mode::Playing?"PLAYING":ready?"READY":"EMPTY";
    box(c,{11,165,789,167},orange);
    button(c,{16,171,156,214},"< CHORDS",blue,false,true,[this]{chordSequencePage_=false;dirty_=true;},15);
    label(c,"CHORD SEQUENCE",169,192,19,white,true,370);
    label(c,std::string(status)+"  P"+std::to_string(seq.player+1),780,194,17,record?0xFFFF5656U:play?green:dim,true,230,Align::Right);
    const int pages=std::max(1,(static_cast<int>(seq.data.count)+7)/8);
    chordSequencePageIndex_=std::clamp(chordSequencePageIndex_,0,pages-1);
    for(int i=0;i<8;++i){
        const int position=chordSequencePageIndex_*8+i;const float x=16.0F+(i%4)*194.0F,y=219.0F+(i/4)*45.0F;
        const bool exists=position<static_cast<int>(seq.data.count),current=position==seq.current;
        box(c,{x,y,x+184,y+40},current?0xFF145D49U:key,current?green:kBorder,3);
        if(exists){const auto& event=seq.data.events[static_cast<std::size_t>(position)];
            label(c,std::to_string(position+1),x+7,y+12,10,dim,false,25);
            label(c,arranger::chordName(event.chord),x+92,y+27,21,white,true,142,Align::Center);
            label(c,std::to_string(event.tick/480)+"q:"+std::to_string(event.tick%480),x+177,y+12,9,dim,false,53,Align::Right);
        }else label(c,position==static_cast<int>(seq.data.count)&&!record&&!play?"+ ADD":"—",x+92,y+26,17,dim,false,170,Align::Center);
        if(!record&&!play&&position<=static_cast<int>(seq.data.count)&&position<static_cast<int>(arranger::kChordSequenceCapacity))
            hit({x,y,x+184,y+40},[this,position]{beginChordSequenceEdit(position);});
    }
    const auto command=[this](bool ok){controlRequested(ok);};
    button(c,{16,312,157,356},record?"STOP REC":"REC",0xFFFF5656U,record,record||player.loaded,[this,command]{command(host::arrangerHost().toggleSequenceRecord(selectedPlayer_));},15);
    button(c,{167,312,308,356},play?"STOP SEQ":"START SEQ",green,play,play||(ready&&player.loaded),[this,command]{command(host::arrangerHost().toggleSequencePlay(selectedPlayer_));},14);
    button(c,{318,312,435,356},"LOCK",orange,seq.locked,true,[this,command]{command(host::arrangerHost().toggleSequenceLock(selectedPlayer_));},14);
    button(c,{445,312,562,356},"CLEAR",blue,false,seq.data.count||record||play,[this,command]{command(host::arrangerHost().clearSequence(selectedPlayer_));},14);
    button(c,{572,312,647,356},"<",blue,false,chordSequencePageIndex_>0,[this]{--chordSequencePageIndex_;dirty_=true;},18);
    label(c,std::to_string(chordSequencePageIndex_+1)+"/"+std::to_string(pages),675,340,14,white,true,55,Align::Center);
    button(c,{706,312,784,356},">",blue,false,chordSequencePageIndex_+1<pages,[this]{++chordSequencePageIndex_;dirty_=true;},18);
    label(c,"LIBRARY SLOT  •  Tap a chord to edit",16,373,12,dim,true);
    for(int i=1;i<=4;++i){const float x=16.0F+(i-1)*87.0F;button(c,{x,380,x+79,429},std::to_string(i),blue,chordSequenceSlot_==i,true,[this,i]{chordSequenceSlot_=i;dirty_=true;},18);}
    button(c,{375,380,575,429},"SAVE SLOT",orange,false,ready&&!record&&!persistentSessionPath_.empty(),[this]{saveChordSequenceSlot();},16);
    button(c,{585,380,784,429},"LOAD SLOT",blue,false,!record&&!persistentSessionPath_.empty(),[this]{loadChordSequenceSlot();},16);
}

void ArrangerView::beginChordSequenceEdit(int index){
    const auto s=host::arrangerHost().chordSequence();
    if(s.mode!=arranger::ChordSequenceMode::Idle||index<0||index>static_cast<int>(s.data.count))return;
    chordSequenceDraft_=s.data;chordSequenceEditIndex_=index;
    if(!chordSequenceDraft_.count){
        const auto& player=players_[static_cast<std::size_t>(selectedPlayer_)];
        chordSequenceDraft_.lengthTicks=static_cast<std::uint32_t>(std::max(120,480*4*player.numerator/std::max(1,player.denominator)));
        chordSequenceDraft_.events[0]={0,{0,arranger::ChordType::Major,0}};chordSequenceDraft_.count=1;chordSequenceEditIndex_=0;
    }else if(index==static_cast<int>(s.data.count)){
        chordSequenceEditIndex_=index-1;insertChordSequenceEvent();
        if(chordSequenceEditIndex_!=index)return;
    }
    chordSequenceEdit_=true;dirty_=true;
}
void ArrangerView::insertChordSequenceEvent(){
    auto& d=chordSequenceDraft_;const auto index=static_cast<std::uint32_t>(chordSequenceEditIndex_);
    if(!d.count||d.count>=d.events.size()||index>=d.count){showToast("Sequence is full",3000);return;}
    const auto before=d.events[index];std::uint32_t tick=before.tick+480U;
    if(index+1<d.count){const auto next=d.events[index+1].tick;if(next<=before.tick+1){showToast("No free ticks between these chords",4000);return;}tick=before.tick+std::min<std::uint32_t>(480U,(next-before.tick)/2U);}
    else if(tick>=d.lengthTicks){
        if(tick>=arranger::kChordSequenceMaxTicks){showToast("Maximum sequence length reached",4000);return;}
        const auto& player=players_[static_cast<std::size_t>(selectedPlayer_)];
        const auto bar=static_cast<std::uint32_t>(std::max(120,480*4*player.numerator/std::max(1,player.denominator)));
        d.lengthTicks=std::min(arranger::kChordSequenceMaxTicks,d.lengthTicks+std::max(bar,tick-d.lengthTicks+1));
    }
    for(auto j=d.count;j>index+1;--j)d.events[j]=d.events[j-1];
    d.events[index+1]={tick,before.chord};++d.count;++chordSequenceEditIndex_;dirty_=true;
}
void ArrangerView::removeChordSequenceEvent(){
    auto& d=chordSequenceDraft_;if(d.count<=1)return;const auto index=static_cast<std::uint32_t>(chordSequenceEditIndex_);
    for(auto j=index;j+1<d.count;++j)d.events[j]=d.events[j+1];
    --d.count;d.events[0].tick=0;chordSequenceEditIndex_=std::min(chordSequenceEditIndex_,static_cast<int>(d.count)-1);dirty_=true;
}
void ArrangerView::adjustChordSequenceEvent(int field,int direction){
    auto& d=chordSequenceDraft_;const auto index=static_cast<std::uint32_t>(chordSequenceEditIndex_);auto& event=d.events[index];
    if(field==0){const auto old=event.chord.root;event.chord.root=(old+direction+12)%12;if(event.chord.bass==old)event.chord.bass=event.chord.root;}
    else if(field==1){int type=static_cast<int>(event.chord.type);do{type=(type+direction+25)%25;}while(type==static_cast<int>(arranger::ChordType::None));event.chord.type=static_cast<arranger::ChordType>(type);}
    else if(field==2)event.chord.bass=(event.chord.bass+direction+12)%12;
    else if(field==3&&index>0){const auto low=d.events[index-1].tick+1;const auto high=index+1<d.count?d.events[index+1].tick-1:d.lengthTicks-1;event.tick=static_cast<std::uint32_t>(std::clamp(static_cast<int>(event.tick)+direction*120,static_cast<int>(low),static_cast<int>(high)));}
    else if(field==4){const auto& player=players_[static_cast<std::size_t>(selectedPlayer_)];const auto bar=std::max(120,480*4*player.numerator/std::max(1,player.denominator));
        d.lengthTicks=static_cast<std::uint32_t>(std::clamp(static_cast<int>(d.lengthTicks)+direction*bar,static_cast<int>(d.events[d.count-1].tick+1),static_cast<int>(arranger::kChordSequenceMaxTicks)));}
    dirty_=true;
}
void ArrangerView::drawChordSequenceEdit(Canvas& c){
    auto& d=chordSequenceDraft_;const auto index=static_cast<std::size_t>(chordSequenceEditIndex_);const auto& event=d.events[index];
    const auto name=[](int pc){static const char* names[]={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};return std::string(names[std::clamp(pc,0,11)]);};
    const auto position=[](std::uint32_t ticks){return std::to_string(ticks/480)+"q + "+std::to_string(ticks%480)+"t";};
    box(c,{11,165,789,167},orange);
    button(c,{16,171,143,214},"CANCEL",blue,false,true,[this]{chordSequenceEdit_=false;dirty_=true;},15);
    label(c,"EDIT CHORD  "+std::to_string(index+1)+" / "+std::to_string(d.count),157,198,19,white,true,380);
    button(c,{610,171,784,214},"APPLY",green,false,arranger::validChordSequence(d),[this]{if(host::arrangerHost().loadChordSequence(chordSequenceDraft_,selectedPlayer_)){chordSequenceEdit_=false;chordSequencePageIndex_=chordSequenceEditIndex_/8;controlRequested(true);}else controlRequested(false);},16);
    const std::array<std::string,4> names{{"ROOT","CHORD TYPE","BASS","POSITION"}};
    const std::array<std::string,4> values{{name(event.chord.root),arranger::chordName({event.chord.root,event.chord.type,event.chord.root}),name(event.chord.bass),position(event.tick)}};
    for(int j=0;j<4;++j){const float x=16.0F+j*194.0F;box(c,{x,220,x+184,335},panel,kBorder,3);
        label(c,names[j],x+92,239,13,dim,true,178,Align::Center);
        label(c,values[j],x+92,267,j==3?16:22,white,true,178,Align::Center);
        button(c,{x+5,282,x+87,330},"−",blue,false,j!=3||index>0,[this,j]{adjustChordSequenceEvent(j,-1);},24);
        button(c,{x+97,282,x+179,330},"+",blue,false,j!=3||index>0,[this,j]{adjustChordSequenceEvent(j,1);},24);
    }
    label(c,"LOOP LENGTH",16,358,12,dim,true);
    button(c,{16,366,80,429},"−",blue,false,true,[this]{adjustChordSequenceEvent(4,-1);},24);
    label(c,position(d.lengthTicks),154,404,17,white,true,140,Align::Center);
    button(c,{226,366,290,429},"+",blue,false,true,[this]{adjustChordSequenceEvent(4,1);},24);
    button(c,{304,366,425,429},"< PREV",blue,false,index>0,[this]{--chordSequenceEditIndex_;dirty_=true;},15);
    button(c,{435,366,556,429},"NEXT >",blue,false,index+1<d.count,[this]{++chordSequenceEditIndex_;dirty_=true;},15);
    button(c,{566,366,675,429},"INSERT",orange,false,d.count<d.events.size(),[this]{insertChordSequenceEvent();},14);
    button(c,{685,366,784,429},"DELETE",0xFFFF5656U,false,d.count>1,[this]{removeChordSequenceEvent();},14);
}
