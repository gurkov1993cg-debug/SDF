// Sound and Keyboard Set Select: the same ten-item Tile View geometry as
// Style Select. Entries and category order come from the current KST catalog.
void ArrangerView::drawKstKeyboardSelect(Canvas& c) {
    const auto catalogHandle=kstCatalog_;
    if(!catalogHandle)return;
    const auto& catalog=*catalogHandle;
    const int type=kstCatalogTab_==1?1:2;
    const bool sounds=type==1;
    const bool performances=catalogUsesPerformances(catalog);
    const auto stateKey=std::make_pair(catalog.rootPath,type);
    auto& state=keyboardSelectStates_[stateKey];
    const std::string allCategory="@all";
    struct Item {std::string name,path,relativePath,category;std::size_t index;};
    struct Folder {std::string path,name,parent;std::vector<std::size_t> indices;std::size_t descendants{0};};
    std::vector<Item> items;
    if(sounds){
        items.reserve(catalog.sounds.size());
        for(std::size_t index=0;index<catalog.sounds.size();++index){const auto& source=catalog.sounds[index];
            // Each PCG resource is an actual Sound bank. Its parent remains a
            // real folder, while the leaf keeps all Sounds from that resource.
            items.push_back({source.name,source.path,source.relativePath,source.relativePath,index});}
    }else{
        items.reserve(catalog.keyboardSets.size());
        for(std::size_t index=0;index<catalog.keyboardSets.size();++index){const auto& source=catalog.keyboardSets[index];
            std::string bank;
            if(!arranger::paKeyboardLocation(source.relativePath,&bank))
                bank=arranger::paPerformanceBankPath(source.relativePath)?source.relativePath:files::parentOf(source.relativePath);
            items.push_back({source.name,source.path,source.relativePath,std::move(bank),index});}
    }
    std::vector<Folder> folders;
    std::map<std::string,std::size_t> folderLookup;
    const auto addFolder=[&](const std::string& path){
        const auto existing=folderLookup.find(path);
        if(existing!=folderLookup.end())return existing->second;
        const auto index=folders.size();folderLookup.emplace(path,index);
        folders.push_back({path,files::nameOf(path),files::parentOf(path),{},0});return index;
    };
    for(std::size_t index=0;index<items.size();++index){
        const auto immediate=addFolder(items[index].category);folders[immediate].indices.push_back(index);
        std::string ancestor=items[index].category;
        for(;;){
            const auto folder=addFolder(ancestor);++folders[folder].descendants;
            const auto parent=files::parentOf(ancestor);
            if(ancestor.empty()||parent==ancestor)break;
            ancestor=parent;
        }
    }
    std::string rootFolder=items.empty()?std::string{}:items.front().category.substr(0,items.front().category.find('/'));
    if(sounds&&!items.empty()&&items.front().category.find('/')==std::string::npos)rootFolder.clear();
    for(const auto& item:items)if(item.category.substr(0,item.category.find('/'))!=rootFolder){rootFolder.clear();break;}
    std::string activePath=activeNativeKeyboardSetPath_;
    const auto keyboardState=ctrl_.engine.nativeKeyboardCombi();
    sampler::ProgramPtr activeProgram;
    std::array<int,3> activeAddress{{-1,-1,-1}};
    if(sounds&&targetTrack_>=0&&soundPlayer_>=0){
        const auto& track=players_[soundPlayer_].tracks[targetTrack_];
        int address=track.soundSettings.setAddress;
        if(address<0&&track.originalSoundRouted&&track.addressKnown&&!track.originalSoundMultiple)
            address=(track.msb<<16)|(track.lsb<<8)|track.program;
        if(address>=0){
            activeAddress={{(address>>16)&127,(address>>8)&127,address&127}};
            activeProgram=host::arrangerHost().preparedKeyboardSound(activeAddress[0],activeAddress[1],activeAddress[2],players_[soundPlayer_].sourcePath);
        }
        activePath=players_[soundPlayer_].sourcePath;
    }else if(sounds&&keyboardState&&targetPart_>=0&&targetPart_<7){
        activeProgram=keyboardState->part(targetPart_).program;
        const auto& binding=keyboardSoundBindings_[static_cast<std::size_t>(targetPart_)];
        activePath=binding.sourcePath;
        activeAddress={{binding.msb,binding.lsb,binding.program}};
    }
    const bool locateActive=!state.initialized||state.locateActive||state.lastSourcePath!=activePath;
    if(locateActive){
        // A Style-owned working copy need not occur in the library. In that
        // case retain the last browsed Keyboard Set bank/page instead of
        // replacing it with All on every open.
        if(sounds||!state.initialized){state.browserPath=rootFolder;state.categoryPath=allCategory;state.categoryPage=0;}
        for(const auto& item:items){
            bool matches=item.path==activePath;
            if(sounds){
                const auto& sound=catalog.sounds[item.index];
                matches=activeProgram&&sound.addressKnown&&sound.msb==activeAddress[0]&&sound.lsb==activeAddress[1]&&sound.program==activeAddress[2]&&
                    host::arrangerHost().preparedKeyboardSound(sound.msb,sound.lsb,sound.program,sound.path)==activeProgram;
            }
            if(!matches)continue;
            state.categoryPath=item.category;
            const auto found=folderLookup.find(item.category);
            if(found!=folderLookup.end()){
                const auto& folder=folders[found->second];
                state.browserPath=folder.parent.empty()?rootFolder:folder.parent;
                const auto position=std::find(folder.indices.begin(),folder.indices.end(),item.index);
                if(position!=folder.indices.end())state.pages[item.category]=static_cast<int>(std::distance(folder.indices.begin(),position)/10);
            }
            break;
        }
        state.initialized=true;state.locateActive=false;
    }
    state.lastSourcePath=activePath;
    if(state.categoryPath!=allCategory&&folderLookup.count(state.categoryPath)==0)state.categoryPath=allCategory;
    if(folderLookup.count(state.browserPath)==0)state.browserPath=rootFolder;
    struct Category {std::string path,name;std::size_t count;bool children;};
    std::vector<Category> categories;
    if(state.browserPath==rootFolder)categories.push_back({allCategory,sounds?"All Sounds":performances?"All Performances":"All KbdSets",items.size(),false});
    const auto browser=folderLookup.find(state.browserPath);
    if(browser!=folderLookup.end()&&!folders[browser->second].indices.empty())
        categories.push_back({state.browserPath,"This folder",folders[browser->second].indices.size(),false});
    // First encounter order follows the catalog; the lookup map never sorts UI.
    for(const auto& folder:folders){
        if(folder.path==state.browserPath||folder.parent!=state.browserPath)continue;
        const bool children=std::any_of(folders.begin(),folders.end(),[&](const auto& candidate){return candidate.path!=folder.path&&candidate.parent==folder.path;});
        categories.push_back({folder.path,folder.name.empty()?folder.path:folder.name,folder.descendants,children});
    }
    if(locateActive||state.locateCategory)for(std::size_t index=0;index<categories.size();++index)
        if(categories[index].path==state.categoryPath){state.categoryPage=static_cast<int>(index/12U);break;}
    state.locateCategory=false;
    const bool all=state.categoryPath==allCategory;
    std::vector<std::size_t> selectedItems;
    if(all){selectedItems.reserve(items.size());for(std::size_t index=0;index<items.size();++index)selectedItems.push_back(index);}
    else {const auto folder=folderLookup.find(state.categoryPath);if(folder!=folderLookup.end())selectedItems=folders[folder->second].indices;}
    const int categoryPages=std::max(1,static_cast<int>((categories.size()+11)/12));
    state.categoryPage=std::clamp(state.categoryPage,0,categoryPages-1);
    auto& page=state.pages[state.categoryPath];
    const int pages=std::max(1,static_cast<int>((selectedItems.size()+9)/10));page=std::clamp(page,0,pages-1);
    box(c,{0,0,800,480},bg);
    button(c,{3,3,96,35},"‹ Exit",green,false,true,[this]{targetKbdSet_=-1;panelExit();},16);
    label(c,sounds?"SOUND SELECT":performances?"PERFORMANCE SELECT":"KEYBOARD SET SELECT",110,27,18,green,true,388);
    if(sounds)label(c,targetTrack_>=0&&soundPlayer_>=0?players_[soundPlayer_].tracks[targetTrack_].name:arrangerKeyboardPartName(targetPart_),503,26,13,dim,false,112);
    else if(targetKbdSet_>=0)label(c,"Position "+std::to_string(targetKbdSet_+1),503,26,13,dim,false,112);
    if(sounds)button(c,{616,3,685,35},"Inspect",green,false,true,[this]{openInspector(Picker::SetSounds);},13);
    if(!sounds&&keyboardSetContents_)button(c,{616,3,685,35},"Info",green,false,true,[this]{contentsReturn_=Picker::KstCatalog;picker_=Picker::KeyboardSetRead;dirty_=true;},13);
    button(c,{694,3,796,35},"Load KST",green,false,true,[this]{openPicker(Picker::KstFolder);},12);
    const std::array<std::string,4> typeNames{{"Styles","Sounds",performances?"Performances":"Keyboard Sets","Samples"}};
    for(int choice=0;choice<4;++choice){const float x=8+choice*198.0F;
        button(c,{x,44,x+192,80},typeNames[static_cast<std::size_t>(choice)],choice==0?orange:green,type==choice,true,[this,choice]{if(choice!=2)targetKbdSet_=-1;if(choice==0||choice==2){targetTrack_=-1;targetPart_=0;}kstCatalogTab_=choice;kstCatalogPage_=0;dirty_=true;},14);
    }
    button(c,{5,84,99,111},"Source KST",green,true,true,[this,stateKey,rootFolder]{auto& selected=keyboardSelectStates_[stateKey];selected.browserPath=rootFolder;selected.categoryPath="@all";selected.categoryPage=0;dirty_=true;},11);
    button(c,{105,84,196,111},"USER",green,false,true,[this,sounds]{if(!sounds){openSavedKeyboardLibrary();return;}bankSoundsOnly_=true;openPicker(Picker::Sound);},13);
    label(c,all?(sounds?"All Sounds":performances?"All Performances":"All Keyboard Sets"):state.categoryPath,211,104,15,green,true,584);
    for(int tile=0;tile<12;++tile){
        const auto offset=static_cast<std::size_t>(state.categoryPage*12+tile);if(offset>=categories.size())continue;
        const auto category=categories[offset];const bool selected=category.path==state.categoryPath;
        const float x=5+(tile%2)*98.0F,y=116+(tile/2)*44.0F;const RectF rect{x,y,x+93,y+40};
        box(c,rect,selected?0xFFE7D58CU:panel,selected?green:kBorder,2);
        const auto lines=wrappedKstText(category.name,83,11);
        label(c,lines.empty()?category.name:lines.front(),x+46.5F,y+13,11,selected?bg:white,true,85,Align::Center);
        if(lines.size()>1)label(c,lines[1],x+46.5F,y+25,11,selected?bg:white,true,85,Align::Center);
        label(c,std::to_string(category.count)+(category.children?"  >":""),x+46.5F,y+36,9,selected?bg:dim,false,85,Align::Center);
        hit(rect,[this,catalogHandle,stateKey,category]{if(kstCatalog_!=catalogHandle)return;auto& browse=keyboardSelectStates_[stateKey];browse.categoryPath=category.path;if(category.children){browse.browserPath=category.path;browse.categoryPage=0;}dirty_=true;});
    }
    button(c,{5,385,48,418},"◀",green,false,state.categoryPage>0,[this,stateKey]{--keyboardSelectStates_[stateKey].categoryPage;dirty_=true;},14);
    label(c,std::to_string(state.categoryPage+1)+" / "+std::to_string(categoryPages),100,407,12,dim,false,94,Align::Center);
    button(c,{153,385,196,418},"▶",green,false,state.categoryPage+1<categoryPages,[this,stateKey]{++keyboardSelectStates_[stateKey].categoryPage;dirty_=true;},14);
    std::size_t availableShown=0,shown=0;
    for(int tile=0;tile<10;++tile){
        const auto offset=static_cast<std::size_t>(page*10+tile);if(offset>=selectedItems.size())continue;
        const auto& item=items[selectedItems[offset]];const auto index=item.index;
        bool available=false,selected=false;std::string detail;
        if(sounds){
            const auto& sound=catalog.sounds[index];
            const auto prepared=sound.addressKnown?host::arrangerHost().preparedKeyboardSound(sound.msb,sound.lsb,sound.program,sound.path):sampler::ProgramPtr{};
            available=prepared!=nullptr;selected=prepared&&prepared==activeProgram;
            detail=available?(sound.drumKit?"User Drum Kit":"User Sound"):"Unavailable — tap for details";
            if(sound.addressKnown)detail+="  "+std::to_string(sound.msb)+" / "+std::to_string(sound.lsb)+" / "+std::to_string(sound.program);
        }else{
            const auto& keyboardSet=catalog.keyboardSets[index];std::size_t readySounds=0;
            if(keyboardSet.metadataSupported)for(const auto& part:keyboardSet.parts){
                if(!part.present||part.hasNoteEvents)continue;
                const arranger::Pa5xPerformancePatch* candidate=nullptr;bool ambiguous=false;
                for(const auto& patch:part.patches){
                    if(!patch.addressComplete)continue;
                    if(candidate&&std::tie(candidate->msb,candidate->lsb,candidate->program)!=std::tie(patch.msb,patch.lsb,patch.program)){ambiguous=true;break;}
                    candidate=&patch;
                }
                if(!ambiguous&&candidate&&host::arrangerHost().preparedKeyboardSound(candidate->msb,candidate->lsb,candidate->program,keyboardSet.path))++readySounds;
            }
            available=readySounds>0;selected=item.path==activeNativeKeyboardSetPath_;
            detail=available?std::to_string(readySounds)+" User Sound"+(readySounds==1?"":"s")+" available":"Unavailable — tap for details";
        }
        ++shown;if(available)++availableShown;
        const int row=tile%5,column=tile/5;const float x=208+column*295.0F,y=116+row*53.0F;const RectF rect{x,y,x+291,y+49};
        box(c,rect,selected?0xFFE7D58CU:(available?panel:0xFF161A1DU),selected?green:kBorder,2);
        keyboard(c,x+9,y+15,31,20,selected?bg:(available?dim:0xFF475158U));
        label(c,item.name,x+48,y+23,16,selected?bg:(available?white:dim),true,235);
        label(c,detail,x+48,y+42,10,selected?bg:(available?dim:0xFFB58D6EU),false,235);
        hit(rect,[this,catalogHandle,sounds,index,stateKey]{
            if(kstCatalog_!=catalogHandle)return;
            if(sounds)chooseKstKeyboardSound(index);
            else if(index<catalogHandle->keyboardSets.size()){
                const auto& chosen=catalogHandle->keyboardSets[index];
                if(!chosen.metadataSupported){showStyleInfo(chosen.name,chosen.blocker+"\n"+chosen.relativePath);return;}
                if(activateNativeKeyboardSet(chosen.path,targetKbdSet_)){
                    auto& selectedState=keyboardSelectStates_[stateKey];
                    selectedState.lastSourcePath=chosen.path;selectedState.locateActive=false;
                }
            }
        });
    }
    if(selectedItems.empty())label(c,items.empty()?(sounds?"No User Sounds in this KST":"No Keyboard Sets in this KST"):"Choose a bank on the left",502,252,18,dim,false,565,Align::Center);
    const auto categoryKey=state.categoryPath;
    button(c,{208,385,253,418},"◀",green,false,page>0,[this,stateKey,categoryKey]{--keyboardSelectStates_[stateKey].pages[categoryKey];dirty_=true;},15);
    const int firstPage=(page/8)*8;
    for(int number=0;number<8&&firstPage+number<pages;++number){const int targetPage=firstPage+number;const float x=264+number*58.0F;
        button(c,{x,385,x+52,418},std::to_string(targetPage+1),green,page==targetPage,true,[this,stateKey,categoryKey,targetPage]{keyboardSelectStates_[stateKey].pages[categoryKey]=targetPage;dirty_=true;},14);
    }
    button(c,{748,385,795,418},"▶",green,false,page+1<pages,[this,stateKey,categoryKey]{++keyboardSelectStates_[stateKey].pages[categoryKey];dirty_=true;},15);
    label(c,std::to_string(shown)+" shown / "+std::to_string(selectedItems.size())+" in bank  •  "+std::to_string(availableShown)+" available on page",210,435,12,dim,false,585);
    const bool canNavigate=state.browserPath!=rootFolder||state.categoryPath!=allCategory;
    button(c,{5,443,98,478},"ROOT",green,false,canNavigate,[this,stateKey,rootFolder]{auto& selected=keyboardSelectStates_[stateKey];selected.browserPath=rootFolder;selected.categoryPath="@all";selected.categoryPage=0;dirty_=true;},14);
    const auto currentFolder=folderLookup.find(all?state.browserPath:state.categoryPath);
    const auto parent=currentFolder==folderLookup.end()?rootFolder:folders[currentFolder->second].parent;
    button(c,{104,443,196,478},"UP",green,false,canNavigate,[this,stateKey,parent,rootFolder]{auto& selected=keyboardSelectStates_[stateKey];selected.browserPath=parent.empty()?rootFolder:parent;selected.categoryPath=(parent.empty()||parent==rootFolder)?"@all":parent;selected.categoryPage=0;dirty_=true;},14);
    box(c,{208,443,796,478},panel,kBorder,2);
    const auto path=files::join(catalog.rootPath,all?rootFolder:state.categoryPath);
    label(c,path,216,464,12,dim,false,571);
}
