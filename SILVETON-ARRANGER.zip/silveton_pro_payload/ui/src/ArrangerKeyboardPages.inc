// Native Home edit pages. Geometry/names follow Pa5X User Manual v1.5,
// pp.35, 434, 442, 457, 461, 480-491 and 549-555. The controls operate
// the existing SILVETON keyboard; extra Upper parts/EQ/send remain explicit.
namespace {
const char* arrangerKeyboardFxName(int type) {
    static const char* names[]{"Off","Digital Delay","Chorus","Plate Reverb","Hall","Room","Chamber","Spring",
        "Tape Delay","Ping-Pong Delay","Multi-Tap Delay","Ducking Delay","Flanger","Phaser","Rotary","Compressor","Drive","Ensemble"};
    return names[static_cast<std::size_t>(std::clamp(type,0,17))];
}
constexpr const char* kNativeFxGroups[]{"Всички групи","Reverb","Delay","Модулация","Динамика","Drive","Без ефект"};
int arrangerKeyboardFxGroup(int type){
    if(type==0)return 6;
    if(type>=3&&type<=7)return 1;
    if(type==1||(type>=8&&type<=11))return 2;
    if(type==2||(type>=12&&type<=14)||type==17)return 3;
    if(type==15)return 4;
    if(type==16)return 5;
    return 0;
}
}

void ArrangerView::openKeyboardEdit(KeyboardEditPage page) {
    if(page==KeyboardEditPage::Guitar){
        if(trackEditPlayer_<0||!host::arrangerHost().snapshot(trackEditPlayer_).loaded){
            showToast("Select a Style before opening Style Guitar",4000);return;
        }
        styleEditTrack_=std::clamp(styleEditTrack_,3,7);
        styleTracksSecondPage_=styleEditTrack_==7||(styleTracksSecondPage_&&styleEditTrack_>=4);
    }else if(keyboardEditPage_==KeyboardEditPage::Guitar&&trackEditPlayer_>=0){
        styleTracksSecondPage_=styleEditTrack_>=4;
    }
    if(page==KeyboardEditPage::SoundEdit||page==KeyboardEditPage::Eq||page==KeyboardEditPage::EqAdvanced){
        if(page!=KeyboardEditPage::SoundEdit)tonePage_=2;
        if(trackEditPlayer_>=0)setPlayerFocus(trackEditPlayer_,false);
        openSoundWindow(trackEditPlayer_<0,trackEditPlayer_<0?keyboardEditPart_:styleEditTrack_);
        return;
    }
    const auto group=[](KeyboardEditPage p){
        if(p==KeyboardEditPage::Mode||p==KeyboardEditPage::SoundEdit||p==KeyboardEditPage::RangeWrap||p==KeyboardEditPage::Guitar)return 0;
        if(p==KeyboardEditPage::Range||p==KeyboardEditPage::Controllers||p==KeyboardEditPage::Aftertouch)return 1;
        return 2;
    };
    if(picker_!=Picker::KeyboardEdit||group(keyboardEditPage_)!=group(page)||
       (page==KeyboardEditPage::EqAdvanced&&keyboardEditPage_!=page))rememberNavigation();
    choosingRangeElement_=false;rangeElement_=-1;fxChoosing_=false;closeKstScan(); editor_=false; picker_=Picker::KeyboardEdit; keyboardEditPage_=page;
    held_={};dirty_=true;refresh();
}

void ArrangerView::drawHomeMenu(Canvas& c) {
    box(c,{0,0,800,480},bg);
    label(c,"HOME MENU",12,30,19,white,true,350);
    button(c,{716,3,795,36},"‹ Exit",orange,false,true,[this]{panelExit();},15);
    const auto tile=[&](int column,int row,const std::string& title,bool enabled,const std::function<void()>& action,int icon){
        const float x=column*200.0F,y=42.0F+row*133.0F;
        const ColorInt ink=enabled?dim:0xFF546166U;
        const RectF r{x+2,y,x+198,y+129};
        box(c,r,enabled?0xFF202D36U:0xFF172128U,kBorder,2);
        if(icon==0){
            box(c,{x+63,y+22,x+137,y+78},bg,ink,2);
            for(int i=0;i<4;++i){const float l=x+76+i*16.0F;box(c,{l,y+28,l+2,y+70},ink);box(c,{l-4,y+35+i*6.0F,l+6,y+41+i*6.0F},ink);}
        }else if(icon==1){
            Paint paint;paint.color=ink;
            for(int j=0;j<2;++j){const float l=x+44+j*61.0F;box(c,{l,y+30,l+48,y+34},ink);box(c,{l+22,y+34,l+24,y+73},ink);}
            box(c,{x+57,y+47,x+85,y+67},bg,ink,2);box(c,{x+114,y+47,x+141,y+67},bg,ink,2);
            c.drawCircle(x+100,y+63,19,paint);paint.color=bg;c.drawCircle(x+100,y+63,15,paint);
        }else if(icon==2){
            keyboard(c,x+62,y+32,76,44,ink);
        }else if(icon==3){
            label(c,"♪",x+100,y+78,64,ink,true,115,Align::Center);
        }else{
            for(int i=0;i<3;++i)keyboard(c,x+47+i*16.0F,y+22+i*13.0F,72,30,ink);
        }
        label(c,title,r.centerX(),y+110,17,enabled?white:ink,true,r.width()-12,Align::Center);
        if(enabled)hit(r,action);
    };
    // The implemented Pa5X sections occupy their Home Menu row and column.
    tile(0,0,"Mixer / FX",true,[this]{trackEditPlayer_=players_[selectedPlayer_].loaded?selectedPlayer_:-1;openKeyboardEdit(KeyboardEditPage::Main);},0);
    tile(1,0,"Drum Editor",players_[selectedPlayer_].loaded||kstCatalog_!=nullptr,[this]{
        if(players_[selectedPlayer_].loaded)openLiveSoundPage(Picker::DrumFamilyEdit);
        else {openInspector(Picker::SetSounds);filterSetSounds(2);}
    },1);
    tile(2,0,"Track Controls",true,[this]{trackEditPlayer_=players_[selectedPlayer_].loaded?selectedPlayer_:-1;openKeyboardEdit(KeyboardEditPage::Mode);},2);
    tile(3,0,"Keyboard Ensemble",true,[this]{trackEditPlayer_=-1;openKeyboardEdit(KeyboardEditPage::Controllers);},4);
    // Pa5X v1.4 menu positions. Unimplemented functions are not wired to
    // unrelated editors. Existing SILVETON tools are kept as separate shortcuts.
    tile(0,1,"Pads",false,[]{},3);
    tile(1,1,"Style Controls",true,[this]{rememberNavigation();picker_=Picker::StyleControls;fillControlSlot_=-1;dirty_=true;},3);
    tile(2,1,"Mic Preset",false,[]{},3);
    tile(3,1,"Guitar Preset",false,[]{},3);
    tile(0,2,"Switches",false,[]{},0);
    label(c,"SILVETON TOOLS",218,333,14,dim,true,565);
    button(c,{207,344,497,391},"Style Guitar",orange,false,players_[selectedPlayer_].loaded&&!players_[selectedPlayer_].styleSwitchPending,[this]{
        trackEditPlayer_=selectedPlayer_;styleEditTrack_=3;
        const auto current=host::arrangerHost().snapshot(trackEditPlayer_);
        if(!current.loaded||current.styleSwitchPending){showToast("Select a Style before opening Style Guitar",4000);return;}
        for(int part=3;part<8;++part){
            const auto guitar=host::arrangerHost().styleGuitar(trackEditPlayer_,current.styleSelectionSerial,current.element,part);
            if(guitar.available&&guitar.guitar){styleEditTrack_=part;break;}
        }
        styleTracksSecondPage_=styleEditTrack_==7;openKeyboardEdit(KeyboardEditPage::Guitar);
    },16);
    button(c,{504,344,796,391},"Pa5X FX Catalogue",orange,false,true,[this]{openPa5xFxCatalog();},16);
    button(c,{207,399,497,446},"Sound Editor",green,false,true,[this]{openEditor(Page::COMBI);},16);
    button(c,{504,399,796,446},liveView_?"Full Panel":"Live View",green,false,true,[this]{home();liveView_=!liveView_;dirty_=true;},16);
    label(c,"Dimmed sections are not yet implemented.",218,471,12,dim,false,570);
}

void ArrangerView::drawKeyboardEdit(Canvas& c) {
    const auto panelHits=hits_.size();
    using silveton::sampler::Combi;
    using silveton::sampler::UpperPart;
    using silveton::sampler::EffectSlot;
    using silveton::sampler::EffectType;
    const auto page=keyboardEditPage_;
    const bool fxPage=page==KeyboardEditPage::InsertFx||page==KeyboardEditPage::Effects||page==KeyboardEditPage::FxSend;
    const bool styleTarget=trackEditPlayer_>=0;
    std::uint64_t selection=0;
    auto snapshot=styleTarget?host::arrangerHost().styleTrackCombi(trackEditPlayer_,selection):ctrl_.engine.nativeKeyboardCombi();
    if(styleTarget&&!snapshot){
        showToast("The Style is no longer available.",4500);panelExit();return;
    }
    const auto partName=[styleTarget](int part)->std::string{
        static const char* tracks[]={"Drum","Perc","Bass","Acc 1","Acc 2","Acc 3","Acc 4","Acc 5"};
        return styleTarget?tracks[std::clamp(part,0,7)]:arrangerKeyboardPartName(part);
    };
    if(!snapshot){showToast("No keyboard performance is available",4000);picker_=Picker::HomeMenu;dirty_=true;return;}
    const bool ensemble=page==KeyboardEditPage::Range||page==KeyboardEditPage::Controllers||page==KeyboardEditPage::Aftertouch;
    const bool track=page==KeyboardEditPage::Mode||page==KeyboardEditPage::SoundEdit||page==KeyboardEditPage::RangeWrap||page==KeyboardEditPage::Guitar;
    const bool guitarPage=styleTarget&&page==KeyboardEditPage::Guitar;
    const char* section=guitarPage?"STYLE GUITAR":ensemble?(styleTarget?"STYLE TRACKS":"KBD ENSEMBLE"):track?"TRACK CONTROL":"MIXER / FX";
    const std::array<int,4> parts=guitarPage?(styleTracksSecondPage_?std::array<int,4>{{4,5,6,7}}:std::array<int,4>{{3,4,5,6}}):
        styleTarget?(styleTracksSecondPage_?std::array<int,4>{{4,5,6,7}}:std::array<int,4>{{0,1,2,3}}):keyboardExtension_?std::array<int,4>{{6,5,4,3}}:std::array<int,4>{{6,2,1,0}};
    const auto mutate=[this,styleTarget,selection,player=trackEditPlayer_](const std::function<void(Combi&)>& change){
        if(styleTarget){
            if(!host::arrangerHost().editStyleCombi(player,selection,change))showToast(host::arrangerHost().lastError(),4500);
            else markPersistentStateChanged();
            dirty_=true;return;
        }
        const auto current=ctrl_.engine.nativeKeyboardCombi();if(!current)return;
        Combi edited=*current;change(edited);
        // Range/FX/solo edits must not make Lower audible in Full mode.
        if(!keyboardSplitEnabled_)edited.part(6).mute=true;
        std::array<bool,7> lowChanged{},highChanged{},enabledChanged{};
        for(std::size_t index=0;index<lowChanged.size();++index){
            const auto& before=current->part(static_cast<int>(index));
            const auto& after=edited.part(static_cast<int>(index));
            lowChanged[index]=before.keyLow!=after.keyLow;
            highChanged[index]=before.keyHigh!=after.keyHigh;
            enabledChanged[index]=before.enabled!=after.enabled;
        }
        if(!ctrl_.engine.nativeApplyKeyboardCombi(edited,true)){showToast(ctrl_.engine.nativeLastTextError(),5000);return;}
        captureKeyboardFxOverride(*current,edited);
        // Split caps are applied to saved/user ranges, never captured again
        // from an unrelated level, pan or FX edit of the already capped part.
        for(std::size_t index=0;index<lowChanged.size();++index){
            const auto& after=edited.part(static_cast<int>(index));
            if(lowChanged[index])keyboardRangeLow_[index]=after.keyLow;
            if(highChanged[index])keyboardRangeHigh_[index]=after.keyHigh;
            if(enabledChanged[index])keyboardSplitSuppressed_[index]=false;
        }
        markPersistentStateChanged();refresh();dirty_=true;
    };
    const auto manualFx=[this,mutate,styleTarget,selection,player=trackEditPlayer_]{
        std::array<std::array<int,3>,8> observed{};
        for(auto& sends:observed)sends.fill(-1);
        if(styleTarget){
            const auto live=host::arrangerHost().snapshot(player);
            if(live.styleSelectionSerial!=selection){showToast("The selected Style has changed",4000);return;}
            for(std::size_t part=0;part<observed.size();++part)observed[part]=live.tracks[part].sourceFxSendRaw;
        }
        mutate([observed](Combi& combi){
            // Manual sends start at the current original Style levels, not
            // the otherwise unused native defaults underneath MIDI sends.
            if(combi.sourceEffects&&combi.sourceEffects->followMidiSends){
                for(std::size_t part=0;part<observed.size();++part){
                    auto& u=combi.part(static_cast<int>(part));
                    float* values[3]{&u.fxSend1,&u.fxSend2,&u.fxSend3};
                    for(std::size_t send=0;send<3;++send)if(observed[part][send]>=0&&observed[part][send]<=127)
                        *values[send]=static_cast<float>(observed[part][send])/127.0F;
                }
            }
            combi.sourceEffects.reset();
        });
        fxChoosing_=false;keyboardSourceFxPage_=0;dirty_=true;
        showToast("The prepared FX and current sends are now editable in SILVETON",4500);
    };
    const auto edit=[mutate](int part,const std::function<void(UpperPart&)>& change){mutate([part,change](Combi& combi){change(combi.part(part));});};
    box(c,{0,0,800,480},bg);
    box(c,{3,3,157,31},key,orange);label(c,section,80,24,16,orange,true,147,Align::Center);
    const int focused=styleTarget?styleEditTrack_:std::clamp(keyboardEditPart_,0,6);
    label(c,partName(focused),171,24,15,dim,true,94);
    const auto& focusedPart=snapshot->part(focused);
    const std::string focusedName=!focusedPart.name.empty()?focusedPart.name:(focusedPart.program?focusedPart.program->name:"Select Sound");
    label(c,styleTarget?"Player "+std::to_string(trackEditPlayer_+1)+" · "+players_[trackEditPlayer_].name:
        fxPage?"Keyboard Set · "+snapshot->name:focusedName,272,24,15,dim,false,286);
    label(c,"b/#: "+signedNumber(globalUi_?globalUi_->transpose:0),566,24,15,dim);
    button(c,{716,4,795,33},"‹ Back",orange,false,true,[this]{panelExit();},13);

    const auto sideTab=[&](KeyboardEditPage target,const std::string& text,int position,bool selected){
        const RectF r{715,45.0F+position*52.0F,798,94.0F+position*52.0F};
        box(c,r,selected?0xFF40484DU:key,selected?orange:kBorder,2);
        const auto split=text.find(' ');
        if(split!=std::string::npos){
            label(c,text.substr(0,split),r.centerX(),r.top+20,12,selected?white:dim,true,77,Align::Center);
            auto second=text.substr(split+1);if(second.size()>2&&second.substr(0,2)=="/ ")second.erase(0,2);
            label(c,second,r.centerX(),r.top+36,12,selected?white:dim,true,77,Align::Center);
        }else label(c,text,r.centerX(),r.centerY()+4,12,selected?white:dim,true,77,Align::Center);
        hit(r,[this,target]{openKeyboardEdit(target);});
    };
    if(ensemble){
        sideTab(KeyboardEditPage::Controllers,"Pedal / CC",0,page==KeyboardEditPage::Controllers);
        sideTab(KeyboardEditPage::Aftertouch,"After Touch",1,page==KeyboardEditPage::Aftertouch);
        sideTab(KeyboardEditPage::Range,"Range / Vel",2,page==KeyboardEditPage::Range);
    }else if(track){
        sideTab(KeyboardEditPage::Mode,"Mode",0,page==KeyboardEditPage::Mode);
        sideTab(KeyboardEditPage::SoundEdit,"Sound Edit",1,page==KeyboardEditPage::SoundEdit);
        if(styleTarget)sideTab(KeyboardEditPage::RangeWrap,"Range/Wrap",2,page==KeyboardEditPage::RangeWrap);
        if(styleTarget)sideTab(KeyboardEditPage::Guitar,"Guitar",3,page==KeyboardEditPage::Guitar);
    }else{
        sideTab(KeyboardEditPage::Main,"Main",0,page==KeyboardEditPage::Main);
        sideTab(KeyboardEditPage::Eq,"EQ",1,page==KeyboardEditPage::Eq||page==KeyboardEditPage::EqAdvanced);
        sideTab(KeyboardEditPage::InsertFx,"Insert FX",2,page==KeyboardEditPage::InsertFx);
        sideTab(KeyboardEditPage::Effects,"Master FX",3,page==KeyboardEditPage::Effects);
        sideTab(KeyboardEditPage::FxSend,"MFX Send",4,page==KeyboardEditPage::FxSend);
        sideTab(KeyboardEditPage::Tune,"Bend / Tuning",5,page==KeyboardEditPage::Tune);
    }
    if(styleTarget&&page!=KeyboardEditPage::Effects)button(c,{715,370,798,409},
        guitarPage?(styleTracksSecondPage_?"Acc 1–4":"Acc 2–5"):(styleTracksSecondPage_?"Tracks 1–4":"Tracks 5–8"),
        green,styleTracksSecondPage_,true,[this,guitarPage]{
            styleTracksSecondPage_=!styleTracksSecondPage_;
            styleEditTrack_=guitarPage?std::clamp(styleEditTrack_,styleTracksSecondPage_?4:3,styleTracksSecondPage_?7:6):(styleTracksSecondPage_?4:0);
            dirty_=true;
        },12);
    else if(!styleTarget&&page!=KeyboardEditPage::Effects)button(c,{715,370,798,409},keyboardExtension_?"Upper 1–3":"Upper 4–6",green,keyboardExtension_,true,[this]{keyboardExtension_=!keyboardExtension_;keyboardEditPart_=keyboardExtension_?3:0;dirty_=true;},12);

    // Numeric cells behave as touch faders through the selected target's
    // control API; Programs and their PCM remain shared.
    const auto field=[&](RectF r,const std::string& title,const std::string& shown,float value,float low,float high,
                         const std::function<void(float)>& change,bool whole=false,bool logarithmic=false,bool enabled=true){
        box(c,r,panel,kBorder,2);label(c,title,r.left+6,r.top+14,11,dim,false,r.width()-12);
        label(c,shown,r.centerX(),r.bottom-8,18,enabled?white:dim,true,r.width()-12,Align::Center);
        const float norm=high<=low?0.0F:(logarithmic?std::log(std::max(value,low)/low)/std::log(high/low):(value-low)/(high-low));
        box(c,{r.left+4,r.bottom-3,r.left+4+(r.width()-8)*std::clamp(norm,0.0F,1.0F),r.bottom-1},enabled?green:kBorder);
        if(enabled)hit(r,{},[r,low,high,change,whole,logarithmic,previous=std::numeric_limits<float>::quiet_NaN()](float x,float) mutable {
            const float n=std::clamp((x-r.left-5)/(r.width()-10),0.0F,1.0F);
            float v=logarithmic?low*std::pow(high/low,n):low+(high-low)*n;
            v=std::clamp(whole?std::round(v):v,low,high);
            if(v==previous)return;
            previous=v;change(v);
        });
    };
    const auto toggle=[&](RectF r,const std::string& text,bool value,const std::function<void()>& change,bool immediate=false){button(c,r,text,green,value,true,change,13,immediate);};
    const auto cell=[](int column,int row,float height=48.0F){const float x=12+column*174.0F,y=111+row*height;return RectF{x,y,x+166,y+height-5};};

    if(page==KeyboardEditPage::SoundEdit){
#include "ArrangerSoundEdit.inc"
    }else if(page==KeyboardEditPage::RangeWrap&&styleTarget){
#include "ArrangerRangeWrap.inc"
    }else if(page==KeyboardEditPage::Guitar&&styleTarget){
#include "ArrangerGuitar.inc"
    }else if(page==KeyboardEditPage::EqAdvanced){
        label(c,"5-band EQ extension",17,63,16,white,true);
        toggle({497,43,695,75},"EQ On",focusedPart.eq.on,[edit,focused]{edit(focused,[](auto& u){u.eq.on=!u.eq.on;});});
        static const char* bandNames[]{"LF","Low Mid","MF","High Mid","HF"};
        for(int band=0;band<5;++band){const float x=12+band*138.0F;const auto b=focusedPart.eq.band[static_cast<std::size_t>(band)];
            toggle({x,88,x+130,119},bandNames[band],b.on,[edit,focused,band]{edit(focused,[band](auto& u){auto& enabled=u.eq.band[static_cast<std::size_t>(band)].on;enabled=!enabled;});});
            field({x,127,x+130,174},"Frequency",fmtFixed(b.freqHz,0)+" Hz",b.freqHz,20,20000,[edit,focused,band](float v){edit(focused,[band,v](auto& u){u.eq.band[static_cast<std::size_t>(band)].freqHz=v;});},false,true);
            field({x,181,x+130,228},"Gain",fmtFixed(b.gainDb,1)+" dB",b.gainDb,-18,18,[edit,focused,band](float v){edit(focused,[band,v](auto& u){u.eq.band[static_cast<std::size_t>(band)].gainDb=v;u.eqLowDb=u.eq.band[0].gainDb;u.eqMidDb=u.eq.band[2].gainDb;u.eqHighDb=u.eq.band[4].gainDb;});});
            if(band>0&&band<4)field({x,235,x+130,282},"Q",fmtFixed(b.q,2),b.q,.1F,10,[edit,focused,band](float v){edit(focused,[band,v](auto& u){u.eq.band[static_cast<std::size_t>(band)].q=v;});},false,true);
            else label(c,"Shelving",x+65,260,13,dim,false,120,Align::Center);
        }
        toggle({12,298,150,329},"High Pass",focusedPart.eq.hpOn,[edit,focused]{edit(focused,[](auto& u){u.eq.hpOn=!u.eq.hpOn;});});
        field({159,292,339,338},"High Pass",fmtFixed(focusedPart.eq.hpHz,0)+" Hz",focusedPart.eq.hpHz,10,2000,[edit,focused](float v){edit(focused,[v](auto& u){u.eq.hpHz=v;});},false,true);
        toggle({354,298,492,329},"Low Pass",focusedPart.eq.lpOn,[edit,focused]{edit(focused,[](auto& u){u.eq.lpOn=!u.eq.lpOn;});});
        field({501,292,695,338},"Low Pass",fmtFixed(focusedPart.eq.lpHz,0)+" Hz",focusedPart.eq.lpHz,1000,20000,[edit,focused](float v){edit(focused,[v](auto& u){u.eq.lpHz=v;});},false,true);
        button(c,{12,349,219,382},"Current Track Reset",green,false,true,[edit,focused]{edit(focused,[](auto& u){u.eq={};u.eqLowDb=u.eqMidDb=u.eqHighDb=0;});},12);
        button(c,{231,349,438,382},styleTarget?"Style Tracks Reset":"Keyboard Tracks Reset",green,false,true,[mutate,styleTarget]{mutate([styleTarget](auto& combi){for(int i=0;i<(styleTarget?8:7);++i){auto& u=combi.part(i);u.eq={};u.eqLowDb=u.eqMidDb=u.eqHighDb=0;}});},12);
        button(c,{450,349,695,382},"Back to Channel EQ",green,false,true,[this]{panelExit();},12);
    }else if(page==KeyboardEditPage::InsertFx||page==KeyboardEditPage::Effects){
        const bool insert=page==KeyboardEditPage::InsertFx;
        if(insert)keyboardFxUnit_=4+focused;else if(keyboardFxUnit_<0||keyboardFxUnit_>3)keyboardFxUnit_=0;
        const int unit=keyboardFxUnit_;
        for(int i=0;i<4;++i){const int selectedUnit=insert?4+parts[static_cast<std::size_t>(i)]:i;const float x=12+i*174.0F;
            button(c,{x,45,x+166,80},insert?std::string("IFX ")+partName(parts[static_cast<std::size_t>(i)]):std::string("MFX ")+std::to_string(i+1),green,selectedUnit==unit,true,[this,insert,i,selectedUnit,parts,styleTarget]{keyboardFxUnit_=selectedUnit;keyboardSourceFxPage_=0;if(insert)(styleTarget?styleEditTrack_:keyboardEditPart_)=parts[i];dirty_=true;},12);
        }
        if(snapshot->sourceEffects){
#include "ArrangerSourceEffects.inc"
        }else{
        const auto& fx=insert?snapshot->insertOf(focused):snapshot->fx[static_cast<std::size_t>(unit)];
        const auto fxEdit=[mutate,insert,focused,unit](const std::function<void(EffectSlot&)>& change){mutate([insert,focused,unit,change](Combi& combi){change(insert?combi.insertOf(focused):combi.fx[static_cast<std::size_t>(unit)]);});};
        const int type=static_cast<int>(fx.type);
        const bool hasNumbered=fx.numbered.index!=0;
        if(fxChoosing_){
            // This chooser owns all input hits while its overlay is visible.
            hits_.resize(panelHits);box(c,{0,0,800,480},bg);
            button(c,{9,6,112,43},"‹ Назад",orange,false,true,[this]{fxChoosing_=false;dirty_=true;},14);
            label(c,"Допълнителни FX",130,34,20,green,true,380);
            button(c,{530,7,788,42},"Pa5X FX · по номера",green,false,insert||unit<3,[this,insert,focused,unit,selection]{
                fxChoosing_=false;openNumberedFxSelector(insert,focused,unit,selection);
            },13);
            constexpr int order[]={0,4,3,5,6,7,1,8,9,10,11,2,17,12,13,14,15,16};
            constexpr int perPage=10;
            nativeFxCategory_=std::clamp(nativeFxCategory_,0,static_cast<int>(std::size(kNativeFxGroups))-1);
            std::array<int,std::size(kNativeFxGroups)> groupCounts{};
            std::vector<int> visible;visible.reserve(sampler::kEffectTypeCount);
            for(const int t:order){
                ++groupCounts[0];++groupCounts[arrangerKeyboardFxGroup(t)];
                if(!nativeFxCategory_||arrangerKeyboardFxGroup(t)==nativeFxCategory_)visible.push_back(t);
            }
            label(c,"ГРУПИ",17,72,12,dim,true,165);
            for(int i=0;i<static_cast<int>(std::size(kNativeFxGroups));++i){
                const float y=88.0F+i*40.0F;const bool selected=nativeFxCategory_==i;
                box(c,{10,y,183,y+35},selected?0xFF203D35U:panel,selected?green:kBorder);
                label(c,kNativeFxGroups[i],18,y+23,13,white,selected,132);
                label(c,std::to_string(groupCounts[i]),175,y+23,11,selected?green:dim,true,27,Align::Right);
                hit({10,y,183,y+35},[this,i]{nativeFxCategory_=i;nativeFxPage_=0;dirty_=true;});
            }
            const int total=static_cast<int>(visible.size());
            const int pages=std::max(1,(total+perPage-1)/perPage);
            nativeFxPage_=std::clamp(nativeFxPage_,0,pages-1);
            label(c,std::string(kNativeFxGroups[nativeFxCategory_])+" · "+(insert?"IFX":"MFX "+std::to_string(unit+1)),195,76,13,white,true,590);
            for(int i=0;i<perPage;++i){
                const int at=nativeFxPage_*perPage+i;if(at>=total)break;
                const int t=visible[static_cast<std::size_t>(at)];
                const float x=194.0F+(i%2)*300.0F,y=96.0F+(i/2)*64.0F;
                const bool selected=!hasNumbered&&type==t;const RectF r{x,y,x+294,y+58};
                box(c,r,selected?0xFF203D35U:panel,selected?green:kBorder,2);
                label(c,arrangerKeyboardFxName(t),x+12,y+25,15,white,true,270);
                label(c,selected?"Текущ ефект":kNativeFxGroups[arrangerKeyboardFxGroup(t)],x+12,y+46,11,selected?green:dim,false,270);
                hit(r,[this,fxEdit,t,type,hasNumbered]{
                    if(t!=type||hasNumbered)fxEdit([t](auto& f){
                        f=EffectSlot{};f.type=static_cast<EffectType>(t);
                        if(t)f.wet=t==15?1.0F:0.3F;
                        if(t==2)f.param1=3;
                        if(t==13)f.param1=6;
                        if(t==15){f.param1=-20;f.param2=4;f.param3=120;f.timeMs=10;f.tone=0;}
                    });
                    fxChoosing_=false;dirty_=true;
                });
            }
            label(c,insert||unit<3?"Отделна колекция от 18 типа, включително Off. Изборът сменя ефекта в този слот.":
                "MFX 4 използва допълнителните ефекти. Номерираните Pa5X FX са за MFX 1–3.",14,430,11,dim,false,774);
            button(c,{194,443,280,478},"‹",green,false,nativeFxPage_>0,[this]{--nativeFxPage_;dirty_=true;},20);
            label(c,"Страница "+std::to_string(nativeFxPage_+1)+" / "+std::to_string(pages)+" · "+std::to_string(total)+" типа",490,466,12,white,true,390,Align::Center);
            button(c,{702,443,788,478},"›",green,false,nativeFxPage_+1<pages,[this]{++nativeFxPage_;dirty_=true;},20);
            return;
        }
        const auto* numbered=hasNumbered?sampler::findNumberedFx(fx.numbered.index):nullptr;
        const std::string shownType=hasNumbered?std::to_string(fx.numbered.index)+" · "+(numbered?numbered->name:"Unknown numbered FX"):arrangerKeyboardFxName(type);
        button(c,{12,88,508,123},std::string(insert?"Insert FX · ":"Master FX · ")+shownType+"  ▾",green,type!=0||hasNumbered,true,[this,hasNumbered,insert,focused,unit,selection,type]{
            if(hasNumbered)openNumberedFxSelector(insert,focused,unit,selection);
            else {nativeFxCategory_=type?arrangerKeyboardFxGroup(type):0;nativeFxPage_=0;fxChoosing_=true;dirty_=true;}
        },14);
        button(c,{520,88,695,123},"Pa5X FX · групи",green,false,true,[this,insert,focused,unit,selection]{openNumberedFxSelector(insert,focused,unit,selection);},12);
        if(hasNumbered){
            const auto support=sampler::numberedFxSupport(fx.numbered.index);
            button(c,{12,139,695,190},"Main / Zoom · параметри по официалния номер",green,false,true,[this,insert,focused,unit,selection,index=fx.numbered.index]{
                openNumberedFxSelector(insert,focused,unit,selection);
                openNumberedFxEditor(index);
            },16);
            if(!insert&&numberedFxHasLiveSource(fx.numbered.index))
                label(c,fx.numberedModulatingPart<0?"Управление: Off · отвори Main / Zoom и избери Mod. Track":
                    "Управляваща партия: "+numberedFxModulatingPartName(fx.numberedModulatingPart,styleTarget),16,215,12,fx.numberedModulatingPart<0?orange:green,false,675);
            else label(c,std::string(sampler::numberedFxOriginName(fx.numbered.origin))+" · ръчни настройки на ефекта",16,215,12,green,false,675);
            const auto lines=wrappedKstText(support.limitation,670,12);
            for(std::size_t line=0;line<std::min<std::size_t>(lines.size(),3);++line)label(c,lines[line],16,238+18.0F*line,12,dim,false,670);
            button(c,{12,292,342,333},"Допълнителни FX · 18 типа",green,false,true,[this]{nativeFxCategory_=0;nativeFxPage_=0;fxChoosing_=true;dirty_=true;},12);
            if(!insert)field({354,286,695,335},"MFX Return Level",fmtFixed(fx.wet*100,0)+" %",fx.wet,0,1,[fxEdit](float value){fxEdit([value](auto& f){f.wet=value;});});
            else label(c,"Wet/Dry е в редактора на ефекта",354,318,12,dim,false,340);
        }else{
        // The offered parameter list changes with the real effect type.
        struct Parameter{const char* title;int id;float value,low,high;bool logarithmic;};
        std::vector<Parameter> parameters;
        // Insert slots interpolate dry/processed audio. Master slots return
        // an additive send signal, so their gain is Return Level.
        if(type!=0)
            parameters.push_back({insert?"Wet / Dry":"Return Level",1,fx.wet,0,1,false});
        const bool delay=type==1||(type>=8&&type<=11),reverb=type>=3&&type<=7;
        if(delay){const float maxTime=insert?1100.0F:2500.0F;if(!fx.tempoSync)parameters.push_back({"Time (ms)",2,std::clamp(fx.timeMs,1.0F,maxTime),1,maxTime,true});parameters.push_back({"Feedback",3,fx.feedback,0,.95F,false});parameters.push_back({"Tone",6,fx.tone,0,1,false});}
        if(reverb){
            parameters.push_back({"Decay",3,fx.feedback,0,.95F,false});
            parameters.push_back({"Pre-Delay (ms)",7,std::clamp(fx.preDelayMs,0.0F,type==7?150.0F:200.0F),0,type==7?150.0F:200.0F,false});
            parameters.push_back({"Tone",6,fx.tone,0,1,false});
            if(type!=7)parameters.push_back({"Damping",8,fx.damping,0,1,false});
            if(type>=4&&type<=6)parameters.push_back({"Modulation",10,fx.mod,0,1,false});
            if(type!=3)parameters.push_back({"Size",9,fx.size,0,1,false});
        }
        if(type==2||type==12||type==13||type==17){parameters.push_back({"Rate (Hz)",4,fx.rateHz,.02F,12,true});parameters.push_back({"Depth",5,fx.depth,0,1,false});}
        if(type==14){
            if(fx.param2>=.5F)parameters.push_back({"Fast Speed (Hz)",14,std::clamp(fx.param1>0?fx.param1:6.5F,2.0F,10.0F),2,10,true});
            else parameters.push_back({"Slow Speed (Hz)",4,std::clamp(fx.rateHz,.1F,2.0F),.1F,2,true});
            parameters.push_back({"Depth",5,fx.depth,0,1,false});
        }
        if(type==12)parameters.push_back({"Feedback",3,fx.feedback,-.95F,.95F,false});
        if(type==13)parameters.push_back({"Feedback",3,std::clamp(fx.feedback,0.0F,.9F),0,.9F,false});
        if(type==15){parameters.push_back({"Threshold (dB)",14,std::clamp(fx.param1,-60.0F,0.0F),-60,0,false});parameters.push_back({"Ratio",15,fx.param2>1?fx.param2:4.0F,1.1F,20,false});parameters.push_back({"Attack (ms)",2,std::clamp(fx.timeMs,.1F,300.0F),.1F,300,true});parameters.push_back({"Release (ms)",16,fx.param3>0?std::clamp(fx.param3,10.0F,3000.0F):120.0F,10,3000,true});parameters.push_back({"Makeup (dB)",6,fx.tone,0,24,false});}
        if(type==16){parameters.push_back({"Drive",5,fx.depth,0,1,false});parameters.push_back({"Tone",6,fx.tone,0,1,false});parameters.push_back({"Output (dB)",14,fx.param1,-24,12,false});}
        if(type==8){parameters.push_back({"Wow / Flutter",10,fx.mod,0,1,false});parameters.push_back({"Saturation",5,fx.depth,0,1,false});}
        if(type==2)parameters.push_back({"Voices",14,std::clamp(std::round(fx.param1),2.0F,4.0F),2,4,false});
        if(type==13)parameters.push_back({"Stages",14,static_cast<float>(std::clamp(static_cast<int>(std::lround(fx.param1))&~1,4,8)),4,8,false});
        if(type==10||type==11)parameters.push_back({type==10?"Spread":"Ducking",5,fx.depth,0,1,false});
        for(std::size_t i=0;i<parameters.size();++i){const auto p=parameters[i];const float x=12+(i%3)*232.0F,y=131+(i/3)*54.0F;
            const bool percent=p.low>=-1&&p.high<=1;
            field({x,y,x+222,y+50},p.title,fmtFixed(percent?p.value*100:p.value,percent?0:1)+(percent?" %":""),p.value,p.low,p.high,[fxEdit,type,id=p.id](float v){if(id==14&&type==13)v=std::round(v/2)*2;if(id==14&&type==2)v=std::round(v);fxEdit([id,v](auto& f){switch(id){case 1:f.wet=v;break;case 2:f.timeMs=v;break;case 3:f.feedback=v;break;case 4:f.rateHz=v;break;case 5:f.depth=v;break;case 6:f.tone=v;break;case 7:f.preDelayMs=v;break;case 8:f.damping=v;break;case 9:f.size=v;break;case 10:f.mod=v;break;case 14:f.param1=v;break;case 15:f.param2=v;break;case 16:f.param3=v;break;default:break;}});},false,p.logarithmic);
        }
        if(type==0)label(c,"Select an effect above",353,236,20,dim,false,630,Align::Center);
        if(delay){
            toggle({12,305,218,338},"Tempo Division",fx.tempoSync,[fxEdit]{fxEdit([](auto& f){f.tempoSync=!f.tempoSync;});});
            if(fx.tempoSync){field({230,296,450,341},"FX Tempo",fmtFixed(fx.tempoBpm,1)+" BPM",fx.tempoBpm,30,300,[fxEdit](float v){fxEdit([v](auto& f){f.tempoBpm=v;});});field({462,296,695,341},"Note Division",fmtFixed(fx.division,3),fx.division,1.0F/64,1,[fxEdit](float v){fxEdit([v](auto& f){f.division=v;});});}
        }
        if(type==14)toggle({12,305,218,338},"Fast",fx.param2>=.5F,[fxEdit]{fxEdit([](auto& f){f.param2=f.param2>=.5F?0.0F:1.0F;});});
        }
        if(!insert)button(c,{12,345,342,378},snapshot->fxRouting==silveton::sampler::EffectRouting::Parallel?"Routing: Parallel":"Routing: MFX 1 into 2",green,snapshot->fxRouting!=silveton::sampler::EffectRouting::Parallel,true,[mutate]{mutate([](Combi& combi){combi.fxRouting=combi.fxRouting==silveton::sampler::EffectRouting::Parallel?silveton::sampler::EffectRouting::Fx1IntoFx2:silveton::sampler::EffectRouting::Parallel;});},12);
        const bool sourceAvailable=styleTarget?bool(host::arrangerHost().styleRead(trackEditPlayer_)):!activeNativeKeyboardSetPath_.empty();
        button(c,{354,345,695,378},"Use SET FX",orange,false,sourceAvailable,[this,styleTarget,player=trackEditPlayer_,selection]{
            if(styleTarget){
                if(!host::arrangerHost().restoreStyleSourceEffects(player,selection))showToast(host::arrangerHost().lastError(),5000);
                else {markPersistentStateChanged();refresh();}
                fxChoosing_=false;keyboardSourceFxPage_=0;dirty_=true;
            }else clearKeyboardFxOverride();
        },13);
        label(c,styleTarget?"Manual SILVETON FX · Save Style retains this rack.":"Manual SILVETON FX · Save the Keyboard Set to retain this rack.",14,392,11,dim,false,685);
        }
    }else{
        for(int column=0;column<4;++column){
            const int part=parts[static_cast<std::size_t>(column)];const auto& u=snapshot->part(part);const float x=12+column*174.0F;
            const auto& channel=players_[styleTarget?trackEditPlayer_:selectedPlayer_].tracks[part];
            const std::string name=styleTarget?(channel.originalSoundRouted&&!channel.originalSoundName.empty()?channel.originalSoundName:channel.soundName):
                (!u.name.empty()?u.name:(u.program?u.program->name:"Select Sound"));
            button(c,{x,45,x+166,73},partName(part),green,focused==part,true,[this,part,styleTarget]{(styleTarget?styleEditTrack_:keyboardEditPart_)=part;dirty_=true;},13);
            box(c,{x,77,x+166,104},panel,kBorder);label(c,name,x+83,96,12,white,false,154,Align::Center);
            hit({x,77,x+166,104},[this,part,styleTarget,player=trackEditPlayer_,selection]{
                if(styleTarget){if(host::arrangerHost().snapshot(player).styleSelectionSerial!=selection)return;
                    setPlayerFocus(player,false);styleEditTrack_=part;openTargetSound(0,part);
                }else {keyboardEditPart_=part;openTargetSound(part,-1);}
            });
            const auto partField=[&](int row,const std::string& title,const std::string& shown,float value,float low,float high,
                                     const std::function<void(UpperPart&,float)>& change,bool whole=false,bool logarithmic=false,bool enabled=true){
                field(cell(column,row),title,shown,value,low,high,[edit,part,change](float v){edit(part,[change,v](auto& target){change(target,v);});},whole,logarithmic,enabled);
            };
            if(page==KeyboardEditPage::Main&&styleTarget){
                const int player=trackEditPlayer_;
                const auto current=[player,selection]{const auto now=host::arrangerHost().snapshot(player);
                    return now.styleSelectionSerial==selection&&!now.styleSwitchPending;};
                button(c,{x,113,x+79,146},"Play",green,!channel.mute,true,[this,player,part,selection]{togglePartMute(player,part,selection);},13,true);
                button(c,{x+87,113,x+166,146},"Solo",green,partSolo(player,part),true,[this,current,player,part]{
                    if(current()){setPlayerFocus(player,false);solo(part);}},13,true);
                field(cell(column,1),"Volume Trim",fmtFixed(channel.volumeDb,1)+" dB",channel.volumeDb,-60,12,
                    [this,player,selection,part](float v){controlRequested(host::arrangerHost().setTrackVolume(player,part,v,selection));});
                field(cell(column,2),"Pan Trim",fmtFixed(channel.pan,2),channel.pan,-1,1,[this,current,player,part](float v){
                    if(current())controlRequested(host::arrangerHost().setTrackPan(player,part,v));});
                label(c,"Style CC7  "+rawValue(channel.sourceVolumeRaw),x+83,297,13,dim,false,158,Align::Center);
                label(c,"Expression  "+rawValue(channel.sourceExpressionRaw),x+83,323,13,dim,false,158,Align::Center);
                box(c,{x+12,355,x+154,363},key);
                if(channel.peak>0)box(c,{x+12,355,x+12+142*std::clamp(channel.peak,0.0F,1.0F),363},green);
            }else if(page==KeyboardEditPage::Main){
                button(c,{x,113,x+79,146},"Play",green,u.enabled&&!u.mute,part!=6||keyboardSplitEnabled_,[this,part]{togglePartMute(-1,part);},13,true);
                toggle({x+87,113,x+166,146},"Solo",partSolo(-1,part),[this,part]{listenPart(-1,part);},true);
                const int sourceVolume=u.sourceVolumeRaw<0?127:u.sourceVolumeRaw;
                const int sourcePan=u.sourcePanRaw<0?64:u.sourcePanRaw;
                partField(1,"Volume",std::to_string(sourceVolume),static_cast<float>(sourceVolume),0,127,[](auto& target,float v){target.sourceVolumeRaw=static_cast<int>(v);},true);
                const std::string sourcePanText=sourcePan==64?"C 00":std::string(sourcePan<64?"L ":"R ")+std::to_string(std::abs(sourcePan-64));
                partField(2,"Pan",sourcePanText,static_cast<float>(sourcePan),0,127,[](auto& target,float v){target.sourcePanRaw=static_cast<int>(v);},true);
                partField(3,"Volume Trim",fmtFixed(u.levelDb,1)+" dB",u.levelDb,-60,18,[](auto& target,float v){target.levelDb=v;});
                const std::string pan=u.pan==0?"C 00":std::string(u.pan<0?"L ":"R ")+std::to_string(static_cast<int>(std::round(std::abs(u.pan)*63)));
                partField(4,"Pan Trim",pan,u.pan,-1,1,[](auto& target,float v){target.pan=v;});
                const float peak=static_cast<std::size_t>(part)<upperMeters_.size()?std::max(upperMeters_[static_cast<std::size_t>(part)].first,upperMeters_[static_cast<std::size_t>(part)].second):0;
                box(c,{x+12,362,x+154,369},key);if(peak>0)box(c,{x+12,362,x+12+142*std::clamp(peak,0.0F,1.0F),369},green);
                label(c,part==6&&!keyboardSplitEnabled_?"Lower silent: SPLIT off":"Expression "+rawValue(u.sourceExpressionRaw),x+83,387,11,dim,false,162,Align::Center);
            }else if(page==KeyboardEditPage::Eq){
                toggle({x,113,x+112,145},"EQ On",u.eq.on,[edit,part]{edit(part,[](auto& target){target.eq.on=!target.eq.on;});});
                button(c,{x+120,113,x+166,145},"⚙",green,false,true,[this,part,styleTarget]{(styleTarget?styleEditTrack_:keyboardEditPart_)=part;openKeyboardEdit(KeyboardEditPage::EqAdvanced);},18);
                for(int row=0;row<3;++row){const int band=row==0?4:row==1?2:0;const float gain=u.eq.band[static_cast<std::size_t>(band)].gainDb;
                    partField(row+1,row==0?"HF":row==1?"MF":"LF",fmtFixed(gain,1)+" dB",gain,-18,18,[band](auto& target,float v){target.eq.band[static_cast<std::size_t>(band)].gainDb=v;target.eq.band[static_cast<std::size_t>(band)].on=true;target.eqLowDb=target.eq.band[0].gainDb;target.eqMidDb=target.eq.band[2].gainDb;target.eqHighDb=target.eq.band[4].gainDb;});
                }
                button(c,{x,316,x+166,348},"Reset EQ",green,false,true,[edit,part]{edit(part,[](auto& target){target.eq={};target.eqLowDb=target.eqMidDb=target.eqHighDb=0;});},12);
            }else if(page==KeyboardEditPage::FxSend){
                float sends[]{u.fxSend1,u.fxSend2,u.fxSend3,u.fxSend4};
                if(styleTarget&&snapshot->sourceEffects&&snapshot->sourceEffects->followMidiSends)
                    for(std::size_t send=0;send<3;++send)if(channel.sourceFxSendRaw[send]>=0)sends[send]=static_cast<float>(channel.sourceFxSendRaw[send])/127.0F;
                const bool originalKeyboard=snapshot->sourceEffects&&!styleTarget&&
                    !snapshot->sourceEffects->style&&!snapshot->sourceEffects->followMidiSends;
                for(int row=0;row<4;++row){
                    const int rawSend=static_cast<int>(std::lround(sends[row]*127.0F));
                    // The keyboard part owns these levels. Keep the immutable
                    // original rack while editing them; a native snapshot stores
                    // the edited levels separately from the retained SET bytes.
                    // Pa5X has three master sends; its source rack has no MFX4.
                    partField(row,"MFX "+std::to_string(row+1)+" Send",std::to_string(rawSend),
                        originalKeyboard?static_cast<float>(rawSend):sends[row],0,originalKeyboard?127.0F:1.0F,
                        [row,originalKeyboard](auto& target,float v){
                            if(originalKeyboard)v=std::round(v)/127.0F;
                            if(row==0)target.fxSend1=v;else if(row==1)target.fxSend2=v;
                            else if(row==2)target.fxSend3=v;else target.fxSend4=v;
                        },originalKeyboard,false,!snapshot->sourceEffects||(originalKeyboard&&row<3));
                }

            }else if(page==KeyboardEditPage::Tune){
                partField(0,"Transpose",signedNumber(u.transposeSemitones),u.transposeSemitones,-36,36,[](auto& target,float v){target.transposeSemitones=static_cast<std::int8_t>(v);},true);
                partField(1,"Detune",fmtFixed(u.tuneCents,1)+" cent",u.tuneCents,-64,63,[](auto& target,float v){target.tuneCents=v;});
                partField(2,"Pitch Bend",std::to_string(u.pitchBendRange)+" st",u.pitchBendRange,0,12,[](auto& target,float v){target.pitchBendRange=static_cast<std::int8_t>(v);},true);
                const auto bounds=partOctaveBounds(u);
                partField(3,"Octave",signedNumber(u.octave),u.octave,bounds.first,bounds.second,[](auto& target,float v){setPartOctave(target,int(v));},true);
                if(u.sourceCoarseTuneRaw>=0||u.sourceFineTuneRaw>=0){
                    const auto coarse=u.sourceCoarseTuneRaw>=0?signedNumber(u.sourceCoarseTuneRaw-64)+" st":std::string("—");
                    const auto fine=u.sourceFineTuneRaw>=0?fmtFixed(static_cast<float>(u.sourceFineTuneRaw-8192)*100.0F/8192.0F,2)+" cent":std::string("—");
                    label(c,"SET Tune: "+coarse,x+83,337,12,dim,false,162,Align::Center);
                    label(c,"SET Fine: "+fine,x+83,360,12,dim,false,162,Align::Center);
                    label(c,"Added to the trims above",x+83,383,11,dim,false,162,Align::Center);
                }
            }else if(page==KeyboardEditPage::Mode){
                const int voice=static_cast<int>(u.voiceMode);
                button(c,cell(column,0),voice==0?"Poly":voice==1?"Mono":"Legato",green,voice!=0,true,[edit,part]{edit(part,[](auto& target){target.voiceMode=static_cast<silveton::sampler::UpperVoiceMode>((static_cast<int>(target.voiceMode)+1)%3);});},16);
                if(styleTarget){
                    const int trigger=channel.soundSettings.trigger;
                    button(c,cell(column,1),trigger<0?"Gate: Sound":trigger==0?"Gate":"One Shot",green,trigger>=0,true,
                        [this,player=trackEditPlayer_,selection,part,trigger]{
                            controlRequested(host::arrangerHost().setTrackTrigger(player,selection,part,trigger==1?-1:trigger+1));
                        },14);
                }else partField(1,"MIDI Input Channel",std::to_string(u.midiChannel+1),u.midiChannel,0,15,[](auto& target,float v){target.midiChannel=static_cast<std::uint8_t>(v);},true);
            }else if(page==KeyboardEditPage::Range){
                partField(0,"Top Key",arrangerNoteName(u.keyHigh),u.keyHigh,u.keyLow,127,[](auto& target,float v){target.keyHigh=static_cast<std::uint8_t>(v);},true);
                partField(1,"Bottom Key",arrangerNoteName(u.keyLow),u.keyLow,0,u.keyHigh,[](auto& target,float v){target.keyLow=static_cast<std::uint8_t>(v);},true);
                partField(2,"Top Velocity",std::to_string(u.velocityHigh),u.velocityHigh,u.velocityLow,127,[](auto& target,float v){target.velocityHigh=static_cast<std::uint8_t>(v);},true);
                partField(3,"Bottom Velocity",std::to_string(u.velocityLow),u.velocityLow,1,u.velocityHigh,[](auto& target,float v){target.velocityLow=static_cast<std::uint8_t>(v);},true);
                toggle({x,316,x+166,349},"Common Part Range",!u.independentLayerRanges,[edit,part]{edit(part,[](auto& target){target.independentLayerRanges=!target.independentLayerRanges;});});
            }else if(page==KeyboardEditPage::Controllers){
                toggle(cell(column,0),"Damper",u.damperEnabled,[edit,part]{edit(part,[](auto& target){target.damperEnabled=!target.damperEnabled;});});
                toggle(cell(column,1),"Expression Level "+std::to_string(globalUi_?globalUi_->expressionCc:11),u.expressionEnabled,[edit,part]{edit(part,[](auto& target){target.expressionEnabled=!target.expressionEnabled;});});
                toggle(cell(column,2),"Breath Level "+std::to_string(globalUi_?globalUi_->breathCc:2),u.breathEnabled,[edit,part]{edit(part,[](auto& target){target.breathEnabled=!target.breathEnabled;});});
                label(c,"Pitch Bend: Mixer / FX",x+83,296,11,dim,false,162,Align::Center);
                label(c,"Bend / Tuning",x+83,314,11,dim,false,162,Align::Center);
                label(c,"CC switches affect level",x+83,346,10,dim,false,162,Align::Center);
                label(c,"Assigned modulation stays active",x+83,364,9,dim,false,162,Align::Center);
            }else if(page==KeyboardEditPage::Aftertouch){
                toggle(cell(column,0),"After Touch",u.aftertouchEnabled,[edit,part]{edit(part,[](auto& target){target.aftertouchEnabled=!target.aftertouchEnabled;});});
                label(c,"Aftertouch follows the Sound",x+83,206,12,dim,false,161,Align::Center);
                label(c,"and controller assignments",x+83,225,12,dim,false,161,Align::Center);
            }
        }
    }
    if(page==KeyboardEditPage::EqAdvanced){
        for(int i=0;i<4;++i){const int part=parts[i];const float x=12+i*174.0F;
            button(c,{x,387,x+166,417},partName(part),green,focused==part,true,[this,part,styleTarget]{(styleTarget?styleEditTrack_:keyboardEditPart_)=part;dirty_=true;},13);}
    }
    if(page==KeyboardEditPage::FxSend&&snapshot->sourceEffects){
        button(c,{12,344,342,378},"SILVETON FX",orange,false,true,manualFx,13);
        const bool originalKeyboard=!styleTarget&&!snapshot->sourceEffects->style&&
            !snapshot->sourceEffects->followMidiSends;
        if(originalKeyboard)button(c,{354,344,695,378},"Върни SET FX",green,false,
            !activeNativeKeyboardSetPath_.empty(),[this]{clearKeyboardFxOverride();},13);
        label(c,originalKeyboard?"SET MFX 1–3 · Нивата се редактират; назначенията се запазват":
            "SET sends · Switch to SILVETON FX to edit",14,396,12,dim,false,685);
    }
    const char* targets[]={"Keyboard","Player 1 · Style","Player 2 · Style"};
    for(int i=0;i<3;++i){const float x=12+i*232.0F;
        button(c,{x,421,x+222,461},targets[i],green,trackEditPlayer_==i-1,i==0||players_[i-1].loaded,[this,i]{
            trackEditPlayer_=i-1;rangeElement_=-1;choosingRangeElement_=false;
            if(!i&&(keyboardEditPage_==KeyboardEditPage::RangeWrap||keyboardEditPage_==KeyboardEditPage::Guitar))keyboardEditPage_=KeyboardEditPage::Mode;
            if(i>0)setPlayerFocus(i-1,false);fxChoosing_=false;dirty_=true;
        },15);
    }
    if(guitarPage)button(c,{715,421,798,461},"Save Style",orange,false,true,[this,player=trackEditPlayer_,selection]{
        const auto current=host::arrangerHost().snapshot(player);
        if(!current.loaded||current.styleSwitchPending||current.styleSelectionSerial!=selection){
            showToast("The Style changed. Open its Guitar page again before saving.",4500);return;
        }
        if(selectedPlayer_!=player)setPlayerFocus(player,false);
        openResourceSave(true);
    },12);
    label(c,"Home > Menu > "+std::string(section),13,476,11,dim,false,510);
    if(page==KeyboardEditPage::SoundEdit)label(c,"Drag up/down · Double-tap reset",792,476,11,dim,false,271,Align::Right);
    if(page==KeyboardEditPage::Guitar)label(c,"GTR: Guitar On · ACC: Guitar Off · Strings 1–6",792,476,10,dim,false,290,Align::Right);

}
