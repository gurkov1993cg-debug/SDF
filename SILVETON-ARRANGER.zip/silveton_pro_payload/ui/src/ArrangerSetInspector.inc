bool ArrangerView::leaveInstrumentEditor(){
    if(picker_==Picker::SetSoundInfo)host::arrangerHost().stopPcmPreview();
    if(picker_!=Picker::DrumKitEdit&&picker_!=Picker::DrumKeySelect&&picker_!=Picker::DrumSampleSelect)return false;
    if(picker_!=Picker::DrumKitEdit)(void)restoreNavigation();
    picker_=Picker::DrumKitEdit;
    drumGroupEdit_=-1;
    if(drumDraft_&&drumDraft_->dirty){drumExitPrompt_=true;dirty_=true;return true;}
    panelExit();return false;
}
void ArrangerView::classifySetSamples(const arranger::Pa5xSetBank& bank){
    sampleClasses_.clear();
    for(const auto& inventory:bank.sampleResourceInventories()){
        const auto* kmp=inventory.index;
        if(!kmp||!kmp->valid||!kmp->multisampleMappingDecoded)continue;
        const auto flag=[&](int row,unsigned category){
            if(row>=0&&static_cast<std::size_t>(row)<kmp->samples.size())sampleClasses_[kmp->samples[row].resourceId]|=category;
        };
        for(const auto& drum:kmp->drumSamples){
            if(drum.version8ReferencesPresent){for(auto idx:drum.version8References)flag(idx,1);}
            else{flag(drum.leftSample,1);flag(drum.rightSample,1);}
        }
        for(const auto& multi:kmp->multisamples)for(auto local:multi.zoneIndices){
            if(local>=multi.zoneCount)continue;
            const auto pos=static_cast<std::size_t>(multi.firstZone)+local;
            if(pos<kmp->keyZones.size())flag(kmp->keyZones[pos].sampleIndex,2);
        }
    }
    filterSamples(false,0);
}
void ArrangerView::filterSamples(bool drum,int filter){
    auto& rows=drum?drumSampleRows_:catalogSampleRows_;rows.clear();
    if(drum){drumSampleFilter_=filter;drumSamplePage_=0;}else{catalogSampleFilter_=filter;kstCatalogPage_=0;}
    const auto add=[&](std::size_t i,std::uint64_t id){
        const auto it=sampleClasses_.find(id);const unsigned flags=it==sampleClasses_.end()?0U:it->second;
        if(filter==0||(filter==1&&(flags&1U))||(filter==2&&(flags&2U))||(filter==3&&!flags))rows.push_back(i);
    };
    if(drum&&drumDraft_)for(std::size_t i=0;i<drumDraft_->samples.size();++i)add(i,arranger::paSampleUid(drumDraft_->samples[i]->sourceIdentity));
    if(!drum&&kstCatalog_)for(std::size_t i=0;i<kstCatalog_->samples.size();++i)add(i,kstCatalog_->samples[i].resourceId);
    dirty_=true;
}
void ArrangerView::drawSampleFilters(Canvas& c,bool drum,float y){
    const char* labels[]={"All samples","Drum Samples","Melodic","Unclassified"};
    for(int i=0;i<4;++i){const float x=12+i*163.0F;
        button(c,{x,y,x+157,y+33},labels[i],green,(drum?drumSampleFilter_:catalogSampleFilter_)==i,true,[this,drum,i]{filterSamples(drum,i);},14);}
    label(c,std::to_string((drum?drumSampleRows_:catalogSampleRows_).size()),780,y+23,15,white,true,102,Align::Right);
}

// Read-only browsing is independent of the active keyboard and Style selection.
void ArrangerView::filterSetSounds(int filter){
    soundFilter_=filter;soundListPage_=0;visibleSetSounds_.clear();
    if(kstCatalog_)for(std::size_t i=0;i<kstCatalog_->sounds.size();++i){
        const bool kit=kstCatalog_->sounds[i].drumKit;
        if(filter==0||(filter==1&&!kit)||(filter==2&&kit))visibleSetSounds_.push_back(i);
    }
    dirty_=true;
}
void ArrangerView::openInspector(Picker page){
    rememberNavigation();
    if(page==Picker::SetSounds){filterSetSounds(0);inspectedSound_.reset();inspectedZones_.clear();}
    picker_=page;dirty_=true;
}
void ArrangerView::inspectSetSound(std::size_t index){
    if(!kstCatalog_||index>=kstCatalog_->sounds.size())return;
    const auto& sound=kstCatalog_->sounds[index];
    soundSelection_=static_cast<int>(index);soundDetailPage_=0;inspectedZones_.clear();
    inspectedSound_=host::arrangerHost().preparedKeyboardSound(sound.msb,sound.lsb,sound.program,kstCatalog_->rootPath);
    bool chosen=false;int distance=128;
    if(inspectedSound_)for(const auto& layer:inspectedSound_->layers)if(layer.multisample){
        for(const auto& z:layer.multisample->zones)if(z.sample){
            const int lo=std::max(z.keyLow,layer.keyLow),hi=std::min(z.keyHigh,layer.keyHigh);
            const int vl=std::max(z.velocityLow,layer.velocityLow),vh=std::min(z.velocityHigh,layer.velocityHigh);
            if(lo>hi||vl>vh||!layer.enabled)continue;
            const int target=sound.drumKit?36:60,keyNumber=std::clamp(target,lo,hi);
            if(!chosen||std::abs(keyNumber-target)<distance){
                chosen=true;distance=std::abs(keyNumber-target);inspectorAuditionKey_=keyNumber;
                inspectorAuditionVelocity_=std::clamp(96,vl,vh);
            }
            const auto range=arrangerNoteName(lo)+(lo!=hi?"–"+arrangerNoteName(hi):"");
            inspectedZones_.push_back({layer.multisample->name+" / "+z.sample->name,
                range+"   Vel "+std::to_string(vl)+"–"+std::to_string(vh)});
        }
    }
    if(picker_==Picker::SetSounds)openInspector(Picker::SetSoundInfo);
}
void ArrangerView::inspectorPager(Canvas& c,int& page,int total,int perPage){
    const int pages=std::max(1,(total+perPage-1)/perPage);page=std::clamp(page,0,pages-1);
    auto* selected=&page; // Callers supply persistent view members.
    auto step=[this,selected,pages](int delta){*selected=std::clamp(*selected+delta,0,pages-1);dirty_=true;};
    button(c,{12,432,121,473},"−10",blue,false,page>0,[step]{step(-10);},17);
    button(c,{130,432,239,473},"‹ Prev",blue,false,page>0,[step]{step(-1);},17);
    label(c,std::to_string(page+1)+" / "+std::to_string(pages),400,460,17,white,true,290,Align::Center);
    button(c,{561,432,670,473},"Next ›",blue,false,page+1<pages,[step]{step(1);},17);
    button(c,{679,432,788,473},"+10",blue,false,page+1<pages,[step]{step(10);},17);
}
void ArrangerView::drawSetInspector(Canvas& c){
    box(c,{0,0,800,480},bg);
    button(c,{8,5,99,41},"‹ Back",blue,false,true,[this]{panelExit();},16);
    if(picker_==Picker::SetInfo){
        label(c,"SAMPLE INFO",115,32,22,blue,true,665);
        if(!kstReport_)return;
        const auto& r=*kstReport_;const auto& s=sampleSummary_;
        label(c,r.rootPath,17,70,16,dim,false,765);
        box(c,{12,85,788,170},panel,kBorder);
        label(c,"Samples ready for playback",28,113,17,white,true,730);
        label(c,s.preparationKnown?std::to_string(s.ready)+" / "+std::to_string(s.identified)+" identified":"Preparation count unavailable",
              28,151,29,s.preparationKnown&&s.identified>0&&s.ready==s.identified&&!s.uncheckedFiles&&!s.unlinked&&!s.inventoryIncomplete?green:orange,true,736);
        const auto mb=[](std::uint64_t bytes){return fmtFixed(static_cast<double>(bytes)/1000000.0,2)+" MB";};
        label(c,"SET files on disk",20,205,16,dim);label(c,mb(r.totalBytes),375,205,18,white,true,190,Align::Right);
        label(c,"PCM on disk",409,205,16,dim);label(c,mb(s.pcmBytes),779,205,18,white,true,180,Align::Right);
        label(c,"PCM files found",20,246,16,dim);label(c,std::to_string(kstPcmFiles_.size()),375,246,19,white,true,130,Align::Right);
        label(c,"Files without full index/check",409,246,15,dim);label(c,std::to_string(s.uncheckedFiles),779,246,19,s.uncheckedFiles?orange:white,true,64,Align::Right);
        label(c,"Failed samples",20,287,16,dim);label(c,s.preparationKnown?std::to_string(s.failed):"?",375,287,19,s.failed?orange:white,true,115,Align::Right);
        label(c,"PCM objects without KMP link",409,287,15,dim);label(c,s.preparationKnown?std::to_string(s.unlinked):"?",779,287,19,s.unlinked?orange:white,true,64,Align::Right);
        label(c,"KMP sample IDs missing from indexed PCM",20,328,16,dim);label(c,std::to_string(s.missing),779,328,19,s.missing?orange:white,true,110,Align::Right);
        label(c,"Known total counts distinct IDs in readable KMP and PCM indexes.",20,366,15,dim,false,758);
        label(c,s.inventoryIncomplete?"Incomplete folder or KMP index. See load messages.":"File sizes describe storage. Ready samples can stream from disk.",20,389,15,s.inventoryIncomplete?orange:dim,false,758);
        const auto report=[this](int tab){kstDetail_.clear();kstReportTab_=tab;kstReportPage_=0;openInspector(Picker::KstReport);};
        button(c,{12,421,255,471},"PCM file details",blue,false,true,[report]{report(4);},16);
        button(c,{265,421,505,471},"Load messages",orange,false,true,[report]{report(3);},16);
        button(c,{515,421,788,471},"Browse samples",green,false,kstCatalog_&&kstCatalog_->rootPath==r.rootPath,[this]{openKstCatalog(3);},16);
        return;
    }
    if(!kstCatalog_)return;
    if(picker_==Picker::SetSounds){
        label(c,"SET SOUNDS",116,32,22,green,true,205);
        label(c,kstCatalog_->name,783,31,16,dim,false,450,Align::Right);
        const char* names[]={"All","Sounds","Drum Kits"};
        for(int i=0;i<3;++i){const float x=12+i*150.0F;
            button(c,{x,51,x+141,90},names[i],green,soundFilter_==i,true,[this,i]{filterSetSounds(i);},16);}
        label(c,std::to_string(visibleSetSounds_.size())+" entries",782,78,17,white,true,270,Align::Right);
        inspectorPager(c,soundListPage_,static_cast<int>(visibleSetSounds_.size()),7);
        for(int row=0;row<7;++row){
            const auto at=static_cast<std::size_t>(soundListPage_*7+row);if(at>=visibleSetSounds_.size())break;
            const auto id=visibleSetSounds_[at];if(id>=kstCatalog_->sounds.size())continue;
            const auto& s=kstCatalog_->sounds[id];const float y=99.0F+row*46.0F;
            box(c,{12,y,788,y+43},panel,kBorder);
            label(c,s.drumKit?"KIT":"SOUND",23,y+27,12,s.drumKit?orange:green,true,67);
            label(c,s.name,97,y+27,17,white,true,401);
            label(c,files::nameOf(s.relativePath)+"   "+originalAddress(s.msb,s.lsb,s.program),776,y+27,13,dim,false,273,Align::Right);
            hit({12,y,788,y+43},[this,id]{inspectSetSound(id);});
        }
        if(visibleSetSounds_.empty())label(c,"No matching PCG entries",400,250,20,dim,false,750,Align::Center);
        return;
    }
    if(soundSelection_<0||static_cast<std::size_t>(soundSelection_)>=kstCatalog_->sounds.size())return;
    const auto& s=kstCatalog_->sounds[static_cast<std::size_t>(soundSelection_)];
    label(c,s.name,117,32,22,green,true,670);
    label(c,(s.drumKit?"Drum Kit    ":"Sound    ")+originalAddress(s.msb,s.lsb,s.program)+"    "+s.relativePath,15,70,16,dim,false,769);
    label(c,(s.drumKit?std::string("User Drum Kit"):std::string("PCG oscillators ")+std::to_string(s.oscillatorCount))+"    Prepared sample zones "+std::to_string(inspectedZones_.size()),15,103,16,white,true,768);
    const bool playable=inspectedSound_&&!inspectedZones_.empty();
    button(c,{12,118,192,160},"Audition",green,false,playable,[this]{if(!host::arrangerHost().auditionSetSound(inspectedSound_,inspectorAuditionKey_,inspectorAuditionVelocity_))showToast("Preview could not start",4000);},16);
    button(c,{201,118,348,160},"Stop",orange,false,playable,[]{host::arrangerHost().stopPcmPreview();},16);
    if(s.drumKit)button(c,{485,118,787,160},"Drum Kit Edit",orange,false,playable,[this]{
        const auto& k=kstCatalog_->sounds[static_cast<std::size_t>(soundSelection_)];
        auto draft=std::make_shared<host::DrumKitDraft>();
        if(!host::arrangerHost().openDrumKit(kstCatalog_->rootPath,k.msb,k.lsb,k.program,*draft)){showToast(host::arrangerHost().lastError(),5500);return;}
        host::arrangerHost().stopPcmPreview();drumDraft_=std::move(draft);drumKey_=inspectorAuditionKey_;drumZone_=drumTab_=0;drumGroupEdit_=-1;drumExitPrompt_=false;drumMidiLearn_=false;openInspector(Picker::DrumKitEdit);
    },17);
    if(!s.drumKit)button(c,{358,118,787,160},"Sound · записани настройки",green,false,bool(inspectedSound_),
        [this,program=inspectedSound_]{openOriginalSoundSettings(program);},16);
    inspectorPager(c,soundDetailPage_,static_cast<int>(inspectedZones_.size()),6);
    if(!playable){label(c,"No prepared User sample zones",18,218,20,orange,true,765);
        const auto message=wrappedKstText(s.blocker.empty()?"See Sample Info and load messages for missing resources.":s.blocker,755,16);
        for(std::size_t i=0;i<std::min<std::size_t>(message.size(),5);++i)label(c,message[i],18,256+24*i,16,dim,false,761);
    }
    for(int row=0;row<6;++row){const auto i=static_cast<std::size_t>(soundDetailPage_*6+row);if(i>=inspectedZones_.size())break;
        const auto& item=inspectedZones_[i];const float y=172+row*41.0F;box(c,{12,y,788,y+38},panel,kBorder);
        label(c,item.first,22,y+25,15,white,false,546);label(c,item.second,777,y+25,14,green,false,200,Align::Right);}
}

void ArrangerView::writeDrumDraft(){
    if(!drumDraft_||!drumDraft_->dirty)return;
    const auto before=drumDraft_->current;
    auto& host=host::arrangerHost();
    if(!host.writeDrumKit(*drumDraft_)){showToast(host.lastError(),6000);return;}
    auto warning=host.lastError();
    const auto update=[this,&before](std::shared_ptr<const sampler::Combi> source)->std::shared_ptr<const sampler::Combi>{
        if(!source)return {};
        auto copy=std::make_shared<sampler::Combi>(*source);bool changed=false;
        for(int part=0;part<sampler::kPartCount;++part)for(int n=0;n<=sampler::kUpperLayers;++n){
            auto& assigned=sampler::soundSource(copy->part(part),n);
            if(assigned.program==before){assigned.program=drumDraft_->current;changed=true;}
        }
        return changed?copy:nullptr;
    };
    if(auto edited=update(ctrl_.engine.nativeKeyboardCombi()))if(!ctrl_.engine.nativeApplyKeyboardCombi(*edited,true))
        warning="Kit saved. Reselect the keyboard Sound to refresh it";
    for(auto& s:keyboardWorkingSets_)if(auto edited=update(s.combi))s.combi=std::move(edited);
    for(auto& player:playerKeyboardBuffers_)for(auto& s:player.working)if(auto edited=update(s.combi))s.combi=std::move(edited);
    // Refresh the underlying inspector without adding an extra navigation frame.
    inspectSetSound(static_cast<std::size_t>(soundSelection_));
    markPersistentStateChanged();
    showToast(warning.empty()?"Drum Kit written to SILVETON":warning,5500);dirty_=true;
}
void ArrangerView::drawDrumSampleSelect(Canvas& c){
    if(!drumDraft_)return;
    box(c,{0,0,800,480},bg);
    button(c,{8,5,99,41},"‹ Back",orange,false,true,[this]{panelExit();},16);
    if(picker_==Picker::DrumKeySelect){
        label(c,"DRUM KIT KEYS",116,32,22,orange,true,650);
        std::vector<int> keys;for(int k=0;k<128;++k)if(!drumDraft_->keys[k].empty())keys.push_back(k);
        label(c,std::to_string(keys.size())+" assigned keys",16,70,16,dim,false,760);
        inspectorPager(c,drumKeyPage_,static_cast<int>(keys.size()),8);
        for(int row=0;row<8;++row){
            const auto ix=static_cast<std::size_t>(drumKeyPage_*8+row);if(ix>=keys.size())break;
            const int k=keys[ix];const auto& items=drumDraft_->keys[k];const float y=83+row*42.0F;
            box(c,{12,y,788,y+39},panel,k==drumKey_?orange:kBorder);
            label(c,arrangerNoteName(k)+"  ("+std::to_string(k)+")",22,y+26,15,orange,true,108);
            label(c,items.front().zone.sample->name,139,y+26,16,white,true,452);
            label(c,std::to_string(items.size())+" layers",775,y+26,15,dim,false,155,Align::Right);
            hit({12,y,788,y+39},[this,k]{drumKey_=k;drumZone_=0;panelExit();});
        }
        return;
    }
    label(c,"SELECT DRUM SAMPLE",116,32,22,orange,true,655);
    drawSampleFilters(c,true,47);
    inspectorPager(c,drumSamplePage_,static_cast<int>(drumSampleRows_.size()),8);
    if(drumSampleRows_.empty())label(c,"No prepared samples in this category",400,244,18,dim,false,755,Align::Center);
    const auto& zones=drumDraft_->keys[drumKey_];
    const auto current=zones.empty()?sampler::SamplePtr{}:zones[drumZone_].zone.sample;
    for(int row=0;row<8;++row){
        const auto i=static_cast<std::size_t>(drumSamplePage_*8+row);if(i>=drumSampleRows_.size())break;
        const auto sample=drumDraft_->samples[drumSampleRows_[i]];const float y=83+row*42.0F;
        box(c,{12,y,788,y+39},panel,current==sample?orange:kBorder);
        label(c,std::to_string(i+1),24,y+26,14,dim,true,61);
        label(c,sample->name,94,y+26,16,white,true,430);
        label(c,std::to_string(sample->sampleRate)+" Hz   "+std::to_string(sample->frameCount())+" frames",773,y+26,13,dim,false,245,Align::Right);
        hit({12,y,788,y+39},[this,sample]{
            auto& items=drumDraft_->keys[drumKey_];
            if(items.empty()){
                sampler::SampleZone z;z.sample=sample;z.oneShot=true;z.nonTranspose=true;
                z.keyLow=z.keyHigh=z.rootKey=static_cast<std::uint8_t>(drumKey_);
                items.push_back({0,std::move(z)});drumZone_=0;drumDraft_->markEdited();
            }else if(items[drumZone_].zone.sample!=sample){
                items[drumZone_].zone.sample=sample;drumDraft_->markEdited();
            }
            panelExit();dirty_=true;
        });
    }
}
void ArrangerView::drawDrumEditor(Canvas& c){
    if(!drumDraft_)return;
    const auto draft=drumDraft_;
    auto& arranger=host::arrangerHost();
    if(arranger.drumKitMidiAuditionEnabled()&&draft->previewNeedsRefresh&&!arranger.auditionDrumKit(*draft,-1,0)){
        arranger.setDrumKitMidiAudition(*draft,false);showToast("MIDI preview could not refresh",4500);
    }
    auto& zones=draft->keys[drumKey_];const bool assigned=!zones.empty();
    drumZone_=assigned?std::clamp(drumZone_,0,static_cast<int>(zones.size())-1):0;
    const auto* selected=assigned?&zones[drumZone_].zone:nullptr;
    box(c,{0,0,800,480},bg);
    if(drumExitPrompt_){
        label(c,"Write changes to "+draft->original->name+"?",400,180,22,white,true,750,Align::Center);
        button(c,{15,235,248,287},"Keep editing",blue,false,true,[this]{drumExitPrompt_=false;dirty_=true;},17);
        button(c,{260,235,526,287},"Discard changes",orange,false,true,[this]{drumDraft_->dirty=false;drumExitPrompt_=false;panelExit();},17);
        button(c,{538,235,785,287},"Write",green,true,true,[this]{writeDrumDraft();if(!drumDraft_->dirty){drumExitPrompt_=false;panelExit();}},17);
        return;
    }
    button(c,{7,5,93,40},"‹ Back",orange,false,true,[this]{panelExit();},15);
    label(c,"DRUM KIT EDIT",108,31,20,orange,true,185);
    label(c,draft->original->name+(draft->dirty?"  *":""),300,31,18,white,true,485);
    if(drumGroupEdit_>=0){drawDrumGroupPicker(c);return;}
    const auto changeKey=[this](int delta){drumKey_=std::clamp(drumKey_+delta,0,127);drumZone_=0;dirty_=true;};
    button(c,{12,51,92,92},"−12",blue,false,drumKey_>0,[changeKey]{changeKey(-12);},16);
    button(c,{99,51,173,92},"−1",blue,false,drumKey_>0,[changeKey]{changeKey(-1);},16);
    button(c,{180,51,430,92},"Key "+arrangerNoteName(drumKey_)+"  ("+std::to_string(drumKey_)+")  ▾",orange,false,true,[this]{
        int prior=0;for(int k=0;k<drumKey_;++k)if(!drumDraft_->keys[k].empty())++prior;
        drumKeyPage_=prior/8;openInspector(Picker::DrumKeySelect);
    },17);
    button(c,{437,51,511,92},"+1",blue,false,drumKey_<127,[changeKey]{changeKey(1);},16);
    button(c,{518,51,598,92},"+12",blue,false,drumKey_<127,[changeKey]{changeKey(12);},16);
    button(c,{607,51,787,92},"Select via MIDI",green,drumMidiLearn_,true,[this]{(void)host::arrangerHost().takeEditorNote();drumMidiLearn_=!drumMidiLearn_;dirty_=true;},14);
    const auto pickSample=[this]{
        filterSamples(true,1);
        const auto& zones=drumDraft_->keys[drumKey_];
        if(!zones.empty()){
            const auto selected=zones[drumZone_].zone.sample;
            for(std::size_t i=0;i<drumSampleRows_.size();++i)if(drumDraft_->samples[drumSampleRows_[i]]==selected){drumSamplePage_=static_cast<int>(i/8);break;}
        }
        openInspector(Picker::DrumSampleSelect);
    };
    button(c,{12,103,137,142},"Key / Mixer",orange,drumTab_==0,true,[this]{drumTab_=0;dirty_=true;},14);
    button(c,{145,103,298,142},"Velocity Layer",orange,drumTab_==1,true,[this]{drumTab_=1;dirty_=true;},14);
    button(c,{306,103,398,142},"Groups",orange,drumTab_==2,true,[this]{drumTab_=2;dirty_=true;},15);
    if(drumTab_==2){
        const bool midi=arranger.drumKitMidiAuditionEnabled();
        button(c,{416,103,787,142},midi?"MIDI Audition: On":"MIDI Audition: Off",green,midi,true,[this,draft]{
            auto& host=host::arrangerHost();
            if(!host.setDrumKitMidiAudition(*draft,!host.drumKitMidiAuditionEnabled()))showToast("MIDI preview could not start",4500);
            dirty_=true;
        },16);
    }else{
        button(c,{416,103,493,142},"‹",blue,false,drumZone_>0,[this]{--drumZone_;dirty_=true;},17);
        label(c,"Layer "+std::to_string(assigned?drumZone_+1:0)+" / "+std::to_string(zones.size()),600,131,16,white,true,193,Align::Center);
        button(c,{705,103,787,142},"›",blue,false,drumZone_+1<static_cast<int>(zones.size()),[this]{++drumZone_;dirty_=true;},17);
    }
    if(drumTab_==2){
        label(c,selected?selected->sample->name:"No sample assigned to this key",17,171,17,selected?white:dim,true,361);
        const auto sourceGroups=draft->original->drumKeyGroups;
        button(c,{389,149,587,182},"Use SET groups",orange,false,sourceGroups!=nullptr,[this,draft,sourceGroups]{
            if(drumDraft_!=draft||!sourceGroups)return;
            bool changed=false;
            for(std::size_t k=0;k<draft->drumKeyGroups.size();++k){
                auto& number=draft->drumKeyGroups[k].exclusiveGroup;
                const auto original=(*sourceGroups)[k].exclusiveGroup;
                if(number!=original){number=original;changed=true;}
            }
            if(changed)draft->markEdited();
            showToast(changed?"Group numbers restored from SET for all keys. Write Drum Kit to save."
                             :"Group numbers already match the SET.",5500);dirty_=true;
        },14);
        button(c,{595,149,787,182},"Select sample",green,false,!draft->samples.empty(),pickSample,14);
        drawDrumGroups(c);
    }else if(!assigned){
        label(c,"No User sample assigned to this key",400,225,20,dim,false,740,Align::Center);
        button(c,{203,250,597,302},"Assign sample",green,false,!draft->samples.empty(),pickSample,17);
    }else{
        label(c,selected->sample->name,17,171,18,white,true,551);
        button(c,{575,149,787,182},"Select sample",green,false,!draft->samples.empty(),pickSample,14);
        auto pair=[this,&c](float x,float y,const std::string& name,const std::string& value,bool down,bool up,std::function<void(int)> adjust){
            label(c,name,x+4,y+17,14,dim,false,361);
            button(c,{x,y+23,x+75,y+62},"−",blue,false,down,[this,adjust]{adjust(-1);drumDraft_->markEdited();dirty_=true;},19);
            label(c,value,x+180,y+49,17,white,true,202,Align::Center);
            button(c,{x+288,y+23,x+366,y+62},"+",blue,false,up,[this,adjust]{adjust(1);drumDraft_->markEdited();dirty_=true;},19);
        };
        const auto idx=drumZone_;const auto keyNum=drumKey_;
        const auto change=[draft,keyNum,idx](auto fn){fn(draft->keys[keyNum][idx].zone);};
        if(drumTab_==0){
            const auto gain=std::minmax_element(zones.begin(),zones.end(),[](const auto& a,const auto& b){return a.zone.gainDb<b.zone.gainDb;});
            const auto pan=std::minmax_element(zones.begin(),zones.end(),[](const auto& a,const auto& b){return a.zone.pan<b.zone.pan;});
            const auto range=[](float a,float b,const std::string& unit){return fmtFixed(a,1)+(std::abs(a-b)>0.01F?" … "+fmtFixed(b,1):"")+unit;};
            pair(16,195,"Key level · all layers",range(gain.first->zone.gainDb,gain.second->zone.gainDb," dB"),
                 gain.second->zone.gainDb>-96,gain.first->zone.gainDb<24,[draft,keyNum](int d){for(auto& z:draft->keys[keyNum])z.zone.gainDb=std::clamp(z.zone.gainDb+d,-96.0F,24.0F);});
            pair(416,195,"Key pan · all layers",range(pan.first->zone.pan*100,pan.second->zone.pan*100,"%"),
                 pan.second->zone.pan>-1,pan.first->zone.pan<1,[draft,keyNum](int d){for(auto& z:draft->keys[keyNum])z.zone.pan=std::clamp(z.zone.pan+d*0.05F,-1.0F,1.0F);});
            label(c,"Velocity layers on this key",19,298,16,dim,true,753);
            std::string bands;for(const auto& z:zones){if(!bands.empty())bands+="   /   ";bands+=std::to_string(z.zone.velocityLow)+"–"+std::to_string(z.zone.velocityHigh);}
            const auto lines=wrappedKstText(bands,753,16);
            for(std::size_t i=0;i<std::min<std::size_t>(3,lines.size());++i)label(c,lines[i],19,329+i*23,16,white,false,756);
        }else{
            pair(16,186,"Layer level",fmtFixed(selected->gainDb,1)+" dB",selected->gainDb>-96,selected->gainDb<24,
                [change](int d){change([d](auto& z){z.gainDb=std::clamp(z.gainDb+d,-96.0F,24.0F);});});
            pair(416,186,"Layer tuning",signedNumber(selected->transposeSemitones)+" st",selected->transposeSemitones>-64,selected->transposeSemitones<63,
                [change](int d){change([d](auto& z){z.transposeSemitones+=d;});});
            const auto lo=selected->velocityLow,hi=selected->velocityHigh;
            const int minLo=idx==0?1:zones[idx-1].zone.velocityLow+1;
            const int maxHi=idx+1==static_cast<int>(zones.size())?127:zones[idx+1].zone.velocityHigh-1;
            pair(16,255,"Velocity bottom",std::to_string(lo),idx>0&&lo>minLo,idx>0&&lo<hi,[draft,keyNum,idx](int d){
                auto& k=draft->keys[keyNum];auto& z=k[idx].zone;
                if(idx>0){auto& prev=k[idx-1].zone;if(prev.velocityHigh+1==z.velocityLow)prev.velocityHigh+=d;}
                z.velocityLow+=d;});
            pair(416,255,"Velocity top",std::to_string(hi),idx+1<static_cast<int>(zones.size())&&hi>lo,idx+1<static_cast<int>(zones.size())&&hi<maxHi,[draft,keyNum,idx](int d){
                auto& k=draft->keys[keyNum];auto& z=k[idx].zone;
                if(idx+1<static_cast<int>(k.size())){auto& next=k[idx+1].zone;if(z.velocityHigh+1==next.velocityLow)next.velocityLow+=d;}
                z.velocityHigh+=d;});
            button(c,{13,340,187,385},"Reverse",orange,selected->reverse,true,[this,change]{change([](auto& z){z.reverse=!z.reverse;});drumDraft_->markEdited();dirty_=true;},15);
            button(c,{196,340,366,385},"One Shot",orange,selected->oneShot,true,[this,change]{change([](auto& z){z.oneShot=!z.oneShot;});drumDraft_->markEdited();dirty_=true;},15);
            button(c,{375,340,572,385},"Split layer",green,false,lo<hi&&zones.size()<16,[this,draft,keyNum,idx]{
                auto& k=draft->keys[keyNum];auto second=k[idx];unsigned lane=0;
                while(std::any_of(k.begin(),k.end(),[lane](const auto& item){return item.layer==lane;}))++lane;
                second.layer=lane;const int mid=(second.zone.velocityLow+second.zone.velocityHigh)/2;
                k[idx].zone.velocityHigh=mid;second.zone.velocityLow=mid+1;
                k.insert(k.begin()+idx+1,std::move(second));drumZone_=idx+1;draft->markEdited();dirty_=true;},15);
            button(c,{581,340,787,385},"Remove layer",orange,false,true,[this,draft,keyNum,idx]{
                auto& k=draft->keys[keyNum];const auto lower=k[idx].zone.velocityLow,upper=k[idx].zone.velocityHigh;
                if(idx+1<static_cast<int>(k.size())&&k[idx+1].zone.velocityLow==upper+1)k[idx+1].zone.velocityLow=lower;
                else if(idx>0&&k[idx-1].zone.velocityHigh+1==lower)k[idx-1].zone.velocityHigh=upper;
                k.erase(k.begin()+idx);
                drumZone_=std::max(0,std::min(idx,static_cast<int>(k.size())-1));draft->markEdited();dirty_=true;},15);
        }
    }
    button(c,{12,419,272,472},"Audition key",green,false,assigned,[this,draft]{
        const auto& z=draft->keys[drumKey_][drumZone_].zone;const int velocity=(z.velocityLow+z.velocityHigh)/2;
        if(!host::arrangerHost().auditionDrumKit(*draft,drumKey_,velocity))showToast("Preview could not start",4500);
    },16);
    button(c,{282,419,481,472},arranger.drumKitMidiAuditionEnabled()?"Stop / MIDI Off":"Stop",orange,false,true,[this]{host::arrangerHost().stopPcmPreview();dirty_=true;},16);
    button(c,{491,419,787,472},"Write Drum Kit",green,draft->dirty,draft->dirty,[this]{writeDrumDraft();},17);
}

void ArrangerView::drawDrumGroups(Canvas& c){
    if(!drumDraft_)return;
    const auto draft=drumDraft_;const int key=drumKey_;
    const auto group=draft->drumKeyGroups[key];
    const auto changed=[this,draft]{draft->markEdited();dirty_=true;};
    const auto enter=[this,key,group](int field){
        drumGroupEdit_=field;drumGroupEditKey_=key;drumGroupMemberPage_=0;
        drumGroupNumber_=std::to_string(field==0?int(group.exclusiveGroup):int(std::lround(group.chokeFadeOutMs)));
        dirty_=true;
    };
    const auto pair=[this,&c](float y,const std::string& title,const std::string& value,bool down,bool up,
                             std::function<void(int)> adjust,std::function<void()> exact){
        label(c,title,20,y+16,15,dim,true,363);
        button(c,{16,y+23,84,y+63},"−",blue,false,down,[adjust]{adjust(-1);},22);
        button(c,{91,y+23,307,y+63},value,orange,false,true,std::move(exact),19);
        button(c,{314,y+23,382,y+63},"+",blue,false,up,[adjust]{adjust(1);},22);
    };
    pair(190,"Exclusive Group · all layers",group.exclusiveGroup?std::to_string(group.exclusiveGroup):"None",
         group.exclusiveGroup>0,group.exclusiveGroup<127,
         [draft,key,changed](int delta){auto& g=draft->drumKeyGroups[key];g.exclusiveGroup=static_cast<std::uint8_t>(std::clamp(int(g.exclusiveGroup)+delta,0,127));changed();},
         [enter]{enter(0);});
    pair(264,"Choke Fade Out Time",fmtFixed(group.chokeFadeOutMs,group.chokeFadeOutMs==std::floor(group.chokeFadeOutMs)?0:1)+" ms",
         group.chokeFadeOutMs>0,group.chokeFadeOutMs<10000,
         [draft,key,changed](int delta){auto& g=draft->drumKeyGroups[key];g.chokeFadeOutMs=std::clamp(g.chokeFadeOutMs+delta,0.0F,10000.0F);changed();},
         [enter]{enter(1);});
    const auto toggle=[this,&c](const RectF& rect,const std::string& title,const std::string& detail,bool value,std::function<void()> action){
        box(c,rect,value?Color::rgb(22,57,37):panel,value?green:kBorder,5);
        label(c,title,rect.left+13,rect.top+24,17,value?green:white,true,rect.width()-26);
        label(c,detail,rect.left+13,rect.top+50,15,dim,false,rect.width()-26);
        hit(rect,std::move(action));
    };
    toggle({416,190,787,253},"Single Trigger: "+std::string(group.singleTrigger?"On":"Off"),
           group.singleTrigger?"Repeated key stops its previous hit":"Repeated key can overlap",group.singleTrigger,
           [draft,key,changed]{auto& g=draft->drumKeyGroups[key];g.singleTrigger=!g.singleTrigger;changed();});
    toggle({416,264,787,327},"Subgroup Choke Off: "+std::string(group.subgroupChokeOff?"On":"Off"),
           group.subgroupChokeOff?"Keep previous hits in this group":"Apply choking within this group",group.subgroupChokeOff,
           [draft,key,changed]{auto& g=draft->drumKeyGroups[key];g.subgroupChokeOff=!g.subgroupChokeOff;changed();});
    if(group.exclusiveGroup){
        std::string members;int count=0;
        for(int k=0;k<128;++k)if(draft->drumKeyGroups[k].exclusiveGroup==group.exclusiveGroup){
            if(count<7){if(!members.empty())members+="   ";members+=arrangerNoteName(k)+" ("+std::to_string(k)+")";}
            ++count;
        }
        label(c,"Group "+std::to_string(group.exclusiveGroup)+" members",19,352,15,orange,true,595);
        const auto lines=wrappedKstText(members,596,14);
        for(std::size_t i=0;i<std::min<std::size_t>(lines.size(),2);++i)label(c,lines[i],19,375+i*19,14,white,false,596);
        button(c,{630,340,787,395},std::to_string(count)+" keys ›",orange,false,true,[enter]{enter(2);},17);
    }else{
        label(c,"None: this key does not join an exclusive group.",19,354,16,white,false,765);
        label(c,"Assign the same number to keys that should stop each other.",19,381,15,dim,false,765);
    }
    const auto sourceGroups=draft->original->drumKeyGroups;
    std::string sourceStatus="Original SET group numbers are unavailable for this kit.";
    if(sourceGroups){
        std::array<bool,128> seen{};int groupCount=0,keyCount=0,changedKeys=0;
        for(std::size_t k=0;k<sourceGroups->size();++k){
            const auto number=(*sourceGroups)[k].exclusiveGroup;
            if(number){++keyCount;if(!seen[number]){seen[number]=true;++groupCount;}}
            if(number!=draft->drumKeyGroups[k].exclusiveGroup)++changedKeys;
        }
        sourceStatus="SET: "+std::to_string(groupCount)+" groups · "+std::to_string(keyCount)+" keys · ";
        sourceStatus+=changedKeys?std::to_string(changedKeys)+" group numbers changed. Reset applies to all keys.":"group numbers match the SET.";
    }
    label(c,sourceStatus,19,408,13,dim,false,765);
}

void ArrangerView::drawDrumGroupPicker(Canvas& c){
    if(!drumDraft_||drumGroupEdit_<0)return;
    const auto draft=drumDraft_;const int key=std::clamp(drumGroupEditKey_,0,127);
    const auto group=draft->drumKeyGroups[key];
    label(c,"Key "+arrangerNoteName(key)+"  ("+std::to_string(key)+") · all velocity layers",17,74,18,orange,true,765);
    if(drumGroupEdit_==2){
        label(c,"EXCLUSIVE GROUP "+std::to_string(group.exclusiveGroup),17,108,20,white,true,765);
        std::vector<int> members;
        for(int k=0;k<128;++k)if(group.exclusiveGroup&&draft->drumKeyGroups[k].exclusiveGroup==group.exclusiveGroup)members.push_back(k);
        const int pages=std::max(1,(static_cast<int>(members.size())+6)/7);
        drumGroupMemberPage_=std::clamp(drumGroupMemberPage_,0,pages-1);
        for(int row=0;row<7;++row){
            const int index=drumGroupMemberPage_*7+row;if(index>=static_cast<int>(members.size()))break;
            const int member=members[index];const auto& zones=draft->keys[member];const float y=119+row*40.0F;
            const RectF rect{12,y,788,y+36};box(c,rect,panel,member==key?orange:kBorder,4);
            label(c,arrangerNoteName(member)+"  ("+std::to_string(member)+")",24,y+25,15,orange,true,126);
            label(c,zones.empty()?"No sample assigned":zones.front().zone.sample->name,161,y+25,16,white,true,588);
            label(c,"›",775,y+25,18,orange,true,20,Align::Right);
            hit(rect,[this,member]{drumKey_=member;drumZone_=0;drumGroupEdit_=-1;dirty_=true;});
        }
        button(c,{12,419,131,472},"‹ Prev",blue,false,drumGroupMemberPage_>0,[this]{--drumGroupMemberPage_;dirty_=true;},17);
        label(c,std::to_string(drumGroupMemberPage_+1)+" / "+std::to_string(pages),264,452,17,dim,false,190,Align::Center);
        button(c,{390,419,509,472},"Next ›",blue,false,drumGroupMemberPage_+1<pages,[this]{++drumGroupMemberPage_;dirty_=true;},17);
        button(c,{521,419,787,472},"‹ Groups",green,false,true,[this]{drumGroupEdit_=-1;dirty_=true;},17);
        return;
    }
    const bool fade=drumGroupEdit_==1;const int maximum=fade?10000:127;
    label(c,fade?"CHOKE FADE OUT TIME":"EXCLUSIVE GROUP",17,112,21,white,true,765);
    box(c,{16,130,249,218},panel,orange,6);
    const std::string display=drumGroupNumber_.empty()?"—":!fade&&drumGroupNumber_=="0"?"None":drumGroupNumber_;
    label(c,display,132,185,33,white,true,211,Align::Center);
    label(c,fade?"milliseconds · 0–10000":"0 = None · groups 1–127",132,242,14,dim,false,233,Align::Center);
    const std::array<int,6> presets=fade?std::array<int,6>{{0,4,10,50,100,500}}:std::array<int,6>{{0,1,2,3,4,8}};
    for(int i=0;i<6;++i){const int value=presets[i];const float x=16+(i%2)*122.0F,y=259+(i/2)*47.0F;
        button(c,{x,y,x+111,y+40},!fade&&!value?"None":std::to_string(value)+(fade?" ms":""),blue,
               drumGroupNumber_==std::to_string(value),true,[this,value]{drumGroupNumber_=std::to_string(value);dirty_=true;},16);
    }
    static const char* digits[]{"7","8","9","4","5","6","1","2","3","Clear","0","‹"};
    for(int i=0;i<12;++i){
        const float x=270+(i%3)*175.0F,y=130+(i/3)*67.0F;
        bool enabled=true;std::string next;
        if(i!=9&&i!=11){
            next=drumGroupNumber_=="0"?std::string{}:drumGroupNumber_;next+=digits[i];
            enabled=next.size()<=(fade?5U:3U)&&std::stoi(next)<=maximum;
        }
        button(c,{x,y,x+165,y+58},digits[i],blue,false,enabled,[this,i,next]{
            if(i==9)drumGroupNumber_.clear();
            else if(i==11){if(!drumGroupNumber_.empty())drumGroupNumber_.pop_back();}
            else drumGroupNumber_=next;
            dirty_=true;
        },i==9?17:24);
    }
    button(c,{16,419,381,472},"Cancel",blue,false,true,[this]{drumGroupEdit_=-1;dirty_=true;},18);
    button(c,{397,419,786,472},"Apply to key",green,false,!drumGroupNumber_.empty(),[this,draft,key,fade,maximum]{
        if(drumDraft_!=draft||drumGroupNumber_.empty())return;
        const int value=std::clamp(std::stoi(drumGroupNumber_),0,maximum);auto& g=draft->drumKeyGroups[key];
        const bool changed=fade?g.chokeFadeOutMs!=value:int(g.exclusiveGroup)!=value;
        if(fade)g.chokeFadeOutMs=static_cast<float>(value);else g.exclusiveGroup=static_cast<std::uint8_t>(value);
        if(changed)draft->markEdited();
        drumKey_=key;drumGroupEdit_=-1;dirty_=true;
    },18);
}
