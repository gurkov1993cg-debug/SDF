#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Support.h"
#include <array>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <iostream>

namespace silveton::ui {
struct DrumEditorTestAccess {
    static std::size_t styleFaders(const ArrangerView& v){std::size_t n=0;for(const auto& h:v.hits_)if(h.drag&&h.reset&&h.resetTarget.surface==ArrangerView::ResetSurface::Volume&&h.resetTarget.player==0)++n;return n;}
    static void menu(ArrangerView& v){v.editor_=false;v.picker_=ArrangerView::Picker::HomeMenu;v.dirty_=true;}
    static bool families(const ArrangerView& v){return v.picker_==ArrangerView::Picker::DrumFamilyEdit;}
    static void detail(ArrangerView& v,std::shared_ptr<host::DrumKitDraft> d){v.drumDraft_=std::move(d);v.picker_=ArrangerView::Picker::DrumKitEdit;v.drumTab_=3;v.drumKey_=36;v.drumZone_=0;v.drumGroupEdit_=-1;v.dirty_=true;}
    static bool styleNotes(const ArrangerView& v){return v.drumStyleNotes_;}
    static int selectedNote(const ArrangerView& v){return v.styleNoteKey_;}
    static int notePage(const ArrangerView& v){return v.styleNotePage_;}
    static bool lamp(const ArrangerView& v,int track,int key){return v.styleNoteLamps_.drums[track].test(key);}
    static int notes(const ArrangerView& v){return static_cast<int>(v.allStyleDrums_.drums.size());}
    static int zone(const ArrangerView& v){return v.drumZone_;}
    static int tab(const ArrangerView& v){return v.drumTab_;}
};
}
using namespace silveton;
static sampler::ProgramPtr kit(){
    auto multi=std::make_shared<sampler::Multisample>();
    const std::pair<int,const char*> names[]={{35,"Kick Deep"},{36,"Kick Punch"},{38,"Snare"},{42,"Unclassified"},
        {43,"Perc A"},{44,"Perc B"},{45,"Perc C"},{46,"Perc D"},{47,"Perc E"},{48,"Perc F"},{49,"Perc G"},{50,"Perc H"},{51,"Perc I"}};
    for(auto [key,name]:names){
        auto sample=std::make_shared<sampler::SampleData>();sample->name=name;sample->sampleRate=48000;sample->rootKey=key;
        sample->interleaved.resize(4800);
        for(std::size_t i=0;i<sample->interleaved.size();++i)sample->interleaved[i]=0.3F*std::sin(float(i)*0.17F);
        sampler::SampleZone z;z.sample=sample;z.keyLow=z.keyHigh=z.rootKey=key;z.oneShot=true;
        multi->zones.push_back(z);
    }
    auto p=std::make_shared<sampler::Program>();p->name="DEMO KIT (test fixture)";
    sampler::ProgramLayer layer;layer.multisample=multi;layer.ampEnvelope={0.001F,0.03F,1.0F,0.02F};p->layers.push_back(layer);return p;
}
int main(int argc,char** argv){
    assert(argc==2||argc==3);
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char dir[]="/tmp/silveton-drums-XXXXXX";assert(::mkdtemp(dir));
    const auto path=std::string(dir)+"/test.mid";
    // VAR 1: Drum key 36. VAR 2: 10 other Drum keys and a separate Perc key.
    // The kit also contains key 35, which must not appear in STYLE NOTES.
    std::vector<unsigned char> track={0,0xFF,0x51,3,7,0xA1,0x20,
        0,0xFF,6,4,'V','A','R','1',0,0x99,36,100,96,0x89,36,0,
        0,0xFF,6,4,'V','A','R','2',0,0x99,38,100,0,0x9A,42,100};
    for(unsigned char note=43;note<=51;++note)track.insert(track.end(),{0,0x99,note,100});
    track.insert(track.end(),{96,0x89,38,0,0,0x8A,42,0});
    for(unsigned char note=43;note<=51;++note)track.insert(track.end(),{0,0x89,note,0});
    track.insert(track.end(),{0,0xFF,0x2F,0});
    std::vector<unsigned char> bytes={'M','T','h','d',0,0,0,6,0,0,0,1,0,96,'M','T','r','k',0,0,0,static_cast<unsigned char>(track.size())};bytes.insert(bytes.end(),track.begin(),track.end());
    {std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(bytes.data()),bytes.size());}
    ui::ControllerEnv env;env.dataDir=dir;ui::SamplerAppController controller(env);ui::ArrangerView view(controller);
    auto& h=host::arrangerHost();const auto p=kit();
    assert(h.loadStyle(0,path));assert(h.assignSound(0,0,1,p));assert(h.assignSound(0,1,2,p));h.prepare(48000,64);
    assert(h.observeMidi(0x90,48,100));assert(h.observeMidi(0x90,52,100));assert(h.observeMidi(0x90,55,100));assert(h.start(0));
    ui::Canvas canvas(1640,1040);std::array<float,128> audio{};int step=0;
    const auto pump=[&]{for(int i=0;i<8;++i){audio.fill(0);h.renderAdd(audio.data(),64,48000);}view.tick(ui::nowMs()+150*++step);view.draw(canvas);};
    const auto click=[&](float x,float y){const auto [px,py]=view.detailPoint(x,y);view.pointer(ui::ArrangerView::PointerAction::Down,px,py);view.pointer(ui::ArrangerView::PointerAction::Up,px,py);pump();};
    pump();auto s=h.snapshot(0);assert(s.loaded&&s.playing);const auto serial=s.styleSelectionSerial;
    assert(ui::DrumEditorTestAccess::styleFaders(view)==8);
    const auto originalVolume=s.tracks[0].volumeDb;
    view.pointer(ui::ArrangerView::PointerAction::Down,68,375);
    view.pointer(ui::ArrangerView::PointerAction::Move,68,398);
    view.pointer(ui::ArrangerView::PointerAction::Up,68,398);pump();s=h.snapshot(0);
    assert(s.tracks[0].volumeDb<originalVolume&&originalVolume-s.tracks[0].volumeDb<2.5F&&s.playing&&s.styleSelectionSerial==serial);
    const auto map=h.styleDrumFamilies(0,0,serial);assert(map.available&&map.keys[35].family==0&&map.keys[36].family==0&&map.keys[38].family==1&&map.keys[42].family==-1);
    assert(host::suggestedDrumFamily("Snare Kick")==-1);
    ui::DrumEditorTestAccess::menu(view);pump();click(300,100);assert(ui::DrumEditorTestAccess::families(view));
    click(331,235);s=h.snapshot(0);assert(s.tracks[0].soundSettings.keyDb[35]==1&&s.tracks[0].soundSettings.keyDb[36]==1);assert(s.tracks[0].soundSettings.keyDb[38]==0&&s.tracks[0].soundSettings.keyDb[42]==0);
    click(725,235);s=h.snapshot(0);assert(s.tracks[0].soundSettings.tones&&s.tracks[0].soundSettings.tones->at(35).tune==10&&s.tracks[0].soundSettings.tones->at(36).tune==10);
    click(153,115);click(331,235);s=h.snapshot(0);assert(s.tracks[0].soundSettings.keyDb[38]==1&&s.tracks[0].soundSettings.keyDb[35]==1);assert(s.playing&&s.styleSelectionSerial==serial);
    assert(!h.setStyleDrumKeys(0,0,serial,map.revision+999999,{{35,2,{}}}));
    assert(!h.setStyleDrumKeys(0,0,serial,map.revision,{{35,2,{}},{35,3,{}}}));
    if(argc==3)assert(ui::writePng(std::string(argv[2])+"/SILVETON-DRUM-EDITOR.png",canvas));
    click(650,398);s=h.snapshot(0);assert(s.tracks[0].soundSettings.keyDb[38]==0&&s.tracks[0].soundSettings.keyDb[35]==1);assert(s.playing);
    // STYLE NOTES contains both sections, excludes unused kit keys, and the selected key is edited alone.
    const auto all=h.styleActivity(0,s,true);assert(all.drums.size()==12&&all.drums[0].note==36&&all.drums[1].note==38&&all.drums[10].note==51&&all.drums[11].track==1&&all.drums[11].note==42);
    click(130,398);assert(ui::DrumEditorTestAccess::styleNotes(view));assert(ui::DrumEditorTestAccess::notes(view)==12);
    assert(ui::DrumEditorTestAccess::selectedNote(view)==36);
    click(761,175);assert(ui::DrumEditorTestAccess::notePage(view)==1&&ui::DrumEditorTestAccess::selectedNote(view)==49);
    click(37,175);assert(ui::DrumEditorTestAccess::notePage(view)==0&&ui::DrumEditorTestAccess::selectedNote(view)==36);
    click(154,450);assert(ui::DrumEditorTestAccess::selectedNote(view)==42);
    click(331,235);s=h.snapshot(0);assert(s.tracks[1].soundSettings.keyDb[42]==1&&s.tracks[0].soundSettings.keyDb[42]==0);
    click(56,450);assert(ui::DrumEditorTestAccess::selectedNote(view)==36);
    click(154,119);assert(ui::DrumEditorTestAccess::selectedNote(view)==38);
    click(331,235);s=h.snapshot(0);assert(s.tracks[0].soundSettings.keyDb[38]==1&&s.tracks[0].soundSettings.keyDb[36]==1&&s.tracks[0].soundSettings.keyDb[35]==1);
    // An actual scheduled Style note, not a wall-clock animation, drives the lamp.
    bool saw36=false,sawOff=false;bool saw38=false;
    for(int i=0;i<300;++i){pump();const bool a=ui::DrumEditorTestAccess::lamp(view,0,36);saw36|=a;sawOff|=!a;saw38|=ui::DrumEditorTestAccess::lamp(view,0,38);if(saw36&&sawOff)break;}
    assert(saw36&&sawOff&&!saw38&&h.snapshot(0).playing);
    assert(ui::DrumEditorTestAccess::selectedNote(view)==38);
    if(argc==3){for(int i=0;i<300&&!ui::DrumEditorTestAccess::lamp(view,0,36);++i)pump();assert(ui::writePng(std::string(argv[2])+"/SILVETON-STYLE-NOTES.png",canvas));}
    click(130,398);assert(!ui::DrumEditorTestAccess::styleNotes(view));
    assert(h.snapshot(0).playing&&h.snapshot(0).styleSelectionSerial==serial);
    auto draft=std::make_shared<host::DrumKitDraft>();draft->original=draft->current=p;
    for(const auto& z:p->layers[0].multisample->zones)draft->samples.push_back(z.sample);
    for(int i=0;i<16;++i){auto z=p->layers[0].multisample->zones[1];z.velocityLow=1+i*8;z.velocityHigh=std::min(127,8+i*8);draft->keys[36].push_back({static_cast<unsigned>(i),z});}
    ui::DrumEditorTestAccess::detail(view,draft);pump();
    click(579,211);assert(ui::DrumEditorTestAccess::zone(view)==8);
    click(165,202);assert(ui::DrumEditorTestAccess::zone(view)==10);
    click(615,320);assert(draft->keys[36][10].zone.tuneCents==1&&draft->keys[36][9].zone.tuneCents==0&&draft->dirty);
    if(argc==3)assert(ui::writePng(std::string(argv[2])+"/SILVETON-DRUMKIT-EDIT.png",canvas));
    click(725,121);assert(ui::DrumEditorTestAccess::tab(view)==1);
    assert(h.snapshot(0).playing&&h.snapshot(0).styleSelectionSerial==serial);
    h.stopStreaming();controller.close();std::cout<<"Drum Editor UI: PASS family edits, all-section note list, pagination, independent Drum/Perc edits, MIDI lamps, per-key/layer selection, transport preserved\n";
}
