#include "RetainedSceneFixture.h"
#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <functional>
#include <cmath>
#include <memory>
#include <string>
#include <unistd.h>

using namespace retained_test;

namespace silveton::ui {
struct ViewTestAccess {
    static std::function<void()> waitDialog(SilvetonSamplerView& v,bool& completed) {
        auto d=std::make_shared<SilvetonSamplerView::Dialog>();
        d->kind=SilvetonSamplerView::Dialog::Kind::Wait;d->title="Pending work";
        d->message="Completion must update the screen";d->cancelable=false;
        d->completion=[&completed]{completed=true;};v.dialogStack.push_back(d);v.invalidate();
        return [d]{d->workDone.store(true,std::memory_order_release);};
    }
    static void textEditor(SilvetonSamplerView& v){
        v.showTextPage("Rename","Old name",[](const std::string&){});
        v.dialogStack.back()->selectAll=false;v.invalidate();
    }
};
struct ArrangerKstCatalogTestAccess {
    static void gate(ArrangerView& v){v.liveView_=true;v.openSoundWindow(true,0);v.tonePage_=3;v.dirty_=true;}
    static void tone(ArrangerView& v){v.tonePage_=0;v.dirty_=true;}
    static bool off(const ArrangerView& v){return v.visibleGateReduction()==0;}
};
}
namespace silveton::ui::classic {
struct ViewTestAccess {
    static std::function<void()> waitDialog(SilvetonSamplerView& v,bool& completed) {
        auto d=std::make_shared<SilvetonSamplerView::Dialog>();
        d->kind=SilvetonSamplerView::Dialog::Kind::Wait;d->title="Pending work";
        d->message="Completion must update the screen";d->cancelable=false;
        d->completion=[&completed]{completed=true;};v.dialogStack.push_back(d);v.invalidate();
        return [d]{d->workDone.store(true,std::memory_order_release);};
    }
    static void textEditor(SilvetonSamplerView& v){
        v.showTextPage("Rename","Old name",[](const std::string&){});
        v.dialogStack.back()->selectAll=false;v.invalidate();
    }
};
}

namespace {
ControllerEnv environment() {
    char path[]="/tmp/silveton-retained-ui-XXXXXX";RETAINED_CHECK(::mkdtemp(path)!=nullptr);
    ControllerEnv env;env.dataDir=path;return env;
}

template<class View,class Access>
void editorScheduling(const char* name,int theme) {
    std::int64_t clock=1000;setFixedClockForTests(clock);
    SamplerAppController controller(environment());
    RETAINED_CHECK(controller.engine.nativeClearPerformance());
    controller.setUiTheme(theme);
    View view(controller);FrameRenderer recorder(1340,800);
    const auto draw=[&]{return recorder.record([&](Canvas& c){view.draw(c);},view.renderCacheKey());};
    const auto tick=[&](std::int64_t ms){clock+=ms;setFixedClockForTests(clock);view.tick(clock);};
    view.setPage(View::Page::SETTINGS);RETAINED_CHECK(view.redrawDue(clock));draw();
    for(int step=0;step<10;++step){tick(100);RETAINED_CHECK(!view.redrawDue(clock));}
    const auto settingsKey=view.renderCacheKey();
    view.setPage(View::Page::COMBI);RETAINED_CHECK(view.redrawDue(clock));draw();
    const auto combiKey=view.renderCacheKey();RETAINED_CHECK(combiKey!=settingsKey);
    for(int step=0;step<10;++step){tick(100);RETAINED_CHECK(!view.redrawDue(clock));}
    controller.toggleTerca(0);tick(100);RETAINED_CHECK(view.redrawDue(clock));
    RETAINED_CHECK(draw());RETAINED_CHECK(view.renderCacheKey()==combiKey);
    tick(100);RETAINED_CHECK(!view.redrawDue(clock));
    view.setMidiConnections(2);RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    RETAINED_CHECK(view.renderCacheKey()==combiKey);
    tick(100);RETAINED_CHECK(!view.redrawDue(clock));
    view.showToast("Saved",200);RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    tick(100);RETAINED_CHECK(!view.redrawDue(clock));
    tick(101);RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    tick(100);RETAINED_CHECK(!view.redrawDue(clock));
    view.setWarning("Async warning");RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    view.setWarning("");RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    view.globalChangedOutside();RETAINED_CHECK(view.redrawDue(clock));draw();
    tick(100);RETAINED_CHECK(!view.redrawDue(clock));
    bool completed=false;auto finish=Access::waitDialog(view,completed);
    RETAINED_CHECK(view.redrawDue(clock));draw();
    tick(31);RETAINED_CHECK(view.redrawDue(clock));draw();
    finish();tick(1);RETAINED_CHECK(completed&&!view.dialogOpen());
    RETAINED_CHECK(view.redrawDue(clock));draw();
    Access::textEditor(view);draw();
    tick(501);RETAINED_CHECK(view.redrawDue(clock));draw();
    view.keyDown(View::Key::Escape);RETAINED_CHECK(view.redrawDue(clock));draw();
    view.setPage(View::Page::SETTINGS);RETAINED_CHECK(view.renderCacheKey()==settingsKey);draw();
    for(int step=0;step<10;++step){tick(100);RETAINED_CHECK(!view.redrawDue(clock));}
    controller.close();
    std::printf("PASS %s: idle settings/combi, direct T/Q change, MIDI, toast, warning, async completion and cursor\n",name);
}

void classicWrapperNavigation() {
    std::int64_t clock=12000;setFixedClockForTests(clock);
    SamplerAppController controller(environment());
    RETAINED_CHECK(controller.engine.nativeClearPerformance());
    RETAINED_CHECK(controller.uiTheme()==4);
    SilvetonSamplerView view(controller);FrameRenderer recorder(1340,800);
    const auto draw=[&]{
        const auto key=view.renderCacheKey();
        const bool present=recorder.record([&](Canvas& c){view.draw(c);},key);
        RETAINED_CHECK(view.renderCacheKey()==key);return present;
    };
    const auto idle=[&]{for(int step=0;step<10;++step){
        clock+=100;setFixedClockForTests(clock);view.tick(clock);RETAINED_CHECK(!view.redrawDue(clock));
    }};
    view.setPage(SilvetonSamplerView::Page::SETTINGS);RETAINED_CHECK(view.redrawDue(clock));draw();idle();
    const auto settingsKey=view.renderCacheKey();
    view.setPage(SilvetonSamplerView::Page::COMBI);RETAINED_CHECK(view.redrawDue(clock));draw();idle();
    RETAINED_CHECK(view.renderCacheKey()!=settingsKey);
    view.setPage(SilvetonSamplerView::Page::SETTINGS);RETAINED_CHECK(view.redrawDue(clock));
    RETAINED_CHECK(view.renderCacheKey()==settingsKey);draw();
    RETAINED_CHECK(recorder.changed().empty());idle();controller.close();
    std::puts("PASS default classic wrapper: menu transitions invalidate, stable cache keys, idle and cached return");
}

template<class View>
void activeMeters(const char* name,int theme,typename View::Page page) {
    std::int64_t clock=30000;setFixedClockForTests(clock);
    SamplerAppController controller(environment());controller.setUiTheme(theme);
    RETAINED_CHECK(controller.engine.nativeClearPerformance());
    RETAINED_CHECK(controller.assignUpperSound(0,{0,0,9001,"Meter fixture"}));
    auto output=std::make_unique<silveton::host::OfflineAudioOutput>(48000.0,96U);
    auto* audio=output.get();
    controller.engine.setBackends(std::move(output),std::make_unique<silveton::host::ManualMidiInput>());
    RETAINED_CHECK(controller.engine.nativeAudioOpen()&&controller.engine.nativeAudioStart());
    View view(controller);view.setPage(page);FrameRenderer recorder(1340,800);
    const auto draw=[&]{return recorder.record([&](Canvas& c){view.draw(c);},view.renderCacheKey());};
    const auto tick=[&](std::int64_t ms){clock+=ms;setFixedClockForTests(clock);view.tick(clock);};
    const auto peak=[&]{const auto levels=controller.upperMeters();return std::max(levels.at(0).first,levels.at(0).second);};
    draw();audio->pump(480U);tick(100);if(view.redrawDue(clock))draw();
    RETAINED_CHECK(controller.engine.nativeMidi(0x90,69,120));
    audio->pump(4800U);tick(100);RETAINED_CHECK(peak()>0.001F);
    RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    // Allow the finite MIDI flash to expire before changing only the sustained
    // sound level. No periodic redraw should be needed to see meter movement.
    tick(300);if(view.redrawDue(clock))draw();
    const float loud=peak();
    RETAINED_CHECK(controller.engine.nativeUpdateUpperMain(0,true,false,false,-30.0F,0,0,127,0));
    audio->pump(24000U);tick(100);RETAINED_CHECK(peak()<loud*0.5F);
    RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    RETAINED_CHECK(controller.engine.nativePanic());audio->pump(192000U);tick(100);
    RETAINED_CHECK(controller.audioStatus().activeVoices==0);RETAINED_CHECK(peak()<0.000001F);
    RETAINED_CHECK(view.redrawDue(clock));RETAINED_CHECK(draw());
    for(int step=0;step<10;++step){tick(100);RETAINED_CHECK(!view.redrawDue(clock));}
    controller.close();
    std::printf("PASS %s: real offline sound/meter changes redraw, then silence settles without repeated redraw\n",name);
}

void gateIdle() {
    std::int64_t clock=20000;setFixedClockForTests(clock);
    SamplerAppController controller(environment());
    RETAINED_CHECK(controller.engine.nativeClearPerformance());
    RETAINED_CHECK(controller.assignUpperSound(0,{0,0,9001,"Gate fixture"}));
    ArrangerView view(controller);FrameRenderer recorder(1340,800);
    using A=ArrangerKstCatalogTestAccess;
    const auto draw=[&]{return recorder.record([&](Canvas& c){view.draw(c);},view.renderCacheKey());};
    const auto tick=[&](std::int64_t ms){clock+=ms;setFixedClockForTests(clock);view.tick(clock);};
    A::gate(view);tick(100);draw();
    // First poll can settle source metadata; it must then remain quiet.
    for(int step=0;step<3;++step){tick(100);if(view.redrawDue(clock))draw();}
    RETAINED_CHECK(A::off(view));
    const auto gateKey=view.renderCacheKey();
    for(int step=0;step<20;++step){tick(50);RETAINED_CHECK(!view.redrawDue(clock));}
    A::tone(view);RETAINED_CHECK(view.renderCacheKey()!=gateKey);draw();
    A::gate(view);RETAINED_CHECK(view.renderCacheKey()==gateKey);draw();
    RETAINED_CHECK(recorder.changed().empty());
    for(int step=0;step<10;++step){tick(50);RETAINED_CHECK(!view.redrawDue(clock));}
    view.showToast("Gate page remains responsive",200);RETAINED_CHECK(view.redrawDue(clock));draw();
    tick(201);RETAINED_CHECK(view.redrawDue(clock));draw();
    controller.close();
    std::puts("PASS Gate Off: no 50ms redraw, cached return and toast expiration");
}
}

int main(int argc,char** argv) {
    if(argc!=2)return 2;
    try{
        setFontDirectory(argv[1]);RETAINED_CHECK(fontsReady());
        editorScheduling<SilvetonSamplerView,ViewTestAccess>("regular editor",0);
        editorScheduling<classic::SilvetonSamplerView,classic::ViewTestAccess>("classic editor",4);
        classicWrapperNavigation();gateIdle();
        activeMeters<SilvetonSamplerView>("regular master meter on Settings",0,SilvetonSamplerView::Page::SETTINGS);
        activeMeters<classic::SilvetonSamplerView>("classic part meters on Combi",4,classic::SilvetonSamplerView::Page::COMBI);
        setFixedClockForTests(-1);
    }catch(const std::exception& e){setFixedClockForTests(-1);std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
    return 0;
}
