// Focused contract checks for browsing and importing selected external SET blends.
// Uses a self-contained measurement model, controller/host state and real SET serialization.
#include "silveton/ui/SamplerAppController.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/SoloDefs.h"
#include <cstdio>
#include <fstream>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#include <unistd.h>

namespace sv=silveton::sampler;
using Ctrl=silveton::ui::SamplerAppController;
#define CHECK(x) do { if(!(x)) throw std::runtime_error(std::string("line ")+std::to_string(__LINE__)+": " #x); } while(false)

namespace {
std::shared_ptr<const sv::solo::Model> measurementModel() {
    sv::solo::Model m;
    m.name="IMPORT MEASUREMENT FIXTURE";
    m.releaseMs=95;
    for (int phase=0;phase<4;++phase) for (int breath=0;breath<2;++breath) {
        sv::solo::Cell cell;
        cell.at.phase=static_cast<sv::solo::Phase>(phase);
        cell.at.key=69;
        cell.at.ageMs=phase==1?300.0F:25.0F;
        cell.at.breath=static_cast<float>(breath);
        cell.count=5;
        cell.sound.db.fill(-90);
        cell.sound.db[0]=0;
        cell.sound.db[1]=breath?-3.0F:-30.0F;
        cell.sound.rmsDb=-18;
        m.cells.push_back(cell);
        m.observations[69][static_cast<std::size_t>(phase)]+=cell.count;
    }
    m.prepare();
    std::string error;
    const auto decoded=sv::solo::decodeModel(sv::solo::encodeModel(m),error);
    CHECK(decoded&&error.empty());
    return decoded;
}
std::string bytes(const std::string& p) {
    std::ifstream f(p,std::ios::binary);CHECK(f.good());
    return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
std::string listKey(Ctrl& c) {
    std::string s;
    for(const auto& x:c.listItems(0,0,0))s+=std::to_string(x.number)+"|"+x.name+"|"+std::to_string(x.combiBank)+"/"+std::to_string(x.combiPage)+"/"+std::to_string(x.combiSlot)+"\n";
    return s;
}
std::vector<bool> occupied(Ctrl& c) {
    std::vector<bool> out;for(int i=1;i<=500;++i)out.push_back(c.engine.nativeCombiSlotOccupied(0,0,i));return out;
}
std::shared_ptr<const sv::Combi> storedAt(Ctrl& c,int index) {
    const auto rows=c.listItems(0,0,0);CHECK(index>=0&&index<static_cast<int>(rows.size()));const auto& r=rows[static_cast<std::size_t>(index)];
    const auto result=c.engine.nativeStoredCombi(r.combiBank,r.combiPage,r.combiSlot);CHECK(result);return result;
}
std::string contract(const std::string& dir,const sv::Combi& combi) {
    sv::SetData d;d.name="IMPORT CONTRACT";d.combis.push_back({{0,0,1},combi});
    const auto path=dir+"/CONTRACT.SVSET";CHECK(sv::SetPackage::save(path,d).success);return bytes(path);
}
void writeList(Ctrl& c,const std::vector<Ctrl::ListItem>& rows) {
    std::vector<int> numbers,addresses;std::vector<std::string> names;
    for(const auto& r:rows){numbers.push_back(r.number);names.push_back(r.name);addresses.insert(addresses.end(),{r.combiBank,r.combiPage,r.combiSlot});}
    CHECK(c.engine.nativeWriteList(0,0,0,"LIVE",numbers,names,addresses));
}
sv::Combi trainedCombi(const std::shared_ptr<const sv::solo::Model>& model,const std::string& name,float fine) {
    sv::Combi c;c.name=name;auto& u=c.uppers[0];
    u.name=model->name;u.soloModel=model;u.commonProcessing=true;u.enabled=true;
    u.engine=sv::engineDefaults(sv::EngineType::Solo);sv::solo::learnedDefaults(u.engine.p.data(),model->releaseMs);
    u.voiceMode=sv::UpperVoiceMode::Legato;u.octave=1;u.transposeSemitones=2;u.tuneCents=fine;u.pitchBendRange=12;
    u.portaMode=sv::PortamentoMode::Kronos;u.portaTime=26;u.portaFingered=true;u.portaRateMode=true;
    u.levelDb=-4;u.pan=.25F;u.keyLow=36;u.keyHigh=100;u.breathEnabled=true;u.expressionEnabled=true;
    u.toneAttackMs=13;u.toneDecayMs=240;u.toneSustain=.67F;u.toneReleaseMs=330;u.toneCutoffHz=8500;
    u.eq.band[2].gainDb=2;u.fxSend1=.35F;u.fxSend3=.1F;
    auto& l=u.layers[0];static_cast<sv::SoundAssignment&>(l)=static_cast<const sv::SoundAssignment&>(u);
    l.name="TRAINED LAYER";l.enabled=true;l.levelDb=-7;l.pan=-.2F;l.transposeSemitones=-3;l.octave=-1;l.tuneCents=12.5F;
    l.keyLow=48;l.keyHigh=96;l.velocityLow=20;l.velocityHigh=120;
    l.tone.attackMs=22;l.tone.decayMs=135;l.tone.sustain=.46F;l.tone.releaseMs=440;l.tone.x.highPassHz=120;
    c.fx[0].type=sv::EffectType::Reverb;c.fx[0].wet=.37F;c.fx[0].feedback=.62F;c.fx[0].preDelayMs=17;
    c.fx[1].type=sv::EffectType::Delay;c.fx[1].wet=.2F;c.fx[1].timeMs=271;
    c.insert[0].type=sv::EffectType::Chorus;c.insert[0].wet=.25F;c.fxRouting=sv::EffectRouting::Fx1IntoFx2;
    c.scale.stored=true;c.scale.enabled=true;c.scale.targets=1;c.scale.tonic=2;c.scale.name="IMPORT SCALE";c.scale.cents[1]=-50;c.scale.cents[6]=-35;
    return c;
}
}

int main() {try {
    const auto model=measurementModel();
    char tmp[]="/tmp/silveton-set-import-tests-XXXXXX";CHECK(mkdtemp(tmp));const std::string dir=tmp;
    silveton::ui::ControllerEnv env;env.dataDir=dir;Ctrl target(env);auto& n=target.engine;
    CHECK(n.nativeClearPerformance());CHECK(n.nativeAssignUpperSound(0,0,9005,0));
    CHECK(target.writeCombiToList(0,"TARGET A")==0);
    CHECK(n.nativeUpdateUpperTune(0,0,0,100,2,0));CHECK(target.writeCombiToList(1,"TARGET B")==1);
    CHECK(n.nativeUpdateUpperTune(0,0,0,999,2,.01F));
    CHECK(n.nativeUpdateGlobal(441,1,-8,1,2,3,true,-9,2,2,11,64,true,true));
    target.setPortaBalance(33);target.setPortaNear(170);
    target.saveListFavourites({1});

    const auto sourceA=trainedCombi(model,"TRAINED A",17.5F),sourceB=trainedCombi(model,"TRAINED B",55.25F);
    sv::SetData data;data.name="SOURCE SET";data.global.masterTuneHz=452;data.global.masterGainDb=-17;
    data.combis.push_back({{0,0,100},sourceA});data.combis.push_back({{0,0,101},sourceB});
    sv::SetList sourceList;sourceList.name="LIVE";
    sourceList.entries={{1,"TRAINED A",0,0,100},{2,"TRAINED B",0,0,101}};
    data.lists.push_back({{0,0,0},sourceList});data.extra="list_favs=1\nporta_balance=3\nporta_near=5\n";
    const auto sourcePath=dir+"/SOURCE.SVSET";CHECK(sv::SetPackage::save(sourcePath,data).success);
    const auto live=n.nativeUpperState(0),global=n.nativeGlobalState(),fx=n.nativeFxParams(0);
    const auto listBefore=listKey(target);const auto slotsBefore=occupied(target);const auto nameBefore=n.nativeCombiName();
    const auto favouritesBefore=target.listFavourites();
    const bool editedBefore=n.nativeBlendEdited();const int activeBefore=n.nativeActiveListEntry(0,0,0);
    auto unchanged=[&]{CHECK(listKey(target)==listBefore);CHECK(target.listFavourites()==favouritesBefore);CHECK(n.nativeUpperState(0)==live);CHECK(n.nativeGlobalState()==global);CHECK(n.nativeFxParams(0)==fx);CHECK(n.nativeCombiName()==nameBefore);CHECK(n.nativeBlendEdited()==editedBefore);CHECK(n.nativeActiveListEntry(0,0,0)==activeBefore);CHECK(occupied(target)==slotsBefore);};
    Ctrl::ListClipboard catalog;CHECK(target.readSetBlends(sourcePath,catalog));
    CHECK(catalog.items.size()==2&&catalog.combis.size()==2&&catalog.sources==std::vector<int>({0,1}));
    CHECK(catalog.items[0].name=="TRAINED A"&&catalog.items[1].name=="TRAINED B");unchanged();
    CHECK(contract(dir,*catalog.combis[0])==contract(dir,sourceA));
    CHECK(catalog.combis[0]->uppers[0].soloModel&&catalog.combis[0]->uppers[0].layers[0].soloModel);
    CHECK(sv::solo::encodeModel(*catalog.combis[0]->uppers[0].soloModel)==sv::solo::encodeModel(*model));
    std::puts("PASS browse: real SET read leaves current list, open edits, FX, globals and active entry unchanged");

    // Both a different target bank and an unresolved program must fail before any insertion.
    int first=-1;auto badBank=catalog;badBank.bankFile="/different-bank.sv";
    CHECK(!target.importSetBlends(badBank,{0},0,first));unchanged();
    auto missing=catalog;auto missingCombi=*missing.combis[0];auto& missingSource=missingCombi.uppers[0];
    missingSource.engine=sv::engineDefaults(sv::EngineType::Off);missingSource.soloModel.reset();missingSource.program.reset();missingSource.soundSlotId=499;missingSource.name="OTHER BANK ONLY";
    missing.combis[0]=std::make_shared<const sv::Combi>(missingCombi);
    CHECK(!target.importSetBlends(missing,{0},0,first));unchanged();
    auto foreignBuiltin=catalog;auto foreignCombi=missingCombi;auto& foreignSource=foreignCombi.uppers[0];
    foreignSource.soundSlotId=9005;foreignSource.name="Foreign Sample";
    foreignBuiltin.combis[0]=std::make_shared<const sv::Combi>(foreignCombi);
    CHECK(!target.importSetBlends(foreignBuiltin,{0},0,first));unchanged();
    auto foreignProgram=std::make_shared<sv::Program>();foreignProgram->name="SINE";
    foreignSource.name="SINE";foreignSource.program=foreignProgram;
    foreignBuiltin.combis[0]=std::make_shared<const sv::Combi>(foreignCombi);
    CHECK(!target.importSetBlends(foreignBuiltin,{0},0,first));unchanged();
    CHECK(!target.importSetBlends(catalog,{},0,first));unchanged();
    Ctrl::ListClipboard broken;CHECK(!target.readSetBlends(dir+"/NO-SUCH-SET.SVSET",broken));unchanged();
    std::puts("PASS rejection: changed bank, missing dependency, empty selection and unreadable file leave target intact");

    // Browsed data is frozen even if the external SET is replaced before the user presses LOAD.
    data.combis[0].combi.name="CHANGED ON DISK";data.combis[0].combi.uppers[0].tuneCents=-300;
    CHECK(sv::SetPackage::save(sourcePath,data).success);
    CHECK(target.importSetBlends(catalog,{1,0,1},0,first)&&first==0);
    const auto merged=target.listItems(0,0,0);CHECK(merged.size()==4);
    CHECK(merged[0].name=="TRAINED A"&&merged[1].name=="TRAINED B"&&merged[2].name=="TARGET A"&&merged[3].name=="TARGET B");
    CHECK(contract(dir,*storedAt(target,0))==contract(dir,sourceA));CHECK(contract(dir,*storedAt(target,1))==contract(dir,sourceB));
    CHECK(n.nativeUpperState(0)==live&&n.nativeGlobalState()==global&&n.nativeFxParams(0)==fx);
    CHECK(n.nativeActiveListEntry(0,0,0)==activeBefore+2&&n.nativeBlendEdited()==editedBefore);
    CHECK(target.portaBalance()==33&&target.portaNear()==170);
    CHECK((target.listFavourites()==std::set<int>{1,3}));
    std::puts("PASS import: selected snapshots preserve models, layers, ADSR, tuning, FX and scale; existing blends shift and open edits keep playing");

    // A full LIST must not leave orphan COMBIs behind when the insertion cannot fit.
    const auto mergedKey=listKey(target);const auto mergedSlots=occupied(target);
    std::vector<Ctrl::ListItem> full(200,merged[2]);
    for(int i=0;i<200;++i){full[static_cast<std::size_t>(i)].number=i+1;full[static_cast<std::size_t>(i)].name="FULL "+std::to_string(i+1);}
    writeList(target,full);const auto fullKey=listKey(target);
    CHECK(!target.importSetBlends(catalog,{0,1},0,first));CHECK(listKey(target)==fullKey);CHECK(occupied(target)==mergedSlots);
    CHECK(n.nativeUpperState(0)==live&&n.nativeGlobalState()==global);writeList(target,merged);
    CHECK(listKey(target)==mergedKey);CHECK(n.nativeSetActiveListEntry(0,0,0,activeBefore+2));
    std::puts("PASS capacity: full list rejection is atomic and creates no extra COMBI slots");

    CHECK(!target.saveSetAs("MERGED"));const auto saved=sv::SetPackage::load(dir+"/MERGED.SVSET");CHECK(saved.ok());
    CHECK(saved.data.samples.empty()&&saved.data.programs.empty()&&saved.data.performance.has_value());
    CHECK(saved.data.performance->combi.uppers[0].tuneCents==999&&saved.data.performance->edited);
    CHECK(!target.loadSavedSet("MERGED"));CHECK(n.nativeUpperState(0)==live&&n.nativeGlobalState()==global);
    CHECK((target.listFavourites()==std::set<int>{1,3}));
    CHECK(contract(dir,*storedAt(target,0))==contract(dir,sourceA));CHECK(contract(dir,*storedAt(target,1))==contract(dir,sourceB));
    CHECK(target.activateListEntry(0,0,0,0));CHECK(target.soundSource(0,0).soloModel&&target.soundSource(0,1).soloModel);
    CHECK(target.upperState(0)->pitchBendRange==12);CHECK(target.upperState(0)->voiceMode==2);
    CHECK(n.nativeGlobalState().at(0)==441);
    std::puts("PASS persistence: merged single-file SET restores imported trained MAIN/layer sources and stored/open-state separation");

    auto unlisted=data;unlisted.lists.clear();const auto unlistedPath=dir+"/UNLISTED.SVSET";
    CHECK(sv::SetPackage::save(unlistedPath,unlisted).success);Ctrl::ListClipboard fallback;
    CHECK(target.readSetBlends(unlistedPath,fallback)&&fallback.items.size()==2);
    std::printf("PASS legacy/unlisted source catalog; fixtures: %s\n",dir.c_str());

    // The older themes keep overwrite semantics, but COPY must be independent
    // and both COPY/MOVE must carry the source favourite to its new position.
    target.saveListFavourites({0,1,3});
    CHECK(target.copyListEntryTo(0,5));
    const auto copied=target.listItems(0,0,0);
    CHECK(copied[0].combiSlot!=copied[5].combiSlot);
    CHECK(contract(dir,*storedAt(target,0))==contract(dir,*storedAt(target,5)));
    CHECK((target.listFavourites()==std::set<int>{0,1,3,5}));
    CHECK(target.moveListEntryTo(5,6));
    CHECK(target.isEmptyListItem(target.listItems(0,0,0)[5]));
    CHECK((target.listFavourites()==std::set<int>{0,1,3,6}));
    CHECK(n.nativeActiveListEntry(0,0,0)==0);
    std::puts("PASS older theme COPY/MOVE: independent snapshot, overwrite positions, favourites and active selection");
}catch(const std::exception& e){std::fprintf(stderr,"FAIL SET IMPORT: %s\n",e.what());return 1;}return 0;}
