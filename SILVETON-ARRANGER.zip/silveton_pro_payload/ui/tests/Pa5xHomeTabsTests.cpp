#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Pa5xHomeTabs.h"
#include "silveton/ui/Support.h"
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <iostream>

namespace silveton::ui {
struct Pa5xHomeTabTestAccess {
    static int tab(const ArrangerView& v) { return homeTabIndex(v.tab_); }
    static bool home(const ArrangerView& v) {
        return v.picker_==ArrangerView::Picker::None && v.panelMode_==ArrangerView::PanelMode::Home;
    }
    static bool catalog(const ArrangerView& v) { return v.picker_==ArrangerView::Picker::Pa5xFxCatalog; }
    static bool stylePicker(const ArrangerView& v) {
        return v.picker_==ArrangerView::Picker::Style ||
               (v.picker_==ArrangerView::Picker::KstCatalog && v.kstCatalogTab_==0) ||
               v.picker_==ArrangerView::Picker::SavedStyleLibrary;
    }
    static int player(const ArrangerView& v) { return v.selectedPlayer_; }
    static std::size_t depth(const ArrangerView& v){return v.navigationHistory_.size();}
    static bool menu(const ArrangerView& v){return v.picker_==ArrangerView::Picker::HomeMenu;}
    static bool globalMenu(const ArrangerView& v){return v.picker_==ArrangerView::Picker::SettingsMenu&&v.globalPage_==ArrangerView::GlobalPage::Menu&&v.panelMode_==ArrangerView::PanelMode::Settings;}
    static bool globalPage(const ArrangerView& v){return v.picker_==ArrangerView::Picker::SettingsMenu&&v.globalPage_!=ArrangerView::GlobalPage::Menu;}
    static void openMenu(ArrangerView& v){v.panelMenu();}
    static void openGlobal(ArrangerView& v){v.openPanelSettings();}
    static void openGeneral(ArrangerView& v){v.openGlobalPage(ArrangerView::GlobalPage::General);}
    static void info(ArrangerView& v){v.showStyleInfo("Navigation test","Detail");}
    static void openStyles(ArrangerView& v){v.openKstCatalog(0,v.selectedPlayer_);}
    static void openUserStyles(ArrangerView& v){v.openSavedStyleLibrary(v.selectedPlayer_);}
    static void openKbd(ArrangerView& v){v.openKstCatalog(2);}
    static void openUserKbd(ArrangerView& v){v.openSavedKeyboardLibrary();}
    static void openLegacyEditor(ArrangerView& v){v.openEditor(ArrangerView::Page::COMBI);}
    static bool legacyEditor(const ArrangerView& v){return v.editor_;}
    static bool wrapperDuplicate(const ArrangerView& v){
        for(const auto& hit:v.hits_)if(hit.rect.top>=7.9F&&hit.rect.bottom<=67.1F&&hit.rect.right>=1417.9F)return true;
        return false;
    }
    static void genericListRegression(ArrangerView& v){
        v.home();v.openPicker(ArrangerView::Picker::Split);
        assert(v.picker_==ArrangerView::Picker::Split);
        v.pickerPage_=5;v.pickerCategory_=0;
        const auto count=v.entries_.size();assert(count==127);
        const auto first=v.entries_.front().name;
        v.showStyleInfo("Detail","nested test");
        v.entries_.clear();v.pickerPage_=0;v.pickerCategory_=2;
        v.panelExit();assert(v.picker_==ArrangerView::Picker::Split);
        assert(v.pickerPage_==5&&v.pickerCategory_==0&&v.entries_.size()==count&&v.entries_.front().name==first);
        v.panelExit();assert(home(v)&&tab(v)==0&&depth(v)==0);
    }

    static void installSelectorFixture(ArrangerView& v) {
        auto catalog=std::make_shared<arranger::Pa5xKstCatalog>();
        catalog->rootPath="/fixture/Selector.KST";catalog->name="Selector.KST";
        catalog->recognized=true;catalog->styleListComplete=true;
        arranger::Pa5xCatalogStyleGroup root,bank;
        root.name="STYLE";root.relativePath="STYLE";root.childGroups={1};
        bank.name="Live Styles";bank.relativePath="STYLE/Live Styles";bank.parentPath="STYLE";
        for(int i=0;i<35;++i){
            arranger::Pa5xCatalogStyle st;st.name="Test Style "+std::to_string(i+1);
            st.relativePath=bank.relativePath+"/"+st.name+".stg";st.path=catalog->rootPath+"/"+st.relativePath;
            st.categoryPath=bank.relativePath;st.positionSlot=i;st.originalSettings.indexed=true;st.originalSettings.readable=true;
            st.bpm=144;st.numerator=4;st.denominator=4;st.error="Selector test fixture";
            // Unavailable entries open their own info instead of loading
            // nonexistent resources, so the test checks the exact tile identity.
            bank.styleIndices.push_back(catalog->styles.size());bank.slotStyleIndices.push_back(i);catalog->styles.push_back(st);
            arranger::Pa5xCatalogKeyboardSet ks;ks.name="Test Keyboard Set "+std::to_string(i+1);
            ks.relativePath="KEYBOARDSET/Live Sets/"+ks.name+".ksc";ks.path=catalog->rootPath+"/"+ks.relativePath;
            ks.blocker="Selector test fixture";catalog->keyboardSets.push_back(ks);
        }
        bank.descendantStyleCount=35;root.descendantStyleCount=35;
        catalog->styleGroups={root,bank};catalog->discoveredStyleFiles=35;catalog->unavailableStyles=35;
        v.kstCatalog_=catalog;v.home();v.openKstCatalog(0,v.selectedPlayer_);
    }
    static bool denseSelector(const ArrangerView& v,int tab) {return v.compactKstSelector()&&v.kstCatalogTab_==tab;}
    static const std::string& infoTitle(const ArrangerView& v) {return v.styleInfoTitle_;}
    static bool infoOpen(const ArrangerView& v) {return v.picker_==ArrangerView::Picker::StyleInfo;}
    static std::size_t tileHits(const ArrangerView& v) {
        std::size_t count=0;
        for(const auto& h:v.hits_){
            const auto& r=h.rect;
            const float z=v.displayZoom_;
            if(r.left>=v.displayLeft_+208*z-.1F && r.right<=v.displayLeft_+800*z+.1F &&
               r.top>=v.displayTop_+77*z-.1F && r.bottom<=v.displayTop_+386*z+.1F &&
               std::abs(r.width()-291*z)<.1F && std::abs(r.height()-36*z)<.1F)++count;
        }
        return count;
    }

};
}

int main(int argc,char** argv){
    assert(argc==2);
    using namespace silveton;
    assert(ui::kPa5xHomeTabs.size()==10);
    for(std::size_t i=0;i<ui::kPa5xHomeTabs.size();++i)
        assert(ui::homeTabIndex(ui::homeTabAt(i))==static_cast<int>(i));
    assert(ui::homeTabAt(123)==ui::Pa5xHomeTab::Main);
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char temporary[]="/tmp/silveton-home-tabs-XXXXXX";
    const char* directory=::mkdtemp(temporary);assert(directory);
    ui::ControllerEnv env;env.dataDir=directory;
    ui::SamplerAppController controller(env);
    ui::ArrangerView view(controller);
    ui::Canvas canvas(1640,1040);
    const auto click=[&](float x,float y){
        view.pointer(ui::ArrangerView::PointerAction::Down,x,y);
        view.pointer(ui::ArrangerView::PointerAction::Up,x,y);
        view.draw(canvas);
    };
    const auto liveTabX=[](int i){
        constexpr float start=24.0F,end=1616.0F,gap=4.0F;
        constexpr float width=(end-start-gap*9.0F)/10.0F;
        return start+(width+gap)*i+width*0.5F;
    };
    view.draw(canvas);
    const auto initial=host::arrangerHost().snapshot(0);
    for(int i=0;i<10;++i){
        click(liveTabX(i),843.0F);
        assert(ui::Pa5xHomeTabTestAccess::tab(view)==i);
        assert(ui::Pa5xHomeTabTestAccess::home(view));
        assert(ui::Pa5xHomeTabTestAccess::depth(view)==0);
        const auto after=host::arrangerHost().snapshot(0);
        assert(after.playing==initial.playing);
        assert(after.styleSelectionSerial==initial.styleSelectionSerial);
    }
    // Jukebox is clearly a two-STYLE-player panel. Its real Focus button
    // changes the working player, without launching/stopping a style.
    click(liveTabX(7),843.0F);
    const auto localClick=[&](float x,float y){const auto [px,py]=view.detailPoint(x,y);click(px,py);};
    localClick(406+318,326.0F);
    assert(ui::Pa5xHomeTabTestAccess::player(view)==1);
    // Kaoss does NOT pretend a DSP XY algorithm exists; the FX Catalog is real.
    click(liveTabX(9),843.0F);
    localClick(582.0F,364.0F);
    assert(ui::Pa5xHomeTabTestAccess::catalog(view));
    // No transport operation was attempted by this navigation-only test.
    assert(host::arrangerHost().snapshot(0).playing==initial.playing);
    using Nav=ui::Pa5xHomeTabTestAccess;
    // Physical/Android Back from FX returns to Kaoss, then MAIN, exactly once.
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::tab(view)==9);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::tab(view)==0&&Nav::depth(view)==0);
    // Nested detail Back uses the same handler as Escape. Check the real
    // touch target, not just a direct state change.
    Nav::openMenu(view);view.draw(canvas);assert(Nav::menu(view)&&!Nav::wrapperDuplicate(view));
    Nav::info(view);view.draw(canvas);assert(Nav::infoOpen(view)&&Nav::depth(view)==2);
    const auto detailBack=[&]{localClick(48,19);};
    detailBack();assert(Nav::menu(view)&&Nav::depth(view)==1);
    Nav::openLegacyEditor(view);view.draw(canvas);assert(Nav::legacyEditor(view));
    click(80,22);assert(Nav::menu(view)&&Nav::depth(view)==1);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::openGlobal(view);view.draw(canvas);assert(Nav::globalMenu(view));
    for(int i=0;i<5;++i){Nav::openGeneral(view);assert(Nav::globalPage(view)&&Nav::depth(view)==2);Nav::openMenu(view);assert(Nav::globalMenu(view)&&Nav::depth(view)==1);}
    Nav::openGeneral(view);Nav::openGlobal(view);assert(Nav::globalMenu(view)&&Nav::depth(view)==1);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::genericListRegression(view);
    // 35 items cover all sixteen tile positions and two page transitions.
    ui::Pa5xHomeTabTestAccess::installSelectorFixture(view);view.draw(canvas);
    for(int i=0;i<6;++i){Nav::openUserStyles(view);Nav::openStyles(view);assert(Nav::depth(view)==1);}
    view.keyDown(ui::ArrangerView::Key::Escape);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::openKbd(view);for(int i=0;i<6;++i){Nav::openUserKbd(view);Nav::openKbd(view);assert(Nav::depth(view)==1);}
    view.keyDown(ui::ArrangerView::Key::Escape);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::openStyles(view);view.draw(canvas);
    const auto tileClick=[&](int slot){localClick(208+(slot/8)*295+130,77+(slot%8)*39+18);};
    const auto checkPages=[&](int tab,const std::string& prefix){
        assert(ui::Pa5xHomeTabTestAccess::denseSelector(view,tab));
        localClick(50,98);
        for(int page=0;page<3;++page){
            if(page>0)localClick(771,413);
            const int count=page<2?16:3;
            assert(ui::Pa5xHomeTabTestAccess::tileHits(view)==static_cast<std::size_t>(count));
            for(int i=0;i<count;++i){
                tileClick(i);assert(ui::Pa5xHomeTabTestAccess::infoOpen(view));
                assert(ui::Pa5xHomeTabTestAccess::infoTitle(view)==prefix+std::to_string(page*16+i+1));
                view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);
                assert(ui::Pa5xHomeTabTestAccess::denseSelector(view,tab));
            }
        }
        localClick(230,413);assert(ui::Pa5xHomeTabTestAccess::tileHits(view)==16);
    };
    checkPages(0,"Test Style ");
    localClick(490,21);checkPages(2,"Test Keyboard Set ");
    localClick(220,21);assert(ui::Pa5xHomeTabTestAccess::denseSelector(view,0));
    localClick(44,21);assert(ui::Pa5xHomeTabTestAccess::home(view));assert(Nav::depth(view)==0);
    assert(host::arrangerHost().snapshot(0).playing==initial.playing);
    assert(host::arrangerHost().snapshot(0).styleSelectionSerial==initial.styleSelectionSerial);
    // Tablet pixel sizes: verify real drawing and touch transforms, page fit,
    // no stretch, and no overlap with the reserved live navigation/transport.
    for(const auto& dimensions : {std::pair<int,int>{1340,800},{1920,1080},{1280,800}}){
        ui::Canvas tablet(dimensions.first,dimensions.second);
        Nav::openGlobal(view);view.draw(tablet);assert(Nav::globalMenu(view));
        const auto [x0,y0]=view.detailPoint(0,0);
        const auto [x1,y1]=view.detailPoint(800,480);
        const float w=x1-x0,h=y1-y0;
        assert(x0>=0&&y0>=0&&x1<=dimensions.first+.1F&&y1<=dimensions.second+.1F);
        assert(std::abs(w/800.0F-h/480.0F)<.001F);
        assert(w/dimensions.first>.78F&&h/dimensions.second>.86F);
        const auto tapTablet=[&](float x,float y){const auto [px,py]=view.detailPoint(x,y);view.pointer(ui::ArrangerView::PointerAction::Down,px,py);view.pointer(ui::ArrangerView::PointerAction::Up,px,py);view.draw(tablet);};
        tapTablet(180,142);assert(Nav::globalPage(view));
        tapTablet(722,27);assert(Nav::globalMenu(view));
        tapTablet(722,27);assert(Nav::home(view));
        Nav::openStyles(view);view.draw(tablet);assert(Nav::denseSelector(view,0));
        assert(Nav::tileHits(view)>0);
        tapTablet(44,21);assert(Nav::home(view));
    }
    controller.close();
    std::cout << "Pa5X HOME navigation: PASS 10 panes; 35 Style and 35 Keyboard Set targets across 16/16/3 positions; nested Back, Global MENU and source-switch history PASS\n";
}
