#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Pa5xHomeTabs.h"
#include "silveton/ui/Support.h"
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <iostream>

namespace silveton::ui {
struct Pa5xHomeTabTestAccess {
    static int tab(const ArrangerView& v) { return homeTabIndex(v.tab_); }
    static bool home(const ArrangerView& v) {
        return v.picker_==ArrangerView::Picker::None && v.panelMode_==ArrangerView::PanelMode::Home;
    }
    static bool catalog(const ArrangerView& v) { return v.picker_==ArrangerView::Picker::Pa5xFxCatalog; }
    static bool stylePicker(const ArrangerView& v) {
        return v.picker_==ArrangerView::Picker::Style ||
               (v.picker_==ArrangerView::Picker::KstCatalog && v.kstCatalogTab_==0) ||
               v.picker_==ArrangerView::Picker::SavedStyleLibrary;
    }
    static int player(const ArrangerView& v) { return v.selectedPlayer_; }
    static std::size_t depth(const ArrangerView& v){return v.navigationHistory_.size();}
    static bool menu(const ArrangerView& v){return v.picker_==ArrangerView::Picker::HomeMenu;}
    static bool velocity(const ArrangerView& v){return v.picker_==ArrangerView::Picker::VelocityControl;}
    static bool arrangerPrefs(const ArrangerView& v){return v.picker_==ArrangerView::Picker::ArrangerControl;}
    static bool switches(const ArrangerView& v){return v.picker_==ArrangerView::Picker::Switches;}
    static bool globalMenu(const ArrangerView& v){return v.picker_==ArrangerView::Picker::SettingsMenu&&v.globalPage_==ArrangerView::GlobalPage::Menu&&v.panelMode_==ArrangerView::PanelMode::Settings;}
    static bool globalPage(const ArrangerView& v){return v.picker_==ArrangerView::Picker::SettingsMenu&&v.globalPage_!=ArrangerView::GlobalPage::Menu;}
    static void openMenu(ArrangerView& v){v.panelMenu();}
    static void openGlobal(ArrangerView& v){v.openPanelSettings();}
    static void openGeneral(ArrangerView& v){v.openGlobalPage(ArrangerView::GlobalPage::General);}
    static void info(ArrangerView& v){v.showStyleInfo("Navigation test","Detail");}
    static void openStyles(ArrangerView& v){v.openKstCatalog(0,v.selectedPlayer_);}
    static void openUserStyles(ArrangerView& v){v.openSavedStyleLibrary(v.selectedPlayer_);}
    static void openKbd(ArrangerView& v){v.openKstCatalog(2);}
    static void openSounds(ArrangerView& v){v.openKstCatalog(1);}
    static void openUserKbd(ArrangerView& v){v.openSavedKeyboardLibrary();}
    static void openLegacyEditor(ArrangerView& v){v.openEditor(ArrangerView::Page::COMBI);}
    static bool legacyEditor(const ArrangerView& v){return v.editor_;}
    static bool wrapperDuplicate(const ArrangerView& v){
        for(const auto& hit:v.hits_)if(hit.rect.top>=7.9F&&hit.rect.bottom<=67.1F&&hit.rect.right>=1417.9F)return true;
        return false;
    }
    static void genericListRegression(ArrangerView& v){
        v.home();v.openPicker(ArrangerView::Picker::Split);
        assert(v.picker_==ArrangerView::Picker::Split);
        v.pickerPage_=5;v.pickerCategory_=0;
        const auto count=v.entries_.size();assert(count==127);
        const auto first=v.entries_.front().name;
        v.showStyleInfo("Detail","nested test");
        v.entries_.clear();v.pickerPage_=0;v.pickerCategory_=2;
        v.panelExit();assert(v.picker_==ArrangerView::Picker::Split);
        assert(v.pickerPage_==5&&v.pickerCategory_==0&&v.entries_.size()==count&&v.entries_.front().name==first);
        v.panelExit();assert(home(v)&&tab(v)==0&&depth(v)==0);
    }

    static void installSelectorFixture(ArrangerView& v) {
        auto catalog=std::make_shared<arranger::Pa5xKstCatalog>();
        catalog->rootPath="/fixture/Selector.KST";catalog->name="Selector.KST";
        catalog->recognized=true;catalog->styleListComplete=true;
        arranger::Pa5xCatalogStyleGroup root,bank;
        root.name="STYLE";root.relativePath="STYLE";root.childGroups={1};
        bank.name="Live Styles";bank.relativePath="STYLE/Live Styles";bank.parentPath="STYLE";
        for(int i=0;i<35;++i){
            arranger::Pa5xCatalogStyle st;st.name="Test Style "+std::to_string(i+1);
            st.relativePath=bank.relativePath+"/"+st.name+".stg";st.path=catalog->rootPath+"/"+st.relativePath;
            st.categoryPath=bank.relativePath;st.positionSlot=i;st.originalSettings.indexed=true;st.originalSettings.readable=true;
            st.bpm=144;st.numerator=4;st.denominator=4;st.error="Selector test fixture";
            // Unavailable entries open their own info instead of loading
            // nonexistent resources, so the test checks the exact tile identity.
            bank.styleIndices.push_back(catalog->styles.size());bank.slotStyleIndices.push_back(i);catalog->styles.push_back(st);
            arranger::Pa5xCatalogKeyboardSet ks;ks.name="Test Keyboard Set "+std::to_string(i+1);
            ks.relativePath="KEYBOARDSET/Live Sets/"+ks.name+".ksc";ks.path=catalog->rootPath+"/"+ks.relativePath;
            ks.blocker="Selector test fixture";catalog->keyboardSets.push_back(ks);
            arranger::Pa5xCatalogSound sound;sound.name="Test Sound "+std::to_string(i+1);
            sound.relativePath="SOUND/USER01.PCG";sound.path=catalog->rootPath+"/"+sound.relativePath;
            sound.blocker="Selector test fixture";catalog->sounds.push_back(sound);
        }
        bank.descendantStyleCount=35;root.descendantStyleCount=35;
        catalog->styleGroups={root,bank};catalog->discoveredStyleFiles=35;catalog->unavailableStyles=35;
        v.kstCatalog_=catalog;v.home();v.openKstCatalog(0,v.selectedPlayer_);
    }
    static std::size_t quickHits(const ArrangerView& v,bool style){
        const float left=style?24.0F:831.0F;
        std::size_t count=0;
        for(const auto& h:v.hits_){const auto& rect=h.rect;
            if(rect.left>=left-.1F&&rect.right<=left+785.1F&&rect.top>=241.9F&&rect.bottom<=437.1F&&
               std::abs(rect.width()-((785.0F+8.0F)/3.0F-8.0F))<.1F&&std::abs(rect.height()-61.0F)<.1F)++count;
        }
        return count;
    }
    static std::size_t volumeHits(const ArrangerView& v,bool keyboard){
        std::size_t count=0;
        for(const auto& h:v.hits_)if(h.drag&&h.reset&&h.resetTarget.surface==ArrangerView::ResetSurface::Volume&&
            (keyboard?h.resetTarget.player==-1:h.resetTarget.player>=0))++count;
        return count;
    }
    static void refresh(ArrangerView& v){v.refresh();}
    static void openKbdTone(ArrangerView& v,int part){v.tonePage_=0;v.openSoundWindow(true,part);}
    static RectF volumeRect(const ArrangerView& v,int part){
        for(const auto& h:v.hits_)if(h.drag&&h.reset&&h.resetTarget.surface==ArrangerView::ResetSurface::Volume&&h.resetTarget.player==-1&&h.resetTarget.part==part)
            return {v.xOffset_+v.scale_*h.rect.left,v.yOffset_+v.scale_*h.rect.top,v.xOffset_+v.scale_*h.rect.right,v.yOffset_+v.scale_*h.rect.bottom};
        assert(false);return {};
    }
    static bool emptyLibrary(const ArrangerView& v){return v.fullLibrarySelector()&&!v.kstCatalog_;}
    static bool savedStyle(const ArrangerView& v){return v.picker_==ArrangerView::Picker::SavedStyleLibrary;}
    static bool savedKbd(const ArrangerView& v){return v.picker_==ArrangerView::Picker::SavedKeyboardLibrary;}
    static void openLocalSound(ArrangerView& v){v.bankSoundsOnly_=true;v.openPicker(ArrangerView::Picker::Sound);}
    static void openLocalCombi(ArrangerView& v){v.bankSoundsOnly_=true;v.openPicker(ArrangerView::Picker::KeyboardSet);}
    static int savedPage(const ArrangerView& v){return savedStyle(v)?v.savedStylePage_:v.savedKeyboardPage_;}
    static void checkEmptyGrid(const ArrangerView& v,const Canvas& c){
        assert(emptyLibrary(v));assert(v.displayWidth_>800.0F&&v.displayHeight_==454.0F);
        const float tileWidth=(v.displayWidth_-220.0F)/3.0F;
        // Sample the drawn tile interiors and the gaps, avoiding labels.
        const auto pixel=[&](float x,float y){const auto p=v.detailPoint(x,y);return c.pixels()[static_cast<int>(p.second)*c.width()+static_cast<int>(p.first)];};
        for(int i=0;i<24;++i){const float x=208+(i/8)*(tileWidth+4),y=77+(i%8)*39;
            assert(pixel(x+tileWidth-12,y+8)!=pixel(x+tileWidth+2,y+8));}
    }
    static bool denseSelector(const ArrangerView& v,int tab) {return v.compactKstSelector()&&v.kstCatalogTab_==tab;}
    static const std::string& infoTitle(const ArrangerView& v) {return v.styleInfoTitle_;}
    static bool infoOpen(const ArrangerView& v) {return v.picker_==ArrangerView::Picker::StyleInfo;}
    static float width(const ArrangerView& v){return v.displayWidth_;}
    static std::size_t tileHits(const ArrangerView& v) {
        std::size_t count=0;
        for(const auto& h:v.hits_){
            const auto& r=h.rect;
            const float z=v.displayZoom_;
            const float tileWidth=(v.displayWidth_-220.0F)/3.0F;
            if(r.left>=v.displayLeft_+208*z-.1F && r.right<=v.displayLeft_+v.displayWidth_*z+.1F &&
               r.top>=v.displayTop_+77*z-.1F && r.bottom<=v.displayTop_+386*z+.1F &&
               std::abs(r.width()-tileWidth*z)<.1F && std::abs(r.height()-36*z)<.1F)++count;
        }
        return count;
    }

};
}

int main(int argc,char** argv){
    assert(argc==2);
    using namespace silveton;
    assert(ui::kPa5xHomeTabs.size()==10);
    for(std::size_t i=0;i<ui::kPa5xHomeTabs.size();++i)
        assert(ui::homeTabIndex(ui::homeTabAt(i))==static_cast<int>(i));
    assert(ui::homeTabAt(123)==ui::Pa5xHomeTab::Main);
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char temporary[]="/tmp/silveton-home-tabs-XXXXXX";
    const char* directory=::mkdtemp(temporary);assert(directory);
    ui::ControllerEnv env;env.dataDir=directory;
    ui::SamplerAppController controller(env);
    ui::ArrangerView view(controller);
    ui::Canvas canvas(1640,1040);
    const auto click=[&](float x,float y){
        view.pointer(ui::ArrangerView::PointerAction::Down,x,y);
        view.pointer(ui::ArrangerView::PointerAction::Up,x,y);
        view.draw(canvas);
    };
    const auto liveTabX=[](int i){
        constexpr float start=24.0F,end=1616.0F,gap=4.0F;
        constexpr float width=(end-start-gap*9.0F)/10.0F;
        return start+(width+gap)*i+width*0.5F;
    };
    view.draw(canvas);
    const auto initial=host::arrangerHost().snapshot(0);
    for(int i=0;i<10;++i){
        click(liveTabX(i),843.0F);
        assert(ui::Pa5xHomeTabTestAccess::tab(view)==i);
        assert(ui::Pa5xHomeTabTestAccess::home(view));
        assert(ui::Pa5xHomeTabTestAccess::depth(view)==0);
        const auto after=host::arrangerHost().snapshot(0);
        assert(after.playing==initial.playing);
        assert(after.styleSelectionSerial==initial.styleSelectionSerial);
    }
    // Jukebox is clearly a two-STYLE-player panel. Its real Focus button
    // changes the working player, without launching/stopping a style.
    click(liveTabX(7),843.0F);
    const auto localClick=[&](float x,float y){const auto [px,py]=view.detailPoint(x,y);click(px,py);};
    localClick(406+318,326.0F);
    assert(ui::Pa5xHomeTabTestAccess::player(view)==1);
    // Kaoss does NOT pretend a DSP XY algorithm exists; the FX Catalog is real.
    click(liveTabX(9),843.0F);
    localClick(582.0F,364.0F);
    assert(ui::Pa5xHomeTabTestAccess::catalog(view));
    // No transport operation was attempted by this navigation-only test.
    assert(host::arrangerHost().snapshot(0).playing==initial.playing);
    using Nav=ui::Pa5xHomeTabTestAccess;
    // Physical/Android Back from FX returns to Kaoss, then MAIN, exactly once.
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::tab(view)==9);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::tab(view)==0&&Nav::depth(view)==0);
    // Nested detail Back uses the same handler as Escape. Check the real
    // touch target, not just a direct state change.
    Nav::openMenu(view);view.draw(canvas);assert(Nav::menu(view)&&!Nav::wrapperDuplicate(view));
    localClick(100,374);assert(Nav::switches(view)&&Nav::depth(view)==2);
    localClick(728,23);assert(Nav::menu(view)&&Nav::depth(view)==1);
    localClick(100,374);assert(Nav::switches(view)&&Nav::depth(view)==2);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::menu(view)&&Nav::depth(view)==1);
    Nav::info(view);view.draw(canvas);assert(Nav::infoOpen(view)&&Nav::depth(view)==2);
    const auto detailBack=[&]{localClick(48,19);};
    detailBack();assert(Nav::menu(view)&&Nav::depth(view)==1);
    Nav::openLegacyEditor(view);view.draw(canvas);assert(Nav::legacyEditor(view));
    click(80,22);assert(Nav::menu(view)&&Nav::depth(view)==1);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::openGlobal(view);view.draw(canvas);assert(Nav::globalMenu(view));
    for(int i=0;i<5;++i){Nav::openGeneral(view);assert(Nav::globalPage(view)&&Nav::depth(view)==2);Nav::openMenu(view);assert(Nav::globalMenu(view)&&Nav::depth(view)==1);}
    Nav::openGeneral(view);Nav::openGlobal(view);assert(Nav::globalMenu(view)&&Nav::depth(view)==1);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::genericListRegression(view);
    // No SET: MAIN remains the mixer. The fallback pickers have 24 empty cells.
    view.draw(canvas);
    click(24+100,125);assert(Nav::savedStyle(view));Nav::checkEmptyGrid(view,canvas);
    const float emptyWidth=Nav::width(view);
    localClick(emptyWidth-27,413);assert(Nav::savedPage(view)==1);
    Nav::checkEmptyGrid(view,canvas);
    localClick(44,21);assert(Nav::home(view));
    Nav::openUserKbd(view);view.draw(canvas);assert(Nav::savedKbd(view));Nav::checkEmptyGrid(view,canvas);
    assert(std::abs(Nav::width(view)-emptyWidth)<.001F);
    localClick(emptyWidth-27,413);assert(Nav::savedPage(view)==1);
    localClick(44,21);assert(Nav::home(view));
    Nav::openLocalSound(view);view.draw(canvas);Nav::checkEmptyGrid(view,canvas);
    localClick(44,21);assert(Nav::home(view));
    Nav::openLocalCombi(view);view.draw(canvas);Nav::checkEmptyGrid(view,canvas);
    localClick(44,21);assert(Nav::home(view));

    // 35 items cover all 24 tile positions and a page transition.
    ui::Pa5xHomeTabTestAccess::installSelectorFixture(view);view.draw(canvas);
    for(int i=0;i<6;++i){Nav::openUserStyles(view);Nav::openStyles(view);assert(Nav::depth(view)==1);}
    view.keyDown(ui::ArrangerView::Key::Escape);assert(Nav::home(view)&&Nav::depth(view)==0);
    Nav::openKbd(view);for(int i=0;i<6;++i){Nav::openUserKbd(view);Nav::openKbd(view);assert(Nav::depth(view)==1);}
    view.keyDown(ui::ArrangerView::Key::Escape);assert(Nav::home(view)&&Nav::depth(view)==0);
    // MAIN never contains the obsolete mini libraries, even with a catalog.
    view.draw(canvas);
    assert(Nav::quickHits(view,true)==0&&Nav::quickHits(view,false)==0);
    assert(controller.engine.nativeClearPerformance());
    for(int part:{0,1,2,6})assert(controller.engine.nativeAssignUpperSound(0,0,9001,part));
    Nav::refresh(view);view.draw(canvas);
    assert(Nav::volumeHits(view,true)==4);
    const auto drag=[&](float x){
        view.pointer(ui::ArrangerView::PointerAction::Down,x,370);
        view.pointer(ui::ArrangerView::PointerAction::Move,x,394);
        view.pointer(ui::ArrangerView::PointerAction::Up,x,394);
        Nav::refresh(view);view.draw(canvas);
    };
    for(int i=0;i<4;++i){
        auto before=controller.engine.nativeKeyboardCombi();assert(before);
        drag(880+i*200.0F);
        auto after=controller.engine.nativeKeyboardCombi();assert(after);
        int part=i==3?6:i;
        assert(after->part(part).levelDb<before->part(part).levelDb);
        for(int other:{0,1,2,6})if(other!=part)assert(after->part(other).levelDb==before->part(other).levelDb);
    }
    // Actual tablet-sized view: no jump on grab, fine drag, reversal, reset.
    {
        ui::Canvas tablet(1340,800);view.draw(tablet);
        const auto rect=Nav::volumeRect(view,0);
        assert(rect.height()>140.0F);
        const float x=rect.centerX(),y=rect.centerY();
        const float initial=controller.engine.nativeKeyboardCombi()->part(0).levelDb;
        const auto move=[&](ui::ArrangerView::PointerAction a,float dy,std::int64_t time){view.pointer(a,x,y+dy,time);};
        using A=ui::ArrangerView::PointerAction;
        move(A::Down,0,1000);assert(controller.engine.nativeKeyboardCombi()->part(0).levelDb==initial);
        move(A::Move,2,1010);assert(controller.engine.nativeKeyboardCombi()->part(0).levelDb==initial);
        move(A::Move,10,1020);const float reduced=controller.engine.nativeKeyboardCombi()->part(0).levelDb;
        assert(reduced<initial&&initial-reduced<=1.2F);
        move(A::Move,20,1030);const float reduced2=controller.engine.nativeKeyboardCombi()->part(0).levelDb;
        assert(reduced2<reduced&&reduced-reduced2<1.6F);
        move(A::Move,10,1040);assert(controller.engine.nativeKeyboardCombi()->part(0).levelDb>reduced2);
        move(A::Up,10,1050);Nav::refresh(view);view.draw(tablet);
        move(A::Down,0,2000);move(A::Up,0,2040);
        const float beforeReset=controller.engine.nativeKeyboardCombi()->part(0).levelDb;assert(beforeReset!=0.0F);
        move(A::Down,0,2160);move(A::Up,0,2200);
        assert(std::abs(controller.engine.nativeKeyboardCombi()->part(0).levelDb)<0.01F);
        Nav::refresh(view);view.draw(canvas);
    }
    click(1412,125); // UPPER Link
    auto before=controller.engine.nativeKeyboardCombi();drag(880);
    auto after=controller.engine.nativeKeyboardCombi();
    for(int part=0;part<3;++part)assert(after->part(part).levelDb<before->part(part).levelDb);
    assert(after->part(6).levelDb==before->part(6).levelDb);
    click(1412,125);
    click(1305,125);assert(Nav::denseSelector(view,2)&&Nav::tileHits(view)==24);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);
    assert(Nav::home(view)&&Nav::volumeHits(view,true)==4);
    click(120,125);assert(Nav::denseSelector(view,0)&&Nav::tileHits(view)==24);
    view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);
    assert(Nav::home(view)&&Nav::volumeHits(view,true)==4);
    Nav::openStyles(view);view.draw(canvas);
    const auto checkPages=[&](int tab,const std::string& prefix){
        assert(ui::Pa5xHomeTabTestAccess::denseSelector(view,tab));
        localClick(50,98);
        const int perPage=24;
        const int pages=(35+perPage-1)/perPage;
        const float width=Nav::width(view),tileWidth=(width-220.0F)/3.0F;
        for(int page=0;page<pages;++page){
            if(page>0)localClick(width-27,413);
            const int count=std::min(perPage,35-page*perPage);
            assert(Nav::tileHits(view)==static_cast<std::size_t>(count));
            for(int i=0;i<count;++i){
                localClick(208+(i/8)*(tileWidth+4)+tileWidth*.5F,77+(i%8)*39+18);
                assert(Nav::infoOpen(view));
                assert(Nav::infoTitle(view)==prefix+std::to_string(page*perPage+i+1));
                view.keyDown(ui::ArrangerView::Key::Escape);view.draw(canvas);
                assert(Nav::denseSelector(view,tab));
            }
        }
        for(int page=1;page<pages;++page)localClick(230,413);
        assert(Nav::tileHits(view)==static_cast<std::size_t>(perPage));
    };
    checkPages(0,"Test Style ");
    localClick(490,21);checkPages(2,"Test Keyboard Set ");
    localClick(220,21);assert(ui::Pa5xHomeTabTestAccess::denseSelector(view,0));
    localClick(44,21);assert(ui::Pa5xHomeTabTestAccess::home(view));assert(Nav::depth(view)==0);
    Nav::openSounds(view);view.draw(canvas);checkPages(1,"Test Sound ");
    localClick(44,21);assert(Nav::home(view)&&Nav::depth(view)==0);
    assert(host::arrangerHost().snapshot(0).playing==initial.playing);
    assert(host::arrangerHost().snapshot(0).styleSelectionSerial==initial.styleSelectionSerial);
    // Tablet pixel sizes: verify real drawing and touch transforms, page fit,
    // no stretch, and no overlap with the reserved live navigation/transport.
    for(const auto& dimensions : {std::pair<int,int>{1340,800},{1920,1080},{1280,800}}){
        ui::Canvas tablet(dimensions.first,dimensions.second);
        Nav::openGlobal(view);view.draw(tablet);assert(Nav::globalMenu(view));
        const auto [x0,y0]=view.detailPoint(0,0);
        const auto [x1,y1]=view.detailPoint(800,480);
        const float w=x1-x0,h=y1-y0;
        assert(x0>=0&&y0>=0&&x1<=dimensions.first+.1F&&y1<=dimensions.second+.1F);
        assert(std::abs(w/800.0F-h/480.0F)<.001F);
        assert(w/dimensions.first>.78F&&h/dimensions.second>.86F);
        const auto tapTablet=[&](float x,float y){const auto [px,py]=view.detailPoint(x,y);view.pointer(ui::ArrangerView::PointerAction::Down,px,py);view.pointer(ui::ArrangerView::PointerAction::Up,px,py);view.draw(tablet);};
        tapTablet(180,350);assert(Nav::arrangerPrefs(view));
        tapTablet(520,26);assert(Nav::velocity(view));
        tapTablet(715,26);assert(Nav::arrangerPrefs(view));
        tapTablet(735,26);assert(Nav::globalMenu(view));
        tapTablet(180,142);assert(Nav::globalPage(view));
        tapTablet(722,27);assert(Nav::globalMenu(view));
        tapTablet(722,27);assert(Nav::home(view));
        Nav::openStyles(view);view.draw(tablet);assert(Nav::denseSelector(view,0));
        assert(Nav::tileHits(view)==24);
        const float styleWidth=Nav::width(view);
        tapTablet(490,21);assert(Nav::denseSelector(view,2)&&Nav::tileHits(view)==24);
        assert(std::abs(Nav::width(view)-styleWidth)<.001F);
        tapTablet(44,21);assert(Nav::home(view));
    }
    // The large Style Play Sound editor edits the same CC5/65 used by the
    // original oscillator. Test actual pointer controls, not direct callbacks.
    using namespace sampler;
    auto imported=std::make_shared<Program>();imported->name="Pa Legato fixture";
    imported->sourceVoiceAssignment={true,8U,12U,true,1U,0U};imported->mono=true;imported->legato=true;
    auto pcm=std::make_shared<SampleData>();pcm->channels=1;pcm->sampleRate=48000;pcm->rootKey=60;
    pcm->interleaved.resize(256U,.005F);
    auto ms=std::make_shared<Multisample>();SampleZone zone;zone.sample=pcm;zone.rootKey=60;ms->zones.push_back(zone);
    ProgramLayer osc;osc.multisample=ms;osc.sourcePortamento={true,false,8U,9U,91U,2U,{}};imported->layers.push_back(osc);
    assert(controller.engine.nativeAssignPreparedKeyboardSound(0,imported));
    assert(controller.engine.nativeAssignPreparedKeyboardSound(1,imported));
    Nav::refresh(view);Nav::openKbdTone(view,0);view.draw(canvas);
    const auto editedPorta=[&](int part,int cc){return controller.engine.nativeKeyboardCombi()->part(part).sourceSoundEdits.controller(cc);};
    assert(editedPorta(0,5)==30&&editedPorta(1,5)==30);
    click(1132,780); // Portamento Time numeric cell -> fine adjustment
    click(1200,550); // +1
    assert(editedPorta(0,5)==31&&editedPorta(1,5)==30);
    click(1500,335); // Back from fine adjustment
    click(815,690); // Portamento Off, without zeroing its time
    assert(editedPorta(0,65)==0&&editedPorta(0,5)==31&&editedPorta(1,65)==-1);
    click(815,690); // Portamento On again
    assert(editedPorta(0,65)==127&&editedPorta(0,5)==31);
    click(1132,780);click(820,760); // Use Sound: restore raw inherited time
    assert(editedPorta(0,5)==-1&&imported->layers[0].sourcePortamento.timeRaw==91);
    assert(editedPorta(1,5)==30);
    click(1500,335);click(285,50);click(350,520); // Reset current track: clear both CCs
    assert(editedPorta(0,5)==-1&&editedPorta(0,65)==-1);
    assert(editedPorta(1,5)==30);
    click(1480,50); // Done
    controller.close();
    std::cout << "Pa5X HOME navigation: PASS 10 panes; 35 Style, 35 Keyboard Set and 35 Sound targets across 24/11 positions; empty USER/Sound/COMBI full-size grids, nested Back, Global MENU and source-switch history PASS\n";
}
