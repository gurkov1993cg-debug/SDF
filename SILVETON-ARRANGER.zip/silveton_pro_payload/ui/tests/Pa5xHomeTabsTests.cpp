#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Pa5xHomeTabs.h"
#include "silveton/ui/Support.h"
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <iostream>

namespace silveton::ui {
struct Pa5xHomeTabTestAccess {
    static int tab(const ArrangerView& v) { return homeTabIndex(v.tab_); }
    static bool home(const ArrangerView& v) {
        return v.picker_==ArrangerView::Picker::None && v.panelMode_==ArrangerView::PanelMode::Home;
    }
    static bool catalog(const ArrangerView& v) { return v.picker_==ArrangerView::Picker::Pa5xFxCatalog; }
    static bool stylePicker(const ArrangerView& v) {
        return v.picker_==ArrangerView::Picker::Style ||
               (v.picker_==ArrangerView::Picker::KstCatalog && v.kstCatalogTab_==0) ||
               v.picker_==ArrangerView::Picker::SavedStyleLibrary;
    }
    static int player(const ArrangerView& v) { return v.selectedPlayer_; }
};
}

int main(int argc,char** argv){
    assert(argc==2);
    using namespace silveton;
    assert(ui::kPa5xHomeTabs.size()==10);
    for(std::size_t i=0;i<ui::kPa5xHomeTabs.size();++i)
        assert(ui::homeTabIndex(ui::homeTabAt(i))==static_cast<int>(i));
    assert(ui::homeTabAt(123)==ui::Pa5xHomeTab::Main);
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char temporary[]="/tmp/silveton-home-tabs-XXXXXX";
    const char* directory=::mkdtemp(temporary);assert(directory);
    ui::ControllerEnv env;env.dataDir=directory;
    ui::SamplerAppController controller(env);
    ui::ArrangerView view(controller);
    ui::Canvas canvas(1640,1040);
    const auto click=[&](float x,float y){
        view.pointer(ui::ArrangerView::PointerAction::Down,x,y);
        view.pointer(ui::ArrangerView::PointerAction::Up,x,y);
        view.draw(canvas);
    };
    const auto liveTabX=[](int i){
        constexpr float start=24.0F,end=1616.0F,gap=4.0F;
        constexpr float width=(end-start-gap*9.0F)/10.0F;
        return start+(width+gap)*i+width*0.5F;
    };
    view.draw(canvas);
    const auto initial=host::arrangerHost().snapshot(0);
    for(int i=0;i<10;++i){
        click(liveTabX(i),843.0F);
        assert(ui::Pa5xHomeTabTestAccess::tab(view)==i);
        assert(ui::Pa5xHomeTabTestAccess::home(view));
        const auto after=host::arrangerHost().snapshot(0);
        assert(after.playing==initial.playing);
        assert(after.styleSelectionSerial==initial.styleSelectionSerial);
    }
    // Jukebox is clearly a two-STYLE-player panel. Its real Focus button
    // changes the working player, without launching/stopping a style.
    click(liveTabX(7),843.0F);
    constexpr float left=(1640.0F-800.0F*1.61F)*0.5F, top=78.0F;
    click(left+1.61F*(406+318),top+1.61F*326.0F);
    assert(ui::Pa5xHomeTabTestAccess::player(view)==1);
    // Kaoss does NOT pretend a DSP XY algorithm exists; the FX Catalog is real.
    click(liveTabX(9),843.0F);
    click(left+1.61F*582.0F,top+1.61F*364.0F);
    assert(ui::Pa5xHomeTabTestAccess::catalog(view));
    // No transport operation was attempted by this navigation-only test.
    assert(host::arrangerHost().snapshot(0).playing==initial.playing);
    controller.close();
    std::cout << "Pa5X HOME navigation: PASS 10 real panes, selected player, FX editor route\n";
}
