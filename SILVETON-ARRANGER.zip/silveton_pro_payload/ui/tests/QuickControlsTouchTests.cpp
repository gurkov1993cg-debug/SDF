// Tablet pointer dispatch, parameter scope and SET/LIST round trips of the
// consolidated ADSR/voice/portamento/pitch page. No direct hit callbacks.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;
#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct ViewTestAccess {
    static void quick(View& v, bool legacyEnvelope = false) {
        v.page_ = View::Page::COMBI;
        v.combiMode_ = View::MODE_EDIT;
        v.editGroup_ = legacyEnvelope ? View::EG_ENVELOPE : View::EG_VOICE;
        v.selectedUpper_ = 0;
        v.stripSound[0] = 0;
        v.invalidate();
    }
    static void hiddenLink(View& v) {
        v.linkOn = true;
        v.markMode = true;
        v.marked.fill(true);
    }
    static bool isolated(const View& v) { return !v.linkOn && !v.markMode && v.editGroup_ == View::EG_VOICE; }
    static void setup(View& v) { v.editGroup_ = View::EG_PARTTUNE; v.invalidate(); }
    static void range(View& v) { v.editGroup_ = View::EG_RANGE; v.invalidate(); }
    static RectF key(const View& v, const std::string& label) {
        CHECK(!v.dialogStack.empty());
        for (const auto& key : v.dialogStack.back()->kbKeys) if (key.label == label) return key.rect;
        throw std::runtime_error("Missing touch keyboard key: " + label);
    }
};
}

namespace {
using Access = classic::ViewTestAccess;
bool near(float a, float b) { return std::fabs(a - b) < .001F; }
ControllerEnv environment() {
    char dir[] = "/tmp/silveton-quick-touch-XXXXXX";
    CHECK(::mkdtemp(dir));
    ControllerEnv env;
    env.dataDir = dir;
    return env;
}
struct Fixture {
    SamplerAppController controller{environment()};
    View view{controller};
    Canvas canvas{1340, 800};
    std::int64_t time{1000};
    Fixture() {
        CHECK(controller.engine.nativeClearPerformance());
        for (int u = 0; u < 7; ++u) {
            CHECK(controller.assignUpperSound(u, {0, 0, 9001, "SINE"}));
            CHECK(controller.setUpperParam(u, 48, 2));
            for (int l = 0; l < 4; ++l) CHECK(controller.setLayerSound(u, l, 9001));
        }
        view.setSoftKeyboard(true);
        view.refreshAllForTests();
        Access::quick(view);
        draw();
    }
    void draw() { setFixedClockForTests(time); view.draw(canvas); }
    void tap(float x, float y) {
        time += 1000;
        setFixedClockForTests(time);
        view.pointer(View::PointerAction::Down, x, y);
        view.pointer(View::PointerAction::Up, x, y);
        draw();
    }
    void drag(float x, float y, float toX, float toY) {
        time += 1000;
        setFixedClockForTests(time);
        view.pointer(View::PointerAction::Down, x, y);
        view.pointer(View::PointerAction::Move, toX, toY);
        view.pointer(View::PointerAction::Up, toX, toY);
        draw();
    }
    void key(const std::string& label) {
        const RectF r = Access::key(view, label);
        tap(r.centerX(), r.centerY());
    }
    void typeNumber(float x, float y, const std::string& text, bool apply = true) {
        tap(x, y);
        CHECK(view.dialogOpen());
        key("CLEAR");
        for (char ch : text) {
            if (ch != '-') key(std::string(1, ch));
        }
        if (!text.empty() && text[0] == '-') key("±");
        tap(apply ? 980.F : 360.F, 697.F);
        CHECK(!view.dialogOpen());
    }
    auto state(int u = 0) { return *controller.upperState(u); }
    std::vector<float> layer(int u, int sound) { return controller.layerParams(u, sound - 1); }
    void sound(int k) { tap(776.6F + k * 119.2F, 190); }
    void upper(int u) { tap(109.F + u * 187.F, 126); }
};

void limitsUnitsAndTouch() {
    Fixture f;
    // A hidden LINK/MARK from the mixer must not alter the touch editor scope.
    Access::hiddenLink(f.view);
    Access::quick(f.view, true);
    f.draw();
    CHECK(Access::isolated(f.view));
    f.tap(1200, 514); CHECK(f.state().octave == 1 && f.state(1).octave == 0);
    f.tap(900, 514); CHECK(f.state().octave == 0);
    f.tap(1200, 578); CHECK(f.state().transpose == 1 && f.state(1).transpose == 0);
    f.tap(900, 578); CHECK(f.state().transpose == 0);
    f.tap(1200, 642); CHECK(near(f.state().fineCents, 1));
    f.tap(900, 642); CHECK(near(f.state().fineCents, 0));
    f.typeNumber(1052, 514, "99"); CHECK(f.state().octave == 4);
    f.tap(1200, 514); CHECK(f.state().octave == 4);
    f.typeNumber(1052, 514, "-99"); CHECK(f.state().octave == -4);
    f.tap(900, 514); CHECK(f.state().octave == -4);
    f.typeNumber(1052, 578, "99"); CHECK(f.state().transpose == 12);
    f.tap(1200, 578); CHECK(f.state().transpose == 12);
    f.typeNumber(1052, 578, "-99"); CHECK(f.state().transpose == -12);
    f.tap(900, 578); CHECK(f.state().transpose == -12);
    f.typeNumber(1052, 642, "9999"); CHECK(near(f.state().fineCents, 1200));
    f.typeNumber(1052, 642, "-9999"); CHECK(near(f.state().fineCents, -1200));
    f.typeNumber(1052, 642, "25.5"); CHECK(near(f.state().fineCents, 25.5F));
    f.typeNumber(1052, 642, "71", false); CHECK(near(f.state().fineCents, 25.5F));
    f.typeNumber(1052, 706, "99"); CHECK(f.state().pitchBendRange == 24);
    f.tap(1200, 706); CHECK(f.state().pitchBendRange == 24);
    f.typeNumber(1052, 706, "0"); f.tap(900, 706); CHECK(f.state().pitchBendRange == 0);
    CHECK(f.controller.upperParams(0).at(48) == 0);
    // The tablet's simultaneous −/+ gesture resets once, without a later Up step.
    f.view.pointer(View::PointerAction::Down, 900, 706);
    f.view.secondPointerDown(1200, 706);
    f.view.pointer(View::PointerAction::Up, 900, 706);
    f.draw(); CHECK(f.state().pitchBendRange == 2);
    f.typeNumber(116, 400, "125"); CHECK(near(f.state().toneAttackMs, 125));
    f.typeNumber(296, 400, "480"); CHECK(near(f.state().toneDecayMs, 480));
    f.typeNumber(476, 400, "37"); CHECK(near(f.state().toneSustain, .37F));
    f.typeNumber(656, 400, "830"); CHECK(near(f.state().toneReleaseMs, 830));
    f.drag(116, 330, 116, 310); CHECK(f.state().toneAttackMs > 125);
    f.tap(296, 300); CHECK(f.state().toneDecayMs > 480);
    f.tap(476, 348); CHECK(near(f.state().toneSustain, 0));
    f.tap(656, 300); CHECK(f.state().toneReleaseMs > 830);
    for (int mode = 0; mode < 3; ++mode) {
        f.tap(868.F + mode * 174.F, 329); CHECK(f.state().voiceMode == mode);
        CHECK(f.state(1).voiceMode == 0);
    }
    // SILVETON time is milliseconds; the other modes use the existing 0..127 parameter.
    f.typeNumber(558, 594, "30"); CHECK(near(f.state().portamentoSec, .03F));
    f.drag(200, 674, 240, 674); CHECK(f.state().portamentoSec > .03F);
    f.tap(400, 674); CHECK(near(f.state().portamentoSec, .065F));
    f.tap(254, 520); f.typeNumber(558, 594, "93");
    CHECK(f.controller.upperParams(0).at(42) == 1 && f.controller.upperParams(0).at(45) == 93);
    f.tap(100, 594); CHECK(f.controller.upperParams(0).at(43) == 1);
    f.tap(400, 594); CHECK(f.controller.upperParams(0).at(44) == 1);
    f.tap(402, 520); CHECK(f.controller.upperParams(0).at(42) == 2);
    f.tap(550, 520); f.typeNumber(558, 594, "127");
    CHECK(f.controller.upperParams(0).at(42) == 3 && f.controller.upperParams(0).at(45) == 127);
    f.tap(250, 594); CHECK(f.controller.upperParams(0).at(44) == 0);
    f.tap(106, 520); CHECK(near(f.state().portamentoSec, .065F));
    f.tap(254, 520); CHECK(f.controller.upperParams(0).at(45) == 127);
    std::puts("PASS real pointer pitch limits/units/keypad/cancel/pair reset, ADSR sliders and portamento mode state");
}

void allPlacesAndPersistence() {
    Fixture f;
    for (int u = 0; u < 7; ++u) {
        f.upper(u);
        for (int sound = 0; sound < 5; ++sound) {
            f.sound(sound);
            f.tap(1200, 514); f.tap(1200, 578); f.tap(1200, 642);
            CHECK(f.state(u).octave == 1 && f.state(u).transpose == 1 && near(f.state(u).fineCents, 1));
            for (int l = 1; l <= 4; ++l) {
                const auto p = f.layer(u, l);
                const float expected = l <= sound ? 1.F : 0.F;
                CHECK(p.at(3) == expected && p.at(4) == expected && p.at(5) == expected);
            }
        }
        // Bend remains per Upper even while L4 is chosen.
        f.tap(1200, 706); CHECK(f.state(u).pitchBendRange == 3);
        for (int other = u + 1; other < 7; ++other) {
            CHECK(f.state(other).octave == 0 && f.state(other).transpose == 0 && near(f.state(other).fineCents, 0));
            CHECK(f.state(other).pitchBendRange == 2);
        }
    }
    f.upper(0); f.sound(1);
    f.typeNumber(1052, 514, "99"); CHECK(f.layer(0, 1).at(4) == 3 && f.state().octave == 1);
    f.typeNumber(1052, 514, "-99"); CHECK(f.layer(0, 1).at(4) == -3);
    CHECK(f.controller.setLayerParam(0, 0, 5, 500));
    f.view.refreshAllForTests(); f.draw();
    f.tap(1200, 642); CHECK(f.layer(0, 1).at(5) == 501);
    f.tap(900, 642); f.tap(900, 642); CHECK(f.layer(0, 1).at(5) == 499);
    f.typeNumber(1052, 642, "9999"); CHECK(f.layer(0, 1).at(5) == 1200 && near(f.state().fineCents, 1));
    f.typeNumber(1052, 642, "-9999"); CHECK(f.layer(0, 1).at(5) == -1200);
    f.typeNumber(476, 400, "42"); CHECK(near(f.layer(0, 1).at(12), .42F));
    CHECK(!near(f.state().toneSustain, .42F));
    CHECK(f.layer(0, 2).at(12) != .42F && f.layer(1, 1).at(12) != .42F);
    // A MIDI range scan must stop when its controls leave the screen.
    Access::range(f.view); f.draw(); f.tap(392, 457);
    CHECK(f.controller.keyScanUpper() == 0 && f.controller.keyScanSound() == 1);
    f.upper(1); CHECK(f.controller.keyScanUpper() == -1);
    f.upper(0); f.tap(392, 457); CHECK(f.controller.keyScanUpper() == 0);
    f.tap(120, 246); CHECK(f.controller.keyScanUpper() == -1 && Access::isolated(f.view));
    Access::setup(f.view); f.draw();
    f.typeNumber(420, 430, "23"); CHECK(f.controller.portaBalance() == 23);
    f.typeNumber(710, 430, "148"); CHECK(f.controller.portaNear() == 148);
    f.typeNumber(1098, 432, "360"); CHECK(f.controller.upperParams(0).at(49) == 360);
    CHECK(f.controller.upperParams(1).at(49) == 0);
    CHECK(f.controller.writeCombiToList(5, "QUICK TOUCH") == 5);
    CHECK(!f.controller.saveSetAs("QUICK TOUCH"));
    CHECK(f.controller.engine.nativeClearPerformance());
    CHECK(!f.controller.loadSavedSet("QUICK TOUCH"));
    for (int u = 0; u < 7; ++u) {
        CHECK(f.state(u).octave == 1 && f.state(u).transpose == 1 && near(f.state(u).fineCents, 1));
        CHECK(f.state(u).pitchBendRange == 3 && f.controller.upperParams(u).at(48) == 3);
        for (int sound = 1; sound <= 4; ++sound) {
            const auto p = f.layer(u, sound);
            CHECK(p.at(3) == 1);
            CHECK(p.at(4) == (u == 0 && sound == 1 ? -3 : 1));
            CHECK(p.at(5) == (u == 0 && sound == 1 ? -1200 : 1));
        }
    }
    CHECK(f.controller.portaBalance() == 23 && f.controller.portaNear() == 148);
    CHECK(f.controller.upperParams(0).at(49) == 360 && near(f.layer(0, 1).at(12), .42F));
    CHECK(f.controller.activateListEntry(0, 0, 0, 5));
    CHECK(f.state().transpose == 1 && f.state().pitchBendRange == 3);
    CHECK(f.layer(0, 1).at(4) == -3 && f.layer(0, 1).at(5) == -1200);
    std::puts("PASS all 35 Upper/sound places stay isolated; distinct MAIN/layer ranges and complete SET/LIST recall");
}
}

int main(int argc, char** argv) {
    if (argc < 2) return 2;
    setFontDirectory(argv[1]);
    if (!fontsReady()) return 2;
    try { limitsUnitsAndTouch(); allPlacesAndPersistence(); }
    catch (const std::exception& e) { std::fprintf(stderr, "FAIL %s\n", e.what()); return 1; }
    return 0;
}
