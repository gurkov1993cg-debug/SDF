#include "RetainedSceneFixture.h"
#include "GlRenderer.h"

#include <cstdint>
#include <cstdlib>
#include <dlfcn.h>
#include <memory>

using namespace retained_test;
using silveton::gl::GlRenderer;

namespace {
constexpr int kWidth=420,kHeight=280;
struct Stats { long long pixels{0};int instances{0};bool cacheHit{false}; };

void checkOriginalFullBaseline(const std::vector<std::uint32_t>& pixels) {
    const char* path=std::getenv("SILVETON_RETAINED_BASELINE_PPM");
    if(!path)return;
    FILE* input=std::fopen(path,"rb");RETAINED_CHECK(input!=nullptr);
    char magic[3]{};int width=0,height=0,maximum=0;
    const int parsed=std::fscanf(input,"%2s%d%d%d",magic,&width,&height,&maximum);
    RETAINED_CHECK(parsed==4&&std::string(magic)=="P6"&&width==kWidth&&height==kHeight&&maximum==255);
    RETAINED_CHECK(std::fgetc(input)=='\n');
    std::vector<unsigned char> rgb(pixels.size()*3U);
    const auto count=std::fread(rgb.data(),1,rgb.size(),input);std::fclose(input);
    RETAINED_CHECK(count==rgb.size());
    std::vector<std::uint32_t> expected(pixels.size());
    for(std::size_t i=0;i<expected.size();++i)expected[i]=0xFF000000U|
        (static_cast<std::uint32_t>(rgb[i*3U])<<16U)|(static_cast<std::uint32_t>(rgb[i*3U+1U])<<8U)|rgb[i*3U+2U];
    expectPixels(pixels,expected,"original full-renderer visual baseline");
    std::puts("PASS original full-renderer visual baseline: all 117600 pixels identical");
}

void failureDiagnostics(const std::vector<std::uint32_t>& got,
                        const std::vector<std::uint32_t>& expected,int width,int height) {
    if(differences(got,expected)==0)return;
    int x0=width,y0=height,x1=-1,y1=-1,maxDelta[4]{};
    std::size_t counts[4]{},opaque=0,flipped=0,shown=0;
    for(int y=0;y<height;++y)for(int x=0;x<width;++x) {
        const auto i=static_cast<std::size_t>(y*width+x);
        if(got[i]!=expected[static_cast<std::size_t>((height-y-1)*width+x)])++flipped;
        if(got[i]==expected[i])continue;
        x0=std::min(x0,x);x1=std::max(x1,x);y0=std::min(y0,y);y1=std::max(y1,y);
        if((got[i]>>24U)==255U&&(expected[i]>>24U)==255U)++opaque;
        if(shown++<12U)std::fprintf(stderr,"pixel (%d,%d): retained=%08x full=%08x\n",x,y,got[i],expected[i]);
        for(unsigned channel=0;channel<4;++channel) {
            const int a=static_cast<int>((got[i]>>(channel*8U))&255U);
            const int b=static_cast<int>((expected[i]>>(channel*8U))&255U);
            if(a!=b)++counts[channel];
            maxDelta[channel]=std::max(maxDelta[channel],std::abs(a-b));
        }
    }
    std::fprintf(stderr,"difference bounds=(%d,%d)-(%d,%d) opaque=%zu flipped_diff=%zu\n"
        "BGRA differing=%zu,%zu,%zu,%zu max_delta=%d,%d,%d,%d\n",x0,y0,x1,y1,opaque,flipped,
        counts[0],counts[1],counts[2],counts[3],maxDelta[0],maxDelta[1],maxDelta[2],maxDelta[3]);
    if(const char* output=std::getenv("SILVETON_RETAINED_DIAGNOSTICS")) {
        for(int which=0;which<2;++which) {
            const std::string path=std::string(output)+(which==0?"/retained.ppm":"/full.ppm");
            if(FILE* f=std::fopen(path.c_str(),"wb")) {
                std::fprintf(f,"P6\n%d %d\n255\n",width,height);
                for(auto p:which==0?got:expected) {
                    const unsigned char rgb[]{static_cast<unsigned char>(p>>16U),static_cast<unsigned char>(p>>8U),static_cast<unsigned char>(p)};
                    std::fwrite(rgb,1,3,f);
                }
                std::fclose(f);
            }
        }
    }
    void* library=dlopen("libEGL.so.1",RTLD_NOW|RTLD_LOCAL);
    if(!library)return;
    using Proc=void(*)();
    auto getProc=reinterpret_cast<Proc(*)(const char*)>(dlsym(library,"eglGetProcAddress"));
    if(getProc) {
        auto getInt=reinterpret_cast<void(*)(unsigned,int*)>(getProc("glGetIntegerv"));
        auto getAttachment=reinterpret_cast<void(*)(unsigned,unsigned,unsigned,int*)>(getProc("glGetFramebufferAttachmentParameteriv"));
        if(getInt&&getAttachment) {
            int samples=0,buffers=0,encoding=0,component=0,bits[4]{};
            getInt(0x80A9U,&samples);getInt(0x80A8U,&buffers);
            getAttachment(0x8D40U,0x0405U,0x8210U,&encoding);
            getAttachment(0x8D40U,0x0405U,0x8211U,&component);
            for(unsigned channel=0;channel<4;++channel)getAttachment(0x8D40U,0x0405U,0x8212U+channel,&bits[channel]);
            std::fprintf(stderr,"default framebuffer: samples=%d buffers=%d encoding=0x%x component=0x%x RGBA_bits=%d,%d,%d,%d\n",
                samples,buffers,encoding,component,bits[0],bits[1],bits[2],bits[3]);
        }
    }
    dlclose(library);
}

struct Harness {
    std::unique_ptr<GlRenderer> gpu;
    FrameRenderer recorder{kWidth,kHeight};
    FrameRenderer oracle{kWidth,kHeight};
    explicit Harness(std::unique_ptr<GlRenderer> renderer):gpu(std::move(renderer)){}
    Stats frame(std::uint64_t key,const Scene& scene,const char* label,
                bool forceWrongBase=false) {
        recorder.record([&](Canvas& c){drawScene(c,scene);},key);
        const auto base=forceWrongBase?recorder.recordedSceneBaseRevision()+1000000:
            recorder.recordedSceneBaseRevision();
        RETAINED_CHECK(gpu->renderRetained(recorder.lastList(),key,recorder.recordedSceneBaseKey(),base,
            recorder.recordedSceneRevision(),recorder.changed(),false));
        const Stats stats{gpu->lastRepaintedPixels(),gpu->lastInstanceCount(),gpu->lastCacheHit()};
        std::vector<std::uint32_t> got,expected;
        RETAINED_CHECK(gpu->readPixels(got));
        oracle.record([&](Canvas& c){drawScene(c,scene);});
        RETAINED_CHECK(gpu->render(oracle.lastList(),false));
        RETAINED_CHECK(gpu->readPixels(expected));
        if(std::string(label)=="first A")checkOriginalFullBaseline(expected);
        if(differences(got,expected)!=0) {
            RETAINED_CHECK(gpu->render(recorder.lastList(),false));
            std::vector<std::uint32_t> same;RETAINED_CHECK(gpu->readPixels(same));
            std::fprintf(stderr,"Same-list full oracle differs from second-record full oracle: %zu\n",differences(same,expected));
        }
        failureDiagnostics(got,expected,kWidth,kHeight);
        expectPixels(got,expected,label);
        RETAINED_CHECK(gpu->retainedSceneCount()<=6U);
        RETAINED_CHECK(gpu->retainedSceneBytes()<=48U*1024U*1024U);
        std::printf("%s: repaint=%lld/%d, instances=%d, hit=%d\n",label,
            stats.pixels,kWidth*kHeight,stats.instances,stats.cacheHit?1:0);
        return stats;
    }
};

std::unique_ptr<GlRenderer> createGpu(bool defaultDisplay,int w=kWidth,int h=kHeight) {
    GlRenderer::Options options;options.width=w;options.height=h;options.surfaceless=!defaultDisplay;
    std::string error;auto gpu=GlRenderer::create(options,error);
    if(!gpu)std::fprintf(stderr,"EGL unavailable: %s\n",error.c_str());
    return gpu;
}

void retainedPixels(Harness& h) {
    Scene a;
    auto stats=h.frame(1,a,"first A");
    RETAINED_CHECK(stats.pixels==kWidth*kHeight);
    stats=h.frame(1,a,"unchanged A");
    RETAINED_CHECK(stats.pixels==0&&stats.instances==0&&stats.cacheHit);
    Scene shared=a;shared.value=29;
    stats=h.frame(50,shared,"first unseen menu shares background");
    RETAINED_CHECK(stats.pixels>0&&stats.pixels<kWidth*kHeight/2&&stats.cacheHit);
    RETAINED_CHECK(!h.recorder.sceneCacheHit());
    stats=h.frame(51,shared,"first unseen menu has identical pixels");
    RETAINED_CHECK(stats.pixels==0&&stats.instances==0&&stats.cacheHit);
    RETAINED_CHECK(!h.recorder.sceneCacheHit());
    shared.overlay=true;
    stats=h.frame(60,shared,"first unseen menu changes a large bounded panel");
    RETAINED_CHECK(stats.pixels>kWidth*kHeight/2&&stats.pixels<kWidth*kHeight&&stats.cacheHit);
    const auto largeDamage=h.recorder.changedBounds();
    RETAINED_CHECK(largeDamage.left>0&&largeDamage.top>40&&largeDamage.right<kWidth&&largeDamage.bottom<kHeight);
    stats=h.frame(1,a,"original menu retained after new menus");
    RETAINED_CHECK(stats.pixels==0&&stats.instances==0&&stats.cacheHit);
    a.value=13;stats=h.frame(1,a,"small label/value edit");
    RETAINED_CHECK(stats.pixels>0&&stats.pixels<kWidth*kHeight/2);
    a.overlay=true;h.frame(1,a,"translucent overlay added");
    a.overlay=false;h.frame(1,a,"translucent overlay removed");
    a.shift=33;h.frame(1,a,"translucent shape moved");
    a.extra=true;h.frame(1,a,"clipped rotated button added");
    a.swapped=true;h.frame(1,a,"overlap order changed");
    a.extra=false;h.frame(1,a,"clipped button removed");
    a.image=false;h.frame(1,a,"image removed");
    a.image=true;h.frame(1,a,"image reinserted");
    Scene b=a;b.page=1;b.value=100;
    h.frame(2,b,"first B");
    stats=h.frame(1,a,"cached A return");
    RETAINED_CHECK(stats.pixels==0&&stats.instances==0&&stats.cacheHit);
    h.frame(2,b,"cached B return");
    a.value=127;h.frame(1,a,"A data changed while hidden");
    a.value=126;stats=h.frame(1,a,"wrong base revision recovery",true);
    RETAINED_CHECK(stats.pixels==kWidth*kHeight);
    setColorTheme(1);stats=h.frame(1,a,"theme changed");
    RETAINED_CHECK(stats.pixels==kWidth*kHeight);
    setColorTheme(0);h.frame(1,a,"theme restored");
    h.recorder.invalidate();stats=h.frame(1,a,"invalidated source graph");
    RETAINED_CHECK(stats.pixels==kWidth*kHeight);
    // Evict GPU scenes independently of the CPU signature cache.
    for(std::uint64_t key=100;key<107;++key) {
        RETAINED_CHECK(h.gpu->renderRetained(h.recorder.lastList(),key,0,key,
            std::vector<IRect>{{0,0,kWidth,kHeight}},false));
    }
    stats=h.frame(1,a,"GPU-only eviction recovery");
    RETAINED_CHECK(stats.pixels==kWidth*kHeight);
    for(std::uint64_t key=10;key<18;++key){b.value=static_cast<int>(key);h.frame(key,b,"bounded page cache fill");}
    stats=h.frame(1,a,"both caches evicted A");
    RETAINED_CHECK(stats.pixels==kWidth*kHeight);
    // A recreated CPU recorder may restart its revision counter at the same
    // number. Its zero base always requires replacing an older GPU picture.
    FrameRenderer replacement(kWidth,kHeight);a.value=38;
    replacement.record([&](Canvas& c){drawScene(c,a);},1);
    RETAINED_CHECK(replacement.recordedSceneBaseRevision()==0);
    // Force the exact counter collision: the GPU has old content under the new
    // recorder's same key AND revision, but that recorder has no valid base.
    RETAINED_CHECK(h.gpu->renderRetained(h.recorder.lastList(),1,0,
        replacement.recordedSceneRevision(),std::vector<IRect>{{0,0,kWidth,kHeight}},false));
    RETAINED_CHECK(h.gpu->renderRetained(replacement.lastList(),1,0,
        replacement.recordedSceneRevision(),replacement.changed(),false));
    RETAINED_CHECK(h.gpu->lastRepaintedPixels()==kWidth*kHeight);
    std::vector<std::uint32_t> got,expected;RETAINED_CHECK(h.gpu->readPixels(got));
    RETAINED_CHECK(h.gpu->render(replacement.lastList(),false));RETAINED_CHECK(h.gpu->readPixels(expected));
    expectPixels(got,expected,"replacement CPU recorder with existing GPU");
    std::puts("PASS retained GLES pixels equal full GLES replay for all scene transitions");
}

void emptyAndTransparent(Harness& h) {
    const auto blank=[](Canvas& c){c.clear(Color::TRANSPARENT);};
    h.recorder.record(blank,500);
    RETAINED_CHECK(h.gpu->renderRetained(h.recorder.lastList(),500,h.recorder.recordedSceneBaseKey(),h.recorder.recordedSceneBaseRevision(),
        h.recorder.recordedSceneRevision(),h.recorder.changed(),false));
    std::vector<std::uint32_t> got;RETAINED_CHECK(h.gpu->readPixels(got));
    RETAINED_CHECK(std::all_of(got.begin(),got.end(),[](auto pixel){return pixel==0;}));
    // Empty command lists must erase prior contents in their damaged region.
    h.recorder.record([](Canvas&){},500);
    RETAINED_CHECK(h.gpu->renderRetained(h.recorder.lastList(),500,h.recorder.recordedSceneBaseKey(),h.recorder.recordedSceneBaseRevision(),
        h.recorder.recordedSceneRevision(),h.recorder.changed(),false));
    RETAINED_CHECK(h.gpu->readPixels(got));
    RETAINED_CHECK(std::all_of(got.begin(),got.end(),[](auto pixel){return pixel==0;}));
    std::puts("PASS transparent/empty retained scene clearing");
}

void recreatedContext(bool defaultDisplay,Harness& h) {
    Scene s;s.value=44;
    auto newer=createGpu(defaultDisplay,500,330);RETAINED_CHECK(newer!=nullptr);
    FrameRenderer recorder(500,330),oracle(500,330);
    recorder.record([&](Canvas& c){drawScene(c,s);},1);
    RETAINED_CHECK(newer->renderRetained(recorder.lastList(),1,recorder.recordedSceneBaseRevision(),
        recorder.recordedSceneRevision(),recorder.changed(),false));
    RETAINED_CHECK(newer->lastRepaintedPixels()==500*330);
    std::vector<std::uint32_t> got,expected;RETAINED_CHECK(newer->readPixels(got));
    oracle.record([&](Canvas& c){drawScene(c,s);});
    RETAINED_CHECK(newer->render(oracle.lastList(),false));RETAINED_CHECK(newer->readPixels(expected));
    expectPixels(got,expected,"recreated context/size");
    // Alternating offscreen contexts must not leave current-context ownership stale.
    h.frame(1,s,"original context after second context");
    RETAINED_CHECK(newer->renderRetained(recorder.lastList(),1,recorder.recordedSceneBaseRevision(),
        recorder.recordedSceneRevision(),{},false));
    RETAINED_CHECK(newer->readPixels(got));expectPixels(got,expected,"second context restored");
    std::puts("PASS context recreation, size and alternating context ownership");
}
}

int main(int argc,char** argv) {
    if(argc<2||argc>3)return 2;
    const bool defaultDisplay=argc==3&&std::string(argv[2])=="default";
    try{
        setFontDirectory(argv[1]);RETAINED_CHECK(fontsReady());setColorTheme(0);
        auto gpu=createGpu(defaultDisplay);if(!gpu)return 77;
        std::printf("GLES renderer: %s\n",gpu->info().c_str());
        Harness h(std::move(gpu));retainedPixels(h);emptyAndTransparent(h);recreatedContext(defaultDisplay,h);
    }catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
    return 0;
}
