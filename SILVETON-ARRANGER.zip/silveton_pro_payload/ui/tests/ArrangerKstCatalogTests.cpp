#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/Support.h"
#include <array>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <unistd.h>

namespace silveton::ui {
struct ArrangerKstCatalogTestAccess {
    static const arranger::Pa5xKstCatalog& catalog(const ArrangerView& view) { assert(view.kstCatalog_);return *view.kstCatalog_; }
    static const std::string& detail(const ArrangerView& view) { return view.styleInfoText_; }
    static bool catalogOpen(const ArrangerView& view) { return view.picker_==ArrangerView::Picker::KstCatalog; }
    static bool styleOpen(const ArrangerView& view) { return view.picker_==ArrangerView::Picker::StyleRead; }
    static bool keyboardOpen(const ArrangerView& view) { return view.picker_==ArrangerView::Picker::KeyboardSetRead; }
    static int element(const ArrangerView& view) { return view.styleReadElement_; }
    static int cv(const ArrangerView& view,std::size_t track) { return view.styleReadCvs_[track]; }
    static bool scanActive(const ArrangerView& view) { return view.kstJob_!=nullptr; }
    static std::shared_ptr<const arranger::Pa5xKeyboardSetRead> keyboard(const ArrangerView& view) { return view.keyboardSetContents_; }
};
}
namespace {
using Bytes=std::vector<std::uint8_t>;
using namespace silveton::ui;
void u16(Bytes& b,std::uint32_t n){b.push_back(static_cast<std::uint8_t>(n>>8U));b.push_back(static_cast<std::uint8_t>(n));}
void u32(Bytes& b,std::uint32_t n){for(int shift=24;shift>=0;shift-=8)b.push_back(static_cast<std::uint8_t>(n>>static_cast<unsigned>(shift)));}
void set32(Bytes& b,std::size_t p,std::uint32_t n){for(int shift=24;shift>=0;shift-=8)b[p++]=static_cast<std::uint8_t>(n>>static_cast<unsigned>(shift));}
void append(Bytes& b,const Bytes& value){b.insert(b.end(),value.begin(),value.end());}
void chunk(Bytes& b,std::uint32_t tag,const Bytes& payload){u32(b,tag);u32(b,static_cast<std::uint32_t>(payload.size()));append(b,payload);}
void variable(Bytes& b,std::uint32_t n){std::uint8_t values[4]{};int count=0;do{values[count++]=static_cast<std::uint8_t>(n&127U);n>>=7U;}while(n);while(count){--count;b.push_back(static_cast<std::uint8_t>(values[count]|(count?128U:0U)));}}
void property(Bytes& b,unsigned tag,const Bytes& value){u16(b,tag);u16(b,static_cast<std::uint32_t>(value.size()));append(b,value);}
void write(const std::string& path,const Bytes& value){std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(value.data()),static_cast<std::streamsize>(value.size()));assert(file.good());}
Bytes korf(unsigned type,unsigned major,const std::string& name,const Bytes& body,std::uint32_t bodyTag,bool pcg=false){
    Bytes fields;u16(fields,4);property(fields,0,{static_cast<std::uint8_t>(type),static_cast<std::uint8_t>(pcg?9:0),static_cast<std::uint8_t>(pcg?7:1)});property(fields,1,{static_cast<std::uint8_t>(major),0});
    Bytes raw(name.begin(),name.end());if(pcg)raw.resize(28,0);else raw.push_back(0);property(fields,2,raw);property(fields,4,{0,0,0,0,0,0,0,1});u32(fields,0);
    Bytes table;u16(table,static_cast<std::uint32_t>(fields.size()));append(table,fields);Bytes children;chunk(children,0x02000018,{11,0,0,0,0,0,0,'K','O','R','F',0});chunk(children,0x05010018,table);
    const auto dataAt=static_cast<std::uint32_t>(children.size()+8);chunk(children,bodyTag,body);Bytes refs{'K','B','E','G'};u32(refs,28);u32(refs,dataAt);append(refs,{'K','E','N','D'});u32(refs,2);chunk(children,0xFE000018,refs);Bytes result;chunk(result,0x01000114,children);return result;
}
Bytes resource(const std::string& type,const std::string& name,const Bytes& data){Bytes result(type.begin(),type.end());result.push_back(0);result.insert(result.end(),name.begin(),name.end());result.push_back(0);u32(result,static_cast<std::uint32_t>(data.size()));append(result,data);return result;}
Bytes xml(const std::string& name,const std::string& data){return resource("Leaf",name,Bytes(data.begin(),data.end()));}
Bytes style(){
    // One proven setup measure:384 PPQ *3 beats=1152 ticks. Bank/program
    // selection belongs to that setup track, not before the CV boundary.
    Bytes setup{0,0xFF,0x58,4,3,2,24,8,0,0xB9,0,120,0,0xB9,32,64,0,0xC9,7};variable(setup,1152);append(setup,{0xFF,0x2F,0});
    Bytes notes;variable(notes,1344);append(notes,{0x99,60,100,96,0x89,60,0});variable(notes,864);append(notes,{0xFF,0x2F,0});
    Bytes midi{'M','T','h','d',0,0,0,6,0,1,0,2,1,128};for(const auto& track:{setup,notes}){append(midi,{'M','T','r','k'});u32(midi,static_cast<std::uint32_t>(track.size()));append(midi,track);}
    Bytes pad=resource("Leaf","Main.mid",midi);append(pad,xml("ClipDescription.xml","<CLIP version=\"0\" release=\"3\"><PARAMS><Pattern type=\"Drum\"/><AppearingTimeSignature numerator=\"3\" denominator=\"2\"/><ORIGINAL_CHORD><CV1 root=\"C\" chord=\"Maj\"/></ORIGINAL_CHORD><CHORD_TABLE><Maj cv=\"1\"/></CHORD_TABLE></PARAMS></CLIP>"));
    Bytes scene=resource("Branch","Drum.pdc",pad);append(scene,xml("SceneDescription.xml","<SCENE><PARAMS><TimeSignature numerator=\"3\" denominator=\"2\"/></PARAMS></SCENE>"));
    Bytes body=resource("Branch","Visible Style.stc",resource("Branch","Main.ssn",resource("Branch","Var1.scn",scene)));append(body,xml("StageDescription.xml","<STAGE><PARAMS><Tempo value=\"625000\"/></PARAMS></STAGE>"));
    Bytes result{'R','o','o','t',0,1,0};u32(result,static_cast<std::uint32_t>(body.size()));append(result,body);return result;
}
Bytes keyboardSet(){
    Bytes content;
    for(const char* name:{"Lower.mid","Upper1.mid","Upper2.mid","Upper3.mid"}){
        const Bytes events{24,0xB0,0,121,0,0xB0,32,64,0,0xC0,7,0,0xB0,7,93,0,0xB0,10,72,0,0xB0,11,112,0,0xFF,0x2F,0};
        Bytes midi{'M','T','h','d',0,0,0,6,0,0,0,1,1,128,'M','T','r','k'};u32(midi,static_cast<std::uint32_t>(events.size()));append(midi,events);append(content,resource("Leaf",name,midi));
    }
    std::string description="<CLIP type=\"KeyboardSetClip\" subtype=\"4\" version=\"1\" release=\"0\"><RESOURCE track1=\"Lower.mid\" track2=\"Upper1.mid\" track3=\"Upper2.mid\" track4=\"Upper3.mid\"/><PARAMS><Lower use=\"1\"/>";
    for(int part=1;part<=4;++part)description+="<Track"+std::to_string(part)+"Params mute=\""+(part==1?"1":"0")+"\" keyrangelow=\"21\" keyrangehigh=\"108\" dynamicrangelow=\"1\" dynamicrangehigh=\"127\"/>";
    description+="<KeyboardProcessing splitpoint=\"57\" globalsplit=\"0\" upperoctavetranspose=\"-1\"/></PARAMS></CLIP>";
    append(content,xml("ClipDescription.xml",description));Bytes result{'R','o','o','t',0,1,0};u32(result,static_cast<std::uint32_t>(content.size()));append(result,content);return result;
}
std::string fixture(const std::string& parent){
    const auto root=files::join(parent,"Visible.KST");for(const char* name:{"STYLE","SOUND","MULTISMP","PCM","KEYBOARDSET"})assert(files::makeDirectories(files::join(root,name)));
    write(files::join(root,"STYLE/Visible.stg"),style());write(files::join(root,"SOUND/USER01.PCG"),korf(4,2,"Visible Sound",{'O','C','3','1'},0x10020038,true));
    write(files::join(root,"KEYBOARDSET/001.Visible Blend.ksc"),keyboardSet());
    Bytes pcm(66+2048*2,0);pcm[7]=1;pcm[8]=1;pcm[9]=16;set32(pcm,10,48000);set32(pcm,14,2048);
    for(std::size_t n=0;n<2048;++n){const auto value=static_cast<std::int16_t>(12000.0*std::sin(static_cast<double>(n)*.15));const auto raw=static_cast<std::uint16_t>(value);pcm[66+n*2]=static_cast<std::uint8_t>(raw>>8U);pcm[67+n*2]=static_cast<std::uint8_t>(raw);}
    write(files::join(root,"PCM/RAM01.PCM"),korf(6,0,"Visible Wave",pcm,0x12000018));
    Bytes kmp(10+111+20+166,0);kmp[1]=3;kmp[3]=1;kmp[7]=1;kmp[9]=1;const std::string name="Visible Wave";std::copy(name.begin(),name.end(),kmp.begin()+90);kmp[113]=1;set32(kmp,116,48000);kmp[120]=60;kmp[124]=127;kmp[125]=60;kmp[141+156]=1;kmp[141+165]=9;
    write(files::join(root,"MULTISMP/RAM.KMP"),korf(5,5,"Mapping",kmp,0x11050018));return root;
}
void draw(ArrangerView& view,Canvas& canvas){view.draw(canvas);}
void tap(ArrangerView& view,Canvas& canvas,float x,float y){draw(view,canvas);const float px=320+x*1.25F,py=24+y*1.25F;view.pointer(ArrangerView::PointerAction::Down,px,py);view.pointer(ArrangerView::PointerAction::Up,px,py);draw(view,canvas);}
}
int main(int argc,char** argv){
    using namespace silveton::ui;
    if(argc<2){std::cerr<<"Usage: catalog_test FONT_DIRECTORY [REAL_KST_ROOT]\n";return 2;}
    setFontDirectory(argv[1]);assert(fontsReady());char path[]="/tmp/arranger-catalog-ui-XXXXXX";assert(::mkdtemp(path));const std::string directory=path;
    const auto root=argc>2?std::string(argv[2]):fixture(directory);
    ControllerEnv env;env.dataDir=files::join(directory,"settings");assert(files::makeDirectories(env.dataDir));SamplerAppController controller(env);ArrangerView view(controller);Canvas canvas(1340,800);
    auto& host=silveton::host::arrangerHost();host.prepare(48000,64);host.stopStreaming();view.setKstDirectoryForPreview(root);draw(view,canvas);
    const auto& catalog=ArrangerKstCatalogTestAccess::catalog(view);assert(!catalog.styles.empty()&&!catalog.sounds.empty()&&!catalog.keyboardSets.empty());assert(ArrangerKstCatalogTestAccess::catalogOpen(view));
    int storageRequests=0;
    view.setStorageAccessRequest([&storageRequests]{++storageRequests;return false;});
    view.requestKstScan(root);
    assert(storageRequests==1&&!ArrangerKstCatalogTestAccess::scanActive(view)&&ArrangerKstCatalogTestAccess::catalogOpen(view));
    view.setStorageAccessRequest({});
    assert(catalog.styles[0].loadable);const auto expectedName=catalog.styles[0].name;const auto expectedTempo=catalog.styles[0].bpm;const auto expectedMeter=catalog.styles[0].numerator;
    tap(view,canvas,200,135);assert(ArrangerKstCatalogTestAccess::styleOpen(view));
    assert(host.snapshot(0).loaded&&host.snapshot(0).name==expectedName&&host.snapshot(0).originalBpm==expectedTempo&&host.snapshot(0).numerator==expectedMeter&&host.snapshot(0).denominator==catalog.styles[0].denominator);
    std::array<float,128> audio{};host.renderAdd(audio.data(),64,48000);view.tick(nowMs()+200);
    const auto styleRead=host.styleRead(0);assert(styleRead&&styleRead->valid&&styleRead->nativeStyle);
    const auto section=static_cast<std::size_t>(ArrangerKstCatalogTestAccess::element(view));assert(styleRead->sections[section].available);
    bool inspected=false;
    for(std::size_t track=0;track<8&&!inspected;++track){
        const int selected=ArrangerKstCatalogTestAccess::cv(view,track);
        const auto& cv=styleRead->sections[section].tracks[track].cvs[static_cast<std::size_t>(selected)];
        if(cv.soundChanges.empty()||!cv.soundChanges.front().sound.addressComplete)continue;
        const auto& expected=cv.soundChanges.front();tap(view,canvas,200,145+static_cast<float>(track)*34);
        const auto partAddress=std::to_string(expected.msb)+" / "+std::to_string(expected.lsb)+" / "+std::to_string(expected.program);
        assert(ArrangerKstCatalogTestAccess::detail(view).find(partAddress)!=std::string::npos);
        assert(ArrangerKstCatalogTestAccess::detail(view).find("CV"+std::to_string(selected+1))!=std::string::npos);
        if(!expected.sound.name.empty())assert(ArrangerKstCatalogTestAccess::detail(view).find(expected.sound.name)!=std::string::npos);
        view.keyDown(ArrangerView::Key::Escape);assert(ArrangerKstCatalogTestAccess::styleOpen(view));inspected=true;
    }
    assert(inspected);const auto beforeInspect=host.snapshot(0);tap(view,canvas,638,62);host.renderAdd(audio.data(),64,48000);
    const auto afterInspect=host.snapshot(0);assert(beforeInspect.element==afterInspect.element&&!afterInspect.playing);
    for(std::size_t track=0;track<8;++track){assert(ArrangerKstCatalogTestAccess::cv(view,track)==1);assert(beforeInspect.tracks[track].selectedCv==afterInspect.tracks[track].selectedCv);}
    view.keyDown(ArrangerView::Key::Escape);tap(view,canvas,200,85);assert(ArrangerKstCatalogTestAccess::catalogOpen(view));tap(view,canvas,300,62);tap(view,canvas,200,135);
    const auto& sound=catalog.sounds[0];const auto soundAddress=std::to_string(sound.msb)+" / "+std::to_string(sound.lsb)+" / "+std::to_string(sound.program);assert(ArrangerKstCatalogTestAccess::detail(view).find(soundAddress)!=std::string::npos);assert(ArrangerKstCatalogTestAccess::detail(view).find(sound.name)!=std::string::npos);assert(!sound.playable);
    tap(view,canvas,40,20);tap(view,canvas,500,62);
    const auto originalCombi=controller.combiName();std::array<std::string,4> originalParts{};const int partIndices[]{6,0,1,2};
    for(std::size_t part=0;part<4;++part){const auto state=controller.upperState(partIndices[part]);originalParts[part]=state?state->soundName:"";}
    tap(view,canvas,200,135);assert(ArrangerKstCatalogTestAccess::keyboardOpen(view));
    const auto blend=host.keyboardSetRead();assert(blend&&blend->valid&&ArrangerKstCatalogTestAccess::keyboard(view)==blend);
    assert(blend->name==catalog.keyboardSets[0].name);bool partInspected=false;
    for(std::size_t part=0;part<4;++part){
        const auto& expected=blend->parts[part];assert(expected.role==static_cast<int>(part+1));
        if(partInspected||!expected.addressKnown)continue;
        tap(view,canvas,200,120+static_cast<float>(part)*79);
        const auto address=std::to_string(expected.msb)+" / "+std::to_string(expected.lsb)+" / "+std::to_string(expected.program);
        assert(ArrangerKstCatalogTestAccess::detail(view).find(address)!=std::string::npos);
        assert(ArrangerKstCatalogTestAccess::detail(view).find("Setup read through tick "+std::to_string(expected.setupLastTick))!=std::string::npos);
        if(!expected.soundName.empty())assert(ArrangerKstCatalogTestAccess::detail(view).find(expected.soundName)!=std::string::npos);
        view.keyDown(ArrangerView::Key::Escape);assert(ArrangerKstCatalogTestAccess::keyboardOpen(view));partInspected=true;
    }
    assert(partInspected&&controller.combiName()==originalCombi);
    for(std::size_t part=0;part<4;++part){const auto state=controller.upperState(partIndices[part]);assert((state?state->soundName:"")==originalParts[part]);}
    tap(view,canvas,40,20);assert(ArrangerKstCatalogTestAccess::catalogOpen(view));tap(view,canvas,700,62);assert(!catalog.samples.empty()&&catalog.samples[0].previewable);tap(view,canvas,200,135);assert(host.pcmPreview().ready);tap(view,canvas,200,330);
    double energy=0;for(int block=0;block<64;++block){audio.fill(0);host.renderAdd(audio.data(),64,48000);for(const float sample:audio)energy+=static_cast<double>(sample)*sample;}assert(energy>1e-10);tap(view,canvas,560,330);tap(view,canvas,40,20);assert(ArrangerKstCatalogTestAccess::catalogOpen(view));
    host.panic();host.stopPcmPreview();controller.close();files::removeRecursively(directory);std::cout<<"PASS visible Style/CV and four-part Keyboard Set contents, original addresses, unchanged assignments, real Style load and rendered PCM audition\n";
}
