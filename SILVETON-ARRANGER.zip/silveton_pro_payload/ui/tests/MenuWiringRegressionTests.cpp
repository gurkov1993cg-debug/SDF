// Tablet workflows use public pointer/key dispatch, including the touch keypad.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include <chrono>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <thread>
#include <unistd.h>

using namespace silveton::ui;
using View=classic::SilvetonSamplerView;
#define CHECK(x) do { if(!(x))throw std::runtime_error(std::string("line ")+std::to_string(__LINE__)+": " #x); } while(false)

namespace silveton::ui::classic {
struct ViewTestAccess {
    static void live(View& v){v.goPage(View::Page::COMBI,View::MODE_LIVE);}
    static bool quick(const View& v){return v.combiMode_==View::MODE_EDIT&&v.editGroup_==View::EG_VOICE;}
    static bool source(const View& v){return v.combiMode_==View::MODE_EDIT&&v.editGroup_==View::EG_WAVE;}
    static bool picker(const View& v){return static_cast<bool>(v.picker);}
    static bool markedPicker(const View& v){return v.picker&&v.picker->markMode;}
    static bool save(const View& v){return v.saveOpen_;}
    static int importStage(const View& v){return v.setImport_?static_cast<int>(v.setImport_->stage):-1;}
    static std::size_t importSelected(const View& v){return v.setImport_?v.setImport_->selected.size():0U;}
    static bool wait(const View& v){return !v.dialogStack.empty()&&v.dialogStack.back()->kind==View::Dialog::Kind::Wait;}
    static int decimals(const View& v){
        if(v.dialogStack.empty())throw std::runtime_error("No numeric dialog: page="+std::to_string(static_cast<int>(v.page_))+" save="+std::to_string(v.saveOpen_)+" scale="+std::to_string(v.scaleOpen_)+" store="+std::to_string(v.listStoreMode_));
        return v.dialogStack.back()->numDec;
    }
    static RectF keypad(const View& v,const std::string& label){
        CHECK(!v.dialogStack.empty());
        for(const auto& key:v.dialogStack.back()->kbKeys)if(key.label==label)return key.rect;
        throw std::runtime_error("No touch key: "+label);
    }
    static RectF plus(const View& v){CHECK(!v.dialogStack.empty());return v.dialogStack.back()->stepRect[1];}
    static void startScan(View& v){v.sampler.startKeyScan(0,0,0);}
};
}

namespace {
using A=classic::ViewTestAccess;
int modelUpper=-1,modelSound=-1;
std::string tempDir(){char p[]="/tmp/silveton-menu-wiring-XXXXXX";CHECK(::mkdtemp(p));return p;}
ControllerEnv environment(const std::string& path){ControllerEnv e;e.dataDir=path;e.chooseSoloModel=[](int u,int s){modelUpper=u;modelSound=s;};return e;}
struct Fixture {
    std::string path=tempDir();
    SamplerAppController controller{environment(path)};
    View view{controller};
    Canvas canvas{1340,800};
    Fixture(){
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(controller.assignUpperSound(0,{0,0,9001,"SOURCE"}));
        CHECK(controller.assignUpperSound(1,{0,0,9002,"OTHER"}));
        CHECK(controller.setLayerSound(1,2,9003));
        view.setSoftKeyboard(true);view.refreshAllForTests();A::live(view);draw();
    }
    void draw(){view.draw(canvas);}
    void tap(float x,float y){view.pointer(View::PointerAction::Down,x,y);view.pointer(View::PointerAction::Up,x,y);draw();}
    void tap(const RectF& r){tap(r.centerX(),r.centerY());}
    void escape(){view.keyDown(View::Key::Escape);draw();}
    void wait(){
        for(int k=0;k<2000&&A::wait(view);++k){std::this_thread::sleep_for(std::chrono::milliseconds(1));view.tick(nowMs());draw();}
        CHECK(!A::wait(view));
    }
};

void navigationAndSourceTarget(){
    Fixture f;
    f.tap(778,744);CHECK(A::quick(f.view));
    f.tap(854,46);CHECK(A::source(f.view));
    f.tap(120,246);CHECK(A::quick(f.view));
    f.tap(1225,46);CHECK(!A::quick(f.view));
    f.tap(500,610);CHECK(A::quick(f.view)); // LIVE has one editor, no second bend/porta knobs
    f.tap(1225,46);
    f.tap(327,210); // UPPER 2 / L3 chip
    CHECK(f.view.selectedSoloPart()==1&&f.view.selectedSoloSound()==3);
    f.tap(325,744); // MIXER
    f.tap(255,195); // this strip's SOURCE, same selected L3
    CHECK(A::source(f.view)&&f.view.selectedSoloPart()==1&&f.view.selectedSoloSound()==3);
    modelUpper=modelSound=-1;
    f.tap(400,344); // sample SOURCE / WAVE → CHOOSE SOUND
    CHECK(A::picker(f.view));
    f.tap(810,120); // the one sound chooser's LOAD .svsolo keeps Upper + layer
    CHECK(modelUpper==1&&modelSound==3);
    f.tap(778,744);CHECK(A::quick(f.view));
    f.tap(1035,46);CHECK(A::save(f.view));
    f.escape();CHECK(!A::save(f.view));
    std::puts("PASS touch navigation: quick/source/back/save and model target retains selected layer");
}

void emptyMainAndPickerBack(){
    Fixture f;
    f.tap(419,391); // empty UPPER 3 ON opens the same picker as its sound display
    CHECK(A::picker(f.view));
    f.escape();CHECK(!A::picker(f.view));
    f.tap(100,150);CHECK(A::picker(f.view));
    const int original=f.controller.upperSoundSlot(0);
    const bool enabled=f.controller.upperState(0)->enabled;
    f.tap(145,222); // preview a different built-in source
    CHECK(f.controller.upperSoundSlot(0)!=original);
    f.escape();
    CHECK(!A::picker(f.view));
    CHECK(f.controller.upperSoundSlot(0)==original&&f.controller.upperState(0)->enabled==enabled);
    f.tap(100,150);f.tap(960,120);CHECK(A::markedPicker(f.view));
    f.escape();CHECK(A::picker(f.view)&&!A::markedPicker(f.view));
    f.escape();CHECK(!A::picker(f.view));
    f.tap(100,150);f.tap(145,222);CHECK(f.controller.upperSoundSlot(0)!=original);
    f.tap(1210,744); // leaving an audition through ordinary navigation cancels it too
    CHECK(!A::picker(f.view)&&f.controller.upperSoundSlot(0)==original);
    std::puts("PASS empty MAIN and Back: picker opens, marking exits first, source/enabled state restored");
}

void numericKeypadAndScan(){
    Fixture f;
    f.tap(1210,744); // SETTINGS > GENERAL
    f.tap(250,465); // BREATH CC numeric value
    CHECK(f.view.dialogOpen());
    CHECK(A::decimals(f.view)==0);
    const int previous=f.controller.globalUiState()->breathCc;
    f.tap(A::plus(f.view));
    CHECK(f.controller.globalUiState()->breathCc==previous+1);
    f.escape();CHECK(f.controller.globalUiState()->breathCc==previous);
    f.tap(250,465);
    f.tap(A::keypad(f.view,"CLEAR"));f.tap(A::keypad(f.view,"1"));f.tap(A::keypad(f.view,"7"));
    f.tap(960,692);CHECK(f.controller.globalUiState()->breathCc==17);
    A::startScan(f.view);CHECK(f.controller.keyScanUpper()==0);
    f.tap(109,744);CHECK(f.controller.keyScanUpper()==-1);
    // The global transpose UI and backend agree on the inclusive -12..12 range.
    auto g=*f.controller.globalUiState();g.transpose=12;CHECK(f.controller.updateGlobalUi(g));
    f.view.refreshAllForTests();f.draw();f.tap(792,466);
    CHECK(f.controller.globalUiState()->transpose==12);
    f.tap(737,466);CHECK(f.view.dialogOpen());CHECK(A::decimals(f.view)==0);
    f.tap(A::keypad(f.view,"CLEAR"));f.tap(A::keypad(f.view,"9"));f.tap(A::keypad(f.view,"9"));
    f.tap(960,692);CHECK(f.controller.globalUiState()->transpose==12);
    std::puts("PASS tablet numeric keys: integer CC steps/apply/cancel, scan stops, global transpose clamps at 12");
}

void importThroughTouch(){
    Fixture f;
    const std::string sourceDir=tempDir();
    {
        SamplerAppController source(environment(sourceDir));
        CHECK(source.engine.nativeClearPerformance());
        CHECK(source.assignUpperSound(0,{0,0,9001,"A"}));
        CHECK(source.writeCombiToList(0,"IMPORT A")==0);
        CHECK(source.assignUpperSound(0,{0,0,9002,"B"}));
        CHECK(source.writeCombiToList(1,"IMPORT B")==1);
        CHECK(!source.saveSetAs("EXTERNAL"));
        CHECK(files::copyFile(sourceDir+"/EXTERNAL.SVSET",f.path+"/EXTERNAL.SVSET"));
    }
    CHECK(f.controller.writeCombiToList(5,"KEEP")==5);
    f.view.refreshAllForTests();f.draw();f.tap(565,744);f.tap(1140,126);
    CHECK(A::importStage(f.view)==0);
    f.escape();CHECK(A::importStage(f.view)==-1);
    f.tap(1140,126);f.tap(400,270);f.tap(1180,602);f.wait();
    CHECK(A::importStage(f.view)==1);
    f.view.pointer(View::PointerAction::Down,500,268);
    f.view.pointer(View::PointerAction::Move,500,334);
    f.view.pointer(View::PointerAction::Up,500,334);f.draw();
    CHECK(A::importSelected(f.view)==2);
    f.tap(1180,602);CHECK(A::importStage(f.view)==2);
    f.tap(850,334); // destination 006, currently KEEP
    f.tap(1180,602);CHECK(A::importStage(f.view)==3);
    f.tap(1180,595);CHECK(A::importStage(f.view)==-1);
    const auto list=f.controller.listItems(0,0,0);
    CHECK(list.at(5).name=="IMPORT A"&&list.at(6).name=="IMPORT B"&&list.at(7).name=="KEEP");
    std::puts("PASS SET import through pointer dispatch: browse, drag select, insert and shift occupied destination");
}
}

int main(int argc,char** argv){
    if(argc!=2)return 2;setFontDirectory(argv[1]);if(!fontsReady())return 2;
    try{navigationAndSourceTarget();emptyMainAndPickerBack();numericKeypadAndScan();importThroughTouch();}
    catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
    return 0;
}
