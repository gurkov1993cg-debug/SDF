#include "RetainedSceneFixture.h"

#include <cstdint>
#include <map>
#include <memory>

using namespace retained_test;

namespace {
struct Surface {
    Canvas pixels;
    std::uint64_t revision{0};
    explicit Surface(int w,int h):pixels(w,h){}
};

struct Harness {
    FrameRenderer recorder;
    std::map<std::uint64_t,std::unique_ptr<Surface>> surfaces;
    explicit Harness(int w=420,int h=280):recorder(w,h){}
    bool frame(std::uint64_t key,const Scene& scene,const char* label) {
        const bool present=recorder.record([&](Canvas& c){drawScene(c,scene);},key);
        RETAINED_CHECK(recorder.recordedSceneKey()==key);
        auto& target=surfaces[key];
        if(!target)target=std::make_unique<Surface>(recorder.width(),recorder.height());
        const auto base=surfaces.find(recorder.recordedSceneBaseKey());
        const bool fresh=recorder.recordedSceneBaseRevision()==0 ||base==surfaces.end()||
            base->second->revision!=recorder.recordedSceneBaseRevision();
        if(fresh)target->pixels.replay(recorder.lastList(),{0,0,recorder.width(),recorder.height()});
        else {
            if(base->first!=key)target->pixels.copyPixels(base->second->pixels,{0,0,recorder.width(),recorder.height()});
            for(const auto& r:recorder.changed())target->pixels.replay(recorder.lastList(),r);
        }
        target->revision=recorder.recordedSceneRevision();
        expectPixels(target->pixels.buffer(),freshPixels(recorder.width(),recorder.height(),scene),label);
        RETAINED_CHECK(recorder.retainedSceneCount()<=FrameRenderer::kMaxRetainedScenes);
        RETAINED_CHECK(recorder.retainedSceneBytes()<=FrameRenderer::kMaxRetainedSignatureBytes);
        return present;
    }
};

void changesAndPageReturns() {
    Harness h;Scene a;
    RETAINED_CHECK(h.frame(1,a,"first A"));
    RETAINED_CHECK(!h.recorder.sceneCacheHit());
    RETAINED_CHECK((h.recorder.changed()==std::vector<IRect>{{0,0,420,280}}));
    RETAINED_CHECK(!h.frame(1,a,"unchanged A"));
    RETAINED_CHECK(h.recorder.changed().empty());
    const auto initialRevision=h.recorder.recordedSceneRevision();
    a.value=13;
    RETAINED_CHECK(h.frame(1,a,"small value edit"));
    RETAINED_CHECK(h.recorder.recordedSceneRevision()!=initialRevision);
    RETAINED_CHECK(!h.recorder.changed().empty());
    RETAINED_CHECK(h.recorder.changedBounds().area()<420LL*280LL/2LL);
    a.overlay=true;RETAINED_CHECK(h.frame(1,a,"alpha modal inserted"));
    a.overlay=false;RETAINED_CHECK(h.frame(1,a,"alpha modal removed"));
    a.shift=41;RETAINED_CHECK(h.frame(1,a,"translucent shape moved"));
    a.extra=true;RETAINED_CHECK(h.frame(1,a,"clipped rotated button inserted"));
    a.swapped=true;RETAINED_CHECK(h.frame(1,a,"overlap order changed"));
    a.extra=false;RETAINED_CHECK(h.frame(1,a,"button removed"));
    a.image=false;RETAINED_CHECK(h.frame(1,a,"image removed"));
    a.image=true;RETAINED_CHECK(h.frame(1,a,"local image inserted"));
    Scene b=a;b.page=1;b.value=97;
    RETAINED_CHECK(h.frame(2,b,"first B"));
    RETAINED_CHECK(h.frame(1,a,"cached A return"));
    RETAINED_CHECK(h.recorder.sceneCacheHit());
    RETAINED_CHECK(h.recorder.changed().empty());
    RETAINED_CHECK(!h.frame(1,a,"cached A remains idle"));
    RETAINED_CHECK(h.frame(2,b,"cached B return"));
    a.value=127;a.overlay=true;
    RETAINED_CHECK(h.frame(1,a,"changed data upon A return"));
    RETAINED_CHECK(h.recorder.sceneCacheHit());
    RETAINED_CHECK(!h.recorder.changed().empty());
    std::puts("PASS retained scene pixels: labels, movement, alpha, removals, order, page returns");
}

void evictionThemeInvalidationAndSize() {
    Harness h;Scene s;
    RETAINED_CHECK(h.frame(1,s,"eviction seed"));
    const auto oldRevision=h.recorder.recordedSceneRevision();
    for(std::uint64_t key=2;key<=9;++key){s.value=static_cast<int>(key);h.frame(key,s,"bounded cache fill");}
    s.value=12;
    RETAINED_CHECK(h.frame(1,s,"evicted menu returns"));
    RETAINED_CHECK(!h.recorder.sceneCacheHit());
    RETAINED_CHECK(h.recorder.recordedSceneBaseKey()==9);
    RETAINED_CHECK(h.recorder.recordedSceneBaseRevision()!=0);
    RETAINED_CHECK(h.recorder.changedBounds().area()<420LL*280LL/2LL);
    RETAINED_CHECK(h.recorder.recordedSceneRevision()>oldRevision);
    setColorTheme(1);
    RETAINED_CHECK(h.frame(1,s,"same menu after theme change"));
    RETAINED_CHECK(h.recorder.recordedSceneBaseRevision()==0);
    RETAINED_CHECK((h.recorder.changed()==std::vector<IRect>{{0,0,420,280}}));
    setColorTheme(0);
    RETAINED_CHECK(h.frame(1,s,"theme restored"));
    const auto beforeInvalidate=h.recorder.recordedSceneRevision();
    h.recorder.invalidate();
    RETAINED_CHECK(h.frame(1,s,"context invalidation"));
    RETAINED_CHECK(h.recorder.recordedSceneBaseRevision()==0);
    RETAINED_CHECK(h.recorder.recordedSceneRevision()>beforeInvalidate);
    Harness resized(500,330);
    RETAINED_CHECK(resized.frame(1,s,"resized renderer"));
    RETAINED_CHECK(!resized.recorder.sceneCacheHit());
    std::puts("PASS retained cache: eviction, invalidation, theme and size");
}

void firstMenuSharesUnchangedGraphics() {
    Harness h;Scene s;h.frame(1,s,"initial shared panel");
    const auto oldRevision=h.recorder.recordedSceneRevision();
    s.value=29;RETAINED_CHECK(h.frame(2,s,"new menu with changed label"));
    RETAINED_CHECK(!h.recorder.sceneCacheHit());
    RETAINED_CHECK(h.recorder.recordedSceneBaseKey()==1);
    RETAINED_CHECK(h.recorder.recordedSceneBaseRevision()==oldRevision);
    RETAINED_CHECK(h.recorder.changedBounds().area()>0);
    RETAINED_CHECK(h.recorder.changedBounds().area()<420LL*280LL/2LL);
    const auto secondRevision=h.recorder.recordedSceneRevision();
    RETAINED_CHECK(h.frame(3,s,"new identity with identical pixels"));
    RETAINED_CHECK(!h.recorder.sceneCacheHit());
    RETAINED_CHECK(h.recorder.recordedSceneBaseKey()==2);
    RETAINED_CHECK(h.recorder.recordedSceneBaseRevision()==secondRevision);
    RETAINED_CHECK(h.recorder.recordedSceneRevision()>secondRevision);
    RETAINED_CHECK(h.recorder.changed().empty());
    RETAINED_CHECK(h.frame(2,s,"cached shared panel return"));
    RETAINED_CHECK(h.recorder.changed().empty());
    s.overlay=true;
    RETAINED_CHECK(h.frame(4,s,"new menu changes a large bounded panel"));
    const auto area=h.recorder.changedBounds();
    RETAINED_CHECK(area.area()>420LL*280LL/2LL&&area.area()<420LL*280LL);
    RETAINED_CHECK(area.left>0&&area.top>40&&area.right<420&&area.bottom<280);
    std::puts("PASS first new menu reuses unchanged graphics and identical new menu copies without repair");
}

void imageSnapshotAndBudget() {
    FrameRenderer r(32,24);
    Image image;image.width=2;image.height=2;image.pixels.assign(4,Color::rgb(200,51,70));
    const auto draw=[&](Canvas& c){c.clear(Color::BLACK);Paint p;p.color=Color::WHITE;c.drawImage(image,{2,2,25,19},p);};
    Canvas expected(32,24);draw(expected);
    RETAINED_CHECK(r.record(draw,1));
    image.pixels.assign(4,Color::rgb(10,190,60));
    Canvas retained(32,24);retained.replay(r.lastList(),{0,0,32,24});
    expectPixels(retained.buffer(),expected.buffer(),"image mutation after record");
    RETAINED_CHECK(r.record(draw,1));
    RETAINED_CHECK(!r.changed().empty());
    r.record([](Canvas& c){
        Paint p;p.color=Color::WHITE;
        for(int i=0;i<100000;++i){const float x=static_cast<float>(i%31);c.drawRect({x,1,x+1,2},p);}
    },99);
    RETAINED_CHECK(r.retainedSceneCount()<=FrameRenderer::kMaxRetainedScenes);
    RETAINED_CHECK(r.retainedSceneBytes()<=FrameRenderer::kMaxRetainedSignatureBytes);
    std::puts("PASS retained image ownership and oversized-signature memory bound");
}

void shaderAliasSnapshot() {
    FrameRenderer r(64,24);auto shader=std::make_shared<Shader>();
    shader->kind=Shader::Kind::Linear;shader->x1=64;
    shader->colors={Color::rgb(200,10,30),Color::rgb(20,50,210)};
    r.record([&](Canvas& c){
        c.clear(Color::BLACK);Paint p;p.shader=shader;
        c.drawRect({0,0,32,24},p);
        shader->colors={Color::rgb(20,220,30),Color::rgb(210,100,20)};
        c.drawRect({32,0,64,24},p);
    },1);
    // Both mutation during the callback and later mutation must leave the
    // previously recorded operations at the exact colors they originally drew.
    shader->colors={Color::WHITE,Color::WHITE};
    Canvas retained(64,24);retained.replay(r.lastList(),{0,0,64,24});
    Canvas expected(64,24);expected.clear(Color::BLACK);Paint p;
    p.shader=linearGradient(0,0,64,0,Color::rgb(200,10,30),Color::rgb(20,50,210));
    expected.drawRect({0,0,32,24},p);
    p.shader=linearGradient(0,0,64,0,Color::rgb(20,220,30),Color::rgb(210,100,20));
    expected.drawRect({32,0,64,24},p);
    expectPixels(retained.buffer(),expected.buffer(),"mutable shader alias snapshot");
    std::puts("PASS immutable shader snapshots across mutable aliases");
}
}

int main(int argc,char** argv) {
    if(argc!=2)return 2;
    try{
        setFontDirectory(argv[1]);RETAINED_CHECK(fontsReady());setColorTheme(0);
        changesAndPageReturns();evictionThemeInvalidationAndSize();firstMenuSharesUnchangedGraphics();
        imageSnapshotAndBudget();shaderAliasSnapshot();
    }catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
    return 0;
}
