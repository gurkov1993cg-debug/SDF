#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Support.h"
#include <array>
#include <cassert>
#include <cstdlib>
#include <iostream>

int main(int argc,char** argv){
    assert(argc==2);
    using namespace silveton;
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char temporary[]="/tmp/silveton-chord-ui-XXXXXX";
    const char* directory=::mkdtemp(temporary);assert(directory);
    ui::ControllerEnv env;env.dataDir=directory;
    ui::SamplerAppController controller(env);
    ui::ArrangerView view(controller);
    auto& host=host::arrangerHost();host.prepare(48000,64);
    std::array<float,128> audio{};
    ui::Canvas canvas(1640,1040);
    int step=0;
    const auto pump=[&]{
        audio.fill(0);host.renderAdd(audio.data(),64,48000);
        view.tick(ui::nowMs()+static_cast<std::int64_t>(++step)*150);
        view.draw(canvas);
    };
    const auto click=[&](float x,float y){
        constexpr float zoom=1.61F,left=(1640.0F-800.0F*zoom)*0.5F,top=78.0F;
        view.pointer(ui::ArrangerView::PointerAction::Down,left+x*zoom,top+y*zoom);
        view.pointer(ui::ArrangerView::PointerAction::Up,left+x*zoom,top+y*zoom);
        pump();
    };
    view.setHomePageForPreview(6);pump();
    assert(host.snapshot(0).chordRecognitionMode==2);
    click(555,230);assert(host.snapshot(0).chordRecognitionMode==3);
    click(337,304);assert(host.snapshot(0).chordScanArea==3);
    click(298,360);assert(host.snapshot(0).bassInversion);
    click(490,360);assert(host.snapshot(0).damperLatch);
    click(106,360);assert(!host.snapshot(0).memory);
    click(490,304);assert(!host.snapshot(0).splitEnabled);
    // One Finger is unavailable with Chord Split off: no hidden selection.
    click(90,230);assert(host.snapshot(0).chordRecognitionMode==3);
    click(490,304);assert(host.snapshot(0).splitEnabled);
    click(90,230);assert(host.snapshot(0).chordRecognitionMode==0);
    host.stopStreaming();controller.close();
    std::cout<<"Arranger Chords UI: PASS (real clicks, applied snapshots, scan/mode/bass/latch/memory/split)\n";
}
