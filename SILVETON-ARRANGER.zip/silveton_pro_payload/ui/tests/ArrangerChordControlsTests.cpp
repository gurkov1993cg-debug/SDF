#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Support.h"
#include <array>
#include <cassert>
#include <cstdlib>
#include <iostream>

int main(int argc,char** argv){
    assert(argc==2);
    using namespace silveton;
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char temporary[]="/tmp/silveton-chord-ui-XXXXXX";
    const char* directory=::mkdtemp(temporary);assert(directory);
    ui::ControllerEnv env;env.dataDir=directory;
    ui::SamplerAppController controller(env);
    ui::ArrangerView view(controller);
    auto& host=host::arrangerHost();host.prepare(48000,64);
    std::array<float,128> audio{};
    ui::Canvas canvas(1340,800);
    int step=0;
    const auto pump=[&]{
        audio.fill(0);host.renderAdd(audio.data(),64,48000);
        view.tick(ui::nowMs()+static_cast<std::int64_t>(++step)*150);
        view.draw(canvas);
    };
    const auto click=[&](float x,float y){
        view.pointer(ui::ArrangerView::PointerAction::Down,x,y);
        view.pointer(ui::ArrangerView::PointerAction::Up,x,y);
        pump();
    };
    view.setHomePageForPreview(5);pump();
    assert(host.snapshot(0).chordRecognitionMode==2);
    click(1014,312);assert(host.snapshot(0).chordRecognitionMode==3);
    click(743,404);assert(host.snapshot(0).chordScanArea==3);
    click(693,475);assert(host.snapshot(0).bassInversion);
    click(933,475);assert(host.snapshot(0).damperLatch);
    click(453,475);assert(!host.snapshot(0).memory);
    click(933,404);assert(!host.snapshot(0).splitEnabled);
    // One Finger is unavailable with Chord Split off: no hidden selection.
    click(433,312);assert(host.snapshot(0).chordRecognitionMode==3);
    click(933,404);assert(host.snapshot(0).splitEnabled);
    click(433,312);assert(host.snapshot(0).chordRecognitionMode==0);
    host.stopStreaming();controller.close();
    std::cout<<"Arranger Chords UI: PASS (real clicks, applied snapshots, scan/mode/bass/latch/memory/split)\n";
}
