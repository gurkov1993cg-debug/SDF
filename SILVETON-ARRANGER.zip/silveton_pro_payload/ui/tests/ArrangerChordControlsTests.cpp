#include "silveton/arranger/ArrangerEngine.h"
#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Support.h"
#include <array>
#include <cassert>
#include <cstdlib>
#include <iostream>

int main(int argc,char** argv){
    assert(argc==2);
    using namespace silveton;
    ui::setFontDirectory(argv[1]);assert(ui::fontsReady());
    char temporary[]="/tmp/silveton-chord-ui-XXXXXX";
    const char* directory=::mkdtemp(temporary);assert(directory);
    ui::ControllerEnv env;env.dataDir=directory;
    ui::SamplerAppController controller(env);
    ui::ArrangerView view(controller);
    auto& host=host::arrangerHost();host.prepare(48000,64);
    std::array<float,128> audio{};
    ui::Canvas canvas(1340,800);
    int step=0;
    const auto pump=[&]{
        audio.fill(0);host.renderAdd(audio.data(),64,48000);
        view.tick(ui::nowMs()+static_cast<std::int64_t>(++step)*150);
        view.draw(canvas);
    };
    const auto click=[&](float x,float y){
        const auto [px,py]=view.detailPoint(x,y);
        view.pointer(ui::ArrangerView::PointerAction::Down,px,py);
        view.pointer(ui::ArrangerView::PointerAction::Up,px,py);
        pump();
    };
    view.setHomePageForPreview(6);pump();
    assert(host.snapshot(0).chordRecognitionMode==2);
    click(555,230);assert(host.snapshot(0).chordRecognitionMode==3);
    click(337,304);assert(host.snapshot(0).chordScanArea==3);
    click(298,360);assert(host.snapshot(0).bassInversion);
    click(490,360);assert(host.snapshot(0).damperLatch);
    click(106,360);assert(!host.snapshot(0).memory);
    click(465,410);assert(host.snapshot(0).memoryMode==1);
    click(675,410);assert(host.snapshot(0).memoryMode==2);
    click(255,410);assert(host.snapshot(0).memoryMode==0);
    click(490,304);assert(!host.snapshot(0).splitEnabled);
    // One Finger is unavailable with Chord Split off: no hidden selection.
    click(90,230);assert(host.snapshot(0).chordRecognitionMode==3);
    click(490,304);assert(host.snapshot(0).splitEnabled);
    click(90,230);assert(host.snapshot(0).chordRecognitionMode==0);
    view.setKstStatePath(std::string(directory)+"/KST.txt");
    arranger::ChordSequenceData seq;seq.count=2;seq.lengthTicks=1920;seq.events[0]={0,{0,arranger::ChordType::Major,0}};seq.events[1]={960,{7,arranger::ChordType::Major,7}};
    assert(host.loadChordSequence(seq,0));pump();click(420,188); // open sequence subpage
    click(375,332);assert(host.chordSequence().locked);
    click(470,405); // save slot 1
    click(500,332);assert(host.chordSequence().data.count==0);
    click(680,405);assert(host.chordSequence().data.count==2);
    if(const char* path=std::getenv("SILVETON_SEQUENCE_PREVIEW"))assert(ui::writePng(path,canvas));
    click(95,240);
    if(const char* path=std::getenv("SILVETON_SEQUENCE_EDIT_PREVIEW"))assert(ui::writePng(path,canvas));
    click(150,305);click(697,192); // change root C -> C#, apply draft
    assert(host.chordSequence().data.events[0].chord.root==1);
    click(680,405);assert(host.chordSequence().data.events[0].chord.root==0);
    click(85,192); // return to recognition page
    view.setHomePageForPreview(2);pump();
    assert(!host.snapshot(0).drumBassOnly);
    click(735,187);assert(!host.snapshot(0).manualBass&&!host.snapshot(0).drumBassOnly); // no Bass assigned
    click(550,187);assert(host.snapshot(0).drumBassOnly);
    click(550,187);assert(!host.snapshot(0).drumBassOnly);
    host.stopStreaming();controller.close();
    std::cout<<"Arranger Chords UI: PASS (real clicks, applied snapshots, scan/mode/bass/latch/memory/split, sequence slots and edit, 1340x800)\n";
}
