#pragma once

#include "silveton/ui/Gfx.h"

#include <algorithm>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <vector>

namespace retained_test {
using namespace silveton::ui;

inline void require(bool okay,const char* expression,int line) {
    if(!okay) throw std::runtime_error(std::string("line ")+std::to_string(line)+": "+expression);
}
#define RETAINED_CHECK(x) ::retained_test::require(static_cast<bool>(x),#x,__LINE__)

struct Scene {
    int page{0};
    int value{12};
    int shift{0};
    bool overlay{false};
    bool extra{false};
    bool swapped{false};
    bool image{true};
};

// Opaque base plus intersecting translucent elements exercise ordered replay,
// clipping, removal, changing text width and callback-local image lifetime.
inline void drawScene(Canvas& c,const Scene& s) {
    c.clear(s.page==0?Color::rgb(25,31,38):Color::rgb(43,29,36));
    const float w=static_cast<float>(c.width());
    const float h=static_cast<float>(c.height());
    Paint p;
    p.shader=linearGradient(0,0,w,h,Color::rgb(24,31,41),Color::rgb(55,65,78));
    c.drawRect({0,0,w,h},p);
    p.shader={};p.color=Color::rgb(15,20,28);
    c.drawRoundRect({12,12,w-12,h-12},12,12,p);
    p.color=Color::WHITE;p.textSize=19;p.typeface=Face::Bold;
    c.drawText(s.page==0?"KEYBOARD / БЛЕНДА":"STYLE / СТИЛ",28,40,p);
    p.textSize=16;p.typeface=Face::Regular;
    c.drawText("Attack "+std::to_string(s.value),30,74,p);
    p.color=Color::rgb(56,66,79);
    c.drawRoundRect({28,88,w-28,123},6,6,p);
    p.color=Color::rgb(240,151,49);
    const float end=std::min(w-28,30+static_cast<float>(s.value)*2);
    c.drawRoundRect({30,90,std::max(32.0F,end),121},5,5,p);
    const auto first=[&]{
        p.color=Color::argb(149,250,47,76);
        c.drawRoundRect({55+static_cast<float>(s.shift),142,176+static_cast<float>(s.shift),221},11,11,p);
    };
    const auto second=[&]{
        p.shader=radialGradient(181,181,58,Color::argb(198,48,216,244),Color::argb(20,30,75,100));
        c.drawCircle(181,181,58,p);
        p.shader={};
    };
    if(s.swapped){second();first();}else{first();second();}
    if(s.extra){
        p.color=Color::argb(191,230,240,90);
        c.save();c.clipRect({200,118,318,216});c.rotate(21,250,165);
        c.drawRect({205,118,304,216},p);c.restore();
    }
    if(s.image){
        Image local;local.width=13;local.height=11;
        local.pixels.resize(143U);
        for(std::size_t i=0;i<local.pixels.size();++i) {
            const auto a=static_cast<std::uint32_t>(96U+(i%4U)*40U);
            local.pixels[i]=(a<<24U)|((a/2U)<<16U)|((a*3U/4U)<<8U)|(a/4U);
        }
        p.color=Color::argb(211,255,255,255);
        c.drawImage(local,{w-80,140,w-29,197},p);
    }
    if(s.overlay){
        p.color=Color::argb(173,14,18,24);
        c.drawRect({12,54,w-12,h-12},p);
        p.color=Color::argb(235,40,47,56);
        c.drawRoundRect({74,104,w-74,h-46},13,13,p);
        p.color=Color::WHITE;p.textSize=17;
        c.drawText("Промяна "+std::to_string(s.value),91,139,p);
    }
}

inline std::vector<std::uint32_t> freshPixels(int w,int h,const Scene& scene) {
    Canvas full(w,h);drawScene(full,scene);return full.buffer();
}

inline std::size_t differences(const std::vector<std::uint32_t>& a,
                               const std::vector<std::uint32_t>& b) {
    RETAINED_CHECK(a.size()==b.size());
    std::size_t n=0;for(std::size_t i=0;i<a.size();++i)if(a[i]!=b[i])++n;
    return n;
}

inline void expectPixels(const std::vector<std::uint32_t>& got,
                         const std::vector<std::uint32_t>& expected,const char* label) {
    const auto n=differences(got,expected);
    if(n)throw std::runtime_error(std::string(label)+": "+std::to_string(n)+" pixels differ");
}
}
