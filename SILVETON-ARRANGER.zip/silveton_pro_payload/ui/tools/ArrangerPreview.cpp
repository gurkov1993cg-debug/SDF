#include "silveton/ui/ArrangerView.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/Support.h"
#include <cstdlib>
#include <iostream>

int main(int argc,char** argv){
    if(argc<4){std::cerr<<"Usage: arranger_preview FONT_DIRECTORY OUTPUT.png DATA_DIRECTORY [page 0..5] [KST_FOLDER_OR_STYLE_FILE]\n";return 2;}
    silveton::ui::setFontDirectory(argv[1]);
    if(!silveton::ui::fontsReady()){std::cerr<<"Fonts unavailable\n";return 2;}
    silveton::ui::ControllerEnv env;env.dataDir=argv[3];
    silveton::ui::files::makeDirectories(env.dataDir);
    silveton::ui::SamplerAppController controller(env);
    silveton::ui::ArrangerView view(controller);
    if(argc>4)view.setHomePageForPreview(std::atoi(argv[4]));
    if(argc>5){
        if(silveton::ui::files::isDirectory(argv[5]))view.setKstDirectoryForPreview(argv[5]);
        else{
            auto& host=silveton::host::arrangerHost();host.prepare(48000,64);
            if(!host.loadStyle(0,argv[5])){std::cerr<<host.lastError()<<'\n';return 1;}
            std::array<float,128> audio{};host.renderAdd(audio.data(),64,48000);
            view.tick(silveton::ui::nowMs()+200);
        }
    }
    silveton::ui::Canvas canvas(1340,800);view.draw(canvas);
    if(!silveton::ui::writePng(argv[2],canvas)){std::cerr<<"Cannot write preview\n";return 1;}
    return 0;
}
