#pragma once
#include "silveton/arranger/ArrangerEngine.h"

#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/Pa5xHomeTabs.h"
#include "silveton/host/ArrangerHost.h"
#include "silveton/arranger/Pa5xKstIndex.h"
#include "silveton/arranger/Pa5xKstCatalog.h"
#include "silveton/arranger/Pa5xSetBank.h"
#include "silveton/arranger/Pa5xStyleRead.h"
#include "silveton/arranger/Pa5xStyleSourceSettings.h"
#include "silveton/arranger/Pa5xKeyboardSetRead.h"
#include "silveton/sampler/SourceEffects.h"
#include <array>
#include <atomic>
#include <functional>
#include <map>
#include <mutex>

namespace silveton::ui {

// Native Pa-series performance surface. The 800x480 display geometry follows
// the official Pa5X Home/Keys/Mixer/Scale pages; physical-panel actions live
// outside that display on the tablet. The existing sampler remains the editor.
class ArrangerView : public SilvetonSamplerView {
public:
    explicit ArrangerView(SamplerAppController& controller);
    ~ArrangerView();
    void draw(Canvas& canvas);
    void pointer(PointerAction action, float x, float y, std::int64_t eventTimeMs = 0);
    void secondPointerDown(float x, float y);
    void keyDown(Key key);
    bool dialogOpen() const;
    bool editorActive() const noexcept { return editor_; }
    void tick(std::int64_t now);
    bool redrawDue(std::int64_t now) const;
    std::uint64_t renderCacheKey() const noexcept;
    std::int64_t nextWorkMs() const;
    bool interactiveFeedbackActive(std::int64_t now) const noexcept { return pointerActive_ || now<controlFeedbackUntil_; }
    void invalidateDisplay() noexcept { dirty_=true; }
    void setWarning(const std::string& message);
    void setMidiConnections(int count);
    void globalChangedOutside();
    void showToast(const std::string& text, int durationMs = 2000);
    void showSoloPart(int upper, int sound = 0);
    void chooseSoloModelFile(int upper, int sound, const std::string& directory);
    void setHomePageForPreview(int page);
    // Physical pixels corresponding to the currently drawn detail page.
    // Also used by native touch regression tests at different screen sizes.
    std::pair<float,float> detailPoint(float x,float y) const noexcept;
    void setKstDirectoryForPreview(const std::string& path);
    void requestKstScan(const std::string& path);
    void setKstStatePath(const std::string& path);
    void setStorageAccessRequest(std::function<bool()> request);
    void resumePersistentState();
    void flushPersistentState();

private:
    friend struct ArrangerKstCatalogTestAccess;
    friend struct Pa5xHomeTabTestAccess;
    friend struct DrumEditorTestAccess;
    using Tab = Pa5xHomeTab;
    enum class Picker { None, Style, Sound, KeyboardSet, Set, Split, KstFolder, KstProgress, KstReport, KstCatalog, KstSample, StyleRead, KeyboardSetRead, StyleInfo, HomeMenu, KeyboardEdit, ResourceSave, SavedKeyboardLibrary, SavedStyleLibrary, WriteMenu, SaveAsMenu, ArrangerControl, Media, SettingsMenu, SetInfo, SetSounds, SetSoundInfo, DrumKitEdit, DrumSampleSelect, DrumKeySelect, StyleSounds, StyleDrums, DrumFamilyEdit, KeyboardParts, StyleControls, Pa5xFxCatalog, NumberedFxEdit, NumberedFxValue, NumberedFxTrack, OriginalSoundSettings, Switches, VelocityControl };
    enum class KeyboardEditPage { Main, Eq, EqAdvanced, FxSend, InsertFx, Effects, Tune, Mode, SoundEdit, RangeWrap, Range, Controllers, Aftertouch, Guitar };
    int trackEditPlayer_{-1},styleEditTrack_{0},rangeElement_{-1};
    bool choosingRangeElement_{false};
    bool styleTracksSecondPage_{false},fxChoosing_{false};
    KeyboardEditPage keyboardEditPage_{KeyboardEditPage::Main};
    enum class PanelMode { Home, File, Settings };
    PanelMode panelMode_{PanelMode::Home};
    enum class GlobalPage { Menu, General, Controllers, MidiInput, MasterEq };
    GlobalPage globalPage_{GlobalPage::Menu};
    struct GlobalSettingsRecord {
        SamplerAppController::GlobalUiState state;
        SamplerAppController::GlobalAdvanced midi;
    };
    std::optional<GlobalSettingsRecord> globalSettingsRecord_;
    std::string globalSettingsPath_;
    bool globalSettingsRestorePending_{false},globalSettingsDirty_{false},globalSettingsSaveFailed_{false};
    bool globalSettingsRecordProtected_{false},globalSettingsRestoreFailed_{false};
    bool globalAudioBaselineSeen_{false};
    std::int64_t globalSettingsSaveDue_{0},globalSettingsRestoreDue_{0};
    struct Entry { std::string name, path; bool directory{false}; int value{-1}; };
    struct NavigationFrame {
        Picker picker{Picker::None};Tab tab{Tab::Main};bool editor{false};
        KeyboardEditPage keyboardPage{KeyboardEditPage::Main};PanelMode mode{PanelMode::Home};
        bool globalSplit{false};
        int styleSelectorTarget{-1};
        int catalogTab{0},keyboardTarget{-1};
        GlobalPage globalPage{GlobalPage::Menu};
        int soundPart{0},soundTrack{-1},soundPlayer{-1};
        std::uint64_t soundSerial{0};
        bool soundEdit{};
        int keyboardTargetPlayer{-1};
        std::uint64_t keyboardTargetSerial{0};
        Page editorPage{Page::COMBI};
        int listPage{0},listCategory{0},catalogPage{0};
        std::string listDirectory,listError;
        std::vector<Entry> listEntries;
        std::vector<SamplerAppController::SoundItem> listSounds;
    };
    std::vector<NavigationFrame> navigationHistory_;
    int keyboardHoldPosition_{-1};
    std::int64_t keyboardHoldDeadline_{0},panelFlashPhase_{-1};
    std::string keyboardHoldStyleKey_;
    std::uint64_t keyboardHoldStyleSerial_{0};
    RectF keyboardHoldRect_{};
    bool keyboardExtension_{false};
    int keyboardEditPart_{0}, keyboardFxUnit_{0}, keyboardSourceFxPage_{0};
    int fxCatalogPage_{0}, fxCatalogCategory_{0}, fxCatalogSelected_{-1};
    int fxCatalogFilter_{0}; // Available for this slot / unfinished / all.
    int nativeFxCategory_{0}, nativeFxPage_{0};
    int fxCatalogSourceIndex_{-1};
    std::string fxCatalogSourceContext_;
    struct NumberedFxTarget {
        bool active{false},insert{false};
        int player{-1},part{0},slot{0};
        std::uint64_t styleSerial{0};
        std::weak_ptr<const sampler::Combi> keyboardOwner;
    } numberedFxTarget_;
    // A frozen, read-only copy from the selected original SET slot. This is
    // inspection data, never a manual assignment target or initialized preset.
    struct NumberedFxSourcePreview {
        sampler::SourceFxSlotStatus slot;
        std::string context;
        bool style{false};
    };
    std::optional<NumberedFxSourcePreview> numberedFxSourcePreview_;
    int numberedFxIndex_{0},numberedFxPage_{0},numberedFxRow_{-1},numberedFxChoicePage_{0},numberedFxSection_{0};
    bool numberedFxZoom_{false};
    enum class ResetSurface { HomeTone, TrackTone, Volume };
    struct ResetTarget {
        ResetSurface surface{};
        int player{},part{};
        const char* parameter{};
        std::uint64_t selection{},soundRevision{};
        std::weak_ptr<const sampler::Combi> keyboard;
        bool matches(const ResetTarget& other) const;
    };
    struct Hit {
        RectF rect;
        std::function<void()> tap;
        std::function<void(float,float)> drag;
        bool triggerOnDown{false};
        std::function<void(float,float)> finishDrag;
        ResetTarget resetTarget{};
        std::function<void()> reset;
    };
    SamplerAppController& ctrl_;
    Tab tab_{Tab::Main};
    Picker picker_{Picker::None};
    std::array<host::ArrangerPlayerView,2> players_{};
    std::array<std::optional<SamplerAppController::UpperState>,7> uppers_{};
    std::optional<SamplerAppController::GlobalUiState> globalUi_;
    std::string combiName_, scaleName_;
    int audioSampleRate_{0};
    std::vector<std::pair<float,float>> upperMeters_;
    std::vector<SamplerAppController::SoundItem> sounds_;
    std::vector<Entry> entries_;
    std::array<int,4> keyboardSets_{{0,0,0,0}};
    std::array<std::string,4> keyboardSetNames_;
    using KeyboardSetLinks = std::array<std::pair<int,std::string>,4>;
    std::map<std::string,KeyboardSetLinks> keyboardSetLinks_;
    using NativeKeyboardSetLinks = std::array<std::pair<std::string,std::string>,4>;
    std::map<std::string,NativeKeyboardSetLinks> nativeKeyboardSetLinks_;
    std::array<std::string,4> keyboardSetPaths_{};
    struct KeyboardSoundBinding { int msb{-1}, lsb{-1}, program{-1}; std::string sourcePath; };
    std::array<KeyboardSoundBinding,7> keyboardSoundBindings_{};
    std::string activeNativeKeyboardSetPath_;
    std::string activeSavedKeyboardEntryPath_;
    int currentKeyboardCombiSlot_{0};
    std::string currentKeyboardCombiBankIdentity_;
    struct SavedKeyboardEntry {int bank{0},position{0};std::string path,name,sourcePath,identity,metadataFile;};
    struct SavedKeyboardRecall {
        bool active{false},splitDeclared{false},splitEnabled{true},lowerMuteBeforeFull{false},useGlobalSplit{true},requiresAvailableSound{false};
        int splitPoint{-1},chordScanArea{-1},bassInversion{-1};
        std::array<KeyboardSoundBinding,7> bindings{};
        std::array<int,7> low{},high{};
        std::array<bool,7> suppressed{};
    };
    // Retain an accepted recall until the audio-owned controls are published.
    // Immediate working-copy capture must not re-save the previous SET's state.
    std::uint32_t keyboardRecallPendingSerial_{0};
    int keyboardRecallPendingSplit_{-1},keyboardRecallPendingArea_{-1},keyboardRecallPendingBass_{-1};
    // Four independent edit buffers belong to the selected Style. Library
    // resources are copied into them; explicit saves publish immutable refs.
    struct KeyboardWorkingSet {
        std::shared_ptr<const sampler::Combi> combi;
        std::shared_ptr<const arranger::Pa5xKeyboardSetRead> read;
        SavedKeyboardRecall recall;
        std::string sourcePath,entryPath,metadataFile,metadataBindings,sourceIdentity;
        int nativeSlot{0};std::string nativeBankIdentity;
    };
    std::array<KeyboardWorkingSet,4> keyboardWorkingSets_{};
    struct PlayerKeyboardBuffers {
        std::string owner;std::uint64_t serial{0};
        std::array<KeyboardWorkingSet,4> working{};
        std::array<int,4> slots{};
        std::array<std::string,4> paths{},names{};
    };
    std::array<PlayerKeyboardBuffers,2> playerKeyboardBuffers_{};
    int keyboardWorkingPlayer_{-1};std::uint64_t keyboardWorkingStyleSerial_{0};
    struct StyleKeyboardCue {
        std::uint64_t serial{0};int player{-1},position{0},previousPosition{-1};
        std::string key,path,previousOwner;int slot{0};bool preview{false},manualOverride{false};
        KeyboardWorkingSet prepared,previous;
    };
    StyleKeyboardCue styleKeyboardCue_;
    std::vector<SavedKeyboardEntry> savedKeyboardEntries_;
    bool savedKeyboardLibraryDirty_{true};
    int savedKeyboardBank_{1},savedKeyboardPage_{0};
    int savedStyleBank_{1},savedStylePage_{0};
    std::vector<host::ArrangerSavedStyleEntry> savedStyleEntries_;
    bool resourceSaveSoundPage_{false};
    bool resourceSaveIsStyle_{false},resourceSaveToStyle_{false},resourceSaveStyleSource_{false},resourceSaveNameEditing_{false},resourceSaveOverwriteConfirm_{false};
    int resourceSaveBank_{1},resourceSavePosition_{1},resourceSaveStylePosition_{0};
    enum class ResourceSaveOwner { None, Style, StyleKeyboard, LibraryKeyboard, SourceKeyboard, NativeCombi };
    ResourceSaveOwner resourceSaveOwner_{ResourceSaveOwner::None};
    bool resourceSaveAs_{false};
    int resourceSavePlayer_{0},resourceSaveCombiSlot_{0},resourceSaveOriginalKeyboardPosition_{-1};
    std::string resourceSaveStyleKey_,resourceSaveKeyboardSource_,resourceSaveKeyboardEntry_,resourceSaveCombiBankIdentity_,resourceSaveDestinationLabel_;
    std::string resourceSaveName_;
    std::string keyboardMetadataLastSaved_;
    std::string keyboardMetadataFile_;
    std::array<int,7> keyboardRangeLow_{{0,0,0,0,0,0,0}};
    std::array<int,7> keyboardRangeHigh_{{127,127,127,127,127,127,127}};
    std::array<bool,7> keyboardSplitSuppressed_{};
    bool keyboardSplitEnabled_{true}, keyboardLowerMuteBeforeFull_{false}, keyboardUseGlobalSplit_{true};
    std::shared_ptr<const sampler::Combi> keyboardMetadataSavedState_;
    std::string keyboardMetadataSavedBindings_, keyboardMetadataError_;
    bool keyboardMetadataRestorePending_{false};
    // Only explicitly edited SILVETON FX are recalled over a matching native
    // Keyboard Set. The values carry no Program/PCM ownership.
    struct KeyboardFxOverrideState {
        std::string identity;
        std::uint8_t masterMask{0};
        std::uint32_t insertMask{0};
        std::array<std::uint8_t,sampler::kPartCount> sendMasks{};
        std::array<KeyboardSoundBinding,4> originalBindings{};
        bool routing{false},dirty{false};
        sampler::Combi values;
    };
    KeyboardFxOverrideState keyboardFxOverride_;
    std::string keyboardFxWarning_;
    int selectedKeyboardSet_{-1}, styleToKeyboardSet_{0};
    bool keyboardSetNextMeasure_{false}, applyingKeyboardSet_{false};
    int pendingKeyboardSet_{-1}, pendingKeyboardSetBar_{-1};
    std::uint64_t pendingKeyboardSetMeasure_{0};
    std::string keyboardRecallStyle_;
    int keyboardRecallElement_{-1};
    std::string uiBank_, uiStatePath_, selectedStyleKey_;
    bool controlStyleTracks_{false};
    std::vector<Hit> hits_;
    Hit held_{};
    int selectedPlayer_{0}, targetPart_{0}, targetTrack_{-1}, targetKbdSet_{-1};
    int targetKbdPlayer_{-1};
    std::uint64_t targetKbdSerial_{0};
    // Choosing a resource for the other Player does not move performance focus.
    int styleSelectorPlayer_{-1};
    std::array<std::pair<int,int>,2> savedStyleBrowse_{{{1,0},{1,0}}};
    int pickerPage_{0}, pickerCategory_{0}, midiConnections_{0};
    bool editor_{false}, dirty_{true}, dragging_{false}, mixerStyle_{true}, screenDrawing_{false};
    bool pointerActive_{false};
    std::int64_t controlFeedbackUntil_{0};
    std::int64_t pointerEventTimeMs_{0},resetDownTime_{},lastResetTapUp_{};
    float resetDownX_{},resetDownY_{},lastResetX_{},lastResetY_{};
    bool resetDragged_{};
    ResetTarget lastResetTarget_{};
    bool isResetDrag(float x,float y) const;
    void finishResetTap(const Hit& hit);

    float scale_{1.0F}, xOffset_{0.0F}, yOffset_{0.0F};
    bool tempoWheelTracking_{false}, tempoWheelAnchored_{false};
    int tempoWheelPlayer_{0};
    double tempoWheelAngle_{0.0}, tempoWheelRemainder_{0.0}, tempoWheelDesired_{120.0};
    std::int64_t tempoWheelDisplayUntil_{0};
    std::string tempoWheelSourceKey_;
    int tapTempoPlayer_{-1}, tapTempoCount_{0};
    std::int64_t tapTempoElapsed_{0};
    std::string tapTempoSourceKey_;
    bool scaleQuarterTonePage_{false};
    int scalePresetPage_{0};
    bool globalSplitEditing_{false};
    bool scaleNameEditing_{false}, scaleMainRemembered_{false}, scaleMainEnabled_{false};
    std::vector<float> scaleMainCents_;
    std::string scaleMainName_;
    int scaleMainTonic_{0};
    std::string pickerDirectory_, stylePickerError_, toast_, warning_;
    std::string styleInfoTitle_, styleInfoText_;
    std::weak_ptr<const arranger::Pa5xStyleRead> styleSourceOwner_;
    arranger::Pa5xStyleSourceSettings styleSourceSettings_;
    struct LiveLog;
    std::unique_ptr<LiveLog> liveLog_;
    bool performanceDiagnosticsInfo_{false};
    int performanceDiagnosticsXrunBaseline_{-1}, performanceDiagnosticsResetTid_{0};
    Picker styleInfoReturn_{Picker::None};
    int styleInfoPage_{0};
    mutable std::mutex warningMutex_;
    std::atomic<bool> warningChanged_{false};
    std::int64_t lastDraw_{0}, lastPoll_{-1000}, lastMetadataPoll_{-1000}, toastUntil_{0}, lastTap_{0};
    std::array<float,12> cents_{};
    struct KstJob;
    std::shared_ptr<KstJob> kstJob_;
    std::string sampleCacheDirectory_;
    std::string pendingStylePath_;
    int pendingStylePlayer_{0};
    arranger::KstProgress kstProgress_;
    std::string kstPcmCacheProgress_;
    std::shared_ptr<const arranger::Pa5xKstIndex> kstReport_;
    struct SampleSummary {
        std::size_t identified{},ready{},failed{},unlinked{},missing{},uncheckedFiles{};
        std::uint64_t pcmBytes{};
        bool preparationKnown{},inventoryIncomplete{};
    } sampleSummary_;
    std::map<std::uint64_t,unsigned> sampleClasses_;
    std::vector<std::size_t> catalogSampleRows_,drumSampleRows_;
    int catalogSampleFilter_{0},drumSampleFilter_{1};
    void classifySetSamples(const arranger::Pa5xSetBank& bank);
    void filterSamples(bool drum,int filter);
    void drawSampleFilters(Canvas& c,bool drum,float y);
    int soundFilter_{0},soundListPage_{0},soundSelection_{-1},soundDetailPage_{0};
    std::vector<std::size_t> visibleSetSounds_;
    sampler::ProgramPtr inspectedSound_;
    sampler::ProgramPtr originalSoundSettings_;
    sampler::SourceSoundEdits originalSoundEdits_{};
    std::vector<sampler::SourceFxSlotStatus> originalSoundFx_;
    int originalSoundPage_{0};
    int originalSoundTab_{0}; // Amp EG / Sound FX / oscillator controls
    std::vector<std::pair<std::string,std::string>> inspectedZones_;
    int inspectorAuditionKey_{60},inspectorAuditionVelocity_{96};
    void filterSetSounds(int filter);
    void inspectSetSound(std::size_t index);
    int drumKeyPage_{0},drumKey_{36},drumZone_{0},drumSamplePage_{0},drumTab_{0};
    int drumGroupEdit_{-1},drumGroupEditKey_{36},drumGroupMemberPage_{0};
    std::string drumGroupNumber_;
    std::shared_ptr<host::DrumKitDraft> drumDraft_;
    bool drumExitPrompt_{false},drumMidiLearn_{false};
    void openInspector(Picker page);
    bool leaveInstrumentEditor();
    void drawSetInspector(Canvas& c);
    void drawDrumEditor(Canvas& c);
    void drawNativeDrumKitPage(Canvas& c);
    void drawDrumGroups(Canvas& c);
    void drawDrumGroupPicker(Canvas& c);
    void openStyleDrumGroups(const host::StyleActivity::Drum& drum);
    void drawDrumSampleSelect(Canvas& c);
    void writeDrumDraft();
    void inspectorPager(Canvas& c,int& page,int total,int perPage);
    std::vector<arranger::Pa5xPcmFileStatus> kstPcmFiles_;
    void updatePcmFileReport(const arranger::Pa5xSetBank* bank,const arranger::Pa5xKstIndex& index);
    std::shared_ptr<const arranger::Pa5xKstCatalog> kstCatalog_;
    std::shared_ptr<const arranger::Pa5xKeyboardSetRead> keyboardSetContents_;
    Picker contentsReturn_{Picker::None};
    int styleReadPlayer_{0}, styleReadElement_{3};
    std::array<int,8> styleReadCvs_{{0,0,0,0,0,0,0,0}};
    int kstCatalogTab_{0}, kstCatalogPage_{0}, kstSampleIndex_{-1};
    struct StyleSelectState {
        std::string browserPath, categoryPath, lastSourcePath;
        int categoryPage{0};
        std::map<std::string,int> pages;
        bool initialized{false};
        bool locateActive{true};
        bool locateCategory{false};
    };
    std::map<std::pair<std::string,int>,StyleSelectState> styleSelectStates_;
    std::map<std::pair<std::string,int>,StyleSelectState> keyboardSelectStates_;
    struct PersistentUiState {
        int selectedPlayer{0}, catalogTab{0};
        bool mixerStyle{true};
        std::string pickerDirectory;
        std::map<std::pair<std::string,int>,StyleSelectState> selectors;
        std::map<std::string,KeyboardSetLinks> keyboardLinks;
        std::map<std::string,NativeKeyboardSetLinks> nativeKeyboardLinks;
        int styleToKeyboardSet{0};
        bool keyboardSetNextMeasure{false},upperVolumeLink{false};
        bool nativeKeyboardActive{false};
        std::string nativeKeyboardSetPath;
        std::string savedKeyboardEntryPath;
        std::string keyboardMetadataFile;
        bool keyboardSplitEnabled{true}, keyboardLowerMuteBeforeFull{false};
        int currentCombiSlot{0};std::string currentCombiBankIdentity;
        int styleKeyboardPosition{-1};std::string styleKeyboardOwner;
    };
    std::optional<PersistentUiState> persistentRestoreUi_;
    std::string persistentSessionPath_, persistentRestoreText_, persistentRestoreRoot_;
    struct PersistentSaveJob;
    std::shared_ptr<PersistentSaveJob> persistentSaveJob_;
    std::string persistentLastSaved_;
    std::uint64_t persistentUiRevision_{1}, persistentObservedUiRevision_{0}, persistentObservedHostRevision_{0};
    bool persistentSavePending_{false};
    std::vector<std::string> persistentRestoreRoots_;
    std::size_t persistentRestoreNext_{0};
    bool persistentConfigured_{false}, persistentRestorePending_{false};
    bool persistentRestoreActive_{false}, persistentRestoreLease_{false}, persistentHostPosted_{false};
    bool persistentSaveAllowed_{false}, persistentRecordProtected_{false};
    bool persistentRecordValid_{false};
    bool persistentRestoreRetry_{true};
    std::int64_t persistentChangedAt_{0};
    bool bankSoundsOnly_{false};
    std::function<bool()> storageAccessRequest_;
    std::string kstStatePath_, savedKstRoot_;
    int kstReportTab_{0}, kstReportPage_{0}, kstReportListPage_{0};
    std::string kstDetailTitle_, kstDetail_;
    struct MediaRestore;
    std::shared_ptr<MediaRestore> mediaRestore_;
    std::vector<Entry> mediaEntries_;
    std::string mediaSetRoot_;
    int mediaFolderTab_{-1};
    std::string mediaDirectory_,mediaCurrentSetPath_,mediaName_,mediaSaveTarget_,mediaLoadingSource_;
    int mediaSelected_{-1},mediaPage_{0};
    bool mediaSaveTab_{false},mediaNameEditing_{false},mediaOverwriteConfirm_{false},mediaPathRead_{false},mediaSaveTargetAs_{false};

    void openMedia(bool saving = false);
    void listMediaDirectory(const std::string& path);
    void drawMedia(Canvas& canvas);
    void loadMediaSelection();
    void saveMediaSet(bool saveAs = false);
    void editMediaSetName();
    void rememberMediaSetPath(const std::string& path);
    void adoptLoadedSetPerformance();
    bool readPersistentStateText(const std::string& text);
    bool beginMediaRestore(const std::string& path,const std::shared_ptr<const sampler::SetData>& prepared);
    bool prepareMediaRestore();
    std::vector<std::string> mediaRestoreSetRoots() const;
    bool finishMediaRestore();
    void failMediaRestore(const std::string& reason);


    void refresh(bool forceMetadata = true);
    void loadUiState();
    bool saveUiState();
    bool readPersistentState();
    std::string persistentStateText() const;
    void markPersistentStateChanged(bool refreshMetadata = true);
    void finishPersistentSave(bool wait);
    void pollPersistentState(std::int64_t now);
    void finishPersistentRestore();
    void abandonPersistentRestore();
    void persistentRestoreFailed(const std::string& reason);
    void selectStyleLinks();
    KeyboardWorkingSet captureKeyboardWorkingSet() const;
    bool postKeyboardRecall(int split,bool enabled,int scan,int bass);
    void rememberStyleKeyboardSet();
    bool prepareWorkingKeyboardSet(const std::string& path,int slot,KeyboardWorkingSet& result,std::string& error);
    bool applyWorkingKeyboardSet(const KeyboardWorkingSet& state,int position,bool notify);
    bool writeKeyboardWorkingMetadata(KeyboardWorkingSet& state,std::string& error);
    bool freezeKeyboardWorkingSet(KeyboardWorkingSet& state,const std::string& owner,int position,const std::string& name,std::string& path,std::string& error);
    bool activateNativeKeyboardSet(const std::string& path, int position = -1, bool notify = true);
    bool recallKeyboardSet(int position, bool notify = true,bool manual = true);
    void pollKeyboardSetRecall();
    void styleKeyboardSelectionAccepted(int player);
    void clearStyleKeyboardCue(bool restorePrevious);
    void overrideStyleKeyboardCue();
    void openKeyboardEdit(KeyboardEditPage page);
    void drawKeyboardEdit(Canvas& c);
    void drawHomeMenu(Canvas& c);
    void drawSwitches(Canvas& c);
    void drawVelocityControl(Canvas& c);
    void drawSettingsMenu(Canvas& c);
    void drawGlobalSettingsPage(Canvas& c);
    void openGlobalPage(GlobalPage page);
    bool changeGlobalSettings(const std::function<void(SamplerAppController::GlobalUiState&)>& change);
    bool changeGlobalMidi(const std::function<void(SamplerAppController::GlobalAdvanced&)>& change);
    void configureGlobalSettings(const std::string& directory);
    void rememberCurrentGlobalSettings(bool intentional = true);
    void restoreSavedGlobalSettings();
    void flushGlobalSettings();
    void pollGlobalSettings(std::int64_t now);
    bool saveKeyboardPerformanceMetadata(bool force = false);
    bool restoreKeyboardPerformanceMetadata();
    bool prepareKeyboardFxOverride(const std::string& path,const arranger::Pa5xKeyboardSetRead& read,
        sampler::Combi& combi,KeyboardFxOverrideState& state,std::string& warning);
    void captureKeyboardFxOverride(const sampler::Combi& before,const sampler::Combi& after);
    bool saveKeyboardFxOverride();
    void clearKeyboardFxOverride();
    bool readSavedKeyboardEntry(const std::string& path,SavedKeyboardEntry& entry,std::string& error) const;
    bool prepareSavedKeyboardEntry(const SavedKeyboardEntry& entry,host::ArrangerKeyboardSet& prepared,SavedKeyboardRecall& recall,std::string& error);
    bool commitKeyboardSave(bool toStyle,int bank,int position,int stylePosition,const std::string& name);
    bool commitStyleSave(int bank,int position,const std::string& name);
    bool findSourceKeyboardOverwrite(const std::string& source,const arranger::Pa5xKeyboardSetRead& read,std::string& entryPath,std::string& error) const;
    bool commitSourceKeyboardOverwrite(const std::string& name);
    bool prepareNativeKeyboardOverwrite(int slot,const std::string& bankIdentity,const sampler::Combi& stored,KeyboardWorkingSet& state,bool& applied,std::string& error);
    bool commitNativeKeyboardOverwrite(int slot,const std::string& bankIdentity,const std::string& name);
    bool resourceSaveDestinationExists() const;
    void refreshSavedKeyboardEntries();
    void openSavedKeyboardLibrary();
    void drawSavedKeyboardLibrary(Canvas& c);
    void openSavedStyleLibrary(int player = -1);
    void drawSavedStyleLibrary(Canvas& c);
    void openResourceSave(bool style,bool saveAs = false);
    bool resourceSaveOwnerMatches() const;
    void drawWriteMenu(Canvas& c);
    void drawResourceSave(Canvas& c);
    void editResourceSaveName();
    std::vector<std::string> keyboardPerformanceSetRoots() const;
    void home();
    void rememberNavigation();
    static int selectorFamily(Picker picker,int catalogTab);
    bool sameSelectorFamily(Picker picker,int catalogTab=0) const;
    void returnToModeMenu();
    bool restoreNavigation();
    void panelExit();
    void panelMenu();
    void openPanelFile();
    void openPanelSettings();
    void cancelKeyboardSetHold();
    void armKeyboardSetHold(int position,const RectF& rect);
    void openEditor(Page page);
    void openPicker(Picker type, int target = -1);
    void openKeyboardSetSelector(int position = -1);
    bool keyboardSetTargetValid(int position);
    int styleSelectorPlayer() const;
    bool styleSelectorOpen() const;
    void openStyleSelectorForPlayer(int player);
    void rememberPlayerKeyboardBuffers();
    void setPlayerFocus(int player, bool forceMetadata = true);
    void listDirectory(const std::string& path);
    void chooseEntry(const Entry& entry);
    void changeUpper(int part, const std::function<void(SamplerAppController::UpperState&)>& change);
    void controlRequested(bool accepted);
    void applySplit(int key);
    void normalizeKeyboardPartRange(int part);
    void setKeyboardSplit(bool enabled);
    bool partSolo(int player,int part) const;
    void togglePartMute(int player,int part,std::uint64_t selection=0);
    void listenPart(int player,int part,int key=-1);
    void solo(int track);
    void drawDisplay(Canvas& c);
    void drawHeader(Canvas& c);
    void drawPlayers(Canvas& c);
    void drawPads(Canvas& c);
    void drawKeys(Canvas& c, bool detailed);
    void drawMixer(Canvas& c);
    void drawLiveSoundPage(Canvas& c);
    void drawDrumFamilyEdit(Canvas& c);
    int drumFamily_{0};
    int drumFamilyParam_{0};
    bool drumStyleNotes_{false};
    int styleNoteKey_{-1},styleNotePage_{0};
    host::StyleActivity allStyleDrums_;
    host::RecentStyleHits styleNoteLamps_;
    int styleNotesPlayer_{-1};
    std::uint64_t styleNotesSerial_{0},styleNotesRevision_{0};
    host::StyleDrumFamilyMap drumFamilyMap_;
    std::uint64_t drumFamilySerial_{};
    int drumFamilyMapTrack_{-1},drumFamilyMapPlayer_{-1};
    void openLiveSoundPage(Picker page);
    void openTargetSound(int part,int track);
    void finishSoundSelection();
    int soundPlayer_{-1},drumTrack_{0},drumPage_{0};
    std::uint64_t soundSerial_{0};
    host::StyleActivity activity_;
    host::RecentStyleHits recentHits_;
    bool recentPartsOnly_{true};
    void drawActivitySwitch(Canvas& c,const RectF& rect,bool playing);
    std::array<int,8> activityCvs_{};
    int activityPlayer_{-1},activityElement_{-1},activityBlocked_{-1},drumNote_{-1};
    std::uint64_t activitySerial_{},activityRevision_{};
    enum class DrumParameter { Attack,Decay,Sustain,Release,Level,Pan,Tune,Gate };
    std::optional<DrumParameter> drumParameter_;
    std::optional<host::StyleActivity::Drum> editedDrum_;
    int previewDrumNote_{-1};
    std::int64_t previewDrumDeadline_{};

    void updateStyleActivity(const host::ArrangerPlayerView& player);
    void drawDrumEnvelope(Canvas& c,const host::StyleActivity::Drum& drum,const host::ArrangerTrackView& track);
    void editStyleDrum(int track,int note,DrumParameter parameter,int value);

    void drawControl(Canvas& c);
    void drawScale(Canvas& c);
    int fillControlSlot_{-1},fillControlPlayer_{-1};std::uint64_t fillControlSerial_{};
    void drawStyleControls(Canvas& c);
    void drawArrangerSettings(Canvas& c);
    void drawChords(Canvas& c);
    void drawChordSequence(Canvas& c);
    void drawChordSequenceEdit(Canvas& c);
    void beginChordSequenceEdit(int index);
    void insertChordSequenceEvent();
    void removeChordSequenceEvent();
    void adjustChordSequenceEvent(int field,int direction);
    arranger::ChordSequenceData chordSequenceDraft_;
    int chordSequenceEditIndex_{0};
    bool chordSequenceEdit_{false};
    void saveChordSequenceSlot();
    void loadChordSequenceSlot();
    bool chordSequencePage_{false};
    int chordSequencePageIndex_{0},chordSequenceSlot_{1};
    std::uint64_t chordSequenceSeen_{0};
    void drawMicGuitar(Canvas& c);
    void drawJukebox(Canvas& c);
    void drawMatrix(Canvas& c);
    void drawKaoss(Canvas& c);
    void switchHomeTab(Tab tab);
    void drawTabs(Canvas& c);
    void drawPicker(Canvas& c);
    void openPa5xFxCatalog(int focusIndex = -1, std::string sourceContext = {}, bool preserveTarget = false);
    void drawPa5xFxCatalog(Canvas& c);
    void openOriginalSoundSettings(sampler::ProgramPtr program,sampler::SourceSoundEdits edits={});
    void drawOriginalSoundSettings(Canvas& c);
    void focusPa5xFxCatalog(int index,bool chooseGroup);
    void showPa5xFxDetail(int index);
    void openNumberedFxSelector(bool insert,int part,int slot,std::uint64_t selection);
    void openNumberedFxEditor(int index);
    void openOriginalSourceFxEditor(const sampler::SourceFxSlotStatus& slot,
                                    const std::string& context,bool style);
    void openNumberedFxValue(int row);
    void drawNumberedFxEditor(Canvas& c);
    void drawNumberedFxValue(Canvas& c);
    void drawNumberedFxTrack(Canvas& c);
    std::shared_ptr<const sampler::Combi> numberedFxOwner();
    bool editNumberedFxSlot(const std::function<bool(sampler::EffectSlot&)>& change);
    void showStyleInfo(const std::string& title, const std::string& text);
    void showPerformanceDiagnostics();
    void resetPerformanceDiagnostics();
    std::string performanceDiagnosticsText();
    void exportPerformanceDiagnostics();
    void drawStyleInfo(Canvas& c);
    void startKstScan(const std::string& path, bool automatic = false);
    void pollKstScan();
    void closeKstScan(bool preserveRestore = false);
    void loadStyleForPlayback(int player, const std::string& path);
    void drawKstProgress(Canvas& c);
    void drawKstReport(Canvas& c);
    void openKstCatalog(int catalogTab = 0, int styleTarget = -1);
    void drawKstCatalog(Canvas& c);
    bool compactKstSelector() const {
        return liveView_ && kstCatalog_ && picker_==Picker::KstCatalog &&
               (kstCatalogTab_==0 || kstCatalogTab_==2) && !kstJob_ && !persistentRestoreActive_;
    }
    void drawCompactKstSelectorHeader(Canvas& c);
    void drawKstKeyboardSelect(Canvas& c);
    void chooseKstKeyboardSound(std::size_t index);
    void drawKstStyleSelect(Canvas& c);
    void drawKstSample(Canvas& c);
    void openStyleRead(int player);
    const arranger::Pa5xStyleSourceSettings& originalStyleSettings(
        const std::shared_ptr<const arranger::Pa5xStyleRead>& read);
    void drawStyleRead(Canvas& c);
    void openKeyboardSetRead(const std::string& path);
    void drawKeyboardSetRead(Canvas& c);
    bool liveView_{true};
    float displayLeft_{0},displayTop_{0},displayZoom_{1},displayHeight_{480};
    RectF panelViewport_{0,0,1640,1040};
    void drawDisplayAt(Canvas& c,float left,float top,float zoom,float contentHeight=480);
    void drawTabletPage(Canvas& c,const RectF& area,float contentHeight=480);
    void drawLiveView(Canvas& c);
    enum class LiveResource { KeyboardSet, UserKeyboard, Combi };
    struct LiveItem {std::string name,path,error;int bank{},slot{};};
    struct LiveBank {std::string id,name;LiveResource type;std::vector<LiveItem> items;};
    struct LiveSelector {
        std::vector<LiveBank> banks;
        int bank{},page{},bankPage{};
        bool choosingBank{};
    };
    LiveSelector performanceSelector_;
    std::weak_ptr<const arranger::Pa5xKstCatalog> liveCatalog_;
    bool liveListsDirty_{true};
    std::string liveSessionPath_,liveSamplerBank_;
    std::uint64_t liveListGeneration_{},liveSlotSerial_{};
    int liveSlot_{-1},liveSlotPlayer_{-1};
    bool choosingPerformance_{};
    bool upperVolumeLink_{};
    bool homeSoundEdit_{false},homeToneKeyboard_{true},soundResetPanel_{};
    int homeTonePart_{0},toneDialPreview_{-1};
    int tonePage_{},toneEqBand_{3};
    std::int64_t gatePollMs_{-1000};
    std::uint64_t gateDisplayKey_{0};
    bool gateDisplayValid_{false};
    std::uint64_t gateMeterDisplayKey(float reduction) const noexcept;
    float visibleGateReduction() const;

    bool eqAnalyzerOn_{true},eqAfter_{true},eqPeak_{true};
    int eqTapPlayer_{-2},eqTapPart_{-1},eqNumberField_{-1};
    std::uint64_t eqTapSerial_{};
    std::int64_t eqTapReadyMs_{};
    std::string eqNumber_;
    std::weak_ptr<const sampler::Combi> eqNumberOwner_;
    float eqGrabX_{};
    struct GateSourceInfo {std::weak_ptr<const sampler::Program> program;bool onlyOneShot{};};
    std::array<GateSourceInfo,sampler::kUpperLayers+1> gateSources_{};
    bool eqNumberFresh_{true};
    void stopEqTap();
    std::string toneDetail_,toneDetailContext_;
    float toneGestureLast_{};
    std::shared_ptr<const sampler::Combi> toneGestureOwner_;
    float toneDialValue_{0},toneDialGrabY_{0};
    void drawPartSoundDials(Canvas&,bool home,int player,int part,std::uint64_t selection,
                            const std::shared_ptr<const sampler::Combi>&,bool oneShot);
    struct GlideRecall {
        std::string preset;
        std::uint64_t serial{};
        std::weak_ptr<const sampler::Program> sound;
        std::array<float,4> duration{};
    };
    std::array<std::array<GlideRecall,8>,3> glideRecall_{};
    void togglePartGlide(sampler::UpperPart&,int player,int part,std::uint64_t selection);
    void openSoundWindow(bool keyboard,int part);
    void closeSoundWindow();
    bool soundWindowVisible() const;
    void drawHomeTone(Canvas&,bool ready);
    std::string styleSoundName(int track) const;
    void drawHomeFader(Canvas& c,float left,float width,bool keyboard,int index,bool ready);
    bool setKeyboardFader(int part,float level,bool followLink=true);
    void rebuildLiveLists();
    void drawLiveSelector(Canvas& c,bool ready);
    void chooseLiveItem(int index);
    void tapLiveKeyboardSlot(int position,const RectF& rect);
    void drawLiveHome(Canvas& c);
    void drawLiveHomeTabs(Canvas& c);
    void drawLiveTransport(Canvas& c);
    void drawLiveElement(Canvas& c,int index,const RectF& rect,const std::string& title,bool compact);
    void drawLiveMessage(Canvas& c,float top);
    void stepTempo(int step);
    void startStopPlayer(int player);
    void movePlayerFader(float position);
    void selectPanelKeyboardSet(int position,const RectF& rect);
    void drawPanel(Canvas& c);
    void drawTempoWheel(Canvas& c, const host::ArrangerPlayerView& player);
    void tapTempo(bool tempoOnly=false);
    void stepTranspose(int step);
    void resetTempoWheelGesture();
    void label(Canvas& c, const std::string& text, float x, float y, float size, ColorInt color,
               bool bold=false, float width=10000.0F, Align align=Align::Left);
    void box(Canvas& c, const RectF& r, ColorInt fill, ColorInt edge=0U, float radius=0.0F);
    void button(Canvas& c, const RectF& r, const std::string& text, ColorInt accent,
                bool on, bool enabled, std::function<void()> action, float size=13.0F, bool triggerOnDown=false);
    void hit(const RectF& r, std::function<void()> action,
             std::function<void(float,float)> drag={}, bool triggerOnDown=false,
             std::function<void(float,float)> finishDrag={});
    void screenHit(const RectF& r, std::function<void()> action,
                   std::function<void(float,float)> drag={}, bool triggerOnDown=false,
             std::function<void(float,float)> finishDrag={});
    void keyboard(Canvas& c, float x, float y, float w, float h, ColorInt color);
};

} // namespace silveton::ui
