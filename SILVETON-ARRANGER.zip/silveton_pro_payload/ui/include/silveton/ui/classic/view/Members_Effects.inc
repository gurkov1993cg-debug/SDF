// SILVETON_MAC_VIEW_V1 - the EFFECTS page (tablet SilvetonSamplerView.kt lines 2582-2721)
    void drawEffects(Canvas& c);
    void drawFxBoardV3(Canvas& c, const RectF& r, int unit);
    void tapTempo(int unit);
    std::vector<std::int64_t> tapTimes;
    // SILVETON_NEW_LOOK_V1: the new look of the EFFECTS page (this file is read before Members_Look.inc, so a key state is passed as the int value of NlBtn)
    void drawFxSends(Canvas& c, const std::array<int, 11>& types, int unit);   // left panel: SENDS matrix, INSERT keys, ROUTING, hints
    void fxKey2(Canvas& c, const RectF& r, const std::string& top, const std::string& sub, int state, float size1, float size2, bool lamp, float spacing1);
    void fxLitKey(Canvas& c, const RectF& r, const std::string& label, bool on, float size);   // dark key with amber lamp + letters when on (TEMPO SYNC)
    void fxKnobNl(Canvas& c, float cx, float cy, float radius, float value, float minV, float maxV, float step, float travel, bool bipolar,
                  const std::string& valueText, const std::string& label, float hitW, std::function<void(float)> onChange,
                  std::function<void()> exact, std::function<void()> reset);
