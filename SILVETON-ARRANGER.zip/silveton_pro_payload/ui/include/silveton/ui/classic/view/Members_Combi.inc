// SILVETON_MAC_VIEW_V1 - the COMBI page (tablet SilvetonSamplerView.kt lines 927-2051 and the helpers at 3263-3400)
    enum class TonePar { ATTACK, DECAY, SUSTAIN, RELEASE, CUTOFF, RESONANCE };
    struct ToneRange { float lo; float hi; int decimals; };

    static float getOr(const std::vector<float>& v, int i, float def) { return i >= 0 && static_cast<std::size_t>(i) < v.size() ? v[static_cast<std::size_t>(i)] : def; }
    static std::string tabName(UpperTab t);
    void postInvalidateDelayed(int ms);
    std::int64_t delayedRedrawMs_ = std::numeric_limits<std::int64_t>::max();

    void drawCombi(Canvas& c);
    void drawUpperMenu(Canvas& c, int i, float left, float w);
    void drawUpperStrip(Canvas& c, const RectF& r, int i, const UpperState& s, std::pair<float, float> meter);
    void drawUpperEditor(Canvas& c);
    void drawLayerTune(Canvas& c, const RectF& sec, int u, int l);
    // SILVETON_KEYRANGE_V1 / SILVETON_VELOCITY_V1 (View_Velocity.cpp): RANGE = the keys only, VEL = the strength of the key press
    struct SoundRanges { int keyLow{0}, keyHigh{127}, velLow{1}, velHigh{127}, transpose{0}; bool has{false}; std::string name; };
    void drawKeyRangePage(Canvas& c, const RectF& sec, int u, int sound);
    void drawVelocityPage(Canvas& c, const RectF& sec, int u, int sound);
    void drawSoundRows(Canvas& c, const RectF& a, int u, int sound, bool velocity);
    SoundRanges soundRanges(int u, int sound);
    void setSoundKeyRange(int u, int sound, int lo, int hi);
    void setSoundVelRange(int u, int sound, int lo, int hi);
    float velP(int u, int sound, int id, float def);
    void setVelP(int u, int sound, int id, float v);
    void selectSound(int u, int k);
    void paramChip(Canvas& c, const RectF& r, const std::string& label, const std::string& value, bool on, float v, float minV, float maxV,
                   float step, std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset);
    void drawToneV2(Canvas& c, const RectF& sec, int u, int sound);
    // SILVETON_TRANSWAVE_V1: the WAVE page of a sound (0 = basic, 1..4 = layer)
    void drawWave(Canvas& c, const RectF& sec, int u, int sound);
    std::vector<float> wParams(int u, int sound);
    float waveP(int u, int sound, int id);
    void setWaveP(int u, int sound, int id, float v);
    void setWavePOne(int u, int sound, int id, float v);
    std::array<std::array<std::optional<std::vector<float>>, 5>, kParts> waveParamsCache;
    static constexpr int kWavePickerBase = 100;   // PickerState::layer of a TRANSWAVE frame = 100 + sound * 8 + frame
    void drawPorta(Canvas& c, const RectF& sec, const UpperState& s);
    // SILVETON_ENGINES_V1: the ENGINE page of an Upper (View_Engine.cpp)
    void drawEngine(Canvas& c, const RectF& sec, int u);
    std::array<std::optional<std::vector<float>>, kParts> engineParamsCache;
    int enginePage_ = 0;                       // 0 ЗВУК, 1 ФИЛТЪР, 2 МОД
    void drawTune(Canvas& c, const RectF& sec, const UpperState& s);
    void hintLine(Canvas& c, const RectF& sec);
    void rangeHalf(Canvas& c, const RectF& half, const std::string& title, const std::string& lowLabel, const std::string& highLabel,
                   int lo, int hi, int minV, int maxV, const std::function<std::string(int)>& fmt, const std::string& hint,
                   std::function<void(int, int)> onRange, std::function<void()> exactLow, std::function<void()> exactHigh,
                   std::function<void()> reset, bool keyboard = false, int scanUpper = -1);
    void drawControl(Canvas& c, const RectF& sec, const UpperState& s);
    void drawUpperFx(Canvas& c, const RectF& sec, const UpperState& s);
    static float portamentoUiValue(float seconds);
    static float portamentoSecondsFromUi(float value);
    UpperState currentUpper(const UpperState& fallback) const;
    static float toneValue(const UpperState& s, TonePar p);
    static float toneToNorm(TonePar p, float v);
    static float toneFromNorm(TonePar p, float t);
    static std::string toneText(TonePar p, float v);
    static ToneRange toneRange(TonePar p);
    void setTone(TonePar p, float value);

    // EQ page and analyzer
    static float eqFreqX(float hz, float x0, float x1);
    static float eqXFreq(float x, float x0, float x1);
    static float eqGainY(float db, float y0, float y1);
    static float eqYGain(float y, float y0, float y1);
    static std::array<int, 4> eqBandIds(int b, int& count);
    static float eqResponseDb(const std::vector<float>& p, float hz);
    void drawEqPage(Canvas& c);
    void eqSlider(Canvas& c, const RectF& r, const std::string& label, const std::string& value, float t,
                  std::function<void(float)> onDrag, std::function<void()> plus, std::function<void()> minus, std::function<void()> exact);
    static constexpr int kAnalyzerBins = 240;
    std::vector<float> fftRe, fftIm, fftWin;
    float fftWinSum = 0.0F;
    std::vector<int> anLo, anHi;
    std::vector<float> anTilt;
    int anSr = 0;
    static void fft(std::vector<float>& re, std::vector<float>& im);
    void drawAnalyzer(Canvas& c, int u, float x0, float x1, float y0, float y1);

    // full-screen sound picker
    void openPicker(int upper, int layer);
    void cancelPicker();
    std::vector<SoundItem> pickerItems(PickerState& pk);
    void pickerAssign(PickerState& pk, const std::optional<SoundItem>& item);
    void drawPicker(Canvas& c, const std::shared_ptr<PickerState>& pk);
    void deleteMarkedSounds(const std::shared_ptr<PickerState>& pk);   // SILVETON_MULTI_DELETE_V1
    void deleteMarkedListEntries();

    // helpers
    void stepper(Canvas& c, const RectF& r, const std::string& title, const std::string& value,
                 std::function<void()> onMinus, std::function<void()> onPlus, std::function<void()> onReset);
    void copyUpper(int u);
    void pasteUpper(int target);
    bool pasteOne(const UpperClip& clip, int t);
    void toggleTercaLinked(int i);
    void toggleQuarterLinked(int i);
    void mirrorSound(int u, int layer);
    void flash(const std::string& message);
    void scanKey(Canvas& c, const RectF& r, int mode, const std::string& label);
    static std::string tercaText(const Ctrl::TercaState& t);
    void cellKey(Canvas& c, const RectF& r, const std::string& title, const std::string& value, std::function<void()> tap,
                 const std::optional<bool>& on = std::nullopt);
