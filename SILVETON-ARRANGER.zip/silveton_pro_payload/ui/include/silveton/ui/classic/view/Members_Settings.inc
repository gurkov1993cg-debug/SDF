// SILVETON_MAC_VIEW_V1 - the SETTINGS page (tablet SilvetonSamplerView.kt lines 2723-2928 and 3388-3470)
// SILVETON_NEW_LOOK_V1: tabs GENERAL, MIDI, INFO, SET and the pedal calibration screen (View_Settings.cpp)
    void drawSettings(Canvas& c);
    void drawGeneralSettings(Canvas& c);   // SILVETON_NEW_LOOK_V1: tab GENERAL
    void drawBankInfo(Canvas& c);          // tab INFO (the sound bank and MY WAVES)
    void drawMidiSettings(Canvas& c);      // tab MIDI
    void drawSetSettings(Canvas& c);       // SILVETON_LOGIC_V1: tab SET - save / load the whole set
    void drawPedalCalibration(Canvas& c, const GlobalUiState& g, const Ctrl::GlobalAdvanced& a);   // SILVETON_PEDAL_CAL_V1
    bool pedalCalOpen_ = false;
    void showDeleteSounds(const Ctrl::BankInfo& info);
    void runDeleteSounds(const std::vector<int>& slots);
    void editGlobal(int i, const GlobalUiState& g);
    void resetGlobal(int i, const GlobalUiState& g);
    static float globalStep(int i);
    static float globalTravel(int i);
    static std::array<float, 3> globalSliderSpec(int i, const GlobalUiState& g);
    static GlobalUiState globalWithSliderValue(int i, const GlobalUiState& g, float v);
    static std::string globalValueText(int i, const GlobalUiState& g);
    static std::string mb(long long bytes);
    // SILVETON_NEW_LOOK_V1: small drawing helpers of the SETTINGS page
    // a dark key; mode 0 = plain, 1 = off (dim), 2 = lit (amber text and an amber lamp bar); sub = the small second line
    void stgKey(Canvas& c, const RectF& r, const std::string& label, const std::string& sub, int mode, float size, bool lamp = true, float spacing = 0.07F);
    // a key with a name and a value that opens something when touched (tap runs, then the page is drawn again)
    void stgCell(Canvas& c, const RectF& r, const std::string& label, const std::string& value, int mode, float size, bool lamp, float spacing, std::function<void()> tap);
    // knob (diameter d) with its name above and the value below; drag, tap on it or on the value = number, double tap = default
    void stgKnob(Canvas& c, float cx, float cy, float d, float value, float minV, float maxV, float step, float travel, bool bipolar,
                 const std::string& valueText, const std::string& label, float vw, float hitW,
                 std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset);
    // tab SET: the saved sets (names and file sizes), the name to save under, the chosen one
    void refreshSetList();
    void saveSetNamed(const std::string& name);
    void loadSetNamed(const std::string& name);
    std::string setsName_ = "SILVETON SET";
    std::vector<std::pair<std::string, long long>> setsList_;
    std::string setsFolder_;
    bool setsListDirty_ = true;
    std::string setsPick_;
    int setsScroll_ = 0;
    int uiLangShown_ = -1;                 // LANGUAGE: the chosen language (read once from the saved setting)
    std::int64_t settingsLastDrawMs_ = 0;  // the page was left when this is old: the calibration closes, the saved sets are read again
