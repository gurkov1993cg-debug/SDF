    // Shared live shortcuts and a clear choice between one blend and a complete SET.
    bool saveOpen_ = false;
    void openSavePage();
    void drawSavePage(Canvas& c);
    void drawLiveActions(Canvas& c);
    std::string openBlendLabel();
