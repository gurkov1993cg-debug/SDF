// SILVETON_MAC_VIEW_V1 - dialogs. The tablet shows Android dialogs (AlertDialog, Dialog, EditText); here they are modal
// overlays drawn inside the same picture, after everything else. While one is open it gets all mouse and keyboard input.
    struct DialogButton {
        std::string label;
        std::function<void()> action;
    };
    // One key of the on-screen keyboard (design units; rebuilt at every draw).
    struct KbKey {
        enum class Act { Char, Backspace, Shift, Language, Clear, Sign, Space };
        RectF rect;
        Act act{Act::Char};
        std::string label;
        std::string output;      // what a Char key types (capital or not as drawn)
    };
    struct Dialog {
        enum class Kind { Message, Items, Multi, Wait, Grid, Text, Number };
        Dialog() = default;
        Dialog(const Dialog&) = delete;
        Dialog& operator=(const Dialog&) = delete;
        ~Dialog() { if (worker.joinable()) worker.join(); }

        Kind kind{Kind::Message};
        std::string title;
        std::string subtitle;
        std::string message;
        std::vector<DialogButton> buttons;            // left to right, the last one is the main one
        bool cancelable{true};
        std::function<void()> onCancel;               // Escape / click outside / CANCEL of the editor pages
        // list dialogs (Items, Multi)
        std::vector<std::string> items;
        std::function<void(int)> onItem;
        std::vector<bool> checked;
        int scroll{0};                                // first visible row
        // grid picker
        std::vector<std::pair<std::string, std::string>> gridItems;
        int gridCurrent{-1};
        std::string gridExtra;
        bool hasExtra{false};
        int gridPage{0};
        float pageScroll{0.0F};
        bool followPage{true};
        float wheelAcc{0.0F};
        std::function<void(int)> onPick;
        bool keepOpen{false};                         // SILVETON_ENGINES_V3: a pick does not close the window (the waves: choose and play)
        // text / number page
        std::string value;
        int cursor{0};
        bool selectAll{false};
        float numMin{0.0F}, numMax{1.0F}, numCurrent{0.0F}, lastPreview{0.0F};
        int numDec{2};
        float numStep{0.01F};
        bool numLive{true};
        bool previewed{false};
        std::function<void(float)> numDone;
        std::function<void()> numRestore;
        int repeatDir{0};
        int repeatCount{0};
        std::int64_t nextRepeatMs{0};
        RectF stepRect[2];
        // on-screen keyboard (SoftKeyboard on the tablet)
        std::vector<KbKey> kbKeys;
        int kbPressed{-1};
        int kbLang{0};                                // 0 = Latin, 1 = Bulgarian (БДС)
        bool kbShift{false};                          // one capital letter
        bool kbShiftOff{false};                       // the capital the sentence start asked for was cancelled
        bool kbCaps{false};                           // caps lock
        std::int64_t kbShiftTapMs{0};
        bool kbBackHeld{false};
        std::int64_t kbNextBackMs{0};
        int kbBackCount{0};
        // background work (the "please wait" dialog)
        std::thread worker;
        std::atomic<bool> workDone{false};
        std::function<void()> completion;
    };
    std::vector<std::shared_ptr<Dialog>> dialogStack;

    bool dialogIsOpen() const { return !dialogStack.empty(); }
    void drawDialogs(Canvas& c);
    void tickDialogs(std::int64_t now);
    bool dialogPointerHook(PointerAction action, float x, float y);
    void dialogKey(Key key);
    void dialogType(const std::string& utf8);
    void dialogWheel(float x, float y, float dy);
    void closeDialog(const std::shared_ptr<Dialog>& d);
    void dialogFire(const std::shared_ptr<Dialog>& d, const std::function<void()>& action);
    void dialogCancel(const std::shared_ptr<Dialog>& d);
    std::vector<std::string> wrapLines(const std::string& s, float size, Face face, float maxW);
    void dialogCard(Canvas& c, const RectF& r);
    void dialogKeyCap(Canvas& c, const RectF& r, const std::string& label, bool selected, float size, bool pressed, bool leftAligned = false);
    void dialogButtonRow(Canvas& c, const std::shared_ptr<Dialog>& d, const RectF& card, float top);
    void dialogHeadText(Canvas& c, const RectF& card, float top, float titleSize, const std::string& title, const std::string& subtitle);
    void drawDialogMessage(Canvas& c, const std::shared_ptr<Dialog>& d);
    void drawDialogList(Canvas& c, const std::shared_ptr<Dialog>& d);
    void drawDialogGrid(Canvas& c, const std::shared_ptr<Dialog>& d);
    void drawDialogEditor(Canvas& c, const std::shared_ptr<Dialog>& d);
    void drawSoftKeyboard(Canvas& c, const std::shared_ptr<Dialog>& d, const RectF& area);
    float softKeyboardHeight(const Dialog& d) const;
    bool kbShifted(const Dialog& d) const;
    void kbPress(const std::shared_ptr<Dialog>& d, int index);
    int kbKeyAt(const Dialog& d, float x, float y) const;
    void numberStepOnce(Dialog& d, int dir, float mult);
    void numberPreview(Dialog& d, float value);
    void numberSetText(Dialog& d, float value);
    float numberTyped(const Dialog& d) const;
    static std::string numberFormat(const Dialog& d, float value);

    // The Android calls, one for one
    void showMessage(const std::string& title, const std::string& message, const std::string& okLabel = "OK");
    void showConfirm(const std::string& title, const std::string& message, const std::string& positiveLabel,
                     std::function<void()> onPositive, const std::string& negativeLabel = "НЕ");
    void showItems(const std::string& title, const std::vector<std::string>& items, std::function<void(int)> onItem,
                   const std::string& negativeLabel = "ОТКАЗ");
    void showMultiChoice(const std::string& title, const std::vector<std::string>& labels, std::function<void(const std::vector<bool>&)> onPositive,
                         const std::string& positiveLabel, const std::string& negativeLabel = "ОТКАЗ");
    void showWait(const std::string& title, const std::string& message, std::function<std::function<void()>()> work);
    void showBlendPicker();
    void showSoundPicker(int upper);
    void showGridPicker(const std::string& title, const std::vector<std::pair<std::string, std::string>>& items, int current,
                        const std::optional<std::string>& extra, std::function<void(int)> pick);
    void showEditorPage(const std::shared_ptr<Dialog>& d, const std::string& title, const std::string& subtitle,
                        const std::string& applyLabel, std::function<void()> onApply);
    void showTextPage(const std::string& title, const std::string& current, std::function<void(const std::string&)> done);
    void showNumber(const std::string& title, float current, float minV, float maxV, int decimals, std::function<void(float)> done,
                    bool live = true, std::function<void()> restore = nullptr);
