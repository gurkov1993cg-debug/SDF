#pragma once

#include <array>
#include <cstddef>

namespace silveton::ui {

// Official Pa5X v1.4 HOME pane order.  UI navigation is independent from
// audio transport: switching panes must never stop a running Style.
enum class Pa5xHomeTab : unsigned char {
    Main, Keys, Control, Mixer, Scale, MicGuitar, Chords, Jukebox, Matrix, Kaoss
};
struct Pa5xHomeTabInfo {
    Pa5xHomeTab tab;
    const char* label;     // original HOME label
    const char* compact;   // fits an 800px instrument viewport
};
inline constexpr std::array<Pa5xHomeTabInfo, 10> kPa5xHomeTabs{{
    {Pa5xHomeTab::Main,     "MAIN",           "MAIN"},
    {Pa5xHomeTab::Keys,     "Keys",           "Keys"},
    {Pa5xHomeTab::Control,  "Control",        "Control"},
    {Pa5xHomeTab::Mixer,    "Mixer",          "Mixer"},
    {Pa5xHomeTab::Scale,    "Scale Tuning", "Scale Tune"},
    {Pa5xHomeTab::MicGuitar,"Mic & Guitar",  "Mic / Guitar"},
    {Pa5xHomeTab::Chords,   "Chords",         "Chords"},
    {Pa5xHomeTab::Jukebox,  "Jukebox",        "Jukebox"},
    {Pa5xHomeTab::Matrix,   "Matrix",         "Matrix"},
    {Pa5xHomeTab::Kaoss,    "Kaoss",          "Kaoss"},
}};
static_assert(kPa5xHomeTabs.size() == 10, "Pa5X v1.4 has ten HOME panes");
inline constexpr int homeTabIndex(Pa5xHomeTab tab) noexcept {
    return static_cast<int>(tab);
}
inline constexpr Pa5xHomeTab homeTabAt(std::size_t index) noexcept {
    return index < kPa5xHomeTabs.size() ? kPa5xHomeTabs[index].tab : Pa5xHomeTab::Main;
}
} // namespace silveton::ui
